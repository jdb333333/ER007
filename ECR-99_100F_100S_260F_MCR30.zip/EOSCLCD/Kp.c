#define KP_C
#include "king.h"
#include "exthead.h"
#include "exth.h"

/***************************************************************/
#define	DTR260	0
#define	TM3001	(DTR260+1)
#define	TM3002	(TM3001+1)
#define	DITRONP	(TM3002+1)
#define	DP3540	(DITRONP+1)
#define	POS58	(DP3540+1)
#define	KPMAX	POS58

#define KP_NORMAL   0   //������ӡ
#define KP_DBLWIDTH 1   //������ӡ
#define KP_BLACK    2   //��ɫ����
#define KP_RED      3   //��ɫ����
#define KP_CUTF     4   //ȫ��ֽ
#define KP_CUTH     5   //����ֽ
#define KP_DBLHIGH  6   //���ߴ�ӡ


const BYTE KPWidth[KPMAX+1]={21,16,21,24,16,16};//ccr2014-04-01,KPWidthΪ������ӡʱ���ַ���

//const BYTE KPArticleCmd[KPMAX+1]={1,1,1,1,1};

CONST BYTE KpCmd[KPMAX+1][7][4] = {
    {           /* DTR-260 */
		{3, 0x1b, 0x21, 0x00},    /* normal width */
		{3, 0x1b, 0x21, 0x20},    /* Double width */
		{3, 0x1b, 0x72, 0},    /* black */
		{3, 0x1b, 0x72, 1},    /* red */
		{2, 0x1b, 'i',  0},    /* Full Cut ESC i + 0*/
		{2, 0x1b, 'm',  0},    /* partial  Cut ESC m */
        {3, 0x1b, 0x21, 0x10},    /* Double heigth */
    },
    {           /* Epson A normal height */
		{3, 0x1b, 0x21, 0x00},    /* normal width */
		{3, 0x1b, 0x21, 0x20},    /* Double width */
		{3, 0x1b, 0x72, 0},    /* black */
		{3, 0x1b, 0x72, 1},    /* red */
		{2, 0x1b, 'i',  0},    /* Full Cut ESC i + 0*/
		{2, 0x1b, 'm',  0},    /* partial  Cut ESC m */
        {3, 0x1b, 0x21, 0x10},    /* Double heigth */
    },
    {           /* Epson B double height */
		{3, 0x1b, 0x21, 0x01},    /* normal width */
		{3, 0x1b, 0x21, 0x21},    /* Double width */
		{3, 0x1b, 0x72, 0},    /* black */
		{3, 0x1b, 0x72, 1},    /* red */
		{2, 0x1b, 'i',  0},    /* Full Cut ESC i + 0 */
		{2, 0x1b, 'm',  0},    /* partial  Cut ESC m */
        {3, 0x1b, 0x21, 0x11},    /* Double heigth */
    },
    {           /* DITRON Sprint */
		{3, 0x1b, 0x77, 0x30},    /* normal heigth */
		{3, 0x1b, 0x77, 0x31},    /* Double heigth */
		{0, 0, 0, 0},    /* black */
		{0, 0, 0, 0},    /* red */
		{0, 0, 0, 0},    /* Full Cut ESC i */
		{0, 0, 0, 0},    /* partial  Cut ESC m */
        {3, 0x1b, 0x21, 0x10},    /* Double heigth */
    },
    {           /* Citizen iDP3540, iDP3541 */
        {3, 0x1b, 0x21, 0},    /* normal width */
        {3, 0x1b, 0x21, 0x20},    /* Double width */
		{0, 0, 0, 0},    /* black */
		{1, 0x13, 0, 0},    /* red */
		{2, 0x1b, 'i',  0},    /* Full Cut ESC i + 0*/
		{2, 0x1b, 'm',  1},    /* partial  Cut ESC m */
        {3, 0x1b, 0x21, 0x10},    /* Double heigth */
    },
    {           /* POS58 */
		{3, 0x1b, 0x21, 0},    /* normal width */
		{3, 0x1b, 0x21, 0x20},    /* Double width */
		{0, 0x1b, 0x72, 0},    /* black */
		{0, 0x1b, 0x72, 1},    /* red */
		{0, 0x1c, 0x49, 0},    /* Full Cut */
		{0, 0x1c, 0x49, 1},    /* Partial Cut */
        {3, 0x1b, 0x21, 0x10},    /* Double heigth */
    },
};

/**
 * ���ݴ�ӡ���ͺ�,���ӡ������KpCmd�е�����
 *
 * @author EutronSoftware (2014-04-01)
 *
 * @param cmd
 */
void CmdKp(BYTE cmd)
{
    CONSTCHAR *p;
    BYTE l, type;

				/* 2 = DTR 260 */
				/* 3 = TM-300 Stand */
				/* 4 = TM-300 Double */
    type = ApplVar.KP.Prt->type & 0x0f;
	if (type > KPMAX+2)
		p = (CONSTCHAR *)KpCmd[0][cmd];
    else
		p = (CONSTCHAR *)KpCmd[type - 2][cmd];
    l = p[0];     /* command length */
    p++;
    while(l)
    {
		SendComm(ApplVar.KP.Prt->port-1, p[0]);
		p++;
		l--;
    }
}

/**
 * ��Ҫ��ӡ����������������ӡ��
 *
 * @author EutronSoftware (2014-04-01)
 *
 * @param cmd=0 normal print
 *        cmd=1 is double
 *        cmd=2 is double, red
 *        cmd=3 receipt issue
 * @param str :Ҫ��ӡ������
 */
void PrintKp(BYTE cmd,char *str)
{
	BYTE l, type;

#if !defined(DEBUGBYPC)
    if (!str)
		return;       /* empty string */
    type = ApplVar.KP.Prt->type & 0x0f;
    if (type == 1)  /* internal */
    {
		PrintStr(str);
		return;
    }
    if (!type)     /* not programmed */
		return;
		//PenGH  2008-10-21 10:16:19  for pos58 and pos80
    //if ((type == TM3001+2 || type == TM3002+2 || type == DP3540+2) && *str == ' ')  /* TM-300 /TM-300H ? */
		//str++;
		//PenGH

    l = KPWidth[type-2];

	//ccr2014-04-01>>>>>>
	if (cmd==KP_DBLHIGH)
	{
		CmdKp(KP_DBLHIGH);      /* ???????double width */
		l *= 2;
	}
    else if (cmd)
		CmdKp(1);      /* ???????double width */
    else
    {
		CmdKp(0);
		//PenGH 2008-10-21 10:21:34 for pos58 and pos80
		//if (type != DITRONP+2)  /* Sprint */
		    l *= 2;
	  //PenGH
	}
	//<<<<<<<<<<<
    if (cmd == 2)
		CmdKp(3);       /* red */
    else
		CmdKp(2);       /* black */

  //PenGH 2008-10-21 10:22:42 for pos58 and pos80
	//if (type == TM3001+2)
	//{
	//	PrintDotEpson(ApplVar.KP.Prt->port-1, str, /* (DOT & BIT7) | */BIT0); /* 1 is TM300 */
	//	return;
	//}
	//PenGH

    while(l && *str)
    {
		if (*str == '_')    /* double size char */
				SendComm(ApplVar.KP.Prt->port-1, ' ');
		else
				SendComm(ApplVar.KP.Prt->port-1, CheckChar(*str));
		str++;          /* ApplVar.KP's are all Epson Compatible now */
		l--;
    }
    //PenGH 2008-10-21 10:23:23 for pos58 and pos80
    //if (type == DITRONP+2)  /* Sprint */
		//SendComm(ApplVar.KP.Prt->port-1, 0x0d);
    //else
		SendComm(ApplVar.KP.Prt->port-1, 0x0a);
		//PenGH
#else
#endif
}

void PrintPbKp(BYTE kp)
{
    BCD num;
    BYTE type;

    MemSet(SysBuf, sizeof(SysBuf), ' ');
//ccr2014-04-01    if (ApplVar.PbNumber)
    {
		type = ApplVar.KP.Prt->type & 0x0f;
		num = ZERO;
		SysBuf[0] = 15;
		if (ApplVar.AP.Pb.Random & 0x0f)
		{
		    memcpy(num.Value, ApplVar.PB.Random, ApplVar.AP.Pb.Random & 0x0f);
		    if ((ApplVar.AP.Pb.Random & 0x0f) > 3)
				SysBuf[0] = 20;
		}
		else
		    WORDtoBCD(num.Value, ApplVar.PbNumber);
		FormatQtyStr(Prompt.Caption[23], &num, SysBuf[0]);
		if (type == 1 || !kp)  /* internal */
		    PrintStr(SysBuf);
		else
		    PrintKp(1, SysBuf);
		if (ApplVar.AP.Pb.Text && TESTBIT(KPPRICE, BIT6))
		{
		    RESETBIT(ApplVar.PrintLayOut, BIT2);
		    PrintKp(0, ApplVar.PB.Text);
		}
    }
/*ccr2014-04-01>>>>>>>
    else
    {
		PrintKp(0, (char*)Prompt.Message[26]);
	}
<<<<<*/
}
/**
 * �ڳ�����ӡ���ϴ�ӡƱͷ
 *
 * @author EutronSoftware (2014-04-01)
 */

void KpHeader()
{
    BYTE type;
    int l,i,w;

    type = ApplVar.KP.Prt->type & 0x0f;
    if (type > 1)  /* epson compatible external */
    {
		w = KPWidth[type-2]*2;

		SendComm(ApplVar.KP.Prt->port-1, 0x1b);
		//PenGH 2008-10-21 10:24:16 for pos58 and pos80
		//if (type == DITRONP+2)      /* Sprint */
		//		SendComm(ApplVar.KP.Prt->port-1, 'P'); /* select font 1 (8 X 11 dots) */
		//else
		{
			SendComm(ApplVar.KP.Prt->port-1, 'R');
			SendComm(ApplVar.KP.Prt->port-1, CHARSET & 0x0f);
		}
		//PenGH
    }
    else if (type)
	{
		w = PRTLEN;

		PrintHead1(3);
		RFeed(1);
	}
    ApplVar.PrintLayOut = 0x02;     /* for ApplVar.KP no double heigth */
    if (TESTBIT(KPPRICE, BIT1))
    {
		//ccr2014-04-01 if (ApplVar.PbNumber || Msg[CWXXI19].str[0]) /* text programmed */
		{
#if (!defined(CASE_MALTA))
		    PrintPbKp(1);
		    MemSet(SysBuf, sizeof(SysBuf), '=');
		    PrintKp(0, SysBuf);
#endif
		}
    }
    else if (Prompt.Message[48 + ApplVar.KP.Number][0])
    {
		MemSet(SysBuf, sizeof(SysBuf), '-');
		PrintKp(0, SysBuf);
    }
    if (Prompt.Message[48 + ApplVar.KP.Number][0])
    {
		PrintKp(0, (char*)Prompt.Message[48 + ApplVar.KP.Number]);
		MemSet(SysBuf, sizeof(SysBuf), '-');
		PrintKp(0, SysBuf);
    }
    if (type > 1)
		SendComm(ApplVar.KP.Prt->port-1, 0x0a);
}

void IssueKp()
{
    BYTE type;

    type = ApplVar.KP.Prt->type & 0x0f;
    if (!type)     /* not programmed */
	return;
    if (ApplVar.FTrain)     /* training ? */
    {
		MemSet(SysBuf, sizeof(SysBuf), ' ');
		strcpy(SysBuf + 5, Prompt.Message[42]);
		PrintKp(2, SysBuf);
    }
    MemSet(SysBuf, sizeof(SysBuf), ' ');
    GetReceiptNumber(SysBuf);
    //PenGH 2008-10-21 10:37:39 for pos58 and pos80
	//if (type == DITRONP+2 || type == TM3001+2)
    //{
		//if (LOCATION)
		//{
		//    SysBuf[8] = 'L';      /* location number */
		//    SysBuf[9] = '0';
		//    WORDtoASC(SysBuf + 10, LOCATION);
		//}
		//if (REGISTER)
		//{
		//    SysBuf[12] = 'R';      /* register number */
		//    SysBuf[13] = '0';
		//    WORDtoASC(SysBuf + 14, REGISTER);
		//}
		//CopyFrStr(SysBuf + 16, ApplVar.Clerk.Name);
		//PrintKp(0, SysBuf);
    //}
    //else
    //PenGH
    {
		CopyFrStr(SysBuf + 8, ApplVar.Clerk.Name);
		PrintKp(0, SysBuf);
    }
    MemSet(SysBuf, sizeof(SysBuf), ' ');
	DateTimeToStr(SysBuf,0);

    //PenGH 2008-10-21 10:39:37 for pos58 and pos 80
    //if (type == DITRONP+2)  /* Sprint */
		//SysBuf[24] = 0;
    //else
    // PenGH
    {
		SysBuf[24] = 0x1b;
		//PenGH 2008-10-21 10:40:27 for pos58 and pos80
		//if (type == DTR260+2)  /* DTR 260 */
		//{
		//    SysBuf[25] = 0x57;
		//    SysBuf[26] = 0x01;
		//}
		//else if (type == DP3540+2)     /* citizen */
		//{
		//	SysBuf[24] = 0x0e;              /* double width */
	  //  	SysBuf[25] = 0x0e;          /* send 3 times for line format */
	  //  	SysBuf[26] = 0x0e;
		//}
		//else
		//PenGH
		{
		    SysBuf[25] = 0x21;
		    SysBuf[26] = 0x21;
		}
		if (LOCATION)
		{
		    SysBuf[28] = 'L';      /* location number */
		    SysBuf[29] = '0';
		    WORDtoASC(SysBuf + 30, LOCATION);
		}
		if (REGISTER)
		{
		    SysBuf[32] = 'R';      /* register number */
		    SysBuf[33] = '0';
		    WORDtoASC(SysBuf + 34, REGISTER);
		}
		SysBuf[35] = 0;
    }
    PrintKp(0, SysBuf);
    //PenGH 2008-10-21 10:35:14 for pos58 and pos80
    //if (type == DTR260+2 || type==POS58+2)  /* DTR 260 */
		SysBuf[0] = 8;  // The old value is 5
//    else if (type == DITRONP+2)  /* Sprint */   //no chg pengh
//		SysBuf[0] = 5;                              //no chg pengh
    //else
		//SysBuf[0] = 9;
		// PenGH
    while(SysBuf[0])
    {
		SendComm(ApplVar.KP.Prt->port-1, 0x0a);
		SysBuf[0]--;
    }
    CmdKp(4);   /* issue */
    //PenGH 2008-10-21 10:36:18 for pos58 and pos80
	//if (type == TM3001+2 || type == TM3002+2)             /* TM-300 ? */
	//		SendComm(ApplVar.KP.Prt->port-1, FF);
	//PenGH
	Delay(100);             /* delay incase all ApplVar.KP got to same PHYSICAL ApplVar.KP */
	WaitOnLine(ApplVar.KP.Prt->port-1);
}

void KpEnd(BYTE kp)
{
    BYTE type;
    //char Nil[1];

    //Nil[0]=0;

    type = ApplVar.KP.Prt->type & 0x0f;
    if (type == 1 || !kp)
		RFeed(1);
    else if (type)
    {
//  PenGH 2008-11-06
#if (defined(CASE_MALTA))
        MemSet(SysBuf, sizeof(SysBuf), '-');    /* print line */
        PrintKp(0, SysBuf);
#else
		PrintKp(0, NULL);     /* empty line normal heigth */
#endif
// PenGH
    }
    if (!TESTBIT(KPPRICE, BIT1) || !kp)
		PrintPbKp(kp);
    if (type == 1 || !kp)
    {
		ApplVar.PrintLayOut = 0x02;
		ReceiptIssue(0);
    }
    else
		IssueKp();
}

void PrintArticle(BYTE cmd, BYTE kp)
{
    char temp[18];
    BYTE *item;

    MemSet(SysBuf, sizeof(SysBuf), ' ');
    if (!TESTBIT(KPPRICE, BIT1)) /* new German System? */
    {
		item = (BYTE *)ApplVar.Dept.Name;
		if (ApplVar.RGRec.Key.Code > PLU1) /* plu ? */
		{
		    if (ApplVar.AP.Plu.CapSize)         /* when programmed always print PLU  */
					item = (BYTE *)ApplVar.Plu.Name;
		    if (TESTBIT(KPPRICE, BIT3) /* Print PLU Number on ApplVar.KP*/
				&& ApplVar.AP.Plu.RandomSize < 3)
		    {
				if (ApplVar.AP.Plu.RandomSize)
				    HEXtoASC(SysBuf + sizeof(SysBuf) - 20,
				     ApplVar.Plu.Random, ApplVar.AP.Plu.RandomSize);
				else
				    WORDtoASCZero(SysBuf + sizeof(SysBuf) - 17, ApplVar.PluNumber + 1);
				if ((CHARSET & 0xf0) == 0x10 || (SLIP != 4 &&
				    ((CHARSET & 0x0f) == 3 || (CHARSET & 0x0f) == 7)
				     ))  /* number sign not available */
				    SysBuf[sizeof(SysBuf) - 21] = 'N';
				else
				    SysBuf[sizeof(SysBuf) - 21] = '#';
		    }
		}
		if ((ApplVar.Qty.Sign & 0x03) || (CompareBCD(&ApplVar.Qty, &ONE) > 0)
		    || TESTBIT(KPPRICE, BIT2+BIT3))  /* print price */
		{
		    FormatQty(SysBuf + sizeof(SysBuf) - 11, &ApplVar.Qty);
		    if (TESTBIT(KPPRICE, BIT2))  /* print price */
				FormatAmt(SysBuf + sizeof(SysBuf) - 2, &ApplVar.Price);
		    SysBuf[sizeof(SysBuf) - 9] = 'X';
		    SysBuf[sizeof(SysBuf) - 1] = 0;
		    if (kp)
				PrintKp(cmd, SysBuf + sizeof(SysBuf) - 22);
		    else
				PrintStr(SysBuf + sizeof(SysBuf) - 22);
		    MemSet(SysBuf, sizeof(SysBuf), ' ');
		}
		if (!TESTBIT(KPPRICE, BIT3) /* Not Print PLU Number on ApplVar.KP */
		    && ApplVar.RGRec.Key.Code > PLU1)
				item = (BYTE *)GetPluPrint(temp, cmd);
		if (kp)
		    PrintKp(cmd, item);
		else
		    PrintStr(item);
	}
    else
    {
		if ((ApplVar.Qty.Sign & 0x03) || (CompareBCD(&ApplVar.Qty, &THOUSAND) > 0))
		{
		    FormatQty(SysBuf + sizeof(SysBuf) - 10, &ApplVar.Qty);
		    SysBuf[sizeof(SysBuf) - 7] = 'X';
		    SysBuf[sizeof(SysBuf) - 6] = 0;
		    if (kp)
				PrintKp(cmd, SysBuf + sizeof(SysBuf) - 20);
		    else
				PrintStr(SysBuf + sizeof(SysBuf) - 20);
		    MemSet(SysBuf, sizeof(SysBuf), ' ');
		}
		else
		    FormatQty(SysBuf + 2 , &ApplVar.Qty);
		if (ApplVar.RGRec.Key.Code > PLU1) /* plu ? */
			memcpy(SysBuf + 5, (BYTE *)GetPluPrint(temp, cmd), ApplVar.AP.Plu.CapSize);
		else
			memcpy(SysBuf + 5, ApplVar.Dept.Name, ApplVar.AP.Dept.CapSize);
		SysBuf[PRTLEN] = 0; /* terminate */
		if (kp)
		    PrintKp(cmd, SysBuf);
		else
		    PrintStr(SysBuf);
    }
}

