#define ICBLOCK_C 2
#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"

/***************************************************************/
  //ccr chipcard 2004-07-01
void GetICBlockOffSet()
{
	//ApplVar.AP.ICBlock.CapSize = 10;
	RamOffSet = (UnLong)ApplVar.ICBlockNumber * icblockSize + ApplVar.AP.StartAddress[AddrICBlock] ;
}

void WriteICBlock()
{


    if (ApplVar.ICBlockNumber < ApplVar.AP.ICBlock.Number)
    {
     GetICBlockOffSet();
     WriteRam((BYTE *)&ApplVar.ICBlock.ICCardNO, 4);
    }
}

void ReadICBlock()
{

    GetICBlockOffSet();
    ReadRam((BYTE *)&ApplVar.ICBlock.ICCardNO, 4);

}


//----------------------------------------------------
void PrintICBlock()
{
	short i;
	BCD TempBCD;
	BYTE TempStr[15];

	RJPrint(print,Msg[GUASHIIC].str);

	for(ApplVar.ICBlockNumber=0;ApplVar.ICBlockNumber<100;ApplVar.ICBlockNumber++)
	{
	 	ReadICBlock();
	 	if (ApplVar.ICBlock.ICCardNO!=0)
	 	{
		  memset(TempStr,' ',sizeof(TempStr));
		  WORDtoASC(TempStr+4,ApplVar.ICBlockNumber+1);
		  TempStr[5]=':';
		  TempStr[6]=0;
		  TempBCD=ZERO;
		  ULongToBCDValue(TempBCD.Value,ApplVar.ICBlock.ICCardNO);
		  RJPrint(0,FormatQtyStr(TempStr,&TempBCD,PRTLEN));
	 	}
	}
}

//-----------------------------------------------------
BYTE QueryICBlock(unsigned long pICCardNO)
{
	BYTE IsBlock = 0;

	for(ApplVar.ICBlockNumber=0;ApplVar.ICBlockNumber<ApplVar.AP.ICBlock.Number;ApplVar.ICBlockNumber++)
	{
		 ReadICBlock();
		 if (ApplVar.ICBlock.ICCardNO == pICCardNO)
		 {
		  IsBlock = 1;
		  break;
		 }
	}
	return IsBlock;
}
