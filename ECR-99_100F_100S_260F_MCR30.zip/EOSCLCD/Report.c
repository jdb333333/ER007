#define REPORT_C 5
#include "king.h"
#include "exthead.h"
#include "exth.h"
#include "ejournal.h"
#include "fiscal.h"

/****************************************************************/


void PrintReportType()
{
    MemSet(SysBuf, sizeof(SysBuf), ' ');
    memcpy(SysBuf + 4, ApplVar.TXT.ReportType[ApplVar.Report.Type], sizeof(ApplVar.TXT.ReportType[0]));
    PrintStr(SysBuf);
    //PrintLine('-');//��Լֽ��
}

void PrintGroup(WORD number)
{
    ApplVar.GroupNumber = number;
    ReadGroup();

    if (ApplVar.RepComputer)
    {
        *((WORD *)SysBuf) = GROUP + 1;
        memcpy(SysBuf+7, ApplVar.Group.Name, ApplVar.AP.Group.CapSize);
        return;
    }
    if (SysBuf[0]&&ApplVar.AP.Group.CapSize)
    {
        memcpy(SysBuf+9,ApplVar.Group.Name,ApplVar.AP.Group.CapSize);
        PrintStr(SysBuf); /* print number */
    }
    else if (SysBuf[0])
        PrintStr(SysBuf); /* print number */
    else if (ApplVar.AP.Group.CapSize)
        PrintStr(ApplVar.Group.Name);
}

void PrintDept(WORD number)
{
    PrintLine('.');
    memset(SysBuf,' ',sizeof(SysBuf));

    ApplVar.DeptNumber = number;
    ReadDept();
    if (ApplVar.RepComputer)
    {
        *((WORD *)SysBuf) = DEPT + ApplVar.DeptNumber + 1;
        if (ApplVar.AP.Dept.RandomSize)
        {
            memcpy(SysBuf+7, ApplVar.Dept.Random, ApplVar.AP.Dept.RandomSize);
            SysBuf[2] = 0;  /* type = random number */
            SendRecord(SysBuf, 7 + 7);     /* always max size 14 */
        }
        *((WORD *)SysBuf) = DEPT + 1;
        memcpy(SysBuf+7, ApplVar.Dept.Name, ApplVar.AP.Dept.CapSize);
        return;
    }
    if (ApplVar.AP.Dept.RandomSize)
    {
        if (!SysBuf[0])
            SysBuf[0] = ' ';
        HEXtoASC(SysBuf + 10, ApplVar.Dept.Random, ApplVar.AP.Dept.RandomSize);
        SysBuf[9] = '#';
        PrintStr(SysBuf);
    }
    if (SysBuf[0]&&ApplVar.AP.Dept.CapSize)
    {
        memcpy(SysBuf+9,ApplVar.Dept.Name,ApplVar.AP.Dept.CapSize);
        PrintStr(SysBuf);
    }
    else if (SysBuf[0])
        PrintStr(SysBuf);
    else if (ApplVar.AP.Dept.CapSize)
        PrintStr(ApplVar.Dept.Name);
}


void PrintPlu(WORD number)
{
    BYTE i;
    char temp[10];
    BCD price;

    ApplVar.PluNumber = number;
    ReadPlu();
    if (ApplVar.RepComputer)
    {
        *((WORD *)SysBuf) = PLU1 + ApplVar.PluNumber + 1;
        if (ApplVar.AP.Plu.RandomSize)
        {
            memcpy(SysBuf+7, ApplVar.Plu.Random, ApplVar.AP.Plu.RandomSize);
            SysBuf[2] = 0;  /* type = random number */
            SendRecord(SysBuf, 7 + 7);     /* always max size 14 */
        }
        *((WORD *)SysBuf) = PLU1 + 1;
        memcpy(SysBuf+7, ApplVar.Plu.Name, ApplVar.AP.Plu.CapSize);
        return;
    }
    if (ApplVar.AP.Plu.RandomSize)
    {
#if (PRTLEN<25)
        HEXtoASC(SysBuf + 6, ApplVar.Plu.Random, ApplVar.AP.Plu.RandomSize);
        SysBuf[6] = SysBuf[0];          /* copy number sign */
#else
        HEXtoASC(SysBuf + 10, ApplVar.Plu.Random, ApplVar.AP.Plu.RandomSize);
        SysBuf[9] = SysBuf[0];          /* copy number sign */
#endif
        PrintStr(SysBuf);
        if (ApplVar.AP.Plu.CapSize)
            PrintStr(ApplVar.Plu.Name);
    }
    else
    {
        if (ApplVar.AP.Plu.CapSize)
            strncpy(SysBuf+8,ApplVar.Plu.Name,ApplVar.AP.Plu.CapSize);
        PrintStr(SysBuf);
    }
    if (ApplVar.AP.Plu.InvSize && ApplVar.Report.Type == 3)
    {
        if (TESTBIT(ART_LEVEL, BIT6))
            PrintQty(Prompt.Caption[48], &ApplVar.PluInventory);    /* qty */
    }
    if (ApplVar.Report.Type == REPTYPEMAX) // lyq
    {
        if (ApplVar.AP.Plu.InvSize)     /* print inventory */
        {
            PrintQty(Prompt.Caption[48], &ApplVar.PluInventory);    /* qty */
            Add(&ApplVar.SaleQty, &ApplVar.PluInventory);
            if (!TESTBIT(ART_LEVEL, BIT2) && ApplVar.AP.Plu.Cost) /* ApplVar.Cost price active ? */
            {
                price = ZERO;
                memcpy(price.Value, ApplVar.Plu.Cost, ApplVar.AP.Plu.PriceSize);
                Multiply(&price, &ApplVar.PluInventory);
                PrintAmt(Prompt.Caption[7], &price);   /* qty */
                Add(&ApplVar.SaleAmt, &price);
            }
        }
        return;
    }
    if (ApplVar.AP.Plu.PriceSize)
    {
        price = ZERO;
        CopyFrStr(temp, Prompt.Caption[4]);
        temp[9] = 0;
        for (i = 0; i < ApplVar.AP.Plu.Level; i++)
        {
            if (ApplVar.AP.Plu.Level > 1)
                WORDtoASC(temp + 8, i + 1);
            memcpy(price.Value, ApplVar.Plu.Price[i], ApplVar.AP.Plu.PriceSize);
            PrintAmt(temp, &price);
        }
    }
}


void PrintTender(WORD number)
{
    ApplVar.TendNumber = number;
    ReadTender();
    if (ApplVar.RepComputer)
    {
        *((WORD *)SysBuf) = TEND + 1;
        memcpy(SysBuf+7, ApplVar.Tend.Name, ApplVar.AP.Tend.CapSize);
        return;
    }
    if (SysBuf[0]&&ApplVar.AP.Tend.CapSize)
    {
        memcpy(SysBuf+9,ApplVar.Tend.Name,ApplVar.AP.Tend.CapSize);
        PrintStr(SysBuf);
    } /* print number+name */
    else if (SysBuf[0])
        PrintStr(SysBuf); /* print number+name */
    else if (ApplVar.AP.Tend.CapSize)
        PrintStr(ApplVar.Tend.Name);
}


void PrintPoRa(WORD number)
{
    ApplVar.PoRaNumber = number;
    ReadPoRa();
    if (ApplVar.RepComputer)
    {
        *((WORD *)SysBuf) = PORA + 1;
        memcpy(SysBuf+7, ApplVar.PoRa.Name, ApplVar.AP.PoRa.CapSize);
        return;
    }
    if (SysBuf[0]&&ApplVar.AP.PoRa.CapSize)
    {
        memcpy(SysBuf+9, ApplVar.PoRa.Name, ApplVar.AP.PoRa.CapSize);
        PrintStr(SysBuf); /* print number + name */
    }
    else if (SysBuf[0])
        PrintStr(SysBuf); /* print number */
    else if (ApplVar.AP.PoRa.CapSize)
        PrintStr(ApplVar.PoRa.Name);
}


void PrintCurrency(WORD number)
{
    ApplVar.CurrNumber = number;
    ReadCurr();
    if (ApplVar.RepComputer)
    {
        *((WORD *)SysBuf) = CURR + 1;
        memcpy(SysBuf+7, ApplVar.Curr.Name, ApplVar.AP.Curr.CapSize);
        return;
    }
    if (SysBuf[0]&&ApplVar.AP.Curr.CapSize)
    {
        memcpy(SysBuf+9, ApplVar.Curr.Name, ApplVar.AP.Curr.CapSize);
        PrintStr(SysBuf); /* print number + name */
    }
    else if (SysBuf[0])
        PrintStr(SysBuf); /* print number */
    else if (ApplVar.AP.Curr.CapSize)
        PrintStr(ApplVar.Curr.Name);
}


void PrintDrawer(WORD number)
{
    ApplVar.DrawNumber = number;
    ReadDrawer();
    if (ApplVar.RepComputer)
    {
        *((WORD *)SysBuf) = DRAW + 1;
        memcpy(SysBuf+7, ApplVar.Draw.Name, ApplVar.AP.Draw.CapSize);
        return;
    }
    if (SysBuf[0]&&ApplVar.AP.Draw.CapSize)
    {
        memcpy(SysBuf+9, ApplVar.Draw.Name, ApplVar.AP.Draw.CapSize);
        PrintStr(SysBuf); /* print number + name */
    }
    else if (SysBuf[0])
        PrintStr(SysBuf); /* print number */
    else if (ApplVar.AP.Draw.CapSize)
        PrintStr(ApplVar.Draw.Name);
}


void PrintCorrec(WORD number)
{
    short i,j;

    ApplVar.CorrecNumber = number;
    ReadCorrec();

    if (ApplVar.RepComputer)
    {
        *((WORD *)SysBuf) = CORREC + 1;
        j = 0;
        for (i=0;i<ApplVar.AP.Correc.CapSize;i++)
        {
            if (ApplVar.Correc.Name[i] != '~')
            {
                SysBuf[7+j] = ApplVar.Correc.Name[i];
                j++;
            }
//			memcpy(SysBuf+7, ApplVar.Correc.Name, ApplVar.AP.Correc.CapSize);
        }
        return;
    }
    if (SysBuf[0])
    {
        if (ApplVar.AP.Correc.CapSize)
        {
            j = 9;
            for (i=0;i<ApplVar.AP.Correc.CapSize;i++)
            {
                if (ApplVar.Correc.Name[i] != '~')
                {
                    SysBuf[j] = ApplVar.Correc.Name[i];
                    j++;
                }
            }
        }
        PrintStr(SysBuf); /* print number */
    }
    else if (ApplVar.AP.Correc.CapSize)
    {
        j = 0;
        for (i=0;i<ApplVar.AP.Correc.CapSize;i++)
        {
            if (ApplVar.Correc.Name[i] != '~')
            {
                SysBuf[j] = ApplVar.Correc.Name[i];
                j++;
            }
        }
        SysBuf[j] = 0;
        PrintStr(SysBuf);
    }
#if defined(FISCAL)
//ccr091223	if((ApplVar.Correc.Options & 0x07) == 2 ) // refund
//ccr091223		Add(&ApplVar.FRetAmt,&ApplVar.Total.Amt);
#endif

}

void PrintDisc(WORD number)
{
    ApplVar.DiscNumber = number;
    ReadDisc();

    if (ApplVar.RepComputer)
    {
        *((WORD *)SysBuf) = DISC + 1;
        memcpy(SysBuf+7, ApplVar.Disc.Name, ApplVar.AP.Disc.CapSize);
        return;
    }

    if (SysBuf[0])
    {
        if (ApplVar.AP.Disc.CapSize)
            memcpy(SysBuf+7, ApplVar.Disc.Name, ApplVar.AP.Disc.CapSize);
        PrintStr(SysBuf); /* print number */
    }
    else if (ApplVar.AP.Disc.CapSize)
        PrintStr(ApplVar.Disc.Name);
#if defined(FISCAL)
    Add(&ApplVar.FDiscAmt,&ApplVar.Total.Amt);
#endif
}


void PrintTax(WORD number)
{

    ApplVar.TaxNumber = number;
    ReadTax();
    if (ApplVar.RepComputer)
    {
        *((WORD *)SysBuf) = TAX + 1;
        memcpy(SysBuf+7, ApplVar.Tax.Name, ApplVar.AP.Tax.CapSize);
    }
    else
    {
        if (SysBuf[0])
        {
            if (ApplVar.AP.Tax.CapSize)
                memcpy(SysBuf+9, ApplVar.Tax.Name, ApplVar.AP.Tax.CapSize);
            PrintStr(SysBuf); /* print number */
        }
        else if (ApplVar.AP.Tax.CapSize)
            PrintStr(ApplVar.Tax.Name);
    }

    if (TESTBIT(ApplVar.Tax.Options, BIT0)) /* vat then calculate vat  ? */
    {
        if (ApplVar.Tax.Rate[0] == 0x99 &&
            ApplVar.Tax.Rate[1] == 0x99 &&
            ApplVar.Tax.Rate[2] == 0x99)
            ApplVar.Total.Disc = ZERO;              /* NET is zero */
        else
        {
            memcpy(ApplVar.Total.Qty.Value, ApplVar.Tax.Rate, sizeof(ApplVar.Tax.Rate));
            ApplVar.Total.Cost = ApplVar.Total.Amt;
            ApplVar.Total.Disc = ApplVar.Total.Amt;
            Add(&ApplVar.Total.Qty, &THOUSAND10);
            ApplVar.Total.Qty.Sign = 0x04;
            Divide(&ApplVar.Total.Disc, &ApplVar.Total.Qty);

            RoundBcd(&ApplVar.Total.Disc, 0);

            AmtRound(1, &ApplVar.Total.Disc);
            Subtract(&ApplVar.Total.Cost, &ApplVar.Total.Disc);  /* taxable - net */
        }
    }
    else    /* add On */
    {
        ApplVar.Total.Disc = ApplVar.Total.Amt;     /* ApplVar.Disc -> total NET */
        Add(&ApplVar.Total.Amt, &ApplVar.Total.Cost);   /* ApplVar.Amt -> Net + ApplVar.Tax */
    }
#if defined(FISCAL)
    if (ApplVar.ReportNumber == 1 && ApplVar.FReport == Z
        && !TESTBIT(ApplVar.FTotal_Flags,(1<<number))//ȱֽ���������´�ӡZ����,���ظ�ͳ�� //
        && !TESTBIT(ApplVar.Fiscal_PrintFlag,BIT5))  // Ϊ��ӡ��Z������������Z���ݴ���,���ظ�ͳ�� //
    {

        Add(&ApplVar.FTotalItem[number],&ApplVar.Total.Disc);
        Add(&ApplVar.FTax[number], &ApplVar.Total.Cost);            //�����ۻ�
        Add(&ApplVar.FTaxTotal[number],&ApplVar.Total.Cost);        //��ʷ�ۻ�
        ApplVar.FTotal_Flags |= 1<<number;//��Ǵ�˰�ֵ������Ѿ��ۼ�

    }
#endif

}


void PrintPbF(WORD number)
{
    ApplVar.PbFNumber = number;
    ReadPbF();

    if (ApplVar.RepComputer)
    {
        *((WORD *)SysBuf) = PBF + 1;
        memcpy(SysBuf+7, ApplVar.PbF.Name, ApplVar.AP.Pb.CapSize);
        return;
    }

    if (SysBuf[0])
    {
        if (ApplVar.AP.Pb.CapSize)
            memcpy(SysBuf+9, ApplVar.PbF.Name, ApplVar.AP.Pb.CapSize);
        PrintStr(SysBuf); /* print number */
    }
    else if (ApplVar.AP.Pb.CapSize)
        PrintStr(ApplVar.PbF.Name);

}

void PrintPb(WORD number)
{
    ApplVar.PbNumber = number;
    PbTotal(number+1,0);

    if (ApplVar.RepComputer)
    {
        *((WORD *)SysBuf) = PBTOT + 1;
        memcpy(SysBuf+7, ApplVar.PB.Text, ApplVar.AP.Pb.Text);
        return;
    }

    if (SysBuf[0])
    {
        if (ApplVar.AP.Pb.Text)
            memcpy(SysBuf+9, ApplVar.PB.Text, ApplVar.AP.Pb.Text);
        PrintStr(SysBuf); /* print number */
    }
    else if (ApplVar.AP.Pb.CapSize)
        PrintStr(ApplVar.PB.Text);

}

WORD PeriodSkip(struct REPSIZE *S, BYTE number)
{
    BYTE period;
    WORD skip;

    skip = 0;
    period = 0x08;
    do
    {
        if (S->Periods & period)
            skip += S->Length * (WORD)number;
        period >>= 1;
    }while (period);
    return skip;
}

/* set ApplVar.ErrorNumber to 27 if user break */

short CheckBreak()
{
//    if (ApplVar.RepComputer && COMPUTER)
//        ApplVar.ErrorNumber=ERROR_ID(CWXXI27);   /* rs232 error */
//    else
        CheckBreakKey();
    return(ApplVar.ErrorNumber);
}

void PrintRange()
{
    MemSet(SysBuf, sizeof(SysBuf), ' ');
    WORDtoASCZero(SysBuf + 11, ApplVar.Report.Start);
    SysBuf[12] = '-';
    WORDtoASCZero(SysBuf + 17, ApplVar.Report.End);
    SysBuf[18] = 0;

    PrintStr(SysBuf);

}


void ResetReport()
{
#if defined(FISCAL)
    if (ApplVar.FReport == Z && !ApplVar.ErrorNumber && ApplVar.Report.Type != REPTYPEMAX&& !TESTBIT(ApplVar.Fiscal_PrintFlag,BIT2))        /* Z report ? */
    {

        switch (ApplVar.Report.Type)
        {
        case 3: /* PLU */
        case 4: /* PO & RA */
        case 6: /* Corrections */
        case 7: /* Discount */
        case 8: /* Currency */
        case 9:    /* tax */
            // δ��ӡ˰��z����֮ǰ�����ϱ��������ݽ�ֹ���
            if (ApplVar.Report.System != 3 &&   /* only reset with fiscal */
                TESTBIT(ApplVar.MyFlags,ZREPORT))//ccr20130318 !ApplVar.Report.PointerType)
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI75);//�ȴ�ӡ˰��Z����
                break;
            }
        default:
            ApplVar.BufCC = 1;  /* set write only sign byte */
            ApplVar.Total.Qty.Sign = 0;
            WriteTotal();
            ApplVar.BufCC = 0;
            break;
        }
    }
#else

    if (ApplVar.FReport == Z && !ApplVar.ErrorNumber && ApplVar.Report.Type != REPTYPEMAX)      /* Z report ? */
    {
        ApplVar.BufCC = 1;  /* set write only sign byte */
        ApplVar.Total.Qty.Sign = 0;
        WriteTotal();
        ApplVar.BufCC = 0;
    }
#endif
}




short CheckTotal()
{
    BYTE temp, periods, periodnumber;
    WORD skip;
    struct REPSIZE *Si ;

    ApplVar.Report.Size = ApplVar.AP.Sales.RecordSize;
    ApplVar.Report.OffSet = 0;
    skip = 0;
    Si = ApplVar.AP.Sales.Size;
    if (ApplVar.Report.PointerType)
    {
        skip += PeriodSkip(Si, 1);
        Si++;
    }
    if (ApplVar.Report.PointerType > 1)
    {
        skip += PeriodSkip(Si, ApplVar.AP.Clerk.Number);
        Si++;
    }
    if (ApplVar.Report.PointerType > 2)
    {
        skip += PeriodSkip(Si, ApplVar.AP.Zone.Number);
        Si++;
    }
    if (ApplVar.Report.PointerType > 3)
    {
        skip += PeriodSkip(Si, ApplVar.AP.Day.Number);
        Si++;
    }
    if (ApplVar.Report.PointerType > 4)
    {
        skip += PeriodSkip(Si, ApplVar.AP.SalPer.Number);
        Si++;
    }
    memcpy(&ApplVar.Size, Si, sizeof(ApplVar.Size));    /* copy CONSTruction to work */
    if (!ApplVar.Size.Length)     /* not active report */
        return 0;
    if (!(ApplVar.Size.Periods & (0x01 << ApplVar.Report.Period))) /* not active */
        return 0;
    temp = 0x01;
    periods = 0;
    periodnumber = 0;
    do
    {
        if (temp & (0x01 << ApplVar.Report.Period))
            periodnumber = periods;
        if (ApplVar.Size.Periods & temp)
            periods++;
        temp <<= 1;
    } while (temp < 0x10);
    RamOffSet = ApplVar.AP.StartAddress[AddrTotl] + ApplVar.Report.OffSet + skip +
                (WORD)ApplVar.Report.Pointer * ApplVar.Size.Length * periods +
                (WORD)ApplVar.Size.Length * periodnumber +
                (WORD)ApplVar.Report.Start * ApplVar.Report.Size;
    ReadTotal();
    if (CheckNotZero(&ApplVar.Total.Amt))
        return 1;
    return 0;
}


void PrintReport(short RepFor,struct REPSIZE *S)
{
    BYTE temp, periods, periodnumber;

    WORD skip, total;
    UnLong save ;     /* unsigned long save; */
    UnLong TempL ;

    if (ApplVar.Report.Type != REPTYPEMAX)          /* ApplVar.Plu inventory ? */ //lyq
    {
        skip = 0;
        if (ApplVar.Report.PointerType)
        {
            skip += PeriodSkip(S, 1);
            S++;
        }
        if (ApplVar.Report.PointerType > 1)
        {
            skip += PeriodSkip(S, ApplVar.AP.Clerk.Number);
            S++;
        }
        if (ApplVar.Report.PointerType > 2)
        {
            skip += PeriodSkip(S, ApplVar.AP.Zone.Number);
            S++;
        }
        if (ApplVar.Report.PointerType > 3)
        {
            skip += PeriodSkip(S, ApplVar.AP.Day.Number);
            S++;
        }
        if (ApplVar.Report.PointerType > 4)
        {
            skip += PeriodSkip(S, ApplVar.AP.SalPer.Number);
            S++;
        }
        memcpy(&ApplVar.Size, S, sizeof(ApplVar.Size));    /* copy CONSTruction to work */
        if (!ApplVar.Size.Length)     /* not active report */
            return;
        if (!(ApplVar.Size.Periods & (0x01 << ApplVar.Report.Period))) /* not active */
            return;
        temp = 0x01;
        periods = 0;
        periodnumber = 0;
        do
        {
            if (temp & (0x01 << ApplVar.Report.Period))
                periodnumber = periods;
            if (ApplVar.Size.Periods & temp)
                periods++;
            temp <<= 1;
        } while (temp < 0x10);
        RamOffSet = ApplVar.AP.StartAddress[RepFor] + ApplVar.Report.OffSet + skip +
                    (WORD)ApplVar.Report.Pointer * ApplVar.Size.Length * periods +
                    (WORD)ApplVar.Size.Length * periodnumber +
                    (WORD)ApplVar.Report.Start * ApplVar.Report.Size;
    }

    temp = 0;

#if defined(FISCAL)
    if (ApplVar.MultiplyCount && !ApplVar.RepComputer && ApplVar.Report.System != 3)        /* range entered ? */
#else
    if (ApplVar.MultiplyCount && !ApplVar.RepComputer)      /* range entered ? */
#endif
    {
        if ((ApplVar.Report.Type == 3 || ApplVar.Report.Type == REPTYPEMAX) && ApplVar.AP.Plu.RandomSize)      /* PLU ? */
        {
            save = RamOffSet;               /* save report start */
            RamOffSet = ApplVar.AP.StartAddress[AddrPLU];    /* start plu table */
            ApplVar.Report.Start = GetPluNumber(0, ApplVar.Qty1.Value);
            if (ApplVar.MultiplyCount == 2)
            {
                RamOffSet = ApplVar.AP.StartAddress[AddrPLU];    /* start plu table */
                total = GetPluNumber(0, ApplVar.Qty2.Value);
            }
            else
                total = ApplVar.Report.Start;
            RamOffSet = save;
        }
        else
        {
            ApplVar.Report.Start = (WORD) BCDValueToULong(ApplVar.Qty1.Value, &TempL);
            if (ApplVar.MultiplyCount == 2)
                total = (WORD) BCDValueToULong(ApplVar.Qty2.Value, &TempL);      /* end address */
            else
                total = ApplVar.Report.Start;
        }
        if (total <= ApplVar.Report.End)
            ApplVar.Report.End = total;
        if (!ApplVar.Report.Start || ApplVar.Report.End < ApplVar.Report.Start)
            return;
        PrintRange();   /* print Range Line */
        ApplVar.Report.Start--;
        RamOffSet += ApplVar.Report.Size * ApplVar.Report.Start;
    }

    for (total = ApplVar.Report.Start; total < ApplVar.Report.End; total++)
    {
        save = RamOffSet;
        if (ApplVar.RepComputer == 'C' && ApplVar.FReport == Z)
        {
            ResetReport();
            RamOffSet = save + ApplVar.Report.Size ;
            continue;
        }
        if (ApplVar.Report.Type == REPTYPEMAX)   //lyq       /* inventory then always all plu's */
        {
            if (!ApplVar.AP.Plu.InvSize)            /* not active */
                break;
            SETBIT(ApplVar.Total.Qty.Sign, BIT2);
        }
        else
        {
            ReadTotal();     /* read correct total */
            if (CheckNotZero(&ApplVar.Total.RetQty))   /* Not Zero then */
                SETBIT(ApplVar.Total.RetQty.Sign, BIT7); /* Always negative */
        }


#if defined(FISCAL)
        if (TESTBIT(ApplVar.Total.Qty.Sign, BIT2) /*|| ApplVar.Report.Type == 10*/)     /* used ? */
#else
        if (TESTBIT(ApplVar.Total.Qty.Sign, BIT2))     /* used ? */
#endif
        {
            ApplVar.Total.Qty.Sign &= 0x83;
            if (!temp)
            {
                if (ApplVar.Report.System == 1)
                    PrintPointType();
                else if (!ApplVar.RepComputer)

                    PrintReportType();
                temp = 1;
            }

            if (!ApplVar.RepComputer)
            {
                MemSet(SysBuf, sizeof(SysBuf), ' ');
                if (ApplVar.Report.Type != 3 && TESTBIT(KEYTONE, BIT2))  /* Not print Number */
                    /* with PLU always */
                    SysBuf[0] = 0;
                else
                {
                    WORDtoASCZero(SysBuf + 5, total + 1);
                    if ((CHARSET & 0xf0) == 0x10 || (SLIP != 4 &&
                                                     ((CHARSET & 0x0f) == 3 || (CHARSET & 0x0f) == 7)
                                                    ))  /* number sign not available */
                        SysBuf[0] = 'N';
                    else
                        SysBuf[0] = '#';
                }
            }
            else
                MemSet(SysBuf + 7, 24, 0);

            if (ApplVar.Report.Type != REPTYPEMAX)  /* not inventory ? */ //lyq
            {
                Add(&ApplVar.SaleQty, &ApplVar.Total.Qty);
                Add(&ApplVar.SaleAmt, &ApplVar.Total.Amt);
            }
            switch (ApplVar.Report.Type)
            {
            case 0:     /* total Sales */
                if (ApplVar.RepComputer)
                {
                    *((WORD *)SysBuf) = RTOTAL;
                    memcpy(SysBuf + 7, ApplVar.TXT.ReportType[0], sizeof(ApplVar.TXT.ReportType[0]));
                }
                break;
            case 1:     /* group sales */
                PrintGroup(total);
                break;
            case 2:     /* dept sales*/
                PrintDept(total);
                break;
            case 3:     /* plu sales*/
            case REPTYPEMAX:        /* Inventory */      //lyq modefied 2003/11/1
                PrintPlu(total);
                break;
            case 4:     /* tender */
                PrintTender(total);
                break;
            case 5:     /* Po & Ra */
                PrintPoRa(total);
                break;
            case 6:     /* drawer */
                PrintDrawer(total);
                break;
            case 7:     /* correction */
                PrintCorrec(total);
                break;
            case 8:     /* discount*/
                PrintDisc(total);
                break;
            case 9:     /* foreign currency */
                PrintCurrency(total);
                break;
            case 10: /* tax */
                PrintTax(total);
                break;
            case 11: /* pb info */
                PrintPbF(total);
                break;
            case 13:
                PrintPb(total);
                break;
            default:
                return;
            }
            if (ApplVar.RepComputer)
            {
                *((WORD *)SysBuf) += total;     /* add current total number */
                SysBuf[2] = 0x80 + ApplVar.Report.Type + 1;  /* type = descriptor */
                SendRecord(SysBuf, 7 + 24); /* always send max size */
                if (ApplVar.Report.Type == REPTYPEMAX && ApplVar.AP.Plu.InvSize)   //lyq
                    SendComp(11, &ApplVar.PluInventory);
            }
            if (ApplVar.Report.Type != REPTYPEMAX)  //lyq            /* inventory  ? */
                PrintTotal();

            if (ApplVar.Report.System == 4 &&
                (ApplVar.Report.Type == 1 || ApplVar.Report.Type == 2))
            {
                Divide(&ApplVar.Total.Amt, &ApplVar.SubTotal);
                RoundBcd(&ApplVar.Total.Amt, 4);
                ApplVar.Total.Amt.Sign &= 0x80;
                ApplVar.Total.Amt.Sign |= 0x02;
                MemSet(SysBuf, 24, ' ');
                FormatQty(SysBuf+19, &ApplVar.Total.Amt);

                SysBuf[4] = '_';
                SysBuf[5] = SysBuf[13];
                SysBuf[6] = '_';
                SysBuf[7] = SysBuf[14];
                SysBuf[8] = '_';
                SysBuf[9] = SysBuf[15];
                SysBuf[10] = '_';
                SysBuf[11] = SysBuf[16];
                SysBuf[12] = '_';
                SysBuf[13] = SysBuf[17];
                SysBuf[14] = '_';
                SysBuf[15] = SysBuf[18];
                SysBuf[16] = '_';
                SysBuf[17] = SysBuf[19];
                SysBuf[18] = '_';
                SysBuf[19] = '%';
                PrintStr(SysBuf);
            }
            if (CheckBreak())
                return;
            RamOffSet = save;       /* reset address pointer */
            ResetReport();
        }
        else if (CheckBreak())
            return;
        RamOffSet = save + ApplVar.Report.Size;
    }

    if (!ApplVar.RepComputer && temp)
    {
        PrintLine('-');
    }
}


void PrintPluReport(short RepFor)
{
    ApplVar.Report.End = ApplVar.AP.Plu.Number;
    if (ApplVar.AP.Plu.RandomSize)
        ApplVar.Report.End =ApplVar.AP.Plu.RNumber;     /* calculate bytes to move 2nd part */
    if (!ApplVar.Report.End)
        return;
    ApplVar.Report.OffSet = ApplVar.AP.Plu.TotalOffSet;
    ApplVar.Report.Size = ApplVar.AP.Plu.RecordSize;
    PrintReport(RepFor,ApplVar.AP.Plu.Size);
}


void PrintDeptReport()
{
    if (!ApplVar.AP.Dept.Number)
        return;
    ApplVar.Report.End = ApplVar.AP.Dept.Number;
    ApplVar.Report.OffSet = ApplVar.AP.Dept.TotalOffSet;
    ApplVar.Report.Size = ApplVar.AP.Dept.RecordSize;
    PrintReport(AddrDept,ApplVar.AP.Dept.Size);
}

void PrintGroupReport()
{
    if (!ApplVar.AP.Group.Number)
        return;
    ApplVar.Report.End = ApplVar.AP.Group.Number;
    ApplVar.Report.OffSet = ApplVar.AP.Group.TotalOffSet;
    ApplVar.Report.Size = ApplVar.AP.Group.RecordSize;
    PrintReport(AddrGroup,ApplVar.AP.Group.Size);
}


void PrintTendReport()
{
    if (!ApplVar.AP.Tend.Number)
        return;
    ApplVar.Report.End = ApplVar.AP.Tend.Number;
    ApplVar.Report.OffSet = ApplVar.AP.Tend.TotalOffSet;
    ApplVar.Report.Size = ApplVar.AP.Tend.RecordSize;
    PrintReport(AddrTend,ApplVar.AP.Tend.Size);
}

void PrintPoRaReport()
{
    if (!ApplVar.AP.PoRa.Number)
        return;
    ApplVar.Report.End = ApplVar.AP.PoRa.Number;
    ApplVar.Report.OffSet = ApplVar.AP.PoRa.TotalOffSet;
    ApplVar.Report.Size = ApplVar.AP.PoRa.RecordSize;
    PrintReport(AddrPoRa,ApplVar.AP.PoRa.Size);
}


void PrintCurrReport()
{
    if (!ApplVar.AP.Curr.Number)
        return;
    ApplVar.Report.End = ApplVar.AP.Curr.Number;
    ApplVar.Report.OffSet = ApplVar.AP.Curr.TotalOffSet;
    ApplVar.Report.Size = ApplVar.AP.Curr.RecordSize;
    PrintReport(AddrCurr,ApplVar.AP.Curr.Size);
}


void PrintDrawReport()
{
    if (!ApplVar.AP.Draw.Number)
        return;
    ApplVar.Report.End = ApplVar.AP.Draw.Number;
    ApplVar.Report.OffSet = ApplVar.AP.Draw.TotalOffSet;
    ApplVar.Report.Size = ApplVar.AP.Draw.RecordSize;
    PrintReport(AddrDrawer,ApplVar.AP.Draw.Size);
}

void PrintCorrecReport()
{
    if (!ApplVar.AP.Correc.Number)
        return;
    ApplVar.Report.End = ApplVar.AP.Correc.Number;
    ApplVar.Report.OffSet = ApplVar.AP.Correc.TotalOffSet;
    ApplVar.Report.Size = ApplVar.AP.Correc.RecordSize;
    PrintReport(AddrCorr,ApplVar.AP.Correc.Size);
}

void PrintDiscReport()
{
    if (!ApplVar.AP.Disc.Number)
        return;
    ApplVar.Report.End = ApplVar.AP.Disc.Number;
    ApplVar.Report.OffSet = ApplVar.AP.Disc.TotalOffSet;
    ApplVar.Report.Size = ApplVar.AP.Disc.RecordSize;
    PrintReport(AddrDisc,ApplVar.AP.Disc.Size);
}

void PrintTaxReport()
{
    if (!ApplVar.AP.Tax.Number)
        return;
    ApplVar.Report.End = ApplVar.AP.Tax.Number;
    ApplVar.Report.OffSet = ApplVar.AP.Tax.TotalOffSet;
    ApplVar.Report.Size = ApplVar.AP.Tax.RecordSize;
    PrintReport(AddrTax,ApplVar.AP.Tax.Size);
}


void PrintPbFReport()
{
    if (!ApplVar.AP.Pb.Number || !ApplVar.AP.Pb.NumberOfPb)
        return;
    ApplVar.Report.End = ApplVar.AP.Pb.Number;
    ApplVar.Report.OffSet = ApplVar.AP.Pb.TotalOffSet;
    ApplVar.Report.Size = ApplVar.AP.Pb.RecordSize;
    PrintReport(AddrPBf,ApplVar.AP.Pb.Size);
}

void PrintPbtReport()
{
    if (!ApplVar.AP.Pb.Number || !ApplVar.AP.Pb.NumberOfPb)
        return;
    ApplVar.Report.End = ApplVar.AP.Pb.NumberOfPb;
    ApplVar.Report.OffSet = ApplVar.AP.Pb.PBTTotalOffset;
    ApplVar.Report.Size = ApplVar.AP.Pb.PBTRecordSize;
    PrintReport(AddrPBt,ApplVar.AP.Pb.PBTSize);
}


void PrintOpenPb()
{
    BYTE printed;
    UnLong TempL ;
    if (!ApplVar.AP.Pb.NumberOfPb)     /* not active */
        return;

    ApplVar.Entry = ZERO;
    ApplVar.Report.End = ApplVar.AP.Pb.NumberOfPb;
    if (ApplVar.MultiplyCount && !ApplVar.RepComputer)
    {
        ApplVar.PbNumber = (WORD) BCDValueToULong(ApplVar.Qty1.Value, &TempL);
        if (ApplVar.MultiplyCount == 2)
        {
            ApplVar.Report.End = (WORD) BCDValueToULong(ApplVar.Qty2.Value, &TempL);                 /* end address */
            if (ApplVar.AP.Pb.NumberOfPb < ApplVar.Report.End)
                ApplVar.Report.End = ApplVar.AP.Pb.NumberOfPb;
        }
        else
            ApplVar.Report.End = ApplVar.PbNumber;  /* One total only */
        ApplVar.Report.Start = ApplVar.PbNumber;
    }
    else
        ApplVar.PbNumber = 1;
    printed = 0;
    for (; ApplVar.PbNumber <= ApplVar.Report.End; ApplVar.PbNumber++)
    {
        PbTotal(ApplVar.PbNumber, 0);   /* read */
        if (ApplVar.PB.Block)        /* check if open */
        {
            if (ApplVar.Report.PointerType == 1 && ApplVar.Report.Pointer != (ApplVar.PB.Clerk - 1))
                continue;

//ccr091125PB.SalPer?			if (ApplVar.Report.PointerType == 5 && ApplVar.Report.Pointer != (ApplVar.PB.SalPer - 1))
//ccr091125PB.SalPer?				continue; //lyq20040113 added for print the "open table message"

            AmtRound(0, &ApplVar.PB.Amt);   /* round total amount */
            if (ApplVar.RepComputer && ApplVar.RepComputer != 'C')      /* 'C' is only reset */
            {
                *((WORD *)SysBuf) = PBTOT + ApplVar.PbNumber;
                SysBuf[3] = ApplVar.Report.Period;
                SysBuf[4] = ApplVar.Report.PointerType;
                if (ApplVar.Report.PointerType == 1)
                    *((WORD *)(SysBuf + 5)) = ApplVar.PB.Clerk - 1;
                else
                    *((WORD *)(SysBuf + 5)) = 0;
                if (ApplVar.AP.Pb.Random & 0x0f)
                {
                    SysBuf[2] = 0;  /* type = random number */
                    memcpy(SysBuf+7, ApplVar.PB.Random, 7);
                    SendRecord(SysBuf, 7 + 7);     /* always max size 14 */
                }
                if (ApplVar.AP.Pb.Text)
                {
                    SysBuf[2] = 1;  /* type = text */
                    memcpy(SysBuf+7, ApplVar.PB.Text, ApplVar.AP.Pb.Text);
                    SendRecord(SysBuf, 7 + 24);     /* always max size 24 */
                }
                SendComp(7, &ApplVar.PB.Amt);
            }
            else if (!ApplVar.RepComputer)
            {
                if (!printed)
                {
                    if (ApplVar.MultiplyCount)
                        PrintRange();           /* print entered range */
                    if (ApplVar.Report.System == 1)
                    {
                        if (ApplVar.Report.PointerType == 1)
                            PrintPointType();
                    }
                    else
                        PrintReportHeader();
                    printed = 1;
                }
                else
                    ApplVar.MultiplyCount = 0;
                if (ApplVar.AP.Pb.Random & 0x0f)
                {
                    memcpy(ApplVar.Entry.Value, ApplVar.PB.Random, 7);
                }
                else
                    WORDtoBCD(ApplVar.Entry.Value, ApplVar.PbNumber);
                PrintQty(Prompt.Caption[23], &ApplVar.Entry);
                if (ApplVar.AP.Pb.Text)
                    PrintStr(ApplVar.PB.Text);
                PrintAmt(Prompt.Caption[7], &ApplVar.PB.Amt);       /* Skip 2 spaces in front */
            }
            if (CheckBreak())
                return;

            Add(&ApplVar.SaleAmt, &ApplVar.PB.Amt);
#if (0)//ccr091214>>>>>>>>>>>
            if (ApplVar.FReport == Z)
            {
                if (ApplVar.Report.PointerType == 1 || ApplVar.MultiplyCount) /* clerk report */
                    PbTotal(ApplVar.PbNumber, 2);   /* reset ApplVar.PB of current ApplVar.Clerk */
                else
                {
                    MemSet(&ApplVar.PB, sizeof(ApplVar.PB), 0);
                    PbTotal(ApplVar.PbNumber, 1);    /* write back empty table */
                }
            }
#endif//<<<<<<<<<<<<<<<<<<<<
        }
    }
    //if (!ApplVar.RepComputer)
    //       PrintLine('=');//��Լֽ��
#if (0)//ccr091214>>>>>>>>>>>>>>>>>>>>>>
    if (ApplVar.Report.PointerType != 1  && !ApplVar.MultiplyCount && /* not clerk report */
        ApplVar.FReport == Z)
    {
        if (ApplVar.AP.StartAddress[AddrTrack] && ApplVar.AP.Pb.BlockSize) /* trackbuffer ? */
        {
            MemSet(SysBuf, ApplVar.AP.Pb.BlockSize, 0);
            RamOffSet = ApplVar.AP.StartAddress[AddrTrack];
            for (ApplVar.EmptyBlock = 0; ApplVar.EmptyBlock < ApplVar.AP.Pb.NumberOfBlocks; ApplVar.EmptyBlock++)
                WriteRam(SysBuf, ApplVar.AP.Pb.BlockSize);
            ApplVar.EmptyBlock = 0;
        }
    }
#endif//<<<<<<<<<<<<<<<<<<<<<<<<<<<
    ApplVar.PbNumber = 0;
}

void PrintPointReport()
{
    ApplVar.SaleAmt = ZERO;
    ApplVar.SaleQty = ZERO;
//ccr20130318>>>>>>>>>>>
    if (ApplVar.FReport == Z)
    {
        switch (ApplVar.Report.Type)
        {
        case 3: /* PLU */
        case 4: /* PO & RA */
        case 6: /* Corrections */
        case 7: /* Discount */
        case 8: /* Currency */
        case 9:    /* tax */
            // δ��ӡ˰��z����֮ǰ�����ϱ��������ݽ�ֹ���
            if (ApplVar.Report.System != 3 &&   /* only reset with fiscal */
                TESTBIT(ApplVar.MyFlags,ZREPORT))////ccr20130318 !ApplVar.Report.PointerType)
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI75);//�ȴ�ӡ˰��Z����
                break;
            }
        }
    }
//<<<<<<<<<<<<<<<<<<<<<<<

    switch (ApplVar.Report.Type)
    {
    case 0://Print TOTALSALES recordes
        ApplVar.Report.End = 1;
        ApplVar.Report.Size = ApplVar.AP.Sales.RecordSize;
        ApplVar.Report.OffSet = 0;
        PrintReport(AddrTotl,ApplVar.AP.Sales.Size);
        break;
    case 1:
        PrintGroupReport();
        break;
    case 2:
        PrintDeptReport();
        break;
    case 3:
        PrintPluReport(AddrPLU);
        break;
    case 4:
        PrintTendReport();
        break;
    case 5:
        PrintPoRaReport();
        break;
    case 6:
        PrintDrawReport();
        break;
    case 7:
        PrintCorrecReport();
        break;
    case 8:
        PrintDiscReport();
        break;
    case 9:
        PrintCurrReport();
        break;
    case 10:
        PrintTaxReport();
        break;
    case 11:
        PrintPbFReport();
        break;
    case 12:                         /* open table */
        PrintOpenPb();
        break;
    case 13:
        PrintPbtReport();
        break;
    case REPTYPEMAX:
        PrintPluReport(AddrRPLU); /* ApplVar.Plu inventory */
        break;
    default :
        break;
    }
    if ((ApplVar.MultiplyCount && ApplVar.Report.Type && (ApplVar.Report.Type == 12 || ApplVar.Report.Type < 4))
        || ApplVar.Report.Type == REPTYPEMAX)   /* Inventory ? */   //lyq
    {
        if (ApplVar.Size.Qty || ApplVar.Report.Type == REPTYPEMAX)
            PrintQty(Prompt.Caption[6], &ApplVar.SaleQty);
        PrintAmt(Prompt.Caption[7], &ApplVar.SaleAmt);
        PrintLine('-');
    }
    ApplVar.MultiplyCount = 0;
}

/* you must set up the period, pointertype and pointer number */

void GetSystemReport(BYTE clearall )
{

    if (!ApplVar.RepComputer && !clearall)
    {
/*		if (!ApplVar.ClerkNumber)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI33);
            return;
        }
        if (ApplVar.AP.SalPer.Number && !ApplVar.SalPerNumber)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI34);
            return;
        }
*/
        if (!Appl_EntryCounter || Appl_EntryCounter > 5)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI26);
            return;
        }

// liuj 0523
#if DD_MMC == 1
        ApplVar.EJContent = TXTCONT;
#endif
//	SETBIT(ApplVar.ContFlag, (ENSTORE|ENHEADER));


#if defined(FISCAL)
        ApplVar.PrintLayOut = 0x0b;
        ApplVar.FStatus = 0;        /* not Fiscal */

#else
        ApplVar.PrintLayOut = 0x0a;
#endif
        CheckSlip();
    }
    if (!clearall)
    {
        MemSet(&ApplVar.Report, sizeof(ApplVar.Report), 0);
        ApplVar.Report.Type = EntryBuffer[sizeof(EntryBuffer) - 3] & 0x0f;
        ApplVar.Report.Type *= 10;
        ApplVar.Report.Type += EntryBuffer[sizeof(EntryBuffer) - 2] & 0x0f;
        ApplVar.Report.PointerType = EntryBuffer[sizeof(EntryBuffer) - 4] & 0x0f;
        ApplVar.Report.Period = EntryBuffer[sizeof(EntryBuffer) - 5] & 0x0f;
    }
    ApplVar.Report.System = 1;
    if (!SetUpReport() || clearall)
    {
        if (clearall)
            ApplVar.ErrorNumber=0;
        else if (!ApplVar.RepComputer)
        {

            if (TESTBIT(KPPRICE, BIT4))
                PrintHead1(1);       /* print rest of header */
            else
                PrintHead1(PREHEADER);       /* print rest of header */
            PrintReportHeader();
            if (ApplVar.Report.Type < 12)
                PrintReportType();
        }
        if (Appl_EntryCounter < 5)
            ApplVar.Report.Pointer = 0;
        else
            ApplVar.Report.PointerEnd = ApplVar.Report.Pointer + 1;
        for (;ApplVar.Report.Pointer < ApplVar.Report.PointerEnd; ApplVar.Report.Pointer++)
        {
            if (ApplVar.Report.PointerType == 1)
            {
                ApplVar.ClerkNumber = ApplVar.Report.Pointer + 1;
                ReadClerk();
                if (!ApplVar.RepComputer && !TESTBIT(ApplVar.Clerk.Options, BIT7) &&
                    Appl_EntryCounter < 5 && !TESTBIT(CLERKFIX, BIT6))
                    /* all pointers then skip training clerk ? */
                    continue;
            }
            if (clearall)
                SETBIT(ApplVar.MyFlags, ENPRINTER);//ccr090508
            PrintPointReport();
            if (clearall)
                RESETBIT(ApplVar.MyFlags, ENPRINTER);//ccr090508

            if (ApplVar.ErrorNumber)  /* break */
                break;
        }

        if (!clearall)
            ReportEnd(1);
    }
}


void GetReport(BYTE xzNum)
{
    BYTE i, j, repnum;
    if (!xzNum || xzNum>XZNUM+1)
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI26);
        return;
    }
    if (xzNum == XZNUM+1)
        repnum = XZNUM;
    else
        repnum = XZTitle[xzNum-1].Index-1;

    if (xzNum==1 && ApplVar.FReport==Z && TESTBIT(ApplVar.Fiscal_PrintFlag, BIT5))//���Z����
        RESETBIT(ApplVar.MyFlags,ZREPORT);

    MemSet(&ApplVar.Report, sizeof(ApplVar.Report), 0);

#if defined(FISCAL)
//	for(i=0;i<ApplVar.AP.Tax.Number;i++)
//    	ApplVar.FTax[i] = ZERO;	//liuj 0605
    ApplVar.FStatus = 0;    /* non fiscal report */
    if (xzNum == 1 && ApplVar.FReport==Z)   /* fiscal report then copy report 0 from eprom */
    {
/*????	memcpy( (char *)&ApplVar.AP.ReportList[repnum],
           (CONSTCHAR *)&Default.ReportList[repnum], sizeof(struct FIXEDREPORT));*/
        ApplVar.Report.System = 3;  /* set fiscal report */
        MemSet(ApplVar.TaxItem, sizeof(ApplVar.TaxItem), 0);    /* used to collect data for */
        /* fiscal eprom */
#if DD_MMC == 1
        ApplVar.EJContent = CLOSCONT;
#endif
    }
#if DD_MMC == 1
    else
        ApplVar.EJContent = TXTCONT;
#endif
//	if(!TESTBIT(ApplVar.ContFlag,(ENSTORE|ENHEADER)))//liuj 0528 for print report paper out
//		SETBIT(ApplVar.ContFlag, (ENSTORE|ENHEADER));	//liuj0603

#endif
    if (repnum == XZNUM)
    {
#if !defined(FISCAL)
        if (!TESTBIT(KEYTONE, BIT3))    /* print power up message ? */
            ApplVar.PrintLayOut = 0x03;     /* r & j */
        else
            ApplVar.PrintLayOut = 0x02;     /* r & j */
#else
        ApplVar.PrintLayOut = 0x03;     /* r & j */
#endif
    }
    else
    {
        ApplVar.Report.PointerType = ApplVar.AP.ReportList[repnum].PointerType;
        ApplVar.PrintLayOut = ApplVar.AP.ReportList[repnum].PrintLayOut;
        ApplVar.Report.Period = ApplVar.AP.ReportList[repnum].Period;
    }

    if (!ApplVar.RepComputer)
    {

        if (ApplVar.FReport != SET)
        {
            if (ApplVar.FTrain) /* Training ? */
            {
                if (ApplVar.Report.PointerType != 1)
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI32);
                    return;
                }
                else if (TESTBIT(ApplVar.AP.ReportList[repnum].Options, BIT1))   /* all pointers ?*/
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI32);
                    return;
                }
            }
        }

        if (CheckSlip())
            return;

#if (DD_MMC)//ccr090819>>>>>>>>>>>>>>

#if (DD_FISPRINTER)
        if ((!TESTBIT(ApplVar.ContFlag, ENSTORE) || !TESTBIT(ApplVar.ContFlag, EJ_HEAD)) && !TESTBIT(ApplVar.MyFlags, ENPRINTER))
        {
            SETBIT(ApplVar.ContFlag,(ENSTORE | ENHEADER));
            if (xzNum!= 1 || ApplVar.FReport != Z)
                Print_NonFiscal();
            ApplVar.FReceipt = 1;
            ReceiptIssue(BIT2);
        }
#else
        StoreEJEnd();

        ApplVar.EJContent = CLOSCONT;
        SETBIT(ApplVar.ContFlag,(ENSTORE | ENHEADER));
        if (xzNum!= 1 || ApplVar.FReport != Z)
            Print_NonFiscal();
        PrintHead1(0);
#endif

#else
        if (ApplVar.PrintLayOut & 0x02)     /* print on receipt ? */
        {
            if (TESTBIT(KPPRICE, BIT4))     /* print on receipt ? */
                PrintHead1(1);
            else
                PrintHead1(PREHEADER);
        }
#endif//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#if defined(FISCAL)
        if (xzNum== 1  && ApplVar.FReport == Z)
            ApplVar.FStatus = 1;    /* set fiscal report */

        if (!TESTBIT(ApplVar.MyFlags, ENPRINTER)) //liuj0530 ccr070610!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            AddReceiptNumber();
        FiscalHeader();
#endif

        RFeed(1);
        MemSet(SysBuf, PRTLEN, ' ');

        if (repnum == XZNUM)
            memcpy(SysBuf, ApplVar.TXT.ReportType[REPTYPEMAX], sizeof(ApplVar.TXT.ReportType[0]));
        else
            memcpy(SysBuf, ApplVar.AP.ReportList[repnum].Name, sizeof(ApplVar.AP.ReportList[0].Name));

        SysBuf[16] = 0;
        if (ApplVar.FReport == Z)//ccr071212
            strcat(SysBuf," -Z" );
        else
            strcat(SysBuf," -X" );

        i = ApplVar.PrintLayOut;
        ApplVar.PrintLayOut &= 0xfc;            /* print Slip */
        PrintStr_Center(SysBuf,true);

        ApplVar.PrintLayOut = i & 0xe7;
        SETBIT(ApplVar.PrintLayOut, BIT2);      /* Double Height */
        PrintStr_Center(SysBuf,true);


        ApplVar.PrintLayOut = i;
        PrintLine('=');

        if (repnum == XZNUM)        /* Pb Invoice report ? */
        {
            if (!SetUpReport())
            {
                StorePbInvoice(2);      /* Print Pb Invoice report */
                ReportEnd(0);
                return;
            }
        }

        if (TESTBIT(ApplVar.AP.ReportList[repnum].Options, BIT0))   /* open drawer ?*/
            OpenDrawer();
    }
    if (!SetUpReport())
    {
        if (ApplVar.RepComputer || TESTBIT(ApplVar.AP.ReportList[repnum].Options, BIT1))   /* all pointers ?*/
            ApplVar.Report.Pointer = 0;
        else
            ApplVar.Report.PointerEnd = ApplVar.Report.Pointer + 1;
        for (;ApplVar.Report.Pointer < ApplVar.Report.PointerEnd; ApplVar.Report.Pointer++)
        {
            if (ApplVar.Report.PointerType == 1)
            {//report for clerk
                ApplVar.ClerkNumber = ApplVar.Report.Pointer + 1;
                ReadClerk();
                if (!ApplVar.RepComputer && !TESTBIT(ApplVar.Clerk.Options,BIT7) &&
                    TESTBIT(ApplVar.AP.ReportList[repnum].Options, BIT1) &&
                    !TESTBIT(CLERKFIX, BIT6))
                    /* all pointers then skip training clerk ? */
                    continue;
            }
            if (ApplVar.RepComputer != 'C')
            {
                if ((ApplVar.Report.PointerType == 5 || ApplVar.Report.PointerType == 1) && CheckTotal() == 0)
                {
                    continue;
                }
                PrintPointType();
            }
            /* % comparison ? */
            if (!ApplVar.RepComputer && TESTBIT(ApplVar.AP.ReportList[repnum].Options, BIT4))
            {
                i = ApplVar.PrintLayOut;
                ApplVar.PrintLayOut = 0;
                ApplVar.Report.Type = 0;                /* get total sales from this pointer */
                j = ApplVar.FReport;
                ApplVar.FReport = X;            /* simulate X */
                PrintPointReport();
                ApplVar.FReport = j;
                ApplVar.SubTotal = ApplVar.SaleAmt;             /* comparison total */
                ApplVar.Report.System = 4;              /* set percentage report */
                ApplVar.PrintLayOut = i;
            }
            for (i = 0; i < 16; i++)
            {
                ApplVar.Report.Type = ApplVar.AP.ReportList[repnum].Link[i];
                if (!ApplVar.Report.Type)   /* end list */
                    break;
                ApplVar.Report.Type--;
                if (ApplVar.MultiplyCount && !ApplVar.RepComputer)      /* range report? */
                    i = 16;         /* only print range !! */
                PrintPointReport();
                if (ApplVar.ErrorNumber)
                    break;
            }
            if (ApplVar.ErrorNumber)
                break;
        }
#if defined(FISCAL)
        if (xzNum == 1 && !ApplVar.RepComputer && !ApplVar.ErrorNumber /* fiscal report ? */
            && !TESTBIT(ApplVar.Fiscal_PrintFlag,BIT5))     //�Ƿ���������ݴ���
        {
            //��ӡ������۹�����Ŀ��Z�������ݺ�,��ӡ�ʹ洢Z�����Ļ�������
            PrintFiscalTax();
        }
#else
        if (xzNum == 1 && !ApplVar.RepComputer && !ApplVar.ErrorNumber)     /* fiscal report ? */
            PrintAmt(Msg[HSJXSHOU].str, &ApplVar.FTotal);  //cc 20071018
#endif

        ReportEnd(!TESTBIT(ApplVar.AP.ReportList[repnum].Options, BIT3));   /* add Z-Count */
#if !defined(FISCAL)//ccr091027
        if (TESTBIT(ApplVar.AP.ReportList[repnum].Options, BIT2) && ApplVar.FReport == Z)   //ccr2014-9-11
        {
            if ((ApplVar.Report.PointerType == 1) && ApplVar.FTrain)
                ApplVar.FisNumber.ReceiptNum[TRECEIPTS] = 0; /*ccr091027 reset training receiptnumber ?*/
            else
            {
                ApplVar.FisNumber.ReceiptNum[NRECEIPTS] = 0; /*ccr091027 reset  receiptnumber ?*/
                ApplVar.FisNumber.ReceiptNum[FRECEIPTS] = 0; /*ccr091027 reset  receiptnumber ?*/
            }
        }
#endif

    }
#if (DD_MMC)//ccr090819>>>>>>>>>>>>>>

#if (DD_FISPRINTER==1)
//		if (!TESTBIT(ApplVar.MyFlags, ENPRINTER))
//		{
//			StoreEJEnd();
//			SETBIT(ApplVar.ContFlag,(ENSTORE | ENHEADER));
//			PrintHead1(0);
//		}
#else
    if (TESTBIT(ApplVar.ContFlag,EJ_HEAD))
    {// EJ head has beed writed into EJ,Append EN ENDCONT auto.
        ApplVar.EJContent = ENDCONT;
        RJPrint(0,0);
    }
    RFeed(4);//ccr2014-08-14 ����˺ֽλ��
#endif

#endif//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

}
#if (BARCUSTOMER==1)
//��ӡ�����Ա����,xzԭ����ʶ��X��������Z����,xz=0ʱ����ӡȫ����Ա�嵥 //
void PrintBARCustomer(BYTE xz)
{
    if (ApplVar.AP.Plu.RandomSize == 7 && TESTBIT(ART_LEVEL, BIT3))
    {// �����Ա�ı��볤�ȱ����� 13λ  //
        SETBIT(ApplVar.PrintLayOut, BIT2);
        RJPrint(0,Msg[BARREPORT].str);//  �� Ա �� �� ��  //
        RESETBIT(ApplVar.PrintLayOut, BIT2);
        RFeed(1);
        PrintLine2('=');
        memset(SysBuf,' ',PRTLEN);
        CopyFrStr(SysBuf+5,Msg[TMHYHAO].str);// ��Ա��  //
        strcpy(SysBuf+PRTLEN-9,Msg[XFJE].str);
        RJPrint(0,SysBuf);
        PrintLine2('=');
        for (ApplVar.PluNumber = 0; ApplVar.PluNumber < ApplVar.AP.Plu.RNumber; ApplVar.PluNumber++)
        {
            memset(&ApplVar.Plu,0,sizeof(ApplVar.Plu));

            ReadPlu();

            if (ApplVar.Plu.Random[6]!=0x09 || ApplVar.Plu.Random[5]!=0x99)
                continue;
            ApplVar.Qty = ZERO;
            ApplVar.Price = ZERO;
            memcpy(&ApplVar.Price.Value,ApplVar.Plu.Price[0],5);
            if (!CheckNotZero(&ApplVar.Price) && xz!=0)
                continue;// û������ʱ������ӡ //

            memcpy(ApplVar.Qty.Value,ApplVar.Plu.Random,ApplVar.AP.Plu.RandomSize);

            strcpy(ProgLineMes,FormatQtyStr(0,&ApplVar.Qty,15));
            RJPrint(0,FormatAmtStr(ProgLineMes,&ApplVar.Price,PRTLEN));

            if (xz==Z)
            {
                memset(ApplVar.Plu.Price[0],0,5);
                WritePlu();
            }
            if (KbHit())
            {//any key for stop
                Getch();
                break;
            }
            FM_EJ_Exist();
        }
        ApplVar.BufKp = 0;
        SETBIT(ApplVar.MyFlags,PRNTRAI);
        PrintLine2('=');
        if (xz!=0)
        {
            ApplVar.FReceipt = 1;
            ReceiptIssue(1);
        }
    }
}
#endif


