#define   INITAPPL_C  6
#include "king.h"
#include "exthead.h"
#include "exth.h"
#include "flowbill.h" //lyq2003
#include "fiscal.h"
#include "Ejournal.h"
#include "message.h"

extern BYTE KeyFrHost;       //    ApplVar.Key code from host computer.

extern void CheckEJ(void);

#if defined(DEBUGBYPC)
#define __disable_irq() {}
#define __enable_irq() {}
#endif

/***************************************************************/
#if FLASH_AppRAM
void InitClearTotal(WORD recSize,WORD totalOff)
{
    //��ʹ��FLASG���洢�ļ�����ʱ,FLASH�еĳ�ʼֵΪ0xff,���Ա������Ϊ0
    if (recSize > totalOff)
    {
        WriteRam(PCBuffer,recSize - totalOff);
    }
}
#else
#define InitClearTotal(recSize,totalOff) {}
#endif


//============================= For Cortex M3 ER-50 ================================


//���������ݺͱ�������ȫ��д���ڴ汣����
extern void UART_PutChar (BYTE c);
//��LCD����ʾ�����ݸ��Ʊ�����,
//ctrl=true,����������;ctrl=false,������ʾʱ���״̬ʱ��������
void Copy_LCD(BYTE ctrl)
{
#if !defined(DEBUGBYPC)
    if (ctrl || InActive < ACTIVE)//���Ǵ�����ʾʱ���״̬
    {
        Save_LCD(ApplVar.LCD_Operator,ApplVar.LCD_Customer);
    }
#endif
}



/**
 *����Ҫ�����ı���(�������ݺ���������)������籣����RAM��
 *
 * @author EutronSoftware (2014-08-07)
 *
 * @param enSave :ǿ�Ʊ�������
 */
void Save_ConfigVar(bool enSave)
{
    int i;
    BYTE j;
    BYTE *applVar;

    if (TESTBIT(ApplVar.MyFlags,CONFIGECR) || enSave)
    {
        applVar= (BYTE*)&ApplVar.SIZE_EXTRAM;
        RESETBIT(ApplVar.MyFlags,CONFIGECR);
        ApplVar.InitFlags[1] = 0;
        for (i=0;i<Config_SIZE-sizeof(ApplVar.InitFlags);i++)
        {
            ApplVar.InitFlags[1] += *applVar;
            applVar++;
        }
        ApplVar.InitFlags[1] = ~ApplVar.InitFlags[1];
        ApplVar.InitFlags[1]++;
        ApplVar.InitFlags[0] = 0x55aa;
//......................................

        applVar= (BYTE*)ApplVar.ZCount;

        ApplVar.ApplVarCRC = j = 0;
        for (i=0;i<AppVAR_SIZE;i++)
        {
            j += *applVar;
            applVar++;
        }
        ApplVar.ApplVarCRC = ~j;
        ApplVar.ApplVarCRC++;

        RamOffSet = RamOfApplVar;
        WriteRam((BYTE*)&ApplVar,sizeof(APPLICATION_SAVE));
    }
    else
	{
        Save_ApplRam();
	}
}

/**
 *����������д���ڴ汣����
 *
 * @author EutronSoftware (2014-08-07)
 *
 * @param enSave :=true,ǿ�Ʊ�����������
 */
void Save_Config(bool enSave)
{
    int i;
    BYTE *applVar= (BYTE*)&ApplVar.SIZE_EXTRAM;

    if (TESTBIT(ApplVar.MyFlags,CONFIGECR) || enSave)
    {
        RESETBIT(ApplVar.MyFlags,CONFIGECR);
        ApplVar.InitFlags[1] = 0;
        for (i=0;i<Config_SIZE-sizeof(ApplVar.InitFlags);i++)
        {
            ApplVar.InitFlags[1] += *applVar;
            applVar++;
        }
        ApplVar.InitFlags[1] = ~ApplVar.InitFlags[1];
        ApplVar.InitFlags[1]++;

        RamOffSet = RamOfApplVar;
        ApplVar.InitFlags[0] = 0x55aa;

        WriteRam((BYTE*)&ApplVar,Config_SIZE);
    }
}
//���ڴ汣������ȡ��������
BOOL Recall_Config(void)
{
    WORD i,j;
    BYTE *applVar= (BYTE*)&ApplVar.SIZE_EXTRAM;

    __disable_irq();    //��ֹ�жϣ����Ᵽ������е����ݱ仯

    RamOffSet = RamOfApplVar;
    ReadRam((BYTE*)&ApplVar,Config_SIZE);

    j = 0;
    for (i=0;i<Config_SIZE-sizeof(ApplVar.InitFlags);i++)
    {
        j += *applVar;
        applVar++;
    }

    j+=ApplVar.InitFlags[1];

    __enable_irq();


    if (ApplVar.InitFlags[0] != 0x55aa || j)
        return false;
    else
        return true;

}
//////////////////////////////////////////////////////////////////////////////
//�ڹػ����ߵ���ʱ,����ҵ����صı������ݴ������ʧ�洢��
//��:�ܵ�ر�����RAM����FLASH��
//......................................................................

void Save_ApplRam()
{
    static WORD Saved1=00;

    int i;
    WORD j;

    BYTE *applVar= (BYTE*)ApplVar.ZCount;


//    if (ApplRamSaved==0x5a)//�������ʱ�ظ�����
    {
        __disable_irq();    //��ֹ�жϣ����Ᵽ������е����ݱ仯
        j = 0;

        ApplVar.ApplFlag =0x5aa5;

        ApplVar.ApplVarCRC = 0;//����ApplVarCRCҲ����ͳ��,��˱�����0,

        for (i=0;i<AppVAR_SIZE;i++)
        {
            j += *applVar;
            applVar++;
        }
        ApplVar.ApplVarCRC = ~(j & 0xff);
        ApplVar.ApplVarCRC++;

        if (Saved1!=j)//�������ʱ�ظ�����
        {
            ApplRamSaved = ~ApplRamSaved;
            Saved1=j;
#if defined(DEBUGBYPC)
            RamOffSet = RamOfApplVar + Config_SIZE;
            WriteRam((BYTE*)ApplVar.ZCount,AppVAR_SIZE);
#elif CASE_ER380
            SRAM_WriteBuffer((BYTE*)ApplVar.ZCount,RamOfApplVar + Config_SIZE + SRAM1_ADDR,AppVAR_SIZE);
#else
            SRAM_WriteBuffer((BYTE*)ApplVar.ZCount,RamOfApplVar + Config_SIZE,AppVAR_SIZE);
#endif
        }
        __enable_irq();

    }
}
//---------------------------------------------------------------------
//�ٿ���ʱ,�ѱ�������ҵ����صı������ݻָ��������ռ���
//��:�ܵ�ر�����RAM����FLASH��
//ApplVar_Restored = 0x5a:�ָ���������������0�������쳣
//return True:�ָ�������������false�������쳣
//......................................................................
BYTE Recall_ApplRam()
{
    WORD i;
    BYTE j;
    BYTE *applVar= (BYTE*)ApplVar.ZCount;

    __disable_irq();    //��ֹ�жϣ����Ᵽ������е����ݱ仯

    RamOffSet = RamOfApplVar + Config_SIZE;

    ReadRam((BYTE*)ApplVar.ZCount,AppVAR_SIZE);

    j = 0;
    for (i=0;i<AppVAR_SIZE;i++)
    {
        j += *applVar;
        applVar++;
    }

    if (j || ApplVar.ApplFlag != 0x5aa5)
    {
        ApplVar_Restored = 0x00;
        RJPrint(0,"Error when Recall Memory!");//testonly
       //memset((char*)ApplVar.ZCount,0,AppVAR_SIZE);
    }
    else
        ApplVar_Restored = 0x5a;
    __enable_irq();

    return (ApplVar_Restored == 0x5a);

}
//////////////////////////////////////////////////////////////////////////

void InitPlu()
{
    BYTE i;

    memcpy(&ApplVar.Plu, &Def.Plu,sizeof(ApplVar.Plu));
    if (ApplVar.AP.Plu.RandomSize)
        ApplVar.AP.Plu.RNumber = 9;//ApplVar.AP.Plu.Number;	 set all used

    for (ApplVar.PluNumber = 0; ApplVar.PluNumber < ApplVar.AP.Plu.Number; ApplVar.PluNumber++)
    {
        ApplVar.Plu.Dept = (ApplVar.PluNumber % ApplVar.AP.Dept.Number);
        ApplVar.Plu.OFFIndex = 1;
        if (ApplVar.AP.Plu.CapSize)
            WORDtoASC(&ApplVar.Plu.Name[7], ApplVar.PluNumber + 1);
        if (ApplVar.AP.Plu.RandomSize)
            WORDtoBCD(ApplVar.Plu.Random, ApplVar.PluNumber + 1);
        if (ApplVar.AP.Plu.PriceSize)
        {
            for (i = 0; i < ApplVar.AP.Plu.Level; i++)
                WORDtoBCD(ApplVar.Plu.Price[i], 0);
        }
        if (ApplVar.AP.Plu.Cost)
            WORDtoBCD(ApplVar.Plu.Cost, 0);

        WritePlu();
        InitClearTotal(ApplVar.AP.Plu.RecordSize, ApplVar.AP.Plu.TotalOffSet);
    }
}


void InitDept()
{
    short i;

#if 1//(defined(CASE_MALTA)  || defined(DEBUGBYPC))
    char sName[25] ="";
#endif

    memcpy(&ApplVar.Dept, &Def.Dept,sizeof(ApplVar.Dept));
    for (ApplVar.DeptNumber = 0; ApplVar.DeptNumber < ApplVar.AP.Dept.Number; ApplVar.DeptNumber++)
    {
        ApplVar.Dept.Group = ApplVar.DeptNumber & 0x07;
        if (ApplVar.AP.Dept.RandomSize)
            WORDtoBCD(ApplVar.Dept.Random, ApplVar.DeptNumber + 1);
        if (ApplVar.AP.Dept.PriceSize)
            WORDtoBCD(ApplVar.Dept.Price, 0);
        for (i=0;i<ApplVar.AP.Dept.PriMaxSize;i++)
            ApplVar.Dept.PriceMax[i] = 0x99;
#if (defined(CASE_ITALIA) || defined(DEBUGBYPC))
        if (ApplVar.AP.Dept.CapSize)
            WORDtoASCL(&ApplVar.Dept.Name[3], ApplVar.DeptNumber + 1);
        if (ApplVar.DeptNumber==0)
            ApplVar.Dept.Tax = 1;
        else if (ApplVar.DeptNumber==1)
            ApplVar.Dept.Tax = 2;
        else if (ApplVar.DeptNumber==2)
            ApplVar.Dept.Tax = 4;
        else
            ApplVar.Dept.Tax = 0;
#else//if (defined(CASE_MALTA))
        if (ApplVar.AP.Dept.CapSize)
            WORDtoASC(&ApplVar.Dept.Name[7], ApplVar.DeptNumber + 1);
        memcpy(sName,ApplVar.Dept.Name,sizeof(ApplVar.Dept.Name));
        if (ApplVar.DeptNumber==0)
        {
            memcpy(&ApplVar.Dept.Name[0], "GOODS F   ",sizeof(ApplVar.Dept.Name));
            ApplVar.Dept.Tax = 1;
        }
        else if (ApplVar.DeptNumber==1)
        {
            memcpy(&ApplVar.Dept.Name[0], "GOODS R   ",sizeof(ApplVar.Dept.Name));
            ApplVar.Dept.Tax = 2;
        }
        else if (ApplVar.DeptNumber==2)
        {
            memcpy(&ApplVar.Dept.Name[0], "EXEMPT    ",sizeof(ApplVar.Dept.Name));
            ApplVar.Dept.Tax = 4;
        }
        else
        {
            strcpy(ApplVar.Dept.Name,Msg[MIANSHUI].str);//ccr070510
            ApplVar.Dept.Tax = 0;
        }
#endif
        WriteDept();
        InitClearTotal(ApplVar.AP.Dept.RecordSize, ApplVar.AP.Dept.TotalOffSet);

#if (defined(CASE_MALTA))
        memcpy(&ApplVar.Dept.Name[0],sName,sizeof(ApplVar.Dept.Name));
#endif
    }
}


void InitGroup()
{
    memcpy(&ApplVar.Group,&Def.Group,sizeof(ApplVar.Group));
    //GetOpt(30, &ApplVar.Group.Family, 99);
    for (ApplVar.GroupNumber = 0; ApplVar.GroupNumber < ApplVar.AP.Group.Number; ApplVar.GroupNumber++)
    {
        if (ApplVar.AP.Group.CapSize)
            WORDtoASC(&ApplVar.Group.Name[7], ApplVar.GroupNumber + 1);
        WriteGroup();
        InitClearTotal(ApplVar.AP.Group.RecordSize, ApplVar.AP.Group.TotalOffSet);

    }
}


void InitTender()
{
    for (ApplVar.TendNumber = 0; ApplVar.TendNumber < ApplVar.AP.Tend.Number; ApplVar.TendNumber++)
    {
        memcpy(&ApplVar.Tend,(CONSTCHAR *)&Def.Tend+ApplVar.TendNumber*sizeof(ApplVar.Tend),sizeof(ApplVar.Tend));    /* copy default */
        WriteTender();
        InitClearTotal(ApplVar.AP.Tend.RecordSize, ApplVar.AP.Tend.TotalOffSet);
    }
}


void InitDrawer()
{
    for (ApplVar.DrawNumber = 0; ApplVar.DrawNumber < ApplVar.AP.Draw.Number; ApplVar.DrawNumber++)
    {
        memcpy(&ApplVar.Draw, (CONSTCHAR *)&Def.Draw+ApplVar.DrawNumber*sizeof(ApplVar.Draw),sizeof(ApplVar.Draw));
        WriteDrawer();
        InitClearTotal(ApplVar.AP.Draw.RecordSize, ApplVar.AP.Draw.TotalOffSet);
    }
}



void InitCorrec()
{
    for (ApplVar.CorrecNumber = 0; ApplVar.CorrecNumber < ApplVar.AP.Correc.Number; ApplVar.CorrecNumber++)
    {
        memcpy(&ApplVar.Correc, (CONSTCHAR *)&Def.Correc+ApplVar.CorrecNumber*sizeof(ApplVar.Correc),sizeof(ApplVar.Correc));
        WriteCorrec();
        InitClearTotal(ApplVar.AP.Correc.RecordSize, ApplVar.AP.Correc.TotalOffSet);
    }
}


void InitCurr()
{
    for (ApplVar.CurrNumber = 0; ApplVar.CurrNumber < ApplVar.AP.Curr.Number; ApplVar.CurrNumber++)
    {
        memcpy(&ApplVar.Curr, (CONSTCHAR *)&Def.Curr+ApplVar.CurrNumber*sizeof(ApplVar.Curr),sizeof(ApplVar.Curr));
        WriteCurr();
        InitClearTotal(ApplVar.AP.Curr.RecordSize, ApplVar.AP.Curr.TotalOffSet);
    }
}


void InitDisc()
{
    for (ApplVar.DiscNumber = 0; ApplVar.DiscNumber < ApplVar.AP.Disc.Number; ApplVar.DiscNumber++)
    {
        memcpy(&ApplVar.Disc,(CONSTCHAR *)&Def.Disc+ApplVar.DiscNumber*sizeof(ApplVar.Disc),sizeof(ApplVar.Disc));
        WriteDisc();
        InitClearTotal(ApplVar.AP.Disc.RecordSize, ApplVar.AP.Disc.TotalOffSet);
    }
}

void InitPoRa()
{
    for (ApplVar.PoRaNumber = 0; ApplVar.PoRaNumber < ApplVar.AP.PoRa.Number; ApplVar.PoRaNumber++)
    {
        memcpy(&ApplVar.PoRa,(CONSTCHAR *)&Def.PoRa+ApplVar.PoRaNumber*sizeof(ApplVar.PoRa),sizeof(ApplVar.PoRa));
        WritePoRa();
        InitClearTotal(ApplVar.AP.PoRa.RecordSize, ApplVar.AP.PoRa.TotalOffSet);
    }
}


void InitTax()
{
    for (ApplVar.TaxNumber = 0; ApplVar.TaxNumber < ApplVar.AP.Tax.Number; ApplVar.TaxNumber++)
    {
        memcpy(&ApplVar.Tax,(CONSTCHAR *)&Def.Tax+ApplVar.TaxNumber*sizeof(ApplVar.Tax),sizeof(ApplVar.Tax));
        WriteTax();
        InitClearTotal(ApplVar.AP.Tax.RecordSize, ApplVar.AP.Tax.TotalOffSet);
    }
}


void InitPbF()
{
    for (ApplVar.PbFNumber = 0; ApplVar.PbFNumber < ApplVar.AP.Pb.Number; ApplVar.PbFNumber++)
    {
        memcpy(&ApplVar.PbF ,(CONSTCHAR *)&Def.PbF+ApplVar.PbFNumber*sizeof(ApplVar.PbF),sizeof(ApplVar.PbF));
        WritePbF();
        InitClearTotal(ApplVar.AP.Pb.RecordSize, ApplVar.AP.Pb.TotalOffSet);
    }
    if ((ApplVar.AP.Pb.Random & 0x0f) || ApplVar.AP.Pb.Text)
    {
        MemSet(ApplVar.PB.Text, sizeof(ApplVar.PB.Text), ' ');
        CopyFrStr(ApplVar.PB.Text, Prompt.Caption[23]);
        for (ApplVar.PbNumber = 1; ApplVar.PbNumber <= ApplVar.AP.Pb.NumberOfPb; ApplVar.PbNumber++)
        {
            if (ApplVar.AP.Pb.Random & 0x0f)
                WORDtoBCD(ApplVar.PB.Random, ApplVar.PbNumber);
            if (ApplVar.AP.Pb.Text)
                WORDtoASC(&ApplVar.PB.Text[6], ApplVar.PbNumber);
            PbTotal(ApplVar.PbNumber, 1);   /* write info */

#if FLASH_AppRAM
            GetPbtOffSet(ApplVar.PbNumber);
            RamOffSet += ApplVar.AP.Pb.TotalOffSet;
            InitClearTotal(ApplVar.AP.Pb.PBTRecordSize, ApplVar.AP.Pb.PBTTotalOffset);
#endif

        }
        ApplVar.PbNumber = 0;
    }
}



void InitClerk()
{
    memcpy(&ApplVar.Clerk,&Def.Clerk,sizeof(ApplVar.Clerk));
    for (ApplVar.ClerkNumber = 1; ApplVar.ClerkNumber <= ApplVar.AP.Clerk.Number; ApplVar.ClerkNumber++)
    {
#if defined(CASE_ITALIA)
        memset(ApplVar.Clerk.Name,0,sizeof(ApplVar.Clerk.Name));
        WORDtoASCL(ApplVar.Clerk.Name, ApplVar.ClerkNumber);
#else
        WORDtoASCL(&ApplVar.Clerk.Name[7], ApplVar.ClerkNumber);
#endif
        WriteClerk();
    }
}



void InitSalPer()
{
    memcpy(&ApplVar.SalPer,&Def.SalPer,sizeof(ApplVar.SalPer));
    for (ApplVar.SalPerNumber = 1; ApplVar.SalPerNumber <= ApplVar.AP.SalPer.Number; ApplVar.SalPerNumber++)
    {
        WORDtoASC(&ApplVar.SalPer.Name[7], ApplVar.SalPerNumber);
        WriteSalPer();
    }
}


void InitModifier()
{
    memcpy(&ApplVar.Modi,&Def.Modi,sizeof(ApplVar.Modi));
    for (ApplVar.ModiNumber = 0; ApplVar.ModiNumber < ApplVar.AP.Modi.Number; ApplVar.ModiNumber++)
    {
        WORDtoASC(&ApplVar.Modi.Name[7], ApplVar.ModiNumber + 1);
        WriteModi();
    }
}


void InitOFFPrice()
{
    memcpy(&ApplVar.OFFPrice, &Def.OFFPrice,sizeof(ApplVar.OFFPrice));
    for (ApplVar.OFFNumber = 0; ApplVar.OFFNumber < ApplVar.AP.OFFPrice.Number; ApplVar.OFFNumber++)
    {
        WriteOFFPrice();
    }
}

void InitPort()
{

    for (ApplVar.PortNumber = 0; ApplVar.PortNumber < ApplVar.AP.Port.Number; ApplVar.PortNumber++)
    {
        memcpy(&ApplVar.Port, &Def.Port,sizeof(ApplVar.Port));
        if (ApplVar.PortNumber == 1)
            ApplVar.Port.Type = '4';
        WritePort();
    }
}


void InitAgree()
{
    memcpy(&ApplVar.Agree, &Def.Agree,sizeof(ApplVar.Agree));
    for (ApplVar.AgreeNumber = 0; ApplVar.AgreeNumber < ApplVar.AP.Agree.Number; ApplVar.AgreeNumber++)
    {
        WriteAgree();
    }
}


void InitGraph()
{
    short i;
    for (i = 0; i<GRAFESTMAX+2;i++)
        memcpy(&ApplVar.Graph[i], &Def.Graph,sizeof(Def.Graph));
}

void ClearApplMemory()
{
    MemSet(ApplVar.ZCount, (BYTE *)&ApplVar.ApplVarCRC + sizeof(ApplVar.ApplVarCRC) - (BYTE *)ApplVar.ZCount, 0) ;//ccr091027
}

void ClearAppMemory()
{

    ClsXRam();
    //Erase ADDR_APPRAM !!!!!!!!!!!!!!!!!!!!!!!!
}
//����sizeof(APPLICATION_SAVE),������StartAddress
//toActual:=true,ת��Ϊʵ�ʵ�ַ,StartAddress[AddrEndP]=sizeof(APPLICATION_SAVE);
//        =false,ת��Ϊ��Ե�ַ,StartAddress[AddrEndP]=0
//return:=true,��ַδԽ��;=false,��ַԽ��
BYTE ResetStartAddress(BYTE toActual)
{
    int i;
    switch (toActual)
    {
        case true:
            if (ApplVar.AP.StartAddress[0]==0)
            {
                for (i=0;i<AddrMAX;i++)
                {
                    ApplVar.AP.StartAddress[i]+=RamOfTotal;
                }
            }
            if (ApplVar.AP.StartAddress[AddrEndP]>=ApplVar.SIZE_EXTRAM)
                return false;
            else
                return true;
        case false:
            if (ApplVar.AP.StartAddress[0]>=RamOfTotal)
            {
                for (i=0;i<AddrMAX;i++)
                {
                    ApplVar.AP.StartAddress[i]-=(RamOfTotal);
                }
            }
            if (ApplVar.AP.StartAddress[AddrEndP]>=ApplVar.SIZE_EXTRAM-RamOfTotal)
                return false;
            else
                return true;
        default:
           break;
    }
    return true;
}
/**************************************************************/
void InitApplication()
{
    UnLong  sAddr,sCmp;
    WORD    j;
    bool    sRePrint=false;//�Ƿ���Ҫ��ӡ�ػ�ǰΪ��ӡ��ϵ�����
    bool    sEcrUsed;//�����Ƿ�ʹ�ù������ұ�������������Ƿ�����
    BYTE    sFMPullOut;

    sEcrUsed = Recall_Config();//�ָ���������
//sEcrUsed    if (sEcrUsed)//����������ȷʱ
//sEcrUsed        sEcrUsed = (ApplVar.AP.StartAddress[0]==Default.StartAddress[0]);//�ж��ļ���ַ�ռ��Ƿ��쳣

    sFMPullOut=ApplVar.FMPullOut[NOFM_FLAG];
#if defined(DEBUGBYPC)
    ApplVar.SIZE_EXTRAM = SRAMSIZE;
#endif
    if (MACSwitch || !sEcrUsed || !Recall_ApplRam())//ccr2014-07-31 �ָ���������
    {//Ϊ�»�����ӵ��ʼ��
        MACSwitch = 1;

//sEcrUsed        /*ʹ��Ĭ�ϵļ���*/
//sEcrUsed        memcpy(ApplVar.AP.KeyTable, Default.KeyTable, sizeof(Default.KeyTable));
//sEcrUsed        memcpy(ApplVar.AP.FirmKeys, Default.FirmKeys, sizeof(Default.FirmKeys));


//sEcrUsed        if (sEcrUsed)//��ʾ����ʹ�ù�,�п�ʹ�õ��ļ�����,�ļ��ռ�δ�ı���ȷ
//sEcrUsed        {
//sEcrUsed            PutsO(CLEANFILES);
//sEcrUsed            while (KbHit()) Getch();
//sEcrUsed            while (!KbHit()) {};
//sEcrUsed            sEcrUsed = (Getch()!=Default.FirmKeys[ID_PRGENTER]);//sEcrUsed=falseʱ,����ļ�����
//sEcrUsed        }
//sEcrUsed        else
//sEcrUsed            sEcrUsed = false;//���ļ�����,ʹ��Ĭ�����ݳ�ʼ���ļ�����
//sEcrUsed
//sEcrUsed        if(!sEcrUsed || !ApplVar_Restored)
        {//������������ļ�,ʹ��Ĭ�����ݳ�ʼ������
            ApplVar_Restored = sEcrUsed = 0;

            ClearApplMemory();

            memcpy(&ApplVar.TXT, &DefaultText, sizeof(struct APPTEXT));
            memcpy(&ApplVar.AP, &Default, sizeof(struct APPLICATION));

            GetTimeDate(&Now);              //* read timer
            if (Now.year<=0x2009)
            {//Ϊ�»���,���û��������ں�ʱ��
                do
                {
                    ApplVar.ErrorNumber = 0;
                    Initial_DateTime(0);//��ʾ��������
                    if (GetStrFrKBD('9',Msg[RIQI].str,0)!=0xff)
                    {
                        Initial_DateTime(1);
                        if (GetStrFrKBD('9',Msg[SHIJIAN].str,0)!=0xff)
                            Initial_DateTime(2);
                    }
                } while (ApplVar.ErrorNumber);
            }

            ClsXRam();
            InitSysFlag();

    #if DD_FISPRINTER == 0
            MaskKeyBoard(1);
    #endif

            sAddr = ApplVar.SIZE_EXTRAM;
            if (sAddr && (sAddr > ApplVar.AP.StartAddress[AddrEndP] - SIZE_FLOWRAM))
            {//���¼����ڴ��п����ɵĵ�Ʒ��Ŀ
                sAddr -= ApplVar.AP.StartAddress[AddrEndP] - SIZE_FLOWRAM;

                sAddr /= pluRecordSize;
                sCmp = sAddr;
                sAddr *= pluRecordSize;
                ApplVar.AP.Plu.Number += sCmp;

                for (sCmp = AddrPLU+1;sCmp<AddrMAX;sCmp++)
                    ApplVar.AP.StartAddress[sCmp] += sAddr;
            }
            else
            {
                PutsO("RAM OUT,HALT!");
                while (1);
            }


            PutsO(Msg[INITWAITING].str);

            COMPUTER = BALANCE = 0;//Lyq modify 2003\10\27
            BARCODE &= 0xf8;

            PutsO("Init Port");InitPort();
            for (ApplVar.PortNumber = 0;ApplVar.PortNumber < ApplVar.AP.Port.Number;ApplVar.PortNumber++)
            {
                ReadPort();
                if (ApplVar.Port.Type >= '1' && ApplVar.Port.Type <= '3' && !COMPUTER)
                    COMPUTER = ApplVar.PortNumber+1;
                if (ApplVar.Port.Type == '4' && !(BARCODE & 0x07))
                    BARCODE = (BARCODE & 0xf8) | (ApplVar.PortNumber+1);
                if (ApplVar.Port.Type == '5' && !BALANCE)
                    BALANCE = ApplVar.PortNumber+1;
    #if 0	//cc 20070930
                if (ApplVar.Port.Type == '8' && !ApplVar.MFRCardPort)
                    ApplVar.MFRCardPort = ApplVar.PortNumber+1;
                if (ApplVar.Port.Type == '9' && !ApplVar.ePosPort)
                    ApplVar.ePosPort = ApplVar.PortNumber+1;
    #endif
                SetComm(ApplVar.PortNumber) ;
            }

            memset(PCBuffer,0,sizeof(PCBuffer));

    #if FLASH_AppRAM
            RamOffSet = ApplVar.AP.StartAddress[AddrTotl];

            InitClearTotal(ApplVar.AP.StartAddress[AddrGroup]-ApplVar.AP.StartAddress[AddrTotl],0);
    #endif

    #if(CASE_RAMBILL)
            PutsO("Init Journal");Init_Flow();
    #endif
            PutsO("Init Tender");InitTender();
            PutsO("Init PoRa");  InitPoRa();
            PutsO("Init Drawer");InitDrawer();
            PutsO("Init Plu");   InitPlu();
            PutsO("Init Dept");  InitDept();
            PutsO("Init Group"); InitGroup();
            PutsO("Init Correc");InitCorrec();
            PutsO("Init Curr");  InitCurr();
            PutsO("Init Discount");  InitDisc();
            PutsO("Init Tax");   InitTax();
            if (ApplVar.AP.Pb.NumberOfPb)
            {
                PutsO("Init PbF");InitPbF();
            }
            PutsO("Init Operator");      InitClerk();
            PutsO("Init SalPer");     InitSalPer();
            PutsO("Init Modifier");   InitModifier();
            PutsO("Init OFFPrice");   InitOFFPrice();
            PutsO("Init Agree");      InitAgree();
            PutsO("Init Graphic");      InitGraph();

            ApplVar.IP.IPAddress[0]=0;//192;
            ApplVar.IP.IPAddress[1]=0;//168;
            ApplVar.IP.IPAddress[2]=0;// 1;
            ApplVar.IP.IPAddress[3]=0;//5;
#if defined(CASE_GPRS)
            ApplVar.IP.APN[0]=0;//ccr2015-03-11
            ApplVar.IP.UserName[0]=0;//ccr2015-03-11
            ApplVar.IP.Password[0]=0;//ccr2015-03-11
#endif

        }//sEcrUsed
#if (0)//sEcrUsed>>>>>>>>
        else
        {
            sRePrint = false;
            for (ApplVar.PortNumber = 0;ApplVar.PortNumber < ApplVar.AP.Port.Number;ApplVar.PortNumber++)
            {
                ReadPort();
                if (ApplVar.Port.Type >= '1' && ApplVar.Port.Type <= '3' && !COMPUTER)
                    COMPUTER = ApplVar.PortNumber+1;
                if (ApplVar.Port.Type == '4' && !(BARCODE & 0x07))
                    BARCODE = (BARCODE & 0xf8) | (ApplVar.PortNumber+1);
                if (ApplVar.Port.Type == '5' && !BALANCE)
                    BALANCE = ApplVar.PortNumber+1;
    #if 0	//cc 20070930
                if (ApplVar.Port.Type == '8' && !ApplVar.MFRCardPort)
                    ApplVar.MFRCardPort = ApplVar.PortNumber+1;
                if (ApplVar.Port.Type == '9' && !ApplVar.ePosPort)
                    ApplVar.ePosPort = ApplVar.PortNumber+1;
    #endif
                SetComm(ApplVar.PortNumber) ;
            }
            //��λ��ӡ�����Ʊ���
            ApplVar.PoolPushIn=0;
            ApplVar.PoolPopOut=0;
            ApplVar.Prn_Command=0;
        }
#endif//sEcrUsed<<<<<<<<<
        ApplVar.ClerkNumber = 0;
        ApplVar.SalPerNumber = 0;
        ApplVar.CentralLock = RG;   //ccr Set REG mode for the default mode
        ApplVar.FRegi = ApplVar.FTend = ApplVar.FSub = ApplVar.FTrain = 0;
//ccr2014-PANAMA>>>

            ApplVar.ZCount[0]=ApplVar.ZCount[1] = 1;
//<<<<PANAMA
        if (ApplVar.AP.Clerk.Number!=0)
        {
            ApplVar.ClerkNumber = 1;
            ReadClerk();
            SetTrainMode();

            //		ApplVar.Key.Code = CLERK;
            //		ApplVar.Entry = ONE;
            //		ApplVar.NumberEntry = 1;
            //		SelectClerk(0);
        }
        if (ApplVar.AP.SalPer.Number!=0)
        {
            ApplVar.SalPerNumber = 1;
            ReadSalPer();
        }
#if !defined(FISCAL)
        ApplVar.FReport = 0;    /*    reset flag else keyb. checked during printing     */ //     liuj 0808
        ApplVar.FTotal = ApplVar.TotalMax = ZERO;      /*    ApplVar.FTax is soft total and cleared at start of report     */       //    cc 20071018
#else

        ApplVar.ZReport = 1 ;// ccr090507 ��ʾ�����ӡZ���� //
        SETBIT(ARROWS, BIT0);    /* set  RON */
#endif
        //	PutsO(EntryBuffer+sizeof(EntryBuffer)-DISLEN-1);

        Save_ConfigVar(true);

#if (!defined(DEBUGBYPC)) && (FLASH_AppRAM==1)
        FlashErase = 1;//��ʾFLASH��д�г�ʼ������,flash�ǿ�
#endif
        //Reset_printer();
        RJPrint(0,Msg[INITWAITING].str);
        PrintVersion(); //cc 20070930
    }
    else//-------------------------------------------------------------------------------------
    {// MACSwitch = 0,sEcrUsed=true;//It's not the first time for use
        //ccr2014-07-31 Recall_ApplRam();//sEcrUsed
        sRePrint = true;

        for (ApplVar.PortNumber = 0;ApplVar.PortNumber < ApplVar.AP.Port.Number;ApplVar.PortNumber++)
        {
            ReadPort();
            if (ApplVar.Port.Type >= '1' && ApplVar.Port.Type <= '3' && !COMPUTER)
                COMPUTER = ApplVar.PortNumber+1;
            if (ApplVar.Port.Type == '4' && !(BARCODE & 0x07))
                BARCODE = (BARCODE & 0xf8) | (ApplVar.PortNumber+1);
            if (ApplVar.Port.Type == '5' && !BALANCE)
                BALANCE = ApplVar.PortNumber+1;
#if 0	//cc 20070930
            if (ApplVar.Port.Type == '8' && !ApplVar.MFRCardPort)
                ApplVar.MFRCardPort = ApplVar.PortNumber+1;
            if (ApplVar.Port.Type == '9' && !ApplVar.ePosPort)
                ApplVar.ePosPort = ApplVar.PortNumber+1;
#endif
            SetComm(ApplVar.PortNumber) ;
        }
    }

#if (1)//ccr2015-10-13
    //������������״̬(���ָ��ػ�ǰ����ʾ)
    ApplVar.CentralLock = RG;
    Appl_MaxEntry = PRTLEN*2;
    strcpy(ModeHead,DText[1+18]);
#else

    ApplVar.CentralLock &= 0xff;

    switch (ApplVar.CentralLock)
    {
    default:
        ApplVar.CentralLock = RG;
    case RG:
        strcpy(ModeHead,DText[1+18]);
        Appl_MaxEntry = PRTLEN*2;
        break;
    case X:
        strcpy(ModeHead,DText[2+18]);
        Appl_MaxEntry = 2;
        break;
    case Z:
        strcpy(ModeHead,DText[3+18]);
        Appl_MaxEntry = 2;
        break;
    case SET:
        strcpy(ModeHead,DText[4+18]);
        Appl_MaxEntry = 5;
        break;
    case MG:
        strcpy(ModeHead,DText[5+18]);
        Appl_MaxEntry = PRTLEN*2;
        break;
    }
#endif
    SetInputMode(0);

//;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

#if(DD_MMC==1)

    if (Bios(BiosCmd_SD_Init, MMC_Buff,0,0))
        GetMMCSize();

    ApplVar.MMCLast = 0xffffffff;
#endif

	  ApplVar.ErrorNumber = 0;
#if defined(FISCAL)
    ApplVar.FMPullOut[NOFM_FLAG] = sFMPullOut;

    CheckFiscal(sEcrUsed);
    CheckFisError();

    if (MACSwitch && (ApplVar.FisCardFlag == FISCALOK || ApplVar.FisCardFlag == FMMACFULL))
    {//Ϊ�ӵ縴λʱ,��ӡ˰����Ϣ
#if DD_MMC//ccr091110
        ApplVar.EJContent = TXTCONT;
        SETBIT(ApplVar.ContFlag,(ENSTORE | ENHEADER));
#endif

        PrintLine2('=');
        memset(SysBuf,' ',PRTLEN);
        SysBuf[0]='F';      SysBuf[1]='M';
        CopyFrStr(SysBuf+3, Msg[KAHAO].str);
#if PRTLEN<25 // liuj 0716
        SysBuf[PRTLEN] = 0;
        RJPrint(0, SysBuf);
        memset(SysBuf,' ',PRTLEN);
        memcpy(SysBuf+PRTLEN - strlen(ApplVar.Fis_Header.FFisCode) , (CONSTCHAR*)ApplVar.Fis_Header.FFisCode,strlen(ApplVar.Fis_Header.FFisCode) );
#else
        memcpy(SysBuf+15, (CONSTCHAR*)ApplVar.Fis_Header.FFisCode,strlen(ApplVar.Fis_Header.FFisCode) );
#endif
        SysBuf[PRTLEN] = 0;
        RJPrint(0, SysBuf);

#if(DD_MMC==1)
        memset(SysBuf,' ',PRTLEN);
        SysBuf[0]='E';      SysBuf[1]='J';
        CopyFrStr(SysBuf+3, Msg[KAHAO].str);
#if PRTLEN<25// liuj 0716
        SysBuf[PRTLEN] = 0;
        RJPrint(0, SysBuf);
        memset(SysBuf,' ',PRTLEN);
        HEXtoASC(SysBuf+PRTLEN - 10, ApplVar.Fis_EJTbl.FEJID+10,5);
#else//ccr070720
        HEXtoASC(SysBuf+15, ApplVar.Fis_EJTbl.FEJID+10,5);
#endif
        SysBuf[PRTLEN] = 0;
        RJPrint(0, SysBuf);
#endif

        memset(SysBuf,' ',PRTLEN);
        CopyFrStr(SysBuf, MessageN61);
        WORDtoASC(SysBuf+16, (WORD)ApplVar.FisNumber.TotalResetNum);
        SysBuf[PRTLEN] = 0;
        RJPrint(0, SysBuf);

        memset(SysBuf,' ',PRTLEN);
        CopyFrStr(SysBuf, MessageN46);
        WORDtoASC(SysBuf+16, (WORD)ApplVar.FisNumber.TotalFMNum);
        SysBuf[PRTLEN] = 0;
        RJPrint(0, SysBuf);

        PrintLine2('=');
#if (ENCUTTER==0)
        RFeed(3);
#endif
        StoreEJEnd();

        MACSwitch = 0;//ccr20131107,��������EJ���
        ApplVar.FReceipt = 1;
        ReceiptIssue(1+BIT2);       //ccr070609pm

        sRePrint = false;
    }

#endif


#if DD_MMC//ccr091110

#if !defined(FISCAL)
    if (!Bios(BiosCmd_SD_ReadInfo, ApplVar.EJNo, MMC_SEND_CID,16))
    {
        ApplVar.FisCardFlag = BADEJ;// EJ is damaged,can't write and read //
    }
    CheckEJ();
#endif

#if (0)   //ccr20120105,������γ���ʱ,����ػ�ǰ������ģʽ,��ô����ʱ,���ӡƱβ������Ϣ,��̫����?
    if (ApplVar.FisCardFlag == FISCALOK || ApplVar.FisCardFlag == FMMACFULL) // liuj 0530
    {
        StoreEJEnd();
        ApplVar.EJContent = REGICONT;
        SETBIT(ApplVar.ContFlag,(ENSTORE | ENHEADER));
    }
#endif

#endif


    ARROWS = 0x01;     //* Clear Arrows and receipt on
    MACSwitch = 0;
//	DENSITY = ApplVar.AP.Config.RDensity;
    if (TESTBIT(KEYTONE,BIT0))
    {
        Bios_1(BiosCmd_AutoClickOff);
    }
    else
    {
        Bios_1(BiosCmd_AutoClickOn);
    }
    CHARSET &= 0x0f;
    CHARSET += ApplVar.AP.Config.Country * 0x10;     //* set char set
    ApplVar.AmtDecimal = NO_DECIMAL;
    Prefix1 = PREFIX_1;
    Prefix2 = PREFIX_2;
//* cortex m3
    if (!TESTBIT(KEYTONE, BIT3))
    {
        ApplVar.PrintLayOut = 0x07;
        PrintMessage(44);     //* print init
    }
//*/

#if (defined(FISCAL) || DD_MMC==1)
#if defined(FISCAL)
    if (ApplVar.FisCardFlag == FMISNEW || ApplVar.FisCardFlag == MUSTINITEJ || ApplVar.FisCardFlag == FMMACFULL)  // liuj 0611
#elif (DD_MMC == 1)
    if (ApplVar.FisCardFlag == MUSTINITEJ )  // liuj 0813
#endif
    {//�Զ���������״̬,���տ������˰�س�ʼ��
        Appl_MaxEntry = 4;
        ApplVar.CentralLock= SET;
        ApplVar.FuncOnEnter = 0;
        strcpy(ModeHead,DText[22]);//program mode
    }
#endif

#if DD_CHIPC
    memset(&IC,0,sizeof(struct ICStruct));//ccr chipcard

#if (CASE_MFRIC==1)
    if (ApplVar.MFRCardPort && TESTBIT(ApplVar.ICCardSet.Options,IC_CHIPCARD))
    {
        Delay(ASECOND);//delay
        PutsO(Msg[WAITEICCARD].str);
        if ( mifs_config()!=0)//MI_OK
        {
            ApplVar.ErrorNumber=CWXXI72 - CWXXI01 + 1;
            ApplVar.MFRCardPort = 0;
        }
        else
            PutsO(Msg[ICCARDOK].str);
    }
#endif

#endif

    ClearEntry();
    CCDCounter = BalCounter = PCCounter = 0;
    DialTime = DialSkiped = 0;//flags
    ProgLine = ProgStart = ProgType = 0;               /* programming type status */

    PutsO(ModeHead);
    ClearLine2();

    DeptPluKeysCount();
#if (CASE_MFRIC==1)
    if (ApplVar.MFRCardPort)
    {
        Delay(ASECOND);//delay for
        if ( mifs_config()!=0)//MI_OK)
        {
            ApplVar.ErrorNumber=CWXXI72 - CWXXI01 + 1;
            CheckError(0);
            ApplVar.MFRCardPort = 0;
        }
    }
#endif

    ApplVar.FBalance = 0;       //cc 2006-06-29 for Balance
    ApplVar.PrintLayOut = 0x03;     /* R & J */

#if  PC_EMUKEY==1

//    #if PCREMOTE==1

    KeyFrHost = 0xff;
#endif

    Bell(2);

#if defined(FISCAL)
    if (ApplVar.ZReport == 1)
    {
        CheckTime(0x80);
        ApplVar.FisNumber.LastZDate = EncordDate(Now.year & 0xff, Now.month, Now.day);    //    liuj0831
    }

#if DD_FISPRINTER
    ApplVar.LogDefine.RecNumTo = 0;
    SelectCounter=0;
#endif

    CheckFisError();
#endif

    GetTimeDate(&Now);              //* read timer

#if !defined(DEBUGBYPC)

    //ccr20131015>>>>>>
    pwrGetStatus(GET_VRTC_STATUS);
    if (BATTERYTooLow(PWR_BUT_WARNING2))
    {
        Bell(2);
#if (DD_ZIP || DD_ZIP_21)
        Puts1_Right(BUTTONBATLOW);
#else
        PutsO(BUTTONBATLOW);
#endif
    }

#if POWERCTRL
    pwrGetStatus(GET_VIN_STATUS);
    while (BATTERYTooLow(PWR_WARNING2 | PWR_BY_BAT))
    {
        Bell(1);
#if (DD_ZIP || DD_ZIP_21)
        Puts1_Right(MessageM95);
#else
        PutsO(MessageM95);
#endif
        Delay(500);
        pwrGetStatus(GET_VIN_STATUS);
    }
    if (BATTERYTooLow(PWR_BY_BAT | PWR_WARNING1))
        ApplVar.ErrorNumber = ERROR_ID(CWXXI95);
#endif
    //<<<<<<<<<<<<<<<
    if (sRePrint)
    {//��ӡ�ػ�ǰ���жϵ�δ��ӡ����
        Start_When_Ready(REPRN_PWON);
        if (TESTBIT(ApplVar.Fiscal_PrintFlag,BIT2))
        {//��ӡZ����ʱ����,��Ҫ���´�ӡZ����
              ApplVar.ErrorNumber= ERROR_ID(CWXXI75);
        }
    }
#endif

#if (0)//ccr2015-10-13
    //�ָ��ػ�ǰ����ʾ����
    if (!ApplVar.ErrorNumber && ApplVar.LCD_Operator[0])
    {
#if (DD_ZIP)
        PutsO(ApplVar.LCD_Operator);
        Puts1(ApplVar.LCD_Operator+DISLEN);
#elif (DD_ZIP_21)
        PutsO(ApplVar.LCD_Operator);
        Puts1(ApplVar.LCD_Operator+DISLEN);
        PutsC(ApplVar.LCD_Customer);
#else
        PutsO(ApplVar.LCD_Operator);
#endif
        ApplVar.LCD_Operator[0]=0;
    }
#endif

    RESETBIT(ApplVar.MyFlags,(KEYFROMHOST));

}

//����ʱ,���Ϊ�»���,���������ں�ʱ��
void Initial_DateTime(BYTE idx)
{

    switch (idx)
    {
    case 0://��ʾ��������
        ClearEntry();
        ClearLine2();

        SetInputMode('0');
        Appl_MaxEntry = 8;

        DateForDisplay(0);

#if(DD_ZIP==1 || DD_ZIP_21==1)
        strcpy(ProgLineMes,Msg[RIQI].str);
        PutsO(ProgLineMes);
        Puts1(SysBuf);
//								PutsC(SysBuf+4);
#else
        CopyFrStr(SysBuf,Msg[RIQI].str);
        PutsO(SysBuf);
#endif
        ClearEntry();
        break;
    case 1:
        if (Appl_EntryCounter)
        {
            NewTimeDate(0xf1);
            if (ApplVar.ErrorNumber)
            {
#if(DD_ZIP==1 || DD_ZIP_21==1)
                Puts1(Msg[ApplVar.ErrorNumber].str);
#else
                PutsO(Msg[ApplVar.ErrorNumber].str);
#endif
            }
            else if (Now.year<0x2000) Now.year |= 0x2000;
        }

        memset(SysBuf,' ',DISLEN);
        HEXtoASC(SysBuf+DISLEN-8,(char*)(&Now.hour),1);SysBuf[DISLEN-6]=':';
        HEXtoASC(SysBuf+DISLEN-5,(char*)(&Now.min),1);SysBuf[DISLEN-3]=':';
        HEXtoASC(SysBuf+DISLEN-2,(char*)(&Now.sec),1);

        SysBuf[DISLEN] = 0;

#if(DD_ZIP==1)
        strcpy(ProgLineMes,Msg[SHIJIAN].str);
        PutsO(ProgLineMes);
        Puts1(SysBuf);
#elif(DD_ZIP_21==1)
        strcpy(ProgLineMes,Msg[SHIJIAN].str);
        PutsO(ProgLineMes);
        Puts1(SysBuf);
//								PutsC(SysBuf+4);
#else
        CopyFrStr(SysBuf,Msg[SHIJIAN].str);
        PutsO(SysBuf);
#endif

        ClearEntry();
        Appl_MaxEntry = 6;
        break;
    case 2:// input time
        if (Appl_EntryCounter)
        {
            NewTimeDate(0xf2);
            if (ApplVar.ErrorNumber)
            {
#if(DD_ZIP==1 || DD_ZIP_21==1)
                Puts1(Msg[ApplVar.ErrorNumber].str);
#else
                PutsO(Msg[ApplVar.ErrorNumber].str);
#endif
                break;
            }
        }
        SetTimeDate(&Now);
        SetDateFlg = 0;

        ClearEntry();
        ClearLine2();
        break;
    }
}


