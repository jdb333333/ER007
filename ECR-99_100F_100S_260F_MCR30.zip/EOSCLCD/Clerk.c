#define CLERK_C 5
#include "debug.h"
#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
#include "flowbill.h"  //lyq2003
#include "message.h"
#if (PC_EMUKEY==1)
#include "FEcrTest.h"
#endif

/****************************************************************/


void GetClerkOffSet()
{
    RamOffSet = (ApplVar.ClerkNumber - 1) * ApplVar.AP.Clerk.RecordSize + ApplVar.AP.StartAddress[AddrClerk];
}

void WriteClerk()
{
    if (ApplVar.ClerkNumber <= ApplVar.AP.Clerk.Number)
    {
		GetClerkOffSet();
		WriteRam(ApplVar.Clerk.Name, ApplVar.AP.Clerk.CapSize);
		WriteRam(&ApplVar.Clerk.Options, sizeof(ApplVar.Clerk.Options));
	    WriteRam(ApplVar.Clerk.Passwd,sizeof(ApplVar.Clerk.Passwd));
    }
}

void ReadClerk()
{
    if (!ApplVar.ClerkNumber || ApplVar.ClerkNumber > ApplVar.AP.Clerk.Number)
    		ApplVar.ClerkNumber = 1;

    GetClerkOffSet();
    ReadRam(ApplVar.Clerk.Name, ApplVar.AP.Clerk.CapSize);
    ApplVar.Clerk.Name[ApplVar.AP.Clerk.CapSize] = 0 ;
    ReadRam(&ApplVar.Clerk.Options, sizeof(ApplVar.Clerk.Options));
    ReadRam(ApplVar.Clerk.Passwd,sizeof(ApplVar.Clerk.Passwd));

}
//�����տ�Ա��˰��״̬,�趨��ѵģʽ״̬
void SetTrainMode()
{
    if (!TESTBIT(ApplVar.Clerk.Options, BIT7))	/* training clerk ? */
    {
#if (DD_ZIP || DD_ZIP_21)
        Puts1_Right(Msg[TRAINMODE].str);
#else
        PutsO_At('T',DISLEN-1);
#endif
        ApplVar.FTrain = 1;	  /* ��ѵģʽ��־ */
    }
    else
    {
        ApplVar.FTrain = 0;	/* ����ѵģʽ */
    }
}
//��¼���տ�Ա
void SelectClerk(BYTE lock)
{
    WORD newclerk;
    short sSave;
    char cPass[7];

	if (ApplVar.CentralLock != RG && ApplVar.CentralLock != MG)
	{
		ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
		return;
	}

    newclerk = 0;
	if (ApplVar.Key.Code == CLERK)
	{
		if (!Appl_EntryCounter)
		{
#if PC_EMUKEY
			if(FisTestTask.PrnOFF)	 //    ccr080519 added for control the printing of pb message
			{
				FisTestTask.PrnOFF = 0;
				PutsO(MessageE49);
			}
			else
			{
				FisTestTask.PrnOFF = 1;
				PutsO(MessageE50);
			}
#endif
			return;
		}
		else if (ApplVar.NumberEntry < (OFFER-CLERK))
			newclerk = ApplVar.NumberEntry;
	}
	else if (!Appl_EntryCounter)
	{
		newclerk = ApplVar.Key.Code - CLERK;
		ApplVar.Entry = ZERO;
		WORDtoBCD(ApplVar.Entry.Value, newclerk);
	}
	if (newclerk > ApplVar.AP.Clerk.Number)
	{
	    ApplVar.ErrorNumber=ERROR_ID(CWXXI24);
		return;
	}


	if (ApplVar.FRegi)    /* still in regi and train no change clerk */
    {
	    if ((ApplVar.FPb && TESTBIT(CLERKFIX, BIT1)) ||
		    TESTBIT(CLERKFIX, BIT2) || ApplVar.FTrain || !newclerk)
	    {
		    ApplVar.ErrorNumber=ERROR_ID(CWXXI14);	/* still in registration */
			return;
		}
	}
//ccr090508	if (!lock)
	{
		if (!newclerk)
		{									   //lyq 20040227 added start
	      	ApplVar.ClerkNumber = 0;
			PutsO((char*)Prompt.Message[59]);
			return;
		}
		if(TESTBIT(CLERKFIX, BIT5))		/* secret code ? */
		{/* ��ҪУ������ */
			sSave = ApplVar.ClerkNumber;
			ApplVar.ClerkNumber = newclerk;
			ReadClerk();
			ApplVar.ClerkNumber = sSave;
			HEXtoASC(cPass,ApplVar.Clerk.Passwd,3);
			cPass[6] = 0;
			if (!CheckPWD(cPass))
			{//ccr090508 �����д�ʱ,�������տ�Ա //
               ReadClerk();
				ApplVar.ErrorNumber=ERROR_ID(CWXXI36);
				return;
			}
		}
	}


//ccr090508>>>>>>>>>>>>>>>>>>
#if(defined(FISCAL))

	sSave = ApplVar.ClerkNumber;
	ApplVar.ClerkNumber = newclerk;
	ReadClerk();
	ApplVar.ClerkNumber = sSave;

	CWORD(cPass[0]) = CWORD(ApplVar.Entry.Value[0]);//save ApplVar.Entry.
	if(TESTBIT(ApplVar.Clerk.Options,BIT7) && ApplVar.FTrain)
	{// ������ѵģʽ��Ϊ����ѵģʽʱ,�Զ����屨�� //
		 ClearAllReport();
	}
	else if(!TESTBIT(ApplVar.Clerk.Options,BIT7))
	{/* Ϊ��ѵ�տ�Ա */
		if(!ApplVar.FTrain && TESTBIT(ApplVar.MyFlags,ZREPORT))
		{// ���ɷ���ѵģʽ��Ϊ��ѵģʽʱ,�����ӡZ���� //
			ReadClerk();
			ApplVar.ErrorNumber=ERROR_ID(CWXXI75);
			return;
		}
		else/* ���µ���ѵ�տ�Ա��¼ʱ,�Զ����屨�� */
			ClearAllReport();
	}

	CWORD(ApplVar.Entry.Value[0]) = CWORD(cPass[0]);

#endif
//<<<<<<<<<<<<<

    if (ApplVar.RGRec.Key.Code < CLERK || ApplVar.RGRec.Key.Code >=OFFER)
		StoreInBuffer();
    ApplVar.RGRec.Key.Code = CLERK + newclerk;	/* store in buffer for correct CC update */

    ApplVar.ClerkNumber = newclerk;
	ReadClerk();
    SetTrainMode();
#if(CASE_RAMBILL)
	Collect_Data(OPERLOG);		  	 //    lyq2003
#endif
   	PutsO(DispQtyStr(DText[13], &ApplVar.Entry,DISLEN));

#if(DD_ZIP==1 || DD_ZIP_21==1)
    Puts1(Msg[SPACE].str);
#endif

}

