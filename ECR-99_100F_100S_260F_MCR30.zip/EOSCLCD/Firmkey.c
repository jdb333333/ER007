#define FIRMKEY_C
#include "king.h"
#include "exthead.h"
#include "exth.h"
#include "ejournal.h"
#include "flowbill.h"	  //lyq2003
#include "fiscal.h"
#include "message.h"

#if (PC_EMUKEY==1)
    #include "FEcrTest.h"
#endif


CONST char Reserved[]=MessageE48;

extern BYTE GrapNo;

extern void LoadReceipLog(void);
extern void CheckFisError(void);

#if DD_MMC == 1
extern void ProcessEJ(void);
extern void PrintEJInfo(void);
extern void CheckEJ(void);
extern void GetMMCSize(void);
extern void PrintEJLog(BYTE prnCtrl);
extern void Search_EJ_Record(void);
#endif
void SuspendECR(void);


#if (DD_FISPRINTER==0)

/**
 * ��ӡ����ϵͳ�˵�
 *
 * @author EutronSoftware (2016-12-20)
 */
void PrintSetupMenu(void)
{
    int mIdx,sIdx,i,j;
    char sStr[PRTLEN+3];

    StoreEJEnd();//ccr070609pm

    strcpy(sStr,"SETUP MANUALS LIST");
    PrintLine2('.');
    PrintStr_Center(sStr,true);
    PrintLine2('=');

    for (mIdx=SETDEPT;mIdx<=SETUPMAX;mIdx++)
    {
        //��ӡ�ϻ��˵�����
        memset(sStr,' ',sizeof(sStr));
        if (mIdx>9) sStr[3]=mIdx/10+'0';
        sStr[4]=mIdx % 10+'0';
        sStr[5]='.';
        strncpy(sStr+6,Prompt.TypeCap[mIdx-1],sizeof(sStr)-6);
        sStr[PRTLEN+3-1]=0;
        RJPrint(0,sStr+3);
#if defined(CASE_GPRS)
        if (mIdx==SETGPRSFUNC)
        {
            for (i=1;i<=gprsMAINITEMS;i++)
            {
                memset(sStr,' ',sizeof(sStr));
                sStr[2]='>';
                if (i>9) sStr[3]=i/10+'0';
                sStr[4]=i % 10+'0';
                sStr[5]='.';
                strncpy(sStr+6,Msg[i+gprsSENDMESS-1].str,sizeof(sStr)-6);
                sStr[PRTLEN]=0;
                RJPrint(0,sStr);
            }
        }
#endif
    }


    strcpy(sStr,"X/Z REPORTS LIST");
    PrintLine2('.');
    PrintStr_Center(sStr,true);
    PrintLine2('=');

    for (mIdx=1;mIdx<XZNUM+1;mIdx++)
    {
        //��ӡ�ϻ��˵�����
        memset(sStr,' ',sizeof(sStr));
        if (mIdx>9) sStr[3]=mIdx/10+'0';
        sStr[4]=mIdx % 10+'0';
        sStr[5]='.';
        strncpy(sStr+6,XZTitle[mIdx-1].Name,sizeof(sStr)-6);
        sStr[PRTLEN+3-1]=0;
        RJPrint(0,sStr+3);
    }


    strcpy(sStr,"COMMANDS FOR SETUP");
    PrintLine2('.');
    PrintStr_Center(sStr,true);
    PrintLine2('=');
    for (mIdx=0;CommandSet[mIdx].str[0];mIdx++)
    {
        //��ӡ�ϻ��˵�����
        RJPrint(0,CommandSet[mIdx].str);
    }

    RFeed(3);
}

#endif

/**** ��ȡ���ܼ���ApplVar.AP.FirmKey�е���� ************
  ����0xff:���ǹ��ܼ�
   ******************************************************/
BYTE GetFirmkeyID(BYTE keyno)
{
    int i;
    for (i = 0; i < FIRMKEYS; i++)
    {
        if (keyno == ApplVar.AP.FirmKeys[i])
        {
            return i;
        }
    }
   return 0xff;
}
//����ĳЩ���ܼ����ڵİ���ת��Ϊ���ܼ���  //
#if (0)
BYTE ChangeFuncKey(BYTE keyIn)
{
    switch (keyIn)
    {
    case 9:             //modelock
        if (ApplVar.AP.KeyTable[9]==ApplVar.AP.KeyTable[8] || ApplVar.AP.KeyTable[9]==0)
            return fLOCK;
        else
            return keyIn;
    case 48:
        if (ApplVar.AP.KeyTable[48]==ApplVar.AP.KeyTable[40] || ApplVar.AP.KeyTable[48]==0)
            return fCLEAR;      //clear
        else
            return keyIn;
    case 47:
        if (ApplVar.AP.KeyTable[47]==ApplVar.AP.KeyTable[46] || ApplVar.AP.KeyTable[47]==0)
            return fPRGTYPE;        //select
        else
            return keyIn;
    case 55:
        if (ApplVar.AP.KeyTable[55]==ApplVar.AP.KeyTable[54] || ApplVar.AP.KeyTable[55]==0)
            return fPRGENTER;       //Enter
        else
            return keyIn;
    default:
        return keyIn;
    }
}
#else
    #define  ChangeFuncKey(keyIn) (keyIn)
#endif


#if DD_FISPRINTER == 0

/**********************************************************************************/

/*****************************************************************************
  ��SETģʽ��,��ѡ��ȷ������Ҫ���õ��ļ���,����DisplayOption
  ProgType: ָ����ǰ���õ��ļ�(����,��Ʒ,˰��...)
  ProgLine: =1,�״ν����ļ�������
            >1ʱ(ProgLine-1)ָʾ��ǰ���õ���Ŀ���,
  ProgNumber:ָ����ǰ�ļ��еļ�¼��;=-1,���м�¼�������,���¿�ʼ
  ProgStart:=0,Ϊ��δȷ�������ĸ��ļ�,��ʱ��ѡ������Զ�����ѡ���ļ�
            =1,�Ѿ�ȷ������ĳ���ļ�;��ʱ��λ������,���ܰ�ѡ���
            =2,Ϊö�ٴ�ӡ�ļ�����
  BitNumber: ���ڿ���λ������.=0:��ʾλ״̬;=2:�ı�λΪYes;=3:�ı�λΪNo
*******************************************************************************/
short DisplayOption()
{
    short   RandomL;
    RESETBIT(ApplVar.MyFlags,PWDMODE+HANZIMODE);
    SetDateFlg = 0;
    for (;;)
    {

        memset(ProgLineMes,' ',sizeof(ProgLineMes));

#if(DD_ZIP==1 || DD_ZIP_21==1)
        memset(ProgLine1Mes,' ',sizeof(ProgLine1Mes));
#endif

        //     if add a new setup,update this line if needed;
#if defined(FISCAL)	//    liuj 0529 modify for EJ
        if (( ProgType == SETDEPT) && ProgStart !=2)
        {

#if DD_MMC == 1
            SETBIT(ApplVar.MyFlags,PRNTRAI);
            if (ProgLine == 1)
            {
                if (TESTBIT(ApplVar.ContFlag,EJ_HEAD) && !TESTBIT(ApplVar.Fiscal_PrintFlag,BIT4))    // liuj 0530
                {
                    StoreEJEnd();
                }
                if (!TESTBIT(ApplVar.ContFlag,ENSTORE))//ccr070612
                {
                    ApplVar.EJContent = TXTCONT;
                    SETBIT(ApplVar.ContFlag, (ENSTORE|ENHEADER));
                }
            }
#endif

        }

#endif
        if (ProgLine == 1)
        {//Ϊ��Ҫ���õ��ļ���׼��(Ԥ����)
            switch (ProgType)
            {
            case SETSYSFLAG:
            case SETDATE:
            case SETTIME:
            case SETIP:
#if defined(CASE_GPRS)
            case SETGPRSFUNC:
#endif
#if defined(CASE_ETHERNET)
            case SETETHERNETFUNC:
#endif
            case SETPORT1:
            case SETPORT2:
            case SETPORT3:
#if defined(FISCAL)
            case SETUSERINFO:
#endif
#if (DD_CHIPC==1)
            case SETCHARGIC:    //ccr chipcard
            case SETCLEARIC:    //ccr chipcard
            case SETINITIC:     //ccr chipcard
            case SETCHIPPOINT:
            case SETIC:         //ccr chipcard
#endif
                break;//can't input any data for these setup
            case SETGRAP:
                if (ApplVar.ProgNumber>=GRASETMAX)
                    ApplVar.ProgNumber = 0;
                CopyFrStr(ProgLineMes,GrapType[ApplVar.ProgNumber]);
                break;
            default:
                if (ApplVar.ProgNumber<0)
                    ApplVar.ProgNumber = 0;
                if (Appl_EntryCounter)
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                    ProgType = 0;
                    MemSet(ModeHead, sizeof(ModeHead), ' ');
                    strcpy(ModeHead,DText[22]);//PROGRAM
                    return 0;
                }
                //��ʾ��¼��
                if (ProgStart == 2)
                {
                    CopyFrStr(ProgLineMes, Prompt.TypeCap[ProgType - 1]);
                    ProgLineMes[ DISLEN - 2 - WORDtoASC(ProgLineMes + DISLEN - 1, ApplVar.ProgNumber + 1)] = '#';//ccr20131120
                }
                else
                {
                    if (ProgType==SETPLU && ApplVar.AP.Plu.RandomSize)//ccr20131120
                    {
                        if (ProgLine==1)
                        {
                            ApplVar.PluNumber = ApplVar.ProgNumber;
                            ReadPlu();
                            if (ApplVar.AP.Plu.RNumber>0)
                                for (RandomL=6;RandomL>=0;RandomL--)
                                {//�������λ��
                                    if (ApplVar.Plu.Random[RandomL]!=0)
                                        break;
                                }
                            else
                                RandomL = -1;
                            CopyFrStr(ProgLineMes, Prompt.TypeCap[ProgType - 1]);
                            if (RandomL<0)
                                ProgLineMes[DISLEN-1] = '?';
                            else
                            {//ccr20131120>>>
                                RandomL++;
                                RandomL <<= 1;
                                if (RandomL>DISLEN)
                                    RandomL = DISLEN;
                                HEXtoASC(ProgLineMes + DISLEN-RandomL, ApplVar.Plu.Random,(RandomL>>1));
                                if (ProgLineMes[DISLEN-RandomL]=='0')
                                    ProgLineMes[DISLEN-RandomL]='#';
                                else if (RandomL != DISLEN)
                                    ProgLineMes[DISLEN-RandomL-1]='#';
                            }//<<<<
                        }
                    }
                    else
                    {
                        CopyFrStr(ProgLineMes, Prompt.TypeCap[ProgType - 1]);
                        ProgLineMes[ DISLEN - 2 - WORDtoASC(ProgLineMes + DISLEN - 1, ApplVar.ProgNumber + 1)] = '#';//ccr20131120
                    }
                }
#if(DD_ZIP==1 || DD_ZIP_21==1)
                strcpy(ProgLine1Mes,ENTERMESS);//ccr20131120
#endif
                break;
            }
        }

        switch (ProgType)
        {
        case SETPLU://1:	/* plu */
            ProgPlu();
            break;
        case SETDEPT://2:	/* dept */
            ProgDept();
            break;
        case SETGROUP://3:	/* ApplVar.Group */
            ProgGroup();
            break;
        case SETTEND://4:	/* tend */
            ProgTend();
            break;
        case SETPORA://5:	/* pora */
            ProgPoRa();
            break;
        case SETCORR://6:	/* correc */
            ProgCorrec();
            break;
        case SETDISC://7:	/* disc */
            ProgDisc();
            break;
        case SETCURR://8:	/* ApplVar.Curr */
            ProgCurr();
            break;
        case SETDRAWER://9:	/* drawer */
            ProgDraw();
            break;
        case SETPBF://10:	 /* pb functions */
            ProgPbF();
            break;
        case SETTAX://11:	 /* tax */
#if defined(FISCAL)
            if (ApplVar.ZReport != 1)   /* z report taken ? */
            {
                ProgStart = 0;
                ProgLine = 0;//ccr2014 ���Ա���Ҫ���˳���,���ǻ�ص���������.
                ApplVar.ErrorNumber=ERROR_ID(CWXXI75);
                CopyFrStr(ProgLineMes, Prompt.TypeCap[ProgType - 1]); // liuj 0808
                return 0;//ccr2014 break;
            }
            if (ApplVar.FTrain)    //cc 20071026
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                break;
            }
#endif
            ProgTax();
            break;
        case SETCLERK://12:	 /* clerk */
            ProgClerk();
            break;
        case SETZONES://13:	 /* zones */
            ProgZone();
            break;
        case SETMODIF://14:	 /* modifiers */
            ProgModi();
            break;
        case SETHEAD://15:	/* program header */
#if(defined(FISCAL))	//cc 20071026
            if (ApplVar.FTrain)
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                break;
            }
#endif
            ProgHeader();
            break;
        case SETTRAIL://16:
            ProgTrailer();
            break;
        case SETSHEAD://17:	    /* slip header */
            ProgSlipHead();
            break;
        case SETREPORT://18:
            ProgReport();
            break;
        case SETFIXCAP://19:	/* fixed captions */
        case SETERRMSG://20:	/* system & error message */
        case SETWEEKCAP://21:	/* day of week captions */
        case SETMONTHCAP://22:	/* month captions */
        case SETREPTYPE://23:	/* report types */
            ProgSysMes();
            break;
        case SETSYSFLAG://24:	 /* system flags */
            ProgSysFlag();
            break;
        case SETKEYB://25:	/* keyboard code and manager */
            Appl_MaxEntry = 5;
            memset(ProgLineMes,' ',sizeof(ProgLineMes));
#if(DD_ZIP==1)
            //memset(ProgLine1Mes,' ',sizeof(ProgLine1Mes));
            strcpy(ProgLine1Mes,EXITMESS);//ccr2014-10-31
#endif
            CopyFrStr(ProgLineMes + 1, Prompt.TypeCap[SETKEYB-1]);
            if (ProgLine < 3)
            {
#if(DD_ZIP==1)
                CopyFrStr(ProgLineMes + 1, Prompt.LineCap[Line_KEYCODE]);
#else
                CopyFrStr(ProgLineMes + 6, Prompt.LineCap[Line_KEYCODE]);
#endif
                if (ProgLine == 1)
                {
                    ProgLine++;
                    break;
                }
            }
            else
            {
                ProgType = 0;
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                strcpy(ModeHead,DText[22]);//PROGRAM
/*ccr080829
#if(DD_ZIP==1 || DD_ZIP_21==1)
                        CopyFrStr(ProgLineMes + 1, Prompt.LineCap[Line_MANAGE]);
#else
                        CopyFrStr(ProgLineMes + 6, Prompt.LineCap[Line_MANAGE]);
#endif
                        if (ProgLine == 3)
                        {
                            ProgLine++;
                            break;
                        }
*/
            }
            if (ApplVar.Key.Code > 2 && ApplVar.Key.Code < 0x0100)
                return 0;
            if (ProgLine == 2)
            {
                if ((ApplVar.NumberEntry == '.' || ApplVar.NumberEntry < 3 || ApplVar.NumberEntry > 299) &&
                    ApplVar.NumberEntry != CLEAR && ApplVar.NumberEntry != MODELOCK)
                {
                    //ccr2014-03-10>>>>>>>>
                    if (ApplVar.AP.FirmKeys[ID_SHIFTDEPT] == ApplVar.KeyNo)
                        ApplVar.AP.FirmKeys[ID_SHIFTDEPT] = 0xff;
                    else if (ApplVar.AP.FirmKeys[ID_DATE] == ApplVar.KeyNo)
                        ApplVar.AP.FirmKeys[ID_DATE] = 0xff;
                    else if (ApplVar.AP.FirmKeys[ID_RJFEED] == ApplVar.KeyNo)
                        ApplVar.AP.FirmKeys[ID_RJFEED] = 0xff;
                    else if (ApplVar.AP.FirmKeys[ID_CLEAR] == ApplVar.KeyNo)
                        ApplVar.AP.FirmKeys[ID_CLEAR] = 0xff;
                    else if (ApplVar.AP.FirmKeys[ID_LOCK] == ApplVar.KeyNo)
                        ApplVar.AP.FirmKeys[ID_LOCK] = 0xff;
                    //<<<<<<<<<<<<<
                    ApplVar.AP.KeyTable[ApplVar.KeyNo] = ApplVar.NumberEntry;
                    switch (ApplVar.NumberEntry)
                    {
                    case SHIFT1:
                        ApplVar.AP.FirmKeys[ID_SHIFTDEPT] = ApplVar.KeyNo;
                        break;
                    case DATETIME:
                        ApplVar.AP.FirmKeys[ID_DATE] = ApplVar.KeyNo;
                        break;
                    case JPF:
                        ApplVar.AP.FirmKeys[ID_RJFEED] = ApplVar.KeyNo;
                        break;
                    }
                    SETBIT(ApplVar.MyFlags,CONFIGECR);
                }
            }
/*ccr080829			else if (ProgLine == 4 && !Appl_EntryCounter)
                    {
                        if (ApplVar.KeyNo == ApplVar.AP.FirmKeys[ID_CANCEL])
                            ProgLine = 0;
                        else
                            ApplVar.AP.Manager[ApplVar.KeyNo / 8] ^= (0x01 << (ApplVar.KeyNo % 8));
                    }*/
            else
            {
                ProgType = 0;
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                strcpy(ModeHead,DText[22]);//PROGRAM
            }
            DeptPluKeysCount();
            break;
        case SETKEYMASK://26:	/* keyswitch disable */
            if (GetOpt(7, ApplVar.AP.Config.KeyMask, sizeof(ApplVar.AP.Config.KeyMask) * 8))
                break;
        case SETPBINF://27:
            ProgPbInfo();
            break;
        case SETSALER://28:
            ProgSalPer();
            break;
        case SETDATE:
#if defined(FISCAL)
            if (ApplVar.ZReport != 1)   /* z report taken ? */
            {
                ProgStart = 0;
                ApplVar.ErrorNumber=ERROR_ID(CWXXI75);
                CopyFrStr(ProgLineMes, Prompt.TypeCap[ProgType - 1]); // liuj 0808
                return 0;//ccr2014 break;
            }
#endif
            ProgDate();
            break;
        case SETTIME:
#if defined(FISCAL)
            if (ApplVar.ZReport != 1)   /* z report taken ? */
            {
                ProgStart = 0;
                ApplVar.ErrorNumber=ERROR_ID(CWXXI75);
                CopyFrStr(ProgLineMes, Prompt.TypeCap[ProgType - 1]); // liuj 0808
                return 0;//ccr2014 break;
            }
#endif

            ProgTime();
            break;
        case SETOFF:
            ProgOFF();
            break;
        case SETPORT1:
            ProgPort(0);
            break;
        case SETPORT2:
            ProgPort(1);
            break;
        case SETPORT3:
            strcpy(ProgLineMes,Reserved);
            break;

        case SETIP:
#if (defined(CASE_ETHERNET)||defined(CASE_GPRS))
            ProgIP();    //ccr chipcard 2004-06-28
#else
            strcpy(ProgLineMes,Reserved);
#endif
            break;
#if defined(CASE_GPRS)
        case SETGPRSFUNC:
            ProgGPRSFuncs();
            break;
#endif
#if defined(CASE_ETHERNET)
        case SETETHERNETFUNC:
            ProgEthernetFuncs();
            break;
#endif
        case SETGRAP:
            ProgPrnGraph();
            break;
        case SETIC:
#if (DD_CHIPC==1)
            ProgIC();    //ccr chipcard 2004-06-28
#else
            strcpy(ProgLineMes,Reserved);
#endif
            break;
        case SETPROM:
            ProgPromotion();
            break;
//ccr070725				case SETAGREE:
//ccr070725					ProgAgree();
//ccr070725					break;
        case SETKP:
            ProgKPrn();
            break;
        case SETSP:
            ProgSlip();
            break;
#if defined(FISCAL)
//hf 20060823 >>>>>>>>>>>>>>>>>>>>>>>>
        case SETUSERINFO:
            ProgUserInfo(ApplVar.UserInfo.InputIDX);
            break;
//hf end <<<<<<<<<<<<<<<<<<<<<<<<<<<<
#endif
#if (DD_CHIPC==1)
        case SETBLOCKIC:
            ProgICBlock();
            break;  //ccr chipcard 2004-07-01
        case SETCHARGIC:
            ProgChargeChip();
            break;
        case SETCLEARIC:
            ProgClearChip();
            break;
        case SETINITIC:
            ProgInitialChip();
            break;
        case SETCHIPPOINT:
            ProgPoints();
            break;
#else
        case SETBLOCKIC:
        case SETCHARGIC:
        case SETCLEARIC:
        case SETINITIC:
        case SETCHIPPOINT:
            strcpy(ProgLineMes,Reserved);
            break;
            //ccr chicard<<<<<<<<<<<<<<<<<<<<<<<<<<<
#endif
        default:
            ProgType = 0;
            strcpy(ModeHead,DText[22]);//PROGRAM
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            break;
        }


////////////////////////////////////  liuj0529
#if 0
#if defined(FISCAL) && DD_MMC == 1
        if (ProgStart  && (ProgType==SETPLU || ProgType == SETDEPT || ProgType == SETTAX ||ProgType == SETHEAD))
        {
            if (ProgLine > 2)
            {
                MemSet(SysBuf, 6, ' ');
                memcpy(SysBuf + 6, ProgLineMes, sizeof(ProgLineMes));
                PrintStr(SysBuf);
            }
            else
            {
                PrintStr(ProgLineMes);
                if (ProgType == SETPLU)      /* PLU ? */
                {
                    if (ProgLine == 1 && ApplVar.AP.Plu.RandomSize) /* random number ?*/
                    {
                        SysBuf[0] = 'R';
                        SysBuf[1] = ':';
                        HEXtoASC(SysBuf+2, ApplVar.Plu.Random, ApplVar.AP.Plu.RandomSize);
                        SysBuf[ApplVar.AP.Plu.RandomSize * 2 + 2] = 0;
                        PrintStr(SysBuf);
                    }
                }
            }
        }
#endif
#endif

        Save_ConfigVar(false);

        //���ProgLine=0,��ʾ�Զ�ѭ�����õ�ǰ�ļ�������
        if (ProgLine
#if defined(FISCAL)
            || ProgType == SETUSERINFO
#endif
            || ProgType == SETSYSFLAG
            || ProgType == SETIP//ccr2015-10-12
            || ProgType == SETGPRSFUNC //ccr2016-12-23
#ifdef CASE_ETHERNET				
            || ProgType == SETETHERNETFUNC//ccr2017-02-16
#endif				
            || ProgType == SETKEYB
            || ProgType == SETKEYMASK
            || ProgType >= SETCLEARIC)//ccr chipcard
            break;

        if (ProgStart == 2)
        {//ö�ٴ�ӡ����
            ApplVar.ProgNumber++;
        }
        else if (ProgType == SETDEPT  && ApplVar.ProgNumber >=0 /*|| ProgType == SETTAX || ProgType == SETHEAD*/)
        {
#if defined(FISCAL)    // liuj 0805
            RFeed(1);   //liuj 0531 PM
            SETBIT(ApplVar.Fiscal_PrintFlag,BIT4);
            DumpDept();// LIUJ 0606  ProgramDump();
#endif
            //PrintRegiInfo();
            //ApplVar.EJContent = ENDCONT;
            //FiscalTrailer();

        }
        ProgLine = 1;//�������õ�ǰ�ļ�
    }//end of for()

    if (ProgStart == 2)
        ProgLineMes[sizeof(ProgLineMes) - 1] = 0;

    return 1;
}


//CheckFirmKey return true(1) If the input from keyboard processed by CheckFirmKey
//else return false(0);
WORD CheckFirmKey()
{
    int  i;
    BYTE    keyno;

    keyno = ChangeFuncKey(ApplVar.KeyNo);

    if (keyno==ApplVar.AP.FirmKeys[ID_CLEAR])    /* firm key clear key */
    {

        ApplVar.Key.Code = CLEAR;
        return 0;
    }

    if ((ApplVar.CentralLock & 0xff00)==PWDFOR)
        return 0;
    if (ApplVar.ErrorNumber)
        return TRUE;
    //ccr2016-12-20>>>>>>>>>>>>>>>
    if (Appl_EntryCounter==0 && ProgType==0 && ApplVar.Key.Code==ZERO2)
    {
        PrintSetupMenu();//��ӡ���ò˵�
        return true;
    }//ccr2016-12-20<<<<<<<<<<<<<<<<
    else if (Appl_EntryCounter && ProgType == SETKEYB && ProgLine == 2)
        i = ID_PRGENTER;    /* simulate enter key */
    else if (ProgType == SETKEYB && ProgLine == 4)
    {
        i = ID_PRGENTER;
        ProgLine--;
    } else
        i = GetFirmkeyID(keyno);

    if (ApplVar.FuncOnEnter!=0 && i!=ID_CANCEL)      //lyq added 2003\10\30		   start
    {
        return false;
    }                                      //lyq added 2003\10\30		   end
    if ((ApplVar.FRegi || ApplVar.FInv) && i < sizeof(ApplVar.AP.FirmKeys))
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI14);
        return 1;
    }
    if (Appl_EntryCounter)
    {
        StrToBCDValue(ApplVar.Entry.Value, &EntryBuffer[sizeof(EntryBuffer) - 2], BCDLEN);
        GetWordEntry();
    }
    else if (ApplVar.NumberEntry<0)//special use for fCANCEL
        ApplVar.NumberEntry = abs(ApplVar.NumberEntry);
    else
        ApplVar.NumberEntry = 0;

    switch (i)//(ApplVar.AP.FirmKeys[i])
    {
    case ID_SYSREP:         // system report trigger
#if defined(FISCAL)
        if (ApplVar.CentralLock == SET)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            return 1;
        }
//liuj 0529
        if (ApplVar.FisCardFlag!= FISCALOK
            && ApplVar.FisCardFlag != TESTFM //liuj 0728  test card can do everything except sale
            && ApplVar.FisCardFlag != FMLESS
            && ApplVar.FisCardFlag != EJLESS)
        {
            if (ApplVar.FisCardFlag == FMISNEW)
                ApplVar.ErrorNumber=ERROR_ID(CWXXI94);
            else
                CheckFisError();
            return 1;
        }

#endif

        ApplVar.FReport = ApplVar.CentralLock;
        GetSystemReport(0);
        ApplVar.FReport = 0;
        break;
    case ID_PRGTYPE:     /* program type key */
        if (ApplVar.CentralLock==X || ApplVar.CentralLock==Z)
        {// use fPRGTYPE key to select a ApplVar.Report file;
            ApplVar.ReportNumber++;
            if (ApplVar.ReportNumber>XZNUM)
                ApplVar.ReportNumber = 1;

            if (Appl_EntryCounter)
            {
                if (ApplVar.NumberEntry==0 || ApplVar.NumberEntry>XZNUM)
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                    break;
                }
            }
            else
                ApplVar.NumberEntry = ApplVar.ReportNumber;

            ApplVar.ReportNumber = ApplVar.NumberEntry;
            memset(SysBuf,' ',DISLEN+5);
#if(DD_LCD_1601==1)//ccr20131120>>>>>>>>>>>>>>
            SysBuf[0] = ModeHead[0];
            SysBuf[1] = '_';
            CopyFrStr(SysBuf+2,XZTitle[ApplVar.ReportNumber-1].Name);
#elif(DD_ZIP==1 || DD_ZIP_21==1)
            CopyFrStr(SysBuf,ModeHead);
            Puts1_Right(XZTitle[ApplVar.ReportNumber-1].Name);
#else
            SysBuf[0] = ModeHead[0];
            SysBuf[1] = '_';
            CopyFrStr(SysBuf+2,XZTitle[ApplVar.ReportNumber-1].Name);
#endif
            //ccr2014 WORDtoASC(SysBuf+DISLEN - 1,ApplVar.NumberEntry);
            PutsO(SysBuf);
			//<<<<<<<<<<<<<<<<<<<<<<
            ClearEntry();
            return 1;
        }
        if (ProgType==SETGRAP && ProgLine==1)
        {//������ͼƬʱ,��ѡ���ѡ��ͼƬ
            ApplVar.ProgNumber++;
            if (ApplVar.ProgNumber>GRASETMAX )
                ApplVar.ProgNumber = 0;
            DisplayOption();
            PutsO(ProgLineMes);
#if(DD_ZIP==1 || DD_ZIP_21==1)
            Puts1(ProgLine1Mes);
#endif
            return 1;
        }
        if (ProgType>0 && ProgLine>0 && ProgStart>0)// && BitNumber)
        {//�ڴ��������ļ���ĳ����Ŀ״̬ʱ,�����ѡ���,�����������
            /* change option on/off */
            if (BitNumber)     /* ֻ�����λ������,���ܹ���ѡ���,invert option ? */
                Appl_EntryCounter = 1;   /* set invert by setting Appl_EntryCounter */
            else
            {//���򱨴�
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                break;
            }
            BitNumber++;
            ProgStart = 1;
            if (!DisplayOption())
                return 0;
            if (!ApplVar.ErrorNumber)
            {
                PutsO(ProgLineMes);
#if(DD_ZIP==1 || DD_ZIP_21==1)
                Puts1(ProgLine1Mes);
#endif
            }
            break;
        }
        if (ApplVar.NumberEntry > 102 && ApplVar.NumberEntry < 108)  /* Check ApplVar.Plu File */
        {
            if (ApplVar.NumberEntry == 107 && ApplVar.CentralLock != SET)
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);  /* repair only in Z or SET */
            else
                CheckPluFile(ApplVar.NumberEntry);
            break;
        }
        if (ApplVar.NumberEntry)
        {//ѡ��Ҫ���õ��ļ�
            ProgType = ApplVar.NumberEntry;
            ProgType--;
            ProgStart = 0;
        }

        if (!ProgType || !ProgStart)// �Զ�������ʽѡ��Ҫ���õ��ļ�
            (ProgType >= SETUPMAX || !ProgType)?(ProgType = 1):(ProgType++);
        Appl_MaxEntry = 5;
        strcpy(ProgLineMes,Prompt.TypeCap[ProgType - 1]);
        PutsO(ProgLineMes);//    display selected type would be setup
#if(DD_ZIP==1 || DD_ZIP_21==1)
        Puts1(ENTERMESS);//ccr20131120
#endif
        ProgStart = 0;
        ApplVar.ProgNumber = 0;
        ProgLine = 0;//
        BitNumber = 0;
        break;
    case ID_PRGUP:     /* ���ص���һ��������Ŀ */
        //1.����SET��,������δ�����ļ�����()
        if (ApplVar.CentralLock == SET)
        {
            if (ProgType==SETGRAP && ProgLine==1)
            {//������ͼƬʱ,��ѡ���ѡ��ͼƬ
                if (ApplVar.ProgNumber>0)
                {
                    ApplVar.ProgNumber--;
                    DisplayOption();
                    PutsO(ProgLineMes);
#if(DD_ZIP==1 || DD_ZIP_21==1)
                    Puts1(ProgLine1Mes);
#endif
                }
                return 1;
            }
            if (ProgType>0 && ProgLine>0 && ProgStart>0)// && BitNumber)
            {//�ڴ��������ļ���ĳ����Ŀ״̬ʱ,
                if (ProgLine>2)
                {
                    ProgLine--;
                    ClearEntry();
                    keyno = ProgLine;//��DisplayOption����ǿ������ProgLine�����
                    BitNumber=0;
                    ProgStart = 1;
                    if (!DisplayOption())
                        return 0;
                    if (ProgLine>keyno)
                    {//��DisplayOption����ǿ���޸�ProgLine�����
                        ProgLine=keyno;
                    }
                    if (!ApplVar.ErrorNumber)
                    {
                        PutsO(ProgLineMes);
        #if(DD_ZIP==1 || DD_ZIP_21==1)
                        Puts1(ProgLine1Mes);
        #endif
                    }
                }
                return 1;
            }
            if (ProgType>1 && !ProgStart)
            {//ѡ��Ҫ���õ��ļ�
                ProgType--;
                memset(ProgLineMes,' ',DISLEN+1);
                CopyFrStr(ProgLineMes, Prompt.TypeCap[ProgType - 1]);
                Appl_MaxEntry = 5;
                PutsO(ProgLineMes);//    display selected type would be setup
        #if(DD_ZIP==1 || DD_ZIP_21==1)
                Puts1(Msg[SPACE].str);
        #endif
                ApplVar.ProgNumber = 0;
                ProgLine = 0;//
                BitNumber = 0;
            }
        }
        break;
    case ID_PRGENTER:     /* enter key */
        if (ApplVar.CentralLock == X || ApplVar.CentralLock == Z)
        {/* select report for X/Z by the input */
#if  (defined(CASE_MALTA))
            if (Appl_EntryCounter==0 && (ApplVar.ReportNumber==0 || ApplVar.ReportNumber>XZNUM))
            {
                ApplVar.NumberEntry = 1;
                Appl_EntryCounter = 1;
            }
#endif
            if (Appl_EntryCounter)
            {

                if (ApplVar.NumberEntry==0 || ApplVar.NumberEntry>XZNUM)
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                    break;
                }

                ApplVar.ReportNumber = ApplVar.NumberEntry;
                memset(SysBuf,' ',DISLEN+5);
				//ccr20131120>>>>>>>>>>>>>>>>>
                ApplVar.ReportNumber = ApplVar.NumberEntry;
                memset(SysBuf,' ',DISLEN+5);
    #if(DD_LCD_1601==1)
                SysBuf[0] = ModeHead[0];
                SysBuf[1] = '_';
                CopyFrStr(SysBuf+2,XZTitle[ApplVar.ReportNumber-1].Name);
    #elif(DD_ZIP==1 || DD_ZIP_21==1)
                CopyFrStr(SysBuf,ModeHead);
                Puts1_Right(XZTitle[ApplVar.ReportNumber-1].Name);
    #else
                SysBuf[0] = ModeHead[0];
                SysBuf[1] = '_';
                CopyFrStr(SysBuf+2,XZTitle[ApplVar.ReportNumber-1].Name);
    #endif
               //ccr2014 WORDtoASC(SysBuf+DISLEN - 1,ApplVar.NumberEntry);
				//<<<<<<<<<<<<<<<<<<<<<<
                PutsO(SysBuf);
            }
#if (BARCUSTOMER==1)
            if (ApplVar.ReportNumber==14)   // �����Ա����  //
            {
#if DD_MMC == 1
                keyno = ApplVar.ContFlag;
                RESETBIT(ApplVar.ContFlag,ENSTORE);
#endif
                PrintBARCustomer(ApplVar.CentralLock);
#if DD_MMC == 1

                ApplVar.ContFlag = keyno;
#endif
            }
            else
#endif
            {
                ApplVar.RepComputer = 0;
                ApplVar.FReport = ApplVar.CentralLock;
#if defined(FISCAL)
//liuj 0529
                if (ApplVar.FisCardFlag!= FISCALOK
                    &&  ApplVar.FisCardFlag != TESTFM //liuj 0728  test card can do everything except sale
                    && ApplVar.FisCardFlag !=FMLESS
                    && ApplVar.FisCardFlag != EJLESS)
                {
                    if (ApplVar.FisCardFlag == FMISNEW)
                        ApplVar.ErrorNumber=ERROR_ID(CWXXI94);
                    else
                        CheckFisError();
                    return 1;
                }

                if (ApplVar.FReport == Z && ApplVar.ReportNumber == 1/*&& ApplVar.FisCardFlag == FISCALOK*/)//ccr070609pm
                    Print_FiscalReport();//��ӡZ����
                else
#endif
                    GetReport(ApplVar.ReportNumber);

                ApplVar.FReport = 0;
            }
            break;
        }
        if (ApplVar.CentralLock == SET && ProgType)//ccr chipcard
        {//Ϊ����״̬
            if (ProgType < SETCLEARIC)//ccr chipcard
            {
                MemSet(ModeHead, sizeof(ModeHead), ' ');
#if(DD_ZIP==1 || DD_ZIP_21==1 || DD_LCD_1601)
                CopyFrStr(ModeHead,Prompt.TypeCap[ProgType - 1]);
                ModeHead[tCAPWIDTH] = 0;
#else
                CopyFrStr(ModeHead,Prompt.TypeCap[ProgType - 1], 4);
                ModeHead[4] = 0;
#endif
            }

            if (ProgLine==1 && Appl_EntryCounter)// && ProgStart>0)
            {
                /* program number key,select spacified PLU/DEPT/.... */
                if (!ProgStart)
                {
                    CheckMultiply();
                    break;
                }
                ApplVar.Entry.Sign = 0;
                if (ProgType == SETPLU && ApplVar.AP.Plu.RandomSize)
                {
                    ApplVar.PluNumber = 0;
                    if (Appl_EntryCounter <= (ApplVar.AP.Plu.RandomSize * 2))
                    {
                        ApplVar.PluNumber = GetPluNumber(1, ApplVar.Entry.Value);
                        if (!ApplVar.PluNumber)       /* not found then add ? */
                        {
                            if (!CheckRandomPlu(0, 0))       /* add */
                            {
                                PutsO(ModeHead);// liuj 0806
                                break;
                            }
                            ApplVar.PluNumber = GetPluNumber(0,ApplVar.Entry.Value);
                        }
                        else if (ApplVar.CentralLock != X)  /* ask for delete ? */
                            CheckRandomPlu(1, 0);   /* delete? */
                        ApplVar.NumberEntry = ApplVar.PluNumber;
                    }
                    else
                        ApplVar.NumberEntry = 0;
                }

                if (ProgType==SETDATE || ProgType==SETTIME)//ccr2015-10-12  || ProgType==SETIP)
                {

                    ProgLine = 2;//set date or time
                    DisplayOption();
                    ClearEntry();
//						ClearLine2();
                    strcpy(ProgLineMes,ModeHead);
                    return 1;
                }
                if (ApplVar.NumberEntry)
                    ApplVar.ProgNumber = ApplVar.NumberEntry - 1;
                else
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                    break;
                }
                //�����˼�¼��
                ProgLine = 0;
                BitNumber = 0;
                Appl_EntryCounter = 0;
                ApplVar.ErrorNumber=0;
                ApplVar.KeyNo = ApplVar.AP.FirmKeys[ID_PRGENTER];//fPRENTER;
                CheckFirmKey();//=======================!!!!!!!!!!!!!
                return 1;
            }
            if ((ProgType==SETDATE || ProgType==SETTIME)//ccr2015-10-12 || ProgType==SETIP)
                && !Appl_EntryCounter && SetDateFlg>0)
            {
                SetDateFlg = 0;
                Appl_EntryCounter = 0;
                ApplVar.ErrorNumber=0;
                ProgLine = 0;
                ProgStart = 0;
                BitNumber = 0;
                ApplVar.KeyNo = ApplVar.AP.FirmKeys[ID_PRGENTER];//fPRTYPE;
                CheckFirmKey();//=======================!!!!!!!!!!!!!
                return 1;
            }
        }// end of "if (ApplVar.CentralLock==SET && ProgType && Appl_EntryCounter)"

        if (!Appl_EntryCounter)
        {
            if (!ProgType)
            {
                PutsO(ModeHead);
                break;
            }
            else if (!TESTBIT(ApplVar.MyFlags,SETCONFIRM))//ccr040809
            {
                ProgLine++;
                BitNumber = 0;
            }
            else
                break;
        }
        else if (BitNumber || !ProgType)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            break;
        }
        ProgStart = 1;
        if (!DisplayOption())
            return 0;
        if (!ApplVar.ErrorNumber)
        {
            PutsO(ProgLineMes);

#if(DD_ZIP==1 || DD_ZIP_21==1)
            Puts1(ProgLine1Mes);
#endif

        }
        break;
    case ID_DUMP:   /* dump program key */
//ccr20140603        ProgramDump();
        break;

    case ID_CANCEL://  ProgType>0
        RESETBIT(ApplVar.MyFlags,PWDMODE+HANZIMODE+SETCONFIRM);//ccr040809
        SetInputMode(0);

        //ccr chipcard>>>>>>>>>>>>>>>>>>>>>>>>>>

        if ((ApplVar.CentralLock & SETUPMG) == SETUPMG)
        {//cancel the verify of password mode,return to REGIS mode directly
            ApplVar.CentralLock &=( ~SETUPMG);
#if	(DD_CHIPC==1)
            IC.ICState &= IC_NOTREMOVED;
#endif
            ClearEntry();
            Appl_MaxEntry = sizeof(EntryBuffer)-2;
            PutsO(ModeHead);
            ClearLine2(); //
            ProgType = ProgLine = 0;
            return ApplVar.CentralLock;
        }//<<<<<<<<<<<<
        //ccr chipcard<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
/*		if (ApplVar.CentralLock & PWDFOR)
        {//cancel the verify of password mode,return to REGIS mode directly
            ApplVar.CentralLock = RG;
            ClearEntry();
            strcpy(ModeHead,DText[1+18]);
            PutsO(ModeHead);						 //lyq added 2003\11\1 end
            ModeHead[0]=0;
            return RG;
        }*/
        Save_Config(false);
        if (ProgLine==0 && ProgStart==0)
        {//return to SET mode
            ProgType = 0;
            if (ApplVar.CentralLock==X || ApplVar.CentralLock==Z)
            {
                PutsO(ModeHead);
                Appl_MaxEntry = 2;
                break;
            }
            else
            {
                ApplVar.FuncOnEnter = 0;           //lyq added 2003/10/30
                ApplVar.CentralLock = SET;
                strcpy(ModeHead,DText[22]);
                PutsO(ModeHead);
                Appl_MaxEntry = 5;
                break;
            }
        }
        else
        {//return to last set mode
#if defined(FISCAL) //&& DD_MMC == 1 //liuj 0530

            if (ProgType == SETDEPT  && ApplVar.ProgNumber >=0 /*|| ProgType == SETTAX || ProgType == SETHEAD*/)
            {
                RFeed(1); // liuj 0531 PM
                SETBIT(ApplVar.Fiscal_PrintFlag,BIT4);
                DumpDept();// LIUJ 0606  ProgramDump();
                ApplVar.FStatus = 0;
                AddReceiptNumber();
                ApplVar.FReceipt = 1;
                ReceiptIssue(1+BIT1);
            }
#endif
            ProgType--;
            ApplVar.ErrorNumber=0;
            Appl_EntryCounter = 0;
            ProgLine = 0;
            ProgStart = 0;

            ApplVar.KeyNo = ApplVar.AP.FirmKeys[ID_PRGTYPE];//fPRGTYPE;
            CheckFirmKey();
            return 1;
        }
    default:
        return 0;
    }
    ClearEntry();
#if( (DD_ZIP==1)||(DD_ZIP_21==1) )
    if (i == ID_CANCEL)
    {
        ClearLine2(); //
    }
#endif
    return 1;
}


BOOL CheckPassword()
{
    CONSTCHAR *sMode;

    switch (ApplVar.CentralLock & 0xff)
    {
    case X:
        sMode = ApplVar.AP.ModePwd.PwdX;
        break;
    case Z:
        sMode = ApplVar.AP.ModePwd.PwdZ;
        break;
    case SET:
        sMode = ApplVar.AP.ModePwd.PwdSET;
        break;
    case MG:
        sMode = ApplVar.AP.ModePwd.PwdMG;
        break;
    default:
        return TRUE;
    }
    if (sMode[0]==0)
        return TRUE;
    else
        return(!strcmp(PwdInput,sMode));
}

void DispForPwd(CONSTCHAR *mess)
{
    if ((ApplVar.CentralLock & 0xf00)==0x200)
        memset(SysBuf,'?',DISLEN+5);
    else
        memset(SysBuf,'-',DISLEN+5);

#if( DD_ZIP==1 || DD_ZIP_21==1 )
    PutsO(mess);
    Puts1(SysBuf);
#else
    CopyFrStr(SysBuf,mess);
    PutsO(SysBuf);
#endif
}
//chang the work mode if Press MODELOCK key
//CheckMode return true(1) or simulated ApplVar.KeyNo If the input from keyboard processed by CheckMode
//else return false(0);


BYTE CheckMode()
{
    BYTE keyno;
    short   i,j;
    UnLong sAddr,sVal;
    BYTE sYear,sMonth,sDay;
    BYTE setprint;

    keyno=ChangeFuncKey(ApplVar.KeyNo);
    if (ApplVar.KeyNo == ApplVar.AP.FirmKeys[ID_RJFEED])
    {
        if (Appl_EntryCounter==0)
        {
            JFeed();
            return true;
        }
        else//���Ѿ�����������ʱ.��������ֽ,��ֽ����Ϊɾ��������
            return false;
    }

    if (ApplVar.ErrorNumber)
        return FALSE;

    if (TESTBIT(ApplVar.MyFlags,CANCELSAL) && keyno != ApplVar.AP.FirmKeys[ID_CLEAR] && keyno != ApplVar.AP.FirmKeys[ID_PRGENTER])
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI25);
        return TRUE;
    }

    if (ApplVar.Key.Code == CORREC+4 && ApplVar.FRegi)
    {//��Ϊȡ������ʱ,����һ��ȷ��
        SETBIT(ApplVar.MyFlags,CANCELSAL);
        PutsO(DMes[24]);//confirm
        return TRUE;
    }

    i = GetFirmkeyID(keyno);

    if (i>=sizeof(ApplVar.AP.FirmKeys))//�������⹦�ܼ�֮��
        return FALSE;

    if (ApplVar.FuncOnEnter)
    {//���Ѿ��������⹦�ܲ���ʱ
        if (i==ID_CANCEL)
        {
            SetInputMode(0);
            ApplVar.FuncOnEnter = 0;
            ApplVar.Key.Code = 0;
            ApplVar.LogDefine.idx = 0;
            ClearEntry();
            Appl_MaxEntry=5;
            PutsO(ModeHead);
            ClearLine2(); //
            return TRUE;
        }
        else if (i==ID_CLEAR)
        {
            ApplVar.Key.Code=0;
            ClearEntry();
#if (DD_ZIP==1 || DD_ZIP_21==1)
            Puts1(Msg[SPACE].str);
#else
            PutsO(EntryBuffer + sizeof(EntryBuffer) - DISLEN - 1);
#endif
            return TRUE;
        }
        else if (i!=ID_PRGENTER && i!=ID_SHIFTKEY)
        {
            ApplVar.Key.Code=0;
            return TRUE;
        }
    }

    switch (i)
    {
/*
    case ID_CANCEL:
        if (ApplVar.CentralLock != RG && !ProgType)
        {

            keyno = RG;
            ApplVar.CentralLock = RG;
            ModeHead[0]=0;
            ClearEntry();
            PutsO(DText[1+18]);
            return keyno;

        }
        else
            return 0;
*/
    case ID_SHIFTKEY:  /* �ı���̵�λ(a->A->9 */
        if ((ApplVar.CentralLock == SET || ApplVar.CentralLock == (SETUPMG|RG) || ApplVar.CentralLock == (SETUPMG|MG)))
        {
            if (TESTBIT(ApplVar.MyFlags,HANZIMODE))
            {
                if (TESTBIT(ApplVar.MyFlags, UPASCII))//��ǰ��ʽΪA
                {//�ı�Ϊ�������뷽ʽ
                    RESETBIT(ApplVar.MyFlags, UPASCII); //UPASCII = 0,NUM_ASCII=1
                    SETBIT(ApplVar.MyFlags, NUM_ASCII);      //INput numric mode
                }
                else if (TESTBIT(ApplVar.MyFlags, NUM_ASCII))//��ǰ��ʽΪ9
                {//�ı�Ϊa��ʽ
                    RESETBIT(ApplVar.MyFlags, NUM_ASCII);    //UPASCII=0,NUM_ASCII=0
                }
                else//��ǰ��ʽΪa
                {//�ı�ΪA
                    SETBIT(ApplVar.MyFlags, UPASCII);       //UPASCII=1,NUM_ASCII=0
                }

                DispInputMode();
                return TRUE;
            }
        }

        return FALSE;
    case ID_SHIFTDEPT:    /* �ı䲿�൵λ */
        if ((ApplVar.CentralLock == RG || ApplVar.CentralLock == MG) && ApplVar.AP.Dept.Number>ApplVar.DeptKeys )// && TESTBIT(SLFLAG,BIT7))  liuj 0921
        {
            INVERTBIT(ApplVar.ArrowsAlfa,BIT6);
            memset(SysBuf,' ',DISLEN);
#if(DD_ZIP==1 || DD_ZIP_21==1)
            PutsO(Prompt.TypeCap[SETDEPT-1]);
            memset(SysBuf,' ',DISLEN);
#else
            CopyFrStr(SysBuf,Prompt.TypeCap[SETDEPT-1]);
#endif

            if (TESTBIT(ApplVar.ArrowsAlfa,BIT6))
            {
                WORDtoASC(SysBuf+7,ApplVar.DeptKeys+1); SysBuf[8] = '-'; WORDtoASC(SysBuf+10,ApplVar.DeptKeys*2);
            }
            else
            {
                WORDtoASC(SysBuf+7,1);  SysBuf[8] = '-'; WORDtoASC(SysBuf+10,ApplVar.DeptKeys);
            }


#if(DD_ZIP==1)
            Puts1(SysBuf);
#elif(DD_ZIP_21==1)
            Puts1(SysBuf);
            PutsC(SysBuf+DISLEN-4);   /*   2008-08-14 10:21:36  ������ʾ����    */
#else
            PutsO(SysBuf);
#endif
            return 1;
        }
        return false;
    case ID_CLEAR:
/*		if (TESTBIT(ApplVar.MyFlags,SETCONFIRM))//ccr040809
        {//don't confirm SETUP request.
            RESETBIT(ApplVar.MyFlags,SETCONFIRM);
            ApplVar.KeyNo = fCANCEL;
            return FALSE;
        }*/
        if (TESTBIT(ApplVar.MyFlags,CANCELSAL))
        {
            RESETBIT(ApplVar.MyFlags,CANCELSAL);
            ApplVar.Key.Code = 0;
            ClearEntry();
            PutsO(EntryBuffer+sizeof(EntryBuffer)-DISLEN-1);
            ClearLine2();
            return TRUE;
        }
        return FALSE;
    case ID_RJFEED:
//			RFeed(1);
        return TRUE;
    case ID_DATE:     /* date */
        if (ApplVar.CentralLock==RG)
        {
            InActive |= ACTIVE+1;     /*    Inactive longer then allowed     */
            CheckTime(TRUE | 0x80);
            InActive ^= 0x80;
            return TRUE;
        }
        else
            return FALSE;
#if !defined(FISCAL)//ccr070609pm
    case ID_OCPRINTER:
        if (TESTBIT(DOT,BIT5) && !Appl_EntryCounter)
        {
#if PC_EMUKEY
            if (FisTestTask.PrnOFF)   //    ccr080519 added for control the printing of pb message
            {
                FisTestTask.PrnOFF = 0;
                PutsO(MessageE49);
            }
            else
            {
                FisTestTask.PrnOFF = 1;
                PutsO(MessageE50);
            }

#else
            if (!TESTBIT(ApplVar.MyFlags,ENPRINTER))
            {
                PutsO(MessageE50);
                SETBIT(ApplVar.MyFlags,ENPRINTER);
            }
            else
            {
                PutsO(MessageE49);
                RESETBIT(ApplVar.MyFlags,ENPRINTER);
            }
#endif
            return TRUE;
        }
        else
            return FALSE;
#endif
    case ID_PRGENTER://������������
        if (ProgType)
            return FALSE;

/*			if (TESTBIT(ApplVar.MyFlags,SETCONFIRM))//ccr040809
            {//confirm SETUP request.
                RESETBIT(ApplVar.MyFlags,SETCONFIRM);
                return FALSE;
            }*/
        if (TESTBIT(ApplVar.MyFlags,CANCELSAL))
        {
            ApplVar.Key.Code = CORREC+4;
            ProcessKey();
            RESETBIT(ApplVar.MyFlags,CANCELSAL);
            ApplVar.Key.Code = 0;
            return TRUE;
        }
#if (defined(CASE_MALTA))
        if (ApplVar.CentralLock==SET || ApplVar.FuncOnEnter ==FUNCUSERINFO || ApplVar.FuncOnEnter == FUNCVATNO)
#else
        if (ApplVar.CentralLock==SET || ApplVar.FuncOnEnter ==FUNCUSERINFO)
#endif
        {//Can chang password for a mode if in SET mode
            if (Appl_EntryCounter)
            {
                StrToBCDValue(ApplVar.Entry.Value, &EntryBuffer[sizeof(EntryBuffer) - 2], BCDLEN);
                GetWordEntry();
            }
            else
            {
                ApplVar.Entry = ZERO;
                ApplVar.NumberEntry = 0;
            }

            switch (ApplVar.FuncOnEnter)
            {
#if(DD_MMC == 1 )
//ccr070530>>>>>>>>>>>>>>>>>>>>>>>>>>
#if (defined(CASE_MALTA))
            case FUNCVATNO://����˿�˰��
                if (!Appl_EntryCounter)
                {
                    ApplVar.ErrorNumber = 1;
                    break;
                }
                if (Appl_EntryCounter>sizeof(ApplVar.FVatNo)) Appl_EntryCounter = sizeof(ApplVar.FVatNo);
                memcpy(ApplVar.FVatNo,EntryBuffer+sizeof(EntryBuffer)-Appl_EntryCounter-1,Appl_EntryCounter);
                SetInputMode(0);

                PutsO(ApplVar.FVatNo);

                ClearEntry();

                ProgLine = 0;
                ApplVar.FuncOnEnter = 0;
                Appl_MaxEntry = sizeof(EntryBuffer)-1;

                return false;
#endif
            case FUNC200:
                Search_EJ_Record();
                return TRUE;
#endif
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
            case FUNC300:
                ApplVar.FuncOnEnter = 0;
                HardTest(ApplVar.NumberEntry);
                CutRPaper(2);RFeed(4);
                ClearEntry();
                ClearLine2();

                strcpy(ModeHead,DText[22]);
                PutsO(ModeHead);
                return TRUE;
#if (CC_DEBUG)
            case FUNC401:
                if (Appl_EntryCounter>0)
                {
                    StoreEJEnd();//ccr070609pm

                    ApplVar.Entry.Sign = 0;
                    BCDValueToULong(ApplVar.Entry.Value,&sAddr);
                    RJPrint(0,FormatQtyStr(ModeHead,&ApplVar.Entry,14));

                    if (ApplVar.LogDefine.Type==0)
                    {
                        if (sAddr>=ADDR_APPRAM && sAddr<(ADDR_APPRAM+ApplVar.SIZE_EXTRAM))
                        {
                            Save_ApplRam();
                            RamOffSet = sAddr-ADDR_APPRAM;
                            ReadRam(SysBuf,128);
                        }
#if !defined(DEBUGBYPC)
                        else
                        {
                            if (sAddr<0x20000000l || sAddr>0x20020000l)
                                sAddr = (sAddr & 0x0001ffffl) + 0x20000000l;
                            memcpy(SysBuf,(CONSTCHAR *)(0x0l+sAddr),128);
                        }
#endif
                    }
#if defined(FISCAL)
                    else if (ApplVar.LogDefine.Type==1)//FM
                    {
                        if (!(Bios_FM_CheckPresence() && Bios_FM_Read(SysBuf, sAddr, 128)))
                            ApplVar.FuncOnEnter = 0;
                    }
#endif
#if (DD_MMC)
                    else if (ApplVar.LogDefine.Type==2)//EJ
                    {
                        if (!(MMC_CheckPresence() && ReadFromMMC(SysBuf, sAddr,128)))
                            ApplVar.FuncOnEnter = 0;
                    }
#endif
                    if (ApplVar.FuncOnEnter)
                    {
                        PrnBuffer(SysBuf,128);
                    }
                    CutRPaper(2);RFeed(4);
                }
                ApplVar.FuncOnEnter = 0;

                ClearEntry();
                ClearLine2();

                strcpy(ModeHead,DText[22]);
                PutsO(ModeHead);
                return TRUE;
#endif
//liuj for Fiscal>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#if defined(FISCAL)
            case FUNC800://Ϊ����˰�س�ʼ������
                Initial_Fiscal(false);
                return TRUE;
//hf end <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
            case FUNC802://���ݼ�¼�Ų�ѯZ��������
                switch (ApplVar.FiscalDefine.idx)
                {
                case 0:
                    if (Appl_EntryCounter)
                        ApplVar.FiscalDefine.RecNumFr = (WORD)BCDValueToULong(ApplVar.Entry.Value,&sVal);
                    else
                        ApplVar.FiscalDefine.RecNumFr = 0;

                    ApplVar.FiscalDefine.idx++;
                    Appl_MaxEntry = 5;
                    ClearEntry();
                    ClearLine2();
                    PutsO(Msg[RECNUMTO].str);
                    break;
                case 1:
                    if (Appl_EntryCounter)
                        ApplVar.FiscalDefine.RecNumTo = (WORD)BCDValueToULong(ApplVar.Entry.Value,&sVal);
                    else
                        ApplVar.FiscalDefine.RecNumTo = 0;
                    if (ApplVar.FiscalDefine.RecNumTo < ApplVar.FiscalDefine.RecNumFr)
                    {
                        ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                        return TRUE;
                    }
                    Read_FiscalData(ApplVar.FuncOnEnter-FUNC800);
                    ProgLine = 0;
                    ApplVar.FuncOnEnter = 0;
                    ClearEntry();
                    break;
                }
                return TRUE;
            case FUNC803://�������ڷ�Χ��ѯFM����
            case FUNC804:
#if DD_MMC == 1
                ApplVar.EJContent = FMCONT; //20070118
//						SETBIT(ApplVar.ContFlag, (ENSTORE|ENHEADER));
#endif

                switch (ApplVar.FiscalDefine.idx)
                {
                case 0:
                    if (Appl_EntryCounter)
                        NewTimeDate(0x11);//�������������ת������

                    sYear = Now.year & 0xff;
                    sMonth = Now.month;
                    sDay = Now.day;

                    ApplVar.FiscalDefine.DateFr = EncordDate(sYear,sMonth,sDay);
                    if (ApplVar.FiscalDefine.DateFr == 0)
                    {
                        ApplVar.ErrorNumber=ERROR_ID(CWXXI02);
                        return TRUE;
                    }
                    ApplVar.FiscalDefine.idx++;
                    Appl_MaxEntry = 8;

                    /*sAddr= ((UnLong)(0x2000+sYear)<<16) + 	//YY
                                    ((UnLong)sMonth<<8) +		//MM
                                    ((UnLong)sDay); 		//DD*/

                    memset(SysBuf,' ',DISLEN);
                    //HEXtoASC(SysBuf+DISLEN-8,(char*)&sAddr,4);
//liuj 0728
                    DateForDisplay(0);

#if(DD_ZIP==1)
                    PutsO(Prompt.LineCap[Line_DATETO]);
                    Puts1(SysBuf);
#elif(DD_ZIP_21==1)
                    PutsO(Prompt.LineCap[Line_DATETO]);
                    Puts1(SysBuf);
//								PutsC(SysBuf+4);
#elif(DD_LCD_1601)
                    memset(ProgLineMes,' ',DISLEN);
                    CopyFrStr(ProgLineMes,Prompt.LineCap[Line_DATETO]);
                    strcpy(ProgLineMes+DISLEN-8,SysBuf+DISLEN-8);
                    PutsO(ProgLineMes);
#else
                    PutsO(Prompt.LineCap[Line_DATETO]);
#endif
                    ClearEntry();
                    break;
                case 1:
                    //<<<<<<<<zengy 20100221
                    if (Appl_EntryCounter)
                        NewTimeDate(0x11);//�������������ת������
                    else
                        CheckTime(true | 0x80);
                    sYear = Now.year & 0xff;
                    sMonth = Now.month;
                    sDay = Now.day;
                    ApplVar.FiscalDefine.DateTo = EncordDate(sYear,sMonth,sDay);

                    GetTimeDate(&Now);
                    if (ApplVar.FiscalDefine.DateTo==0 || ApplVar.FiscalDefine.DateTo < ApplVar.FiscalDefine.DateFr )
                    {
                        ApplVar.ErrorNumber=ERROR_ID(CWXXI02);
                        return TRUE;
                    }
                    Read_FiscalData(ApplVar.FuncOnEnter-FUNC800);
                    ProgLine = 0;
                    ApplVar.FuncOnEnter = 0;
                    ClearEntry();
                    break;
                }
                return TRUE;
//cc for Fiscal>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#endif
            }

            switch ((WORD)ApplVar.NumberEntry)
            {
#if defined(CASE_ETHERNET)
            case 62479://����MAC��ַ
                ClearEntry();
                ClearLine2();
                ProgMAC();
                strcpy(ModeHead,DText[22]);
                PutsO(ModeHead);
                return TRUE;
#endif
            case 100://��ӡ��Ʒ��Ϣ
                if (ApplVar.AP.Plu.RandomSize)
                    i = ApplVar.AP.Plu.RNumber;
                else
                    i = ApplVar.AP.Plu.Number;
                if (i !=0 )
                {
                    StoreEJEnd();//ccr070609pm

                    SETBIT(ApplVar.PrintLayOut, BIT2);
                    RJPrint(0,MessageE6);
                    RESETBIT(ApplVar.PrintLayOut, BIT2);
                    RFeed(1);
                    memset(SysBuf,'=',PRTLEN);
                    SysBuf[PRTLEN] = 0;
                    RJPrint(0,SysBuf);
                    memset(SysBuf,' ',PRTLEN);
                    CopyFrStr(SysBuf,MessageE7);
                    CopyFrStr(SysBuf+16,MessageE8);
                    if (ApplVar.AP.Plu.RandomSize)
                        CopyFrStr(SysBuf+PRTLEN-10,MessageE9);
                    strcpy(SysBuf+PRTLEN-5,MessageE10);
                    RJPrint(0,SysBuf);
                    PrintLine2('=');
                    for (ApplVar.PluNumber = 0; ApplVar.PluNumber < i; ApplVar.PluNumber++)
                    {
                        ApplVar.Qty = ZERO;
                        ApplVar.Amt = ZERO;
                        ApplVar.Price = ZERO;
                        ReadPlu();
                        memcpy(&ApplVar.Price.Value,ApplVar.Plu.Price[0],5);
                        memcpy(&ApplVar.Amt,&ApplVar.Plu.Inventory,ApplVar.AP.Plu.InvSize);
                        ApplVar.Price.Sign = 2;

                        if (ApplVar.AP.Plu.RandomSize)
                        {
#if (BARCUSTOMER==1)
                            if (ApplVar.Plu.Random[6]==0x09 && ApplVar.Plu.Random[5]==0x99 && TESTBIT(ART_LEVEL, BIT3))
                                continue;
#endif
                            memcpy(ApplVar.Qty.Value,ApplVar.Plu.Random,ApplVar.AP.Plu.RandomSize);
                            RJPrint(0,FormatQtyStr(ApplVar.Plu.Name,&ApplVar.Qty,PRTLEN));
                            RJPrint(0,FormatStrQtyPriAmt((CONSTCHAR *)0,&ApplVar.Amt,(BCD *)0,&ApplVar.Price,PRTLEN));
                        }
                        else
                            RJPrint(0,FormatStrQtyPriAmt(ApplVar.Plu.Name,&ApplVar.Amt,(BCD *)0,&ApplVar.Price,PRTLEN));
                        if (KbHit())
                        {//any key for stop
                            Getch();
                            break;
                        }
                        FM_EJ_Exist();
                    }
                    ApplVar.BufKp = 0;
                    CutRPaper(2);RFeed(4);//ccr070612
                    SETBIT(ApplVar.MyFlags,PRNTRAI);
                }
                ClearEntry();
                ClearLine2();

                strcpy(ModeHead,DText[22]);
                PutsO(ModeHead);
                return TRUE;
#if (BARCUSTOMER==1)
            case 101:// ��ӡ�����Ա���������   //
                StoreEJEnd();//ccr070609pm
                PrintBARCustomer(0);// ��ӡ�����Ա�嵥  //
                CutRPaper(2);RFeed(4);//ccr070612

                ClearEntry();
                ClearLine2(); //
                return TRUE;
#endif
//ccr070530>>>>>>>>>>>>>>>>>>>>>
#if (DD_MMC)//��ѯ��ӡEJ�е��ĵ�
            case 200:// Reprint Invoice documents from EJ;
            case 201:// Reprint No Fiscal documents from EJ;
            case 202:// Reprint Z Closure documents from EJ;
            case 203:// Reprint FM report documents from EJ.
            case 204:// Reprint All of the types of documents from EJ.
                ApplVar.FuncOnEnter = FUNC200;
                memset((char *)&ApplVar.LogDefine,0,sizeof(ApplVar.LogDefine));
                ApplVar.LogDefine.Type = ApplVar.NumberEntry-200+REGICONT;
                if (ApplVar.NumberEntry>=202)
                    ApplVar.LogDefine.Type++;
                Appl_MaxEntry = 10;
                ClearEntry();
                ClearLine2();
                PutsO(Msg[RECNUMFR].str);
                return TRUE;
#endif
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
            case 300:
                ApplVar.FuncOnEnter = FUNC300;
                Appl_MaxEntry = 4;
                strcpy(ModeHead,DText[34]);
                PutsO(ModeHead);
                ClearEntry();
                ClearLine2(); //
                return TRUE;

            case 500:       //print graphics
                StoreEJEnd();//ccr070609pm

                for (i=1;i<=GRAPHICMAX;i++)
                {//�����Զ���ͼƬ
                    memset(SysBuf,' ',PRTLEN);

                    CopyFrStr(SysBuf,Prompt.TypeCap[SETGRAP-1]);

                    WORDtoASC(SysBuf+PRTLEN-5,i);

                    RJPrint(0,SysBuf);
                    Bios(BiosCmd_PrintGraph, (void*)(i), 1 , 0); //�����Դ�����
                }
                CutRPaper(2);RFeed(4);//ccr070612

                ClearEntry();
                ClearLine2(); //
                return TRUE;

/////////////////////////////////////////////////
            case 550:       //diale over modem
                ApplVar.PortNumber = COMPUTER_1;
                ReadPort();
                if (ApplVar.Port.Type=='3' && ApplVar.Port.Tele[0])
                    DialOverModem(ApplVar.Port.Tele);
                strcpy(ModeHead,DText[22]);
                ClearEntry();
                ClearLine2(); //
                return TRUE;
            case 551:       //diale over modem
                ApplVar.PortNumber = COMPUTER_1;
                ReadPort();
                if (ApplVar.Port.Type=='3')
                    HandDownModem();
                strcpy(ModeHead,DText[22]);
                ClearEntry();
                ClearLine2(); //
                return TRUE;

//;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
#if CC_DEBUG
#define TESTSIZE    124
#define TESTALIGN   1
            case 400://������չSRAM���Ķ�д����ReadRam/WriteRam
                for (RamOffSet=0;RamOffSet<ApplVar.SIZE_EXTRAM;)
                {
                    sVal = TESTSIZE;
                    if (ApplVar.SIZE_EXTRAM-RamOffSet<TESTSIZE)
                        sVal=ApplVar.SIZE_EXTRAM-RamOffSet;
                    ReadRam(SysBuf,sVal);RamOffSet-=sVal;
                    memset(MMC_Buff+TESTALIGN,0xaa,sVal);
                    WriteRam(MMC_Buff+TESTALIGN,sVal);RamOffSet-=sVal;
                    memset(MMC_Buff+TESTALIGN,0,sVal);
                    ReadRam(MMC_Buff+TESTALIGN,sVal);RamOffSet-=sVal;
                    WriteRam(SysBuf,sVal);RamOffSet-=sVal;
                    for (i=0;i<sVal;i++)
                    {
                        if (MMC_Buff[i+TESTALIGN]!=0xaa)
                            break;
                    }
                    if (i<sVal) break;
                    memset(MMC_Buff+TESTALIGN,0x55,sVal);
                    WriteRam(MMC_Buff+TESTALIGN,sVal);RamOffSet-=sVal;
                    memset(MMC_Buff+TESTALIGN,0,sVal);
                    ReadRam(MMC_Buff+TESTALIGN,sVal);RamOffSet-=sVal;
                    WriteRam(SysBuf,sVal);RamOffSet-=sVal;
                    for (i=0;i<sVal;i++)
                    {
                        if (MMC_Buff[i+TESTALIGN]!=0x55)
                            break;
                    }
                    if (i<sVal) break;
                    RamOffSet+=sVal;
                }

                memset(SysBuf,' ',PRTLEN+1);
                strcpy(SysBuf,MessageE27);
                j = strlen(SysBuf);
                if (i<sVal)
                {
                    RamOffSet+=i;
                    strcpy(SysBuf+j-5,MessageE26);
                    j = strlen(SysBuf);
                }

                HEXtoASC(SysBuf+j, (char *)&RamOffSet, 3);

                SysBuf[j+6] = 'H';
                SysBuf[j+7] = 0;
                RJPrint(0, SysBuf);
                PutsO(ModeHead);
                ClearEntry();
                ClearLine2(); //
                return true;
            case 401://DUMP RAM
#if defined(FISCAL)
            case 402://DUMP FM
#endif
#if (DD_MMC)
            case 403://DUMP EJ
#endif
                ApplVar.LogDefine.Type = ApplVar.NumberEntry-401;
                ApplVar.FuncOnEnter = FUNC401;
                Appl_MaxEntry = 12;
                if (ApplVar.NumberEntry==401)
                    strcpy(ModeHead,DText[35]);
                else
                    if (ApplVar.NumberEntry==402)
                    strcpy(ModeHead,MessageE51);
                else
                    strcpy(ModeHead,MessageE52);
                PutsO(ModeHead);
                ClearEntry();
                ClearLine2(); //
                return TRUE;
#if 0
            case 404:
                GetTimeDate(&Now);

                PutsO("Time=01:02:03");
                rtc_time.hh = 1;
                rtc_time.mm = 2;
                rtc_time.ss = 3;
                Bios_1(BiosCmd_SetTime);

                PutsO("Reset DateTime");
                SetTimeDate(&Now);

                PutsO(ModeHead);
                ClearEntry();
                ClearLine2(); //
                return TRUE;
#endif
//cc test 2005-12-29
#if (DD_MMC)
            case 700://     ��ʼ��MMC //
#if (!defined(DEBUGBYPC))
                Bios(BiosCmd_SD_Init, MMC_Buff,0,0);
                SysBuf[0] = SD_GetLastError();
                Bios(BiosCmd_SD_UnProtect, MMC_Buff,0,0);
                SysBuf[1] = SD_GetLastError();
                Bios(BiosCmd_SD_Erase, MMC_Buff,0,0);
                SysBuf[2] = SD_GetLastError();
                RJPrint(0,Msg[EJCSHUA].str);
                PrnBuffer(SysBuf,3);
#endif
                Bell(2);
                PutsO("Clean EJ.");

                RamOffSet = BLOCK0*SD_BLOCKSIZE;
                memset(SysBuf,0xff,sizeof(SysBuf));
                for (i=0;i<8;i++)     //���SD����ʼ4����.
                    WriteStream(SysBuf,sizeof(SysBuf),false);

                sAddr = ApplVar.MMCSIZEMAX;
                GetMMCSize();

                strcpy(SysBuf,MessageE53);

                HEXtoASC(SysBuf+13,(char*)(&ApplVar.MMCSIZEMAX),4);

                SysBuf[8+13]=0; RJPrint(0,SysBuf);

                ClearEntry();
                ClearLine2(); //

#if (!defined(DEBUGBYPC))
                ApplVar.MMCSIZEMAX = sAddr;
                ApplVar.INDEXSIZE=GETINDEXSIZE();
#endif
                return true;
            case 701://��д1��
            case 702://��д2��
            case 703://��д3��
            case 704://��д4��

                sVal = ApplVar.MMCSIZEMAX;
                GetMMCSize();

                keyno = 0x55;
                sDay = 0;
                setprint=(ApplVar.NumberEntry==704);// // Ϊ0ʱ, ��0��ַ��ʼ��д���� 2008-11-18 14:57:03//
                ApplVar.NumberEntry -= 700;
                for (sAddr = (ApplVar.MMCSIZEMAX-SD_BLOCKSIZE)*setprint;(sAddr<ApplVar.MMCSIZEMAX) && !KbHit();sAddr+=PCBUFMAX)
                {
                    FM_EJ_Exist();

                    if ((sAddr+PCBUFMAX)>(ApplVar.MMCSIZEMAX-PCBUFMAX))
                        sAddr = ApplVar.MMCSIZEMAX-PCBUFMAX;
                    HEXtoASC(SysBuf,(char*)(&sAddr),4);SysBuf[8]=0; PutsO(SysBuf);
                    for (j=0;j<ApplVar.NumberEntry & !ApplVar.ErrorNumber;j++)
                    {
                        RamOffSet = sAddr;
                        keyno = ~keyno;
                        sYear = (sAddr / PCBUFMAX)  & 0xff;//Ϊ����
                        for (i=0;i<PCBUFMAX/2;i++)
                        {
                            if (j<2)
                            {
                                PCBuffer[2*i] = i;
                                PCBuffer[2*i+1] = keyno;
                            }
                            else
                            {
                                PCBuffer[2*i+1] = i;
                                PCBuffer[2*i] = keyno;
                            }
                        }

                        WriteStream(PCBuffer,PCBUFMAX,false);
                        if (ApplVar.FisCardFlag != BADEJ)
                        {
                            memset(PCBuffer, 0x5a, PCBUFMAX);
                            i = ReadFromMMC( PCBuffer,sAddr, PCBUFMAX);
                            if (i)
                            {
                                if (j<2)
                                    for (i=0;i<PCBUFMAX/2;i++)
                                    {
                                        if (PCBuffer[2*i] != i || PCBuffer[2*i+1] != keyno)
                                        {
                                            SysBuf[1] = keyno;
                                            SysBuf[0] = i;
                                            PrnBuffer(SysBuf, 2);
                                            sDay = 2*i;
                                            sAddr += sDay;
                                            i=0;
                                            break;
                                        }
                                    }
                                else
                                    for (i=0;i<PCBUFMAX/2;i++)
                                    {
                                        if (PCBuffer[2*i+1] != i || PCBuffer[2*i] != keyno)
                                        {
                                            SysBuf[0] = keyno;
                                            SysBuf[1] = i;
                                            PrnBuffer(SysBuf, 2);
                                            sDay = 2*i;
                                            sAddr += sDay;
                                            i=0;
                                            break;
                                        }
                                    }
                            }
                            if (!i)
                            {
                                ApplVar.ErrorNumber=ERROR_ID(CWXXI82);
                                break;
                            }
                        }
                        else
                        {
                            ApplVar.ErrorNumber=ERROR_ID(CWXXI84);
                            break;
                        }
                    }
                    if (ApplVar.ErrorNumber)
                        break;
                    else if (setprint)
                    {
                        sAddr = 0;
                        setprint = 0;
                    }

                }
                if (ApplVar.ErrorNumber || sAddr<ApplVar.MMCSIZEMAX)
                {
                    memset(SysBuf,' ',PRTLEN);
                    strcpy(SysBuf,MessageE54);
                    HEXtoASC(SysBuf+13,(char*)(&sAddr),4);
                    i = 8+13;
                    SysBuf[i++]=':'; SysBuf[i++]='E'; SysBuf[i++]='r'; SysBuf[i++]='r';
                    SysBuf[i++]='=';
#if (!defined(DEBUGBYPC))
                    sYear = SD_GetLastError();
                    SysBuf[i++]=sYear /10 +'0';
                    SysBuf[i++]=sYear % 10 +'0';
#endif
                    SysBuf[i++]=0;
                    RJPrint(0,SysBuf);
                    PrnBuffer(&PCBuffer[sDay],PCBUFMAX-sDay);

                }
                else
                {
                    strcpy(SysBuf,MessageE53);
                    HEXtoASC(SysBuf+13,(char*)(&sAddr),4);
                    SysBuf[8+13]=0; RJPrint(0,SysBuf);
                }
                ClearEntry();
#if (!defined(DEBUGBYPC))
                ApplVar.MMCSIZEMAX = sVal;
                ApplVar.INDEXSIZE=GETINDEXSIZE();
#endif
                return true;

            case 705:
                i = Bios(BiosCmd_SD_ReadInfo, MMC_Buff,MMC_SEND_CID,16);
                if (i)
                    SendString(MMC_Buff,16);
                else
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI84);
                ClearEntry();
                ClearLine2(); //
                return true;

            case 706:
                i = Bios(BiosCmd_SD_ReadInfo, MMC_Buff,MMC_SEND_CSD,16);
                if (i)
                    SendString(MMC_Buff,16);
                else
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI84);

                ClearEntry();
                ClearLine2(); //
                return true;
            case 707:
                ApplVar.MMCLast = 0xffffffff;//ccr091206
                if (ReadFromMMC(SysBuf,EJHEADERADDR, sizeof(ApplVar.EJHeader)))
                {
                    PrnBuffer(SysBuf,sizeof(ApplVar.EJHeader));
                }
                ClearEntry();
                ClearLine2(); //
                return true;


#endif	// DD_MMC

#if (defined(FISCAL))
            case 710://����Fiscal Memory
                if (Bios_FM_CheckPresence())
                {
                    PutsO("Clean Fis.Memory");
                    FM_AllErase();
                    PutsO("Check Fis.Memory");
                    i=0;
                    for (sAddr=0;sAddr<FISMEMERYSIZE && !KbHit();sAddr+=sizeof(SysBuf))
                    {
                        memset(SysBuf, 0, sizeof(SysBuf));
                        i = Bios_FM_Read(SysBuf,sAddr, sizeof(SysBuf));
                        if (i)
                        {
                            for (i=0;i<sizeof(SysBuf);i++)
                            {
                                if (SysBuf[i] != 0xff)
                                {
                                    sAddr+=i;
                                    i=0;
                                    break;
                                }
                            }
                        }
                        if (!i)//Error
                            break;
                    }

                    if (!i)
                    {
                        RJPrint(0,"Erase Error at:");
                        PrnBuffer((char *)&sAddr,sizeof(sAddr));
                        PrnBuffer(&SysBuf[j],sizeof(SysBuf)-j);
                        ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
                    }
                    else
                        RJPrint(0,"Clear Fiscal Memory");
                }

                ClearEntry();
                Bell(2);
                return true;

            case 711://����Fiscal memory
                if (Bios_FM_CheckPresence())
                {
                    PutsO("Erase Fis.Memory");
                    FM_AllErase();
                    PutsO("Check Fis.Memory");
                    i=0;
                    for (sAddr=0;sAddr<FISMEMERYSIZE && !KbHit();sAddr+=sizeof(SysBuf))
                    {
                        //HEXtoASC(ProgLineMes,(char*)(&sAddr),4);ProgLineMes[8]=0;
                        //PutsO(ProgLineMes);

                        memset(SysBuf, 0, sizeof(SysBuf));
                        i = Bios_FM_Read(SysBuf,sAddr, sizeof(SysBuf));
                        if (i)
                        {
                            for (i=0;i<sizeof(SysBuf);i++)
                            {
                                if (SysBuf[i] != 0xff)
                                {
                                    sAddr+=i;
                                    i=0;
                                    break;
                                }
                            }
                        }
                        if (!i)//Error
                            break;
                    }

                    if (!i)
                    {
                        PutsO("FM Check Error");
                        RJPrint(0,"Erase Error at:");
                        PrnBuffer((char *)&sAddr,sizeof(sAddr));
                        PrnBuffer(&SysBuf[j],sizeof(SysBuf)-j);

                        ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
                        break;
                    }

                    for (sAddr=0;sAddr<FISMEMERYSIZE && !KbHit();sAddr+=sizeof(SysBuf))
                    {
                        //FM_EJ_Exist();
                        if ((sAddr & 0xffff)==0)
                        {
                            HEXtoASC(ProgLineMes,(char*)(&sAddr),4);ProgLineMes[8]=0;
                            PutsO(ProgLineMes);
                        }

                        memset(SysBuf, 0x55, sizeof(SysBuf));
                        i = Bios_FM_Write(sAddr,  SysBuf, sizeof(SysBuf));
                        if (i)
                        {
                            memset(SysBuf, 0, sizeof(SysBuf));
                            i = Bios_FM_Read(SysBuf,sAddr, sizeof(SysBuf));
                            if (i)
                            {
                                for (i=0;i<sizeof(SysBuf);i++)
                                {
                                    if (SysBuf[i] != 0x55)
                                    {
                                        sAddr+=i;
                                        j = i;
                                        i=0;
                                        break;
                                    }
                                }
                            }
                            if (!i)//Error
                                break;
                        }
                        else
                        {
                            Bios_FM_Read(SysBuf,sAddr, sizeof(SysBuf));
                            break;
                        }

                        memset(SysBuf, 0, sizeof(SysBuf));
                        i = Bios_FM_Write(sAddr,  SysBuf, sizeof(SysBuf));
                        if (i)
                        {
                            memset(SysBuf, 0, sizeof(SysBuf));
                            i = Bios_FM_Read(SysBuf,sAddr, sizeof(SysBuf));
                            if (i)
                            {
                                for (i=0;i<sizeof(SysBuf);i++)
                                {
                                    if (SysBuf[i] != 0)
                                    {
                                        sAddr+=i;
                                        j = i;
                                        i=0;
                                        break;
                                    }
                                }
                            }
                            if (!i)//Error
                                break;
                        }
                        else
                        {
                            Bios_FM_Read(SysBuf,sAddr, sizeof(SysBuf));
                            break;
                        }
                    }
                    if (!i)
                    {
                        RJPrint(0,MessageE56);
                        PrnBuffer((char *)&sAddr,sizeof(sAddr));
                        PrnBuffer(&SysBuf[j],sizeof(SysBuf)-j);

                        ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
                    }
                    else
                    {
                        strcpy(SysBuf,MessageE57);
                        HEXtoASC(SysBuf+13,(char*)(&sAddr),4);
                        SysBuf[8+13]=0; RJPrint(0,SysBuf);
                    }

                    PutsO("Erase Fis.Memory");
                    FM_AllErase();
                    PutsO("Check Fis.Memory");
                    i=0;
                    for (sAddr=0;sAddr<FISMEMERYSIZE && !KbHit();sAddr+=sizeof(SysBuf))
                    {
                        memset(SysBuf, 0, sizeof(SysBuf));
                        i = Bios_FM_Read(SysBuf,sAddr, sizeof(SysBuf));
                        if (i)
                        {
                            for (i=0;i<sizeof(SysBuf);i++)
                            {
                                if (SysBuf[i] != 0xff)
                                {
                                    sAddr+=i;
                                    i=0;
                                    break;
                                }
                            }
                        }
                        if (!i)//Error
                            break;
                    }

                    if (!i)
                    {
                        PutsO("FM Check Error");
                        RJPrint(0,"Erase Error at:");
                        PrnBuffer((char *)&sAddr,sizeof(sAddr));
                        PrnBuffer(&SysBuf[j],sizeof(SysBuf)-j);

                        ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
                    }
                    else
                        PutsO("FM Check Ready");

                    if (KbHit()) Getch();
                }
                ClearEntry();
                ClearLine2(); //
                return true;
#endif//FISCAL
#endif//CC_DEBUG
#if defined(FISCAL)
//    cc for Fiscal>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            case 800://FUNC800,˰�س�ʼ��
                CheckFiscal(false);
                if (ApplVar.FisCardFlag == FMISNEW)  /* new card */
                {
/*ccr2014-PANAMA-TRAIN
                    if (TESTBIT(ApplVar.MyFlags,ZREPORT))   //z report taken ?
                    {
                        ApplVar.ErrorNumber=ERROR_ID(CWXXI75);
                        ApplVar.FuncOnEnter = 0; //liuj 0528
                        return TRUE;
                    }
*/
                    ApplVar.FuncOnEnter = FUNC800;
                    ApplVar.FiscalDefine.idx = 0;
                    Initial_Fiscal(true);
                }
                else
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI79);     /* already initialied */

                return TRUE;
//hf end <<<<<<<<<<<<<<<<<<<<<<<<<<<
            case 801:
                //20070302 if(ApplVar.FisCardFlag != FISOK)	/* new card */
                if (CheckInFiscalMode())
                {
                    Read_FiscalData(ApplVar.NumberEntry-801);
                }
                else
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI81);
                }
                //Getch();
                ClearEntry();
                return TRUE;
            case 802:
                //20070302 if(ApplVar.FisCardFlag != FISOK)	/* new card */
                if (CheckInFiscalMode())
                {
                    ApplVar.LogDefine.idx = 0;
                    ApplVar.FuncOnEnter = FUNC802;
                    memset((char *)&ApplVar.FiscalDefine,0,sizeof(ApplVar.FiscalDefine));
                    Appl_MaxEntry = 5;
                    ClearEntry();
                    ClearLine2();
                    PutsO(Msg[RECNUMFR].str);
                }
                else
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI81);
                }
                return TRUE;
            case 803:
            case 804:
                //20070302 if(ApplVar.FisCardFlag != FISOK)	/* new card */
                if (CheckInFiscalMode())
                {
                    ApplVar.FuncOnEnter = FUNC803 + (ApplVar.NumberEntry-803);
                    memset((char *)&ApplVar.FiscalDefine,0,sizeof(ApplVar.FiscalDefine));
                    Appl_MaxEntry = 8;

                    /*sAddr= (((UnLong)Now.year)<<16) + 	//YY
                                    ((UnLong)Now.month<<8) +		//MM
                                    ((UnLong)Now.day); 		//DD*/
                    DateForDisplay(0);


#if(DD_ZIP==1)
                    PutsO(Prompt.LineCap[Line_DATEFR]);
                    Puts1(SysBuf);
#elif(DD_ZIP_21==1)
                    PutsO(Prompt.LineCap[Line_DATEFR]);
                    Puts1(SysBuf);
    //						PutsC(SysBuf+4);
#elif(DD_LCD_1601)
                    memset(ProgLineMes,' ',DISLEN);
                    CopyFrStr(ProgLineMes,Prompt.LineCap[Line_DATEFR]);
                    strcpy(ProgLineMes+DISLEN-8,SysBuf+DISLEN-8);
                    PutsO(ProgLineMes);
#else
                    PutsO(Prompt.LineCap[Line_DATEFR]);
#endif
                    ClearEntry();
                }
                else
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI81);
                }
                return TRUE;
#endif
            case 810://��ӡ������˰����Ϣ
#if(DD_MMC==1)
                StoreEJEnd();//ccr070609pm
                ApplVar.EJContent = TXTCONT;
                SETBIT(ApplVar.ContFlag, (ENSTORE|ENHEADER));
#endif
                AddReceiptNumber();
                PrintMemoForFiscal();
                i = ApplVar.FReceipt;
                ApplVar.FReceipt = 1;
                ReceiptIssue(1+BIT1);//ccr070609pm
                ApplVar.FReceipt = i;
                RFeed(1);

                ClearEntry();
                return TRUE;
//    cc 2006-07-04 for MMC>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

#if(DD_MMC==1 && defined(FISCAL))
            case 900:
                Initial_EJ();//ccr091125
                return true;
            case 950://��ӡEJ��Ϣ
                if (CheckInFiscalMode())
                {
                    StoreEJEnd();//ccr070609pm
                    ApplVar.EJContent = TXTCONT;
                    SETBIT(ApplVar.ContFlag, (ENSTORE|ENHEADER));
                    Print_NonFiscal();

                    AddReceiptNumber();
                    PrintEJInfo();
                    RFeed(1);
                    i = ApplVar.FReceipt;
                    ApplVar.FReceipt = 1;
                    ReceiptIssue(1+BIT1);//ccr070609pm
                    ApplVar.FReceipt = i;
                    RFeed(1);
                }
                return true;
#endif
//cc 2006-07-04 for MMC>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
//<<<<<<<<<<<<<CCR070609pmEND here>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
//cc test 2005-12-29
#if (DD_CHIPC==1)//ccr050316
            case 600:                   //print message of te chipcard
#if (CASE_MFRIC==1)
                ChipCard();
                if (IC.CHIP_Flag>=0)
                {
                    if (ApplVar.ErrorNumber)
                        CheckError(0);
                    else
                    {
                        StoreEJEnd();
                        PrintChipCard(2);
                        CutRPaper(2);RFeed(4);//ccr070612
                    }
                }
                CC_Close();
                RESETBIT(IC.ICState,IC_INSERT | IC_NOTREMOVED);
#else
                if (IC.CHIP_Flag>=0)
                {
                    RESETBIT(IC.ICState,IC_INSERT | IC_NOTREMOVED);
                    ChipCard();
                    if (ApplVar.ErrorNumber)
                        CheckError(0);
                    else
                    {
                        StoreEJEnd();
                        PrintChipCard(2);
                        CutRPaper(2);RFeed(4);//ccr070612
                    }
                }
#endif
                return TRUE;
#endif
#if (!defined(FISCAL))//ccr070610
            case 3:

#if(DD_ZIP==1 || DD_ZIP_21==1)
                PutsO(MessageE58);
                Puts1(DMes[24]);
                //    TODO PutsC(DMes[24]);
#else
                PutsO(DMes[24]);//confirm
#endif
                while (!KbHit())  FM_EJ_Exist();
                if (Getch() == ApplVar.AP.FirmKeys[ID_PRGENTER])  /* CR is accept */
                    ClearAllReport();
                strcpy(ModeHead,DText[22]);
                ClearEntry();
                ClearLine2(); //
                return TRUE;
#endif
            case 4:
                ApplVar.CentralLock = 0x100 + X;
                ModeHead[0]=DText[20][0];//'X';
                break;
            case 5:
                ApplVar.CentralLock = 0x100+Z;
                ModeHead[0]=DText[21][0];//'Z';
                break;
            case 1:
                ApplVar.CentralLock = 0x100 + SET;
                ModeHead[0]=DText[22][0];//'S';
                break;
            case 2:
                ApplVar.CentralLock = 0x100 + MG;
                ModeHead[0]=DText[23][0];//'M';
                break;

            case 7://��������
                if (pbNumber>10)
                {
                    PutsO(DMes[24]);//confirm

                    while (!KbHit())   FM_EJ_Exist();
                    if (Getch() == ApplVar.AP.FirmKeys[ID_PRGENTER])  /*    CR is accept     */
                    {
                        memcpy((void*)&ApplVar.AP.KeyTable,(void*)&KeyTablePBF,sizeof(KeyTablePBF));
                        PutsO(DText[30]);
                        RESETBIT(ApplVar.MyFlags, PRNONPB);// |
                        SETBIT(ApplVar.MyFlags,CONFIGECR);

                    }
                }
                ClearEntry();
                ClearLine2(); //
                return TRUE;

            case 8://���м���
                PutsO(DMes[24]);//confirm
                while (!KbHit())  FM_EJ_Exist();

                if (Getch() == ApplVar.AP.FirmKeys[ID_PRGENTER])  /* CR is accept */
                {
                    memcpy((void*)&ApplVar.AP.KeyTable,(void*)&Default.KeyTable,sizeof(Default.KeyTable));//???????????
                    PutsO(DText[29]);
                    RESETBIT(ApplVar.MyFlags, PRNONPB);// |
                }
                ClearEntry();
                ClearLine2(); //
                return TRUE;
            default:
                if (Appl_EntryCounter)
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI32);     //illegle input
                else
                    PutsO(ModeHead);
                return 0;
            }
            Appl_MaxEntry = MAXPWD-2;
            strcpy(ModeHead+1,DText[25]);
            DispForPwd(ModeHead);
            ClearEntry();
            ClearLine2(); //
            return TRUE;
        }
        else
        {
            keyno = ApplVar.CentralLock >> 8;
            if (keyno)//verify password
            {
                switch (keyno)
                {
                case (PWDFOR>>8)://verify password if needed
                    strcpy(PwdInput,EntryBuffer + sizeof(EntryBuffer) - Appl_EntryCounter - 1);
                    if (CheckPassword())
                    {
                        ApplVar.CentralLock &= 0xff;

                        switch (ApplVar.CentralLock)
                        {
                        case X:
                            keyno = X;
                            Appl_MaxEntry = 2;
                            strcpy(ModeHead,DText[20]);
                            break;
                        case Z:
                            keyno = Z;
                            Appl_MaxEntry = 2;
                            strcpy(ModeHead,DText[21]);
                            break;
                        case SET:
                            keyno = SET;
                            Appl_MaxEntry = 5;
                            strcpy(ModeHead,DText[22]);
                            break;
                        case MG:
                            keyno = MG;
                            Appl_MaxEntry = PRTLEN*2;
                            strcpy(ModeHead,DText[23]);
                            break;
                        }
#if (DD_MMC)//ccr070609pm>>>>>>>>>>>>>
                        if (!TESTBIT(ApplVar.ContFlag,PRNRGHEAD) && (ApplVar.CentralLock == MG || ApplVar.CentralLock == RG))//ccr070609pm
                        {
                            ApplVar.FReceipt = 1;
                            ReceiptIssue(1+BIT2);       //ccr070609pm
                        }
#endif	//<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                        PutsO(ModeHead);
                        ClearEntry();
                        ClearLine2(); //
                        return keyno;
                    }
                    else
                    {//��������ʱ��ǿ�ƽ���Ӫҵ��   //
                        RESETBIT(ApplVar.MyFlags,PWDMODE);
                        keyno = RG;
                        ApplVar.CentralLock = RG;
                        strcpy(ModeHead,DText[19]);
                        Appl_MaxEntry = sizeof(EntryBuffer)-2;
                        ClearEntry();
                        ClearLine2(); //
                        PutsO(DMes[18]);
                        return keyno;
                    }
                    break;
/*				case 1://verify the old password first
                    strcpy(PwdInput,EntryBuffer + sizeof(EntryBuffer) - Appl_EntryCounter - 1);
                    if (CheckPassword())
                    {
                        ApplVar.CentralLock += 0x100;
                        strcpy(ModeHead+1,DText[25]);
                        DispForPwd(ModeHead);
                    }
                    else
                        PutsO(DMes[18]);
                    break;*/
                case 1://confirm password
                    strcpy(PwdInput,EntryBuffer + sizeof(EntryBuffer) - Appl_EntryCounter - 1);
                    ApplVar.CentralLock += 0x100;
                    strcpy(ModeHead+1,DText[26]);
                    DispForPwd(ModeHead);
                    break;
                case 2://replace password
                    if (strcmp(PwdInput,EntryBuffer + sizeof(EntryBuffer) - Appl_EntryCounter - 1))
                    {
                        PutsO(DMes[18]);
#if(DD_ZIP==1 || DD_ZIP_21==1)
                        Puts1(Msg[SPACE].str);  //
                        //    TODO PutsC(Msg[SPACE].str);	//
#endif
                        ApplVar.CentralLock = (ApplVar.CentralLock & 0xff) + 0x100;
                    }
                    else//replace password
                    {
                        ApplVar.CentralLock &= 0xff;
                        switch (ApplVar.CentralLock)
                        {
                        case X:
                            strncpy(ApplVar.AP.ModePwd.PwdX,PwdInput,MAXPWD-1);
                            Appl_MaxEntry = 2;
                            break;
                        case Z:
                            strncpy(ApplVar.AP.ModePwd.PwdZ,PwdInput,MAXPWD-1);
                            Appl_MaxEntry = 2;
                            break;
                        case SET:
                            strncpy(ApplVar.AP.ModePwd.PwdSET,PwdInput,MAXPWD-1);
                            Appl_MaxEntry = 5;
                            break;
                        case MG:
                            Appl_MaxEntry = PRTLEN*2;
                            strncpy(ApplVar.AP.ModePwd.PwdMG,PwdInput,MAXPWD-1);
                            break;
                        }
                        ApplVar.CentralLock = SET;
                        strcpy(ModeHead,DText[22]);
#if(DD_ZIP==1 || DD_ZIP_21==1)
                        strcpy(ProgLineMes,ModeHead);

                        Puts1(DMes[19]);
                        //    TODO PutsC(DMes[19]);
#else
                        PutsO(DMes[19]);//display "Accepted"
#endif
                    }
                    break;
                default:
                    return 0;
                }
                ClearEntry();
                //			ClearLine2();	//
                return TRUE;
            }
            else
                return 0;
        }
    case ID_LOCK:       //change mode

        ApplVar.FuncOnEnter = 0;
        setprint =0;//liuj 0606
#if defined(FISCAL)
        ProcessTax(false);
        ProcessHead(true);
#endif
        if (ApplVar.CentralLock == SET && ProgLine>0 || TESTBIT(ApplVar.MyFlags,PWDMODE))
        {// ������ʱ���������ʱ����ֹģʽ�л�  //
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            return 0;
        }

        if (Appl_EntryCounter)
        {
            StrToBCDValue(ApplVar.Entry.Value, &EntryBuffer[sizeof(EntryBuffer) - 2], BCDLEN);
            GetWordEntry();
        }
        else
            ApplVar.NumberEntry = 0;
        //ccr2017-02-23>>>>���л���Ӫҵ��ʱ,���������������еĴ���
        if (ApplVar.FRegi && ApplVar.NumberEntry!=1)// || (ApplVar.PB.Block || ApplVar.FProforma))//ccr091127
        {//on the saling mode,can't chang the mode
            ApplVar.ErrorNumber=ERROR_ID(CWXXI14);
            return 0;
        }
        if (ApplVar.CentralLock==MG && ApplVar.FInv)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI47);
            return 0;
        }

        {//select new mode first

#if DD_MMC==0
            if (ApplVar.CentralLock == SET && ApplVar.NumberEntry != 3 && TESTBIT(ApplVar.MyFlags,PRNTRAI))
            {
                i = 0;
                if (!ApplVar.FReceipt)
                {
                    i=1;
                    ApplVar.FReceipt = 1;
                }
                ReceiptIssue(1);
                RESETBIT(ApplVar.MyFlags,PRNTRAI);
                if (i)
                    ApplVar.FReceipt = 0;

            }
#endif
#if defined(FISCAL)	//liuj 0529
            if (ApplVar.FisCardFlag != FISCALOK && ApplVar.FisCardFlag != FMLESS && ApplVar.FisCardFlag != EJLESS)  // liuj 0728
            {
                CheckFisError();    //liuj 0611
                ApplVar.NumberEntry = 4;
            }

#elif DD_MMC == 1  // liuj 0813
            if (ApplVar.FisCardFlag == MUSTINITEJ)  // liuj 0728
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI97);
                ApplVar.NumberEntry = 4;
            }
#endif

            PwdInput[0]=0;

            switch (ApplVar.NumberEntry)
            {
            case 0:
                if (Appl_EntryCounter>0 )
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                    return 0;
                }
                SuspendECR();
                keyno = 0;
                return 1;
            case 1:
                if (ApplVar.CentralLock == RG)//ccr070608
                    setprint = 1;

                keyno = RG;
                ApplVar.CentralLock = RG;

                strcpy(ModeHead,DText[1+18]);
                if (ApplVar.AP.KeyTable[MAXKEYB-1]==0xffff)     //lyq added 2003\11\1 start
                {//������ʽ�£�ʹ��Сд��ĸ��ʾӪҵģʽ
                    for (i=strlen(ModeHead)-1;i>0;i--)
                        ModeHead[i] |= 0x20;
                }                                      //lyq added 2003\11\1 end
                RESETBIT(ApplVar.MyFlags,PWDMODE);
                SetInputMode(0);
                PutsO(ModeHead);

                Appl_MaxEntry = sizeof(EntryBuffer)-2;
                if (TESTBIT(CLERKFIX, BIT0))    /* clerk compulsory or secret, no key */
                    ApplVar.ClerkNumber = 0;
                if (TESTBIT(KEYTONE, BIT6))
                {
                    ApplVar.SalPerNumber = 0;
                }
                Save_ConfigVar(false);

                break;
            case 5:
                keyno = MG;

                SetInputMode(0);

                strcpy(ModeHead,DText[5+18]);
                ApplVar.CentralLock = MG;
                if (CheckPassword())
                {
                    PutsO(DText[5+18]);
                    Appl_MaxEntry = PRTLEN*2;
                }
                else
                {
                    Appl_MaxEntry = MAXPWD-2;
                    ModeHead[0]=DText[23][0];//'M';
                    ApplVar.CentralLock |= PWDFOR;
                    strcpy(ModeHead+1,DText[24]);
                    DispForPwd(ModeHead);
                }
                if (TESTBIT(CLERKFIX, BIT0))    /* clerk compulsory or secret, no key */
                    ApplVar.ClerkNumber = 0;
                if (TESTBIT(KEYTONE, BIT6))
                {
                    ApplVar.SalPerNumber = 0;
                }

                Appl_MaxEntry = sizeof(EntryBuffer)-2;
                RESETBIT(ApplVar.MyFlags,PWDMODE);
                break;
            case 2:
                keyno = X;
                ApplVar.CentralLock = X;
                SetInputMode(0);

                ApplVar.ReportNumber = 0;
                if (CheckPassword())
                {
                    strcpy(ModeHead,DText[2+18]);//ccr20131120
                    PutsO(ModeHead);//ccr20131120
                    Appl_MaxEntry = 2;
                }
                else
                {
                    Appl_MaxEntry = MAXPWD-2;
                    ApplVar.CentralLock |= PWDFOR;
                    ModeHead[0] = DText[20][0];//'X';
                    strcpy(ModeHead+1,DText[24]);
                    DispForPwd(ModeHead);//display "XPD"
                }
#if(DD_ZIP==1 || DD_ZIP_21==1)
                strcpy(ProgLineMes,ModeHead);
#endif
                RESETBIT(ApplVar.MyFlags,PWDMODE);
                break;
            case 3:
#if defined(FISCAL)    //ccr091127>>>>>>>>>>>>>>>
#if (0)
                for (i=1; i <= ApplVar.AP.Pb.NumberOfPb; i++)
                {
                    PbTotal(i, 0);
                    if (ApplVar.PB.Block)
                    {// �й������̨ʱ,ǿ�ƴ�ӡZ��������������й������̨������   //

                        memset(SysBuf,' ',DISLEN);
                        WORDtoASCZero(SysBuf+4, i);
                        SysBuf[1]='T';
                        strcpy(SysBuf+6,SERVING);
                        PutsO(SysBuf+1);

                        while (1)
                        {
                            if (!KbHit())
                                continue;
                            i =Getch();
                            if (i==ApplVar.AP.FirmKeys[ID_CLEAR])
                            {
                                PutsO(ModeHead);
                                ApplVar.ErrorNumber=ERROR_ID(CWXXI14);
                                return 0;
                            }
                            if (i==ApplVar.AP.FirmKeys[ID_PRGENTER])
                            {
                                ApplVar.ZReport = 1;// ���ι���ǿ�ƴ�ӡZ���� //
                                break;
                            }
                        }
                    }
                }
#endif
                RESETBIT(ApplVar.Fiscal_PrintFlag,BIT2);    //cc 20070524
#endif     //<<<<<<<<<<<<<<<<<<<<<
                SetInputMode(0);

                keyno = Z;
                ApplVar.CentralLock = Z;

                ApplVar.ReportNumber = 0;
                strcpy(ModeHead,DText[3+18]);
                if (CheckPassword())
                {
                    PutsO(DText[3+18]);
                    Appl_MaxEntry = 2;
                }
                else
                {
                    Appl_MaxEntry = MAXPWD-2;
                    ApplVar.CentralLock |= PWDFOR;
                    ModeHead[0] =DText[21][0];// 'Z';
                    strcpy(ModeHead+1,DText[24]);
                    DispForPwd(ModeHead);
                }
#if(DD_ZIP==1 || DD_ZIP_21==1)
                strcpy(ProgLineMes,ModeHead);
#endif
                RESETBIT(ApplVar.MyFlags,PWDMODE);
                break;
            case 4:
//					if (ApplVar.AP.KeyTable[MAXKEYB-1]==0xffff)
                for (i=1; i <= ApplVar.AP.Pb.NumberOfPb; i++)
                {
                    PbTotal(i, 0);
                    if (ApplVar.PB.Block)
                    {// �й������̨ʱ,��ֹ����SET   //
                        ApplVar.ErrorNumber=ERROR_ID(CWXXI14);
                        return 0;
                    }
                }
//liuj 0523 debug
/*
                    ApplVar.EJContent = TXTCONT;
                    SETBIT(ApplVar.ContFlag, (ENSTORE|ENHEADER));
*/
#if DD_CHIPC
                RESETBIT(IC.ICState,IC_INSERT);//ccr040809
#endif
                keyno = SET;
                ApplVar.CentralLock = SET;
                SetInputMode('9');

                if (CheckPassword())
                {
                    strcpy(ModeHead,DText[4+18]);
                    PutsO(ModeHead);
                    Appl_MaxEntry = 5;
                }
                else
                {
                    ApplVar.CentralLock |= PWDFOR;
                    ModeHead[0]=DText[22][0];//'S';
                    Appl_MaxEntry = MAXPWD-2;
                    strcpy(ModeHead+1,DText[24]);
                    DispForPwd(ModeHead);
                }
                RESETBIT(ApplVar.MyFlags,PWDMODE);
                break;
            default:
                if (Appl_EntryCounter)
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI32);     //illegle input
                return 0;
            }
// liuj 0603
#if DD_MMC == 1
//ccr070609pm			if((ApplVar.NumberEntry == 1 ||ApplVar.NumberEntry == 5 /*||ApplVar.NumberEntry == 2 ||ApplVar.NumberEntry == 3*/) && !setprint )//ccr070609pm
            if (!TESTBIT(ApplVar.ContFlag,PRNRGHEAD) && !(ApplVar.CentralLock & PWDFOR) && (ApplVar.CentralLock == MG || ApplVar.CentralLock == RG))//ccr070609pm
            {
                ApplVar.FReceipt = 1;
                ReceiptIssue(1+BIT2);       //ccr070609pm
            }
#endif
//liuj 0603
            ClearEntry();
#if (DD_ZIP || DD_ZIP_21)//ccr20131120>>>>>>>>>
            if (ApplVar.CentralLock==RG || ApplVar.CentralLock==MG)
                Puts1(EntryBuffer + sizeof(EntryBuffer) - DISLEN - 1);
            else
                Puts1(SELECTMESS);
#endif//<<<<<<<<<<<<<<<<
            //�л�����ģʽ������ڶ���
            return keyno;
        }
    default:
        return 0;
    }
}
#endif

//Suspend ECR if user press MODELOCK,Resume ECR until user press MODELOCK
void SuspendECR()
{
#if (!defined(DEBUGBYPC) && DD_FISPRINTER==0)

    BYTE keyno,Befl;

    Bios_1(BiosCmd_BuzzS);

    LCDClose();

    PutsO_Only(MessageE59);

    do
    {
        Bios_1(BiosCmd_AutoClickOff);
        while (!KbHit()) FM_EJ_Exist();
        keyno = Getch();
#if !defined(DEBUGBYPC)
        /*������״̬��,������˳���,��ر�GPIOA,����ʹ��JLINK���س���*/
        if (keyno==Default.FirmKeys[ID_CANCEL])
        {
            Save_ApplRam();
            PutsO_Only("For JLINK!");//
            GPIO_DeInit(GPIOA);
            while(1){};
        }
#endif
    } while (keyno != ApplVar.AP.FirmKeys[ID_LOCK]);

    if (!TESTBIT(KEYTONE,BIT0))
        Bios_1(BiosCmd_AutoClickOn);

    PutsO_Saved();
    Bios_1(BiosCmd_BuzzS);
    LCDOpen();

#endif
}

//////////////////////////////////////////////////////////////////////////
