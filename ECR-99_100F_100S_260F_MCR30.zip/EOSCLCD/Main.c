#define  MAIN_C 4

// =============================================================
// Riferimenti esterni
// =============================================================

#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
#include "fiscal.h"
#include "ejournal.h"
#include "message.h"
#if (CASE_MFRIC==1)
    #include "MFRCard.h"
#endif

#if defined(CASE_ETHERNET)
#if defined(DEBUGBYPC)
#define LwIP_Periodic_Handle(localtime) {}
#else
void Set_ETHERNET_Ready(BYTE  );//ccr2015-01-22
void LwIP_Periodic_Handle(__IO uint32_t localtime);
#endif
#endif

#if (defined(CASE_GPRS))
#include "Gprs.h"
#endif

//VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV

#if !defined(DEBUGBYPC)

//#include "monitor.h"

/*********************************************************************************************************
  �궨��
*********************************************************************************************************/

extern volatile BYTE keyget_flag;
/*********************************************************************************************************
  ����ȫ�ֱ���
*********************************************************************************************************/
#endif

//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//     ===========================================================
//     Funzioni definite in questo file
//     ===========================================================

void OutPrint(WORD Cmd, CONSTBYTE *Line); //    Lancia stampa (standard)
void OutPrintEx(WORD Cmd, CONSTCHAR *Line, WORD DotLinesBlank);   //    Lancia stampa (comando generico)

extern BYTE Display_RGBuf(int UpDown);

void ProcessKey(void);
WORD KeyInput(void);

short   KbHit(void);
BYTE   Getch(void);

BYTE CheckPrinter(void);

void CheckICCard(void);


#if DD_MMC == 1
extern void StoreEJStart(void);
extern void StoreLogData(BYTE cmd, CONSTBYTE *str);
//extern BYTE testonly_BADEJ;
#endif

#if (PC_EMUKEY==1)
    #include "FEcrTest.h"
#endif

// =============================================================
// Variabili globali
// =============================================================

BYTE CheckFiscalMust;//ccr100612

extern void CheckEJ(void);

extern BYTE KEY_MASK;
extern BYTE CurCode;
extern CONST BYTE TABKEY[KEY_MAXKEYS];


BYTE    KeyFrHost=0;       //ApplVar.Key code from host computer.
BYTE Bios_Key0_Key;         //    key number: 00 = No key

#if defined(DEBUGBYPC)
BYTE LoopInput=0;
#endif

//Main program>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

void CheckBattery()
{
// liuj 0803
    if (Bios_1(BiosCmd_CheckBattery)!=1)//Low Battery
    {

        PutsO((char*)Msg[LOWBAT].str);
        Bell(0);
        while (!KbHit() || Getch()!=ApplVar.AP.FirmKeys[ID_CLEAR]) FM_EJ_Exist();
    }

}

/*********************************************************************************************************
** Function name:       mainTask
** Descriptions:        ������
** input parameters:    pvData: û��ʹ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
#if !defined(DEBUGBYPC)
void mainTask(void *pvData)
#else
void main_pc()
#endif
{
    ULONG     i;

#if defined(DEBUGBYPC)
    if (LoopInput)
        return;

#else// DEBUGBYPC==0

    while (KbHit()) Getch();//20130728 �������Զ��а���,���֮

    InitApplication();     /* Initialise application program */
/****************************************************************************/
#if defined(CASE_ETHERNET)
    //Ethernet_Start() �����������տ����IP��ַ�Ȳ���,��˱�����õ�InitApplicationִ��
	Ethernet_Start();
    if (CLONG(MAC_ADDR[0])==0xffffffff)
        PutsO("NO MAC Address!");
#endif

    while (1)         /* Exit loop only with power fail */
#endif
    {
        ApplRamSaved = 0x5a;//Appl Ram δ����

        ApplVar_Restored = 0x5a;

#if defined(CASE_GPRS)
        GPRSWaitForReady(false);
#endif

//ccr091125>>>>>>>>>>>>>>>>>

#if (defined(FISCAL) && DD_MMC && DD_FISPRINTER==0)
        //��⵽��EJ��,ֱ����ʾ��ʼ����EJ��.
        if (ApplVar.FisCardFlag==MUSTINITEJ && ApplVar.CentralLock != SET)
        {
            //testonly_BADEJ = 0;
            PutsO(INITEJPROMPT);
            do {
                FM_EJ_Exist();
                if (KbHit())
                {
                    i =Getch();
                    if (i==ApplVar.AP.FirmKeys[ID_CLEAR])
                        break;
                    if (i==ApplVar.AP.FirmKeys[ID_PRGENTER])
                    {
                        Initial_EJ();
                        CheckError(0);
                    }
                }
            } while (ApplVar.FisCardFlag==MUSTINITEJ && !ApplVar.FTrain);//��ѵ״̬��,��ִֹ��EJ��ʼ������
            ClearEntry();
            PutsO(ModeHead);
#if (DD_ZIP_21 || DD_ZIP)
            Puts1(Msg[SPACE].str);
#endif
            ApplVar.ErrorNumber = 0;
            CheckFisError();
        }
#endif
//<<<<<<<<<<<<<<<<<<<<<<<<<<<
#if PC_EMUKEY
        FisTestProc();
#endif


#if (DD_CHIPC==1)
        CheckICCard();//ccr050316
#endif
        while (Computer())//communicate with computer
            ProcessRecord();
#if DD_FISPRINTER == 0
#if !defined(DEBUGBYPC)


#if POWERCTRL
        if (!DC_DET_GET() && ApplVar.PoolPushIn==ApplVar.PoolPopOut)
        {
            mDrawPower(1);
            pwrGetStatus(GET_VIN_STATUS);
            if (BATTERYTooLow(PWR_WARNING2 | PWR_BY_BAT))
            {
                while (BatteryVoltage()<VIN_LOW && !DC_DET_GET())
                {
                    Bell(1);
        #if (DD_ZIP || DD_ZIP_21)
                    Puts1_Right(MessageM95);
        #else
                    PutsO(MessageM95);
        #endif
                    Delay(500);
                    pwrGetStatus(GET_VIN_STATUS);
                }
                if (BATTERYTooLow(PWR_BY_BAT | PWR_WARNING1))
                    ApplVar.ErrorNumber = ERROR_ID(CWXXI95);
            }
        }
#endif


        if ((BarCode() || KeyInput() || BalanceWeight(0)))//ccr050331 get from keyboard or Bar reader
#else
        if (KeyInput())
#endif
        {
            ProcessKey();
        }
        else
        {
            CheckTime(0);            /* display time after 5 minutes */
            CheckPrinter();
        }
#else
        ProcessButton();

        CheckPrinter();
#endif//DD_FISPRINTER


#if defined(FISCAL)
        if (TESTBIT(ApplVar.Fiscal_PrintFlag,BIT7))
            PrintAgain();

        FM_EJ_Exist();
#if DD_MMC == 1
        if (ApplVar.FisCardFlag == NOEJ || ApplVar.FisCardFlag==FM_X_EJ)
        {
            ApplVar.FisCardFlag=FISCALOK;
            CheckEJ();

            if (ApplVar.FisCardFlag==FISCALOK)
                ApplVar.ErrorNumber=0;
            else if (ApplVar.FisCardFlag!=NOEJ && ApplVar.FisCardFlag!=MUSTINITEJ) //ccr090115 It is must the same EJ
                ApplVar.FisCardFlag=FM_X_EJ;
            CheckFisError();
        }
#endif
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#elif DD_MMC == 1 // liuj 0813
        if (!MMC_CheckPresence())
        {
            ApplVar.FisCardFlag = NOEJ;     // no EJ //
            ApplVar.ErrorNumber=ERROR_ID(CWXXI83);
            while (1)
            {//ccr20140617 block the ECR
                CheckError(0); // while (!MMC_CheckPresence());
            }
        }
        else if (ApplVar.FisCardFlag == NOEJ)    //ccr090121
        {
            if (!Bios(BiosCmd_SD_ReadInfo, ProgLineMes, MMC_SEND_CID,16))
            {
                ApplVar.FisCardFlag = BADEJ;// EJ is damaged,can't write and read //
            }

            for (i = 0; i < 16; i++)
            {
                if (ProgLineMes[i] != ApplVar.EJNo[i])
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI98);
                    ApplVar.FisCardFlag = FM_X_EJ ;
                    break;
                }
            }

        }

#endif

//ccr070723>>>>>>>>>>>>
#if ((DD_FISPRINTER==0) && defined(FISCAL))
        if (ApplVar.ErrorNumber== ERROR_ID(CWXXI75) && ApplVar.CentralLock!=SET)       /* first take fiscal Z-ApplVar.Report */
        {
            //ApplVar.ErrorNumber=0;
            Appl_MaxEntry = 4;
            ClearEntry();
            ApplVar.CentralLock = Z;
            strcpy(ModeHead,DText[21]);
            PutsO(ModeHead);
            ClearLine2();
        }
#endif
//<<<<<<<<<<<<<<<<<<<<

//ccr090202>>>>>>>>>>>>
#if(DD_MMC)
        if (!ApplVar.FRegi && !ApplVar.ErrorNumber &&
            ApplVar.FisCardFlag != FMFULL && ApplVar.FisCardFlag != MUSTINITEJ && ApplVar.FisCardFlag != EJFULL &&
            ApplVar.EJLogHeader.NextNP >= INDEXADDR-MMC_FULL)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI88);             // 5 KB left, only warn once
            ApplVar.FisCardFlag = EJFULL;
//            while (1)
//            {//ccr20140617 block the ECR
//                CheckError(0);
//            }
        }
#endif
//<<<<<<<<<<<<<<<<<<<<<
#if (DD_FISPRINTER && defined(FISCAL))//ccr090917
        CheckFisError();
#endif

        CheckError(0);

    }

}

//==================================================================
//Test if has some key for read
//Return True if a key pressed
short   KbHit()
{
    WORD i;
#if (defined(DEBUGBYPC))
    ProcessMessages();
#endif


        i =Bios_1(BiosCmd_CheckKeyborad);//����Ƿ��а���

#if (PC_EMUKEY)
        if (i && (i==ApplVar.AP.FirmKeys[ID_LOCK]+1))// && ApplVar.CentralLock==RG && Appl_EntryCounter==0)
        {
            if (FisTestTask.Going)//�ڶ��ΰ����Լ�ʱ���رմ�ӡ��
            {
                if (FisTestTask.PrnOFF == 0)
                    FisTestTask.PrnOFF = 1;
                else
                    FisTestTask.Going = FisTestTask.PrnOFF = 0;//�رպ������Լ�ʱ���򿪴�ӡ��
                Getch();
                return 0;
            }
            else if (Appl_EntryCounter==0 && ApplVar.CentralLock==RG)
                {
                    FisTestTask.Going = 0x01;
                    Getch();
                    return 0;
                }
        }
#endif
        if (i==0)
        {//�ް���
            if (KeyFrHost!=0xff)
            {
                SETBIT(ApplVar.MyFlags, KEYFROMHOST);
                i = Bios_Key0_Key = KeyFrHost+1;
                KeyFrHost = 0xff;
#if (defined(DEBUGBYPC) && PC_EMUKEY)
                if ((i==ApplVar.AP.FirmKeys[ID_LOCK]+1) && ApplVar.CentralLock==RG)//  && Appl_EntryCounter==0)
                {
                    if (FisTestTask.Going)//�ڶ��ΰ����Լ�ʱ���رմ�ӡ��
                    {
                        if (FisTestTask.PrnOFF == 0)
                            FisTestTask.PrnOFF = 1;
                        else
                            FisTestTask.Going = FisTestTask.PrnOFF = 0;//�رպ������Լ�ʱ���򿪴�ӡ��
                        Getch();
                        return 0;
                    }
                    else if (Appl_EntryCounter==0)
                        {
                            FisTestTask.Going = 0x01;
                            Getch();
                            return 0;
                        }
                }
#endif
            }
        }
        return i;
}


// test chipcard                  //
void CheckICCard()
{//ccr050316
#if (DD_CHIPC==1)
#if (CASE_MFRIC==1)
    if (TESTBIT(IC.ICState,IC_INSERT) && !CC_Insert())// ���Կ��Ƿ�ȡ��  //
    {
        if (ApplVar.CentralLock == (SETUPMG | MG))
        {//  �ڽ����˶�IC�������ò���ʱ������γ������Զ��Ƴ�����   //
            ClearEntry();
            ApplVar.KeyNo =  ApplVar.AP.FirmKeys[ID_CANCEL];
            CheckFirmKey();
        }
        if ((IC.REC_Customer[CC_CLIST] & 3)>0 && (IC.REC_Customer[CC_CLIST] & 3)<ApplVar.AP.Plu.Level)//ccr chipcard
            ApplVar.PluPriceLevel = 0;
        IC.CHIP_Flag = -1;
        RESETBIT(IC.ICState,IC_INSERT | IC_NOTREMOVED);
    }
#else
    if (TESTBIT(IC.ICState,IC_INSERT) && !CC_Insert())// ���Կ��Ƿ�ȡ��  //
    {
        if ((IC.REC_Customer[CC_CLIST] & 3)>0 && (IC.REC_Customer[CC_CLIST] & 3)<ApplVar.AP.Plu.Level)//ccr chipcard
            ApplVar.PluPriceLevel = 0;
        IC.CHIP_Flag = -1;
        if (ApplVar.CentralLock == (SETUPMG | MG))// ���Կ��Ƿ�ȡ��  //
        {
            //  �ڽ����˶�IC�������ò���ʱ������γ������Զ��Ƴ�����   //
            ClearEntry();
            ApplVar.KeyNo =  ApplVar.AP.FirmKeys[ID_CANCEL];
            CheckFirmKey();
        }
    }
    if (((ApplVar.CentralLock & 0xff) == MG || ApplVar.CentralLock == RG)  && ChipCard())//ccr chipcard
    {
        InActive = 0;
        if (!ApplVar.ErrorNumber)
        {
            PrintChipCard(0);
        }
    }
#endif
#endif
}
//--------------------------------------------------------
// ����ӡ���Ĺ���״̬    			//
//return:0-Error found  1-no error //
BYTE CheckPrinter(void)
{
    BYTE newErr;
#if (PC_EMUKEY)
    if (FisTestTask.Going)//�Զ���������ʱ��������ӡ��
        return TRUE;
    else
#endif
    {
#if (!defined(DEBUGBYPC))
        newErr = 0;

        Get_Printer_status();
        if (Printer_Status.g_bNOPAPER)//paper out                       /* Near End */
        {
#if defined(FISCAL) // LIUJ 0805
            if (TESTBIT(ApplVar.Fiscal_PrintFlag,(BIT0 | BIT2)))
            {
                SETBIT(ApplVar.Fiscal_PrintFlag,BIT7);
            }
#endif
            newErr = ERROR_ID(CWXXI40);
        }
#if(CASE_HANDUP)	//    cc 20070827
        else if (Printer_Status.g_bHANDUP)                       /*    Near End     */
        {
            newErr = ERROR_ID(CWXXI39);
        }
#endif
        else if (Prn_Status.g_bTOOHOT)                       /* Near End */
        {
            newErr = ERROR_ID(CWXXI41);
        }
#endif
        if (newErr!=0)
        {
            if (newErr!=(ApplVar.ErrorNumber&0x7f))
                ApplVar.ErrorNumber=newErr;
            return false;
        }
        else if ((ApplVar.ErrorNumber&0x7f)>=39 && (ApplVar.ErrorNumber&0x7f)<=41)
        {
//            if ((ApplVar.ErrorNumber&0x7f)==ERROR_ID(CWXXI40))
//                RFeed(1);//�Զ�������ӡ

            Start_When_Ready(Msg[SPACE].str);
            ApplVar.ErrorNumber=0;
        }
        return TRUE;
    }
}
//==========================================================================
short CheckFunctionEntry()
{
    if (ApplVar.Key.Code < 1000 && !(ApplVar.Key.Code % 100))
    {   /* number function key */
        if (!ApplVar.NumberEntry || ApplVar.NumberEntry > 99)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            return 1;
        }
        ApplVar.Key.Code += ApplVar.NumberEntry;
        if (ApplVar.MultiplyCount)
        {
            ApplVar.DecimalPoint = ApplVar.Qty.Sign & 0x03;
            ApplVar.Entry = ApplVar.Qty;
            ApplVar.MultiplyCount = 0;
            GetWordEntry(); /* make word from entry to ApplVar.NumberEntry */
        }
        else
            Appl_EntryCounter = 0;
    }
    return 0;
}


void GetEntry()
{
    if (ApplVar.DecimalPoint)
    {
        ApplVar.DecimalPoint--;
        ApplVar.Entry.Sign = ApplVar.DecimalPoint;
    }
#if (AMTMUL100)//defined(CASE_MALTA) && !defined(CASE_ITLIA))
    else
    {//û������С����ʱ,�Զ�Ϊ��λС��(����������Է�Ϊ��λ
        if ((ApplVar.Key.Code==NPRICE)||(ApplVar.Key.Code>PORA&&ApplVar.Key.Code<MODI)||(ApplVar.Key.Code==DISC+3)||(ApplVar.Key.Code==DISC+4)||(ApplVar.Key.Code>DEPT&&ApplVar.Key.Code<DEPT+100))
        {
            ApplVar.Entry.Sign =  2;
            ApplVar.DecimalPoint=2;
        }
/*	 		else if(ApplVar.Key.Code==MULT)
            {
                ApplVar.Entry.Sign =  3;
                memcpy(SysBuf, EntryBuffer, sizeof(EntryBuffer));
                ApplVar.DecimalPoint=3;
                StrToBCDValue(ApplVar.Entry.Value, &SysBuf[sizeof(EntryBuffer) - 2], BCDLEN);
            }*/
        else
        {
            ApplVar.Entry.Sign =  0;
        }
    }
#else
    else
    {
        ApplVar.Entry.Sign =  0;
    }
#endif
    StrToBCDValue(ApplVar.Entry.Value, &EntryBuffer[sizeof(EntryBuffer) - 2], BCDLEN);
    GetWordEntry(); /* make word from entry to ApplVar.NumberEntry */
}

/*-------Process the input from keyboard-------------
    ApplVar.KeyNo: �������
    ApplVar.Key.Code:������Ӧ�Ĺ�����
------------------------------------------------------*/
void ProcessKey()
{
#if DD_FISPRINTER == 0
    short       i,j,k;
    BYTE    sDot,sP;
    BYTE    sFlag = 1;//=1,��ʾ����δ������;=2,��ʾ�����Ѵ���EntryBuffer

    if (ApplVar.Key.Code == CLEAR)                     /* clear key ? */
    {
        ApplVar.FSub = 0;
#if defined(FISCAL)
        if (ApplVar.FStatus > 0x90)
        {
            ApplVar.FStatus = 0;    /* exit fiscal init when lock changed */
            ReceiptIssue(0);
        }
#endif

        Fixed();
        if (ApplVar.CentralLock==RG || ApplVar.CentralLock==MG)
            Appl_MaxEntry = sizeof(EntryBuffer)-1;

#if POWERCTRL
        if (!DC_DET_GET() && !ApplVar.FRegi)
            mDrawPower(2);//��ʾ���
#endif
        return;
    }
    else if (ApplVar.ErrorNumber)  /* Error Condition ? */
        return;

    if (!ApplVar.Key.Code)       /* Not used */
        return;


    if (ApplVar.Key.C.High && !TESTBIT(ApplVar.MyFlags,HANZIMODE) && ApplVar.KeyNo != fBACKSPACE)
    {//Ϊ���ַ�������װ��̨,Key.C.High>0,Input from the keeyboard is a function key(�����ּ�)
#if defined(FISCAL)
        if (ApplVar.FisCardFlag != FISCALOK &&
            ApplVar.FisCardFlag != TESTFM &&
            ApplVar.FisCardFlag != FMLESS &&
            ApplVar.FisCardFlag != EJLESS &&
            (ApplVar.FisCardFlag!= BADEJ || !ApplVar.FRegi || ApplVar.Key.Code!=CORREC+4)) // ccr091124 EJ����ʱ,����ȡ������ //
        {
            /*		if(ApplVar.FisCardFlag == FMISNEW)
                        ApplVar.ErrorNumber=ERROR_ID(CWXXI94);
                    else*/
            CheckFisError();
            return;
        }

#if (!defined(CASE_MALTA) || defined(CASE_ITALIA))
        if (!ApplVar.FRegi && ApplVar.ZReport == 2)     /* check if day changed when not in transaction */
        {//��������ӡZ����
            ApplVar.ErrorNumber=ERROR_ID(CWXXI75);       /* first take fiscal Z-ApplVar.Report */
            return ;
        }
#endif
#endif

#if POWERCTRL
        if (!DC_DET_GET())
            mDrawPower(0);//����ʾ���
#endif
        ApplVar.NumberEntry = 0;
        if (Appl_EntryCounter)          /* ApplVar.Entry ? */
        {
            if (Appl_EntryCounter <= (BCDLEN * 2))
                GetEntry();
            else
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);     /*    maximum 16 digits entry     */
                return;
            }
        }
    }
    else   /*    if (!ApplVar.Key.C.High)     */
    {//Ϊ�༭�����������ַ���
        /* Key.C.High<0, Ascii '0'..'9','.' entry key     */
        if (Appl_EntryCounter < (sizeof(EntryBuffer) - 1))
        {
            if (ApplVar.KeyNo == fBACKSPACE)
            {//���ɾ����������ַ�
                sFlag = 2;//��ʾ�����Ѿ���������
                DeleteEntry();
            }

            if (Appl_EntryCounter<Appl_MaxEntry+(ASCIIINPUT*COMPOSEIN))
            {
                if (ApplVar.Key.Code == ZERO2)  /* double zero key*/
                {
                    if (!TESTBIT(ApplVar.MyFlags,HANZIMODE))//ccr2014-08-15 �ַ���ʽ�� || TESTBIT(ApplVar.MyFlags,NUM_ASCII + HANZIMODE))
                    {//'00'Ϊ��������0
                        sFlag = 2;//��ʾ�����Ѿ���������
                        if (!AppendEntry('0')) return;
                        if (!AppendEntry('0')) return;
                    }
                }//end of if(ApplVar.Key.Code == ZERO2)

                if (sFlag==1)//����δ���������̴���
                {
#if (ASCIIINPUT==1 || COMPOSEIN==0)
                    if ((sP = GetComposeASC(ApplVar.KeyNo))==0)
                        return;
#elif (COMPOSEIN==1)//�������������ĸ
                    if ((sP = GetComposeASC(ApplVar.Key.Code))==0)
                        return;//������Ϊ�Ƿ�����,�˳�
                    if (sP==0xff)
                        sFlag=2;//�ַ��Ѿ�����������
#endif

                    if (Appl_EntryCounter<Appl_MaxEntry && sFlag==1)
                    {
                        if (!AppendEntry(sP)) return;
                    }
                }
                if (ApplVar.ErrorNumber)
                    return;

                memset(SysBuf,' ',DISLEN+5);

                if (ApplVar.DecimalPoint>0)  //      �������С���㣬����д���  PenGH //
                {

                    j = DISLEN-1;
                    i = sizeof(EntryBuffer)-2;
                    k = Appl_EntryCounter;
                    sDot = 0;

                    while (k>0 && j>=0)  //     �����뻺�������ݸ��Ƶ�ϵͳ������ //
                    {
#if(DD_ZIP_21 || DD_ZIP || DD_LCD_1601 || defined(DEBUGBYPC))

                        //ccr2014-08-15>>>>>>>>>��.ת��Ϊ,
                        if (!TESTBIT(COMMA,BIT0) && EntryBuffer[i]=='.')
                            SysBuf[j--] = ',';
                        else
                            SysBuf[j--] = EntryBuffer[i];
                        //<<<<<<<<<<<<<<<<<<<<<<
                        i--;
                        k--;
#else
                        if (EntryBuffer[i]=='.')
                            sDot = 0x80;//��С������ϵ���ǰһ���ַ���
                        else
                        {
                            SysBuf[j--] = EntryBuffer[i] | sDot;
                            sDot = 0;
                        }
                        i--;
                        k--;
#endif
                    }
                }
                else
                    memcpy(SysBuf,EntryBuffer + sizeof(EntryBuffer) - DISLEN - 1,DISLEN);

                SysBuf[DISLEN] = 0;

                if (TESTBIT(ApplVar.MyFlags,PWDMODE) || (ApplVar.CentralLock & PWDFOR))// & (ApplVar.CentralLock & 0xff!=MG))        /* secret code entry ? */
                {
                    //Ϊ�������뷽ʽ
                    for (i=0;i<DISLEN;i++)
                    {
                        if (SysBuf[i]>' ')
                            SysBuf[i]='-';
                        else if ((ApplVar.CentralLock & PWDFOR)==0x200)
                            SysBuf[i] = '?';//ȷ����������(������)
                        else
                            SysBuf[i]='_';
                    }
                }
                if (ApplVar.CentralLock!=RG && (ApplVar.CentralLock & 0xff)!=MG)
                {
                    i = strlen(ModeHead);
                    while (i>0 && ModeHead[i-1]==' ') i--;

                    if (i>0 && SysBuf[i]==' ' && ProgLine<=1)
                    {
                        for (j=0;j<i;j++)
                        {
                            if (SysBuf[j]==' ' || !ModeHead[j])
                                break;
                            else
                                SysBuf[j] = ModeHead[j];
                        }
                    }
                }
#if(DD_ZIP==1)
                if (ProgType || ApplVar.FuncOnEnter == FUNC800) //liuj 0604
                {
                    PutsO(ProgLineMes);
                }
                else
                {
                    if (ApplVar.FuncOnEnter==0)//ccr091202
                        PutsO(ModeHead);
                }
                Puts1(SysBuf);
#elif(DD_ZIP_21==1)                     //    PenGH 2008-06-03
                if (ProgType || ApplVar.FuncOnEnter == FUNC800) //    liuj 0604
                {
                    PutsO(ProgLineMes);
                }
                else
                {
                    if (ApplVar.FuncOnEnter==0)//ccr091202
                        PutsO(ModeHead);
                }
                Puts1(SysBuf);
                if ( ((ApplVar.CentralLock==RG)||(ApplVar.CentralLock==MG))&&(ProgType!=0x91)  )
                {
                    PutsC(SysBuf+4);
                }
#else
                PutsO(SysBuf);
#endif

            }//��������̫��
//ccr20130104 �������Ȳ�����            else if (Appl_MaxEntry)//ccr070608
//ccr20130104 �������Ȳ�����                ApplVar.ErrorNumber=ERROR_ID(CWXXI18);
        }
        else
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);       /* Invalid ApplVar.Entry */
        return;
    }//end of if (!ApplVar.Key.C.High)

//    if (ApplVar.Key.Code >= TEND &&  ApplVar.Key.Code < (TEND + 100))
//		ApplVar.FRefund = 0;

    if (ApplVar.FuncOnEnter)
        return;

    if (ApplVar.FCorr || ApplVar.FRefund)
    {
        if (ApplVar.Key.Code >= TEND &&  ApplVar.Key.Code < (TEND + 100))
        {
            if (ApplVar.FRegi)
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                return;
            }
        }
        else if (ApplVar.Key.Code >= PBF &&  ApplVar.Key.Code < (PBF + 100))
        {
        }
        else if (ApplVar.Key.Code >= DISC &&  ApplVar.Key.Code < (DISC + 100))
        {
        }
        else if (ApplVar.Key.Code >= PORA &&  ApplVar.Key.Code < (PORA + 100))
        {
        }
        else if (ApplVar.Key.Code != MULT && ApplVar.Key.Code != NPRICE && ApplVar.Key.Code < DEPT)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            return;
        }
    }
    if (CheckFunctionEntry())
        return;
    if ((ApplVar.MultiplyCount || ApplVar.FPrice) && ApplVar.Key.Code < DEPT
        && ApplVar.Key.Code != MULT && (ApplVar.Key.Code < PORA || ApplVar.Key.Code > PORA+99))
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI01);    /* multiply only on article, pora and X key */
        return;
    }
    if ((ApplVar.Key.Code < DISC || ApplVar.Key.Code > DISC + 100) &&   //      ��������ۿ۴����Ҳ��Ǹ��ʽ��������С������ PenGH ?  //
        (ApplVar.Key.Code < TEND || ApplVar.Key.Code > TEND + 100))
        ApplVar.FSub = 0;       /* reset subtotal flag */

//ccr090526>>>>>>>>>>>>>>>
    if (ApplVar.DecimalPoint &&
        (ApplVar.Key.Code>=DRAW && ApplVar.Key.Code<=PORA ||
         ApplVar.Key.Code>=MODI && ApplVar.Key.Code<MULT ||
         ApplVar.Key.Code>=LEVEL1 && ApplVar.Key.Code<=DEPT ||
         ApplVar.Key.Code % 100==0))
    //<<<<<<<<<<<<<<<<<<<<<<<<
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
        ClearEntry();
        return;
    }
    if ((ApplVar.Key.Code != MULT && ApplVar.Key.Code!=CLERK && ApplVar.Key.Code!=SALPER &&
         (ApplVar.Key.Code<DRAW || ApplVar.Key.Code>=DRAW+100) &&
         (ApplVar.Key.Code < DISC || ApplVar.Key.Code > DISC + 100) &&
         (ApplVar.Key.Code < PBF || ApplVar.Key.Code > PBF + 100) &&
         ApplVar.Key.Code != NUMBER && ApplVar.Key.Code != NUMBER1 && ApplVar.Key.Code != NUMBER2 &&
         ApplVar.Key.Code < PLU1) ||
        (ApplVar.Key.Code == MULT && ApplVar.CentralLock==MG && ApplVar.FInv == 3))
    {
        if (!ChangePoint())
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            return;
        }
    }

/*    if (ApplVar.DecimalPoint && ApplVar.Key.Code != MULT &&
        ApplVar.Key.Code != NUMBER && ApplVar.Key.Code != NUMBER1 && ApplVar.Key.Code != NUMBER2 &&
         (ApplVar.Key.Code < DISC || ApplVar.Key.Code > DISC + 100) &&	(ApplVar.Key.Code < PLU1 + 1))
        ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
    else    */
//ccr2016-12-20#if (defined(CASE_MALTA))
    if ((ApplVar.CentralLock & 0xff)==SET || ApplVar.CentralLock==X || ApplVar.CentralLock== Z ||ApplVar.FuncOnEnter == FUNCUSERINFO || ApplVar.FuncOnEnter == FUNCVATNO)
    //cc 20071102>>>>>>>>>>>>>>>>>>>>>>>
    {
        ApplVar.ErrorNumber = 1;
        return;
    }
//ccr2016-12-20#endif
    if (ApplVar.Key.Code < 300)    /*    256 to 299 not used     */
        ApplVar.ErrorNumber=ERROR_ID(CWXXI42);  //      �Ƿ�������  //
    else if (ApplVar.FInv && ApplVar.Key.Code < PLU1 && ApplVar.Key.Code != SUB && ApplVar.Key.Code != CLEAR
             && ApplVar.Key.Code != SUB1 && ApplVar.Key.Code != MULT
             && (ApplVar.Key.Code < LEVEL1 || ApplVar.Key.Code > ARTLEVEL9) && ApplVar.Key.Code != LEVEL
             && ApplVar.Key.Code != ARTLEVEL)
        ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
    else if ((ApplVar.KeyNo==ApplVar.AP.FirmKeys[ID_PRGUP]) //ccr2014-08-15 �����ͻ||ApplVar.KeyNo==ApplVar.AP.FirmKeys[ID_DOWN])
             && ApplVar.FRegi && Appl_EntryCounter==0)
    /* Ϊ�����������,ֻ�ڴ������վݺ�����ô˹��� */
     {
        if (ApplVar.KeyNo==ApplVar.AP.FirmKeys[ID_PRGUP])
            Display_RGBuf(-1);
        else
            Display_RGBuf(1);
     }
    else if (ApplVar.Key.Code < CORREC + 100)    //     correction functions 300 - 399 //
        Correction();
    else if (ApplVar.Key.Code < CURR + 100)    /*    currency functions 400 - 499     */
        Currency();
    else if (ApplVar.Key.Code < DISC + 100)    /*    discount functions 500 - 599     */
        Discount();
    else if (ApplVar.Key.Code < DRAW + 100)    /*    drawer functions 600 - 699     */
        Drawer();
    else if (ApplVar.Key.Code < PBF + 100)     /*    pb functions 700 - 799     */
        PbFunction();
    else if (ApplVar.Key.Code < PORA + 100)    /*    ApplVar.PoRa functions 800 - 899     */
        PaidOutRa();
    else if (ApplVar.Key.Code < TEND + 100)   /*    Tendering Functions 900 - 999     */
        Tender();
    else if (ApplVar.Key.Code < MODI + 1000)    /*    Modifiers  1000 - 1999     */
        GetModifier();
    else if (ApplVar.Key.Code < FIXED + 99)   /*    fixed functions 2000 - 2099     */
    {
        Fixed();
        return;                        /*    don't clear entry     */
    }
    else if (ApplVar.Key.Code >= SALPER && ApplVar.Key.Code < SALPER+256)
        SelectSalPer();
    else if (ApplVar.Key.Code < CLERK)
        ApplVar.ErrorNumber=ERROR_ID(CWXXI42);
    else if (ApplVar.Key.Code < OFFER)
        SelectClerk(0);
    else if (ApplVar.Key.Code >= DEPT && ApplVar.Key.Code < PLU1)
        ProcessDept();
    else if (ApplVar.Key.Code >= PLU1 && ApplVar.Key.Code < PLU3)
        ProcessPlu();
/*     else if (ApplVar.Key.Code < PLU3)
else if (ApplVar.Key.Code < 60000)
    */
    else
        ApplVar.ErrorNumber=ERROR_ID(CWXXI42);
    ClearEntry();
#endif
}

/*---------------------------------------------------------------------
  ����:true-��Ч����
    ApplVar.KeyNo:�ʹ��������
    ApplVar.Key.Code:�ͳ�������Ӧ�Ĺ�����
      false-��Ч����
---------------------------------------------------------------------*/
WORD KeyInput()
{
#if DD_FISPRINTER==0
    BYTE keyno;

    if (!KbHit())
        return 0;

    ApplVar.FBarcode = 0;
    keyno = Getch();        /*    read key     */


    if (keyno != ApplVar.AP.FirmKeys[ID_DATE] || Appl_EntryCounter>0)
    {
        //ccr20130308>>>>>>>>>>>>>>>>>>>>
        if (ACTIVE && InActive > ACTIVE && ApplVar.LCD_Operator[0] && keyno==ApplVar.AP.FirmKeys[ID_CLEAR])
        {//�������������Ҵ��ڰ�����ʱ��ʾʱ��ģʽ���������ʾʱ���ģʽ���ָ�֮ǰ����ʾ���ݣ�
            PutsO(ApplVar.LCD_Operator);
            ApplVar.LCD_Operator[0]=0;
#if (DD_LCD_1601==1)
            //        PutsC(ApplVar.LCD_Customer);
#endif
            InActive = 0;//Disable display datetime
            return 0;
        }
        //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        InActive = 0;//Disable display datetime
    }

    if (keyno < 64)                 /* if keyno larger 63 then Lock Code */
    {
        ApplVar.KeyNo = keyno;
        if (ApplVar.AP.KeyTable[ApplVar.KeyNo] != CLEAR)
            ApplVar.OldKey.Code = ApplVar.Key.Code;       /* save previous key */
        ApplVar.Key.Code = ApplVar.AP.KeyTable[ApplVar.KeyNo];
        keyno = CheckMode();
#if (defined(CASE_MALTA))
        if (keyno || (ApplVar.CentralLock != MG && (ApplVar.CentralLock != RG  ||(ApplVar.CentralLock == RG && (ApplVar.FuncOnEnter == FUNCUSERINFO || ApplVar.FuncOnEnter == FUNCVATNO)))&& CheckFirmKey()))
#else
        if (keyno || (ApplVar.CentralLock != MG && ApplVar.CentralLock != RG && CheckFirmKey()))
#endif
            ApplVar.Key.Code = 0;
//        else if (ApplVar.Key.C.High && ApplVar.CentralLock == RG && ApplVar.Key.Code != CLEAR)    /* function ? */
//        {
//            if (ApplVar.AP.Manager[keyno >> 3] & (0x01 << (keyno & 7)))//??????keyno��CheckMode()���ı�,�˴��к���????
//                ApplVar.ErrorNumber=ERROR_ID(CWXXI28);
//            else
//                return TRUE;
//        }
        else
            return TRUE;
    }
    //else
//    if (keyno > 64 && !ApplVar.ErrorNumber)
//    {
//		HEXtoASC(sBuf,&keyno,1);sBuf[2] = 0;
//		PutsO(sBuf);
//	}
    CheckError(0);

#endif
    return FALSE;

}


/* return 1 incase of error */
BYTE AmtInputMask()
{
/*    if (Appl_EntryCounter && TESTBIT(ROUNDMASK, BIT0))
    {       // entry must end with 0 or 5
        switch(ApplVar.Entry.Value[0] & 0x0f)
        {
            case 0:
            case 5:
                break;
            default:
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                return 1;
        }
    }*/
    return 0;
}

//-----------------------------------------------------------
// Funzione OutPrint
// -----------------
//
// Lancia un comando di stampa standard sulla stampante
//
// Inputs :   Cmd              = Comando di stampa (CMDP_xx)
//            *Line            = Pointer a linea di dati da stampare
//


void OutPrint(WORD Cmd, CONSTBYTE *Line)
{

    if (!TESTBIT(ApplVar.MyFlags, PRNONPB+ENPRINTER))     //lyq20040223 added for control the printing of pb message
    {

#if(DD_MMC)
        StoreEJStart();
#endif

        if (Line && Line[0]=='@')
        {
#if !defined(DEBUGBYPC)
            OutPrintEx(CMDP_DRJ, Line+1, 0);
#else
//            Cmd = CMDP_DRJ;

            OutPrintEx(Cmd, Line+1, 0);
#endif
#if(DD_MMC)
            StoreLogData(CEJ_STARTLND, Line+1);
#endif

        }
        else
        {
#if !defined(DEBUGBYPC)
            OutPrintEx(Cmd | CMDP_LFRJ, Line, 0);
#else
            Cmd |= CMDP_LFRJ;
            OutPrintEx(Cmd, Line, 0);
#endif
#if(DD_MMC)
            StoreLogData(CEJ_STARTLN, Line);
#endif

        }
    }
}




//
// Funzione OutPrintEx
// -------------------
//
// Lancia un comando di stampa esteso sulle stampanti interne (Scontrino e/o Giornale)
//
// Inputs :   Cmd              = Comando di stampa (CMDP_xx)
//            *Line            = Pointer a linea di dati da stampare
//            DotLinesBlank    = #dot line post-stampa addizionali
//
#if (!defined(DEBUGBYPC))
void OutPrintEx(WORD Cmd, CONSTCHAR *Line, WORD DotLinesBlank)
{

#if (PC_EMUKEY)
    if (!FisTestTask.PrnOFF)
#endif
        if (!TESTBIT(ApplVar.MyFlags, PRNONPB+ENPRINTER))     //lyq20040223 added for control the printing of pb message
            Bios(BiosCmd_PrintX, (void*)Line, Cmd , DotLinesBlank);
}

#endif //    DEBUGBYPC

//    Reset the keyboard if user redefine a new function on the masked KEY
//    pReset:0 Set the mask if needed
//           1 set the mask alwasy
void MaskKeyBoard(char pReset)
{
    short i,j;
    char sMask[KEY_MAXKEYS];
    char sReset = pReset;

    memset(sMask,0,KEY_MAXKEYS);
    for (i=0;i<KEY_MAXKEYS;i++)
    {
        if (ApplVar.AP.KeyTable[i]!=0 && ApplVar.AP.KeyTable[i]!=0xffff)
        {
            j = i;
            sMask[j] = j+1;
            sReset = 1;
        }
    }

    if (sReset)
    {
        Bios_SetKeyboard(0, KEY_MAXKEYS,  (CONSTBYTE*)&sMask, 1);
    }
}


#if !defined(DEBUGBYPC)


/*********************************************************************************************************
** Function name:       main
** Descriptions:        �û�������ں���(ʹ���ж�ʱ�������OS���ж����ú���,��IRQ.h)
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
extern void STM32_Initial(void);

int main(void)
{

    InitMonitor(MONITOR_RS232);
    STM32_Initial();
    Print_Initial();

    MACSwitch=Bios_TestMAC();

    mainTask(0);

}
#endif
/*********************************************************************************************************
  End Of File
*********************************************************************************************************/

