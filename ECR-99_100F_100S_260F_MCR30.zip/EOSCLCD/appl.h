#ifndef APPL_H
#define APPL_H

#if defined(DEBUGBYPC)
    #pragma option -a1
#else
    #pragma pack(1)
#endif

#include "debug.h"
#include "print.h"

#include "CHNMess.h"		//cc added 2005-03-14

//     include APPL.h after KING.h and Bios_Dir.h================================


#define YES true
#define NO  false


#define FISCAL 1

#define YN		0x17    //����������1-No,0-Yesʱ,ʹ��YN������ȡ��

#define ADDR_EXTRAM	0x64000000	//SRAM�ĵ�ַ����,RAM for application from ADDR_EXTRAM

#define		FLASH1SIZE		0x100000
#define		FLASH2SIZE		0x100000
#define		FLASHTOTAL		(FLASH1SIZE+FLASH2SIZE)


#if (defined(CASE_PCR01)||defined(CASE_ER100)||defined(CASE_MCR30))    //���STM32F103MCU��MCU���޵籣����RAM��
#define     DOWN_GR_SIZE    0  //����ͼƬ��С(��ʱ���ṩ�Զ���ͼƬ����)��
#define		SRAMSIZE	(0x40000-DOWN_GR_SIZE)//����4K�����û��Զ���ͼƬ
#define     DOWN_GR_ADDR    (ADDR_EXTRAM+SRAMSIZE)//����ͼƬ���λ�ã�ʹ����չ���ⲿRAM
#define     MCU_RAM_SIZE    0x10000
#elif defined(CASE_ER520U)
#define     MCU_RAM_SIZE    0x10000
#define		SRAMSIZE		0x80000
#elif (defined(CASE_ER260F) || defined(CASE_ECR100F))
#define		SRAMSIZE		0x80000
#define     MCU_RAM_SIZE    0x20000
#else
#define		SRAMSIZE		0x40000
#define     MCU_RAM_SIZE    0x20000
#endif

#define SIZE_APPRAM     ((EXTRAMN & 0x0f) * SRAMSIZE)     //size of SRAM
#define ADDR_APPRAM	    ADDR_EXTRAM
#define SIZE_FLOWRAM    0


#define TCPIPPORT		3

#define BARCUSTOMER	0		//     ccr 050307 ʹ�������Ա����  //

#define PRNONOFF   205
// command index for upload
#define UOK		0
#define UCA		1
#define UEN		2
#define UER		3



//    cc 2006-07-03 for MMC>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

/* if WWATCH is 1 then each plu can have 2 dept selections */
#define WWATCH	    0
#define MAXKEYB		64
#define REPDEFMAX	6
#define XZNUM		13	 	//Number of XReport
#define ASECOND		1000
#define DELAY485	2
#define CCDBUFMAX 	40
#define PCBUFMAX	1024
#define REPTYPEMAX	14

#define CAPSIZEMAX  25      //����͵�Ʒ���Ƴ���

#define ENTRYSIZE   80

#if(DD_LCD_1601==1)
    #define PORTTYPELEN 7
    #define  lenDMes 	15
    #define  lenDText	15	// < sieof(ModeHead)

    #define CAPWIDTH	15	// < DISLEN
    #define dCAPWIDTH	9
    #define mCAPWIDTH	9
    #define lCAPWIDTH	8	//!!!!!!!!
    #define tCAPWIDTH	16
#elif(DD_ZIP==1 || DD_ZIP_21==1)
    #define PORTTYPELEN 16
    #define  lenDMes	15
    #define  lenDText	15

    #define CAPWIDTH	15
    #define dCAPWIDTH	9
    #define mCAPWIDTH	9
    #define lCAPWIDTH	12
    #define tCAPWIDTH	16
#elif CASE_SPANISH == 1
    #define PORTTYPELEN 7
    #define  lenDMes	11
    #define  lenDText	6

    #define CAPWIDTH	9
    #define dCAPWIDTH	9
    #define mCAPWIDTH	10
    #define lCAPWIDTH	4
    #define tCAPWIDTH	10
#else
    #define PORTTYPELEN 7
    #define  lenDMes	11
    #define  lenDText	6
    #define CAPWIDTH	9
    #define dCAPWIDTH	9
    #define mCAPWIDTH	9
    #define lCAPWIDTH	4
    #define tCAPWIDTH	10
#endif
#define MESSWIDTH	17
#define REPWIDTH	17
//#define SHEADWIDTH	35
#define SHEADWIDTH	PRTLEN  // Lyq modified 20040331

#define GRASETMAX	4
#define GRAFESTMAX	10
//    Function number under ENTER
#define FUNC1		1
#define FUNC4		2
#define FUNC5		3
#define FUNC6		4
#define FUNC7		5
#define FUNC8		6
#define FUNC10		7
#define FUNC11  		8
#define FUNC100		9
#define FUNC101		10
#define FUNC120		11
#define FUNC300		12
#define FUNC398		13
#define FUNC399		14
#define FUNC401		15
#define FUNC490		16
#define FUNC491		17
#define FUNC492		18
#define FUNC495		19
#define FUNC496 	20
#define FUNC497		21
#define FUNC498		22
#define FUNC499		23
#define FUNC500		24
#define FUNC600		25
#define FUNC601		26
#define FUNC610		27
#define FUNC700		28
#define FUNC550		29
#define FUNC551 	30
#define FUNC200		31


//cc 2006-09-19 for Fiscal>>>>>>>>
#define FUNC800				32	/* hf 20060919 20 */
#define FUNC802				33
#define FUNC803				34
#define FUNC804				35
//cc 2006-09-19 for Fiscal>>>>>>>>

//cc 20071102>>>>>>>>>>>>>>>>>>>>>>>>
#define FUNCUSERINFO		37	//for userinfo input
//ccr2016-12-20#if (defined(CASE_MALTA))
#define FUNCVATNO			38
//ccr2016-12-20#endif
//Flags for  ArrowsAlfa==================================================
#define UPPERASCII	BIT0   //=1,Uppercase of ascii;=0,lowwer case
#define NUMRIC09	BIT1   //=1,input numric;=0,input ascii
#define COMPASCII   BIT2   //=1,��Ҫ����������ֽ������Ϊ��ĸ
#define INPUTVALUE	BIT3	//=0ʱ,ʶ��С����;=1,��ʶ��С����,��������ĸ��������
#define INPUTPWD	BIT4	// Ϊ�������뷽ʽ,������ַ���ʾΪ*
#define KEY2ndLAYER BIT6    //����ʹ���ϵ�(GREECE:�ڶ������);=0:����ʹ���µ�
#define SETCONFIRM	BIT7	// ��Ҫ����������ݽ��ж���ȷ������(��:����ȷ��)

//Flags for MyFlags==========================================================
#define CANCELSAL 	BIT0	/* set when SALE-CANCEL key pressed ,and clear after ENTER key pressed*/
#define PLUPACK		BIT1	/* Set when Mix/Match mode for PLU sales */
#define PLUDISC		BIT2	/* Set when Mix/Match mode for PLU sales */
#define PLUOFF		(PLUDISC | PLUPACK)	/* Set if Mix/Match mode for PLU sales */
#define SETCONFIRM	BIT3	// ��Ҫ����������ݽ��ж���ȷ������(��:����ȷ��)
#define LOCKPLU		BIT4	// =0,lock price,=1 lock inv
#define ZREPORT		BIT5	//=1,can't change datetime or print Z report must;
#define PRNONPB		BIT6    //
#define PRNTRAI		BIT7	//Print the trail when out of setup
#define CLOSEPRINT  BIT8   //=0,open printer;=1 close printer
#define ENSLIPPB    BIT9   //enable slip in pb	(open table)

#define HANZIMODE	BIT10	// ���ڷ����۹����µ�����,��������ĸ��������
#define PWDMODE		BIT11	// Ϊ�������뷽ʽ,������ַ���ʾΪ*
#define COMPASCII   BIT12   //=1,��Ҫ����������ֽ������Ϊ��ĸ
#define UPASCII		BIT13   //=1,Uppercase of ascii;=0,lowwer case
#define NUM_ASCII	BIT14   //=1,input numric;=0,input ascii

#define CONFIGECR   BIT15   //�޸����տ�������ò���

#define KEYFROMHOST BIT17   //�д�������������ⰴ��

//----------------setup index definitions------------------------
#define SETDEPT   	1 				/* 1 dept	*/
#define SETPLU   	(SETDEPT+1)		/* 2 plu */
#define SETTAX   	(SETPLU+1) 	 	/* 3 tax */
#define SETHEAD   	(SETTAX+1)		/* 4 program header */
#define SETDISC   	(SETHEAD+1)		/* 5 disc */
#define SETSALER   	(SETDISC+1)		/* 6 keyswitch disable */
#define SETSYSFLAG  (SETSALER+1) 	/* 7 system flags */
#define SETCURR   	(SETSYSFLAG+1)	/* 8 Curr */
#define SETPORT1   	(SETCURR+1)     // 9
#define SETPORT2   	(SETPORT1+1)    // 10
#define SETPORT3   	(SETPORT2+1)    // 11
#define SETDATE		(SETPORT3+1)	/* 12 keyswitch disable */
#define SETTIME 	(SETDATE+1)  	/* 13 keyswitch disable */
#define SETGRAP     (SETTIME+1)     // 14
#define SETGROUP   	(SETGRAP+1)		/* 15 Group */
#define SETTEND   	(SETGROUP+1)	/* 16 tend */
#define SETIC       (SETTEND+1)     // 17
#define SETPROM     (SETIC+1)       // 18
#define SETPBF   	(SETPROM+1)		/* 19 pb functions */
#define SETKP       (SETPBF+1)      // 20 ccr070725
#define SETCLERK   	(SETKP+1)		/* 21 clerk */
#define SETMODIF   	(SETCLERK+1) 	/* 22 modifiers */
#define SETPBINF   	(SETMODIF+1)  	/* 23 keyswitch disable */
#define SETCORR   	(SETPBINF+1)	/* 24 correc */
#define SETZONES   	(SETCORR+1)		/* 25 zones */
#define SETKEYB   	(SETZONES+1) 	/* 26 keyboard code and manager */
#define SETREPTYPE  (SETKEYB+1)		/* 27 report types */
#define SETREPORT   (SETREPTYPE+1)  // 28
#define SETOFF		(SETREPORT+1)   // 29
#define SETPORA   	(SETOFF+1)		/* 30 pora */
#define SETDRAWER   (SETPORA+1)		/* 31 drawer */
#define SETTRAIL   	(SETDRAWER+1)   // 32
#define SETSP       (SETTRAIL+1)    // 33
#define SETSHEAD   	(SETSP+1) 	    /* 34 slip header */
#define SETBLOCKIC      (SETSHEAD+1)/* 35 icblock*/   //ccr chipcard 2004-07-01
#define SETIP		(SETBLOCKIC+1)	/* 36 ����ip��ַ */

#if defined(CASE_GPRS)
#define SETGPRSFUNC     (SETIP+1)       /* 37 GPRS����*/
#else
#define SETGPRSFUNC			(SETIP) // 37ccr070725
#endif

#if defined(CASE_ETHERNET)
#define SETETHERNETFUNC     (SETGPRSFUNC+1)       /* 38 ����ͨ�Ź���*/
#define SETUPMAX			(SETETHERNETFUNC) // 38ccr070725
#else
#define SETUPMAX			(SETGPRSFUNC) // 37ccr070725
#endif

//hf added end <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//not used
#define SETFIXCAP   (SETUPMAX+1) 		/* fixed captions */
#define SETERRMSG   (SETFIXCAP+1)		/* system & error message */
#define SETWEEKCAP  (SETERRMSG+1)		/* day of week captions */
#define SETMONTHCAP (SETWEEKCAP+1)	/* month captions */
#define SETKEYMASK  (SETMONTHCAP+1)	/* keyswitch disable */

//ccr chipcard>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#define MGSETUPIC		(SETKEYMASK+100)
#define SETCLEARIC		MGSETUPIC
#define SETINITIC		(SETCLEARIC+1)
#define SETCHARGIC		(SETINITIC+1)
#define SETCHIPPOINT	(SETCHARGIC+1)
#if defined(FISCAL)
    #define SETUSERINFO			(SETCHIPPOINT+1)
#endif
#if (defined(CASE_MALTA))
    #define SETVATNO			(SETUSERINFO + 1)
#endif
//ccr chipcard<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#define SETUPMG		0xf000  //Ϊ����ģʽ���߾���ģʽ�������ַ���������״̬.
//---------------- end of setup index definitions---------------------

#define MAXPWD	(12+1)	//max length of password is 12
#define	PWDFOR	0x0f00		//Must input password for new mode
#define	VERPWD	0x0100		//Set new password for mode
#define	SETPWD	0x0200		//Set new password for mode
#define	SETPWD2	0x0300		//confirm new password for mode

#define NUMASC  61			//ASCII table can be input

#define CARDPORT    2	    /* serial port card reader */
#define NOCARDi	    200     /* No Card Inserted */
#define CARDERROR   201     /* Card comm error */
#define CARDMAX     202     /* Card over max */
#define CARDREQ     203     /* Card Total required */
#define CARDUSED    204      /* card total already used */
#define CARDREAD    205     /* Card already read so no release */
#define CARDSHORT   206     /* Card short */
#define BADCARD     207     /* Card Data Error */
#define ONBLIST     208     /* Card on BlackList */
#define WRONGCARDi   209     /* Card changed with Facility Reader */
#define NOTALLOWED  210     /* CRD TTL not allowed when "NO CARD" used */

#define APPSTART    0xa000
#define SYSFLAGS    64
#if !defined(FISCAL)	//    cc 20070929
    #define SYSUSED	 32
#else
    #define SYSUSED	 30
#endif
#define FIRMKEYS    16


#define ENDREC	    0
#define PROGID	    1
#define SYSFLG	    2
#define START	    3
#define RCONFIG     4
#define RDAY	    5
#define RMONTH	    6
#define RZONE	    7
#define RTOTAL	    8
#define RDEBET	    9
#define LDEBET	    10		/* Debet List Record */

#define KEY0	    11
#define KEY32	    12
#define KEY64	    13
#define KEY96	    14
#define FIRM	    19
#define MNGR	    20
#define RREP1	    21
#define RREP2	    22
#define RREP3	    23
#define RREP4	    24
#define RREP5	    25

#define RCAP1	    30
#define RCAP2	    31
#define RCAP3	    32
#define RCAP4	    33
#define RCAP5	    34
#define RCAP6	    35

#define RMES1	    40
#define RMES2	    41
#define RMES3	    42
#define RMES4	    43
#define RMES5	    44
#define RMES6	    45
#define RMES7	    46
#define RMES8	    47
#define RMES9	    48
#define RMES10	    49

#define RDAYCAP     60
#define RMONTHCAP   62

#define REPCAP1     65
#define REPCAP2     66
#define REPCAP3     67

#define RHEAD1	    70
#define RHEAD2	    71
#define RHEAD3	    72

#define RTRAIL1     73
#define RTRAIL2     74
#define RTRAIL3     75

#define RSLIPH1     76
#define RSLIPH2     77
#define RSLIPH3     78

#define PROMO   	80

#define PBTRAIL     90
#define LOGO1		91		/* logo for old controller */
#if INDO == 1
    #define FISCDMP 	92		/* fiscal dump record */
#else
    #define CCHAR		92		/* Chinese Character record */
#endif
#define OPTIONS 	93		/* NEW Options record */
#define CHIPCARDSET	94		//ccr chipcard

#define REMOTE_ID   99

#define REMOTESETTIME			98

#define UPDPLU	    100
#define ADDPLU	    101
#define DELPLU	    102
#define MERGEPLU	103		/* Merge PLU file and Update File */
#define REMOVEPLU	104		/* Remove Deleted PLU from file */
#define REMMER		105		/* Merge and Remove */
#define TESTPLU 	106		/* TEST Plu file */
#define REPPLU		107		/* TEST and Repair PLU file */

#define ZERO3	    2		//000
#define TENDBUF 	199			/* Record ID for TENDERBUFFER */
/*======================================================================================================
    {CORREC+1   ,CORREC+4 ,0,"���Ĺ���"   ,"ȡ��\0����\0�˻�\0ȡ������"},
    {CURR       ,CURR+2   ,0,"���"        ,"��Ԫ\0��Ԫ\0�۱�"},
    {DISC+1     ,DISC+4   ,0,"�ۿ۹���"   ,"+%�ӳ�\0-%�ۿ�\0���ӳ�\0����ۿ�"},
    {DRAW+1     ,DRAW+7   ,0,"Ǯ�书��"   ,"������\0֧Ʊ\0���ÿ�\0����ȯ\0��ͨ��\0IC��\0С��"},
    {PBF+1      ,PBF+12   ,0,"��������"   ,"��̨����\0̨��\0�ݽ�\0ȷ��\0��ӡ��̨\0��ӡ�ʵ�\0ȡ��ȷ��\0����\0ת��\0����ת��\0����\0�ϲ�"},
    {PORA+1     ,PORA+2   ,0,"�������"   ,"����\0���"},
    {TEND+1     ,TEND+6   ,0,"���ʽ"   ,"�ֽ�\0���ÿ�\0����\0֧Ʊ\0����ȯ\0IC��"},
    {CLEAR      ,CLEAR    ,1,"���"       ,"���"},
    {JPF        ,JPF      ,1,"��ֽ"       ,"��ֽ"},
    {MULT       ,MULT     ,1,"����"       ,"X"},
    {SUB        ,SUB      ,1,"С��"       ,"С��"},
    {NPRICE     ,NPRICE+4 ,0,"�۸�"       ,"�۸�\0�۸�1\0�۸�2\0�۸�3\0�۸�4"},
    {SHIFT1     ,SHIFT1   ,0,"SHIFT"      ,"SHIFT"},
    {DATETIME   ,DATETIME ,1,"����"       ,"����"},
    {MODELOCK   ,MODELOCK ,1,"��ʽ��"     ,"��ʽ��"},
    {SALPER     ,SALPER   ,0,"ӪҵԱ"     ,"ӪҵԱ"},
    {CLERK      ,CLERK    ,0,"�տ�Ա"     ,"�տ�Ա"},
    {DEPT+1     ,DEPT+50  ,0,"����"       ,"*"},
    {DEPT       ,DEPT     ,0,"����#"     ,"����#"},
    {PLU1       ,PLU1     ,0,"��Ʒ"           ,"PLU"},
    {PLU1+1     ,PLU1+1000,0,"ֱ�ӵ�Ʒ"   ,"*"},
    {ARTLEVEL  ,ARTLEVEL  ,0,"��Ʒ���"   ,"��Ʒ���"},  //����ֱ�ӵ�Ʒ����ʱ�ķ���
    {ARTLEVEL1  ,ARTLEVEL9,0,"��Ʒ����"   ,"*"},  //����ֱ�ӵ�Ʒ����ʱ�ķ���
    {LOOKPLU    ,LOOKPLU  ,0,"��Ʒ��ѯ"       ,"PLU��ѯ"},
    {POINT      ,POINT+11 ,1,"����",      "��\0OO\0��\0��\0��\0��\0��\0��\0��\0��\0��\0��"},
    {ODRAW      ,ODRAW    ,0,"��Ǯ��"     ,"��Ǯ��"},
    {MODI       ,MODI     ,0,   "˵��",   "˵��"},
    {INPUTVATNO ,INPUTVATNO,0,   "��˰��",   "��˰��"},
    {NUMBER     ,NUMBER     ,0,   "����",   "����"},
    {USERINFO ,USERINFO ,0,"�û���Ϣ"   ,"�û���Ϣ"},
=============================================================================================================*/
#define CORREC	    300			//Correct
#define CURR	    400			//Currency
#define DISC	    500			//Discount
#define DRAW	    600			//
#define PBF	    	700			//
#define PORA	    800			//801-CashOut  802-Cash IN   803-CashOut2   804-CashIn2
#define TEND	    900			//901-Cash  902-   903-credit

#define MODI	    1000
#define FIXED	    2000
#define CLEAR	    2000		//
#define RPF	    	2001		//Feed
#define JPF	    	2002		//feed
#define RON	    	2003		//
#define MULT	    2004		//X
#define SUB	    	2005		//Subtotal
#define NUMBER	    2006		//
#define ODRAW	    2007		//
#define PROFORMA    2008
#define FUNC	    2009    	/* DITRON language 'F' key */
#define NPRICE	    2010		//Price
#define LEVEL1	    2011		//PLU level1
#define LEVEL2	    2012		//PLU level2
#define LEVEL3	    2013		//PLU level3
#define LEVEL4	    2014		//PLU level3

//cc 2006-06-29 for Balance>>>>>>>>>>>>>>>>>>
#define USERINFO			2018	/* quick input */
//cc 20071102>>>>>>>>>>>>>>>>>>>>>>>>
#define INPUTVATNO			2019

#define WEIGHT				2020
//cc 2006-06-29 for Balance>>>>>>>>>>>>>>>>>>

#define ARTLEVEL1   2021
#define ARTLEVEL2   2022
#define ARTLEVEL3   2023
#define ARTLEVEL4   2024
#define ARTLEVEL5   2025
#define ARTLEVEL6   2026
#define ARTLEVEL7   2027
#define ARTLEVEL8   2028
#define ARTLEVEL9   2029

#define LIST	    2030
//#define BEEP	    2031
#define NEWRECEIPT  2032		/* issue receipt and start new */
#define KPGROUP     2033		/* if set disable single ticket on kp */
#define NUMBER1     2034		/* number entry on RJ/slip direct */
#define TAXST1	    2035		/* invert tax 1 and 2 for transaction */
#define TAXSA1	    2036		/* invert tax 1 and 2 for one item */
#define RELCARD     2037		/* release card for DEBET only */
#define NUMBER2     2038		/* same as NUMBER1 and Open Draw when no entry */
#define SALPERS     2039		/* Sales person selection key */
#define DISCARD     2040		/* Disable card for transaction */
#define TPNUMBER    2045		/* Tax Payer Number (invoice printing) */
#define PROFORMA1   2046		/* proforma invoice also print onjournal */
#define SUB1	    2047		/* Subtotal with Print */
#define VALIDATION  2048
#define VALCHECK    2049
#define SHOECOLOR   2050		/* 2050 - 2055 */
#define SHOESIZE    2060		/* 2060 - 2074 */
#define SUSPEND 	2080		/* Suspend / Recall key */
#define NFOLIO		2081		/* New Folio Key */
#define LEVEL		2082		/* PRICE LEVEL number key */
#define ARTLEVEL	2083		/* Article Level Number key */
#define PLUINQ		2084		/* Plu Inquiry key code */
#define SHIFT1		2090         // Alfa Shift 1 (xchange ASCII<->QuWei)
#define DATETIME	2091
#define MODELOCK	2092
#define LOOKPLU		2093

#define NONKEY		2094	//cc 20071102

#define SALPER		2100
#define TAX	    	2900
#define CLERK	    3000
#define OFFER		3100
#define GROUP	    4000
#define DEPT	    5000		//
#define PLU1	    10000		//PLU#
#define PLU2	    42760
#define PLU3	    50000
#define AGREE		50000
#define BLOCKIC		50500		//ccr chipcard
#define PBTOT	    60000	 	/* 60001 to 65000 pb total info */


#define POINT		46
#define ZERO2	    47		//00
#define NUM0		48
#define NUM1		49
#define NUM2		50
#define NUM3		51
#define NUM4		52
#define NUM5		53
#define NUM6		54
#define NUM7		55
#define NUM8		56
#define NUM9		57


#define ENTER		TEND+1
#define SELECT		SUB
#define EXIT		CURR

//===firmkey can be use for table FirmKeys==============================
#define ID_CLEAR	0 	//firmkey clear. It must be the first byte!!!!!!.
#define ID_OCPRINTER 1 // open or close printer ,lyq added 20040227
//#define ID_LOOKPLU	1 	//Set Time
#define ID_DATE		2 	//Display Date
#define ID_REPORT	3 	//ReportList Trigger
#define ID_PRGTYPE	4 	//programming Type key
#define ID_SELECT   ID_PRGTYPE
#define ID_PRGNUM	5 	//Programming number
#define ID_PRGENTER	6 	//programming Enter
#define  ID_ENTER   ID_PRGENTER
#define ID_PRGUP	7 	//Programming UP
//#define ID_RIGHT	ID_PRGUP 	//Programming UP
#define ID_UP       ID_PRGUP

#define ID_SYSREP	8 	//system report trigger
#define ID_HARDTEST	9 	//Machine test key
#define ID_DUMP	10	// Dump Program key
//#define ID_LEFT     10
#define ID_DOWN     10

#define ID_SHIFTDEPT	11	// Alfa Shift 1
#define ID_xDEPT	ID_SHIFTDEPT	// Alfa Shift 1

#define ID_SHIFTKEY	12	// Alfa Shift 2
#define ID_LOCK	13	// Mode lock
#define ID_CANCEL	14	//
#define ID_RJFEED	15	// feed paper anytime
#define ID_DELETE   ID_RJFEED

#if (CASE_PCR01)

    #define fCLEAR		0x0c			//35 is the scan code.
    #define fDATE		0xff			//Set date
    #define fOCPRINTER	0x02			//open or close printer ,lyq added 20040227
    #define fLOCK		0x06			//Mode lock
    #define fREPORT		0xff			// ReportList Trigger
    #define fPRGTYPE	0x1d          // programming Type key
    #define fPRGNUM		0xff         	// Programming number
    #define fPRGENTER	0x23          // programming Enter
    #define fPRGOPT		0xff         	// Programming option invert
    #define fSYSREP		0xff         // system report trigger
    #define fHARDTEST	0xff         // Machine test key
    #define fDUMP		0xff         // Dump Program key
    #define fSHIFT1		0xff         // Alfa Shift 1 (xchange ASCII<->QuWei)
    #define fSHIFT2		0x0d         // Alfa Shift 2
    #define fSHIFT3		0xff        // Alfa Shift 3
    #define fCANCEL     0x17			//cancel,EXIT
    #define fNULL		0xff		//
    #define fDOWN		11         //  Dump Program key Left or Down
    #define fRJFEED		0x00		//feed paper anytime
    #define fBACKSPACE	fRJFEED		//�����ַ�����ʱ,������ɾ�ַ��İ���
    #define fPRGUP	    5         	//     Programming ����ѡ����Ŀ
    #define fSHIFTDEPT	0xff      //�л��������µ�
    #define fSHIFTKEY	13

#elif (CASE_ER50)

    #define fCLEAR		10			//    35 is the scan code.
    #define fRJFEED	    00			//    Set date
    #define fOCPRINTER	0xff			//    open or close printer ,lyq added 20040227
    #define fLOCK		01			//    Mode lock
    #define fREPORT	    0xff			//     ReportList Trigger
    #define fPRGTYPE	24          //     programming Type key
    #define fPRGNUM	    0xff         	//     Programming number
    #define fPRGENTER	34          //     programming Enter
    #define fPRGUP	    0xff         	//     Programming option invert
    #define fSYSREP	    0xff         //     system report trigger
    #define fHARDTEST	0xff         //     Machine test key
    #define fDUMP		0xff         //     Dump Program key
    #define fSHIFTDEPT	0xff      //�л��������µ�
    #define fSHIFTKEY	03      //�л��ַ���Сд
    #define fSHIFT3	    0xff        //     Alfa Shift 3
    #define fCANCEL     19			//    cancel,EXIT
    #define fBACKSPACE	fRJFEED		//�����ַ�����ʱ,������ɾ�ַ��İ���
    #define fDATE		0xff		//    feed paper anytime    */

#elif (defined(CASE_ER220)||defined(CASE_ER100)||defined(CASE_ECR100F)||defined(CASE_MCR30))

    #define fCLEAR		02			//    35 is the scan code.
    #define fRJFEED	    01			//    Set date
    #define fOCPRINTER	0xff			//    open or close printer ,lyq added 20040227
    #define fLOCK		0x00			//    Mode lock
    #define fREPORT	    0xff			//     ReportList Trigger
    #define fPRGTYPE	27          //     programming Type key
    #define fPRGNUM	    0xff         	//     Programming number
    #define fPRGENTER	34          //     programming Enter
    #define fPRGUP	    06         	//     Programming ����ѡ����Ŀ
    #define fSYSREP	    0xff         //     system report trigger
    #define fHARDTEST	0xff         //     Machine test key
    #define fDUMP		0xff         //     Dump Program key
    #define fDOWN		13         //  Dump Program key Left or Down
    #define fSHIFTDEPT	0xff         //     Alfa Shift 1 (xchange ASCII<->QuWei)
    #define fSHIFTKEY	03
    #define fSHIFT3	    0xff        //     Alfa Shift 3
    #define fCANCEL     20			//    cancel,EXIT
    #define fBACKSPACE	fRJFEED		//�����ַ�����ʱ,������ɾ�ַ��İ���
    #define fDATE		0xff		//    feed paper anytime    */

#elif (defined(CASE_ER260) || defined(CASE_ER260F))
    #define fCLEAR		0x20			//35 is the scan code.
    #define fDATE		0xff			//Set date
    #define fOCPRINTER	0x0f			//open or close printer ,lyq added 20040227
    #define fLOCK		0x08			//Mode lock
    #define fREPORT		0xff			// ReportList Trigger
    #define fPRGTYPE	0x1f          // programming Type key
    #define fPRGNUM		0xff         	// Programming number
    #define fPRGENTER	0x27          // programming Enter
    #define fPRGOPT		0xff         	// Programming option invert
    #define fSYSREP		0xff         // system report trigger
    #define fHARDTEST	0xff         // Machine test key
    #define fDUMP		0xff         // Dump Program key
    #define fSHIFT3		0xff        // Alfa Shift 3
    #define fCANCEL    	0x17			//cancel,EXIT
    #define fNULL		0xff		//
    #define fRJFEED		0x00		//feed paper anytime
    #define fBACKSPACE	fRJFEED		//�����ַ�����ʱ,������ɾ�ַ��İ���
    #define fPRGUP	    07         	//     Programming ����ѡ����Ŀ
    #define fDOWN		06         //  Dump Program key Left or Down
    #define fSHIFTDEPT	0xff         //     Alfa Shift 1 (xchange ASCII<->QuWei)
    #define fSHIFTKEY	01

#elif (CASE_WISE158)

    #define fCLEAR				56		/*    0x08	35 is the scan code.     */
    #define fDATE				41		/*    Set date     */
    #define fOCPRINTER			54		/*    open or close printer ,lyq added 20040227     */
    #define fLOCK				0		/*    Mode lock     */
    #define fREPORT				0xff	/*    ReportList Trigger     */
    #define fPRGTYPE				47		/*    programming Type key     */
    #define fPRGNUM				0xff	/*    Programming number     */
    #define fPRGENTER			60		/*    programming Enter     */
    #define fPRGUP				0xff	/*    Programming option invert     */
    #define fSYSREP				0xff	/*    system report trigger     */
    #define fHARDTEST			0xff	/*    Machine test key     */
    #define fDUMP				0xff	/*    Dump Program key     */
    #define fSHIFTDEPT				12		/*    Alfa Shift 1 (xchange ASCII<->QuWei)     */
    #define fSHIFTKEY				1
    #define fSHIFT3				0xff	/* Alfa Shift 3 */
    #define fCANCEL     			33		/* cancel,EXIT */
    #define fRJFEED				13		/*    feed paper anytime     */
    #define fBACKSPACE	fRJFEED		//�����ַ�����ʱ,������ɾ�ַ��İ���

#elif (CASE_ER28S)

    #define fCLEAR					0x00		//35 is the scan code.
    #define fDATE					0xff		//Set date
    #define fOCPRINTER				0x04		//open or close printer ,lyq added 20040227
    #define fLOCK					0x01		//Mode lock
    #define fREPORT					0xff		// ReportList Trigger
    #define fPRGTYPE					0x17          	// programming Type key
    #define fPRGNUM					0x03         	// Programming number
    #define fPRGENTER				0x1d         	 // programming Enter		"="
    #define fPRGUP					0xff         	// Programming option invert
    #define fSYSREP					0xff         	// system report trigger
    #define fHARDTEST				0xff         	// Machine test key
    #define fDUMP					0xff         	// Dump Program key
    #define fSHIFTDEPT					0xff        	// Alfa Shift 1 (xchange ASCII<->QuWei)
    #define fSHIFTKEY					0x02
    #define fSHIFT3					0xff        	// Alfa Shift 3
    #define fCANCEL					0x11		//cancel,EXIT

    #define fRJFEED					0xff		//feed paper anytime
    #define fBACKSPACE	fRJFEED		//�����ַ�����ʱ,������ɾ�ַ��İ���

#elif (CASE_ER28T)

    #define fCLEAR		0x20			//35 is the scan code.
    #define fDATE		0xff			//Set date
    #define fOCPRINTER	0x10			//open or close printer ,lyq added 20040227
    #define fLOCK		0x08			//Mode lock
    #define fREPORT		0xff			// ReportList Trigger
    #define fPRGTYPE		0x1f          // programming Type key
    #define fPRGNUM		0xff         	// Programming number
    #define fPRGENTER	0x27          // programming Enter
    #define fPRGUP		0xff         	// Programming option invert
    #define fSYSREP		0xff         // system report trigger
    #define fHARDTEST	0xff         // Machine test key
    #define fDUMP		0xff         // Dump Program key
    #define fSHIFTDEPT		0xff         // Alfa Shift 1 (xchange ASCII<->QuWei)
    #define fSHIFTKEY		0x01
    #define fSHIFT3		0xff        // Alfa Shift 3
    #define fCANCEL    	0x17			//cancel,EXIT

    #define fRJFEED		0x00		//feed paper anytime
    #define fBACKSPACE	fRJFEED		//�����ַ�����ʱ,������ɾ�ַ��İ���

//liuj 0716
#else //ER380

    #define fCLEAR		0x28			//35 is the scan code.
    #define fDATE		0x02			//Set date
    #define fOCPRINTER	0x01			//open or close printer ,lyq added 20040227
    #define fLOOKPLU	0xff			//set time
    #define fLOCK		0x08			//Mode lock
    #define fREPORT		0xff			// ReportList Trigger
    #define fPRGTYPE	0x2e          // programming Type key
    #define fPRGNUM		0xff         	// Programming number
    #define fPRGENTER	0x36          // programming Enter
    #define fPRGUP		0xff         	// Programming option invert
    #define fSYSREP		0xff         // system report trigger
    #define fHARDTEST	0xff         // Machine test key
    #define fDUMP		0xff         // Dump Program key
    #define fSHIFTDEPT		0x05         // Alfa Shift 1 (xchange ASCII<->QuWei)

    #define fSHIFTKEY		0x13
    #define fSHIFT3		0xff        // Alfa Shift 3
    #define fCANCEL    0x27			//cancel,EXIT

    #define fRJFEED		0x00		//feed paper anytime
    #define fBACKSPACE	fRJFEED		//�����ַ�����ʱ,������ɾ�ַ��İ���

#endif

#define fTEST		fLOCK			//     �������԰��� //

//Index of discount=======================================================
#define DISC1		(DISC+1)
#define DISC2		(DISC+2)
#define DISC3		(DISC+3)
#define DISC4		(DISC+4)
#define DISC5		(DISC+5)
#define DISC6		(DISC+6)
#define DISC7		(DISC+7)

#define DISCCANCEL	5		/* ȡ������ */

/**************************************************************************/


#define KPTypeNum			(6+2)
#define SPTypeNum			(5)		//lyq added for slip 20040331

#define LogoSize			0			//logo size in bytes for download
/****************** Definitions for TAXTABLE ***********/
/*taxNumber������FIS_CLEARRECORD�е�FTaxSale[5]��FTaxAmt*/
#if defined(FISCAL)
#if defined(CASE_MALTA)
    #define taxNumber			8 	    /* number of tax itemizers*/
#else
    #define taxNumber			4 	    /* number of tax itemizers:4 for PANAMA*/
#endif
#else
    #define taxNumber			3 	    /* number of tax itemizers */
#endif
#define taxCapSize			8 	    /* caption length max 12 */
#define taxTotalOffSet		(taxCapSize+4)    /* Start of totalizer in record */
#define taxRecordSize		(taxTotalOffSet+2*13)     /* size of 1 tax record */
//    struct  REPSIZE Size[REPDEFMAX]      /* Totalizer Lay Out for function */

/**************** Definitions Used for Clerk CLERKTABLE **************************/
#define clrkNumber			8
#define clrkCapSize			8 	    /* caption length max 12 */
#define clrkRecordSize		(clrkCapSize+1+3)      /* size of 1 Clerk record */

/**************** Definitions Used for SALPERTABLE **************************/
// liuj 0716
#if(DD_FISPRINTER==1)
    #define salNumber			1
#else
    #define salNumber			50
#endif
// liuj 0716
#define salRecordSize		9/* size of 1 Salesperson record */
#define salCapSize			8/* caption length max 24 */

/**************** Definitions Used for Time Zone ZONETABLE **************************/
#define zoneNumber			12
//    WORD    Start[24]	    /* start of zone max 24 */

/**************** Definitions Used for Day of Week DAYTABLE **************************/
#define dayNumber			7

/**************** Definitions Used for MONTHTABLE **************************/
/* When DEBET is set Months are used for SalesPerson */
#define monthNumber			12

/****************** Definitions for  PORTTABLE *************************/
#if CASE_ER380
#define portNumber			3	    /* number of PORT */
#else
#define portNumber			2	    /* number of PORT */
#endif
#define portCapSize			8	    /* caption length max 24 */
#define portRecordSize		0  /* size of 1 PORTRecord */

#if 0	//cc 20070930
    #define portTypeNum		9	   			// ccr epos
#endif
#define portTypeNum		7
#define portProNum          portTypeNum	   // ccr epos

/*   ***************** Definitions for  OFFTABLE ************************    */
#define offNumber			5	    /*    number of OFF     */
#define offCapSize			16	    /*    caption length max 24     */
#define offPriUSize			3		/*    Bytes for OFF Price u      */
#define offRecordSize		(offCapSize+1+2*4+1+1+offPriUSize+4)     /*    size of 1 OFF record     */


/*   ***************** Definitions for  GROUPTABLE ************************    */
#define grpNumber			10	    /*    number of Groups, max 250    */
#define grpCapSize			16	    /*    caption length max 24     */
#define grpTotalOffSet		(grpCapSize+2)    /*    Start of totalizer in record     */
#define grpRecordSize		(grpTotalOffSet+2*20)     /*    size of 1 Group record     */
//        struct  REPSIZE Size[REPDEFMAX]      /*    Totalizer Lay Out for Groups     */


/*   *************** Definitions for   for the DEPTTABLE *****************    */
//    liuj 0716
#if( CASE_WISE158)
    #define depNumber			48
#else
    #define depNumber			26	    /* number of Departments */
#endif
//    liuj 0716
#define depRandomSize		0      	/*    max random size is 7 bytes     */
#define depCapSize			22	    /*    caption length max 24     */
#define depPriceSize		4		/*    max size is 4     */
#define depPriMaxSize		4		/*    max size is 4     */
#define depTotalOffSet		(depRandomSize+depCapSize+depPriceSize+depPriMaxSize+5+(taxNumber!=0)*1)    	/*    Start of totalizer in record     */
#define depRecordSize		(depTotalOffSet+2*16)     	/*    size of 1 Department record     */
//        struct  REPSIZE Size[REPDEFMAX]      	/*    Totalizer Lay Out for dept     */


/*   ***************** Definitions for  PLUTABLE ************************    */
#define pluNumber			10	    	/*    number of Plus     */
#define pluRandomSize		7	     	/*    max random size is 7 bytes     */
#define pluCapSize			22		    /*    caption length max 24     */
#define pluLevel			1		    /*    number of price levels, max is 4    */
#define pluPriceSize		4		    /*    max is 10 digits     */
#define pluCost			0
#define pluInvSize			5		    /*    number of bytes for inventory     */
#define pluTotalOffSet		(pluRandomSize+pluCapSize+(offNumber>0)*2+1+(pluLevel*pluPriceSize)+(pluCost!=0)*pluPriceSize+pluInvSize)	    	/*    Start of totalizer in record     */
#define pluRecordSize		(pluTotalOffSet+14)	   	/*    size of 1 PLU record, 8 is the total data size     */

//Link & DeptHi set by AP.Options.Plu
//  SIZE Size[REPDEFMAX]      /* Totalizer Lay Out for PLU's */


/*   ***************** Definitions for  TENDTABLE **********    */
#define tendNumber			6 	    /*  PANANM:��Ҫ����6(˰�ش洢����)  number of tendering functions     */
#define tendCapSize			8 	    /*    caption length max 12     */
#define tendTotalOffSet		(tendCapSize+5)    /*    Start of totalizer in record     */
//    #define tendRecordSize		(tendTotalOffSet+2*7+(clrkNumber+salNumber)*5*2)     /*    size of 1 tendering record     *//    /cc 20070611
#define tendRecordSize		(tendTotalOffSet+2*9+(clrkNumber+salNumber)*7*2)     /*    size of 1 tendering record     */
//        struct  REPSIZE Size[REPDEFMAX]      /*    Totalizer Lay Out for function     */

/*   ***************** Definitions for  PORATABLE **********    */
#define poraNumber			6 	    /*    number of PO & RA functions     */
#define poraCapSize			8 	    /*    caption length max 12     */
#define poraTotalOffSet		(poraCapSize+4)    /*    Start of totalizer in record     */
#define poraRecordSize		(poraTotalOffSet+2*8+(clrkNumber+salNumber)*6*2)     /* size of 1 record */
//        struct  REPSIZE Size[REPDEFMAX]      /*    Totalizer Lay Out for function     */


/*   ***************** Definitions for  CORRECTABLE **********    */
#define corrNumber			4  	    /*    number of correction functions     */
#define corrCapSize			12  	    /*    caption length max 24     */
#define corrTotalOffSet		(corrCapSize+2)     /*    Start of totalizer in record     */
#define corrRecordSize		(corrTotalOffSet+2*9+(clrkNumber+salNumber)*9*2)     /*    size of 1 record     */
//        struct  REPSIZE Size[REPDEFMAX]      /*    Totalizer Lay Out for function     */

/*   ***************** Definitions for  DISCTABLE **********    */
#define discNumber			4 	    /*    number of correction functions     */
#define discCapSize			8  	    /*    caption length max 12     */
#define discTotalOffSet		(discCapSize+10)     /*    Start of totalizer in record     */
#define discRecordSize		(discTotalOffSet+2*7+(clrkNumber+salNumber)*7*2)     /*    size of 1 record     */
//        struct  REPSIZE Size[REPDEFMAX]      /*    Totalizer Lay Out for function     */

/*   ***************** Definitions for CURRTABLE **********    */
#define currNumber			5 	    /*    number of foreign currency     */
#define currCapSize			8 	    /*    caption length max 12     */
#define currTotalOffSet		(currCapSize+12)    /*    Start of totalizer in record     */
#define currRecordSize		(currTotalOffSet+2*7+(clrkNumber+salNumber)*5*2)     /*    size of 1 currency record     */
//        struct  REPSIZE Size[REPDEFMAX]      /*    Totalizer Lay Out for function     */


/*   ***************** Definitions for PBTABLE **********    */

#if(DD_FISPRINTER==1)
#define pbNumber			1	 	    /* Close PB functions     */
#else
#define pbNumber			12	 	    /* 12 must,   number of PB functions     */
#endif

#define pbCapSize			8 	    /*    caption length max 24     */
#define pbTotalOffSet		(pbCapSize+2)    /*    Start of totalizer in record     */
#define pbRecordSize		(pbTotalOffSet+2*6+(clrkNumber+salNumber)*6*2)     /* size of 1 PB function record */
//        struct  REPSIZE Size[REPDEFMAX]      /*    Totalizer Lay Out for function     */

/****************Definitions for  PBTOTAL ***********************/

#if(DD_FISPRINTER==1)
    #define pbNumberOfPb	15   /* Close PB function */
#else
    #define pbNumberOfPb	 45 /* number of PB available */
#endif
//liuj 0716
#define pbRandom			0 	  /* random number size max 14 digits bit 0 to 3 */
#define pbText				8 	  /* text for each PB# max 24 */
#define pbAmtSize			4 	  /* size of pb amount	*/
#define pbtTotalOffset      (2+pbRandom+pbText+1+1+1+(pbAmtSize+1)+(pbAmtSize + 1) * 2)         //ccr 2003-10-31
//WORD Block;BYTE Random[7];char Text[25];BYTE Clerk;BYTE Lines;BYTE Covers;BCD Amt;BCD Disc1;BCD Disc2;
#define pbtRecordSize       (pbtTotalOffset+7+(clrkNumber+salNumber)*5)          // Record size for PBTable report ccr 2003-10-31

#define pbAmtDisc			3		// ccr091224 ����ۿ۽��,pbAmtDisc+pbArtAmt < 8 //
#define pbArtAmt			3 	    /* max amount size for art record */
#define pbQty				3 	    /* max qty for artrecord */
#define pbArtSize			(pbAmtDisc+pbArtAmt+pbQty+1+2) 	    /* ccr091210 size of art record is ArtAmt + Qty + 1 + 2 */
// liuj 0716
#if (pbNumberOfPb<5 || pbNumber<12)
    #define pbNumberOfItems		1
    #define pbNumberOfBlocks	1
#else
    #define pbNumberOfItems		10  /* number of items in 1 table record */
    #define pbNumberOfBlocks	75  /* number table blocks */
#endif

#define pbBlockSize			(pbNumberOfItems * pbArtSize +2) /* max 128 bytes */

//size  = (pbAmtSize + pbText + pbRandom + 6)*pbNumberOfPb
//

/****************** Definitions for DRAWERTABLE ***********/

#define drawNumber			8 	    /*    number of tendering functions     */
#define drawCapSize			8 	    /*    caption length max 24     */
#define drawTotalOffSet		(drawCapSize+2)    /*    Start of totalizer in record     */
//    #define drawRecordSize		(drawTotalOffSet+2*5+(clrkNumber+salNumber)*5*2)     /*    size of 1 Drawer record     *//    /cc 20070611
#define drawRecordSize		(drawTotalOffSet+2*7+(clrkNumber+salNumber)*7*2)     /*    size of 1 Drawer record     */
//        struct  REPSIZE Size[REPDEFMAX]      /*    Totalizer Lay Out for function     */

/**************** Definitions for MODITABLE **************************/
#define modiNumber			20
#define modiCapSize			16	    /* caption length max 24 */

/********************* Definitions for  TOTALSALES**********************/

//    #define totalRecordSize		(2*10+zoneNumber*7+(clrkNumber+salNumber)*5*2)     /*    size of TOTAL SALES record     *//    /cc 20070611
#define totalRecordSize		(2*12+zoneNumber*9+(clrkNumber+salNumber)*7*2)     /*    size of TOTAL SALES record     */
//        struct  REPSIZE Size[REPDEFMAX]      /*    Totalizer Lay Out     */

/****************** Definitions for AGREETABLE ***********/
#define agreeNumber			1 	    /* number of foreign currency */
#define agreeCapSize		12 	    /* caption length max 25 */
#define agreeTotalOffSet	(agreeCapSize+20+18)
#define agreeRecordSize		(agreeTotalOffSet+4)     /* size of 1 currency record */

/****************** Definitions for ICBLOCKTABLE ***********/  //ccr chipcard 2004-07-01
#if (DD_CHIPC==1)
    #define icblockNumber         100
#else
    #define icblockNumber         1
#endif
#define icblockSize        4

/****************** Definitions for CHECKTABLE ***********/  //cc added 2005-03-10
#define	checkNumber	1
//cc added end

//define for the ICCard_Options=============================================

#define IC_CHIPCARD BIT0
#define IC_TYPE_0   BIT1
#define IC_TYPE_1   BIT2
#define IC_TYPE_2   BIT3
#define IC_REPORT   BIT4
#define IC_DISCOUNT BIT5
#define IC_POINTS   BIT6
#define IC_TOT_CC   BIT7
#define IC_DEAD 	 BIT8			//��Ч���Ƿ���Ч

//Index for file address table=============================================

#define AddrTotl	0
#define AddrGroup	AddrTotl+1
#define AddrDept	AddrGroup+1
#define AddrPLU		AddrDept+1
#define AddrPort	AddrPLU+1
#define AddrTend	AddrPort+1
#define AddrPoRa	AddrTend+1
#define AddrDrawer	AddrPoRa+1
#define AddrCorr	AddrDrawer+1
#define AddrDisc	AddrCorr+1
#define AddrCurr	AddrDisc+1
#define AddrTax		AddrCurr+1
#define AddrPBf		AddrTax	+1
#define AddrModi	AddrPBf	+1
#define AddrClerk	AddrModi+1
#define AddrOFF		AddrClerk+1
#define AddrICBlock	AddrOFF+1  //Edit By Ranjer.Hu 2004-06-28
#define AddrSalPer	AddrICBlock+1
#define AddrAgree	AddrSalPer+1
#define AddrRPLU	AddrAgree+1
#define AddrEndP	AddrRPLU+1
#define AddrPBt		AddrEndP+1
#define AddrTrack   AddrPBt	+1
#define AddrMAX		AddrTrack+1

/*************** start arress for applications ****************/

#define RamOfApplVar  0 //Address for save ApplVar
#define RamOfTotal	(RamOfApplVar + (sizeof(APPLICATION_SAVE) & 0xfff0) + 0x10) //
#define RamOfGroup	(totalRecordSize + RamOfTotal)
#define RamOfDept	(grpNumber * grpRecordSize+RamOfGroup)
#define RamOfPLU	(depNumber * depRecordSize+RamOfDept)
#define RamOfPort	(pluNumber * pluRecordSize+RamOfPLU)
#define RamOfTend	(RamOfPort)
#define RamOfPoRa	(tendNumber * tendRecordSize+RamOfTend)
#define RamOfDrawer	(poraNumber * poraRecordSize+RamOfPoRa)
#define RamOfCorr	(drawNumber * drawRecordSize+RamOfDrawer)
#define RamOfDisc	(corrNumber * corrRecordSize +RamOfCorr)
#define RamOfCurr	(discNumber * discRecordSize+RamOfDisc)
#define RamOfTax	(currNumber * currRecordSize+RamOfCurr)
#define RamOfPBf	(taxNumber * taxRecordSize+RamOfTax)
#define RamOfModi	(pbNumber * pbRecordSize +RamOfPBf)
#define RamOfClerk	(modiNumber * modiCapSize +RamOfModi)
#define RamOfOFF	(clrkNumber * clrkRecordSize +RamOfClerk)
#define RamOfICBlock    (offNumber * offRecordSize +RamOfOFF)    //ccr chipcard 2004-07-01
#define RamOfRPLU	(RamOfICBlock+icblockNumber * icblockSize)
#define RamOFSalPer	(RamOfRPLU)
#define RamOFAgree	(salNumber * salRecordSize +RamOFSalPer)
#define RamOfPBt	(agreeNumber * agreeRecordSize +RamOFAgree)
#define RamOfTrack  (pbtRecordSize*pbNumberOfPb+RamOfPBt)
#define RamOfEndP	(pbBlockSize*pbNumberOfBlocks+RamOfTrack)
/*************** start arress for applications ****************/

#define NO_DECIMAL  ApplVar.AP.Flag[0]
/*
0 -> 1,00
1 ->	1
2 -> 1,000
3 -> 1,0
*/
#define COMMA	    ApplVar.AP.Flag[1]
/*
BIT-0	If set then Amount Point instead of Amount Comma
BIT-1	If set then print Info Line 1 (receipt number) Double Height
BIT-2	If set then print Info Line 2 (Time / Date) Double Height
BIT-3	If set then Suppress Receipt Number (R/J/Slip)
BIT-4	If set then Suppress Location/Register (R/J/Slip)
BIT-5	If set then Suppress Clerk (R/J/Slip)
BIT-6	If set then Suppress Date (R/J)
BIT-7	If set then Suppress Time (R/J)
*/
#define AM_PM	    ApplVar.AP.Flag[2]
/*
BIT 0 If set then AM/PM time system
BIT 1 If set then 04/10 TOTAL rounding
BIT 2 if set then Receipt Header Double Height
BIT 3 If set then Receipt Trailer Double Height
BIT 4 If set then Reset Salesperson to 1
BIT 5 If set then don't consolidate in Transaction Buffer
BIT 6 If set then Bonus on Discount Itemizer 1
*/
#define TIME_DATE   ApplVar.AP.Flag[3]
#define KEYTONE     ApplVar.AP.Flag[4]
/* bit 0 if set then no keytone */
/* bit 1 if set then no Alfa Keyboard */
/* bit 2 if set then no Number print in reports (Plu always number */
/* bit 3 if set then don't print report end and power up on journal */
/* bit 4 if set then Item Discount not in Sales, Item, Dept, Group */
/* bit 5 if set then Item/Subtotal discount ONE key (add 1 to func) */
/* bit 6 if set then Salesperson selection compulsory */
/* bit 7 if set then no SalesPerson change in transaction */
#define QTY_I	    ApplVar.AP.Flag[5]
#define SLIP_TOP    ApplVar.AP.Flag[6]
#define SLIP_MAX    ApplVar.AP.Flag[7]
#define SLIPINFO    ApplVar.AP.Flag[8]
#define CLERKFIX    ApplVar.AP.Flag[9]
/*	bit 0 -> if set then clerk selection compulsory */
/*	bit 1 -> if set then clerk fixed to PB# 	*/
/*	bit 2 -> if set then no clerk change in transaction */
/*	bit 3 -> if set then autofinalising when no clerk key */
/*		 with PB # always keycode 701 and normal keycode 901 */
/*	bit 4 -> if set then print clerk descriptor when clerk changed */
/*		 during transaction */
/*	bit 5 -> if set then the first 4 locations of the clerk name are */
/*				are used as a secret 4 digit code */
/*	bit 6 -> if set then the TRAINING clerks are included in report */
/*  Bit 7 -> if set then Press SUBKey must befor Tending */
#if (defined(CASE_MALTA))
#define PREFIX_1   128
#define PREFIX_2   0
#else
#define PREFIX_1    ApplVar.AP.Flag[10]
#define PREFIX_2    ApplVar.AP.Flag[11]
#endif
#define PRICE_LEVEL ApplVar.AP.Flag[12]
#define PVAT	    ApplVar.AP.Flag[13] //
#define LOCATION    ApplVar.AP.Flag[14]	//Location number of ECR
#define REGISTER    ApplVar.AP.Flag[15]	//Register number of ECR
/* #define DENSITY_R   ApplVar.AP.Flag[16] */
#define SECOND	    ApplVar.AP.Flag[16]

/* #define DENSITY_J   ApplVar.AP.Flag[17] */
#define DENSITY     ApplVar.AP.Flag[17]     /* combined into 1 flag */
/*
BIT0 - 0:normal dencity,1:double dencity
*/
#define PBINFO	    ApplVar.AP.Flag[18]
/*
BIT0 - If set Compulsory PB selection
BIT1 - If set display amount instead of PB#
BIT2 - If set then Open PB# (Check#)
BIT3 - If set then Old PB system with checkout function
BIT4 - if set then no receiptnumber increment with PB
#if PBTIME == 1
BIT5 & 6 -	00	PB time system not active
01	PB time system in minutes
10	PB time system in hours
11	PB time system in days
#endif
BIT7 - If set then store DiscItem 1&2 must not be changed by user !!!
*/
#define PBPRINT     ApplVar.AP.Flag[19]
/*
BIT0 - If set then the reprint bill only in MG
BIT1 - If set then after print on slip then slip compulsory
BIT2 - If set then print new balance after close PB
BIT3 - if set then don't print Articles with ZERO amount on BILL
BIT4 - reserved harm
BIT5 - reserved harm
BIT6 - reserved harm
BIT7 - if set then Auto Check Number
*/
#define COMPUTER   ApplVar.AP.Flag[20]	//RS232 port for computer
#define COMPUTER_1    (ApplVar.AP.Flag[20] -1 )	//RS232 port for computer
#define ACTIVE	    ApplVar.AP.Flag[21]
#define CUTTER	    ApplVar.AP.Flag[22]
/*
=1, Enable Receipt cutter
=2, Enable receipt and journal cutter
*/
#define ART_LEVEL   ApplVar.AP.Flag[23]
/*
bit 0 - if set then zero after article
bit 1 - if set to zero at end of transaction
bit 2 - is set then cost price is used for Mix/Match
bit 3 - is set then In Store Marking is active (also RANDOM PLU
MUST be set. format FFRRRRRAAAAAC fixed 13 digits
FF = 21 Identifier
RRRRR = Random Plu Number
AAAAA = Amount
C = check digit
bit 4 - If set then article level also on PLU# key
bit 5 - If set then article level also on DEPRTMENTS
bit 6 - if set then print inventory Qty in PLU sales report if active
*/
#define PLU_PRINT   ApplVar.AP.Flag[24]
// BIT 0 Print PLU # if set
/* bit 4 print Salesperson if set  lyq added 2003\10\23 */
/* bit 5 can change PLU price(PLU FREE)*/
/* bit 6 flags for TALLONS */
/* BIT 7 if set then compulsory multiply key on fixed plu */
#define CRT_LAY_OUT ApplVar.AP.Flag[25]
#define DOT	    	ApplVar.AP.Flag[25] 	    /* if BIT 7 set then print small chinese font */
/* if BIT 7 set then print small chinese font */
/* if BIT 4 set then print the tallon lyq*/
/* if BIT 3 set then collect the flow record lyq2003*/
#define RJPRN	    (TESTBIT(DOT,BIT6))     /* if 0 then r print else j print */
#define PRNHOST		ApplVar.AP.Flag[26]
//BIT0 if set then print the data from host when update
#define DBLHIPRN		ApplVar.AP.Flag[26]
/*
BIT2 Set then print name in double high mode
BIT3 Set then print Head in center
BIT4 Set then print trail in center
*/

#define PROMOTION   ApplVar.AP.Flag[27]
/*			Bit 0: 1-Jolly disabled,0-Jolly enabled
Bit 1: 1-Point Disabled,0-Point Enabled
*/
#define BALANCE	    ApplVar.AP.Flag[28]	   //lyq modify 2003\10\27

#define LMARGE	    ApplVar.AP.Flag[29]
#define BARCODE     ApplVar.AP.Flag[30]
/* port number for barcode scanner, max is 7 */
/* when BIT 3 is set then no prefix in the code */
/* If Bit 4 is set then Magazine Decoding for France */
/* If Bit 5 set then no CTS check but Timer */
/* If Bit 6 is set then also Weigth decoding from barcode */
/* If Bit 7 is set then Extended Instore marking */
/* 02, 20, 26, 28 */
#define SLIP	    ApplVar.AP.Flag[31]     /* 2 bytes for slip */
#define SLIPPORT    (ApplVar.AP.Flag[32] - 1 )
#define CHARSET     ApplVar.AP.Flag[33]
/* set character set used by Controller and epson comp printers */
/* low 4 bit (o - > 15) for External printers */
/* high bit used for internal char set */
#define KPSTART     ApplVar.AP.Flag[34]     /* 8 X 3 bytes for kp's */
#define KPPRICE     ApplVar.AP.Flag[58]
/*	BIT 0 if set then Print also amt on KP
BIT 1 if set then new KP print format for NORIS
BIT 2 if set then print price on KP (also BIT 1 set)
BIT 3 if set then print PLU# on KP (also BIT 1 set)
BIT 4 if set then Short Receipt Header and long when
print PB Bill
BIT 5 if set then enter modifier before article (must
be used with single ticket on department.
BIT 6 if set then print PB Text on Item Receipt and KP
if text active.
BIT 7 if set then only 2 digit receipt number on KP
*/
#define CARDREADER  ApplVar.AP.Flag[59]     /* cardreader connected ? */
#define EFTFLAG 	ApplVar.AP.Flag[60]		/* EFT Type */
/*
0				No EFT
1				Datatraffic Telepas III geintegreerd
2				Datatraffic Telepas III standalone
3				CCV Verifone Tranz 380
4-6				Future use
bit 7 			enable SHIFT if not set
*/
#define SLFLAG	    ApplVar.AP.Flag[60]     /* DITRON Language Flag ? */
/*
bit 0 if set Remote Input
bit 1 if set Data Record
bit 2 if set Remote Request
bit 3 if set Echo Remote Input
bit 4 if set then send print data
bit 7 enable SHIFT if not set
*/
//#define SL_TIMEOUT  ApplVar.AP.Flag[61]     /* SL time out is TIMEOUT * 5.37 msec */
#define EXTRAMN		ApplVar.AP.Flag[61]		/* ��4λ������ʾ��չ�ڴ���Ŀ(ÿ��256K) */
#define COPYRECEIP  ApplVar.AP.Flag[62]     /* Bit0..3, */
/* bit7=1,reset Z# after Z report */

#define ROUNDMASK   ApplVar.AP.Flag[63]     /* type of rounding sales rounding*/
/* 2 is Swiss Rounding on Finalizing Sales amount */
/* 4 is Swiss Rounding on MULT, TAX & Percentage discount */
/* 6 Swiss Rounding on Both */
/* 8 is French Rounding on Finalizing Sales Amount */
/* 16 is French Rounding on MULT, TAX & Percentage discount */
/* 24 French Rounding on Both */
/* 1 Is Swiss Input masking (last digit must be 0 or 5) */
/* BIT 5 if set 12/25 Danish Rounding on Sales Amount */
/* BIT 6 if set 24/50 Norwegian Rounding on Sales Amount */
/* BIT 7 if set 00/10 Rounding (used in Tsjechie) on Sales Amount */
/* Other rounding in System Flag AM_PM */
/****************** General Used Structures & Unions **********************/

//===================================================================================
struct PASSWORD
{
    char PwdX[MAXPWD];
    char PwdZ[MAXPWD];
    char PwdSET[MAXPWD];
    char PwdMG[MAXPWD];
};
//===================================================================================


struct PRINTER
{
    BYTE type;      /* type of printer */
/*
BIT0..BIT 3 used for KP type
BIT4 - not used
BIT5 - If set then print TALON (Total) receipt on KP
BIT6 - If set then Single Qty (1) tickets.
BIT7 - If set then Single tickets per Item.
*/
    BYTE port;      /* serial port */
    BYTE alter;     /* alternative printer */
};

struct KPINFO
{
    BYTE Number;
    BYTE Current;
    BYTE Used;
    BYTE Error;
    BYTE Next;
    struct PRINTER *Prt;
};


/* the structure SIZE is used by the tables which define the totals and
functions. The Data is stored for reporting according to the tlzr's activated.
*/

struct REPSIZE
{
    BYTE    Periods;        /* number of periods, */
    BYTE    Length;     /* length=Cc+Qty+Amt+RetQty+Disc+Cost+1 */
    BYTE    Cc;         /* Customer count size */
    BYTE    Qty;        /* Quantity size */
    BYTE    Amt;        /* Amount size */
    BYTE    RetQty;     /* return only Qty */
    BYTE    Disc;       /* Discounts only Amount */
    BYTE    Cost;       /* Cost only Amount */
};

/* the structure TOTAL is used by the routine which adds the data to the */
/* activated tlzr's in a total or function */

struct TOTAL
{
    BCD Cc;         /* �˿����� */
    BCD Qty;        /* ��Ʒ���� */
    BCD Amt;        /* �����ܼ� */
    BCD RetQty;     /* �˻��������� */
    BCD Disc;       /* �ۿۻ��� */
    BCD Cost;       /* ���ۻ��� */
};

/* the structure report is used by the print report routines */

struct REPORT
{
    BYTE System;    /* if non zero then system report */
    BYTE Period;
    BYTE Type;
    WORD Start;         /* Start number of PLU, DEPT etc */
    WORD End;
    BYTE PointerType;   //��ʾ�����������͵�ͳ�����ݣ�1-Clerk,2-Hour,3-Day,4-Month,5-Saleper
#if NETTEST == 1
    WORD Pointer;    /* current processed pointer number */
    WORD PointerEnd;
#else
    BYTE Pointer;    /* current processed pointer number */
    BYTE PointerEnd;
#endif
    WORD Size;
    BYTE OffSet;
};

struct FIXEDREPORT
{
    char Name[17];
    BYTE PrintLayOut;
    BYTE Options;
    BYTE Number;        /* depending on option Group or Dept number */
    BYTE Period;
    BYTE PointerType;
    BYTE Link[16];      /* link with a report */
};

struct TRANSRECORD
{
    union KEY Key;
    BYTE Group;
    BCD Qty;
    BCD Amt;
};

struct PBARTICLE
{
    struct TRANSRECORD Rec;
    BCD Total;
    BYTE Flag;
    BYTE Random[7];
#if pbAmtDisc
    BCD Disc;//ccr091210
#endif
};

/****************** Structures used for the AGREE *************************/
struct AGREETABLE
{
    WORD Number;
    WORD RecordSize;
    BYTE    TotalOffSet;    /* Start of totalizer in record */
    BYTE CapSize;
};
/****************** Structures used for the AGREE *************************/
struct AGREERECORD
{
    char    Name[25];
    char    Addr[20];
    char    Tax[18];
    BYTE    Total[4];
};


/****************** Structures used for the PORT *************************/
struct PORTTABLE
{
    WORD    Number;     /* number of Groups */
    WORD    RecordSize;     /* size of 1 Group record */
    BYTE    CapSize;        /* caption length max 24 */
};


struct PORTRECORD
{
    char    Name[portCapSize+1];
    BYTE    Type;           /* '1','2','3','4','5'.. */
    BYTE    Prot[portProNum];    // lyq modified 20040331
    char    Tele[15];
};
//  �޸�PORTRECORD�еĶ��壬����ͬʱ�޸�Bios_dir.i30�е�����ֵ
//	SioName=0			;��ʾ�������ƴ��λ��
//	SioType=portCapSize+1;��ʾ�������ʹ��λ�ã�'1','2','3','4','5'.��
//	SioProt= SioType+1	;��ʾ����Э����λ��
//	SioTele��SioProt +6	;��ʾ���ڵ绰����λ��
/****************** Structure used for the TOTAL SALES Totalizer ***********/

struct TOTALSALES
{
    WORD    RecordSize;     /* size of TOTAL SALES record */
    struct  REPSIZE Size[REPDEFMAX];      /* Totalizer Lay Out */
};

/****************** Structures used for the OFF *************************/
struct OFFTABLE
{
    WORD    Number;     /* number of Groups */
    WORD    RecordSize;     /* size of 1 Group record */
    BYTE    CapSize;        /* caption length max 24 */
    BYTE    PriUSize;       /* max is 4 */
};


struct OFFRECORD
{
    char    Name[25];
    BYTE    Type;
    BYTE    DateFrom[2];
    BYTE    DateTo[2];
    BYTE    TimeFrom[2];
    BYTE    TimeTo[2];
    BYTE    WeekDay;
    union
    {
        BYTE    Discount[9];
        struct
        {
            BYTE    NumItems;
            BYTE    PriceU[4];
            BYTE    PriceP[4];
        }   TYPE1;
    } OFFVal;
};

/****************** Structures used for the GROUPS *************************/

struct GROUPTABLE
{
    WORD    Number;     /* number of Groups */
    WORD    RecordSize;     /* size of 1 Group record */
    BYTE    TotalOffSet;    /* Start of totalizer in record */
    BYTE    CapSize;        /* caption length max 24 */
    struct  REPSIZE Size[REPDEFMAX];      /* Totalizer Lay Out for Groups can be trapped for :*/
/* Standard */
/* Clerk */
/* Hour */
/* Day of Week */
/* Month of Year */
};

struct GROUPRECORD
{
    WORD    Family;    /* 16 Family selection max  */
    char    Name[25];       /* max 24 with terminator */
};


/****************** Structures used for the DEPARTMENTS *************************/

struct DEPTTABLE
{
    WORD    Number;     /* number of Departments */
    WORD    RecordSize;     /* size of 1 Department record */
    BYTE    TotalOffSet;    /* Start of totalizer in record */
    BYTE    RandomSize;     /* max random size is 7 bytes */
    BYTE    CapSize;        /* caption length max 24 */
    BYTE    PriceSize;      /* max size is 4 */
    BYTE    PriMaxSize;     /* max size is 4 */
    struct  REPSIZE Size[REPDEFMAX];      /* Totalizer Lay Out for dept */
/* can be trapped for : */
/* Standard */
/* Clerk */
/* Hour */
/* Day of Week */
/* Month of Year */
};

struct DEPTRECORD
{
    BYTE    Random[7];  /* max 7 bytes is 14 digits */
    char    Name[CAPSIZEMAX];   /* max 24 with terminator */
    BYTE    Group;  /* group selection max 0xff also for print bill,=0 not allon to a group */
    BYTE    Print;  /* print lay out */
    BYTE    Options;
/*
Dept.Options
BIT 0 - If set then price is negative
BIT 1 - if set then Zero Price not allowed
BIT 2 - if set Single Ticket
BIT 3 - if set then Double ticket (also Single set)
BIT 4 - Print Line after article
BIT 5 - if Set single item when start of sale on TEND#1
BIT 6 - Add to Discount Itemizer 1
BIT 7 - Add to Discount Itemizer 2
*/
    BYTE    Tax;    /* Tax selection max 8 */
    BYTE    Kp;     /* Kp aansturing max 8 */
    BYTE    Price[5];
    BYTE    PriceMax[5];
/* flags */
};

/****************** Structures used for the PLU'S *************************/

struct PLUTABLE
{
    WORD    Number;     /* number of Plus */
    WORD    RNumber;        /* Number of RandomPLU */
    WORD    RecordSize;     /* size of 1 PLU record */
    BYTE    TotalOffSet;    /* Start of totalizer in record */
    BYTE    RandomSize;     /* max random size is 7 bytes */
    BYTE    CapSize;        /* caption length max 24 */
    BYTE    Level;      /* number of price levels */
    BYTE    PriceSize;      /* max is 10 digits */
    BYTE    Cost;
    BYTE    InvSize;        /* number of bytes for inventory */
    struct  REPSIZE Size[REPDEFMAX];      /* Totalizer Lay Out for PLU's */
};              /* can be trapped for : */
/* Standard */
/* Clerk */
/* Hour */
/* Day of Week */
/* Month of Year */

struct PLURECORD
{
    BYTE    Random[7];  /* max 7 bytes is 14 digits */
    char    Name[CAPSIZEMAX];   /* max 24 with terminator */
    WORD    OFFIndex;   // Index of OFFPrice
    BYTE    Dept;       /* department selection max 0xff */
    BYTE    DeptHi;             /* High Dept Number */
    BYTE    Price[4][5];      /* max price is 10 digits is 5 bytes */
    BYTE    Cost[5];          /* max 4 levels with 1 cost price */
    WORD    Link;               /* PLU Link */
    BCD     Inventory;  /* plu inventory */
/* scale */
/* flag */
/* inventory */
};

/****************** Structures used for the Tendering functions ***********/
/* Cash, CC, Check */

struct TENDTABLE
{
    BYTE    Number;     /* number of tendering functions */
    WORD    RecordSize;     /* size of 1 tendering record */
    BYTE    TotalOffSet;    /* Start of totalizer in record */
    BYTE    CapSize;        /* caption length max 12 */
    struct  REPSIZE Size[REPDEFMAX];      /* Totalizer Lay Out for function */
};

struct TENDRECORD
{
    BYTE    Print;
    BYTE    Options;
/*
BIT 0 - If set then open drawer
BIT 1 - if set then must entry on charge
BIT 2 - if set then not entry on charge and card
BIT 3 - if set then  must entry CardNo
BIT 4 - if set then overtender is tipp
BIT 5 - if set then no tax calc
BIT 6 -
BIT 7 -
*/
    BYTE    Drawer;
    BYTE    Over;      /* over tender, tip if bit set */
    BYTE    MaxEntry;
    char    Name[13];       /* max 12 with terminator */
};

/****************** Structures used for PO/ RA functions ***********/

struct PORATABLE
{
    BYTE    Number;     /* number of PO & RA functions */
    WORD    RecordSize;     /* size of 1 record */
    BYTE    TotalOffSet;    /* Start of totalizer in record */
    BYTE    CapSize;        /* caption length max 12 */
    struct  REPSIZE Size[REPDEFMAX];      /* Totalizer Lay Out for function */
};

struct PORARECORD
{
    BYTE    Print;
    BYTE    Options;
/*
BIT 0 - If set then open drawer
BIT 1 - if set then
BIT 2 - if set then
BIT 3 - if set then
BIT 4 - if set then
BIT 5 - if set then
BIT 6 -
BIT 7 -
*/
    BYTE    Drawer;
    BYTE    MaxEntry;
    char    Name[13];       /* max 12 with terminator */
};

/****************** Structures used for Correction functions ***********/

struct CORRECTABLE
{
    BYTE    Number;     /* number of correction functions */
    WORD    RecordSize;     /* size of 1 record */
    BYTE    TotalOffSet;    /* Start of totalizer in record */
    BYTE    CapSize;        /* caption length max 24 */
    struct  REPSIZE Size[REPDEFMAX];      /* Totalizer Lay Out for function */
};

struct CORRECRECORD
{
    BYTE    Print;
    BYTE    Options;
    char    Name[13];       /* max 12 with terminator */
};

/****************** Structures used for DISCOUNT functions ***********/

struct DISCTABLE
{
    BYTE    Number;     /* number of correction functions */
    WORD    RecordSize;     /* size of 1 record */
    BYTE    TotalOffSet;    /* Start of totalizer in record */
    BYTE    CapSize;        /* caption length max 12 */
    struct  REPSIZE Size[REPDEFMAX];      /* Totalizer Lay Out for function */
};

struct DISCRECORD
{
    BYTE    Print;
    BYTE    Options;
    BYTE    Fixed[3];
    BYTE    Tax;
    BYTE    Max[4];
    char    Name[13];       /* max 12 with terminator */
};

/****************** Structures used for Foreign Currency functions ***********/

struct CURRTABLE
{
    BYTE    Number;     /* number of foreign currency */
    WORD    RecordSize;     /* size of 1 currency record */
    BYTE    TotalOffSet;    /* Start of totalizer in record */
    BYTE    CapSize;        /* caption length max 12 */
    struct  REPSIZE Size[REPDEFMAX];      /* Totalizer Lay Out for function */
};

struct CURRRECORD
{
    BYTE    Options;
    BYTE    Drawer;
    BYTE    Prefix1;
    BYTE    Prefix2;
    BYTE    BuyRate[4];
    BYTE    SellRate[4];
    char    Name[13];       /* max 12 with terminator */
};

/****************** Structures used for Previous Balance functions ***********/

struct PBTABLE
{
    BYTE    Number;     /* number of PB functions */
    WORD    RecordSize;     /* size of 1 PB function record */
    BYTE    TotalOffSet;    /* Start of totalizer in record */
    BYTE    CapSize;        /* caption length max 24 */
    WORD    NumberOfPb;     /* number of PB available */
    BYTE    Random;   /* random number size max 14 digits bit 0 to 3 */
/* bit 4 not used */
/* bit 5 if set then store random plu in trackbuffer*/
/* bit 6 if set then specail PB invoice Number and storage of MAX 200 numbers with 7 digits amount and sign */
/* bit 7 if set then Extra PB Trailer of fixed 50 lines which is printed on the receipt with Print Bill function */
    BYTE    Text;     /* text for each PB# max 24 */
    BYTE    AmtSize;      /* size of pb amount	*/
    BYTE    ArtAmt;     /* max amount size for art record */
//#if pbAmtDisc
//BYTE 	Disc;//ccr091210
//#endif
    BYTE    Qty;        /* max qty for artrecord */
    BYTE    ArtSize;        /* size of art record is ArtAmt + Qty + 1 + 2 */
    BYTE    NumberOfItems;     /* number of items in 1 table record */
    WORD    NumberOfBlocks; /* number table blocks */
    WORD    BlockSize;
    WORD    PBTRecordSize;
    BYTE    PBTTotalOffset;

    struct  REPSIZE Size[REPDEFMAX];      /* Totalizer Lay Out for function */
    struct  REPSIZE PBTSize[REPDEFMAX];      /* Totalizer Lay Out for function */
};

struct PBRECORD
{
    BYTE    Print;
    BYTE    Options;
    char    Name[13];       /* max 12 with terminator */
};

struct PBTOTAL    /* struct used for PB storage */
{
    WORD Block;
    BYTE Random[7];
    char Text[25];
    BYTE Clerk;
//ccr091125PB.SalPer? BYTE SalPer;
    BYTE Lines;
    BYTE Covers;
    BCD Amt;
    BCD Disc1;
    BCD Disc2;
#if CUBA1 == 1
    BYTE Count[3];      /* Extra counter for CUBA */
#endif
};

/****************** Structures used for the Drawer Totalizers ***********/

struct DRAWERTABLE
{
    BYTE    Number;     /* number of tendering functions */
    WORD    RecordSize;     /* size of 1 Drawer record */
    BYTE    TotalOffSet;    /* Start of totalizer in record */
    BYTE    CapSize;        /* caption length max 24 */
    struct  REPSIZE Size[REPDEFMAX];      /* Totalizer Lay Out for function */
};

struct DRAWERRECORD
{
    BYTE    Print;
    BYTE    Options;
    char    Name[13];       /* max 12 with terminator */
};



/****************** Structures used for the TAX Totalizers ***********/

struct TAXTABLE
{
    BYTE    Number;     /* number of tax itemizers */
    WORD    RecordSize;     /* size of 1 tax record */
    BYTE    TotalOffSet;    /* Start of totalizer in record */
    BYTE    CapSize;        /* caption length max 12 */
    struct  REPSIZE Size[REPDEFMAX];      /* Totalizer Lay Out for function */
};

struct TAXRECORD
{
    char    Name[13];       /* max 12 with terminator */
    BYTE    Rate[3];        /* rate 0.00% to 9999.00% */
    BYTE    Options;
                             /* Bit0:=1,(VAT)Ϊ����˰(��ֵ˰),��:���ۼ۸����˰;
                                     =0,(Add on)����˰(Ӫҵ˰),��:���ۼ۸񲻰���˰ */
                             /* BIT1:��ӡ˰����(Bit0Ϊ1ʱ��Ч,����ӡ����˰��)  */
                             /* BIT2:��ӡ0˰��(Bit0Ϊ1ʱ��Ч)     */
                             /* BIT3: GST tax if set*/
                             /* BIT4:��ӡ˰��(Bit0Ϊ1ʱ��Ч)     */
};



/**************** Structure Used for Modifiers **************************/

struct MODITABLE
{
    WORD    Number;
    BYTE    CapSize;        /* caption length max 24 */
};

struct MODIRECORD
{
    char Name[25];
};

/**************** Structure Used for ICBlock **************************/
//ccr chipcard 2004-07-01
struct ICBLOCKTABLE
{
    WORD    Number;
    BYTE    BlockSize;      /* caption length max 10 */
};

struct ICBLOCKRECORD
{
    unsigned long ICCardNO;
};


/**************** Structure Used for Clerk Info **************************/

struct CLERKTABLE
{
    WORD    Number;
    WORD    RecordSize;     /* size of 1 Clerk record */
    BYTE    CapSize;        /* caption length max 12 */
};

struct CLERKRECORD
{
    char Name[13];
    BYTE Options;
            //BIT0:  =0,training clerk
            //BIT1:  only clerk report
            //BIT2:  Z allowed?
            //BIT3:  prog allowed
            //BIT4,BIT5:  drawer 1 ?
    char Passwd[3];

};

/**************** Structure Used for Time Zone Info **************************/

struct ZONETABLE
{
    BYTE    Number;
    WORD    Start[24];      /* start of zone max 24 */
};

/**************** Structure Used for Check Time Info **************************/
// cc added 2005-03-10
//cc added end
/**************** Structure Used for Day of Week Info **************************/
struct DAYTABLE
{
    BYTE    Number;
};

/**************** Structure Used for MONTH Info **************************/
/* When DEBET is set Months are used for SalesPerson */

struct MONTHTABLE
{
    BYTE    Number;
};


/**************** Structure Used for Salesperson Info **************************/

struct SALPERTABLE
{
    WORD    Number;
    WORD    RecordSize; /* size of 1 Salesperson record */
    BYTE    CapSize;    /* caption length max 24 */
};

struct SALPERRECORD
{
    char Name[25];
    BYTE Options;
};

struct OPTIONTABLE                /* structure holding new options */
{
    BYTE    ChinaChar;
    BYTE    Plu;    /* BIT 0 - Linked Plu, BIT 1 - large Dept# */
    BYTE    InvAmt; /* PLU amount inventory size */
    BYTE    Cost;   /* BIT 0 if set then ALL Salesdata ex VAT */
/* If DANKORT set and BIT 0 not then always */
/* Subtract TAX 1 from Net Sales */
/* BIT 1 if set COSTPRICE system Active */
/* BIT 2 if set then report difference between */
/* entered price and programmed price as discount */
/* BIT 3 if set then print costcode on rececipt */
/* BIT 4 if set then don't print price in Cost */
/* Code */
/* BIT 5 Calculate Profit Ratio */
    WORD    TendBuffer;     /* Number of Entries in Tender Buffer */
    BYTE    TendAmtSize;
    BYTE    TendNumberSize;
    BYTE    Modulo;
    BYTE    WeightF[8];     /* WeightFactor for Modulo Check */
    BYTE    NotUsed;
};

    #if DEBET == 1
/**************** Structure Used for Debet Card Info *****************/


struct DEBETTABLE
{
    WORD List;      /* black list entries */
    WORD NonSub;     /* Non subtract table */
    WORD Shift;     /* Shift entries */
    WORD SalPer;    /* Salesperson entries */
    BYTE Print;     /* Print Format */
/* BIT 0 -> Journal */
/* BIT 1 -> Receipt */
/* BIT 2 -> Double Heigth */
/* BIT 3 -> Slip */
/* BIT 4 -> Compulsory Slip */
/* BIT 5 -> 2 line */
    BYTE Option1;
/* BIT 0 -> Minus Allowed */
/* BIT 1 -> Add Change */
    BYTE Option2;
    BYTE PFormat;     /* Print Format */
/* BIT 0 -> print Company Code */
/* BIT 1 -> print Card# */
/* BIT 2 -> print Old Balance */
/* BIT 3 -> print New Balance */
    BYTE Max[3];    /* max amount */
    BYTE DisableShift;  /* shift used for disable card */
    BYTE DisableSalPer;  /* SalesPerson used for disable card */
    BYTE FreeVendId;    /* Shift on CARD used for FreeVend */
    BYTE FreeVendShift; /* shift used for freevend */
    BYTE StartSalPer;   /* start Salesperson on GiroVend */
    BYTE Free[12];  /* future use */
};
    #endif
/*************************************************************************/

/*********** definition of the all texts used  ***********/

struct GRAPFORPRN
{
    BYTE    PictNo;//0:no picture for use
    BYTE    DateFrom[4];
    BYTE    DateTo[4];
};


struct APPTEXT
{
    char    Header[8][PRTLEN+1];    /* PRTLEN+1 max width printer 32 char */
    char    ReportType[17][REPWIDTH];
    char    SlipHeader[6][SHEADWIDTH+1];
    char    Trailer[6][PRTLEN+1];//PRTLEN+1
};


struct PROMPTTEXT
{
#if(DD_ZIP==1 || DD_ZIP_21==1 || DD_LCD_1601==1)
    char    Caption[115][CAPWIDTH]; /*    Fixed Captions used by the program     */
#elif (defined(CASE_MALTA))
    char    Caption[115][CAPWIDTH];
#else
    char    Caption[79][CAPWIDTH];  /* Fixed Captions used by the program */
#endif
    char    DayCap[7][dCAPWIDTH];
    char       Title[PRTLEN+1];     //
    char    Message[60][MESSWIDTH];
    char    MonthCap[12][mCAPWIDTH];
    char    LineCap[Line_Items][lCAPWIDTH+1];   // LineCap[Line_Items]
    char    TypeCap[SETUPMAX][tCAPWIDTH];//ccr chipcard

};

struct PROMRECORD
{
    WORD    Freq;
    BYTE    JollyMin[4];
    BYTE    PointVal[4];
    BYTE    PointMin[4];
    BYTE    GrapIdx;
    char    Memo[PRTLEN+1];
};


struct  ICCARDSETTABLE  //ccr chipcard 2004-07-01
{
    BYTE Options;
    BYTE Password[3];
    ULONG PosCode;
    BYTE Value[3];
    BYTE MiniNum[3];

} ;
/*********************** Structure Used for IPSet ***********************/

//***** Flags for TNETWORK.Option
#define DHCPFlag        BIT0    //����DHCP��ʽ
#define IPByDHCPFlag    BIT1    //����DHCP��ʽʱ,�õ���IP��ַ,������DHCPʱ,�˱�־�Զ�����
#define MINISTRYFlag    BIT2
#define DNSPROGRESSFlag BIT3    //�Ѿ��ύDNS��������

#define PRINTNETSET     BIT7 //�Ƿ��ӡ�˵�

struct TNETWORK
{
    BYTE    Option;
    BYTE    IPAddress[4];
    WORD    ClientPort;
    BYTE    ServerIP[4];
    WORD    ServerPort;
    BYTE    GateWay[4];
    BYTE    IPMask[4];
    BYTE    PrimaryDNS[4];//ccr2017-09-14
    BYTE    SecondDNS[4];//ccr2017-09-14
    char    ServerURL[48];
    char    APN[48];
    char    UserName[16];
    char    Password[16];
    BYTE    ECR_ID[10];  //ccr2017-09-14PERSONAL CODE NUMBER 9λ����
    BYTE    SecurityCode[32];  //ccr2017-10-19 personal security code
};//<<<<<<<<<<<<<<<<

typedef struct TNETWORK* PIPSET;
//ccr2017-04-14>>>>>>>>>>>>>>>>
struct TTAXSET {
    ULONG TAXID;        //TLD66000003�е�6λ����:66000003
};

struct TEJ {
    ULONG ZReceiptDate; //��������Ҫ��ӡ��Z�������վ�����:YYMMDD
};
//ccr2017-04-14<<<<<<<<<<<<<<<<<<
/*********** definition of the complete application structure ***********/
/* Please note that Flag is used in ASM files so please check when
structure AP changes
*/

struct APPLICATION
{

    BYTE                FirmKeys[FIRMKEYS];     /* firm key used when lock not in RG or MG */
    BYTE                Manager[16];        /* manager table max 128 keys */
    BYTE                Flag[SYSFLAGS];  /* system flags for general options */

    WORD                KeyTable[MAXKEYB];      /* KeyTable */

    UnLong              StartAddress[AddrMAX];

    struct PASSWORD     ModePwd;
    struct CCONFIG      Config;

    struct CLERKTABLE   Clerk;
    struct SALPERTABLE  SalPer;
    struct FIXEDREPORT  ReportList[XZNUM];

    struct TOTALSALES   Sales;
    struct CORRECTABLE  Correc;
    struct CURRTABLE    Curr;
    struct DEPTTABLE    Dept;
    struct DISCTABLE    Disc;
    struct DRAWERTABLE  Draw;
    struct GROUPTABLE   Group;
    struct MODITABLE    Modi;
    struct PBTABLE      Pb;
    struct PLUTABLE     Plu;
    struct PORATABLE    PoRa;
    struct TAXTABLE     Tax;
    struct TENDTABLE    Tend;
    struct ZONETABLE    Zone;
    struct DAYTABLE     Day;
    struct MONTHTABLE   Month; /* for DEBET month used as salesperson */
    struct OPTIONTABLE  Options;
    struct OFFTABLE     OFFPrice;
    struct PORTTABLE    Port;
    struct PROMRECORD   Promotion;
    struct AGREETABLE   Agree;
    struct ICBLOCKTABLE ICBlock;  //ccr chipcard 2004-07-01
    struct TTAXSET      TaxSet;//ccr2017-04-10
    struct TNETWORK NetWork;      //hf added 20040907
};

struct DEFAULT
{
    struct CORRECRECORD Correc[corrNumber];
    struct CURRRECORD   Curr[currNumber];
    struct DISCRECORD   Disc[discNumber];
    struct DRAWERRECORD Draw[drawNumber];
    struct PBRECORD     PbF[pbNumber];
    struct PORARECORD   PoRa[poraNumber];
    struct TENDRECORD   Tend[tendNumber];
    struct TAXRECORD    Tax[taxNumber];
    struct MODIRECORD   Modi;
    struct CLERKRECORD  Clerk;
    struct GROUPRECORD  Group;
    struct DEPTRECORD   Dept;
    struct PLURECORD    Plu;
    struct SALPERRECORD SalPer;
    struct OFFRECORD    OFFPrice;
    struct PORTRECORD   Port;
    struct GRAPFORPRN   Graph;
    struct AGREERECORD  Agree;
    struct ICBLOCKRECORD ICBlock;  //ccr chipcard 2004-07-01
    struct TNETWORK NetWork;      //hf added 20040907
};


struct SYSFLAGIDX
{
    BYTE    Index;
    BYTE    Max;
    BYTE    Bit;
    BYTE    Invert;
#if(DD_ZIP==1 || DD_ZIP_21==1 || DD_LCD_1601==1)
    char        Name[17];
#endif
};

struct FARADDR
{
    CONSTCHAR *Addr;
};

struct XZREPORT
{
    BYTE    Index;
#if(DD_ZIP==1 || DD_ZIP_21==1 || DD_LCD_1601==1)
    char Name[16];
#else
    char    Name[9];
#endif
};

#if defined(FISCAL)
#define MAXUSERLINE				2
#define INFOISOK				BIT4
#define INFOOVER				BIT5

/*ccr2014-PANAMA**************************************
����1+USERINFO:����˿�����
����2+USERINFO:����˿�RUC
����3+USERINFO:�����ӦDebit�վݵ������վݺ�
����4+USERINFO:����˿�˰����
����5+USERINFO:����˿͵�ַ
Ϊ������������ݽṹ:
************************************************/
#define   cUSERMAX  5       //��������û���Ϣ����

#define cFCNameID   0	//1-�˿�����
#define cFCRUCID	1	//2-�˿�RUC,
#define cFCDebitID  2	//3-�����վݺ�
#define cFCAddrID   3	//4-�˿͵�ַ
#define cFVatNoID   4   //5-��������վݵĹ˿�˰����


#define cFCName   BIT0	//1-�˿�����
#define cFCRUC	  BIT1	//2-�˿�RUC,
#define cFCDebit  BIT2	//3-�����վݺ�
#define cFCAddr   BIT3	//4-�˿͵�ַ
#define cFVatNo   BIT4   //5-��������վݵĹ˿�˰����

//�������֮ǰ������û���Ϣ
struct TUSERINPUT{
    BYTE InputIDX;     //��������:1-�˿�����,2-�˿�RUC,3-�����վݺ�,4-�˿͵�ַ,5-�˿�˰����
    BYTE InputType;    //�Ѿ��������������,bit0-�˿�����,bit1-�˿�RUC,bit2-�����վݺ�,bit3-�˿͵�ַ,bit4-�˿�˰����
    char FCName[PRTLEN+1];	//1-�˿�����
    char FCAddr[60];	//2-�˿͵�ַ
    char FCRUC[20];		//3-�˿�RUC,
    char FVatNo[16];    //4-��������վݵĹ˿�˰����
    char FCDebit[10];	//5-�����վݺ�
};

#endif


#if (pbBlockSize>=128)
    #error "Too large!!!"
#endif

#include "ICCard.h"		//ccr chipcard
//#include "Fiscal.h"
#include "Flowbill.h"
//#include "EJournal.h"

#define SETUPMARIN		0	// ������,����������ʾ��Ϣ��ʾλ�� //
#define DATECHAR	'-'
/*****************FMPullOut******************************/
#define NOFM_FLAG       0
#define NEWTAX_FLAG     1
#define NEWHEAD_FLAG    2
/********************** For ER50 ***********************/
//�ѳ�ʼ����Ϣ���浽FLASH��
typedef struct
{
    WORD   InitFlags[2];        //InitFlags����Ϊ��һ������
    ULONG  SIZE_EXTRAM; //size of SRAM����Ϊ�ڶ�������
    BYTE   FMPullOut[3];//ccr071212 [0]=0x69:FM�����γ�,[1]=0x69:�޸���˰��,[2]=0x69:�޸���Ʊͷ//
    struct APPTEXT TXT;         //TXT����ΪInitFlags֮��ĵ�һ������
    struct APPLICATION AP;
    struct PORTRECORD   PortList[portNumber];
    //^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^����Ϊ����������
    WORD    ZCount[ZSIZE];  // ZCount 65535, ZCount[0]����������ʽ�µ�Z����,ZCount[1]������ѵģʽ�µ�Z���� //

    BYTE                   //����λʱ�����뽫���±�����0   //
        CopyReceipt,
        ReportNumber;

    WORD
        PromCounter,        // counter for promotion
        EmptyBlock,       /* first empty block in track buffer */
        PbInvoice;

   UnLong
        MyFlags,                /* flags for appliction */
#if(DD_MMC==1)
        MMCLast,
#endif
        AutoCheck ;

    /*************************************/

    BYTE
        MFRCardPort,
        ePosPort,               //ccr epos  eͨ�������Ӵ��ں�.0-������1������0��2������1 //
        DeptKeys,
        PluKeys,
        FuncOnEnter,
#if GREEK == 1
        ArrowsFlag,
#endif
        AmtDecimal,             /* used in format routines if 1 then no decimal in amount */
        ArrowsAlfa,  /*	BIT0:
  						BIT1:
  						BIT2:
  						BIT3:
  						BIT4:
  						BIT5:
  						BIT6:=1:����ʹ���ϵ�;=0:����ʹ���µ�
  						BIT7:=1:
  						*/

        BufCC,                  /* if 1 then add CC byte instead of bit for speed */
        BufCmd,                 /* used in StoreInBuffer */
        BufKp,                  /* if 1 then print KP */
        BufRec,                  /* If 1 then second receipt */
        /* set to one before calling ProcessBuffer */
        CancelNumber,
        CancPrint,
        ClerkLock,              /* Current Clerk Lock Position */
        CorrecNumber,
        CurrNumber,
        CurLine,
        Day,
        DecimalPoint,           /* decimal point count */
        DiscNumber,
        DrawNumber,
        ErrorNumber,            /* if not zero then error condition */
        FBarcode,               /* entry is barcode or In Store Marking !!*/
        FBuffer,                /* if set then regi buffer full */
        FCanc,                  /* if 1 then normal cancel else non add */
        FCard,                  /* if card used set */
        FCorr,                  /* flags is non zero set */
        FCurr,                  /* currency used */
        FExt,                   /* if set then external input (SL) */
        FInv,                   /* if 1 then ADD inventory */
        /* if 2 subtract inventory */
#if !defined(FISCAL)
        FJournal,
#endif
        FKpGroup,                 /* if set disable seperate tickets on KP */
        FNoPb,                  /* if BIT 0 set to 1 then no pb compulsion for */
        /* 1 transaction, if BIT1 to 1 then no */
        /* tender allowed after open/add PB function unless */
        /* paper is in slip */
        /* if BIT 2 set then print PB Trailer with tender */
        /* and store invoice number when used */
        FNoTax,                 /* if set then no tax calculation */
        FNoTime,                /* if set then print no time in trailer line */
        FNum,                   /* number entered */
        FPb,                    /* if set then pb open */
        FPlu,                   /* if set then plu */
        FPrice,
        FProforma,              /* if set then proforma transaction */
        FReceipt,
        FRecIssue,              /* if set then Receipt issue key used */
        FRefund,
        FRegi,
        FRemote,                /* if set then external plu (SL) */
        FReport,                /* if set report in progress */
        FTrain,                 /* =1,Ϊ��ѵģʽ;=0,Ϊ����ѵģʽ */
        FSale,
        FSplit,                 /* split bill */
        FTend,
        FVoid,
        FDisc,          //cc 20071102
        HardTestActive,         /* if set then power down during hardtest */
        KeyNo,
        Menu,
        MenuPage,
        MenuType,
        ModiCount,              /* number of entered modifiers */
        Month,      /* for DEBET month used as salesperson */
        MultiplyCount,          /* number of times multiply used */
        NoDisplay,
        OldModiCount,
        OldMultiCount,
        OpDraw,             /* open drawer */
        PbFNumber,          /* pb function number */
        PbSplit,            /* flag use din PBBUFFER */
        PluPriceLevel,
        PointerType,         /* pointertype used in addpointertotal */
        PoRaNumber,
        PrintLayOut,            /* Print CONSTruction */
        RepComputer,            /* if set then computer report */
        RepeatCount,            /* repeat counter used by void */
        RGNumber,             /* pointer in Transaction Buffer */
        SlipDouble,             /* if set the double wide on slip */
        SlipLines,            /* if 1 then paper in slip */
        SlipPage,               /* slip page number */
        TaxNumber,
        TaxPerm,                /* permanent tax shift */
        TaxTemp,                /* temporary tax shift */
        TaxTemp1,               /* used for void and repeat */
        TendNumber,
#if !defined(FISCAL)
        Zone,
#else
        Zone,
        FJournal,               /* is set the journal used */
#endif                     /* Add NEW FLAG at the END because of location */
        /* Receipt Number for Fiscal versions */
        FNFolio,                        /* if set then new folio */
        FSuspend,
        FTrvoid,
        FMixMatch,
        FPluEnq,                                /* if set process plu as enquiry */
        FBalance,       //cc 2006-06-29 for Balance
#if (defined(CASE_MALTA))
        FVatNo[16],      //��������վݵĹ˿�˰����
#endif
        FisCardFlag,
        FSub;                   /* if set then last item was mixmatch */

    short
        PluArtLevel,        /* article shift */
        ProgNumber,             /* item  (plu or function #) number of programming */
        NumberEntry;            /* entry converted to WORD if keycode / 100 */

    UnLong
        MMCSIZEMAX,
        INDEXSIZE;


    WORD
        AgreeNumber,
        PortNumber,
        OFFNumber,
        CentralLock,            /* Current Central Lock Position */
        ClerkNumber,
        SaveClerk,              /* used for clerk storage during report */
        DeptNumber,
        GroupNumber,
        ModiNumber,             /* modifier number */
        ModNum[4],                /* modifiers for article */
        OldClerk,               /* old clerk used for clerk change check */
        PbNumber,
        PluNumber,
        SalPerNumber,
        SaveSalPer,
        OldSalPer,
        omax,
        nmax,
        errplu,
        ICBlockNumber,  //ccr chipcard 2004-07-01

#if !defined(FISCAL)
        SuspendClerkNumber,
        PluDept;
#else
        PluDept;
#endif

    struct  ICCardSetTable ICCardSet;   //ccr chipcard

#if (BARCUSTOMER==1)
    struct PLURECORD   BarCustomer;
#endif

    struct CLERKRECORD      Clerk;
    struct CORRECRECORD Correc;
    struct CURRRECORD   Curr;
    struct DEPTRECORD   Dept;
    struct DISCRECORD   Disc;
    struct DRAWERRECORD Draw;
    struct GROUPRECORD  Group;
    struct MODIRECORD   Modi;
    struct PBRECORD     PbF;
    struct PLURECORD    Plu;
    struct PORARECORD   PoRa;
    struct REPORT       Report;
    struct REPSIZE         Size;           /* used in Total Routines */
    struct TAXRECORD    Tax;
    struct TENDRECORD   Tend;
    struct TOTAL        Total;
    struct TRANSRECORD  RGRec;          /* temporary record */
    struct TRANSRECORD  RGBuf[TRANSITEMS];    /* Transaction Buffer */
    struct  PBTOTAL     PB;
#if !(SKIP & S_PB)
    struct  PBARTICLE   PBA;             /* used for temporay pbbuffer storage */
#endif
    struct  KPINFO      KP;
    struct OFFRECORD    OFFPrice;
    struct PORTRECORD   Port;
    struct GRAPFORPRN   Graph[GRAFESTMAX+2];
    //0:Used for SHOP TYPE
    //1..GRAFESTMAX:used for FESTIVAL
    //GRAFESTMAX+1:Used for LOGO
    struct AGREERECORD  Agree;
    struct SALPERRECORD  SalPer;
    struct ICBLOCKRECORD ICBlock;  //ccr chipcard 2004-07-01

    union KEY
        Key,
        OldKey;

#if BONUS == 1
        UnLong BonusPoints;
#endif
    short
        NewPlu,
        OldPlu ;

    BCD
        TotalMax,   // ΪZ����֮�������ܼ�ͳ��ccr080901
        FTotal,     // Ϊ�Ի���ʹ������������ͳ�� cc 20071018
        FSubAmt,        //    cc 2006-02-15>>>>>>>>>>>>>>
        SubTotalDisc,
        Amt,                     /* Qty X Price */
        BonusPointAmt,
        BonusExemptAmt,
#if DEBET != 0
        CardAdjust,
        CardAmt,
        CardMax,
        CardNew,                /* card balance */
        CardNumber,
#endif
        Cost,
        DiscAmt,
        DiscItem[2],            /* discount selection itemizers */
        Entry,                  /* Entry in BCD format */
        MixQty,                 /* used for Mix Match */
        NumberEntered,      /* store number entered */
        Price,                  /* Item Price (Dept or Plu) */
        Qty,                    /* Total Qty */
        Qty1,                   /* Qty1, Qty2 and Qty3 used with Multiplication */
        Qty2,
        Qty3,
        RetQty,                 /* used during total update */
        SaleAmt,                /* Total Sales Amount */
        SaleQty,                /* Total Sales Qty */
        SubTotal,               /* subtotal amount used in tender and subtotal */
#if PBTIME == 1
        TimeQty,
#endif
#if CHINA != 1
        SuspendSaleAmt,
        SuspendSaleQty,
        SuspendTaxItem[8],
#endif
#if CUBA == 1
        STotal[2],                      /* Used for FIscal Receipt and Fiscal Invoice Total */
#endif
#if !defined(FISCAL) && CHINA != 1
        TaxItem[3][8],  //ccr090108
        ValidAmt,
#if COST == 1
        CostCode,
        PluInvAmt,
#endif
        PluInventory;
#else
        TaxItem[3][8],//ccr090108
#if COST == 1
        CostCode,
        PluInvAmt,
#endif
        PluInventory;       //<<<<<<<<<<!!!!!!!
#endif

    struct LOGCOND LogDefine;


#if DD_MMC

    BYTE EJNo[16];

    struct  EJLOGHEAD EJLogHeader;
    struct EJHEADER EJHeader;
    //BIT0 : store data when print, BIT1:  store head data
    WORD
        RefundNumber,               //Refund invoice number
        //non fiscal counter
        FMCount;                        //FM report counter

    BYTE EJContent,             //content type of EJ Log
        ContFlag,                       //BIT0 : store data when print, BIT1:  store head data
        EJcrc;                      //crc of EJ

#endif

#if defined(FISCAL)

    union  FISCALRECORD FiscalBuff;
    struct FIS_FifoHeader FiscalHead;
    struct FISCALCODE FiscalDefine;
    struct FISCAL_TOTAL FiscalTotal;//���ݲ�ѯʱ,ͳ��˰������
    struct FIS_HEADER Fis_Header;//˰�س�ʼ������
    struct FIS_EJTBL Fis_EJTbl;
    struct FIS_HEADCHG Fis_HeadChg;
    WORD TXTCount   ;


    BYTE
        ZReport,                    // =0,��ʾҪ��ӡZ����; =1,��ʾ�Ѵ�ӡZ����; =2,��ʾ�ѹ���,�����ӡZ���� //
        FStatus,
        Fiscal_PrintFlag,                /*BIT0: 	FRegi
                                           BIT1:	FTend & FRegi
                                           BIT2:	��ʾ���ڴ�ӡZ Report
                                           BIT3:    ��ӡZ����ʱȱֽ,���´�ӡһ��,�������Ʋ��ظ����ܼ�˰����
                                           BIT4:    ��ӡ������Ϣ
                                           BIT5:    ֻ���,����ӡ
                                           BIT6:     ��ӡZ�����ǵ���ǰ�Ѿ�ͳ�Ƽ�˰����
                                           BIT7:	��ӡZ����ʱȱֽ PaperOut
                                        */
        CurrentTaxRate[8][2];       //ccr070614 for tax rate


    //>>>>ʵʱͳ��˰������,�����ɺʹ�ӡZ��������>>>>>>
    struct FIS_NUMBER FisNumber;

    BCD FTotalItem[8],
        FDiscAmt,
        FRetAmt,
        FRetTax,           //ccr091223
        FpbRetAmt,     //ccr091223
        FpbRetTax,     //ccr091223
        FTax[8],
        FTaxTotal[8],//liuj 0613 for fiscal report total
        FExento;

    BYTE FTotal_Flags;      //ccr20130311,��ӡZ����ʱ,���ܳ��ֶϵ��ȱֽ,��Ҫ���´�ӡZ����,
                            //FTotal_Flags������ʾȱֽ���ߵ���֮ǰ,��˰���µ������Ƿ��Ѿ�����

    WORD LastInvoiceDate;                   //last invoice date		20070118
    WORD SaleReceipts;//ccr091027

    BYTE LastInvoiceTime[3];                //last invoice time		20070118

    //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    struct TUSERINPUT  UserInfo;           /*ccr2014 ��������վ��ϵĹ˿����� */
    PBOPENFLAG  PBOpenFlag;     //ccr091127

#else
    extern struct FIS_NUMBER FisNumber;//cce091027
#endif

#if DD_FISPRINTER == 1
    WORD Fiscal_Status, Printer_Status;     //20070308
    BCD
        DiscountAmt,            //discount/increase amount,	0 exempt, 1, TAX A, 2 TAX B...
        RefundAmt,          //refund amount,	0 exempt, 1, TAX A, 2 TAX B...
        ExemptAmt,                      //tax-exempt amount
        RegExempt;                      //tax-exempt amount in a receipt
    BYTE LineCount, DocCount;               //20070313 every 4 line print a "NO FISCAL"
    char ItemName[PRTLEN+1];                //20070313 name of deptname
#endif

#if (pbAmtDisc)
    WORD    LastKey;//ccr091210 �������۵��������һ�����۵ĵ�Ʒ����Ĺ�����() //
#endif
    BYTE    TendFlags;          //������ʾ���ʽ,ÿһλ��Ӧһ�����ʽ
    //��ӡ������>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    char GrafTexts[TEXTSOFGRAPH][(PRTLEN +1)];

    struct TPRN_POOL PoolForPrint[MAX_PRNPOOL];//��ӡ�������
    BYTE    PoolPushIn;
    BYTE    PoolPopOut;
    BYTE    Prn_Command;
    //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    //��ʾ���ݱ�����
#if (DD_ZIP)
    char LCD_Operator[DISLEN*2],LCD_Customer[DISLEN*2];//LCD_Operator[0]!='\0'ʱ������ʱ��ʾ���е�����
#elif (DD_ZIP_21)
    char LCD_Operator[DISLEN*2],LCD_Customer[DISLEN];//LCD_Operator[0]!='\0'ʱ������ʱ��ʾ���е�����
#else
    char LCD_Operator[DISLEN],LCD_Customer[DISLEN];//LCD_Operator[0]!='\0'ʱ������ʱ��ʾ���е�����
#endif


    BYTE    ScreenMap[SCREENLN+STATELN][SCREENWD];
    WORD    ScreenStat;
    CURSOR  sCursor;

    //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#if (defined(CASE_GPRS) || defined(CASE_ETHERNET))
    BYTE    DaysMust;        //��С������ˮ���ݼ��������=0ʱ����������������
                             //BIT7Ϊ�Ƿ��Զ�������ˮ���ݣ�=1ʱΪ���ʺ������Զ�������ˮ
    WORD    LastDaysLog;     //���һ�η�����ˮ������
#endif

#if defined(CASE_EURO) //!!! GREECE_ONLY !!!
    BYTE    CommentCou;     //ccr2018-01-03 �����վ�ʱ��0
    char    CommentStr[COMMENTSMAX][PRTLEN+1];
#endif

    //^^^^^^^^^^^^^^^^^�����ڴ���֮ǰ�����µı���^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
    //vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
    WORD
        ApplFlag;//������ʾ������������
    //		ApplVarCRC must be the last , The new variable must insert befor ApplVarCRC
    BYTE
        ApplVarCRC;            //CRC of ApplVar
}  APPLICATION_SAVE;

/*************************Format definitions for Print on receipt**************************************/
#if  defined(CASE_MALTA)
#define PRINTITEMSType  0   // ������Ŀ��ӡ��ʽѡ��  //
#else
#define PRINTITEMSType  1   // ������Ŀ��ӡ��ʽѡ��  //
#endif
//   ====Items print type0==|====Items print type1======
//   GOODS F         12.54 F|GOODS F  1   12.54    12.54
//   GOODS R         32.56 R|GOODS R  1   35.26    35.26
//   EXEMPT          58.74 E|EXEMPT   1    5.84     5.84

#if  defined(CASE_MALTA)
#define PRINTTENDType  1   // �������ݴ�ӡ��ʽѡ��  //
#else
#define PRINTTENDType  0   // �������ݴ�ӡ��ʽѡ��  //
#endif
// -----------Mode 0--------|-----------mode 1-------
// SALES               12.54|SUBTOTAL F        12.54
// TAXABLE A   7.00%   12.54|SUBTOTAL R        25.36
// SALES               32.56|SUBTOTAL E        25.87
// TAXABLE B  10.00%   32.56|SUM EXC.VAT       57.27
// SALES               58.74|TAX AMOUNT         6.50
// TAXABLE C  15.00%   58.74|
// SALES                0.00|
// TAXABLE D   0.00%    0.00|
// SUM EXC.VAT         92.40|
// TAX AMOUNT          11.44|

#define PREHEADER	3	// �վ�Ԥ��ӡ��Ʊͷ����,PANAMA�汾ʱ,��ֵ��ҪС��3  //

#define Config_SIZE ((sizeof(ApplVar.InitFlags)\
                      +sizeof(ApplVar.SIZE_EXTRAM)\
                      +sizeof(ApplVar.FMPullOut)\
                      +sizeof(ApplVar.AP)\
                      +sizeof(ApplVar.TXT)\
                      +sizeof(ApplVar.IP)\
                      +sizeof(ApplVar.PortList)))
#define AppVAR_SIZE (sizeof(APPLICATION_SAVE)-Config_SIZE)

#define AtEntryBuffer(p) EntryBuffer[sizeof(EntryBuffer) - p - 1]

#endif
