#define TAX_C 5
#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
//type=0:Total sales rounding;
//type=1:Rounding on MULT, TAX & Percentage discount

void AmtRound(BYTE type ,BCD *amt)
{
    BYTE b, sign;

    if ((!type && TESTBIT(ROUNDMASK, BIT0+BIT1+BIT2+BIT3)) ||
        (type && TESTBIT(ROUNDMASK, BIT4+BIT5+BIT6+BIT7)))   /* Detail rounding?*/
    {

        sign = amt->Sign;   /* save sign */
        amt->Sign = 0;
        b = ROUNDMASK & 0x0f;
        if (!b)
            b = (ROUNDMASK>>4) & 0x0f;
        switch (b)
        {
        case 1:
            if ((amt->Value[0] & 0x0f)>=0x05)
                Add(amt,&TEN);
            amt->Value[0] &= 0xf0;
            break;
        case 2:
            b = amt->Value[0];
            amt->Value[0] = 0;      /* 00 - 24 -->0 */
            if (b > 0x74)           /* 75 - 99  --> 100 */
                Add(amt, &HUNDRED);
            else if (b > 0x24)      /* 25 - 74 --> 50 */
                amt->Value[0] = 0x50;
            break;
        case 3:
            b = amt->Value[0] & 0xf0;
            amt->Value[0] = 0;      /* 00 - 49 -->0 */
            if (b >= 0x50)
                Add(amt, &HUNDRED);/* 50 - 99  --> 100 */
            break;
        case 4:
            b = amt->Value[0] & 0xf0;
            amt->Value[0] = 0;      /* 00 - 09 -->0 */
            if (b > 0x00)
                Add(amt, &HUNDRED);/* 10 - 99  --> 100 */
            break;
        }
        amt->Sign = sign;       /* restore sign */
    }
}

void RoundTaxable(BCD *amt)
{
    RoundBcd(amt, 0);
    AmtRound(1, amt);
}

void GetTaxOffSet()
{
    RamOffSet = ApplVar.TaxNumber * ApplVar.AP.Tax.RecordSize + ApplVar.AP.StartAddress[AddrTax];
}

void AddTaxTotal()
{
    GetTaxOffSet();
    RamOffSet += ApplVar.AP.Tax.TotalOffSet;
    for (ApplVar.PointerType = 0; ApplVar.PointerType < REPDEFMAX; ApplVar.PointerType++)
    {
        ApplVar.Size = ApplVar.AP.Tax.Size[ApplVar.PointerType];
        AddPointerTotal();
    }
}

void WriteTax()
{
    if (ApplVar.TaxNumber < ApplVar.AP.Tax.Number)
    {
        GetTaxOffSet();
        ApplVar.Tax.Rate[2] = 0;//ccr070614

        WriteRam(ApplVar.Tax.Name, ApplVar.AP.Tax.CapSize);
        WriteRam((BYTE *)ApplVar.Tax.Rate, sizeof(ApplVar.Tax.Rate));
        WriteRam(&ApplVar.Tax.Options, sizeof(ApplVar.Tax.Options));
    }
}
//Read ApplVar.Tax from area of TAX_C
void ReadTax()
{
    memset(&ApplVar.Tax,0,sizeof(ApplVar.Tax));
    if (ApplVar.TaxNumber < ApplVar.AP.Tax.Number)
    {
        GetTaxOffSet();

        ReadRam(ApplVar.Tax.Name, ApplVar.AP.Tax.CapSize);
        ReadRam(ApplVar.Tax.Rate, sizeof(ApplVar.Tax.Rate));
        ReadRam(&ApplVar.Tax.Options, sizeof(ApplVar.Tax.Options));
        ApplVar.Tax.Rate[2] = 0;//ccr070614
    }
}


//ccr091223>>>>>>>>>>>>>>>>
void CalculateRefundTax(BYTE tax,BCD *taxAmt, BYTE pbRefund)
{
    if (CheckNotZero(taxAmt))
    {
        if (pbRefund)
            Add(&ApplVar.FpbRetAmt, taxAmt);
        else
            Add(&ApplVar.FRetAmt, taxAmt);
        for (ApplVar.TaxNumber = 0; ApplVar.TaxNumber < ApplVar.AP.Tax.Number && tax; ApplVar.TaxNumber++,tax>>=1)
        {
            if (tax & 1)
            {
                ReadTax();
                ApplVar.Cost = ZERO;        /* clear calculated tax */
                ApplVar.Qty = ZERO;
                memcpy(ApplVar.Qty.Value, ApplVar.Tax.Rate, sizeof(ApplVar.Tax.Rate));
                if (!TESTBIT(ApplVar.Tax.Options, BIT0)) /* add on ? */
                {
                    ApplVar.Cost = *taxAmt;
                    ApplVar.Qty.Sign = 0x04;
                    Multiply(&ApplVar.Cost, &ApplVar.Qty);
                    RoundBcd(&ApplVar.Cost, 0);
                    AmtRound(1, &ApplVar.Cost);
                }
                else
                {
                    ApplVar.Cost = *taxAmt; /* contains TAX */
                    ApplVar.DiscAmt = ApplVar.Cost; /* contains NET */
                    Add(&ApplVar.Qty, &THOUSAND10);
                    ApplVar.Qty.Sign = 0x04;
                    Divide(&ApplVar.DiscAmt, &ApplVar.Qty); /* calculate net */
                    RoundTaxable(&ApplVar.DiscAmt);
                    Subtract(&ApplVar.Cost, &ApplVar.DiscAmt);  /* taxable - net */
                }//if
                if (pbRefund)
                    Add(&ApplVar.FpbRetTax,  &ApplVar.Cost);
                else
                    Add(&ApplVar.FRetTax, &ApplVar.Cost);
            }
        }
    }
}
//<<<<<<<<<<<<<<<<<<<<<<<<


void AddTaxItem(BYTE tax,BYTE option)//ccr090108
{
    BYTE t, i;

#if	(pbAmtDisc)//ccr091210>>>>>>>>>>>>>>>>>>
    BCD sAmt=ApplVar.Amt;

    if (ApplVar.PBA.Disc.Sign!= 0xff)//ccr091210
    {
        Add(&sAmt,&ApplVar.PBA.Disc);
        if (TESTBIT(sAmt.Sign,BIT7))// Ϊ�˻���
            CalculateRefundTax(tax, &sAmt,1);//ccr091223
    }
#endif//<<<<<<<<<<<<<<<<<<<


    t = 1;
    tax ^= ApplVar.TaxPerm; /* shift tax 1 & 2 if needed */
    tax ^= ApplVar.TaxTemp;

    for (i = 0; i < ApplVar.AP.Tax.Number; i++)
    {
        if (tax & t)
        {//ccr090108>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#if	(pbAmtDisc)//ccr091210>>>>>>>>>>>>>>>>>>
            Add(&ApplVar.TaxItem[0][i], &sAmt);
            if (TESTBIT(option, BIT6))
                Add(&ApplVar.TaxItem[1][i], &sAmt);
            if (TESTBIT(option, BIT7))
                Add(&ApplVar.TaxItem[2][i], &sAmt);
#else//<<<<<<<<<<<<<<<<<<<<<<<<<<
            Add(&ApplVar.TaxItem[0][i], &ApplVar.Amt);
            if (TESTBIT(option, BIT6))
                Add(&ApplVar.TaxItem[1][i], &ApplVar.Amt);
            if (TESTBIT(option, BIT7))
                Add(&ApplVar.TaxItem[2][i], &ApplVar.Amt);
#endif
        }//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        t <<= 1;
    }
    Add(&ApplVar.SaleAmt, &ApplVar.Amt);
    Add(&ApplVar.SaleQty, &ApplVar.Qty);
    ApplVar.TaxTemp1 = ApplVar.TaxTemp;     /* save article tax shift */
    ApplVar.TaxTemp = 0;        /* reset article tax shift */
}

/* if type = 0 then add in report and calculate add on tax */
/* if type = 1 then not add in report and calculate add on tax */
/* if type = 2 then calculate and print add on tax not report */
/* if type = 3 then print inclusive tax */
/* GST is a special tax which is always ADD ON and calculated as */
/* a percentage on (SalesAmt + TAX1 + TAX2 ..)	*/
#if (0)
void CalculateTax(BYTE type )
{

    BYTE printsub;
    BYTE calcgst;
    BCD gst,sVal1;
    BCD tAmt,tTax;

    tAmt=ZERO;
    tTax = ZERO;
#if defined(CASE_MALTA)
    Prefix1 = 0;
    Prefix2 = 0;


#endif
    printsub = 0;
    calcgst = 0;    /* checkif tax used for GST (tax on total sales amount)*/
	if (!type)
	    AmtRound(0, &ApplVar.SaleAmt);	/*    sales amount rounding     */

	if(type!=5) // liuj modify 080610
		ApplVar.SubTotal = ApplVar.SaleAmt;

#if defined(FISCAL)
    if (ApplVar.AP.Tax.Number)
#else
    if (ApplVar.AP.Tax.Number && !ApplVar.FNoTax)   /* if ApplVar.FNoTax == 1 then no tax */
#endif
    {
	    for(;;)
	    {
	        for (ApplVar.TaxNumber = 0; ApplVar.TaxNumber < ApplVar.AP.Tax.Number; ApplVar.TaxNumber++)
	        {
		        ReadTax();
		        if (TESTBIT(ApplVar.Tax.Options, BIT3))        /* GST tax ? */
		        {
		            if (calcgst == 2)
		            {
			            ApplVar.Amt = gst;		 /* Taxable is Saleamt + ApplVar.Tax */
			            ApplVar.TaxItem[0][ApplVar.TaxNumber] = ApplVar.Amt;   /* ccr090108 used for external invoice */
		            }
		            else
		            {
			            calcgst = 1;		/* set GST active */
			            continue;
		            }
		        }//if
		        else if (calcgst == 2)
	                continue;
	            else
	                ApplVar.Amt = ApplVar.TaxItem[0][ApplVar.TaxNumber];//ccr090108
		        ApplVar.Cost = ZERO;	    /* clear calculated tax */
		        if (CheckNotZero(&ApplVar.Amt))
		        {
		            ApplVar.Qty = ZERO;
		            memcpy(ApplVar.Qty.Value, ApplVar.Tax.Rate, sizeof(ApplVar.Tax.Rate));
		            if (!TESTBIT(ApplVar.Tax.Options, BIT0)) /* add on ? */
		            {
			            ApplVar.Cost = ApplVar.Amt;
			            ApplVar.Qty.Sign = 0x04;
			            Multiply(&ApplVar.Cost, &ApplVar.Qty);
			            RoundBcd(&ApplVar.Cost, 0);
			            AmtRound(1, &ApplVar.Cost);

						if(type!=5)	//liuj modify 080610
			            	Add(&ApplVar.SubTotal, &ApplVar.Cost);
		            }
		            else
		            {
			            if (type == 3 || type == 5)  // liuj 0731
			            {
			                ApplVar.Cost = ApplVar.Amt; /* contains TAX */
							if (ApplVar.Qty.Value[0] == 0x99 &&
								ApplVar.Qty.Value[1] == 0x99 &&
								ApplVar.Qty.Value[2] == 0x99)
								ApplVar.DiscAmt = ZERO; 	/* NET is zero */
							else
							{
								ApplVar.DiscAmt = ApplVar.Amt;	/* contains NET */
				                Add(&ApplVar.Qty, &THOUSAND10);
				                ApplVar.Qty.Sign = 0x04;
				                Divide(&ApplVar.DiscAmt, &ApplVar.Qty);	/* calculate net */
								RoundTaxable(&ApplVar.DiscAmt);
				                Subtract(&ApplVar.Cost, &ApplVar.DiscAmt);	/* taxable - net */
				                Subtract(&gst, &ApplVar.Cost);	/* calculate net for */
				    /* add on tax for Argentina */
							}
							Add(&tAmt,&ApplVar.DiscAmt); // liuj 0731
			            }
		            }
			        Add(&tTax,&ApplVar.Cost); //liuj 0731 total tax
		            if (!type || type == 4)		/* add report */
			            AddTaxTotal();
		        }//if
		        if (type == 2)
		        {
		            if (!TESTBIT(ApplVar.Tax.Options, BIT0) && TESTBIT(ApplVar.Tax.Options,BIT1))
		            {			      /* ADD ON and print */
#if !defined(CASE_MALTA)
						if (CheckNotZero(&ApplVar.Cost) || TESTBIT(ApplVar.Tax.Options, BIT2))
#endif
			            {		    /* print also zero */
#if !defined(CASE_MALTA)
			                if (!printsub)
			                {
				                if (calcgst == 2)   /* GST subtotal ?*/
				                    PrintAmt(Prompt.Caption[1], &gst);  //liuj 0712
				                else
				                    PrintAmt(Prompt.Caption[1], &ApplVar.SaleAmt);  //liuj 0712
				                printsub = 1;
			                }
#endif
//ccr070614>>>>>>>>>
			                if (TESTBIT(ApplVar.Tax.Options, BIT4))	   /* print taxable */	//liuj 0613
		                	{
#if !defined(CASE_MALTA)
#if !defined(FISCAL)    // liuj 0805
				                PrintAmt(Prompt.Caption[46], &ApplVar.Amt);
#else
								memset(ProgLineMes, ' ', sizeof(ProgLineMes));
								sVal1 = ZERO;
								CWORD(sVal1.Value[0]) = CWORD(ApplVar.Tax.Rate[0]);
								CopyFrStr(ProgLineMes,Msg[XIAOSHOUA].str);
								ProgLineMes[strlen(Msg[XIAOSHOUA].str)+1] = 'A' + ApplVar.TaxNumber;
								sVal1.Sign = 2;
								FormatQty(ProgLineMes+16,&sVal1);//cr070424
								ProgLineMes[17] = '%';		//ProgLineMes[13] = '%';
								ProgLineMes[18] = 0;		//ccr090113
//liuj 0716
#if PRTLEN<25
								PrintStr(ProgLineMes+1);
								PrintAmt(" ",&ApplVar.Amt);
#else
								PrintAmt(ProgLineMes,&ApplVar.Amt);
#endif
#endif
#else
								//if(ApplVar.TaxNumber<3 ||( CheckNotZero(&ApplVar.Amt) && ApplVar.TaxNumber>2))		//liuj0829
								if( CheckNotZero(&ApplVar.Amt) )	 // liuj 080430
								{
										memset(ProgLineMes, ' ', sizeof(ProgLineMes));
										CopyFrStr(ProgLineMes,Msg[XIAOSHOUA].str);
										ProgLineMes[strlen(Msg[XIAOSHOUA].str)+1] = ApplVar.Tax.Name[0];
										PrintAmt(ProgLineMes,&ApplVar.Amt);
								}

#endif
		                	}
#if !defined(CASE_MALTA)
#if (defined(FISCAL) && CC_TESTFM == 0)
							memset(ProgLineMes, ' ', sizeof(ProgLineMes));
							CopyFrStr(ProgLineMes,ApplVar.Tax.Name);
							sVal1 = ZERO;
							CWORD(sVal1.Value[0]) = CWORD(ApplVar.Tax.Rate[0]);
							sVal1.Sign = 2;
							FormatQty(ProgLineMes+15,&sVal1);//cr070424
							ProgLineMes[16] = '%';		//ProgLineMes[13] = '%';
							ProgLineMes[17] = 0;		//ccr090113
#endif
                            PrintAmt(ProgLineMes, &ApplVar.Cost);
#endif

//liuj 0716


//<<<<<<<<<<<<<<<<<<<<<<
			            }
		            }
		        }
		        else if (type == 3)
	            {
	                if (TESTBIT(ApplVar.Tax.Options, BIT0) && TESTBIT(ApplVar.Tax.Options, BIT1))		/* print incl tax ? */
				    {
					    if (CheckNotZero(&ApplVar.Amt) || TESTBIT(ApplVar.Tax.Options, BIT2))
					    {
#if defined(FISCAL)    // liuj 0805
//ccr070614>>>>>>>>>>>
#if !defined(CASE_MALTA)
                            memset(ProgLineMes, ' ', sizeof(ProgLineMes));
                            CopyFrStr(ProgLineMes,ApplVar.Tax.Name);

                            sVal1 = ZERO;
                            CWORD(sVal1.Value[0]) = CWORD(ApplVar.Tax.Rate[0]);
                            sVal1.Sign = 2;
                            FormatQty(ProgLineMes+15,&sVal1);//cr070424
                            ProgLineMes[16] = '%';      //ProgLineMes[13] = '%';
                            ProgLineMes[17] = 0;        ////ccr090113

//liuj 0716
#if PRTLEN<25
                            PrintStr(ProgLineMes);
                            PrintAmt(" ",&ApplVar.Cost);
#else
                            PrintAmt(ProgLineMes,&ApplVar.Cost);
#endif
#endif//
#else
                            PrintAmt(ApplVar.Tax.Name, &ApplVar.Cost);
#endif
                            if (TESTBIT(ApplVar.Tax.Options, BIT4))     /* print taxable ? */
                            {
#if !defined(FISCAL)    // liuj 0805
                                PrintAmt(Prompt.Caption[46], &ApplVar.DiscAmt);
#else
#if defined(CASE_MALTA)
                                memset(ProgLineMes, ' ', sizeof(ProgLineMes));
                                CopyFrStr(ProgLineMes,Msg[XIAOSHOUA].str);
                                ProgLineMes[strlen(Msg[XIAOSHOUA].str)+1] = ApplVar.Tax.Name[0];
#else

                                memset(ProgLineMes, ' ', sizeof(ProgLineMes));
                                CopyFrStr(ProgLineMes,Msg[XIAOSHOUA].str);
                                ProgLineMes[strlen(Msg[XIAOSHOUA].str)+1] = 'A' + ApplVar.TaxNumber;

                                FormatQty(ProgLineMes+16,&sVal1);//cr070424
                                ProgLineMes[17] = '%';      //ProgLineMes[13] = '%';
                                ProgLineMes[18] = 0;        //ccr090113
                                //liuj 0716
#endif
#if PRTLEN<25
                                PrintStr(ProgLineMes+1);
                                PrintAmt(" ",&ApplVar.DiscAmt);
#else
                                PrintAmt(ProgLineMes,&ApplVar.DiscAmt);
#endif
#endif
                            }
//<<<<<<<<<<<<<<<<<<<<
                        }
                    }
                    ApplVar.Cost = ZERO;
                }
            }//for

	        if (calcgst == 1)	    /* gst active ? */
	        {
		        AmtRound(0, &ApplVar.SubTotal);     /* sales amount rounding */
		        gst = ApplVar.SubTotal;
		        calcgst = 2;
		        printsub = 0;
	        }
	        else
		        break;
	    }//for /* also calculate gst */
    }//if

//liuj 0731
    if(type == 5)
    {
        if (tTax.Sign & 0x80)
            ApplVar.Qty = tTax;
        else if (tAmt.Sign & 0x80)
            ApplVar.Qty = tAmt;
        else if (ApplVar.SubTotal.Sign & 0x80)
            ApplVar.Qty = ApplVar.SubTotal;
        else
            ApplVar.Qty = ZERO;
    }
	#if defined(CASE_MALTA)
	if(type == 2)
	{
			//RFeed(1);
			if(CheckNotZero(&tAmt)) // liuj 080430   //PenGH 2009-02-12 16:41:43
				PrintAmt("SUM EXC.VAT",&tAmt);
			if(CheckNotZero(&tTax)) // liuj 080430  //PenGH 2009-02-12 16:41:57
				PrintAmt("VAT AMOUNT", &tTax);
			PutsO(FormatAmtStr("TOTAL", &ApplVar.SubTotal, DISLEN));
	}
	Prefix1 = PREFIX_1;
	Prefix2 = PREFIX_2;

#endif
//liuj 0731

//	if (!ApplVar.FPb)
//	    AmtRound(0, &ApplVar.SubTotal);	/* sales amount rounding */
}
#endif
/* if type = 0 then add in report and calculate add on tax */
/* if type = 1 then not add in report and calculate add on tax */
/* if type = 2 then calculate and print add on tax not report */
/* if type = 3 then print inclusive tax */
/* if type = 5 then calculate tax ,story in Qty*/
/* GST is a special tax which is always ADD ON and calculated as */
/* a percentage on (SalesAmt + TAX1 + TAX2 ..)	*/
void CalculateTax(BYTE type )
{
    BYTE printsub;
    BYTE calcgst;
    BCD gst,sVal1, tAmt,tTax;
    int i;

    tAmt=ZERO;
    tTax = ZERO;

#if (defined(CASE_MALTA))
    Prefix1 = 0;
    Prefix2 = 0;
#endif

    printsub = 0;
    calcgst = 0;    /* checkif tax used for GST (tax on total sales amount)*/
    if (!type)
        AmtRound(0, &ApplVar.SaleAmt);  /* sales amount rounding */
//pxxxb080717
    if (type!=5)    // liuj modify 080610 //pxxxb080718 for pay for Amount many times
        ApplVar.SubTotal = ApplVar.SaleAmt;

#if (defined(FISCAL))
    if (ApplVar.AP.Tax.Number)
#else
    if (ApplVar.AP.Tax.Number && !ApplVar.FNoTax)   /* if ApplVar.FNoTax == 1 then no tax */
#endif
    {
        for (;;)
        {
            for (ApplVar.TaxNumber = 0; ApplVar.TaxNumber < ApplVar.AP.Tax.Number; ApplVar.TaxNumber++)
            {
                ReadTax();
                if (TESTBIT(ApplVar.Tax.Options, BIT3))        /* GST tax ? */
                {
                    if (calcgst == 2)
                    {
                        ApplVar.Amt = gst;       /* Taxable is Saleamt + ApplVar.Tax */
                        ApplVar.TaxItem[0][ApplVar.TaxNumber] = ApplVar.Amt;   /* ccr090108 used for external invoice */
                    }
                    else//calcgst==0
                    {
                        calcgst = 1;        /* set GST active �ȴ���ȡ��һ��˰�� */
                        continue;
                    }
                }//if
                else if (calcgst == 2)
                    continue;
                else
                    ApplVar.Amt = ApplVar.TaxItem[0][ApplVar.TaxNumber];//ccr090108
                ApplVar.Cost = ZERO;        /* clear calculated tax */

                if (CheckNotZero(&ApplVar.Amt))
                {
                    ApplVar.Qty = ZERO;
                    memcpy(ApplVar.Qty.Value, ApplVar.Tax.Rate, sizeof(ApplVar.Tax.Rate));
                    if (!TESTBIT(ApplVar.Tax.Options, BIT0)) /* add on ? */
                    {//add onΪ����˰,��:���ۼ۸񲻰���˰
                        ApplVar.Cost = ApplVar.Amt;
                        ApplVar.Qty.Sign = 0x04;
                        Multiply(&ApplVar.Cost, &ApplVar.Qty);
                        RoundBcd(&ApplVar.Cost, 0);
                        AmtRound(1, &ApplVar.Cost);

                        if (type!=5) //pxxxb080718 for pay for Amount many times
                            Add(&ApplVar.SubTotal, &ApplVar.Cost);
                    }
                    else
                    {//VATΪ����˰,��:���ۼ۸����˰
#if (defined(CASE_MALTA))
                        if (type == 3|| type == 5||type == 2)
#else
                        if (type == 3|| type == 5)
#endif
                        {
                            ApplVar.Cost = ApplVar.Amt; /* contains TAX ()*/
                            if (ApplVar.Qty.Value[0] == 0x99 &&
                                ApplVar.Qty.Value[1] == 0x99 &&
                                ApplVar.Qty.Value[2] == 0x99)
                                ApplVar.DiscAmt = ZERO;     /* NET is zero */
                            else
                            {
                                ApplVar.DiscAmt = ApplVar.Amt;  /* contains NET */
                                Add(&ApplVar.Qty, &THOUSAND10);
                                ApplVar.Qty.Sign = 0x04;
                                Divide(&ApplVar.DiscAmt, &ApplVar.Qty); /* calculate net */
                                RoundTaxable(&ApplVar.DiscAmt);/* No Tax (NET) */
                                Subtract(&ApplVar.Cost, &ApplVar.DiscAmt);  /* taxable - net */
                                Subtract(&gst, &ApplVar.Cost);  /* calculate net for */
                                /* add on tax for Argentina */
                            }
                            Add(&tAmt,&ApplVar.DiscAmt); /* contains NET */
                        }
                    }
                    Add(&tTax,&ApplVar.Cost); //liuj 0731 total tax

                    if (!type || type == 4)     /* add report */
                        AddTaxTotal();
                }//if
                if (type == 2)
                {
                    if (TESTBIT(ApplVar.Tax.Options, BIT0) && TESTBIT(ApplVar.Tax.Options,BIT1))
                    {                 /* ADD ON and print */
//ccr2014-07-30#if (!defined(CASE_MALTA))
                        if (CheckNotZero(&ApplVar.Cost) || TESTBIT(ApplVar.Tax.Options, BIT2))
//ccr2014-07-30#endif
                        {           /* print also zero */
#if (!defined(CASE_MALTA))
                            if (!printsub)
                            {
                                if (calcgst == 2)   /* GST subtotal ?*/
                                    PrintAmt(Prompt.Caption[1], &gst);
                                else
                                    PrintAmt(Prompt.Caption[1], &ApplVar.SaleAmt);
                                printsub = 1;
                            }
#endif
//ccr070614>>>>>>>>>
                            if (TESTBIT(ApplVar.Tax.Options, BIT4))    /* print taxable */  //liuj 0613
                            {
#if ((PRINTTENDType == 0)|| defined(CASE_ITALIA))
                                if (CheckNotZero(&ApplVar.Amt))
                                {
                                    //SALES                      12.54
//                                    PrintAmt(Prompt.Caption[46], &ApplVar.Amt);
#if (defined(FISCAL))
    /* Print out after tend
    --------------------------------
    SALES                      12.54
    TAXABLE A   7.00%          12.54
    SALES                      32.56
    TAXABLE B  10.00%          32.56
    SALES                      58.74
    TAXABLE C  15.00%          58.74
    SALES                       0.00
    TAXABLE D   0.00%           0.00
    SUM EXC.VAT                92.40
    VAT AMOUNT                 11.44
    */
                                    memset(ProgLineMes, ' ', sizeof(ProgLineMes));
                                    sVal1 = ZERO;
                                    CWORD(sVal1.Value[0]) = CWORD(ApplVar.Tax.Rate[0]);
                                    i = strlen(Msg[XIAOSHOUA].str);
                                    memcpy(ProgLineMes,Msg[XIAOSHOUA].str,i);
//                                    ProgLineMes[i+1] = 'A' + ApplVar.TaxNumber;
                                    ProgLineMes[i+1] = ApplVar.Tax.Name[0];
                                    sVal1.Sign = 2;
                                    FormatQty(ProgLineMes+15,&sVal1);//cr070424
                                    ProgLineMes[16] = '%';      //ProgLineMes[13] = '%';
                                    ProgLineMes[17] = 0;        //ccr090113
                                    PrintAmt(ProgLineMes,&ApplVar.Amt);
#endif
                                }
#else //PRINTTENDType == 1
/* Print out after tend
--------------------------------
SUBTOTAL F                 12.54
SUBTOTAL R                 25.36
SUBTOTAL E                 25.87
SUM EXC.VAT                57.27
VAT AMOUNT                  6.50
*/

                                //if(ApplVar.TaxNumber<3 ||( CheckNotZero(&Amt) && ApplVar.TaxNumber>2))		//liuj0829
                                if ( CheckNotZero(&ApplVar.Amt) )     // liuj 080430
                                {
                                    memset(ProgLineMes, ' ', sizeof(ProgLineMes));
                                    i= strlen(Prompt.Caption[1]);
                                    memcpy(ProgLineMes,Prompt.Caption[1],i);
                                    ProgLineMes[i+1] = ApplVar.Tax.Name[0];
                                    PrintAmt(ProgLineMes,&ApplVar.Amt);
                                }

#endif
                            }
#if (!defined(CASE_MALTA) || defined(CASE_ITALIA))
                            memset(ProgLineMes, ' ', sizeof(ProgLineMes));
                            CopyFrStr(ProgLineMes,ApplVar.Tax.Name);
                            sVal1 = ZERO;
                            CWORD(sVal1.Value[0]) = CWORD(ApplVar.Tax.Rate[0]);
                            sVal1.Sign = 2;
                            FormatQty(ProgLineMes+15,&sVal1);//cr070424
                            ProgLineMes[16] = '%';      //ProgLineMes[13] = '%';
                            ProgLineMes[17] = 0;        //ccr090113
                            PrintAmt(ProgLineMes, &ApplVar.Cost);
#endif
//<<<<<<<<<<<<<<<<<<<<<<
                        }

                    }
                }
                else if (type == 3)
                {
                    if (TESTBIT(ApplVar.Tax.Options, BIT0) && TESTBIT(ApplVar.Tax.Options, BIT1))       /* print include tax ? */
                    {
                        if (CheckNotZero(&ApplVar.Amt) || TESTBIT(ApplVar.Tax.Options, BIT2))
                        {
//ccr070614>>>>>>>>>>>
                            memset(ProgLineMes, ' ', sizeof(ProgLineMes));
                            CopyFrStr(ProgLineMes,ApplVar.Tax.Name);

                            sVal1 = ZERO;
                            CWORD(sVal1.Value[0]) = CWORD(ApplVar.Tax.Rate[0]);
                            sVal1.Sign = 2;
                            FormatQty(ProgLineMes+15,&sVal1);//cr070424
                            ProgLineMes[16] = '%';      //ProgLineMes[13] = '%';
                            ProgLineMes[17] = 0;        //ccr090113

                            PrintAmt(ProgLineMes, &ApplVar.Cost);/* print also zero */
//ccr070614						    PrintAmt(ApplVar.Tax.Name, &ApplVar.Cost);
                            if (TESTBIT(ApplVar.Tax.Options, BIT4))     /* print taxable ? */
                            {
                                PrintAmt(Prompt.Caption[46], &ApplVar.DiscAmt);
#if (defined(FISCAL))
                                memset(ProgLineMes, ' ', sizeof(ProgLineMes));
                                i = strlen(Msg[XIAOSHOUA].str);
                                memcpy(ProgLineMes,Msg[XIAOSHOUA].str,i);
                                ProgLineMes[i+1] = 'A' + ApplVar.TaxNumber;

                                FormatQty(ProgLineMes+16,&sVal1);//cr070424
                                ProgLineMes[17] = '%';      //ProgLineMes[13] = '%';
                                ProgLineMes[18] = 0;        //ccr090113
                                PrintAmt(ProgLineMes,&ApplVar.DiscAmt);
#endif
                            }
//<<<<<<<<<<<<<<<<<<<<
                        }
                    }
                    ApplVar.Cost = ZERO;
                }
            }//for
            if (calcgst == 1)       /* gst active ? */
            {
                AmtRound(0, &ApplVar.SubTotal);     /* sales amount rounding */
                gst = ApplVar.SubTotal;
                calcgst = 2;
                printsub = 0;
            }
            else
                break;
        }//for /* also calculate gst */
    }//if
//liuj 0731
    if (type == 5)
    {
        if (tTax.Sign & 0x80)
            ApplVar.Qty = tTax;//��˰��
        else if (tAmt.Sign & 0x80)
            ApplVar.Qty = tAmt;//����˰���
        else if (ApplVar.SubTotal.Sign & 0x80)
            ApplVar.Qty = ApplVar.SubTotal;//������
        else
            ApplVar.Qty = ZERO;

    }
//liuj 0731

#if (defined(CASE_MALTA))
    if (type == 2)
    {
#if !defined(CASE_ITALIA)
        //RFeed(1);
/*ccr20140725 һ����Ʒ�ж��ּ�˰ʱ����������>>>>>>>>
        if (CheckNotZero(&tAmt)) // ����˰���
            PrintAmt(Msg[SUM_EXC_VAT].str,&tAmt);
<<<<<<<<<<<<*/

        if (CheckNotZero(&tTax)) // ˰��
            PrintAmt(Msg[VAT_AMOUNT].str, &tTax);
#endif

        //��ʾ��˰���Ӧ���ܽ��
        PutsO(DispAmtStr(DText[1], &ApplVar.SubTotal, DISLEN));//ccr20131104
    }
    Prefix1 = PREFIX_1;
    Prefix2 = PREFIX_2;

#endif

//	if (!FPb)
//	    AmtRound(0, &SubTotal);	/* sales amount rounding */
}