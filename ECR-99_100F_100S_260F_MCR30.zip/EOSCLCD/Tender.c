#define TENDER_C 5
#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
#include "flowbill.h" //lyq200
#if 0	//cc 20070930
#if !defined(FISCAL)
#include "ePosCard.h"//ccr epos
#endif
#endif
#include "fiscal.h"
#if (defined(CASE_GPRS))
#include "Gprs.h"
#endif

/*   *****************************************************************    */
void GetTenderOffSet()
{
	RamOffSet = ApplVar.TendNumber * ApplVar.AP.Tend.RecordSize + ApplVar.AP.StartAddress[AddrTend];
}

void AddTenderTotal()
{
    GetTenderOffSet();
    RamOffSet += ApplVar.AP.Tend.TotalOffSet;
    for (ApplVar.PointerType = 0; ApplVar.PointerType < REPDEFMAX; ApplVar.PointerType++)
    {
		ApplVar.Size = ApplVar.AP.Tend.Size[ApplVar.PointerType];
		AddPointerTotal();
    }
}

void WriteTender()
{
    if (ApplVar.TendNumber < ApplVar.AP.Tend.Number)
    {
		GetTenderOffSet();
        WriteRam((BYTE *)&ApplVar.Tend, ApplVar.AP.Tend.TotalOffSet);      /* write function options */
    }
}

void ReadTender()
{
    GetTenderOffSet();

    ReadRam((BYTE *)&ApplVar.Tend, ApplVar.AP.Tend.TotalOffSet);	/* write function options */
	ApplVar.Tend.Name[ApplVar.AP.Tend.CapSize] = 0 ;
}


void Tender()
{
	BYTE	payIC=0;//ccr chipcard ccr epos:=1ΪIC�� ��2 ΪePos //
	BCD		sSave,sTotal;
	BYTE	sEntryCou;
	WORD	sKeyCode;
	long    sAmount;

	if (TESTBIT(CLERKFIX,BIT7) && !ApplVar.FSub && !ApplVar.FTend)//ccr101111
	{
		ApplVar.ErrorNumber=ERROR_ID(CWXXI46);
		return;
	}

	if (ApplVar.FRefund==1 && ApplVar.FRegi==0)
	{//ccr 050111
		ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
		ApplVar.FRefund = 0;
		return;
	}
#if 0	//cc 20070930
	if (ApplVar.Key.Code == (TEND + 5) && !ApplVar.ePosPort)
	{
		ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
		return;
	}
#endif
#if (DD_CHIPC==1)
//Ccr chipcard>>auto discount>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#if (CASE_MFRIC==1)
	if (ApplVar.Key.Code == (TEND + 6))
	{
		if (ApplVar.MFRCardPort==0)
		{
			ApplVar.ErrorNumber=ERROR_ID(CWXXI72);
			return;
		}
		else
		{
			PutsO(Msg[WAITEICCARD].str);
			if (!ChipCard() || IC.CHIP_Flag<=0)
			{
				if (!ApplVar.ErrorNumber)
					ApplVar.ErrorNumber=ERROR_ID(CWXXI50);
				return;
			}
			else
				PrintChipCard(0);
		}
	}
#else
	if (ApplVar.Key.Code == (TEND + 6) && IC.CHIP_Flag<=0)
	{
		ApplVar.ErrorNumber=ERROR_ID(CWXXI50);
		return;
	}

	if (IC.CHIP_Flag>0 && !Appl_EntryCounter && ApplVar.Key.Code==TEND+1
		&& TESTBIT(ApplVar.ICCardSet.Options,IC_TOT_CC))//ccr chipcard
		ApplVar.Key.Code = TEND + 6;//ChipCard payment
#endif

	if ((IC.CHIP_Flag==0 || (IC.CHIP_Flag==1 || IC.CHIP_Flag==2) && ApplVar.Key.Code == (TEND + 6))
		&& !TESTBIT(IC.ICState,IC_DISCOUNT) && TESTBIT(ApplVar.ICCardSet.Options,IC_DISCOUNT)  && ApplVar.FRegi//ccr040809
		&& CWORD(IC.REC_Customer[CC_CPERC])!=0 ) //ccr chipcard
	{
		SETBIT(IC.ICState,IC_DISCOUNT);
		sSave = ApplVar.Entry;
		sEntryCou = Appl_EntryCounter;
		sKeyCode = ApplVar.Key.Code;
		Appl_EntryCounter = 0;
		if (!ApplVar.FSub)
		{
			ApplVar.Key.Code = SUB;
			Fixed();
		}
		for (ApplVar.DiscNumber=0;ApplVar.DiscNumber<ApplVar.AP.Disc.Number;ApplVar.DiscNumber++)
		{
			GetDiscOffSet();
			ReadDisc();
			if (ApplVar.Disc.Options==0x11)  //Discount %
				break;
		}
		if (ApplVar.DiscNumber >= ApplVar.AP.Disc.Number);
			ApplVar.DiscNumber = 1;

		ApplVar.Key.Code = ApplVar.DiscNumber + DISC + 1;
		Appl_EntryCounter = 0;
		icBCD2EcrBCD(&ApplVar.Entry,(char*)&IC.REC_Customer[CC_CPERC], 2);
		Discount();
		ApplVar.Key.Code = sKeyCode;
		Appl_EntryCounter = sEntryCou;
		ApplVar.Entry = sSave;
	}
#endif
#if (BARCUSTOMER==1)
	if ((ApplVar.Key.Code != TEND + 6) && ApplVar.BarCustomer.OFFIndex>0 && ApplVar.BarCustomer.DeptHi==0 && !TESTBIT(ApplVar.BarCustomer.Dept,BIT0))
	{// ʹ�������Ա���ۿ۹���  //
		SETBIT(ApplVar.BarCustomer.Dept,BIT0);
		sSave = ApplVar.Entry;
		sEntryCou = Appl_EntryCounter;
		sKeyCode = ApplVar.Key.Code;
		Appl_EntryCounter = 0;
		if (!ApplVar.FSub)
		{
			ApplVar.Key.Code = SUB;
			Fixed();
		}
		for (ApplVar.DiscNumber=0;ApplVar.DiscNumber<ApplVar.AP.Disc.Number;ApplVar.DiscNumber++)
		{
			GetDiscOffSet();
			ReadDisc();
			if (ApplVar.Disc.Options==0x11)  //Discount %
				break;
		}
		if (ApplVar.DiscNumber >= ApplVar.AP.Disc.Number);
			ApplVar.DiscNumber = 1;

		ApplVar.Key.Code = ApplVar.DiscNumber + DISC + 1;
		Appl_EntryCounter = 0;
		ApplVar.Entry = ZERO;
		ApplVar.Entry.Value[0] = ApplVar.BarCustomer.Price[1][0];
		ApplVar.Entry.Value[1] = ApplVar.BarCustomer.Price[1][1];

		Discount();
		ApplVar.Key.Code = sKeyCode;
		Appl_EntryCounter = sEntryCou;
		ApplVar.Entry = sSave;
	}
#endif

	if (ApplVar.FSub || ApplVar.FTend)//ccr2014-12-22
		sSave = ApplVar.SubTotal;
	else
		sSave = ApplVar.SaleAmt;

#if defined(FISCAL) && DD_FISPRINTER == 0
		if(CheckNotZero(&sSave) && sSave.Sign &0x80)	//ccr2014-08-06	// not allow negative
		{
			ApplVar.ErrorNumber=ERROR_ID(CWXXI101);
			return;
		}
//liuj 0731
		CalculateTax(5);//������۽��/˰���Ƿ�<0
		if(CheckNotZero(&ApplVar.Qty) && ApplVar.Qty.Sign &0x80) //ccr2014-08-06		// not allow negative
		{
			ApplVar.ErrorNumber=ERROR_ID(CWXXI101);
			return;
		}
		ApplVar.Qty = ZERO;
//liuj 0731

#endif


#if (BARCUSTOMER==1)
	if ((ApplVar.Key.Code != TEND + 6) && ApplVar.BarCustomer.OFFIndex>0)
	{// ͳ�������Ա�������ܶ�  //
		sTotal = ZERO;
		memcpy(sTotal.Value,&ApplVar.BarCustomer.Price[0],5);
		Add(&sTotal,&sSave);
		memcpy(&ApplVar.BarCustomer.Price[0],sTotal.Value,5);
		ApplVar.PluNumber = ApplVar.BarCustomer.OFFIndex-1;
		ApplVar.Plu = ApplVar.BarCustomer;
		WritePlu();
	}
#endif

#if (DD_CHIPC==1)
	if ((IC.CHIP_Flag==0 || (IC.CHIP_Flag>0  && ApplVar.Key.Code == TEND + 6)) &&
        ApplVar.FRegi && CheckNotZero(&sSave))//Chipcard payment 040805
	{
		if (!Appl_EntryCounter)//Chipcard payment 040805
		{
			PayByChipCard(&sSave,FALSE);//���Կ��Ͻ���Ƿ��㹻���� //
			if (ApplVar.ErrorNumber)
				return;
		}

		if (!TESTBIT(IC.ICState,IC_POINTS))//ccr 040805
		{
			if (!TESTBIT(sSave.Sign, BIT7))
			{
				if (TESTBIT(ApplVar.ICCardSet.Options,IC_REPORT))
					payIC = 1;
				PointsByChipCard(&sSave);
			}
		}
	}
//ccr chipcard<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#endif

	ApplVar.TendNumber = ApplVar.Key.Code - TEND - 1;
	if (ApplVar.TendNumber < ApplVar.AP.Tend.Number)
	{
		ReadTender();		/* read function */
	}
	else
	{
		ApplVar.ErrorNumber=ERROR_ID(CWXXI42);
		return;
	}
	if ((TESTBIT(PBINFO, BIT3) && ApplVar.FPb) || TESTBIT(ApplVar.FNoPb, BIT1))       /* pb used ? */
	{
		ApplVar.ErrorNumber=ERROR_ID(CWXXI07);
		return;
	}

	if (!Appl_EntryCounter)
	{
		if(TESTBIT(ApplVar.Tend.Options, BIT1) && !ApplVar.FRefund)   /* entry compulsory ? */
		{
			if (!TESTBIT(ApplVar.SaleAmt.Sign, BIT7))	/* negative then allowed */
			{
				ApplVar.ErrorNumber=ERROR_ID(CWXXI43);
				return;
			}
		}
	}
	else
	{
		if (TESTBIT(ApplVar.Tend.Options, BIT2) && !ApplVar.FRefund)   /* no entry allowed ? */
		{
			ApplVar.ErrorNumber=ERROR_ID(CWXXI04);
			return;
		}
	}
	if (AmtInputMask())
		return;
	if (ApplVar.FRegi)
	{
		if (TESTBIT(ApplVar.Tend.Options, BIT3) && !ApplVar.FNum)   /* number entry ? */
		{
			ApplVar.ErrorNumber=ERROR_ID(CWXXI30);
			return;
		}
	}
#if DD_FISPRINTER == 0	//liuj0911
	if (ApplVar.FRefund)
	{

		if (ApplVar.FCurr || ApplVar.FCanc || !Appl_EntryCounter)
		{
			ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
			return;
		}
#if defined(FISCAL)
	ApplVar.FStatus = 0;	    /* set non fiscal receipt */
#endif

		if (RegiStart())
			return;
		ApplVar.SubTotal = ApplVar.Entry;
		Add(&ApplVar.SubTotal, &ApplVar.Entry);
		ApplVar.FTend = 1;
		ApplVar.FRegi = 1;
#if(CASE_RAMBILL)
		Collect_Data(REGISLOG);
#endif
	}
#endif
	if (ApplVar.PbNumber)
		ApplVar.Tend.Print = ApplVar.PbF.Print;

	ApplVar.PrintLayOut = ApplVar.Tend.Print;
	if (TESTBIT(ApplVar.Tend.Options, BIT5))   /* if set no tax calc */
		ApplVar.FNoTax = 1;
#if 0	//cc 20070930
#if !defined(FISCAL) && CASE_SPANISH == 0
//ccr epos>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	if (!Appl_EntryCounter && ApplVar.Key.Code == TEND + 5  && ApplVar.ePosPort
		&& CheckNotZero(&sSave) && ApplVar.FRegi && ApplVar.FRefund==0)
	{//ʹ��ePos ���� //
		if (ApplVar.FTend)
			sSave = ApplVar.SubTotal;

		AmtRound(0, &sSave); 	/* total sales rounding */
		if ((sSave.Sign & 0x80) || BCDWidth(&sSave)>=8 || PayByePosCard(&sSave)!=SUCCESS)
		{
			ApplVar.ErrorNumber=CWXXI70-CWXXI01+1;
			return;
		}
		else
			payIC = 2;//ΪePos����  //
	}
//ccr epos<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#endif
#endif
	if (!ApplVar.FTend)   /* already in tender ? */
	{
		if (ApplVar.FRegi)   /* registration */
		{
			ApplVar.BufKp = 1;		    /* set ApplVar.KP not printed yet */
			CalculateTax(0);	    /* calculate and add report */   //@@@@@@@@@@@
			if (ApplVar.PbNumber)
			{
				ClearPb();
#if !defined(FISCAL)
				if (TESTBIT(PBINFO, BIT4))
					AddReceiptNumber(); // liuj 0704
#endif
				AmtRound(0, &ApplVar.SubTotal); 	/* total sales rounding */
				if (TESTBIT(ApplVar.FNoPb, BIT2))   /* store ApplVar.PbInvoice ? */
				{
					StorePbInvoice(0);
				}
			}
		}
		else
			CalculateTax(1);	    /* calulate and not add report */
	}

	if (!Appl_EntryCounter)
	{
#if (DD_CHIPC==1)
//ccr chipcard>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		if (IC.CHIP_Flag>0 && (ApplVar.Key.Code == TEND + 6) && ApplVar.FRegi
			&& CheckNotZero(&ApplVar.SubTotal))//Chipcard payment 040805
		{
			PayByChipCard(&ApplVar.SubTotal,true);
			if (ApplVar.ErrorNumber)
			{
				IC.CHIP_Flag = RD_ChipCard();
				return;
			}
			if (TESTBIT(ApplVar.ICCardSet.Options,IC_REPORT))
				payIC = 1;
		}
//ccr chipcard<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#endif
		ApplVar.Entry = ApplVar.SubTotal;
		ApplVar.Amt = ApplVar.SubTotal;
		if (ApplVar.FCurr)
			GetCurrency(0, &ApplVar.Entry);	  /* subtotal to currency */
	}
	else
	{
//		ApplVar.Entry.Sign = ApplVar.SubTotal.Sign;
		ApplVar.Amt = ApplVar.Entry;	/* entry has sign of total positive */
		if (ApplVar.FCurr)
			GetCurrency(1, &ApplVar.Amt);	/* entry to local */
	}
	if (ApplVar.FCurr)
		ApplVar.AmtDecimal = ApplVar.Curr.Options & BIT0;   /* decimal in amount ? */
	if (Appl_EntryCounter)
	{
		if (CompareBCD(&ApplVar.SubTotal, &ApplVar.Amt) < 1)	/* overtendering ? */
		{
			RESETBIT(ARROWS, BIT1); /* reset RG led */
			if (TESTBIT(ApplVar.Tend.Options, BIT4))   /* overtender is tipp? */
			{
#if(DD_ZIP==1)
				if(ApplVar.FCurr)
					PutsO(DText[0]);
				else
					PutsO(DText[1]);
				Puts1(DispAmtStr(0, &ApplVar.Entry,DISLEN));
#elif(DD_ZIP_21==1)
				Puts1(DispAmtStr(0, &ApplVar.Entry,DISLEN));
				if(ApplVar.FCurr)
				{
					PutsO(DText[0]);
					if (SysBuf[sizeof(SysBuf)- DISLENC + 3]==' ')
						CopyFrStr(&SysBuf[sizeof(SysBuf)- DISLENC], CusDText[cusCUR]);
					PutsC(&SysBuf[sizeof(SysBuf)- DISLENC]);
				}
				else
				{
					PutsO(DText[1]);
					if (SysBuf[sizeof(SysBuf)- DISLENC + 3]==' ')
						CopyFrStr(&SysBuf[sizeof(SysBuf)- DISLENC], CusDText[cusTOT]);
					PutsC(&SysBuf[sizeof(SysBuf)- DISLENC]);
				}
#else
				if (ApplVar.FCurr)
				{
					PutsO(DispAmtStr(DText[0], &ApplVar.Entry,DISLEN));
				}
				else
				{
					PutsO(DispAmtStr(DText[1], &ApplVar.Entry,DISLEN));
				}
#endif
			}
			else
			{//��ʾ������
				ApplVar.AmtDecimal = NO_DECIMAL;     /* local format */
				ApplVar.Price = ApplVar.Amt;
				Subtract(&ApplVar.Price, &ApplVar.SubTotal);
#if(DD_ZIP==1)
				Puts1(DispAmtStr(DText[2], &ApplVar.Price,DISLEN));//ccr20131104
#elif(DD_ZIP_21==1)
				Puts1(DispAmtStr(DText[2], &ApplVar.Price,DISLEN));//ccr20131104
                PutsC(DispAmtStr(CusDText[cusCHG], &ApplVar.Price,DISLENC)); //ccr20131104
#else
				PutsO(DispAmtStr(DText[2], &ApplVar.Price,DISLEN));
#endif
			}
			if (!ApplVar.FRegi)       /* registration */
				ApplVar.FTend = 0;
		}
		else
		{		    /* undertendering */
			ApplVar.Price = ApplVar.SubTotal;
			ApplVar.AmtDecimal = NO_DECIMAL;
			Subtract(&ApplVar.Price, &ApplVar.Amt);
            //��ʾ�������
//ccr20131104>>>>>>>>>>>>
#if(DD_ZIP==1)
			PutsO(DispAmtStr(DText[36], &ApplVar.Price,DISLEN));
#elif(DD_ZIP_21==1)
			PutsO(DispAmtStr(DText[36], &ApplVar.Price,DISLEN));
			PutsC(DispAmtStr(CusDText[cusSUB], &ApplVar.Price,DISLENC));
#else
			PutsO(DispAmtStr(DText[36], &ApplVar.Price,DISLEN)); /*    sub in local     */
#endif
//<<<<<<<<<<<<<<
			if (!ApplVar.FRegi)
			{
				ApplVar.FTend = 1;
				ApplVar.SubTotal = ApplVar.Price;
			}
		}
	}
	else if (ApplVar.FRegi || ApplVar.FTend) /* registration or tender ? */
	{
		RESETBIT(ARROWS, BIT1); /* reset RG led */
//ccr20131104>>>>>>>>>>>>>
        //�ڵ�һ����ʾӦ�ս��
#if(DD_ZIP==1)
		if (ApplVar.FCurr)
		{
			PutsO(DispAmtStr(DText[0], &ApplVar.Entry,DISLEN));
		}
		else
		{
			PutsO(DispAmtStr(DText[1], &ApplVar.Amt,DISLEN));
		}
#elif(DD_ZIP_21==1)
		if (ApplVar.FCurr)
		{
			PutsO(DispAmtStr(DText[0], &ApplVar.Entry,DISLEN));
			PutsC(DispAmtStr(CusDText[cusCUR], &ApplVar.Entry,DISLENC));
		}
		else
		{
			PutsO(DispAmtStr(DText[1], &ApplVar.Amt,DISLEN));
			PutsC(DispAmtStr(CusDText[cusTOT], &ApplVar.Amt,DISLENC));
		}
#else
		if (ApplVar.FCurr)
		{
			PutsO(DispAmtStr(DText[0], &ApplVar.Entry,DISLEN));
		}
#if (!defined(CASE_MALTA))
		else
		{
			PutsO(DispAmtStr(DText[1], &ApplVar.Amt,DISLEN));
		}
#endif
#endif
//<<<<<<<<<<<<<<<<<
		if (!ApplVar.FRegi)
			ApplVar.FTend = 0;
	}

	if (ApplVar.FRegi)	 /* registration */
	{

		ApplVar.TendFlags |= (1<<ApplVar.TendNumber);//��Ǹ��ʽ

		ApplVar.AmtDecimal = NO_DECIMAL;
		if (TESTBIT(ApplVar.Tend.Options, BIT0)) /* open drawer ? */
			ApplVar.OpDraw = 1;
		if (ApplVar.FRecIssue)
		{
			NewReceipt();
			RESETBIT(ApplVar.PrintLayOut, BIT1);
			RESETBIT(ApplVar.Tend.Print, BIT1);
		}
		ApplVar.FRecIssue = 0;
		StoreInBuffer();
		ApplVar.RGRec.Key.Code = 0;
		if (!ApplVar.FTend)   /* already in tender ? */
		{
			ApplVar.Price = ApplVar.Amt;    /* save ApplVar.Amt */
			RegiEnd();   //@@@@@@@@@@@@@@@@@

			ApplVar.FSale = 0;
			ApplVar.Amt = ApplVar.Price;
			ApplVar.PrintLayOut = ApplVar.Tend.Print;	    /* restore print */
			ApplVar.RGRec.Key.Code = 299;    /* end transaction */
			StoreInBuffer();
			ApplVar.RGRec.Key.Code = 0;
			ApplVar.FTend = 1;
#if defined(FISCAL)    // liuj 0805
			if(TESTBIT(ApplVar.Fiscal_PrintFlag,BIT0))
				SETBIT(ApplVar.Fiscal_PrintFlag,BIT1);
#endif
		}

		if (TESTBIT(ApplVar.Tend.Options, BIT3) && ApplVar.FNum == 1)	 /* number entry ? */
			PrintNumber(&ApplVar.NumberEntered);
		ApplVar.FNum = 0;

		ApplVar.Price = ZERO;
		if (Appl_EntryCounter)
		{
			if (CompareBCD(&ApplVar.SubTotal, &ApplVar.Amt) < 1 ||((ApplVar.SubTotal.Sign & 0x80) == 0x80 && (ApplVar.Amt.Sign & 0x80) == 0))	/* overtendering ? */
			{//���踶��������(����Ľ���������֧�����)
				Subtract(&ApplVar.Amt, &ApplVar.SubTotal);  /* calculate change */

				BCDValueToULong(ApplVar.SubTotal.Value, (unsigned long *)&sAmount);
				if (TESTBIT(ApplVar.Entry.Sign,BIT7))
					sAmount = -sAmount;
				if (ApplVar.Tend.Over && TESTBIT(ApplVar.Tend.Options, BIT4))	/* overtender is tipp? */
				{
					ApplVar.DrawNumber = ApplVar.Tend.Over - 1;    /* add tip */
					ReadDrawer();
					PrintAmt(ApplVar.Draw.Name, &ApplVar.Amt);
					ApplVar.RGRec.Key.Code = DRAW+ApplVar.Tend.Over;	/* store overtender */
					ApplVar.RGRec.Amt = ApplVar.Amt;
					ApplVar.RGRec.Amt.Sign ^= 0x80;
					ApplVar.RGRec.Qty = ONE;
					StoreInBuffer();
					ApplVar.RGRec.Key.Code = 0;
					ApplVar.Price = ApplVar.Entry;
					if (ApplVar.FCurr)
						Add(&ApplVar.Price, &ApplVar.Amt);	/* Add ApplVar.Entry in ApplVar.Report */
				}
				else
					ApplVar.Price = ApplVar.SubTotal;
				if (ApplVar.FCurr)
				{
					PrintStr(ApplVar.Curr.Name);
					ApplVar.AmtDecimal = ApplVar.Curr.Options & BIT0;
					Prefix1 = ApplVar.Curr.Prefix1;
					Prefix2 = ApplVar.Curr.Prefix2;
					GetCurrency(0, &ApplVar.Price); /* calculate currency */
				}

				if (!TESTBIT(ApplVar.Tend.Options, BIT4))   /* overtender is tipp? */
                {
                    PrintAmt(ApplVar.Tend.Name, &ApplVar.Entry);//ccr2014-08-19
					//ccr2014-08-19PrintAmt(Prompt.Caption[8], &ApplVar.Entry);
                }
				else//ccr20130417
					PrintAmt(ApplVar.Tend.Name, &ApplVar.Price);

				ApplVar.AmtDecimal = NO_DECIMAL;
				Prefix1 = PREFIX_1;
				Prefix2 = PREFIX_2;
				ApplVar.Price = ApplVar.Amt;	/* change */
				if (TESTBIT(ApplVar.Tend.Options, BIT4))   /* overtender is tipp? */
					ApplVar.Amt = ApplVar.Entry;
				else
				{
					SETBIT(ApplVar.PrintLayOut, BIT2);	/* double height */
					ApplVar.SlipDouble = 1;
					if (CheckNotZero(&ApplVar.Price))//ccr091015
						PrintAmt(Prompt.Caption[9], &ApplVar.Price);//��ӡ������
					ApplVar.PrintLayOut = ApplVar.Tend.Print;	    /* restore print */
					if (ApplVar.FCurr)	    /* print change in currency ? */
					{
						if (TESTBIT(ApplVar.Curr.Options, BIT1))
						{
							GetCurrency(2, &ApplVar.Price);
							ApplVar.AmtDecimal = ApplVar.Curr.Options & BIT0;
							Prefix1 = ApplVar.Curr.Prefix1;
							Prefix2 = ApplVar.Curr.Prefix2;
							PrintAmt(ApplVar.Curr.Name, &ApplVar.Price);
							Subtract(&ApplVar.Entry, &ApplVar.Price);
						}
					}
					ApplVar.Amt = ApplVar.SubTotal;
				}
				ApplVar.FTend = 0;
				ApplVar.FRegi = 0;
#if DD_FISPRINTER
				SETBIT(ApplVar.DocCount, OVERTEND);		//20070313
#endif
			}
			else//(����Ľ����������֧�����)
			{			/* undertendering */
				if (!ApplVar.FBuffer)	/* buffer full then must */
				{		/* finalise without split */
					if (ApplVar.FCurr)
					{
						PrintStr(ApplVar.Curr.Name);
						ApplVar.AmtDecimal = ApplVar.Curr.Options & BIT0;
						Prefix1 = ApplVar.Curr.Prefix1;
						Prefix2 = ApplVar.Curr.Prefix2;
					}
					if (ApplVar.FRefund)
						ApplVar.Entry.Sign ^= 0x80;
					PrintAmt(ApplVar.Tend.Name, &ApplVar.Entry);/* ��ӡ������ */
#if (DD_ZIP || DD_ZIP_21)
                    /* ��ʾ������ */
                    Puts1(DispAmtStr(ApplVar.Tend.Name, &ApplVar.Entry, DISLEN));//ccr20131104
#endif
					BCDValueToULong(ApplVar.Entry.Value, (unsigned long *)&sAmount);
					if (TESTBIT(ApplVar.Entry.Sign,BIT7))
						sAmount = -sAmount;
					Subtract(&ApplVar.SubTotal, &ApplVar.Amt);
					if (ApplVar.FCurr)
					{
						ApplVar.AmtDecimal = NO_DECIMAL;
						Prefix1 = PREFIX_1;
						Prefix2 = PREFIX_2;
						PrintAmt(Prompt.Caption[1], &ApplVar.SubTotal);

					}
#if DD_FISPRINTER
					SETBIT(ApplVar.DocCount, HAVETEND);		//20070313
#endif
				}
				else
				{
					ApplVar.ErrorNumber=ERROR_ID(CWXXI44);	/* must finalise without split */
					return;
				}
			}
		}
		else//û������������,Ĭ��ȫ���,���踶��������
		{
			if (ApplVar.FCurr)
			{
				PrintStr(ApplVar.Curr.Name);
				ApplVar.AmtDecimal = ApplVar.Curr.Options & BIT0;
				Prefix1 = ApplVar.Curr.Prefix1;
				Prefix2 = ApplVar.Curr.Prefix2;
			}
            //���ø�����
			PrintAmt(ApplVar.Tend.Name, &ApplVar.Entry);
//ccr20131104>>>>>
        //�ڵڶ�����ʾʵ�ս��
#if(DD_ZIP==1 || DD_ZIP_21==1)
    		Puts1(DispAmtStr(ApplVar.Tend.Name, &ApplVar.Entry,DISLEN));
#else
//	    	PutsO(DispAmtStr(ApplVar.Tend.Nam, &ApplVar.Entry,DISLEN));
#endif
//<<<<<<<<<<<<<<<<<<<

			BCDValueToULong(ApplVar.Entry.Value, (unsigned long *)&sAmount);
			if (TESTBIT(ApplVar.Entry.Sign,BIT7))
				sAmount = -sAmount;
			ApplVar.FRegi = 0;
			ApplVar.FTend = 0;
#if DD_FISPRINTER
			SETBIT(ApplVar.DocCount, OVERTEND);		//20070313
#endif

		}

#if (DD_CHIPC==1)
		if (payIC==1 && !Appl_EntryCounter)//ccr chipcard ccr epos
		{
			PrintChipCard(payIC);
			ApplVar.PluPriceLevel = 0;
		}
//		else //ccr ePos
#endif

#if 0	//cc 20070930
#if !defined(FISCAL)
//ccr ePos>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
		if (payIC==2)
		{
			PrintePosTAC();
		}
//ccr epos<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#endif
#endif
		if (ApplVar.FRefund)
		{
			ApplVar.FRefund = 0;
			ApplVar.Amt.Sign ^= 0x80;
		}
		ApplVar.Qty = ONE;
		if (ApplVar.FCurr)
			AddCurrTotal();
		else
		{
#if(CASE_RAMBILL)
			Collect_Given(); //    lyq2003
#endif
			AddTenderTotal();
		}
		if (ApplVar.PbNumber)
		{
			Add(&ApplVar.FRetAmt,&ApplVar.FpbRetAmt);		//ccr091223
			Add(&ApplVar.FRetTax,&ApplVar.FpbRetTax);		//ccr091223
			ApplVar.FpbRetAmt = ApplVar.FpbRetTax = ZERO;	//ccr091223

			AddPbtTotal();
		}
		ApplVar.RGRec.Key.Code = ApplVar.Key.Code;
		ApplVar.RGRec.Amt = ApplVar.Amt;
		ApplVar.RGRec.Qty = ZERO;
		ApplVar.BufCmd = 0;		/* don't consolidate tendering functions */


		if (ApplVar.FCurr || ApplVar.Tend.Over)
		    ApplVar.Amt = ApplVar.Entry;
		if (ApplVar.FCurr)
		    *((WORD *)ApplVar.RGRec.Qty.Value) = CURR + ApplVar.CurrNumber;
		StoreInBuffer();

		ApplVar.RGRec.Key.Code = 0;

		if (ApplVar.FCurr)
		{
		    if (ApplVar.Curr.Drawer)
		    {
				ApplVar.DrawNumber = ApplVar.Curr.Drawer - 1;
				AddDrawerTotal();
			    ApplVar.RGRec.Key.Code = DRAW+ApplVar.Curr.Drawer;	  /* store drawer */
				ApplVar.RGRec.Amt = ApplVar.Amt;
				ApplVar.RGRec.Qty = ZERO;
			    StoreInBuffer();
				ApplVar.RGRec.Key.Code = 0;
		    }
		    ApplVar.Amt = ZERO;
		    if (!TESTBIT(ApplVar.Curr.Options, BIT1))	 /* change in local */
		    {
				if (!ApplVar.Tend.Over)
				{
				    ApplVar.Amt = ApplVar.Price;		    /* change in local */
				    ApplVar.Amt.Sign ^= 0x80; /* invert sign */
				}
		    }
		    else
				ApplVar.Price = ZERO;
		}

		if (ApplVar.Tend.Drawer)
		{
		    ApplVar.DrawNumber = ApplVar.Tend.Drawer - 1;
		    AddDrawerTotal();
		    ApplVar.RGRec.Key.Code = DRAW+ApplVar.Tend.Drawer;	  /* store drawer */
			ApplVar.RGRec.Amt = ApplVar.Amt;
			ApplVar.RGRec.Qty = ZERO;
		    StoreInBuffer();
			ApplVar.RGRec.Key.Code = 0;
		}
		if (ApplVar.Tend.Over)
		{

		    ApplVar.Amt = ApplVar.Price;
		    ApplVar.Amt.Sign ^= 0x80; /* invert sign */

		    ApplVar.DrawNumber = ApplVar.Tend.Over - 1;
		    AddDrawerTotal();
		    if (!TESTBIT(ApplVar.Tend.Options, BIT4))	/* overtender is not tip? */
			{
			    ApplVar.RGRec.Key.Code = DRAW+ApplVar.Tend.Over;	/* store overtender */
				ApplVar.RGRec.Amt = ApplVar.Amt;
				ApplVar.RGRec.Qty = ZERO;
			    StoreInBuffer();
				ApplVar.RGRec.Key.Code = 0;
			}
		}
		if (!ApplVar.FRegi)   /* end of registration ? */
		{//���踶����֧�����
            ApplVar.UserInfo.InputType=0;//ccr2014-PANAMA

#if (defined(CASE_MALTA))
		    //PrintLine('-');  //��Լֽ��
		    CalculateTax(2);        /* ccr091210 only print and calculate tax */
#endif
#if (BARCUSTOMER==1)
			if ((ApplVar.Key.Code != TEND + 6) && ApplVar.BarCustomer.OFFIndex>0)
			{// Print the customer message //
					sSave = ZERO;
					sTotal = ZERO;
					memcpy(&ApplVar.Price.Value,ApplVar.Plu.Price[0],5);
					memcpy(sSave.Value,ApplVar.Plu.Random,ApplVar.AP.Plu.RandomSize);
					strcpy(ProgLineMes,FormatQtyStr(0,&sSave,14));
					strcpy(ProgLineMes+14,Msg[ZONGJI].str);
					RJPrint(0,FormatAmtStr(ProgLineMes,&ApplVar.Price,PRTLEN));
					ApplVar.PluPriceLevel = 0;
			}
			ApplVar.BarCustomer.OFFIndex = 0;// ��ʶû�л�Ա��¼  //
#endif
		    ApplVar.AmtDecimal = NO_DECIMAL;	    /* restore local values for kp */
		    Prefix1 = PREFIX_1; 			/* and VAT print */
		    Prefix2 = PREFIX_2;
		    if (ApplVar.OpDraw)
                OpenDrawer();
		    StoreInBuffer();

		    if (ApplVar.PbNumber)
			PrintNewBal();

		    if (PVAT)
				CalculateTax(3);    /* print inclusive tax */

			PrintSaleQty();//��ӡ������Ŀ��Ŀ

		    PromtionCheck();
		    ReceiptIssue(1);       //���踶��������

		    ApplVar.BufCC = 1;		       /* set add Customer Count */
		    ProcessBuffer();	/* reset Customer count and print kp */
		    ApplVar.PbNumber = 0;
		    ApplVar.FNoPb = 0;		/* reset extra ApplVar.PB Trailer and NO ApplVar.PB */
		    ApplVar.FSplit = 0;
#if (defined(CASE_INDONESIA) && (defined(CASE_GPRS)))
            if (TESTBIT(ApplVar.DaysMust,BIT7))//���Զ��������ݣ�������ˮ
            {
                SETBIT(ApplVar.MyFlags,ZREPORT);
                ApplVar.FCurr = 0;
                ApplVar.AmtDecimal = NO_DECIMAL;	    /* restore local values */
                Prefix1 = PREFIX_1;
                Prefix2 = PREFIX_2;
                GPRSSendECR_LOG();
            }
#endif
#if(DD_ZIP || DD_ZIP_21)
            /* ������� */
            Puts1(DText[37]);//ccr20131104 finished
#endif

		}
    }
	else//ccr 050301>>>>>>>>>>>>>>>>>>>>>>>>>>>
		if (TESTBIT(ApplVar.Tend.Options, BIT0) && !Appl_EntryCounter)
		{
		    if (ApplVar.CentralLock==MG)
	    	{
			    ApplVar.DrawNumber = ApplVar.TendNumber;
				DispDrawerTotal();
	    	}
		}
    RESETBIT(ApplVar.MyFlags, ENSLIPPB);	 //lyq added for slip 20040324
    SETBIT(ApplVar.MyFlags,ZREPORT);
    ApplVar.FCurr = 0;
    ApplVar.AmtDecimal = NO_DECIMAL;	    /* restore local values */
    Prefix1 = PREFIX_1;
    Prefix2 = PREFIX_2;
#if defined(FISCAL)    // liuj 0805
    if(! TESTBIT(ApplVar.Fiscal_PrintFlag, BIT7))
        ApplVar.Fiscal_PrintFlag = 0; // liuj 0529
#endif
}


