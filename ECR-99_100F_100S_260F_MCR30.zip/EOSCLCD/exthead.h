//------------------------For Debug--------------------------
#include "debug.h"
//------------------------For Debug--------------------------


/******************* Working Lay Out with Assembly language ******************/

extern BYTE
    InActive,               /* Activity timer for displaying Time */
	CopyReceipt,
	ARROWS,         /* define ARROWS ArrowsRight */
                    //(ARROWS, BIT0);   set receipt on
                    //(ARROWS, BIT1);   set RG led,��ʶ��������״̬(û��ʹ��)
	Prefix1,
	Prefix2 ;

extern UnLong RamOffSet,
		 FisOffSet ;

extern CONST WORD SORT[7] ;

/******************* Working Memory Lay Out with C language ******************/


extern BCD
	ZERO,
	ONE,
	TEN,
	HUNDRED,
	THOUSAND,
	THOUSAND10,
	THOUSAND100,
	MAXWORD,
	MAXBYTE,
	MILLION,
	MILLION10,
	MAXLONG;

extern BCD
	PluInventory;

extern  UnLong
//cc 2006-07-06 for MMC>>>>>
#if(DD_MMC==1)
	MMCLast,
#endif
//cc 2006-07-06 for MMC>>>>>
	AutoCheck;
#if BONUS == 1
extern  UnLong
	BonusPoints;
#endif

extern char PassMes[3][9] ;
extern struct TimeDate StartTime ;
extern struct APPTEXT DefaultText ;
extern struct APPLICATION Default ;
extern struct DEFAULT Def ;

extern CONSTCHAR DMes[][lenDMes] ;
extern CONSTCHAR DText[][lenDText] ;


#if(DD_ZIP_21==1)
#define  cusTOT    0
#define  cusSUB    1
#define  cusCHG    2
#define  cusPRI    3
#define  cusCAN    4
#define  cusCUR    5
#define  cusCOV    6

extern CONSTCHAR CusDText[][4];//[4];
#endif


extern CONST char UPCOMM[][4];

#if COMPOSEIN
extern CONST char CodeASC[NUMASC][4];
#endif

extern CONST struct XZREPORT XZTitle[XZNUM];

extern CONST WORD  KeyTablePBF[MAXKEYB];

extern CONST char PortType[portTypeNum][PORTTYPELEN];

extern const BYTE KPArticleCmd[KPTypeNum-2];
extern CONST char KPType[KPTypeNum][7];
extern CONST char SPType[SPTypeNum][8];		//lyq added 20040331

extern CONST struct SYSFLAGIDX SysFlagUsed[SYSUSED];
extern CONST char GrapType[GRASETMAX][tCAPWIDTH];
extern CONST char GrapSet[4][tCAPWIDTH];

extern CONST char Release[16] ;
extern CONST char ReleaseDate[];


extern CONSTCHAR ConfTab[][17];
extern CONSTCHAR ConfTi[][PRTLEN+1];


extern CONST FSTRING Msg[];


extern CONST BYTE	ASCIIKEY[MAXKEYB];
extern CONST BYTE	NUMASC_KEYBOARD[MAXKEYB];


#if (DD_FISPRINTER)
extern BYTE	LED_BLNK;	//��ʼֵ=_LED_BLNKFreq,����0ʱ,�ı�ָʾ�Ƶ�״̬ //
extern BYTE 	LED_BLNKFreq; //ָʾ����˸Ƶ��,=0ʱ,����˸	//
extern WORD  SelectCounter,EnterCounter;// ͳ�Ƽ����µ�ʱ�� //

extern CONST FSTRING MsgError[];
#else
extern CONST FSTRING CommandSet[];
#endif

#if (pbAmtDisc)
extern WORD	LastKey;//ccr091210 �������۵��������һ�����۵ĵ�Ʒ����Ĺ�����() //
#endif

extern CONST struct PROMPTTEXT Prompt;
extern struct TimeDate     Now;
extern short	PCCounter,CCDCounter;

extern BYTE DialTime;// store the second when dialup
extern BYTE DialSkiped;//flags


extern BYTE
    ApplVar_Restored,
    ApplRamSaved,               //ApplVar �����־
    MACSwitch,  //0=MAC is off;1=MAC is on
    BitNumber,              /* used during programming */
    ProgLine,                /* programming type line */
    ProgStart,               /* programming started */
    ProgType,               /* programming type status */
    Appl_MaxEntry,               //Max length of input from keyboard
    Appl_EntryCounter;                   /* entry counter */

extern BYTE
    ModeHead[tCAPWIDTH+1],
    PwdInput[MAXPWD],       //    Save the password of input
    PCBuffer[PCBUFMAX], // !!!!!!!��Ҫ�ƶ�PCBuffer��Ϊ�˽�Լ�ռ�,��Щ�ط�����PCBuffer�����ı������ʹ�� !!!!!!//
    EntryBuffer[73],                /*    entry buffer is ((max caption size) * 2) + 1     */
    ProgLineMes[64],            /* Ϊ������ʾʱ,������ñ��������,��ʾ�ڵ�һ�� */
                                /* Ϊ˫����ʾʱ��������������ñ���,��ʾ�ڵ�һ�� */
#if (DD_ZIP==1 || DD_ZIP_21==1)
    ProgLine1Mes[64],       //Ϊ˫����ʾʱ���������������,��ʾ�ڵڶ���
#endif
    SysBuf[128],            /*    System buffer max 128 positions     */
    SetDateFlg,             //used for set up date and time
    DateAsci[16],           /*    holds asci date: "Mon,2014-01-21" or "Mon,21-01-2014" */
    TimeAsci[10];                    /* holds asci time:12:23:34*/

#if DD_CHIPC
extern struct  ICStruct IC;                //ccr chipcard
#endif

extern WORD
    FieldNumber[15];


extern APPLICATION_SAVE ApplVar;

#if defined(DEBUGBYPC)
extern BYTE LoopInput;
#endif

extern BYTE    Power_Fail;

extern struct DISPLAY_RGBUF
    Appl_DispRGBuf;

