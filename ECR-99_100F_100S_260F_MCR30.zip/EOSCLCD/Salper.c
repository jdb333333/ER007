#define SALPER_C 2
#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"


/***************************************************************/

void GetSalPerOffSet()
{
	RamOffSet = (ApplVar.SalPerNumber - 1) * ApplVar.AP.SalPer.RecordSize + ApplVar.AP.StartAddress[AddrSalPer];
}

void WriteSalPer()
{
    if (ApplVar.SalPerNumber <= ApplVar.AP.SalPer.Number)
    {
		GetSalPerOffSet();
		WriteRam(ApplVar.SalPer.Name, ApplVar.AP.SalPer.CapSize);
		WriteRam(&ApplVar.SalPer.Options, sizeof(ApplVar.SalPer.Options));
    }
}

void ReadSalPer()
{
    GetSalPerOffSet();
    if (ApplVar.AP.SalPer.Number)
    {
		ReadRam(ApplVar.SalPer.Name, ApplVar.AP.SalPer.CapSize);
		ReadRam(&ApplVar.SalPer.Options, sizeof(ApplVar.SalPer.Options));
		ApplVar.SalPer.Name[ApplVar.AP.SalPer.CapSize] = 0 ;
    }
}


void SelectSalPer()
{
    WORD newsalper;


	if (ApplVar.CentralLock != RG && ApplVar.CentralLock != MG)
	{
		ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
		return;
	}

    newsalper = 0;
	if (ApplVar.Key.Code == SALPER && ApplVar.NumberEntry < 256)
		newsalper = ApplVar.NumberEntry;
    else if (!Appl_EntryCounter)
	{
		newsalper = ApplVar.Key.Code - SALPER;
		ApplVar.Entry = ZERO;
		WORDtoBCD(ApplVar.Entry.Value, newsalper);
    }
	if (!newsalper || newsalper > ApplVar.AP.SalPer.Number)
    {
	    ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
		return;
    }
	if (ApplVar.FRegi)    /* still in regi no change salesperson */
    {
	    if (TESTBIT(KEYTONE, BIT7))
		{
			ApplVar.ErrorNumber=ERROR_ID(CWXXI14);   /* still in registration */
		    return;
		}
	}
    if (ApplVar.RGRec.Key.Code < SALPER || ApplVar.RGRec.Key.Code > SALPER + 255)
		StoreInBuffer();
    ApplVar.RGRec.Key.Code = SALPER + newsalper;  /* store in buffer for correct CC update */
	ApplVar.SalPerNumber = newsalper;
    ReadSalPer();

	PutsO(DispQtyStr(DText[17], &ApplVar.Entry,DISLEN));

}

