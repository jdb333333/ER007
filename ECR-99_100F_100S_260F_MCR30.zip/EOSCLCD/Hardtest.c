#define HARDTEST_C 7
#include "king.h"               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
#include "flowbill.h"
#include "ejournal.h"
#include "fiscal.h"
#include "message.h"


#define TEST    0

void PrintConfInf(void);		// lyq added 20040303

long TestLMM(WORD lmmPage);

#if TEST == 0
void DumpChina(short progNumber)
{
	BYTE i,j,k,c ;

	if (ApplVar.NumberEntry == 100)
	{
		i = 0;
		k = 95;
	}
	else
	{
		i = ApplVar.NumberEntry - 100;
		k = i+progNumber;
		if(!progNumber)
			k ++ ;
		if (k>195)
			k=195;
	}
	while (i < k && i < 95)
	{
		MemSet(SysBuf+11, PRTLEN, ' ');
		ApplVar.PrintLayOut = 0x06;
		SysBuf[11] = i / 10 + '0';
		SysBuf[12] = i % 10 + '0';
		SysBuf[13] = 'X';
		SysBuf[14] = 'X';
		PrintStr(SysBuf+11);
		SysBuf[13] = '0';
		ApplVar.PrintLayOut = 0x02;
		c = 0;
		for (j = 1; j < 95; j++)
		{
			if(KbHit() && Getch() == ApplVar.AP.FirmKeys[ID_CLEAR])
				return;
			SysBuf[16+c] = ' ';
			SysBuf[11+c] = j / 10 + '0';
			SysBuf[12+c] = j % 10 + '0';
			SysBuf[13+c] = ' ';
			SysBuf[14+c] = i + 0xa0;               /* page number */
			SysBuf[15+c] = j + 0xa0;                         /* offset */
			c += 6;
		if(c>=24 || j==94)
			{
			SysBuf[11+c] = 0;
			PrintStr(SysBuf+11);
			c=0;
			}

		}
		i++;
	}
}
#else
void DumpChina(short progNumber)
{
	BYTE i,j,k ;

	if (ApplVar.NumberEntry == 100)
	{
		i = 0;
		k = 95;
	}
	else
	{
		i = ApplVar.NumberEntry - 100;
		k = i+1;
	}
	while (i < k)
	{
		MemSet(SysBuf+11, PRTLEN, ' ');
		ApplVar.PrintLayOut = 0x06;
		SysBuf[11] = i / 10 + '0';
		SysBuf[12] = i % 10 + '0';
		SysBuf[13] = 'X';
		SysBuf[14] = 'X';
		SysBuf[0] = i + 0x20;
		HEXtoASC(SysBuf+27, SysBuf, 1);
		SysBuf[29] = 'X';
		SysBuf[30] = 'X';
		PrintStr(0,SysBuf+11);
		SysBuf[17] = i+160;
		ApplVar.PrintLayOut = 0x02;
		for (j = 1; j < 95; j++)
		{
		if (KbHit() && Getch() == ApplVar.AP.FirmKeys[ID_CLEAR])
				return;
			WORDtoASC(SysBuf+24, ((i-1)*94)+j);
			SysBuf[18] = j+160;
            if (1) /*(ExternFont != 0xff)*/
			{       /* debug */
					 /*       if (!GetFontT(*((WORD *)(SysBuf+17)), 0))*/
					continue;
			}
			SysBuf[13] = j / 10 + '0';
			SysBuf[14] = j % 10 + '0';
			SysBuf[0] = j + 0x20;
			HEXtoASC(SysBuf+29, SysBuf, 1);
			PrintStr(0,SysBuf+11);
		}
		i++;
	}
}
#endif



void TestPrinter()
{
	short i,j;

#if (DD_FISPRINTER==0)
	StoreEJEnd();//ccr070609pm
#endif
//cc 20070312 for EN>>>>>>>>>>>>>>>>>>
	OutPrint(CMDP_R, MessageE13);		//Normale
	OutPrint(CMDP_DR, MessageE14);				//Doppia altezza
	OutPrint(CMDP_R, MessageE15);	//Raddoppio caratteri
	OutPrint(CMDP_R, MessageE16);	//Raddoppio caratteri
	OutPrint(CMDP_DR, MessageE17);		//Dopia altezza + Raddoppio caratteri

//cc 20070312 for EN>>>>>>>>>>>>>>>>>>
	OutPrint(CMDP_LFR, NULL);								//Line Feed standard
	OutPrint(CMDP_LFR, NULL);								//Line Feed standard
	OutPrintEx(((1 << B_PRI_RON) | (1 << B_PRI_FCUT)), NULL, 50); //taglio carta + 100 dot-lines bianche

/*	for (i=0;i<TEXTSOFGRAPH;i++)
	{
		strcpy(&ApplVar.GrafTexts[i], "\xcd\xbc\xcf\xf1 TEXT RAM   ");
		ApplVar.GrafTexts[i][14] = i +'A';
	}
*/
#if (DD_FISPRINTER==0)
//	if (ApplVar.Graph[0].PictNo>0)
//		i = ApplVar.Graph[0].PictNo;
//    if (i>=GRAPHICMAX-5)
//        i = GRAPHICMAX-5;
//	else
		i = 1;

	RJPrint(0,MessageE20);
	Bios(BiosCmd_PrintGraph, (void*)i, 0 , 10);i++; //Stampa msg ram
	RJPrint(0,MessageE21);
	Bios(BiosCmd_PrintGraph, (void*)i, 2 , 20);i++;  //Get info+reload default
	RJPrint(0,MessageE22);
	Bios(BiosCmd_PrintGraph, (void*)i, 1, 10); //Stampa msg ram
#endif
    //�����ַ���ӡ
    for (j=0,i=33;i<256;i++)
    {
        SysBuf[j++] = i;
        if (j == PRTLEN)
        {
            SysBuf[j] = 0;
            RJPrint(0,SysBuf);
            j = 0;
        }
    }
    if (j>0)
    {
        SysBuf[j] = 0;
        RJPrint(0,SysBuf);
    }

    //�������ߴ�ӡ
    SysBuf[0] = '@';
    for (j=1,i=33;i<256;i++)
    {
        SysBuf[j++] = '~';
        SysBuf[j++] = i;
        if (j >= PRTLEN)
        {
            SysBuf[j] = 0;
            RJPrint(0,SysBuf);
            j = 1;
        }
    }
    if (j>1)
    {
        SysBuf[j] = 0;
        RJPrint(0,SysBuf);
    }

}

void TestDisplayer()
{
	short i,j;

	MemSet(SysBuf,DISLEN,' ');

	for (j=0;j<2;j++)
		for (i=0;i<DISLEN;i++)
		{
			SysBuf[i]='8' + 0x80;
			PutsO(SysBuf);
			Delay(ASECOND/5);
			SysBuf[i]=' ';
		}
}

void PrintVersion()
{
	WORD i,print;

//cc 20070930>>>>>>>>>>>>>>>
#if(!defined(FISCAL))
	memset(SysBuf,' ', sizeof(SysBuf));
	DateTimeToStr(SysBuf,3);

	RJPrint(0,SysBuf);
#endif
//cc 20070930>>>>>>>>>>>>>>>

	RJPrint(0,DMes[26]);
	SysBuf[0] = SysBuf[1] = ' ';
	strcpy(SysBuf+2,Release);
	strcpy(SysBuf+strlen(SysBuf),MessageE24);
	i = CheckSum();
	print = strlen(SysBuf);
	HEXtoASC(SysBuf+print, (char *)&i, 2);

	SysBuf[print+4] = 0;
    	RJPrint(0, SysBuf);

	memset(SysBuf,' ', sizeof(SysBuf));
	strcpy(SysBuf+2,__DATE__);//100831 ReleaseDate);
	i=strlen(SysBuf);	SysBuf[i] = ',';
	strcpy(SysBuf+i+1,__TIME__);//100831 ReleaseDate);

   	RJPrint(0,SysBuf);
}

void TestRomRam()
{
	WORD print;
    long lmmAddr,ramAddr;


    //ccr20131112>>>>>>>>>>>
	while( TestPrintGoingOn() )	{};//��ӡʱ,��ֹTestLMM
    ramAddr = TestRam();// ������չRAM (10000H-27fff) //
    lmmAddr = TestLMM(0);// ������չRAM (��Ӱ���ӡ��������)
    //<<<<<<<<<<<<<<<<<<<<<

	PrintVersion();

	MemSet(SysBuf,PRTLEN+1,' ');
	strcpy(SysBuf,MessageE25);
	print = strlen(SysBuf);

	if (ramAddr<=0)
	{//SRAM������
		ramAddr = -ramAddr;
		strcpy(SysBuf+print-5,MessageE26);
		print = strlen(SysBuf);

	}
	HEXtoASC(SysBuf+print, (char *)&ramAddr, 3);

	SysBuf[print+6] = 'H';
	SysBuf[print+7] = 0;
    RJPrint(0, SysBuf);

	MemSet(SysBuf,PRTLEN+1,' ');
	strcpy(SysBuf,MessageE27);
	print = strlen(SysBuf);
	if (lmmAddr<0)
	{
		lmmAddr = -lmmAddr;
		strcpy(SysBuf+print-5,MessageE26);
		print = strlen(SysBuf);
	}
	HEXtoASC(SysBuf+print, (char *)&lmmAddr, 3);

	SysBuf[print+6] = 'H';
	SysBuf[print+7] = 0;
    RJPrint(0, SysBuf);
}

void TestDateTime()
{
	if (TestRtc())
	{
		RJPrint(0,MessageE28);
	}
	else
	{
		memset(SysBuf,' ',sizeof(SysBuf));
		DateTimeToStr(SysBuf+4,3);
		SysBuf[PRTLEN] = 0;
		PutsO(SysBuf+4);
        memcpy(SysBuf, Prompt.DayCap[Now.dow-1], 3);
		RJPrint(0,SysBuf);
	}
}

void TestBEEP()
{
	short i;

//	if (TESTBIT(KEYTONE,BIT0))
//    	Bios_1(BiosCmd_AutoClickOn);
//    else
//   		Bios_1(BiosCmd_AutoClickOff);
	for (i = 0; i < 4; i++)
	{
//		if (TESTBIT(KEYTONE,BIT0))
		Bell(i);
		Delay(ASECOND/2);
	}
}

void TestOpenDrawer()
{
	OpenDrawer();
}

void TestKeyboard()
{
	BYTE i;
	do{
		while (!KbHit())   FM_EJ_Exist();

		i = Getch();            /* wait keyhit */
		MemSet(SysBuf, DISLEN, ' ');
		SysBuf[0] = 'K';
		SysBuf[1] = 'E';
		SysBuf[2] = 'Y';

		WORDtoASC(SysBuf + 7, i);
		PutsO(SysBuf);
	} while (i != ApplVar.AP.FirmKeys[ID_CLEAR]);    /* until clear firmkey */
}

void TestPrnPower()
{

}


void TestSerial123()
{

	if (TestCom123(1))
		strcpy(SysBuf,MessageE29);
	else
		strcpy(SysBuf,MessageE30);
	RJPrint(0,SysBuf);

	if (TestCom123(2))
		strcpy(SysBuf,MessageE31);
	else
		strcpy(SysBuf,MessageE32);

	RJPrint(0,SysBuf);

#if (NUMPORT==3)
    if (TestCom123(3))
        strcpy(SysBuf,MessageE33_Err);
    else
        strcpy(SysBuf,MessageE33_OK);

    RJPrint(0,SysBuf);
#endif
}


void HardTest(WORD idx)
{
	WORD tstIdx;
	BYTE sKey;
	short i;
	short sSecOld,sSecNow;


	tstIdx = idx;
	i = 0;
	if (TESTBIT(tstIdx,BIT0+BIT2+BIT10+BIT11+BIT3+BIT12))	//lyq modified 20040303
    {
        StoreEJEnd();//ccr070609pm
		RJPrint(0,DMes[30]);
    }
	if (TESTBIT(tstIdx,BIT11))//2048
		InActive = ACTIVE+1;
	sKey = 0xff;
	sSecOld = 0;
	do {
        FM_EJ_Exist();
		if (sKey == ApplVar.AP.FirmKeys[ID_RJFEED])
		{
			sKey = 0xff;
			RFeed(1);
		}
		if (TESTBIT(tstIdx,BIT0))// 1
			TestPrinter();
		if (TESTBIT(tstIdx,BIT1))//  2
			TestDisplayer();
		if (TESTBIT(tstIdx,BIT2))// 4
			TestRomRam();
		if (TESTBIT(tstIdx,BIT3))// 8
			TestDateTime();
		if (TESTBIT(tstIdx,BIT4))// 16
			TestBEEP();
		if (TESTBIT(tstIdx,BIT5))// 32
			TestOpenDrawer();
		if (TESTBIT(tstIdx,BIT6))//     64
		{
			ClearEntry();   /*    PenGH  2008-08-18 15:11:44     */
			ClearLine2();
			TestKeyboard();
		}
		if (TESTBIT(tstIdx,BIT9))//     512
			TestPrnPower();
		if (TESTBIT(tstIdx,BIT10))// 1024
			TestSerial123();
        mDrawPower(2);
		if (TESTBIT(tstIdx,BIT11))// 2048
		{
			CheckTime(0x80);
			sSecNow = ((Now.min>>4)*10+(Now.min & 0x0f))*60 + (Now.sec>>4)*10+(Now.sec & 0x0f);
			if(sSecOld != sSecNow)
			{
				sSecOld = sSecNow-sSecOld;
				if (sSecOld<0)
					sSecOld += (60*60);
				i += sSecOld;
				if (i >= 300)
				{
					memset(SysBuf,' ', sizeof(SysBuf));
					DateTimeToStr(SysBuf,3);
					SysBuf[PRTLEN] = 0;
					RJPrint(0,SysBuf);
					i = 0;
				}
				sSecOld = sSecNow ;
			}
		}
	} while (TESTBIT(tstIdx,BIT11) && (!KbHit() || (sKey = Getch()) !=ApplVar.AP.FirmKeys[ID_CLEAR]));

	if (TESTBIT(tstIdx,BIT12))//4096
	{
	    PrintConfInf();
	}

	if (TESTBIT(tstIdx,BIT0+BIT2+BIT10+BIT11+BIT3+BIT12)) //lyq modified 20040303
	{
		RJPrint(0,DMes[31]);
	}

	ClearEntry();
//    cc 2070315 for smart >>>>>>>>>>>>>>>>>>>>
#if(DD_ZIP==1 || DD_ZIP_21==1)
	ClearLine2();
#else
	PutsO(EntryBuffer+sizeof(EntryBuffer)-DISLEN-1);
#endif
//cc 2070315 for smart >>>>>>>>>>>>>>>>>>>>
}

void RWRand(BYTE read,WORD  num, BYTE *to)
{
	RamOffSet = (UnLong)num * ApplVar.AP.Plu.RecordSize + ApplVar.AP.StartAddress[AddrPLU] ;
	if (!read)
		WriteRam(to, ApplVar.AP.Plu.RecordSize);
	else if (read == 1)
		ReadRam(to, ApplVar.AP.Plu.RandomSize);
	else if (read == 2)             /* read rest of record */
		ReadRam(to, ApplVar.AP.Plu.RecordSize);
}

#define RNEWL   127
void CheckPluFile(WORD type)
/* type == MERGEPLU(103) then merge file and update file */
/* type == REMOVEPLU(104) then remove deleted PLU from file */
/* type == REMMER(105) then merge and remove file */
/* type == TESTPLU(106) then check file sequence */
/* type == REPPLU(107) then check file sequence and repair */
{
	BYTE    rnew[RNEWL+1] ;      /* Read old in Sysbuf */

	if (!ApplVar.AP.Plu.RandomSize)
	{
		ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
		return;
	}
	MemSet(SysBuf, 24, ' ');
	memcpy(SysBuf, MessageE64, 7);
	WORDtoASC(SysBuf + 10, type);
	RJPrint(02, SysBuf);
	if (ApplVar.AP.Plu.RecordSize > RNEWL+1)
	{
		RJPrint(0x02, MessageE65);
		ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
		return;
	}
    ApplVar.omax = ApplVar.AP.Plu.RNumber;
	ApplVar.nmax = ApplVar.omax;
	ApplVar.errplu = 0;
	if (type != MERGEPLU) /* != 103 */
	{
		ApplVar.NewPlu = 0;
		if (type == TESTPLU || type == REPPLU) /* 106 & 107 */
		{
			rnew[RNEWL] = 0;
		}
		for (ApplVar.OldPlu = 0; ApplVar.OldPlu < ApplVar.nmax; ApplVar.OldPlu ++)
		{
			RWRand(2, ApplVar.OldPlu, SysBuf);
			if (type == TESTPLU || type == REPPLU)
			{
				if (ApplVar.OldPlu == ApplVar.omax)
					rnew[RNEWL] = 0;
				if(rnew[RNEWL] && CompareBCDValue(rnew, SysBuf, ApplVar.AP.Plu.RandomSize) >= 0)
					/* previous larger then current then delete current */
				{
					ApplVar.errplu++;
					if (type == REPPLU)
						SysBuf[ApplVar.AP.Plu.RandomSize] = 0xff;
				}
			}
			if((BYTE)SysBuf[ApplVar.AP.Plu.RandomSize] != 0xff)  /* active ? */
			{
				if (ApplVar.NewPlu != ApplVar.OldPlu)
					RWRand(0, ApplVar.NewPlu, SysBuf);         /* write back at correct position */
				ApplVar.NewPlu++;
				if (type == TESTPLU || type == REPPLU)
				{
					memcpy(rnew, SysBuf, ApplVar.AP.Plu.RandomSize);
					rnew[RNEWL] = 1;
				}
			}
			if (ApplVar.OldPlu == (ApplVar.omax - 1))  /* end of first file ? */
				ApplVar.AP.Plu.RNumber = ApplVar.NewPlu;    /* new end */
//			if (ApplVar.OldPlu == (ApplVar.nmax - 1))  /* end of second file ? */
//			{
//				ApplVar.AP.StartAddress[AddrRPLU] = ApplVar.NewPlu - (ApplVar.AP.StartAddress[AddrRPLU] & 0xffff) ;
//			}
			if (!(ApplVar.OldPlu % 10))
			{
				WORDtoASCZero(SysBuf + 7, ApplVar.OldPlu);
				SysBuf[2] = ' ';
				SysBuf[8] = 0;
				PutsO(SysBuf+2);
			}
		}
		if (type != TESTPLU)
		{
			MemSet(SysBuf, sizeof(SysBuf), 0);
			for (; ApplVar.NewPlu < ApplVar.nmax; ApplVar.NewPlu++)
				RWRand(0, ApplVar.NewPlu, SysBuf);         /* clear rest of file */
		}
		ApplVar.omax = ApplVar.AP.Plu.RNumber;
		ApplVar.nmax = 0;
		ApplVar.nmax += ApplVar.omax;
		if (type == TESTPLU || type == REPPLU)
		{
			MemSet(SysBuf, 24, ' ');
			CopyFrStr(SysBuf, DMes[17]);
			WORDtoASC(SysBuf + 10, ApplVar.errplu);
				RJPrint(2, SysBuf);
		}
	}
	if (ApplVar.nmax != ApplVar.omax && (type == MERGEPLU || type == REMMER))
	{
		if(ApplVar.omax)
		{
			for(ApplVar.errplu = 0 ; ApplVar.errplu < 6 ; ApplVar.errplu++)
			{
				for(ApplVar.OldPlu = SORT[ApplVar.errplu] ; ApplVar.OldPlu < ApplVar.nmax ; ++ApplVar.OldPlu)
				{
					RWRand(2, ApplVar.OldPlu, SysBuf);
					for(ApplVar.NewPlu = ApplVar.OldPlu-SORT[ApplVar.errplu], RWRand(1, ApplVar.NewPlu, rnew) ;
						CompareBCDValue(SysBuf, rnew, ApplVar.AP.Plu.RandomSize) < 0 ; )
					{
						RWRand(2, ApplVar.NewPlu, rnew) ;
						RWRand(0, ApplVar.NewPlu+SORT[ApplVar.errplu], rnew) ;
						ApplVar.NewPlu -= SORT[ApplVar.errplu] ;
						if(ApplVar.NewPlu < 0)
							break ;
						RWRand(1, ApplVar.NewPlu, rnew) ;

					}
					RWRand(0, ApplVar.NewPlu+SORT[ApplVar.errplu], SysBuf) ;
				}
			}
		}
	}
	ApplVar.nmax = ApplVar.AP.Plu.RNumber;
	MemSet(SysBuf, 24, ' ');
	CopyFrStr(SysBuf, Prompt.TypeCap[SETPLU-1]);
	WORDtoASC(SysBuf + 10, ApplVar.nmax);
	RJPrint(2, SysBuf);
	ClearEntry();
	PutsO(&EntryBuffer[sizeof(EntryBuffer) - DISLEN - 1]);
}



//-----------------------------------------------------------------------------------
/**
 *
 *
 * @author EutronSoftware (2014-08-04)
 *
 * @param n :��������
 * @param size :��С����
 * @param str :����
 * @param fRAM :�Ƿ�ΪRAM�ռ�,ΪRAM�ռ�ʱ,��size/1024���ӡ,����str���׷��KB
 */
void FormPrtConfInf(unsigned long n, unsigned long size, CONSTCHAR* str,BYTE fRAM)
{
	if(n == 0 && size == 0)
		return;
	MemSet(SysBuf, sizeof(SysBuf), ' ');
	if(size)
	{
        ApplVar.Entry = ZERO;//ccr20120101
        if (fRAM)
        {
            size/=1024;
            ULongToBCDValue(ApplVar.Entry.Value,size);
            FormatAmtFix(SysBuf+PRTLEN-4,&ApplVar.Entry);
            SysBuf[PRTLEN-3]=' ';
            SysBuf[PRTLEN-2]='K';
            SysBuf[PRTLEN-1]='B';
        }
        else
        {
            ULongToBCDValue(ApplVar.Entry.Value,size);
            FormatQty(SysBuf+PRTLEN-1,&ApplVar.Entry);
        }
	}
	if(n)
	{
        ApplVar.Entry = ZERO;//ccr20120101
		ULongToBCDValue(ApplVar.Entry.Value,n);
#if (PRTLEN<25)
		FormatQty(SysBuf+13,&ApplVar.Entry);
#else
		FormatQty(SysBuf+17,&ApplVar.Entry);
#endif
	}
	CopyFrStr(SysBuf, str);//, len);
	SysBuf[PRTLEN] = 0;
	RJPrint(0,SysBuf);
	return;
}

//------------------------------------------------------------------------------------
void PrintLine2(char c)          /* print line of characters */
{
    MemSet(SysBuf, PRTLEN, c);
    SysBuf[PRTLEN]=0;
	RJPrint(0, SysBuf);
}
//ccr2014-08-04>>>>>>>>>>>>>> ��ӡ��˰����ص���Ϣ //
void PrintMemoForFiscal()
{

    WORD sDateFr,sDateTo;
    ULONG   sAddr,sAddrEnd;

//ccr2014-08-04	PrintLine2('=');
	RJPrint(0, FISCALMESSAGE);
	PrintLine2('-');

#if CC_DEBUG
	FormPrtConfInf(0, ApplVar.SIZE_EXTRAM, (CONSTCHAR *)ConfTab[17],0);
#endif

#if (defined(FISCAL))
    if (ApplVar.FisCardFlag!=NOFM)
    {
#if CC_DEBUG
        FormPrtConfInf(0, FISMEMERYSIZE, (CONSTCHAR *)ConfTab[19],0);
#endif
        if (ApplVar.FisCardFlag!=FMISNEW)
        {
#if CC_DEBUG
            FormPrtConfInf(0, FISMEMERYSIZE-ApplVar.FiscalHead.MaxP, REMAINFM,0);
#endif
            FormPrtConfInf(0, (FISMEMERYSIZE-ApplVar.FiscalHead.MaxP)/FRECORDLEN, MESG_Z_BALANCE,0);//ʣ��Z����
        }
    }

	if(ApplVar.FiscalHead.MaxP > FISDATAADDR)
	{
        sDateFr = sDateTo = 0;
        for (sAddr=FISDATAADDR;sAddr<ApplVar.FiscalHead.MaxP;sAddr+=FRECORDLEN)
        {//���ҵ�һ��Z����
            if (Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,sAddr,FISRECORDLEN))
            {
                if(ApplVar.FiscalBuff.Fis_ClearRecord.FunN==FISCLEARLOG)
                {
                    sDateFr = ApplVar.FiscalBuff.Fis_ClearRecord.FDate;
                    break;
                }
            }
			else
				break;
        }
        if (sDateFr)
        {
            sDateTo = sDateFr;
            for (sAddrEnd=ApplVar.FiscalHead.MaxP-FRECORDLEN;sAddrEnd>sAddr;sAddrEnd-=FRECORDLEN)
            {//�������һ��Z����
                if (Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,sAddrEnd,FISRECORDLEN))
                {
                    if(ApplVar.FiscalBuff.Fis_ClearRecord.FunN==FISCLEARLOG)
                    {
                        sDateTo = ApplVar.FiscalBuff.Fis_ClearRecord.FDate;
                        break;
                    }
                }
				else
					break;
            }
            memset((char *)&ApplVar.FiscalTotal,0,sizeof(ApplVar.FiscalTotal));//ccr070424
#if (PRTLEN>30)
            memset(SysBuf,' ',PRTLEN);
            CopyFrStr(SysBuf, MESG_Z_START);
            DecordDateFiscal(sDateFr, SysBuf+PRTLEN-10);
            SysBuf[PRTLEN]=0;
            RJPrint(0,SysBuf);

            memset(SysBuf,' ',PRTLEN);
            CopyFrStr(SysBuf, MESG_Z_LAST);
            DecordDateFiscal(sDateTo, SysBuf+PRTLEN-10);
            SysBuf[PRTLEN]=0;
            RJPrint(0,SysBuf);

#else
            memset(SysBuf,' ',PRTLEN);
            RJPrint(0,MESG_Z_START);
            DecordDateFiscal(sDateFr, SysBuf+PRTLEN-10);
            SysBuf[PRTLEN]=0;
            RJPrint(0,SysBuf);

            memset(SysBuf,' ',PRTLEN);
            RJPrint(0,MESG_Z_LAST);
            DecordDateFiscal(sDateTo, SysBuf+PRTLEN-10);
            SysBuf[PRTLEN]=0;
            RJPrint(0,SysBuf);
#endif
        }

	}

#endif

#if (DD_MMC)

//	GetMMCSize();
	if (ApplVar.MMCSIZEMAX)
	{
//		FormPrtConfInf(0, ApplVar.MMCSIZEMAX, Msg[SIZEEJ].str);
		FormPrtConfInf(0, MMCSIZEUSE, Msg[SIZEEJ].str,1-CC_DEBUG);
		if (ApplVar.EJLogHeader.EndAddr>ApplVar.EJLogHeader.NextNP)
		{
			FormPrtConfInf(0, ApplVar.EJLogHeader.EndAddr-ApplVar.EJLogHeader.NextNP, REMAINEJ,1-CC_DEBUG);
		}

		if (ApplVar.EJLogHeader.RecordCount>0)
		{
#if (PRTLEN>30)
            memset(SysBuf,' ',PRTLEN);
            CopyFrStr(SysBuf, MESG_EJ_START);
			if (ReadFromMMC((char*)&sDateFr,INDEXADDR,2))
				DecordDateFiscal(sDateFr, SysBuf+PRTLEN-10);
            RJPrint(0,SysBuf);

            memset(SysBuf,' ',PRTLEN);
            CopyFrStr(SysBuf, MESG_EJ_LAST);
			if (ReadFromMMC((char*)&sDateFr,(ApplVar.EJLogHeader.RecordCount-1)*INDEXRECORDSIZE+INDEXADDR,2))
				DecordDateFiscal(sDateFr, SysBuf+PRTLEN-10);
			RJPrint(0,SysBuf);
#else
            RJPrint(0,MESG_EJ_START);
            memset(SysBuf,' ',PRTLEN);
			if (ReadFromMMC(&sDateFr,INDEXADDR,2))
				DecordDateFiscal(sDateFr, SysBuf+13);
			RJPrint(0,SysBuf);

            RJPrint(0,MESG_EJ_LAST);
			memset(SysBuf,' ',PRTLEN);
			if (ReadFromMMC(&sDateFr,(ApplVar.EJLogHeader.RecordCount-1)*INDEXRECORDSIZE+INDEXADDR,2))
				DecordDateFiscal(sDateFr, SysBuf+PRTLEN-10);
			RJPrint(0,SysBuf);
#endif

		}

	}
	else
		RJPrint(0,Msg[CWXXI97].str);

#endif

#if CC_DEBUG
	PrintLine2('=');
	sDateFr = ApplVar.ErrorNumber & 0x7f;
	memset(SysBuf,' ',PRTLEN);
	SysBuf[PRTLEN]=0;
#if (DD_FISPRINTER)
	CopyFrStr(SysBuf, MsgError[i].str);
#else
	if (sDateFr)
		CopyFrStr(SysBuf, Msg[CWXXI01+sDateFr-1].str);
	else
		CopyFrStr(SysBuf, MessageM0);
#endif
	SysBuf[16]='E';SysBuf[17]='R';SysBuf[18]='R';SysBuf[19]='=';
	WORDtoASC(SysBuf+22, sDateFr);

#if defined(FISCAL)
	SysBuf[24]='F';SysBuf[25]='I';	SysBuf[26]='S';SysBuf[27]='=';
	WORDtoASC(SysBuf+30, ApplVar.FisCardFlag);
#endif
	RJPrint(0,SysBuf);
	PrintLine2('=');
#endif

}
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//------------------------------------------------------------------------------------
void PrintConfInf()
{
	unsigned long Size,filesize;
    CONSTCHAR *sp;
	char Pro[5];
	BYTE i,files;
	WORD Number;
	short n,j;

	files = 0;
	filesize = 0;

//	StoreEJEnd();//ccr070609pm
	PrintLine2('=');
	PrintVersion();
	RJPrint(0,MessageE33);		//����ǰʱ�䡱
	Bios_1(BiosCmd_GetDate);
	Bios_1(BiosCmd_GetTime);
	MemSet(SysBuf,PRTLEN,' ');
	DateTimeToStr(SysBuf+2,3);
	SysBuf[PRTLEN] = 0;
	RJPrint(0,SysBuf);
	PrintLine2('=');
#if (DD_FISPRINTER==0)
	RJPrint(0, ConfTi[0]);
	PrintLine2('=');
	for(i=0;i<AddrMAX;i++)
	{
		 sp = NULL;
		 Number = 0;
		 Size = 0;
		 switch(i)
		 {
			 case AddrTotl:
			 	sp = (CONSTCHAR *)ConfTab[2];
			 	Number = NULL;
			 	Size = ApplVar.AP.StartAddress[AddrGroup];
			 	break;
			 case AddrGroup:
			 	sp = Def.Group.Name;
			 	Number = ApplVar.AP.Group.Number;
			 	Size = ApplVar.AP.StartAddress[AddrDept] - ApplVar.AP.StartAddress[AddrGroup];
			 	break;
			 case AddrDept:
			 	sp = Def.Dept.Name;
			 	Number = ApplVar.AP.Dept.Number;
			 	Size = ApplVar.AP.StartAddress[AddrPLU] - ApplVar.AP.StartAddress[AddrDept];
			 	break;
			 case AddrPLU:
			 	Number = ApplVar.AP.Plu.Number;
			 	sp = Def.Plu.Name;
			 	Size =(ApplVar.AP.StartAddress[AddrPort] - ApplVar.AP.StartAddress[AddrPLU]);
			 	if(ApplVar.AP.Plu.RandomSize)
			 	{
			 		CopyFrStr(ProgLineMes,Def.Plu.Name);
			 		n = 4;//strlen(Def.Plu.Name);
                    ApplVar.Entry = ZERO;//ccr20120101
			 		ULongToBCDValue(ApplVar.Entry.Value,ApplVar.AP.Plu.Number);
			 		MemSet(SysBuf, sizeof(SysBuf), ' ');
			 		ProgLineMes[n++] = '(';
			 		FormatQty(SysBuf+12,&ApplVar.Entry );
			 		for (j=0;j<13;j++)
			 		{
							if (SysBuf[j]!=' ')
								ProgLineMes[n++]=SysBuf[j];
			 		}
			 		ProgLineMes[n++] = ')';
			 		ProgLineMes[n] = 0;
			 		Number = ApplVar.AP.Plu.RNumber;
			 	    sp = ProgLineMes;
			 	}
			 	break;
			 case AddrTend:
				sp = (CONSTCHAR *)ConfTab[3];
				Number = ApplVar.AP.Tend.Number;
				Size = ApplVar.AP.StartAddress[AddrPoRa] - ApplVar.AP.StartAddress[AddrTend];
				break;
			 case AddrPoRa:
			 	sp = (CONSTCHAR *)ConfTab[4];
			 	Number = ApplVar.AP.PoRa.Number;
			 	Size = ApplVar.AP.StartAddress[AddrDrawer] - ApplVar.AP.StartAddress[AddrPoRa];
			 	break;
			 case AddrDrawer:
			 	sp = (CONSTCHAR *)ConfTab[5];
			 	Number = ApplVar.AP.Draw.Number;
			 	Size = ApplVar.AP.StartAddress[AddrCorr] - ApplVar.AP.StartAddress[AddrDrawer];
			 	break;
			 case AddrCorr:
			 	sp = (CONSTCHAR *)ConfTab[6];
			 	Number = ApplVar.AP.Correc.Number;
			 	Size = ApplVar.AP.StartAddress[AddrDisc] - ApplVar.AP.StartAddress[AddrCorr];
			 	break;
			 case AddrDisc:
			 	sp = Prompt.TypeCap[SETDISC-1];
			 	Number = ApplVar.AP.Disc.Number;
			 	Size = ApplVar.AP.StartAddress[AddrCurr] - ApplVar.AP.StartAddress[AddrDisc];
			 	break;
			 case AddrCurr:
			 	sp = (CONSTCHAR *)ConfTab[7];
			 	Number = ApplVar.AP.Curr.Number;
			 	Size = ApplVar.AP.StartAddress[AddrTax] - ApplVar.AP.StartAddress[AddrCurr];
			 	break;
			 case AddrTax:
			 	sp = (CONSTCHAR *)ConfTab[8];
			 	Number = ApplVar.AP.Tax.Number;
			 	Size = ApplVar.AP.StartAddress[AddrPBf] - ApplVar.AP.StartAddress[AddrTax];
			 	break;
			 case AddrPBf:
			 	sp = (CONSTCHAR *)ConfTab[9];
			 	Number = ApplVar.AP.Pb.Number;
			 	Size = ApplVar.AP.StartAddress[AddrModi] - ApplVar.AP.StartAddress[AddrPBf];
			 	break;
			 case AddrModi:
			 	sp = Def.Modi.Name;
			 	Number = ApplVar.AP.Modi.Number;
			 	Size = ApplVar.AP.StartAddress[AddrClerk] - ApplVar.AP.StartAddress[AddrModi];
			 	break;
			 case AddrClerk:
			 	sp = Def.Clerk.Name;
			 	Number = ApplVar.AP.Clerk.Number;
			 	Size = ApplVar.AP.StartAddress[AddrOFF] - ApplVar.AP.StartAddress[AddrClerk];
			 	break;
			 case AddrOFF:
			 	sp = Def.OFFPrice.Name;
			 	Number = ApplVar.AP.OFFPrice.Number;
			 	Size = ApplVar.AP.StartAddress[AddrICBlock] - ApplVar.AP.StartAddress[AddrOFF];  //Edit By Ranjer.Hu 2004-07-01
			 	break;
			 case AddrSalPer:
			 	sp = Def.SalPer.Name;
			 	Number = ApplVar.AP.SalPer.Number;
			 	Size = ApplVar.AP.StartAddress[AddrAgree] - ApplVar.AP.StartAddress[AddrSalPer];
			 	break;
			 case AddrAgree:
			 	sp = (CONSTCHAR *)ConfTab[11];
			 	Number = ApplVar.AP.Agree.Number;
			 	Size = ApplVar.AP.StartAddress[AddrPBt] - ApplVar.AP.StartAddress[AddrAgree];
			 	break;
			 case AddrRPLU:
			 	sp = (CONSTCHAR *)ConfTab[12];
   			 	Number = ApplVar.AP.Plu.RNumber;
			 	Size = ApplVar.AP.StartAddress[AddrSalPer] - ApplVar.AP.StartAddress[AddrRPLU];
			 	break;
			 case AddrPBt:
			 	sp = (CONSTCHAR *)ConfTab[13];
			 	Number = ApplVar.AP.Pb.NumberOfPb;
			 	Size = ApplVar.AP.StartAddress[AddrTrack] - ApplVar.AP.StartAddress[AddrPBt];
			 	break;
			 case AddrTrack:
			 	sp = (CONSTCHAR *)ConfTab[14];
			 	Number = ApplVar.AP.Pb.NumberOfBlocks;
			 	Size = ApplVar.AP.StartAddress[AddrEndP] - ApplVar.AP.StartAddress[AddrTrack];
			 	break;
			 case AddrICBlock://ccr chipcard
			 	sp = (CONSTCHAR *)ConfTab[18];
			 	Number = ApplVar.AP.ICBlock.Number;
			 	Size = ApplVar.AP.StartAddress[AddrSalPer] - ApplVar.AP.StartAddress[AddrICBlock];
			 	break;
			 case AddrMAX:
			 	sp = (CONSTCHAR *)ConfTab[15];
			 	Number = 0;
#if (CASE_RAMBILL)
			 	Size = FlowHeader.MAXNUMB;
#elif (DD_MMC)
			 	Size = ApplVar.EJLogHeader.EndAddr-EJLOGADDR;
#else
			 	Size = ApplVar.SIZE_EXTRAM - (ApplVar.AP.StartAddress[AddrEndP]+8);
#endif
			 	break;
		 }
		 if (Size)
 	 	 {
		 	files++;
			filesize+=Size;
		    FormPrtConfInf(Number, Size, sp,0);
	 	 }
	}
	PrintLine2('-');
	FormPrtConfInf(0, files, (CONSTCHAR *)ConfTab[0],0);
	FormPrtConfInf(0, filesize, (CONSTCHAR *)ConfTab[1],0);
	PrintLine2('.');
#endif


	RJPrint(0, ConfTi[1]);
	PrintLine2('-');
	for(Number=0;Number<portNumber;Number++)
	{
		MemSet(SysBuf, sizeof(SysBuf), ' ');
		memcpy(SysBuf, ApplVar.PortList[Number].Name, strlen(ApplVar.PortList[Number].Name));
		SysBuf[strlen(ApplVar.PortList[Number].Name)] = Number + 1 + '0';

#if (PRTLEN<25)
		memcpy(SysBuf + 7,PortType[ApplVar.PortList[Number].Type - '0' - 1],6);
#else
		memcpy(SysBuf + 13,PortType[ApplVar.PortList[Number].Type - '0' - 1],6);
#endif

		n = ApplVar.PortList[Number].Prot[ApplVar.PortList[Number].Type - 0x31];
		DeCodeProto(n, Pro);
#if (PRTLEN<25)
		memcpy(SysBuf + PRTLEN - 5,Pro,5);
#else
		memcpy(SysBuf + PRTLEN - 8,Pro,5);
#endif
		SysBuf[PRTLEN] = 0;
		RJPrint(0, SysBuf);
	}
	PrintMemoForFiscal();
}

//------------------------------------------------------------------------------------
