//---------------------------------------------------------------------------

#include "king.h"
#include "exthead.h"
#include "exth.h"
#include "message.h"

extern CONST WORD code_buf[6768];

#if (defined(DEBUGBYPC))
extern BYTE LoopInput;
#endif

/****************************************************************
  ���������뷨���������޸�
  --------------------------
  1��2��3��4��5��
  6��7��8��9��0��
  ƴ:ji
  ***************************************************************/
////////////////////
#define ASC_MODE    0   //��ǰΪASCII����
#define QUWEI_MODE  1   //��ǰΪ��λ����
#define PYBH_MODE   2   //��ǰΪƴ����ڻ�����
/////////////////////////

//---------------------------------------------------------------------------
#if defined(CASE_FORHANZI)

#define  PYorBH   1		// =1ʹ��ƴ�����뷨��=0 ʹ�ñʻ����뷨

char HZFound[DISPMAX*2];//����ҵ������뺺��

CONST MODEREC INPUTMODE[3]={
    {InputMode1,1},//A
    {InputMode2,4},//qu
#if (PYorBH)
    {InputMode3,6},//ping
#else
    {InputMode4,6},//5bihua
#endif
};


#define cPYCODE     26
#if (PYorBH)
CONST MODEREC PYCODE[cPYCODE]={
    {"iu",  'q' & 0x1f},
    {"ua",  'w' & 0x1f},
    {"ia",  'w' & 0x1f},
    {"uan", 'r' & 0x1f},
    {"ue",  't' & 0x1f},
    {"uai", 'y' & 0x1f},
    {"ing", 'y' & 0x1f},
    {"uo",  'o' & 0x1f},
    {"un",  'p' & 0x1f},
    {"iong",'s' & 0x1f},
    {"ong", 's' & 0x1f},
    {"uang",'d' & 0x1f},
    {"iang",'d' & 0x1f},
    {"en",  'f' & 0x1f},
    {"eng", 'g' & 0x1f},
    {"ang", 'h' & 0x1f},
    {"an",  'j' & 0x1f},
    {"ao",  'k' & 0x1f},
    {"ai",  'l' & 0x1f},
    {"ei",  'z' & 0x1f},
    {"ie",  'x' & 0x1f},
    {"iao", 'c' & 0x1f},
    {"ui",  'v' & 0x1f},
    {"ou",  'b' & 0x1f},
    {"in",  'n' & 0x1f},
    {"ian", 'm' & 0x1f},
};
#else
WORD   SkipBihua;   // �ʻ����뷨������ֵ  //
#endif

BYTE    InputNum;   // code number of input

char    SelMax;
char    SelIdx;
short     HZPage,ScanIdx;

char    QPCode[7];
char    SPCode[2];
short   ScanDir;

char    SaveScreen[SCREENLN-1][SCREENWD];//������Ļ����

#else
CONST MODEREC INPUTMODE[1]={
    {"a:",1},//A
};

#endif


WORD    HANZI;      //0-Empty input; <0xa0,ASCII input; >0xa0a0, HANZI input
BYTE    CHNMode;    //0-ACSII mode,1-Quwei Mode 2-Pyin mode

char    SaveState[SCREENWD];//

//==============================================================================
//get the input key from input area
char GetInputKey(short idx)
{
    return(ApplVar.ScreenMap[SCREENLN][idx+INPUTPOS]);
}


WORD GetNumric(BYTE keyno)
{
    //ccr20131223>>>>>

    BYTE i;

    if (keyno>=64)
        return(0x0100+keyno);

#if defined(CASE_FORHANZI)
    if (CHNMode==QUWEI_MODE)
    {
        i = NUMASCII[keyno];
        if (i>='0' && i<='9')
            return i;
    }
#endif

    if (TESTBIT(ApplVar.MyFlags, UPASCII + SPASCII)==SPASCII)
        i = NUMASCII[keyno];
    else
    {
        i = ASCIIKEY[keyno];
        if (TESTBIT(ApplVar.MyFlags, UPASCII) && i>='a' && i<='z')
            i &=(~0x20);
    }

    if (i==0)
        return(0x0100+keyno);
    else
        return i;
    //<<<<<<<<<<<<<<<<<<<<<<<<<<<<
}

#if defined(CASE_FORHANZI)
//�ָ����������븲�ǵ���Ļ��������
void RecallScreen()
{
    int i;
    if (TESTBIT(ApplVar.ScreenStat,SCREENCOPY))
    {//�ָ���Ļ����
        memcpy(ApplVar.ScreenMap,SaveScreen,(SCREENLN-1)*SCREENWD);
        RESETBIT(ApplVar.ScreenStat,SCREENCOPY);
        for (i=0;i<SCREENLN-1;i++)
        {
            mRefreshLine(i);
        }
    }
}
//Ϊ��ʾ���뺺�ֱ�����Ļ����
void BackupScreen()
{
    int i;
    if (!TESTBIT(ApplVar.ScreenStat,SCREENCOPY))
    {//������Ļ����
        memcpy(SaveScreen,ApplVar.ScreenMap,(SCREENLN-1)*SCREENWD);
        memset(ApplVar.ScreenMap,' ',(SCREENLN-1)*SCREENWD);
        for (i=0;i<SCREENLN-1;i++)
        {
            mRefreshLine(i);
        }
        SETBIT(ApplVar.ScreenStat,SCREENCOPY);
    }
}
//..............................................................................
WORD QWInput(BYTE keyno)
{
    char sCh;
    WORD sQWCode;
    short i;
    char x=DISPPOSX,y=DISPPOSY;//���뺺����ʾλ��

    sCh = GetNumric(keyno);
    if (sCh>='0' && sCh<='9')
    {
        if (TESTBIT(ApplVar.ScreenStat,HZSELECT))
            ChnInput(2);
        else if (InputNum>=INPUTMODE[CHNMode].MaxInput)
            return 0;

        DispCharXY(sCh,INPUTPOS+InputNum,SCREENLN);
        QPCode[InputNum] = sCh;
        InputNum++;

        QPCode[InputNum] = 0;
        HZPage = 0;
        //keyno = cNEXT;
        keyno = cDOWN;
    }
    switch (keyno)
    {
    case cUP:
        if (InputNum<=1)
            return 0;
        HZPage-=2;
        if (HZPage<0)
        {
            HZPage = 1;
            return 0;
        }
    case cDOWN:
        if (InputNum==0)
            return 0;
        RESETBIT(ApplVar.ScreenStat,HZSELECT);
        sQWCode = 0;
        for (i=0;i<InputNum;i++)
            sQWCode = sQWCode*10 + (QPCode[i] & 0x0f);
        switch (InputNum)
        {
        case 2:
        case 3:
            if (InputNum==3)
            {
                sCh = (sQWCode % 10) * 10 + 0xa1;
                sQWCode = (sQWCode/10 + 0xa0);
            }
            else
            {
                sCh = 0xa1;
                sQWCode = sQWCode+0xa0;
            }
            if (HZPage<2 && InputNum==3 || HZPage<10 && InputNum==2)
            {//���뺺����ʾ����,������ʾ5��

                //������Ļ����
                BackupScreen();
                DispStrXY(Msg[SELECT1HZ].str,0,0);
                memset(HZFound,' ',sizeof(HZFound));
                for (i=0;i<DISPMAX;i++)
                {//��ʾ���뺺��
                    if (i==DISPMAX/2)
                    {//��ʾ�ڶ���
                        x=DISPPOSX;y=DISPPOSY+1;
                    }
                    sQWCode = (sQWCode & 0xff) + ((HZPage * DISPMAX + i + sCh & 0xff)<<8);
                    if ((sQWCode & 0xff00)>0xfe00)
                    {//���ǺϷ��ĺ���
                        break;
                    }
                    else
                    {//��ʾ����
                        DispCharXY(' ',x,y);x++;
                        DispCharXY(sQWCode,x,y);x+=2;
                        CWORD(HZFound[i*2])=sQWCode;
                    }
                }
                HZPage++;
                break;
            }
            return 0;
        case 4:
            RecallScreen();
            SETBIT(ApplVar.ScreenStat,HZSELECT);
            return((sQWCode /100 + 0xa0)+((sQWCode % 100 + 0xa0)<<8));
        default:
            i = 0;
            break;
        }
        SelMax = i;
        for (;i<DISPMAX;i++)
        {
            if (i==DISPMAX/2)
            {//��ʾ�ڶ���
                x=DISPPOSX;y=DISPPOSY+1;
            }
            DispCharXY(' ',x,y);x++;
            DispCharXY(' ',x,y);x++;
            DispCharXY(' ',x,y);x++;
        }
        DispCharXY('>',DISPPOSX,DISPPOSY);
        SelIdx = 0;
        break;
    }
    return 0;
}
//..............................................................................
#if (PYorBH) //  ƴ�����봦��  ����
//Change QPyin code into SPCode
void QP2SP()
{
    WORD sP;
    short i;

    SPCode[1] = 0;
    if (InputNum==1)
    {
        SPCode[0] = QPCode[0]  & 0x1f;
        return;
    }
    else
    {
        sP = *((WORD *)QPCode);
        if (sP == 0x687a)       //'zh'
        {
            SPCode[0] = 'v';
            sP = 2;
        }
        else if (sP == 0x6863 ) //'ch'
        {
            SPCode[0] = 'i';
            sP = 2;
        }
        else if (sP == 0x6873)  //'sh'
        {
            SPCode[0] = 'u';
            sP = 2;
        }
        else
        {
            SPCode[0] = QPCode[0];
            sP = 1;
        }
        SPCode[0] &= 0x1f;
        if (sP==InputNum)
            return;

        if (InputNum==2)
            for (i=0;i<cPYCODE;i++)
                if (!strcmp(QPCode,PYCODE[i].Name))
                {
                    SPCode[0] = PYCODE[i].MaxInput;
                    return;
                }

        if (sP+1==InputNum)
        {
            SPCode[1] = QPCode[InputNum-1] & 0x1f;
            return;
        }
        for (i=0;i<cPYCODE;i++)
            if (!strcmp(QPCode+sP,PYCODE[i].Name))
            {
                SPCode[1] = PYCODE[i].MaxInput;
                return;
            }
        SPCode[1] = 0xff;
        return;
    }
}

WORD PYInput(BYTE keyno)
{
    WORD sCh;
    WORD sQWCode;
    char* code;
    short i;
    char x=DISPPOSX,y=DISPPOSY;//���뺺����ʾλ��

    sCh = GetNumric(keyno);
    if (sCh<0x0100)
    {
        if (sCh<='9')
        {
            if (sCh>='0' && sCh<=DISPMAX+'0')
            {
                sCh = sCh - '0';
                if (sCh<SelMax)
                {
                    SETBIT(ApplVar.ScreenStat,HZSELECT);

                    if (sCh>=DISPMAX/2)
                    {//��ѡ��2�е����뺺��
                        x = (sCh-DISPMAX/2)*3+DISPPOSX+1;
                        y=DISPPOSY+1;
                    }
                    else
                    {//��ѡ��1�е����뺺��
                        x = sCh*3+DISPPOSX+1;
                        y=DISPPOSY;
                    }
                    sCh=CWORD(HZFound[sCh*2]); //GetChFr(x,y);
                    RecallScreen();
                    return sCh;
                }
                else
                    return 0;
            }
            else
                return 0;
        }
        else
            if (sCh=='@' || sCh=='~')
            return sCh;

        if (TESTBIT(ApplVar.ScreenStat,HZSELECT))
            ChnInput(2);
        else if (InputNum>=INPUTMODE[CHNMode].MaxInput)
            return 0;

        sCh |= 0x20;
        DispCharXY(sCh,INPUTPOS+InputNum,SCREENLN);
        QPCode[InputNum] = sCh;
        InputNum++;
        QPCode[InputNum] = 0;
        QP2SP();
        ScanDir = 1;
        HZPage = ScanIdx = 0;
        //keyno = cNEXT;
        keyno = cDOWN;
    }
    switch (keyno)
    {
    case cUP:
        if (ScanDir==1)
            HZPage = ScanIdx;
        if (HZPage<0)
            return 0;
        ScanDir = -1;
    case cDOWN:
        if (InputNum==0  ||  HZPage>=6768)
            return 0;
        //if (keyno==cNEXT)
        if (keyno == cDOWN)
        {
            if (ScanDir==-1)
                HZPage = ScanIdx;
            ScanDir = 1;
        }
        if (HZPage<0)
            HZPage = 0;
        RESETBIT(ApplVar.ScreenStat,HZSELECT);

        //������Ļ����
        BackupScreen();
        DispStrXY(Msg[SELECT1HZ].str,0,0);
        memset(HZFound,' ',sizeof(HZFound));
        for (i=0;i<DISPMAX;i++)
        {
            if (i==DISPMAX/2)
            {
                x=DISPPOSX;y=DISPPOSY+1;
            }
            for (;(HZPage>=0 && HZPage<6768);)
            {
                code = (char*)code_buf + HZPage*2;
                if ((code[0]&0x1f) == SPCode[0] &&
                    ((code[1]&0x1f) == SPCode[1] || !SPCode[1]))
                {
                    sQWCode = (HZPage/94+176) + ((HZPage % 94+161)<<8);
                    DispCharXY(i+'0',x++,y);
                    DispCharXY(sQWCode,x,y);x+=2;
                    CWORD(HZFound[i*2])=sQWCode;

                    if (!i)
                        ScanIdx = HZPage -  ScanDir;
                    break;
                }
                HZPage +=ScanDir;
            }
            if (HZPage<0 || HZPage>=6768)
                break;
            HZPage += ScanDir;
        }    //cctest050819

        if (i)
        {
            SelMax = i;
            for (;i<DISPMAX;i++)
            {//������뺺�����޺�����ʾ����
                if (i==DISPMAX/2)
                {
                    x=DISPPOSX;y=DISPPOSY+1;
                }
                DispCharXY(' ',x++,y);
                DispCharXY(' ',x++,y);
                DispCharXY(' ',x++,y);
            }
            SelIdx = 0;
        }
        break;
    }
    return 0;
}

#else//  �ʻ����봦��  ����//

void QP2SP()
{
    WORD sP;
    short i;

    SkipBihua = sP = 0;
    for (i=InputNum-1;i>=0;i--)
    {
        sP <<= 3;
        SkipBihua <<= 3;
        sP |= (QPCode[i] & 0x07);
        SkipBihua |= 7;
    }

    CWORD(SPCode) = sP;
}

WORD PYInput(BYTE keyno)
{
    WORD sCh;
    WORD sQWCode;
    char* code;
    short i;
    char x=DISPPOSX,y=DISPPOSY;

    sCh = GetNumric(keyno);
    if (sCh<0x0100)
    {
        if (sCh<=DISPMAX+'0' && InputNum>=DISPMAX &&  !TESTBIT(ApplVar.ScreenStat,HZSELECT))
        {
            if (sCh>='0' && sCh<=DISPMAX+'0')
            {
                sCh = sCh - '0';
                if (sCh<SelMax)
                {
                    if (sCh>=DISPMAX/2)
                    {//��ѡ��2�е����뺺��
                        x = (sCh-DISPMAX/2)*3+DISPPOSX+1
                        y=DISPPOSY+1;
                    }
                    else
                    {//��ѡ��1�е����뺺��
                        x = sCh*3+DISPPOSX+1
                        y=DISPPOSY;
                    }

                    SETBIT(ApplVar.ScreenStat,HZSELECT);
                    sCh=CWORD(HZFound[sCh*2]); //GetChFr(x,y);
                    RecallScreen();
                    return sCh;
                }
                else
                    return 0;
            }
            else
                return 0;
        }
        else
        {
            if (sCh=='@' || sCh=='~' || (sCh>='A' && sCh<='Z') || (sCh>='a' && sCh<='z'))
            {
                RecallScreen();
                return sCh;
            }
        }

        if (TESTBIT(ApplVar.ScreenStat,HZSELECT))
            ChnInput(2);
        else if (InputNum>=INPUTMODE[CHNMode].MaxInput)
            return 0;

        sCh |= 0x20;
        DispCharXY(sCh,INPUTPOS+InputNum,SCREENLN);
        QPCode[InputNum] = sCh;
        InputNum++;
        QPCode[InputNum] = 0;
        QP2SP();
        ScanDir = 1;
        HZPage = ScanIdx = 0;
        //keyno = cNEXT;
        keyno = cDOWN;
    }
    switch (keyno)
    {
    case cUP:
        if (ScanDir==1)
            HZPage = ScanIdx;
        if (HZPage<0)
            return 0;
        ScanDir = -1;
    case cDOWN:
        if (InputNum==0  ||  HZPage>=6768)
            return 0;
        //if (keyno==cNEXT)
        if (keyno==cDOWN)
        {
            if (ScanDir==-1)
                HZPage = ScanIdx;
            ScanDir = 1;
        }
        if (HZPage<0)
            HZPage = 0;
        RESETBIT(ApplVar.ScreenStat,HZSELECT);
        BackupScreen();
        DispStrXY(Msg[SELECT1HZ].str,0,0);
        memset(HZFound,' ',sizeof(HZFound));
        for (i=0;i<DISPMAX;i++)
        {
            if (i==DISPMAX/2)
            {
                x=DISPPOSX;y=DISPPOSY+1;
            }
            for (;(HZPage>=0 && HZPage<6768);)
            {
                code = (char*)code_buf + HZPage*2;
                sQWCode = ((WORD)code[1] * 256 + code[0]) & SkipBihua;
                if (sQWCode == CWORD(SPCode))
                {
                    sQWCode = (HZPage/94+176) + ((HZPage % 94+161)<<8);
                    DispCharXY(i+'0',x++,y);
                    DispCharXY(sQWCode,x,y);x+=2;
                    CWORD(HZFund[i*2])=sQWCode;

                    if (!i)
                        ScanIdx = HZPage -  ScanDir;
                    break;
                }
                HZPage +=ScanDir;
            }
            if (HZPage<0 || HZPage>=6768)
                break;
            HZPage += ScanDir;
        }

        if (i)
        {
            SelMax = i;
            for (;i<DISPMAX;i++)
            {
                if (i==DISPMAX/2)
                {
                    x=DISPPOSX;y=DISPPOSY+1;
                }
                DispCharXY(' ',x++,y);
                DispCharXY(' ',x++,y);
                DispCharXY(' ',x++,y);
            }
            SelIdx = 0;
        }
        break;
    }
    return 0;
}
#endif

#endif
/*process user input*****************************************
return:
    0��û������  //
    0x01??�����ֽ�Ϊ����λ���� //
    0x00??�����ֽ�ΪASCII�ַ� //
    >0xa0a0��Ϊ���� //
    '00'��Ϊ˫00 //
*************************************************************/
WORD CheckInput()
{
    WORD W;
    BYTE keyno;
//    char x=DISPPOSX,y=DISPPOSY;

    if (!KbHit())
        return 0;
    ApplVar.KeyNo = keyno = Getch();        /* read key */
    if (TESTBIT(ApplVar.ScreenStat,HZINPUTMODE))
    {
        switch (GetFirmkeyID(keyno))
        {

#if defined(CASE_FORHANZI)
        case ID_CLEAR:
            if (InputNum>0)
            {
                ChnInput(2);
                return 0;
            }
            else
                return(0x0100+keyno);
        case ID_SELECT:

            if (CHNMode==ASC_MODE)
                return(0x0100+keyno);
            if (TESTBIT(ApplVar.ScreenStat,HZSELECT))
            {//�Ѿ���ѡ��һ������,�ٰ�ѡ���,������ѡ
                BackupScreen();
                DispStrXY(Msg[SELECT1HZ].str,0,0);
                for (keyno=0;keyno<DISPMAX;keyno++)
                {
                    if (HZFound[keyno*2]!=' ')
                    {
                        if (keyno<DISPMAX/2)
                        {
                            DispCharXY(keyno+'0',keyno * 3 + DISPPOSX,DISPPOSY);
                            DispCharXY(CWORD(HZFound[keyno*2]),keyno * 3 + DISPPOSX+1,DISPPOSY);
                        }
                        else
                        {
                            DispCharXY(keyno+'0',(keyno-DISPMAX/2) * 3 + DISPPOSX,DISPPOSY+1);
                            DispCharXY(CWORD(HZFound[keyno*2]),(keyno-DISPMAX/2) * 3 + DISPPOSX+1,DISPPOSY+1);
                        }
                    }
                }
                RESETBIT(ApplVar.ScreenStat,HZSELECT);
            }
            else
            {//ѡ���µĺ���
                if (SelIdx<SelMax)
                {
                    if (CHNMode<=QUWEI_MODE)
                        keyno = ' ';
                    else
                        keyno = SelIdx+'0';
                    if (SelIdx<DISPMAX/2)
                        DispCharXY(keyno,SelIdx * 3 + DISPPOSX,DISPPOSY);
                    else
                        DispCharXY(keyno,(SelIdx-DISPMAX/2) * 3 + DISPPOSX,DISPPOSY+1);
                }
                SelIdx++;
            }
            if (SelIdx>=SelMax)
                SelIdx = 0;

            if (SelIdx<DISPMAX/2)
                DispCharXY('>',SelIdx * 3 + DISPPOSX,DISPPOSY);
            else
                DispCharXY('>',(SelIdx-DISPMAX/2) * 3 + DISPPOSX,DISPPOSY+1);

            return 0;
        case ID_DELETE:
            if (InputNum>0)
            {
                InputNum--;
                QPCode[InputNum] = 0;
                DispCharXY(' ',InputNum + INPUTPOS,SCREENLN);
                ScanDir = 1;
                HZPage = ScanIdx = 0;
                if (InputNum>0)
                    switch (CHNMode)
                    {
                    case QUWEI_MODE:
                        //QWInput(cNEXT);
                        QWInput(cDOWN);
                        break;
                    case PYBH_MODE:
                        QP2SP();
                        //PYInput(cNEXT);
                        PYInput(cDOWN);
                        break;
                    }
                return 0;
            }
            else
            {
                RecallScreen();
                return(0x0100+keyno);
            }

        case ID_ENTER:
            if (SelIdx<SelMax && !TESTBIT(ApplVar.ScreenStat,HZSELECT))
            {//û����ѡ����ʱ,��ѡһ��������Ϊ����
                SETBIT(ApplVar.ScreenStat,HZSELECT);
/*
                if (SelIdx>=DISPMAX/2)
                {//��ѡ��2�е����뺺��
                    x = (SelIdx-DISPMAX/2)*3+DISPPOSX+1;
                    y=DISPPOSY+1;
                }
                else
                {//��ѡ��1�е����뺺��
                    x = SelIdx*3+DISPPOSX+1;
                    y=DISPPOSY;
                }
 */
                W=CWORD(HZFound[SelIdx*2]); //GetChFr(x,y);
                RecallScreen();
                return W;
            }
            else if (CHNMode==ASC_MODE || TESTBIT(ApplVar.ScreenStat,HZSELECT) || SelMax==0)
            {//�Ѿ�ѡȡ��һ������,�����µ�����ʱ
                ChnInput(3);//�Զ��˳�����ģʽ
                return(0x0100+keyno);//��ȷ�ϰ����ύ���������ܴ���
            }
            else
                return 0;

        case ID_xINPUT://�л����뷨
            RecallScreen();
            CHNMode++;
            if (CHNMode>PYBH_MODE)
                CHNMode = ASC_MODE;
            InputNum = SelIdx = SelMax = 0;
            RESETBIT(ApplVar.ScreenStat,HZSELECT);
            if (CHNMode==PYBH_MODE)//Ϊƴ�����뷨
                RESETBIT(ApplVar.MyFlags, SPASCII);

            ClearLine(SCREENLN);
            DispStrXY((BYTE*)INPUTMODE[CHNMode].Name,0,SCREENLN);
            //ccr20131223>>>>>
            if (CHNMode==ASC_MODE)
            {
                switch (TESTBIT(ApplVar.MyFlags, UPASCII + SPASCII))
                {
                case SPASCII:  DispCharXY('*',0,SCREENLN);break;
                case UPASCII:  DispCharXY('A',0,SCREENLN);break;
                default:  break;
                }
            }//<<<<<<<<<<<<<<<<<
            return 0;
#else
        case ID_CLEAR:
        case ID_SELECT:
        case ID_DELETE:
        case ID_ENTER:
            return(0x0100+keyno);
        case ID_xINPUT:
            CHNMode = ASC_MODE;
            RESETBIT(ApplVar.ScreenStat,HZSELECT);
/*ccr20131223 ���Ӣ�İ汾���л���Сд���������
            ClearLine(SCREENLN);
            DispStrXY((BYTE*)INPUTMODE[CHNMode].Name,0xff,SCREENLN);
            return 0;
*/
#endif
        case ID_xASCII://�л�ASCII��Сд(=ID_xDEPT)
            if (CHNMode==ASC_MODE)
            {
                if (TESTBIT(ApplVar.MyFlags, UPASCII))
                {
                    RESETBIT(ApplVar.MyFlags, UPASCII);
                    SETBIT(ApplVar.MyFlags, SPASCII);
                    DispCharXY('*',0,SCREENLN);
                }
                else if (TESTBIT(ApplVar.MyFlags, SPASCII))
                {
                    RESETBIT(ApplVar.MyFlags, SPASCII);
                    DispStrXY((BYTE*)INPUTMODE[0].Name,0,SCREENLN);
                }
                else
                {
                    SETBIT(ApplVar.MyFlags, UPASCII);
                    DispCharXY('A',0,SCREENLN);
                }
                return 0;
            }
            else
            {
#if defined(CASE_FORHANZI)
                RecallScreen();
#endif
                return(0x0100+keyno);
            }

        case ID_CANCEL:
#if defined(CASE_FORHANZI)
            InputNum = SelIdx = SelMax = 0;
            RecallScreen();
#endif
            RESETBIT(ApplVar.ScreenStat,HZINPUTMODE);
            memcpy(ApplVar.ScreenMap[SCREENLN],SaveState,SCREENWD);
            mRefreshLine(SCREENLN);
            return 0;
        }

#if defined(CASE_FORHANZI)
        switch (CHNMode)
        {
        case ASC_MODE:
            return GetNumric(keyno);
        case QUWEI_MODE:
            return  QWInput(keyno);
        case PYBH_MODE:
            return  PYInput(keyno);
        }
#else
        if (CHNMode==ASC_MODE)
            return GetNumric(keyno);
#endif
    }

    if (keyno<64)
    {
        W = ApplVar.AP.KeyTable[keyno];
        if (W>='0' && W<='9' || W=='.')
            return W;
        else if (W == ZERO2 && !TESTBIT(ApplVar.MyFlags,HANZIMODE))
            return 0x3030;
    }
    return (0x0100 | keyno);
}
/************************************************************************************
    func=0,��������Ƿ������룻����Ϊ0ʱ����ʾû������ //
    func��1��CHNInput��ȡ������������,����ֵ>256ʱ����ʾ������һ�����֣� //
    func��2���տ�����뺺������״̬����ʱ������λ�ô�����Ļ�����һ�У� //
            ����Ļ�Ϲ�һ�У����λ��ͬʱҲ����һ�У���״̬�У���ʾ��������״̬��Ϣ�� //
    func=3���տ���˳���������״̬���ر�״̬�С� //
**********************************************************************************/
WORD ChnInput(BYTE func)
{
    switch (func)
    {
    case 0://��������Ƿ������룻����Ϊ0ʱ����ʾû������
        HANZI = CheckInput();
    case 1://��ȡ�����������ݷ���ֵ>256ʱ����ʾ������һ������
        return  HANZI;
    case 2://�տ�����뺺������״̬
        if (!TESTBIT(ApplVar.ScreenStat,HZINPUTMODE))
        {
            memcpy(SaveState,ApplVar.ScreenMap[SCREENLN],SCREENWD);
            OpenMess(1);
        }
#if defined(CASE_FORHANZI)
        InputNum = SelIdx = SelMax = 0;
#endif
        RESETBIT(ApplVar.ScreenStat,HZSELECT);
        ClearLine(SCREENLN);
        DispStrXY((BYTE*)INPUTMODE[CHNMode].Name,0xff,SCREENLN);
        //ccr20131223>>>>>
        if (CHNMode==ASC_MODE)
        {
            switch (TESTBIT(ApplVar.MyFlags, UPASCII + SPASCII))
            {
            case SPASCII:  DispCharXY('*',0,SCREENLN);break;
            case UPASCII:  DispCharXY('A',0,SCREENLN);break;
            default:  break;
            }
        }//<<<<<<<<<<<<<<<<<

        SETBIT(ApplVar.ScreenStat,HZINPUTMODE);

        return 0;
    case 3://�տ���˳���������״̬���ر�״̬��
        if (TESTBIT(ApplVar.ScreenStat,HZINPUTMODE))
        {
#if defined(CASE_FORHANZI)
            RecallScreen();
#endif
            RESETBIT(ApplVar.ScreenStat,HZINPUTMODE);
            memcpy(ApplVar.ScreenMap[SCREENLN],SaveState,SCREENWD);
            mRefreshLine(SCREENLN);
        }
//            OpenMess(0);
        return 0;
    default:
        return 0;
    }
}

/*�б༭���������Ա�����EntryBuffer�е�������Ϣ���б༭ //
�˱༭��ֻ���ں���ģʽ�£�MyFlags,HANZIMODE��
Input:
    ch:�ַ������֡������� //
    ch.high = 0, ch��ΪASCII�ַ� //
    ch.high>0xa0��ch��Ϊ���� //
    ch.high=1,ch.lowΪ���� //
Return:
    =0xff,û�ж���Ϣ���б༭ //
    ����ֵ��Ϊ�༭����Ϣ���� //
*/
BYTE LineEditor(union KEY ch)
{
    short sCurX,oldX,newX;

    oldX = Editor.BuffSize - (Editor.DispW-(Editor.CursorX-Editor.DispX)+Editor.EditOffs);

//cc 2006-08-14 for Caption>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (!Editor.EditOffs)
    {
        newX = Editor.BuffSize-Editor.DispW-Editor.EditOffs;
        DispStrXY(Editor.EditBuff+newX, Editor.DispX+TestHZRight(Editor.EditBuff, newX),Editor.DispY);
    }
//cc 2006-08-14 for Caption>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (ch.C.High==1)
    {//input is a function key

        sCurX = Editor.CursorX;
        switch (GetFirmkeyID(ch.C.Low))
        {
        case ID_ENTER:// Ϊ����ȷ�ϼ�  //
            if (TESTBIT(ApplVar.MyFlags,HANZIMODE))
            {
                if (TESTBIT (ApplVar.ScreenStat,HZINPUTMODE))
                    ChnInput(3);
                break;
            }
            else
                return 0xff;
        case ID_CLEAR:        // 12
            if (ApplVar.ErrorNumber)
            {//ccr060118 ���������ʾ //
                ApplVar.ErrorNumber=0;
				mRefreshLine(SCREENLN);//20130930  �ָ���ʾ��ǰ����ʾ     ClsState2();
                if (TESTBIT(ApplVar.MyFlags,HANZIMODE))
                    ChnInput(2);
                break;
            }
#if defined(CASE_FORHANZI)
            else if (InputNum == 0 && Editor.EditCount>0)
#else
            else if (Editor.EditCount>0)
#endif
            {
                Editor.CursorX = SCREENWD;//                GotoXY(SCREENWD,Editor.DispY);
                memset(Editor.EditBuff,' ',Editor.BuffSize);
                if (!TESTBIT(ApplVar.MyFlags,HANZIMODE))
                    Editor.EditBuff[Editor.BuffSize-1] = '0';
                Editor.EditBuff[Editor.BuffSize] = 0;
                ApplVar.DecimalPoint = 0;//ccr090617
                Editor.EditCount = 0;
                DispStrXY(Editor.EditBuff,Editor.DispX,Editor.DispY);
                break;
            }
            else
                return 0xff;
#if (CASE_ER220 || CASE_ER520U)
        case ID_UP:     // 255
#else
        case ID_LEFT://cUP:		// 255
#endif
            if (ApplVar.CentralLock==RG || ApplVar.CentralLock==MG)
                return 0xff;
            if (Editor.DispW-(Editor.CursorX-Editor.DispX)+Editor.EditOffs>=Editor.EditCount)
                break;
            newX = oldX - 1;
            newX -= TestHZRight(Editor.EditBuff,newX);
            sCurX -= (oldX-newX);

            if (sCurX>=Editor.DispX)
            {
                Editor.CursorX = sCurX;//  GotoXY(sCurX,ApplVar.sCursor.y);
            }
            else //(sCurX<DispX)
            {
                Editor.EditOffs += (Editor.DispX - sCurX);
                sCurX = Editor.DispX;
                Editor.CursorX = sCurX;//  GotoXY(sCurX,ApplVar.sCursor.y);
                DispStrXY(Editor.EditBuff+newX,Editor.DispX,Editor.DispY);
            }
            break;
#if (CASE_ER220 || CASE_ER520U)
        case ID_DOWN:     // 255
#else
        case ID_RIGHT://cDOWN:		// 255
#endif
            if (ApplVar.CentralLock==RG || ApplVar.CentralLock==MG)
                return 0xff;
            if (oldX>=Editor.BuffSize)
                break;
            newX = oldX + 1;
            newX += TestHZRight(Editor.EditBuff,newX);
            sCurX += (newX-oldX);

            if (sCurX<=Editor.DispX+Editor.DispW)
            {
                Editor.CursorX = sCurX;//  GotoXY(sCurX,ApplVar.sCursor.y);
            }
            else //(sCurX>DispX+DispW)
                if (Editor.EditOffs>0)
            {
                sCurX = Editor.DispX+Editor.DispW-1;
                Editor.EditOffs--;
                if (Editor.EditBuff[newX]>0xa0)
                {
                    Editor.EditOffs--;
                    sCurX--;
                }
                Editor.CursorX = sCurX;//  GotoXY(sCurX,ApplVar.sCursor.y);

                newX = Editor.BuffSize-Editor.DispW-Editor.EditOffs;
                sCurX = TestHZRight(Editor.EditBuff,newX);
                if (sCurX)
                    DispCharXY(' ',Editor.DispX,Editor.DispY);
                DispStrXY(Editor.EditBuff+newX+sCurX,Editor.DispX+sCurX,Editor.DispY);
            }
            break;
        case ID_DELETE:
            if (Editor.EditCount>0 &&
                (Editor.DispW-(Editor.CursorX-Editor.DispX)+Editor.EditOffs<=Editor.EditCount))
            {
                oldX--;
                Editor.EditCount--;
                newX = oldX;
#if defined(CASE_FORHANZI)
                if (Editor.EditBuff[oldX]>0xa0)
                {
                    oldX--;
                    Editor.EditCount--;
                }
#endif
                oldX--;
                for (;oldX>=0;)
                    Editor.EditBuff[newX--]=Editor.EditBuff[oldX--];
                Editor.EditBuff[newX] = ' ';


                newX = Editor.BuffSize-Editor.DispW-Editor.EditOffs;
                sCurX = TestHZRight(Editor.EditBuff,newX);
#if defined(CASE_FORHANZI)
                if (sCurX)
                    DispCharXY(' ',Editor.DispX,Editor.DispY);
#endif
                DispStrXY(Editor.EditBuff+newX+sCurX,Editor.DispX+sCurX,Editor.DispY);
            }
            break;
        default:
            return 0xff;
        }
    }
    else
    {//input is a character (HANZI or ASCII)
        if (Editor.EditCount>=Appl_MaxEntry)
        {
            if (Appl_MaxEntry && ApplVar.DispKey.Code == ApplVar.AP.FirmKeys[ID_ENTER])
            {
                //ClearEntry(false);
                oldX = Editor.BuffSize;
                ApplVar.DispKey.Code = 0;
            }
            else
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI18);
                return 0xff;
            }
        }
        if (!Editor.EditCount)
            memset(Editor.EditBuff,' ',Editor.BuffSize);
        if (!TESTBIT(ApplVar.MyFlags,HANZIMODE))
        {
            if (ch.C.Low == '.')
            {
                if (!ApplVar.DecimalPoint)
                {
                    ApplVar.DecimalPoint = 1;
                    if (Editor.EditCount==0)
                    {
                        Editor.EditBuff[Editor.BuffSize-1] = '0';
                        Editor.EditCount = 1;
                    }
                }
                else
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI01);//The count of point must be 0
                    return 0xff;
                }
            }
            else if (ApplVar.DecimalPoint)
            {
                ApplVar.DecimalPoint++;
                if (ch.Code == 0x3030)
                    ApplVar.DecimalPoint++;
                if (ApplVar.DecimalPoint > 4)
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                    return 0xff;
                }
            }
        }

        newX = 1;
        Editor.EditCount++;
#if defined(CASE_FORHANZI)
        if (ch.C.High>0x20)// Ϊ�����ַ� //
        {
            if (Editor.EditCount<Appl_MaxEntry)
            {// �༭ȥ���������������� //
                Editor.EditCount++;
                newX++;
            }
            else
                ch.Code = 0x0020;
        }
#endif
        memcpy(Editor.EditBuff,Editor.EditBuff+newX,oldX-newX);
        oldX--;
#if defined(CASE_FORHANZI)
        if (ch.C.High>0x20)//���CASE_FORHANZI=0,˫'00'������ܳ���!!!!!
            Editor.EditBuff[oldX--]=ch.C.High;
#endif
        Editor.EditBuff[oldX]=ch.C.Low;

        if (!TESTBIT(ApplVar.MyFlags,HANZIMODE))
        {
//			if (Editor.EditCount<=Appl_MaxEntry)
            {
                memset(SysBuf,' ',Editor.DispW);

                memcpy(SysBuf,Editor.EditBuff + Editor.BuffSize - Editor.DispW,Editor.DispW);

                SysBuf[Editor.DispW] = 0;

                if (TESTBIT(ApplVar.MyFlags,PWDMODE) || (ApplVar.CentralLock & 0x0f00))        /* secret code entry ? */
                {
                    for (oldX=0;oldX<Editor.DispW;oldX++)
                        if (SysBuf[oldX]>' ')
                            SysBuf[oldX]='*';
                        else if ((ApplVar.CentralLock & 0xf00)==0x200)
                            SysBuf[oldX] = '?';
                        else
                            SysBuf[oldX]='_';
                }


                if (TESTBIT(ApplVar.MyFlags,PWDMODE))
                {
                    if ((ApplVar.CentralLock & 0x0f00) || Appl_ProgLine<1)        /* secret code entry ? */
                        DispStrXY(SysBuf,Editor.DispX,SCREENLN);
                    else
                        DispStrXY(SysBuf,Editor.DispX,Editor.DispY);
                }
                else
                {
                    if ((ApplVar.CentralLock==SET || ApplVar.CentralLock==(SETUPMG | MG)) && Appl_ProgLine>1)//Appl_ProgLine>1ʱ,�����������ʾ����Ļ������
                        DispStrXY(Editor.EditBuff+Editor.BuffSize-Editor.DispW,Editor.DispX,Editor.DispY);
                    else
                        DispSt2(Editor.EditBuff+Editor.BuffSize-Editor.DispW);
                    if (ApplVar.CentralLock==RG || ApplVar.CentralLock==MG)
                        PutsO(SysBuf);//�����������ͬʱ��ʾ�ڿ�����
                }
            }
//		    else
//		    {
//		    	ApplVar.ErrorNumber=ERROR_ID(CWXXI18);
//		    	return 0xff;
//		    }
        }
        else
        {
            newX = Editor.BuffSize-Editor.DispW-Editor.EditOffs;
            sCurX = TestHZRight(Editor.EditBuff,newX);
            if (sCurX)
                DispCharXY(' ',Editor.DispX,Editor.DispY);
            DispStrXY(Editor.EditBuff+newX+sCurX,Editor.DispX+sCurX,Editor.DispY);
        }
    }
    return Editor.EditCount;
}
#if (1)//New
//============================================================================
// �ڵ�ǰ���λ�������ַ������ݱ༭��                                       //
// ���أ�1ʱ����ʾ��������˳���, ����ֵ>0,Ϊ���볤��                       //
// buf=�������ݴ����,width=�����������ݳ���, hzInput=�Ƿ���Ҫ���뺺������    //
// ��������ݿ�������buf��ǰwidth��λ�ã��������ݲ���width��ʱ��������ո�//
// ��width=6,���롮123����buf�е�����Ϊ'   123';                            //
//============================================================================
short GetChinStr(char *buf,short width,BYTE hzInput)
{
    WORD keyno ;
    BYTE saveRet,sSaveLine ;
    int x,y ;

#if defined(DEBUGBYPC)
	LoopInput=1;
#endif

    x=SCREENWD-width ;
    if(x<0)
    {
    	x=0;
        width = SCREENWD;
    }
    y=CursY ;

    DispStrXY(buf,x,y);
    GotoXY(SCREENWD,y);    //ccr�����붨�ڱ༭�����Ҷ�//
    Editor.EditBuff=buf ;	//// ��ʼ������������  ////
    Editor.BuffSize=width ;
    *((char*)(buf+width))=0 ;//// set the end flag of input    ////????????????
    Appl_MaxEntry=width ;		//// Max entry for input
    Editor.EditOffs=0 ;	//// the first input
    Editor.EditCount=0 ;
    Editor.DispX=x ;		//locationg for display
    Editor.DispY=y ;
   	Editor.DispW=width ;
    //ccrָ���༭���Ŀ���//
    if (!TESTBIT(ApplVar.MyFlags,PWDMODE))//ccr 050523
	    SETBIT(ApplVar.MyFlags,HANZIMODE);

#if PC_EMUKEY==0
	if (hzInput)
	{
	    ChnInput(2);//// ��ʼ���������뷽��,���뺺����������״̬ ////
	}
#endif
	sSaveLine = Appl_ProgLine;
	if (ApplVar.CentralLock == SET && TESTBIT(ApplVar.MyFlags,PWDMODE))//// input password mode
		Appl_ProgLine = 1;//display the password on screen area
	ApplVar.DispKey.Code = 0;//// ccr080612 ////
    for(;;)
    {
        while((keyno=ChnInput(0))==0)//// �����Ƿ�������  ////
		{//// ��������ң��״̬�µĴӼ�������ļ������� ////
		}
		if (keyno==(0x0100+cEXIT))
		{//// Ϊ�˳��� ////
            RESETBIT(ApplVar.MyFlags,(HANZIMODE | PWDMODE));//// ���������������������־  ////
#if defined(DEBUGBYPC)
            LoopInput=0;
#endif
			return -1;				//ccr 050523 �ͳ��˳���  ////
		}

		if (keyno==(0x0100+cSHIFT) && hzInput && !TESTBIT(ApplVar.ScreenStat,HZINPUTMODE))
		{//// Ϊ���뺺�����뷽ʽ�� ////
            ChnInput(2);
			continue;
		}


	    if (!TESTBIT(ApplVar.MyFlags,PWDMODE))//ccr 050523
    	    SETBIT(ApplVar.MyFlags,HANZIMODE);//  ������������״̬ʱ,���뺺������״̬  ////
        if((keyno&0xff00)==0x0100&&(keyno&0xff)==ApplVar.AP.FirmKeys[ID_ENTER])
        {//// Ϊ���ܼ���ȷ�ϼ�ʱ,�˳����� ////
        	ApplVar.ErrorNumber=0;
            ChnInput(3);
            RESETBIT(ApplVar.MyFlags,(HANZIMODE | PWDMODE));
            ScreenFeed(1);
            //ccr 040422
			Appl_ProgLine = sSaveLine;
#if defined(DEBUGBYPC)
            LoopInput=0;
#endif
            return(Editor.EditCount);
        }
        if (keyno==0x3030)// ˫<00>�� //
       	{
			keyno = '0';
	        saveRet=LineEditor(*((union KEY*)&keyno));//// ���ñ༭��,���������ݽ��б༭  ////
       	}
        saveRet=LineEditor(*((union KEY*)&keyno));//// ���ñ༭��,���������ݽ��б༭  ////
        ApplVar.ErrorNumber = 0;// !!!!!!!!!!!!!�����LineEditor����Ĵ��󣬷��򣬵�����ʱ��ChnInput�޷���������  ////
    }
}
#else//old
//============================================================================
//if buf[0]==' ', set the input mode into chinese
short GetChinStr(char *buf,short width,BYTE pwd)
{
    WORD keyno ;
    BYTE saveRet ;
    short x,y ;

    x=SCREENWD-width ;
    if(x<0)
    {
        x=0;
        width = SCREENWD;
    }
    y=CursY ;
    //ccr 040422

    GotoXY(SCREENWD,y);
    Editor.CursorX = SCREENWD;
    //�����붨�ڱ༭�����Ҷ�  //
    Editor.EditBuff=buf ;
    Editor.BuffSize=width ;
    *((char*)(buf+width))=0 ;

    Appl_MaxEntry=width ;
    Editor.EditOffs=0 ;
    Editor.EditCount=0 ;
    Editor.DispX=x ;
    Editor.DispY=y ;
    Editor.DispW=width ;
    //ָ���༭���Ŀ���         //
    if (buf[0]==' ')//input ascii string!!!!!!!!
    {
        SETBIT(ApplVar.MyFlags,HANZIMODE);
        ChnInput(2);
    }
    for (;;)
    {
        while ((keyno=ChnInput(0))==0);
        if ((keyno&0xff00)==0x0100&&(keyno&0xff)==ApplVar.AP.FirmKeys[ID_ENTER])
        {
            ChnInput(3);
            RESETBIT(ApplVar.MyFlags,HANZIMODE);
            ScreenFeed(1);
            //ccr 040422
            return(Editor.EditCount);
        }

        saveRet=LineEditor(*((union KEY*)&keyno));
    }
}
#endif



