#define PRINT_C
#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
#include "ejournal.h"
#include "fiscal.h"
#include "flowbill.h"
#include "Message.h"//lyq2003

#if (PC_EMUKEY==1)
    #include "FEcrTest.h"
#endif
//#define LQ300K  40
#define LQ300K  PRTLEN	 //Lyq modified 20040331

CONST char SlipCmd1[8][5] = {
    { 4, 27, 64, 0x1c, 0x26},            /* init printer command ESC '@', select chinese */
    { 2, 27, 118},           /* ask status byte from printer ESC 'v' */
    { 3, 27, 33, 0x20},        /* set double width with 1 space advance ' ' ESC '!' 0x20*/
    { 3, 27, 33, 0x00},        /* reset double width  ESC '!' 0x00 */
    { 3, 12, 27, 113},          /* eject and release FF ESC 'q' */
    { 3, 27, 70, 0},           /* set normal feed ESC 'F' 0 */
    { 3, 27, 70, 1},           /* set reverse feed ESC 'F' 1 */
    { 2, 27, 100},           /* fast feed paper N lines ESC 'd' n*/
};

CONST char SlipCmd2[8][5] = {
    { 2, 27, 64},            /* init printer command ESC '@' */
    { 2, 27, 118},           /* ask status byte from printer ESC 'v' */
    { 3, 27, 33, 0x20},        /* set double width with 1 space advance ' ' ESC '!' 0x20*/
    { 3, 27, 33, 0x00},        /* reset double width  ESC '!' 0x00 */
    { 3, 12, 27, 113},          /* eject and release FF ESC 'q' */
    { 3, 27, 70, 0},           /* set normal feed ESC 'F' 0 */
    { 3, 27, 70, 1},           /* set reverse feed ESC 'F' 1 */
    { 2, 27, 100},           /* fast feed paper N lines ESC 'd' n*/
};

CONST char SlipCmd3[8][5] = {
    { 0},            /* init printer command ESC '@' */
    { 3, 28, 33,12},           /* ask status byte from printer ESC 'v' 1 */
    { 3, 28, 33, 8},        /* set double width with 1 space advance ' ' ESC '!' 0x20*/
    { 3, 28, 33, 0},        /* reset double width  ESC '!' 0x00 */
    { 1, 12},          /* eject and release FF ESC 'q' */
    { 3, 27, 87, 1},           /* set double high ESC 'W' 1*/
    { 3, 27, 87, 0},           /* set double high ESC 'W' 1*/
    { 0},           /* fast feed paper N lines ESC 'd' n*/
};

CONST char SlipCmd4[8][5] = {
    { 5, 27, 64},   /* init printer command ESC '@'and 40 col  */
    { 2, 27, 118},           /* ask status byte from printer ESC 'v' */
    { 4, 27, 33, 0x21},        /* set double width with 1 space advance ' ' ESC '!' 0x20*/
    { 3, 27, 33, 0x01},        /* reset double width  ESC '!' 0x00 */
    { 3, 12, 27, 113},          /* eject and release FF ESC 'q' */
    { 3, 27, 70, 0},           /* set normal feed ESC 'F' 0 */
    { 3, 27, 70, 1},           /* set reverse feed ESC 'F' 1 */
    { 2, 27, 100},           /* fast feed paper N lines ESC 'd' n*/
};

CONST char SlipCmd5[8][5] = {            /* Sprint */
    { 2, 27, 103},   /* init printer font 2, 32 col  */
    { 0},           /* ask status byte from printer ESC 'v' */
    { 3, 27, 87, 49, 0},        /* set double width ESC 'W' '1'*/
    { 3, 27, 87, 48, 0},        /* reset double width  ESC 'W' '0' */
    { 1, 12},          /* eject and release FF */
    { 0},           /* set normal feed ESC 'F' 0 */
    { 0},           /* set reverse feed ESC 'F' 1 */
    { 0},           /* fast feed paper N lines ESC 'd' n*/
};

CONST BYTE CharTable[48] = {
    0x5c,0x7e,0x60,0x61,0x7b,0x40,0x7d,0x5c,
    0x65,0x65,0x7d,0x69,0x69,0x7e,0x5b,0x5d,
    0x40,0x7b,0x5b,0x6f,0x7c,0x7c,0x75,0x7c,
    0x79,0x5c,0x5e,0x7c,0x23,0x5c,0x23,0x66,
    0x61,0x69,0x6f,0x75,0x7c,0x5c,0x61,0x6f,
    0x5d,0x20,0x20,0x20,0x20,0x5b,0x3c,0x3e,
};


void PrintAllons(void);


/* check character for external printer */
BYTE CheckChar(BYTE ch)
{
    BYTE chset;

    chset = CHARSET & 0x0f;
    if (chset) /* not standard */
    {
        switch (ch)
        {
        case 0x15:
            if (chset == 1)
                ch = 0x5d;
            else
                ch = 0x40;
            break;
        case 0x81:
            if (chset == 2)
                ch = 0x7d;
            else
                ch = 0x7e;
            break;
        case 0x82:
            if (chset == 1)
                ch = 0x7b;
            else if (chset == 6)
                ch = 0x5d;
            else
                ch = 0x60;
            break;
        case 0x85:
            if (chset == 6)
                ch = 0x7b;
            else
                ch = 0x40;
            break;
        case 0x97:
            if (chset == 6)
                ch = 0x60;
            else
                ch = 0x7c;
            break;
        case 0x9a:
            if (chset == 2)
                ch = 0x5d;
            else
                ch = 0x5e;
            break;
        case 0xcf:
            ch = 0x24;
            break;
        case 0xe1:
            ch = 0x7e;
            break;
        case 0xf8:
            ch = 0x5b;
            break;
        default:
            if (ch > 0x7f && ch < 0xb0)
                ch = CharTable[ch & 0x7f];
            break;
        }
    }
    return ch;
}


void CmdSlip(char cmd)
{
    CONSTCHAR *p;
    BYTE l;

    if (SLIP == 1)
        p = (CONSTCHAR *)SlipCmd1[cmd];
    else if (SLIP == 2)
        p = (CONSTCHAR *)SlipCmd2[cmd];
    else if (SLIP == 5)     /* citizen printer */
        p = (CONSTCHAR *)SlipCmd4[cmd];
    else if (SLIP == 6)     /* DITRON Sprint */
        p = (CONSTCHAR *)SlipCmd5[cmd];
    else
        p = (CONSTCHAR *)SlipCmd3[cmd];

    l = *p;        /* length of data string */
    p++;
    while (l)
    {
        SendComm(SLIPPORT, *p);
        p++;
        l--;
    }
}

void ReleaseSlip()
{
    if (SLIP != 3)   // LYQ ADDED FOR ESP\C 20040324
        CmdSlip(6);     /* set reverse line feed */
    CmdSlip(4);
    if (SLIP != 3)   // LYQ ADDED FOR ESP\C 20040324
        CmdSlip(5);     /* set normal line feed */
}


BYTE CheckSlip()
{
    ApplVar.SlipLines = 0;
    if (!SLIP)
        return 0;
    if (!TESTBIT(ApplVar.PrintLayOut, BIT3)) /* print on slip ? */
        return 0;

    if (!CheckOnLine(SLIPPORT))
    {
        if (ApplVar.SlipPage || TESTBIT(ApplVar.PrintLayOut, BIT4)) /* slip compulsory */
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI38);   /* not on line */
            return 1;
        }
        else
            return 0;
    }
/*       while(Check232(SLIPPORT)); */
    if (SLIP < 3 || SLIP == 5)       /* only CTM-290 & 290 II */
    {
        CmdSlip(0);     /* init printer */
        if (SLIP == 5)      /* also set columns */
            CmdSlip(3);
        CmdSlip(1);     /* ask status */
        ApplVar.SlipLines = ReadComm(SLIPPORT);
        if (ApplVar.SlipLines & (BIT0 + BIT1))
        {
            ApplVar.SlipLines = 0;
            if ((ApplVar.SlipPage && TESTBIT(ApplVar.PrintLayOut, BIT3))
                || TESTBIT(ApplVar.PrintLayOut, BIT4))
            {

                ApplVar.ErrorNumber=ERROR_ID(CWXXI35);
                return 1;
            }
            else
                return 0;
        }
    }
    if (SLIP != 4 && SLIP != 6)       /* Epson compatible ? then select char set */
    {
        SendComm(SLIPPORT, 0x1b);
        SendComm(SLIPPORT, 'R');
        SendComm(SLIPPORT, CHARSET & 0x0f);
        if (SLIP == 3)
        {
            SendComm(SLIPPORT, 0x1c);
            SendComm(SLIPPORT, '&');
        }
    }
    ApplVar.SlipLines = 1;
    return 0;
}

void FeedSlip(BYTE lines)

{
    if (SLIP > 2 && SLIP != 5)
    {
        while (lines)
        {
            SendComm(SLIPPORT, 0x0a);        /* line feed */
            lines--;
        }
    }
    else
    {
        CmdSlip(7);
        SendComm(SLIPPORT, lines);
    }
}

void SlipMargin()
{
    BYTE l;

    l = LMARGE;     /* left margin */
    while (l)
    {
        SendComm(SLIPPORT, ' ');
        l--;
    }
}

void PrintSlip(CONSTCHAR *str)
{
#if !defined(DEBUGBYPC)
    BYTE l, d ,r = 0;
    //BYTE sInt,data[15]="I'm Here!";	//hf added for test

    if (SLIP == 2)
    {
        PrintDotEpson();   /* 0 is TM290 */
        return;
    }

    l = LQ300K ;  /* 31; */
    if (SLIP == 6)
    {
        CmdSlip(0);                        /* set font 2 */
        l = 32;
        if (SLIP == 6)             /* sprint */
        {
            SendComm(SLIPPORT, 27);
            SendComm(SLIPPORT, 65);
            SendComm(SLIPPORT, CHARSET & 0x0f);
        }
    }
    d = 0;
    while (*str == ' ')
    {
        r++;
        if (r<LQ300K+1)
            str++;
        else
            break;

    }
    r = 0;
    while (l && *str)
    {
        if (*str == '~' && SLIP == 3)        /* double size char lyq modified for double high*/
        {
            CmdSlip(5);
            d = 1;              /* set double width */
            r = 0;
        }
        else if (*str == '@')
        {
            if (SLIP == 3 && d == 1)
                CmdSlip(1);
            else
                CmdSlip(2);
            d = 2;
            r = 0;
        }
        else
        {
            if (SLIP != 4)     /* Epson Compatible */
                SendComm(SLIPPORT, CheckChar(*str));
            else
            {
                SendComm(SLIPPORT, *str);           /* hf print to slip printer */
                //hf added for test >>>>>>>>>>>>>>>>>>>>
                /*data[9] = 0x0d;
                data[10] = 0x0a;
                for(sInt = 0;sInt < 11;sInt++)
                {
                    SendComm(SLIPPORT,*(data+sInt));
                    }*/
                //hf added end <<<<<<<<<<<<<<<<<<<<<<<
            }
            if (ApplVar.SlipDouble==0 && d )
            {
                if (*str < 0x81 || r==1)
                {
                    if (SLIP != 3 && d==2)
                        CmdSlip(3);                /* reset double high */
                    else
                        CmdSlip(6);
                }
            }
            r = 1;
        }
        str++;
        l--;
    }
    if (d==2)
    {
        ApplVar.SlipLines ++ ;
//    	CmdSlip(3);                /* reset double high */
//    	d = 0;
    }
    SendComm(SLIPPORT, 0x0d);
    SendComm(SLIPPORT, 0x0a);
#endif
}


void PrintSlipPage(short sub)
{
    char line[LQ300K+1], l;   /* 36 */
    BYTE BCDValue1,BCDValue2,temp3;

    MemSet(line, sizeof(line), ' ');
    if (SLIP == 2)
        l = 24;
    else if (SLIP == 6)
        l = 32;
    else
        l = LQ300K ; /* 35; */
    line[l] = 0;
    l--;
    CopyFrStr(line, Prompt.Caption[28]);
    WORDtoASC(line + 8, ApplVar.SlipPage);
    if (sub && (ApplVar.FRegi || ApplVar.FTend || ApplVar.BufRec))
    {
        if (SLIP != 2)
            CopyFrStr(line + 11, Prompt.Caption[1]);
        BCDValue1 = ApplVar.AmtDecimal; /*    save     */
        BCDValue2 = Prefix1;
        temp3 = Prefix2;
        ApplVar.AmtDecimal = NO_DECIMAL; /* restore */
        Prefix1 = PREFIX_1;
        Prefix2 = PREFIX_2;
        if (ApplVar.FRegi)
            FormatAmt(line + l, &ApplVar.SaleAmt);
        else
            FormatAmt(line + l, &ApplVar.SubTotal);
        ApplVar.AmtDecimal = BCDValue1; /* restore */
        Prefix1 = BCDValue2;
        Prefix2 = temp3;
    }
    SlipMargin();
//    PrintSlip(line);	// delete if open table, page number isn't continuous  20040331
}

/* ApplVar.PrintLayOut contains the print CONSTruction */
/* BIT 0 if set journal */
/* BIT 1 if set receipt */
/* BIT 2 if set DOUBLE HEIGHT (XT thermal) */
/* BIT 3 if set then print on slip, if set in command to xt printer then */
/* no inter line spacing so skip bit */

void PrintRJ(CONSTCHAR *str)
{
    BYTE    print;


    if (ApplVar.FReport || ProgStart == 2)        /* report or dump in progress? */
    {
/*ccr20130311>>>>>>>>
        if (!ApplVar.RepComputer)
        {
            if (ChkPaper())          // out of paper ?
            {
                CheckError(ERROR_ID(CWXXI40));
                while (ChkPaper()) ;
            }
        }
 <<<<<<<<<<<<<<<<<<<<<<*/
        CheckBreakKey();
    }

    print = ApplVar.PrintLayOut & 0x07;

    if (TESTBIT(ARROWS, BIT0) || ApplVar.FReport)        /* receipt on or report ? */
    {
        if (TESTBIT(ApplVar.PrintLayOut, BIT1))     /* print on receipt ? */
            ApplVar.FReceipt = 1; //ccr2015-01-12:�������1,�����������һ��RegiInit�д�ӡһ��Ʊͷ������
    }
    else
        RESETBIT(print, BIT1);
    if (TESTBIT(ApplVar.PrintLayOut, BIT0))     /* print on journal ? */
        ApplVar.FJournal = 1;   /* set journal used */

    if (TESTBIT(print, BIT0 + BIT1))    /* still print ? */
    {
        if ( !RJPRN )
            print &= 0xfe ;
        else if ( RJPRN &&( ApplVar.CentralLock == RG || ApplVar.CentralLock == MG ) )
            print &= 0xfd ;
        RJPrint(print,str) ;
    }
}


BYTE PrintQtyAmt(BCD *qty,CONSTCHAR *str,BCD *amt)
{
    BYTE l, sliplen,rlen;

    if (ApplVar.FCanc)
        ApplVar.PrintLayOut &= ApplVar.CancPrint;
//    if (ApplVar.FTrain || ApplVar.FProforma == 1)
//		ApplVar.PrintLayOut &= 0xfe;    /* skip journal */

    if (amt)
    {
        if (TESTBIT(ApplVar.PrintLayOut, BIT5))  // amount on seperate line ?
        {
            if (str)
                PrintRJ((CONSTCHAR *)str);
            PrintRJ(FormatAmtStr((CONSTCHAR *)0, amt, PRTLEN));
        }
        else
        {
            if (qty)
            {
                rlen = strlen(str);
//				memcpy(SysBuf, str, rlen);
                while (*(str+rlen -1)==' ' && rlen)
                    rlen--;
#if (PRTLEN>24)
                if ((rlen+BCDWidth(qty))>12)
                {//012345678901234567890123456789012
                 //Caption
                 //       QTY       Price    Amout
                    PrintRJ((CONSTCHAR *)str);
                    MemSet(SysBuf, sizeof(SysBuf), ' ');
                    FormatAmt(SysBuf +PRTLEN - 1, amt);
                    FormatAmt(SysBuf + 18 +(PRTLEN>32)*2, &ApplVar.Price);
                    FormatQty(SysBuf + 10 +(PRTLEN>32)*2, qty);
                    PrintRJ(SysBuf);
                }
                else if (BCDWidth(&ApplVar.Price)>(6) || BCDWidth(amt)>(6))
                {//012345678901234567890123456789012
                 //Caption  QTY
                 //             Price         Amout
                    strcpy(ProgLineMes,FormatQtyStr((CONSTCHAR *)str,qty,12+(PRTLEN>32)*2));
                    PrintRJ(ProgLineMes);
                    MemSet(SysBuf, sizeof(SysBuf), ' ');
                    FormatAmt(SysBuf +PRTLEN - 1, amt);
                    FormatAmt(SysBuf + 18 +(PRTLEN>32)*2, &ApplVar.Price);
                    PrintRJ(SysBuf);
                }
                else//012345678901234567890123456789012
                    //Caption QTY      Pri     Amout
                    PrintRJ(FormatStrQtyPriAmt((CONSTCHAR *)str, qty, &ApplVar.Price, amt, PRTLEN));
#else
                if (CompareBCD(qty,&ONE))
                {//shop2000
                    MemSet(ProgLineMes, sizeof(ProgLineMes), ' ');
                    FormatQty(ProgLineMes + 7, qty);
                    ProgLineMes[9] = 'X';
                    ProgLineMes[10] = 0;
                    l = (BCDWidth(&ApplVar.Price))+12;
                    if (l==12)  //  PriceΪ0ʱ��ȷ��3λС�� //
                        l+=3;
                    PrintRJ(FormatAmtStr(ProgLineMes, &ApplVar.Price, l));
                }
                PrintRJ(FormatStrQtyPriAmt((CONSTCHAR *)str, 0, 0, amt, PRTLEN));
#endif
            }
            else
                PrintRJ(FormatAmtStr((CONSTCHAR *)str, amt, PRTLEN));
        }
    }
    else if (qty)
        PrintRJ(FormatQtyStr((CONSTCHAR *)str, qty, PRTLEN));
    else
        PrintRJ((CONSTCHAR *)str);
    //hf  update from here >>>>>>>>>>>>>>>>>>>>>
    if (ApplVar.SlipLines && TESTBIT(ApplVar.PrintLayOut, BIT3) && ApplVar.FRegi && SLIP)     /* print on slip ? */
    {
        if (SLIP_MAX)     /* max lines on slip ? */
        {
            if ((ApplVar.SlipLines >= SLIP_MAX) || (SLIP == 6 && ApplVar.SlipLines >= 26))
            {
                ApplVar.SlipPage++;
                PrintSlipPage(1);
                ReleaseSlip();
                if (SLIP == 6)
                {
                    ApplVar.SlipLines = 1;
                }
                else
                {
                    PutsO(DMes[15]);
                    Bell(3);
                    for (;;)
                    {
                        FM_EJ_Exist();
                        if (KbHit()&&ApplVar.AP.KeyTable[Getch()] == CLEAR)
                        {
                            l = CheckSlip();  /* clear key and paper */
                            if (!l || ApplVar.ErrorNumber== 38)
                            {
                                if (ApplVar.ErrorNumber== 38)
                                    return 0;
                                ApplVar.ErrorNumber=0;
                                break;
                            }
                        }

                    }
                }
            }
        }
        if (ApplVar.SlipLines == 1)
        {
            if (SLIP_TOP)     /* start of slip and feed ? */
                FeedSlip(SLIP_TOP);
            ApplVar.SlipLines = 1;
            if (!ApplVar.SlipPage && ((ApplVar.Correc.Options & 0x07)!=3))     //20040325
            {
                for (l = 0; l < 6; l++)
                {
                    if (ApplVar.TXT.SlipHeader[l][0])
                    {
                        SlipMargin();
                        //MemSet(SysBuf, 41, ' ');
                        //memcpy(SysBuf, ApplVar.TXT.SlipHeader[l],PRTLEN);	  // 20040325
                        PrintSlip(ApplVar.TXT.SlipHeader[l]);
                        ApplVar.SlipLines++;
                    }
                    else
                        break;
                }
            }
            if (ApplVar.SlipPage)
            {
                PrintSlipPage(1);
                ApplVar.SlipLines++;
            }
        }
        SlipMargin();
        if (SLIP != 2)             /* Chinese with TM-290II */
        {
            if (ApplVar.SlipDouble)    /* Double size ? */
            {
                if (SLIP !=  4)
                {
                    CmdSlip(2);                /* set double width */
                }
                l = LQ300K ; /* 31; */
                if (SLIP == 6)
                    l--;
            }
            else
            {
                if (TESTBIT(SLIPINFO, BIT0) && amt && qty)
                    l = LQ300K ;  /* 31; */
                else
                    l = LQ300K ;  /* 31; */

                if (SLIP == 6)
                    l -= 3;
            }
        }
        if (!amt && !qty && str)
            PrintSlip((CONSTCHAR *)str);
        else
        {
            if (SLIP == 2)
            {
                if (amt)
                {
                    if (TESTBIT(ApplVar.PrintLayOut, BIT5)) /* amount on seperate line ? */
                    {
                        PrintSlip((CONSTCHAR *)str);
                        ApplVar.SlipLines++;
                        PrintSlip(FormatStrQtyPriAmt((CONSTCHAR *)0, qty, &ApplVar.Price, amt, PRTLEN));
                    }
                    else
                    {
                        PrintSlip(FormatStrQtyPriAmt(str, qty, &ApplVar.Price, amt, PRTLEN));
                    }
                }
                else if (qty)
                    PrintSlip(FormatQtyStr((CONSTCHAR *)str, qty, PRTLEN));
                else
                    PrintSlip((CONSTCHAR *)str);
            }
            else
            {
                if (SLIP == 6)
                    sliplen = 26;
                else
                    sliplen = 25;

                /*hf slip printer >>>>>>>>>>>>>>>>>>>>>>>
                if (amt)
                {
                    FormatAmtStr((CONSTCHAR *)str, amt, l);
                    if (qty) //&& l == sliplen
                    FormatStrQtyPriAmt(str, qty, &ApplVar.Price, amt, PRTLEN);//????????????????????????
                }
                else
                    FormatQtyStr((CONSTCHAR *)str, qty, l);      // not print if > 999 or with decimal
                hf slip printer <<<<<<<<<<<<<<<<<<<<<<<<*/

                //hf 20050815 start >>>>>>>>>>>>>>>>>>>>>>>>>>
                if (amt)
                {
                    FormatAmtStr((CONSTCHAR *)str, amt, l);
                    if (qty) //&& l == sliplen
                    {
#if(PRTLEN<25)
                        rlen = strlen(str);
                        while (*(str+rlen-1)==' ' && rlen)
                            rlen--;
                        if (CompareBCD(qty,&ONE))
                        {
                            MemSet(ProgLineMes,sizeof(ProgLineMes),' ');
                            FormatQty((ProgLineMes+7),qty);
                            ProgLineMes[9]='X' ;
                            ProgLineMes[10]=0 ;
                            l=(BCDWidth(&ApplVar.Price))+12 ;
                            //  PriceΪ0ʱ��ȷ��3λС�� //
                            if (l==12)
                                l+=3 ;
                            PrintSlip(FormatAmtStr(ProgLineMes,&ApplVar.Price,l));
                        }
#else
                        FormatStrQtyPriAmt(str, qty, &ApplVar.Price, amt, PRTLEN);//????????????????????????
#endif
                    }
#if(PRTLEN<25)
                    FormatStrQtyPriAmt(str, NULL, NULL, amt, PRTLEN);   //hf added for test
#endif
                }
                else
                    FormatQtyStr((CONSTCHAR *)str, qty, l);      // not print if > 999 or with decimal
                //hf  end <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


                if (l == sliplen)
                    l += 6;
                if (SLIP == 4 && l == 17)               // double size
                {
                    SysBuf[sizeof(SysBuf) - 36] = ' ';//????????????????????????
                    for (l = 0; l < 17; l++)
                    {
                        SysBuf[sizeof(SysBuf) + l * 2] = ' ';//????????????????????????
                        SysBuf[sizeof(SysBuf) + l * 2] = SysBuf[sizeof(SysBuf) + l];//????????????????????????
                    }
                    PrintSlip(SysBuf);//????????????????????????
                }
                else
                {
                    PrintSlip(SysBuf);//????????????????????????		//print slip to extern printer
                }
            }
        }
        if (ApplVar.SlipDouble && SLIP == 3)
            ApplVar.SlipLines ++ ;
        ApplVar.SlipLines++;
        if (SLIP != 4)
            CmdSlip(3);        /* set normal width */
    }
    ApplVar.SlipDouble = 0;
    return 0;
}

void PrintStr(CONSTCHAR *str)
{
    if (ApplVar.FCanc)
        ApplVar.PrintLayOut &= ApplVar.CancPrint;
    PrintRJ(str);
}

void PrintLine(char c)          /* print line of characters */
{
    MemSet(SysBuf, PRTLEN, c);
    SysBuf[PRTLEN]=0;
    PrintStr(SysBuf);
}

BYTE PrintAmt(CONSTCHAR *str,BCD *amt)
{
    return(PrintQtyAmt(0, str, amt));
}

BYTE PrintQty(CONSTCHAR *str,BCD *qty)
{
    return(PrintQtyAmt(qty, str, 0));
}

void PrintHead1(short line)
{

    BYTE saveprint;

    saveprint = ApplVar.PrintLayOut;

    if (TESTBIT(AM_PM, BIT2))
        ApplVar.PrintLayOut = 0x06;
    else
        ApplVar.PrintLayOut = 0x02;
    if ( RJPRN )
        ApplVar.PrintLayOut = 0 ;
    {
        for (; line < 8; line++)
        {
			if (ApplVar.TXT.Header[line][0])
			{
				PrintStr_Center(ApplVar.TXT.Header[line],DBLHIPRN & BIT3);
			}
			else
				break;
        }
    }
    ApplVar.PrintLayOut = saveprint;

}


void PrintRegiInfo(BYTE prnGrp)
{
    WORD i,sP;

    if (ApplVar.FTrain)
        PrintMessage(43);   /* print training */
    if (ApplVar.FProforma)
        PrintMessage(58);   /* print proforma */

    sP = 0;
#if !defined(CASE_ITALIA)
#if (DD_FISPRINTER==0)		// liuj 0907
    if (!TESTBIT(COMMA, BIT5))         /* print CLERK ? */
    {
        memset(SysBuf,' ', sizeof(SysBuf));
//012345678901234567890123456789012345
/*Clerk :********    Saler :********    */
        CopyFrStr(SysBuf,DMes[20]);
        sP = strlen(DMes[20]);
        i = strlen(ApplVar.Clerk.Name);
        if (i>15)    //8  ccr20140715
            i = 15;  //8  ccr20140715
        memcpy(SysBuf + sP, ApplVar.Clerk.Name,i);

#if (PRTLEN<25)
        SysBuf[PRTLEN]=0;
        PrintStr(SysBuf);
        if (ApplVar.SalPerNumber && TESTBIT(PLU_PRINT,BIT4))
        {
            memset(SysBuf,' ', sizeof(SysBuf));
            sP = strlen(DMes[21]);
            CopyFrStr(SysBuf,DMes[21]);
            i = strlen(ApplVar.SalPer.Name);
            if (i>15)    //8  ccr20140715
                i = 15;  //8  ccr20140715
            memcpy(SysBuf + sP, ApplVar.SalPer.Name,i);
            SysBuf[PRTLEN]=0;
            PrintStr(SysBuf);
        }
#else
        sP = (PRTLEN<36)?17:(19);
        if (ApplVar.SalPerNumber && TESTBIT(PLU_PRINT,BIT4))
        {
            CopyFrStr(SysBuf+sP,DMes[21]);
            sP += strlen(DMes[21]);
            i = strlen(ApplVar.SalPer.Name);
            if (i>15)    //8  ccr20140715
                i = 15;  //8  ccr20140715
            memcpy(SysBuf + sP, ApplVar.SalPer.Name,i);
        }
        //  PenGH  2008-11-21
        //  If the end char of the str is ~ or @ then  delete it
        if (  (SysBuf[PRTLEN-1]=='~')||(SysBuf[PRTLEN-1]=='@') )
        {
            SysBuf[PRTLEN-1]=SysBuf[PRTLEN];
        }
        //  PenGH
        SysBuf[PRTLEN]=0;
        PrintStr(SysBuf);
#endif
    }

    if (TESTBIT(CLERKFIX, BIT3))         /* print CLERK ? */
    {
//012345678901234567890123456789012345
/*ApplVar.Clerk :********    Saler :********    */
        memset(SysBuf,' ', sizeof(SysBuf));
        strcpy(SysBuf,DMes[20]);
        sP = strlen(DMes[20]);
        SysBuf[sP]='#';
        WORDtoASC(SysBuf + sP + 2, ApplVar.ClerkNumber);
#if (PRTLEN<25)
        sP = 11;
#else
        sP = 17;
#endif
        if (ApplVar.SalPerNumber && TESTBIT(PLU_PRINT,BIT4))
        {
            strcpy(SysBuf+sP,DMes[21]);
            sP += strlen(DMes[21]);
            SysBuf[sP]='#';
            WORDtoASC(SysBuf + sP + 2, ApplVar.SalPerNumber);
        }
        SysBuf[PRTLEN]=0;
        PrintStr(SysBuf);
    }
#endif
#endif
    if (!TESTBIT(COMMA, BIT4))         /* print LXX RXX ? */
    {
//012345678901234567890123456789012345
/*RegiterN: 9999        POSI: 9999   */
        memset(SysBuf,' ', sizeof(SysBuf));
        sP = 0;
        if (REGISTER)
        {/* REGISTER number */
            sP = strlen(DMes[22]);
            CopyFrStr(SysBuf,DMes[22]);
            WORDtoASC(SysBuf + sP + 3, REGISTER);
#if	(PRTLEN<25)
            sP = 11;
#else
            sP = 15;
#endif
        }
        if (LOCATION)
        { /* LOCATION number */
            i = strlen(DMes[23]);
            CopyFrStr(SysBuf + sP, DMes[23]);
            sP += i;
            WORDtoASC(SysBuf + sP +3, LOCATION);
        }
        if (LOCATION || REGISTER)
        {
            SysBuf[PRTLEN]=0;
            PrintStr(SysBuf);
        }
    }


    RESETBIT(ApplVar.PrintLayOut, BIT2);

    memset(SysBuf,' ', sizeof(SysBuf));
#if defined(CASE_ITALIA)
    if (!TESTBIT(COMMA, BIT5))         /* print CLERK ? */
    {
        sprintf(SysBuf,"OP.%u",ApplVar.ClerkNumber);
        SysBuf[strlen(SysBuf)]=' ';
    }
    DateTimeToStr(SysBuf+PRTLEN-16,3);
    SysBuf[PRTLEN] = 0;  //The time format must be HH:MM (Hours:Minutes)
#else
    DateTimeToStr(SysBuf,3);
#endif

#if (defined(CASE_ITALIA) || (PRTLEN<25))
    SysBuf[PRTLEN]=0;
    PrintStr(SysBuf);
    memset(SysBuf,' ', sizeof(SysBuf));
#endif

#if defined(CASE_ITALIA)

    sprintf(SysBuf,"#%lu",ApplVar.EJLogHeader.DocNumber_EJ);//ccr091103
    SysBuf[strlen(SysBuf)]=' ';
    sprintf(SysBuf+10,"REG.%.3u",ApplVar.EJHeader.EJID);//ccr091103
    RJPrint(0, SysBuf);     //liuj 0528

    memset(SysBuf,' ', sizeof(SysBuf));
    GetReceiptNumber(SysBuf);
    SETBIT(ApplVar.PrintLayOut, BIT0);
    RJPrint(0,SysBuf);//2012-12-13 09:34:13     F000004
#else
#if !defined(FISCAL)
    if (!TESTBIT(COMMA, BIT3))         /* print receipt number ? */
#endif
        GetReceiptNumber(SysBuf +  PRTLEN -9);
    if (((SLIPINFO & (BIT1+BIT2)) != BIT1+BIT2) ||
        (COMMA & (BIT3+BIT6+BIT7)) != (BIT3+BIT6+BIT7))  /* print something */
    {
        if (TESTBIT(COMMA, BIT2))          /* double heigth ? */
            SETBIT(ApplVar.PrintLayOut, BIT2);
        SysBuf[PRTLEN] = 0;
        SETBIT(ApplVar.PrintLayOut, BIT0);
        RJPrint(0,SysBuf);//2012-12-13 09:34:13     F000004
        RESETBIT(ApplVar.PrintLayOut, BIT2);
        if (TESTBIT(SLIPINFO, BIT3) && (ApplVar.Key.Code>PORA + 100 && ApplVar.Key.Code < TEND + 100))     /* print on slip ? */ //lyq added for slip  start 20040324
        {
            SlipMargin();
            PrintSlip(SysBuf);
            //			RESETBIT(ApplVar.MyFlags, ENSLIPPB);	 //lyq added for slip 20040324
        }                               //lyq added for slip end 20040324
    }
#endif

    if (prnGrp && !TESTBIT(ApplVar.MyFlags, PRNONPB+ENPRINTER))
    {
        GetTimeDate(&Now);
        sP = EncordDate(Now.year,Now.month,Now.day);
        for (i=1;i<GRAFESTMAX+1;i++)
        {
            if (ApplVar.Graph[i].PictNo>0 && ApplVar.Graph[i].PictNo<=GRAPHICMAX)
            {//=1ʱ��Ϊ�û��Զ���ͼƬ
                if (sP>=EncordDate(*((WORD *)(ApplVar.Graph[i].DateFrom+2)),ApplVar.Graph[i].DateFrom[1],ApplVar.Graph[i].DateFrom[0]) &&
                    sP<=EncordDate(*((WORD *)(ApplVar.Graph[i].DateTo+2)),ApplVar.Graph[i].DateTo[1],ApplVar.Graph[i].DateTo[0]))
                {
                    Bios(BiosCmd_PrintGraph, (void*)(ApplVar.Graph[i].PictNo), 1 , 0); //Stampa msg ram
                    break;
                }
            }
        }
        if (ApplVar.Graph[GRAFESTMAX+1].PictNo>0 && ApplVar.Graph[GRAFESTMAX+1].PictNo<=GRAPHICMAX && i==GRAFESTMAX+1)
            Bios(BiosCmd_PrintGraph, (void*)(ApplVar.Graph[GRAFESTMAX+1].PictNo), 1 , 0); //Stampa msg ram
    }
}

void ReceiptIssue(short sliptimedate)
/*
    if bit0=0 then print time data on slip
    if bit1=0 then Print Head and the add start of EJ_DOC flag to EJ
    if bit2=0 then Print trailer and then add end of EJ_DOC flag to EJ
*/
{
    short i;
    BYTE saveprint;

#if (!defined(FISCAL) || DD_MMC==0)
    RESETBIT(sliptimedate,BIT1+BIT2);//ccr070609pm
#endif

#if DD_CHIPC
    RESETBIT(IC.ICState,IC_DISCOUNT | IC_POINTS);//ccr chipcard
#endif

    if (!TESTBIT(sliptimedate,BIT2))//    ccr070609pm
    {
#if(CASE_RAMBILL)
        Collect_Data(ENDLOG);
        Collect_Data(GIVENLOG);
#endif
        if (ApplVar.BufKp != 2)
        {
            if (ApplVar.FJournal && !ApplVar.BufRec && (ApplVar.CentralLock == RG || ApplVar.CentralLock == MG))
                ApplVar.PrintLayOut = 0x01;
            if (ApplVar.SlipLines > 1 && (sliptimedate & 1))//ccr
                ApplVar.PrintLayOut |= 0x08;        /* set print slip */
            if (ApplVar.FReceipt)    /* Receipt Used ? */
            {
                ApplVar.PrintLayOut |= 0x02;
                RFeed(0);
            }
        }
#if (defined(CASE_MALTA))
        if (ApplVar.FVatNo[0])
        {
            memset(SysBuf, ' ', PRTLEN);
            CopyFrStr(SysBuf,RIFCUSTOMER);
            memcpy(SysBuf+PRTLEN-1-sizeof(ApplVar.FVatNo),ApplVar.FVatNo,sizeof(ApplVar.FVatNo));
            RJPrint(0,SysBuf);
            memset(&ApplVar.FVatNo,0,sizeof(ApplVar.FVatNo));
        }
#endif
        PrintRegiInfo(true);
#if defined(FISCAL)
        FiscalTrailer();
#elif DD_MMC == 1  // liuj 0813
        if (TESTBIT(ApplVar.ContFlag,ENSTORE))   // liuj 0528
        {
            memset(SysBuf,' ',PRTLEN);
            sprintf(SysBuf+PRTLEN-9,"E%.8lu",ApplVar.EJLogHeader.DocNumber_EJ);//ccr091103
            PrintStr(SysBuf);
        }
#endif

        saveprint = ApplVar.PrintLayOut;
        if (ApplVar.FReceipt)    /* Receipt Used ? */
        {
            if (RJPRN)
                ApplVar.PrintLayOut = 0 ;
            else if (TESTBIT(AM_PM, BIT2))
                ApplVar.PrintLayOut = 0x06;        /* Double Heigth */
            else
                ApplVar.PrintLayOut = 0x02;
            if (ApplVar.BufKp != 2)
            {
//                if (ApplVar.TXT.Trailer[0][0])
                {//��ӡƱβ������Ϣ
                    for (i = 0; (i < 6) && ApplVar.TXT.Trailer[i][0] ; i++)
                    {
                         PrintStr_Center(ApplVar.TXT.Trailer[i],DBLHIPRN & BIT4);
                    }
                }
                PrintPbTrailer();
            }
        }

        if (!TESTBIT(PLU_PRINT,BIT6) && ApplVar.FTrvoid==0)
        {
            ApplVar.PrintLayOut=saveprint;
            PrintAllons();
        }

        CutRPaper(3);//ccr070612
    }
#if ( DD_MMC == 1)//liuj 0813
    if (TESTBIT(ApplVar.ContFlag,ENSTORE | EJ_HEAD) && !TESTBIT(sliptimedate,BIT2))//ccr070609pm
    {
        ApplVar.EJContent = ENDCONT;
        StoreLogData(CEJ_STARTLN,0);//ccr070609pm
        RESETBIT(ApplVar.ContFlag,PRNRGHEAD+EJ_HEAD); //liuj 0611
    }

    if (!TESTBIT(sliptimedate,BIT1))  //ccr070609pm
    {
        SETBIT(ApplVar.ContFlag, ENSTORE|ENHEADER);
        if (ApplVar.CentralLock == Z)
            ApplVar.EJContent = CLOSCONT;
        else if (ApplVar.CentralLock == X)
            ApplVar.EJContent = TXTCONT;
        else
        {
            SETBIT(ApplVar.ContFlag,PRNRGHEAD);//ccr070609pm
            ApplVar.EJContent = REGICONT;
        }
    }
#endif

    if (ApplVar.FReceipt &&                         /* Receipt Used ? */
        !TESTBIT(sliptimedate,BIT1))
    {
        if (RJPRN)
            ApplVar.PrintLayOut = 0 ;
        else if (TESTBIT(AM_PM, BIT2))
            ApplVar.PrintLayOut = 0x06;        /* Double Heigth */
        else
            ApplVar.PrintLayOut = 0x02;

#if (DD_FISPRINTER==0)
#if (DD_CUTTER)//ccr2014-08-14 ����˺ֽλ��>>>>>
        if (!(CUTTER & 0x03))
            RFeed(5);//
#else
        RFeed(1);//
#endif//<<<<<<<<
#endif

        if (TESTBIT(KPPRICE, BIT4))
        {
            if (TESTBIT(AM_PM, BIT2) && (CUTTER & 0x03)==0)
                RFeed(4);
            else
                RFeed(5);
            if (ApplVar.TXT.Header[0][0])
            {
                PrintStr_Center(ApplVar.TXT.Header[0],DBLHIPRN & BIT3);
            }
            else
                RFeed(1);
        }
        else
        {
            for (i = 0; i < PREHEADER; i++)
            {//Ԥ��ӡƱͷ
                if (ApplVar.TXT.Header[i][0])
                {
                    PrintStr_Center(ApplVar.TXT.Header[i],DBLHIPRN & BIT3);
                }
                else
                    RFeed(1);

                if ((CUTTER & 0x03)==0)
                {
                    if (i > 4 || (TESTBIT(AM_PM, BIT2) && i > 1))
                        break;
                }
            }
        }

#if DD_CUTTER
//        if ((CUTTER & 0x03))
//            DrawerOpen();
#endif
    }

    ApplVar.PrintLayOut = saveprint;
    ApplVar.FNoTime = 0;

    if (ApplVar.BufKp == 2)
        return;
    if (ApplVar.SlipPage)
    {
        ApplVar.SlipPage++;
        if (!ApplVar.FPb)
            PrintSlipPage(0);           /* no Subtotal */
    }
    if (ApplVar.SlipLines > 1)
    {
        ReleaseSlip();
        ApplVar.Correc.Options = 0;
    }

    ApplVar.SlipPage = 0;
    ApplVar.PrintLayOut &= 0x01;
    /*PrintLine('+');*/
    ApplVar.FReceipt = 0;
    ApplVar.FJournal = 0;
    ApplVar.CurLine = 0;
#if defined(FISCAL) // LIUJ 0805
//liuj 0730
    if (ApplVar.FisCardFlag == EJLESS)
        ApplVar.ErrorNumber=ERROR_ID(CWXXI87) ;
#endif

}

void PrintAllons()
{

#define PRESSENTER 1	//   �Ƿ���Ҫ��ȷ�ϼ�    //
#define PRNAMTON 	0	//  �Ƿ���СƱ��ͬʱ��ӡ�����ͽ�� //
#define ALLPRNPOS	(6-PRNAMTON*2)  //   ��Ʒ���ƴ�ӡλ��   //

#if (PRNAMTON)
    BCD sAmt;
#endif
    short i,j;
    BYTE sGroup;
    BYTE sLine;
    BYTE keyno = 0;
    WORD sFlags,sSavePBn;

    for (i=0;i<ApplVar.RGNumber;i++)
    {
        if (ApplVar.RGBuf[i].Group!=0xff && (ApplVar.RGBuf[i].Key.Code>PLU1 && ApplVar.RGBuf[i].Key.Code<PLU3 ||
                                             ApplVar.RGBuf[i].Key.Code>DEPT && ApplVar.RGBuf[i].Key.Code<DEPT+5000))
            break;
//		else
//			continue;
    }
    if (i==ApplVar.RGNumber)
        return;

    sSavePBn = ApplVar.PbNumber;

    if (/*ApplVar.AP.KeyTable[MAXKEYB-1]==0xffff && */TESTBIT(ApplVar.MyFlags, PRNONPB) && (ApplVar.PbF.Options & 0x0f) < 3)
    {
        RESETBIT(ApplVar.MyFlags, PRNONPB);
        keyno=1;
    }

    sFlags = ApplVar.MyFlags;
    RESETBIT(ApplVar.MyFlags, ENPRINTER);

    RFeed(1);
    sLine = 0;
    do
    {
        sGroup = 0xff;
        for (i=0;i<ApplVar.RGNumber;i++)
        {
            if (/*ApplVar.AP.KeyTable[MAXKEYB-1] == 0xffff && */ApplVar.RGBuf[i].Key.Code > PBF && ApplVar.RGBuf[i].Key.Code < (PBF + 100))   /* pb function */
            {
                ApplVar.PbFNumber = ApplVar.RGBuf[i].Key.Code - PBF - 1;
                ReadPbF();
                switch (ApplVar.PbF.Options & 0x0f)
                {
                case 0:
                case 1:
                    ApplVar.PbNumber = *((WORD *) ApplVar.RGBuf[i].Qty.Value);
                    break;
                }
            }

            if (sGroup==0xff && ApplVar.RGBuf[i].Group!=0xff &&
                (ApplVar.RGBuf[i].Key.Code>PLU1 && ApplVar.RGBuf[i].Key.Code<PLU3 ||
                 ApplVar.RGBuf[i].Key.Code>DEPT && ApplVar.RGBuf[i].Key.Code<DEPT+5000)
               )
            {
                sGroup = ApplVar.RGBuf[i].Group;
                ApplVar.GroupNumber = sGroup;
                ReadGroup();
                ApplVar.Group.Name[ApplVar.AP.Group.CapSize] = 0;
                if (!sLine)
                {
                    if (!keyno)
                    {
                        RFeed(4);
                        for (j = 0; j < PREHEADER; j++)
                        {//Ԥ��ӡƱͷ
                            if (ApplVar.TXT.Header[j][0])
                                PrintStr_Center(ApplVar.TXT.Header[j],DBLHIPRN & BIT3);
                            else
                                break;
                        }

                        RFeed(PREHEADER-j);
                    }
#if (PRESSENTER)
                    PutsO("NEXT");
                    for (;;)
                    {
                        while (!KbHit()) FM_EJ_Exist();
                        if (Getch()==ApplVar.AP.FirmKeys[ID_PRGENTER])
                            break;
                    }
#endif
                    if (!keyno)
                    {
                        if (j>=PREHEADER)
                            for (j = PREHEADER; j < 8; j++)
                            {//Ԥ��ӡƱͷ
                                if (ApplVar.TXT.Header[j][0])
                                    PrintStr_Center(ApplVar.TXT.Header[j],DBLHIPRN & BIT3);
                                else
                                    break;
                            }
                    }
                    keyno = 0;
                    sLine = 1;
                }
                if (ApplVar.PbNumber)//ccr20110916 && ApplVar.AP.KeyTable[MAXKEYB-1] == 0xffff && )
                {
                    memcpy(SysBuf,&ApplVar.PB,sizeof(ApplVar.PB));//ccr20110916 save the ApplVar.PB
                    memset(ProgLineMes,' ',PRTLEN);
                    CopyFrStr(ProgLineMes,ApplVar.Group.Name);

                    PbTotal(ApplVar.PbNumber, 0);   /* read new for ApplVar.PB text */
                    if (ApplVar.AP.Pb.Text && ApplVar.PB.Text[0])//ccr20110913
                        memcpy(ProgLineMes+PRTLEN/2, ApplVar.PB.Text, ApplVar.AP.Pb.Text);
                    else if (ApplVar.AP.Pb.Random & 0x0f)
                        HEXtoASC(ProgLineMes+PRTLEN/2,ApplVar.PB.Random,7);
                    else
                    {
                        CopyFrStr(ProgLineMes+PRTLEN/2,Msg[ZHUOTAI].str);
                        WORDtoASC(ProgLineMes+PRTLEN-3,ApplVar.PbNumber);
                    }
                    memcpy(&ApplVar.PB,SysBuf,sizeof(ApplVar.PB));//ccr20110916 save the ApplVar.PB

                    ProgLineMes[PRTLEN]=0;
                    PrintStr(ProgLineMes);
                }
                else
                    PrintStr(ApplVar.Group.Name);
            }
            if (sGroup!=0xff && ApplVar.RGBuf[i].Group==sGroup &&
                (ApplVar.RGBuf[i].Key.Code>PLU1 && ApplVar.RGBuf[i].Key.Code<PLU3 ||
                 ApplVar.RGBuf[i].Key.Code>DEPT && ApplVar.RGBuf[i].Key.Code<DEPT+5000)
               )//it must be the PLU or DEPT record
            {
                if (CheckNotZero(&ApplVar.RGBuf[i].Qty))//Must not be the cancel record
                {
                    memset(ProgLineMes,' ',sizeof(ProgLineMes));
                    if (ApplVar.RGBuf[i].Key.Code>PLU1 && ApplVar.RGBuf[i].Key.Code<PLU3)
                    {
                        ApplVar.PluNumber = ApplVar.RGBuf[i].Key.Code - PLU1 - 1;
                        ReadPlu();

                        strcpy(ProgLineMes+ALLPRNPOS,ApplVar.Plu.Name);
                        if (ProgLineMes[ALLPRNPOS]=='@')
                        {
                            ProgLineMes[ALLPRNPOS] = ' ';
                            ProgLineMes[0] = '@';
                        }
                    }
                    else
                    {
                        ApplVar.DeptNumber = ApplVar.RGBuf[i].Key.Code - DEPT - 1;
                        ReadDept();

                        strcpy(ProgLineMes+ALLPRNPOS,ApplVar.Dept.Name);
                        if (ProgLineMes[ALLPRNPOS]=='@')
                        {
                            ProgLineMes[ALLPRNPOS] = ' ';
                            ProgLineMes[0] = '@';
                        }
                    }
#if (PRNAMTON)
                    sAmt = ApplVar.RGBuf[i].Amt;
                    Multiply(&sAmt, &ApplVar.RGBuf[i].Qty);
                    RoundBcd(&sAmt, 0);
                    RJPrint(0,FormatStrQtyPriAmt(ProgLineMes, &ApplVar.RGBuf[i].Qty, 0, &sAmt, PRTLEN));
#else
                    RJPrint(0,FormatQtyStr(ProgLineMes,&ApplVar.RGBuf[i].Qty,PRTLEN));
#endif
                }
                ApplVar.RGBuf[i].Group = 0xff;
                // liu Yiqun added  start 20040210
                if (ApplVar.RGBuf[i+1].Key.Code>MODI && ApplVar.RGBuf[i+1].Key.Code< MODI + 1000)
                {
                    ApplVar.ModiCount = ApplVar.RGBuf[i+1].Key.Code - MODI;
                    memcpy(ApplVar.ModNum, &ApplVar.RGBuf[i+1].Qty, sizeof(ApplVar.ModNum));
                    for (j=0;j<ApplVar.ModiCount;j++)
                    {
                        ApplVar.ModiNumber = ApplVar.ModNum[j];
                        ReadModi();
                        MemSet(SysBuf, sizeof(SysBuf), ' ');
                        strcpy(SysBuf + ALLPRNPOS, ApplVar.Modi.Name);
                        if (SysBuf[ALLPRNPOS]=='@')
                        {
                            SysBuf[ALLPRNPOS] = ' ';
                            SysBuf[0] = '@';
                        }
                        PrintStr(SysBuf);
                    }
                    ApplVar.ModiCount = 0;
                    memset(ApplVar.ModNum, 0, sizeof(ApplVar.ModNum));
                    i++;
                }
                // liu Yiqun added  end 20040210
            }
        }
//Lyq added for header and tailer of tallons 2003\11\18 start
        if (TESTBIT(DOT,BIT4) && sLine)
        {
            PrintLine('-');
            PrintRegiInfo(FALSE);
            RFeed(1);
            PrintLine('-');
            sLine = 0;
        }
    }while (sGroup!=0xff);

    if (sLine)
    {
        if (!TESTBIT(DOT,BIT4))
        {
            PrintLine('-');
            PrintRegiInfo(FALSE);
            RFeed(1);
        }
        if ( RJPRN )
            ApplVar.PrintLayOut = 0 ;
        else if (TESTBIT(AM_PM, BIT3))          /* Double Heigth Trailer ? */
            ApplVar.PrintLayOut = 0x06;
        else
            ApplVar.PrintLayOut = 0x02;
        if (ApplVar.BufKp != 2 && (ApplVar.TXT.Trailer[0][0]))
        {
            RFeed(1);
            for (i = 0; (i < 6) && ApplVar.TXT.Trailer[i][0]; i++)
            {
                PrintStr_Center(ApplVar.TXT.Trailer[i],DBLHIPRN & BIT4);
            }
        }
    }
    ApplVar.MyFlags = sFlags;
    ApplVar.PbNumber =sSavePBn;
#if (PRESSENTER)
    ClearEntry();
    PutsO(EntryBuffer+sizeof(EntryBuffer)-DISLEN - 1);
#endif
}

