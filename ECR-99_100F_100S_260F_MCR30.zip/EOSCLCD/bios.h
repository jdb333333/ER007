/************************************************************************
*																		*
*	file name	: bios.h :definition of CONSTants for BIOS				*
*																		*
*																		*
************************************************************************/
#ifndef BIOS_H
#define BIOS_H

#include "bios_dir.h"	//direttive di compilazione del BIOS

// Definizione di alcune costanti che indicano "limiti"


// Definzioni di costanti varie
#ifndef TRUE
#define TRUE	1
#endif

#ifndef FALSE
#define FALSE   0
#endif

#ifndef true
#define true	1
#endif

#ifndef false
#define false   0
#endif

//    ==========================================================================
//    Devices CONSTants
//    ==========================================================================

#define	LN_LCDM		12	//    Lungh della riga di dislplay-module Slave-0 / 1
#define LN_LEDLCDM    1   //    PenGH
#define LN_FIP		12	//    Lunghezza totale del FIP
#define LN_FIPB		16	//    unghezza dei buffers per fip

#if DD_EPSON
 #define PRTLEN	24	//Dimensione riga di stampa in caratteri
#endif

#if DD_S2242
 #define PRTLEN	36	//Dimensione riga di stampa in caratteri
#endif

#if (DD_S2342 || CASE_PT723F_RJ)
 #define PRTLEN	20	//Dimensione riga di stampa in caratteri
#endif

#if DD_SF247
 #define PRTLEN	36	//Dimensione riga di stampa in caratteri
#endif

#if (DD_SF347 || DD_SF347F || DD_MT532)	// liuj 0827

#if (SF347_58MM)
 #define PRTLEN	32		//Dimensione riga di stampa in caratteri
#else
 #define PRTLEN	48		//Dimensione riga di stampa in caratteri
#endif

#endif


#if DD_CP290
 #define PRTLEN	36	//Dimensione riga di stampa in caratteri
#endif

#if (DD_S1245 || DD_Z245 || DD_Z245_RJ)
 #define PRTLEN	32	//Dimensione riga di stampa in caratteri
#endif


#ifndef PRTLEN
 #error "PRTLEN non definita !!!!"
#endif
//    ---------------------------------------------------------------------------


//    --------------------------------------------------------
//    CONSTants for KEYBOARD
//    --------------------------------------------------------

#define KEY_MAXROW	8	//    Numero max di righe gestite dallo slave
#define KEY_MAXCOL	8	//    Numero max di colonne gestite dallo slave
#define KEY_MAXKEYS	64	//    Max numero di tasti possibili (incroci riga/colonna)
//    ---------------------------------------------------------------------------


//     Bit Definition della double-word di stato stampanti (PRN_Status)
//     ---------------------------------------------------------------
//     NOTA : 2 bytes totali
//
#define	B_PS_RPE		0	//    bit 0 : fine carta scontrino
#define	B_PS_JPE		1	//    bit 1 : fine carta jornale
#define	B_PS_RHUP		2	//    bit 2 : testa scontrino fuori posto
#define	B_PS_JHUP		3	//    bit 3 : testa jornale fuori posto
#define	B_PS_RTOOR		4	//    bit 4 : temperatura testa scontrino fuori range
#define	B_PS_JTOOR		5	//    bit 5 : temperatura testa giornale fuori range
#define	B_PS_24V		6	//    bit 6 : Head Power non OK
#define	B_PS_PWFL		7	//    bit 7 : Power fail in stampa
#define	B_PS_CUTTER		8	//    bit 8 : Taglierina bloccata
#define	B_PS_BURN		13	//    bit 14: in atto fase di stampa eff. (strobe)
#define	B_PS_MOTOR		14	//    bit 14: motore attivo
#define	B_PS_PBUSY		15	//    bit 15: comando in esecuzione
//    ------------------
#define MK_NOPAPER	((1 << B_PS_RPE))//     | (1 << B_PS_JPE))

#define MK_PRERR		((1 << B_PS_RPE) | (1 << B_PS_RTOOR) | (1 << B_PS_24V))
#define MK_PRERRG		(MK_PRERR | (1 << B_PS_PWFL))

/////////// bit Command of print:ApplVar.Prn_Command ///////////////////////////////////////
#define PRN_DBLW_Mode        BIT0    //double with print mode for text
#define PRN_DBLH_Mode        BIT1    //double high print mode for text
#define PRN_RECEIPT_Mode     BIT2    //print on receipt printer
#define PRN_STUB_Mode        BIT3    //print on stub printer
#define PRN_GRAPHIC_Mode     BIT4    //print a graphic
#define PRN_CUTF_Mode        BIT5    //Cut paper full
#define PRN_CUTH_Mode        BIT6    //Cut paper half
#define PRN_CUTRESET_Mode    BIT7    //reset cutter

//
//     Definizione flags di stampa contenute in PRN_FlagI
//     --------------------------------------------------
//
#define	B_PRI_DBLH			1	//    PRN_DBLH_Mode
#define	B_PRI_RON			2	//    PRN_RECEIPT_Mode
#define	B_PRI_JON			3	//    PRN_STUB_Mode
#define	B_PRI_GRAF			4	//    PRN_GRAPHIC_Mode
#define	B_PRI_FCUT			5	//    PRN_CUTF_Mode
#define	B_PRI_PCUT			6	//    PRN_CUTH_Mode

//======================================================================
// EQU comandi di stampa :
//======================================================================

#define	CMDP_RJ		((1 << B_PRI_RON) | (1 << B_PRI_JON))//     Stampa normale R+J
#define	CMDP_R		((1 << B_PRI_RON))// Stampa normale solo R :
#define	CMDP_J		((1 << B_PRI_JON))// Stampa normale solo J :
#define	CMDP_DRJ	((1 << B_PRI_RON) | (1 << B_PRI_JON) | (1 << B_PRI_DBLH))// Stampa doppia altezza R+J :
#define	CMDP_DR		((1 << B_PRI_RON) | (1 << B_PRI_DBLH))// Stampa doppia altezza solo R :
#define	CMDP_DJ		((1 << B_PRI_JON) | (1 << B_PRI_DBLH))// Stampa doppia altezza solo J :
#define	CMDP_LFRJ	((1 << B_PRI_RON) | (1 << B_PRI_JON))// Stampa line feed R+J :
#define	CMDP_LFR	((1 << B_PRI_RON))// Stampa line feed solo R :
#define	CMDP_LFJ	((1 << B_PRI_JON))// Stampa line feed solo J :
#define	CMDP_PRGRA	((1 << B_PRI_RON) | (1 << B_PRI_GRAF))// Stampa dot-line grafica solo R :
#define	CMDP_RFEED	((1 << B_PRI_RON))// Speciale per avanzamento carta  R :
#define	CMDP_JFEED	((1 << B_PRI_JON))// Speciale per avanzamento carta  J :

// =========================================================================
// Definizione dei comandi peri il BIOS
// =========================================================================

#define BiosCmd_OutLM0A		1	//Slave-0, Output to LCDM Up row
#define BiosCmd_OutLM0B		5	//Slave-0, Output to LCDM Down row
#define BiosCmd_ZeroLM0B	8	//Slave-0, Output "0" to LCDM down row

#define BiosCmd_ClrFip0		15	//Slave 0, Blank FIP
#define BiosCmd_ZeroFip0	16	//Slave 0, Output "0" to FIP
#define BiosCmd_PopFip0		17	//Slave 0, Output to FIP, PopUp mode

#define BiosCmd_SaveDisp0	18	//Slave 0, Salva display per PopUp
#define BiosCmd_RestDisp0	19	//Slave 0, Restore display dopo PopUp

#define BiosCmd_KeyReset	20	//Slave-0, Reset buffer tastiera, annulanndo eventuali tasti esistenti
#define BiosCmd_KeyOff		21	//Slave-0, Disable Keyboard
#define BiosCmd_KeyOn		22	//Slave-0, Enable Keyboard
#define BiosCmd_AutoClickOff 23	//Slave-0, Disable AutoClick
#define BiosCmd_AutoClickOn	24	//Slave-0, Enable AutoClick
#define BiosCmd_BuzzS		25	//Slave-0, Buzzer short
#define BiosCmd_BuzzM		26	//Slave-0, Buzzer medium
#define BiosCmd_BuzzL		27	//Slave-0, Buzzer long
#define BiosCmd_BuzzOff		28	//Slave-0, Buzzer off
#define BiosCmd_CheckKeyborad		29	//Slave-0, Read keyboard

#define BiosCmd_PopLM1A	30	//Slave-1, Output to LCDM Up row, PopUp mode
#define BiosCmd_OutLM1A		31	//Slave-1, Output to LCDM Up row
#define BiosCmd_RefrLM1A	32	//Slave-1, Re-display LCDM Up row buffer
#define BiosCmd_ClrLM1A		33	//Slave-1, Clear and Re-display LCDM Up row buffer
#define BiosCmd_PopLM1B	34	//Slave-1, Output to LCDM Down row, PopUp mode
#define BiosCmd_OutLM1B		35	//Slave-1, Output to LCDM Down row
#define BiosCmd_RefrLM1B	36	//Slave-1, Re-display LCDM Down row buffer
#define BiosCmd_ClrLM1B		37	//Slave-1, Clear and Re-display LCDM down row buffer
#define BiosCmd_ZeroLM1B	38	//Slave-1, Output "0" to LCDM down row

#define BiosCmd_FlagFip1		39	//Slave-1, Attiva/Disattiva  Blink/Punto/Caption sui digits del fip
#define BiosCmd_WrFlafFip1	40	//Slave-1, Trasmette allo slave il buffer flags_fip
#define BiosCmd_RdFlafFip1	41	//Slave-1, Legge dallo slave il buffer flags_fip
#define BiosCmd_Out1Fip1	42	//Slave-1, Carica solo un determinato digit sul fip
#define BiosCmd_OutFip1		43	//Slave 1, Output to FIP
#define BiosCmd_RefrFip1		44	//Slave 1, Refresh FIP Buffer
#define BiosCmd_ClrFip1		45	//Slave 1, Blank FIP
#define BiosCmd_ZeroFip1	46	//Slave 1, Output "0" to FIP
#define BiosCmd_PopFip1		47	//Slave 1, Output to FIP, PopUp mode

#define BiosCmd_SaveDisp1	48	//Slave 1, Salva display per PopUp
#define BiosCmd_RestDisp1	49	//Slave 1, Restore display dopo PopUp

//ccr 040526 for chipcard
#define BiosCmd_CC_Open      50
#define BiosCmd_CC_Close     51
#define BiosCmd_CC_Read      52
#define BiosCmd_CC_Compare   53
#define BiosCmd_CC_Write     54
#define BiosCmd_CC_VerifyPsw 55
#define BiosCmd_CC_WritePsw  56

#define BiosCmd_PrintRestart 60	//    Riattiva/Abort processo di stampa
#define	BiosCmd_PrintCheck	61	//    Torna stato corrente sensori stampanti
#define BiosCmd_PrintWaitEnd 62	//    Attende stampanti RJ a riposo
#define BiosCmd_ResetCutter	63	//    Sblocca la taglierina
#define BiosCmd_PrintGraph	68	//    Comando di stampa di un disegno
#define BiosCmd_PrintDirect	69	//    Comando di stampa diretti, con attesa fine
#define BiosCmd_PrintX		70	//    Comando di stampa R2=opz.stampa  R3=#dot-line blank post extra


#define BiosCmd_GetDate		80	//    RTC: read date
#define BiosCmd_GetTime		81	//    RTC: read time
#define BiosCmd_SetDate		82	//    RTC: set date
#define BiosCmd_SetTime		83	//    RTC: set time
#define BiosCmd_RtcInit		84	//    RTC: init

#define BiosCmd_Refresh		85	//    Refresh
#define	BiosCmd_ScannerOn	86	//    Abilita lo scanner, se questo esiste su una porta
#define	BiosCmd_ScannerOff	87	//    Disabilita lo scanner, se questo esiste su una porta

#define BiosCmd_CheckBattery 88 //     Low Battery
//    -----------------------------------------------------------------------------------

//     define Comandi per l'MMC :
//     --------------------------

#define	BiosCmd_SD_Init		92	//    Inizializza MMC
#define	BiosCmd_SD_ReadBlock	93	//    Raead block
#define	BiosCmd_SD_ReadInfo		94	//    Read CID/CSD/PROT/STATUS
#define	BiosCmd_SD_WriteBlock	95	//    Write block
#define	BiosCmd_SD_WriteInfo	96	//    Wite CID/CSD/ ecc
#define	BiosCmd_SD_Erase			97	//    Erase groups
#define	BiosCmd_SD_Protect		98	//    Protect group
#define	BiosCmd_SD_UnProtect	99	//    UnProtect group
#define	BiosCmd_SD_ReadProtMask 100	//    Legge mask protezione gruppi
#define BiosCmd_SD_CheckPresence   101 //    cc 20060426????????????????


//////////////////////////////////////////////////////////////////

#define BIOS_TICMS	5		//Valore in millisecondi del TIC base (timer A0)


extern WORD Bios(WORD cmd, VOIDFAR *ptr, WORD par1, WORD par2);	//Accesso al Bios

extern WORD Bios_1(WORD cmd);										//Accesso al Bios

extern WORD Bios_2(WORD cmd, VOIDFAR *ptr);						//Accesso al Bios

#if (CASE_MFRIC==1)
#define CC_Open(BuffATR) (1)
#define CC_Close() mifs_halt()
#else
//ccr 040526 for chipcard
#define CC_Open(BuffATR) Bios_2(BiosCmd_CC_Open, BuffATR)
#define CC_Close() Bios_1(BiosCmd_CC_Close)
#define CC_Read(Dest, ChipAdr, NumBytes) Bios(BiosCmd_CC_Read,Dest, ChipAdr, NumBytes)
#define CC_Compare(Source, ChipAdr,NumBytes)  Bios(BiosCmd_CC_Compare, Source, ChipAdr,NumBytes)
#define CC_Write(Source, ChipAdr,NumBytes)  Bios(BiosCmd_CC_Write,Source, ChipAdr,NumBytes)
#define CC_VerifyPWD(Password) Bios_2(BiosCmd_CC_VerifyPsw, Password)
#define CC_WritePWD(Password) Bios_2(BiosCmd_CC_WritePsw,Password)
#endif

//cc 2006-07-03 for MMC>>>>>>>>>>>>>>>>>>>>>>>>>>>

#if(DD_MMC && defined(DEBUGBYPC))
#define MMC_ReadBlock(buf,addr) 	Bios(BiosCmd_SD_ReadBlock, buf,(WORD)addr,  (addr)>>16)
#define MMC_WriteBlock(buf,addr) Bios(BiosCmd_SD_WriteBlock, buf,(WORD)addr,  (addr)>>16)

//ccr070718 #define MMC_CheckPresence() Bios(BiosCmd_SD_CheckPresence, 0, 0, 0)
#endif
//
// Torna : 1 = OK
//         0 = NON-OK (errore in Bios_LastError)
//
#if defined(DEBUGBYPC)
extern WORD Bios_FM_Read(void *Dest, unsigned long SrcAdr, WORD Num);
extern void FM_AllErase(void);									/* bios_fm.i30 */
extern WORD Bios_FM_Write(unsigned long DestAdr, VOIDFAR *Src, WORD Num);
#else
//��˰�ش洢��FM�ĵ�ַDestAdrд��Num�ֽڵ�����,,���ز������״̬
#define Bios_FM_Write(DestAdr, Src, Num) FiscalMem_WriteBuffer((BYTE*)Src,DestAdr, Num)

//��˰�ش洢��FM�ĵ�ַDestAdr��ȡNum�ֽڵ�����,���ز������״̬
#define Bios_FM_Read(Dest, SrcAdr, Num)	FiscalMem_ReadBuffer((BYTE*)Dest, SrcAdr, Num)


//����˰�ش洢��
#define  FM_AllErase() FiscalMem_EraseBulk()
#endif

#if defined(FISCAL)
 extern BYTE Bios_FM_CheckPresence(void);						/* bios_fm.i30 */
#endif


// Bios_PortWrite() :
// trasmette NumBytes bytes a partire da *TxData sulla porta NumCom
// Flags :  bit 0 : 0=non attende completamento   1 = attende completamento
//
// Torna : 1 = OK
//      0 = NON-OK (errore in Bios_LastError)
//
extern WORD Bios_PortWrite(BYTE NumCom, BYTE *TxData, WORD NumBytes, BYTE Flags);

// Bios_PortRead() :
//  Ricezione dalla porta NumCom
//  NumBytes : 0 = torna bytes pendenti/Status senza leggere
//            >0 = leggi max NumBytes caratteri con time-out TimeOut(unit\xE0 5 millisecondi)
//            <0 = leggi tutti i caratteri pendenti
//
// Torna : Numero di bytes letti (o pendenti se NumBytes=0)
//         *Status  =  bit-flags per gestione errori :
//                     bit 15 : 1 = uno o pi\xF9 errori presenti
//                     bit 14 : 1 = parity error
//                     bit 13 : 1 = frame error
//                     bit 12 : 1 = overrun error
//                     bit 11 : 1 = overflow su buffer interno di ricezione
//                     bit 10 : 1 = superato time-out
//                     bit 9  : 1 = avvenito power-fail durante la ricezione

extern short Bios_PortRead(BYTE NumCom, void *Dest, short NumBytes, ULONG TimeOut, WORD *Status);



// Funzioni BIOS per SET/GET di propieta varie:
// --------------------------------------------
//
// Bios_SetKeyboard : Setta la tastiera in uso
extern WORD Bios_SetKeyboard(BYTE Code, WORD NumKeys, CONSTBYTE *TabPnt, BYTE TabRecLen);


// Bios_SetCutter : Ailita/disabilita la taglierina
extern WORD Bios_SetCutter(BYTE Stato);

// Bios_SetPortBusy() : Attiva/Disattiva speciale modalit\xE0 "busy"
//Ccr // Bios_SetPortBusy() : Attiva/Disattiva speciale modalit?"busy"
//   Stato : 0 = disattiva modo busy    1=attiva modo busy
//   ChrRx : codice ascii del carattere da filtrare (ENQ)
//   ChrTx : codice ascii del carattere da trasmettere in risposta
//
// Torna : 1 = OK
//         0 = NON-OK (errore in Bios_LastError)
//
extern WORD Bios_SetPortBusy(BYTE NumCom, BYTE Satato, BYTE ChrRx, BYTE ChrTx);

// Bios_TestMAC() : Torna TRUE se MAC-Switch presente
//
extern WORD Bios_TestMAC(void);

// =============================================================================
// Riferimenti alle variabili del bios
// =============================================================================


extern WORD Bios_PRN_Status;		//    Stato stampanti interne

extern WORD Bios_LastError;			//    BIOS Error-Code (vedi lista codici di errore)

extern DATE_BCD rtc_date;			//    buffer per get/set data corrente
extern TIME_BCD rtc_time;			//    buffer per get/set orario corrente

extern BYTE Bios_Key0_Key;			//    key number: 00 = No key
									//                FF = Invalid Key
extern BYTE Bios_Key0_Scan;			//    key normalized scan-code
extern BYTE Bios_Key0_SW1;			//    key switches-1
extern BYTE Bios_Key0_SW2;			//    key switches-2

extern DATE_BCD _rtc_date;			//    BCD Buffer read/write for date (DD-MM-YY-WW)
extern TIME_BCD _rtc_time;			//    BCD Buffer read/write for time (HH-MM-SS-xx)

extern BYTE	PWFL_FlgOk,RESET_Flag;

//====================================================================
#if (DD_LCD_1601==1 && !defined(DEBUGBYPC))
extern void LightLCD(BYTE OnOff);
#else
#define  LightLCD(OnOff) {}
#endif

//    ------------------------------------------------------------------------------

// =============================================================================
// Codici di errori del BIOS (Passati nella variabile Bios_LastError)
// =============================================================================
//
//
#define BIOSERR_NO_COM		 	0x0001			//la porta seriale specificata non esiste
#define BIOSERR_COM_NOTSET	0x0002			//la porta seriale non e' configurata
#define BIOSERR_COM_CONF	 	0x0003			//parametri configurazione porta seriale errati
#define BIOSERR_COM_NOTON	 	0x0004			//porta non aperta / disabilitata

#define BIOSERR_COM_SIZE		0x0005

//ccr040526 for chipcard
#define BIOSERR_CC_NOCARD	    0x0006
#define BIOSERR_CC_UNSUPP     0x0007
#define BIOSERR_CC_PSW        0x0008
#define BIOSERR_CC_TMOUT      0x0009
#define BIOSERR_CC_COMPARE    0x000a


// ----------------------------------------------------------------------------


//void EraseChip(unsigned long toA1A0);	//cc 20071026

void EraseSector(CONSTCHAR *SectorA1A0);


extern WORD CC_Insert(void);	//ccr040526 chipcard


// define Comandi per l'MMC :
// --------------------------

#define	MMC_GO_IDLE_STATE				0x40	//CMD00 = 0x00
#define	MMC_SEND_OP_COND				0x41	//CMD01 = 0x01
#define	MMC_ALL_SEND_CID     			0x42	//CMD02
#define	MMC_SET_RELATIVE_ADDR		0x43    //CMD03
#define	MMC_SET_DSR          			0x44    //CMD04
#define	MMC_SELECT_DESELECT_CARD		0x47    //CMD07
#define	MMC_SEND_CSD					0x49    //CMD09
#define	MMC_SEND_CID					0x4a    //CMD10
#define	MMC_READ_DAT_UNTIL_STOP		0x4b    //CMD11
#define	MMC_STOP_TRANSMISSION		0x4c    //CMD12
#define	MMC_SEND_STATUS        		0x4d    //CMD13
#define	MMC_SET_BUS_WIDTH_REGISTER  0x4e    //CMD14
#define	MMC_GO_INACTIVE_STATE    	0x4f    //CMD15
#define	MMC_SET_BLOCKLEN          	0x50    //CMD16
#define	MMC_READ_BLOCK            	0x51    //CMD17
#define	MMC_READ_MULTIPLE_BLOCK  	0x52    //CMD18
#define	MMC_WRITE_DAT_UNTIL_STOP 	0x54    //CMD20
#define	MMC_WRITE_BLOCK           	0x58    //CMD24
#define	MMC_WRITE_MULTIPLE_BLOCK 	0x59    //CMD25
#define	MMC_PROGRAM_CID           	0x5a    //CMD26
#define	MMC_PROGRAM_CSD           	0x5b    //CMD27
#define	MMC_SET_WRITE_PROT        	0x5c    //CMD28
#define	MMC_CLR_WRITE_PROT        	0x5d    //CMD29
#define	MMC_SEND_WRITE_PROT       	0x5e    //CMD30
#define	MMC_TAG_SECTOR_START      	0x60    //CMD32
#define	MMC_TAG_SECTOR_END        	0x61    //CMD33
#define	MMC_UNTAG_SECTOR           	0x62    //CMD34
#define	MMC_TAG_ERASE_GROUP_START 	0x63    //CMD35
#define	MMC_TAG_ERASE_GROUP_END   	0x64    //CMD36
#define	MMC_UNTAG_ERASE_GROUP     	0x65    //CMD37
#define	MMC_ERASE_SECTORS         	0x66    //CMD38
#define	MMC_READ_OCR					0x7A	//CMD58
#define	MMC_CRC_ON_OFF				0x7B	//CMD59
///////////////////////////////////////////////////////////////////////////
#define TIMER_INTERVAL 	500

/** @addtogroup USBD_USER
  * @{
  */
#define USB_NONE        0   //ccr USB�����豸
#define USB_DISK        1   //ccr USB��Ϊ��
#define USB_KEYBOARD    2   //ccr USB��Ϊ����,����ǹ

#endif
