#define PROGDUMP_C
#include "king.h"				/* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"


//liuj 0606
void DumpDept()
{
BCD bcdtemp;
	if(ApplVar.ProgNumber >=0  )
        {

	ApplVar.DeptNumber = ApplVar.ProgNumber;
	if(ApplVar.DeptNumber > ApplVar.AP.Dept.Number)
		return ;
	ReadDept();

	memset(SysBuf,' ',sizeof(SysBuf));
#if DD_ZIP
	CopyFrStr(SysBuf, Prompt.LineCap[Line_DEPART]);
	WORDtoASC(SysBuf + 15, ApplVar.ProgNumber + 1);
	SysBuf[12]='#';

#else
	CopyFrStr(SysBuf, Prompt.LineCap[Line_DEPART]);
	WORDtoASC(SysBuf + 8, ApplVar.ProgNumber + 1);
	SysBuf[6]='#';

#endif
	RJPrint(0, SysBuf);

	RJPrint(0, ApplVar.Dept.Name);

	memset(SysBuf,' ',sizeof(SysBuf));
	bcdtemp = ZERO;
	CopyFrStr(SysBuf, Prompt.Caption[4]);
	memcpy(bcdtemp.Value, ApplVar.Dept.Price,5);
	FormatAmt(SysBuf+18, &bcdtemp);
	RJPrint(0, SysBuf);

	memset(SysBuf,' ',sizeof(SysBuf));
	bcdtemp = ZERO;
	CopyFrStr(SysBuf+1, Prompt.LineCap[Line_MAX]);

	memcpy(bcdtemp.Value, ApplVar.Dept.PriceMax,5);
	FormatAmt(SysBuf+18, &bcdtemp);
	RJPrint(0, SysBuf);


	memset(SysBuf,' ',sizeof(SysBuf));
	CopyFrStr(SysBuf, Prompt.Caption[27]);
	OptionToStr(ApplVar.Dept.Tax,SysBuf+8);

	RJPrint(0,SysBuf);

	memset(SysBuf,' ',sizeof(SysBuf));
	CopyFrStr(SysBuf+1, Prompt.Caption[50]);
	OptionToStr(ApplVar.Dept.Options,SysBuf+8);

	RJPrint(0,SysBuf);

	RFeed(1);

	}

}

void DumpTax()
{
BCD bcdtemp;
BYTE i;

	for(i=0;i<ApplVar.AP.Tax.Number;i++)
		{
			ApplVar.TaxNumber = i;
			ReadTax();

			memset(SysBuf,' ',sizeof(SysBuf));
			CopyFrStr(SysBuf, Prompt.Caption[27]);
			WORDtoASC(SysBuf + 8, i + 1);
			SysBuf[6]='#';
			RJPrint(0, SysBuf);

			RJPrint(0, ApplVar.Tax.Name);

			memset(SysBuf,' ',sizeof(SysBuf));
			bcdtemp = ZERO;
			CopyFrStr(SysBuf+1, Prompt.LineCap[Line_TAXRATE]);
			memcpy(bcdtemp.Value, ApplVar.Tax.Rate,3);
			FormatAmt(SysBuf+18, &bcdtemp);
			RJPrint(0, SysBuf);


			memset(SysBuf,' ',sizeof(SysBuf));
			CopyFrStr(SysBuf+1, Prompt.Caption[50]);
			OptionToStr(ApplVar.Tax.Options,SysBuf+10);

			RJPrint(0,SysBuf);
			RFeed(1);
		}


}

//liuj 0606

#if (DD_FISPRINTER==0)

void ProgramDump()
{
	BYTE s_type;
	WORD s_number;

	if (ProgType == SETKEYB && ProgType == SETKEYMASK)  /* don't print keyboard */
		return;
	if (!ProgStart) /* dump all */
	{
		ApplVar.ProgNumber = 0;
		ApplVar.NumberEntry = 0xffff;
	}
	ProgLine = 1;
	ApplVar.PrintLayOut = 0x02;
	ProgStart = 2;      /* indicate program dump */
	Appl_EntryCounter = 0;
	s_number = ApplVar.ProgNumber;
	s_type = ProgType;
/*	if (ApplVar.NumberEntry)   //liuj 0531 PM
		ApplVar.NumberEntry--;
	else   */
		ApplVar.NumberEntry = ApplVar.ProgNumber;

    while(ApplVar.ProgNumber == ApplVar.NumberEntry)	//liuj 0601
	{
		if (DisplayOption() && !ApplVar.ErrorNumber)
		{
		  	if (ApplVar.ProgNumber > ApplVar.NumberEntry && (ApplVar.NumberEntry > 0))        //liuj 0603
				break;
			if (ProgLine > 1)
			{
				MemSet(SysBuf, 6, ' ');
				memcpy(SysBuf + 6, ProgLineMes, sizeof(ProgLineMes));
#if DD_ZIP == 1
				memcpy(SysBuf + 16, ProgLine1Mes, sizeof(ProgLine1Mes));
#endif
				PrintStr(SysBuf);
			}
			else
			{
				PrintStr(ProgLineMes);
				if (ProgType == SETPLU)      /* PLU ? */
				{
					if (ProgLine == 1 && ApplVar.AP.Plu.RandomSize) /* random number ?*/
					{
						SysBuf[0] = 'R';
						SysBuf[1] = ':';
						HEXtoASC(SysBuf+2, ApplVar.Plu.Random, ApplVar.AP.Plu.RandomSize);
						SysBuf[ApplVar.AP.Plu.RandomSize * 2 + 2] = 0;
						PrintStr(SysBuf);
					}
				}
			}
		}
		else
			break;
		if (ProgType == SETSYSFLAG)
			ApplVar.ProgNumber++;
		else
		{
			ProgLine++;
			BitNumber = 0;  // liuj 0602
		}
  		if (KbHit() && Getch() == ApplVar.AP.FirmKeys[ID_CLEAR])
			break;      /* clear key means break */
	}
	if(TESTBIT(ARROWS, BIT0))        /* receipt on ?*/
		RFeed(2);
	ProgStart = 1;
	ApplVar.ProgNumber = s_number;
	ProgType = s_type;
	ProgLine = 1;
	BitNumber = 0;
	ApplVar.ErrorNumber=0;

#if !defined(FISCAL)
	DisplayOption();
	PutsO(ProgLineMes);
#endif
	ClearLine2();	//
}
#endif
