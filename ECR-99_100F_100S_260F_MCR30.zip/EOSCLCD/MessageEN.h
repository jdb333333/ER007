#ifndef MESSAGEH
#define MESSAGEH


//>>>>>>>>>>>>>>>>>  Ʊͷ ENGLISH>>>>>>>>>>>>

#if (PRTLEN>45)                    /*	   12345678901234567890123 */
#define Header1		  "**********************************************"
#define Header2		  "   Thanks for Choosing Eutron Cash Register   "
#define Header3		  "**********************************************"

#elif (PRTLEN<25)
/*	                 12345678901234567890*/
#define Header1	 	"* SHOP LEGAL NAME  *"  //ZWQ
#define Header2	 	"*  SHOP  ADDRESS   *"
#define Header3	 	"*   TAX  ID CODE   *"//Ccr" 	 �� �� �� ��     �� �� �� ��   *"*/
#define Header4	 	"* --------------   *"//Ccr" 	 �� �� �� ��     �� �� �� ��   *"*/
#elif (PRTLEN<36)
              /*	 12345678901234567890123456789012*/
#define Header1	 	"*    SHOP REGISTERED NAME      *"
#define Header2	 	"*     SHOP LEGAL ADDRESS       *"
#define Header3	 	"*         TAX ID CODE          *"//Ccr" 	 �� �� �� ��     �� �� �� ��   *"*/
#define Header4	 	"*         --------------       *"//Ccr" 	 �� �� �� ��     �� �� �� ��   *"*/

#else
              /*	 12345678901234567890123456789012*/
#define Header1	 	"*    SHOP  REGISTERED NAME     *"
#define Header2	 	"*       SHOP LEGAL ADDRESS     *"
#define Header3	 	"*         TAX ID CODE          *"//Ccr" 	 �� �� �� ��     �� �� �� ��   *"*/
#define Header4	 	"*         --------------       *"//Ccr" 	 �� �� �� ��     �� �� �� ��   *"*/
#endif

//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


//>>>>>>>>>>>>>>   �������� ENGLISH   >>>>>>>>>>>>>>>>>>>

#define ReportType0     "  GRAND TOTAL   "        //"   ��  ��  ��   "
#define ReportType1     "  GROUP         "        //" ��  ��  ��  �� "//1
#define ReportType2     "  DEPARTMENT    "        //" ��  ��  ��  �� "//2
#define ReportType3     "  PLU           "        //" ��  Ʒ  ��  �� "      /* 3 Used with Plu Report */
#define ReportType4     "  TENDER        "        //" ��  ��  ��  Ϣ "//4
#define ReportType5     "  PORA          "        //" �� �� �� �� Ϣ "//5
#define ReportType6     "  DRAWER        "        //" Ǯ  ��  ��  Ϣ "//6
#define ReportType7     "  CORRECTION    "        //" ��  ��  ��  Ϣ "//7
#define ReportType8     "  DISCOUNT      "        //" ��  ��  ��  Ϣ "//8
#define ReportType9     "  CURRENCY      "        //" ��  ��  ��  Ϣ "//9
#define ReportType10    "  TAX           "        //" ��  ˰  ��  Ϣ "//10
#define ReportType11    " PB FUNCTIONS   "        //" ��  ��  ��  Ϣ "//11
#define ReportType12    "PREVIOUS BALANCE"        //" ��  ̨  ��  Ϣ "//12
#define ReportType13    "  TABLES        "        //" ��  ̨  ��  Ϣ "//13
#define ReportType14    "  INVENTORY     "        //" ��  Ʒ  ��  �� "//14
#define ReportType15    "  PB INVOICES   "	      // �������ָʲô? ZWQ û����
#define ReportType16    "  TENDER BUFFER "        // �������ָʲô? ZWQ û����
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


//>>>>>>>>>>>>>>>>  Ʊβ  ENGLISH  >>>>>>>>>>>>>>>>>>>>>

#if (PRTLEN<25)
#define 	Trailer1 	"WELCOME TO EUTRON" //Ccr 	"     ~��  ~л  ~��  ~��     "
#define 	Trailer2 	"    GOODBYE       " //Ccr 	"          ~��  ~��         "
#else
#if (defined(CASE_MALTA))
#define 	Trailer1 	"  THANK YOU FOR SHOPPING   "
#define 	Trailer2 	"    PLEASE VISIT AGAIN     "
#else
#define 	Trailer1 	"WELCOME TO EUTRON" //Ccr 	"     ~��  ~л  ~��  ~��     "
#define 	Trailer2 	"    GOODBYE       " //Ccr 	"          ~��  ~��         "
#endif
#endif
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


//>>>>>>>>>>>>>>>>>>>����Ŀ¼>>>>>>>>>>>>>>>>>>
#if (defined(CASE_MALTA))
#define ReportList1		"OPERATOR DAILY" //CCR" �� �� Ա �� �� "
#define ReportList2		"OPERATOR PERIOD" //CCR" �� �� Ա �� �� "
#define ReportList3		"DAILY REPORT" //CCR" ��  ��  ��  �� "
#define ReportList4		"PERIOD REPORT" //CCR" ��  ��  ��  �� "
#define ReportList5		"PLU REPORT" //CCR" ��  Ʒ  ��  �� "
#define ReportList6		"TABLE REPORT" //CCR" ��  ��  ��  �� "
#define ReportList7		"TIME ZONE" //CCR" ʱ  ��  ��  �� "
#define ReportList8		"ALL OPER. DAILY" //CCR"  ȫ�տ�Ա�ձ�  "
#define ReportList9	    "ALL OPER.PERIOD" //CCR"  ȫ�տ�Ա�ܱ�  "
#define ReportList10	"SALP. DAILY" /* Ӫ ҵ Ա �� �� */
#define ReportList11	"SALP. PERIOD"//CCRӪ ҵ Ա �� ��//
#define ReportList12	"ALL SALP.DAILY" //CCR"  ȫӪҵԱ�ձ�  "
#define ReportList13	"ALL SALP.PERIOD" //CCR"  ȫӪҵԱ�ܱ�  "
#else // ENGLISH
#define ReportList1     "OPERATOR DAILY"        //" �� �� Ա �� �� "
#define ReportList2     "OPERATOR WEEKLY"        //" �� �� Ա �� �� "
#define ReportList3     "DAILY REPORT "        //" ��  ��  ��  �� "
#define ReportList4     "WEEKLY REPORT "        //" ��  ��  ��  �� "
#define ReportList5     "PLU REPORT"        //" ��  Ʒ  ��  �� "
#define ReportList6     "TABLE REPORT"        //" ��  ��  ��  �� "
#define ReportList7     "TIME ZONE REPORT"        //" ʱ  ��  ��  �� "
#define ReportList8     "ALL-OPER. DAILY"        //"  ȫ�տ�Ա�ձ�  "
#define ReportList9     "ALL-OPER. WEEKLY"        //"  ȫ�տ�Ա�ܱ�  "
#define ReportList10    "SALESPER.DAILY "        //" Ӫ ҵ Ա �� �� "
#define ReportList11    "SALESPER. WEEKLY"        //" Ӫ ҵ Ա �� �� "
#define ReportList12    "ALL SALPR.DAILY"        //"  ȫӪҵԱ�ձ�  "
#define ReportList13    "ALL SALP. WEEKLY"        //"  ȫӪҵԱ�ܱ�  "
#endif
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

//>>>>>>>��  ~ϲ  ~��  ~��>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

#define Promotion1		"  CONGRATULATIONS!  "//		"  ~��  ~ϲ  ~��  ~��"
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


#define Correc1 					"VOID    " //Ccr 		{ PLAYOUT, 0x01, " ȡ��   "},
#define Correc2 					"CORRECT " //Ccr 		{ PLAYOUT, 0x00, "����    "},
#define Correc3 					"RETURN  " //Ccr 		{ PLAYOUT, 0x02, "�˻�    "},
#define Correc4 					"CANCEL  " /* "ȡ������" */
#if defined(CASE_MALTA)
#define CURRENCY1		  "Lm      "
#else
#define CURRENCY1	      "DOLLAR  "
#endif
#define CURRENCY2         "YEN     "  //"��Ԫ    "
#define CURRENCY3         "HK $    "  //"�۱�    "
#define CURRENCY4         "CURR   1"  //"���1   "
#define CURRENCY5         "CURR   2"  //"���2   "

#define DISCOUNT1         "(+%)SURC"  //"+%�ӳ�"
#define DISCOUNT2         "(-%)DISC"  //"(-%)�ۿ�"
#define DISCOUNT3         "NET SURC"  //"���ӳ�"		ZWQ
#define DISCOUNT4         "NET DISC"  //"����ۿ�"		ZWQ

#define DRAWER1           "CASH    "  //"�ֽ�    "
#define DRAWER2           "CHECK   "  //"֧Ʊ    "
#define DRAWER3           "C.CARD  "  //"���ÿ�  "
#define DRAWER4           "COUPON  "  //"����ȯ  "
#define DRAWER5           "CREDIT  "   //"����    "
#define DRAWER6           "CHIPCARD"  //"IC��    "
#define DRAWER7           "FEE     "  //"С��    "
#define DRAWER8           "DRAWER 8"  // "DRAWER 8"


#define PBFunction0       "OPEN    "  // "����"
#define PBFunction1       "ADD     "  // "��̨����"
#define PBFunction2       "SERVICE "  //  "�ݽ�"
#define PBFunction3       "CONFIRM "  //  "ȷ�Ͻ���"
#define PBFunction4       "PRINT   "  //   "��ӡ��̨"
#define PBFunction5       "PRT BILL"  //   "��ӡ�ʵ�"
#define PBFunction6       "CANCEL  "  //   "ȡ��ȷ��'
#define PBFunction7       "SPLIT   "  //   "����"
#define PBFunction8       "TRANSFER"  //   "ת��"
#define PBFunction9       "MOVE TO "  //   "ת����"
#define PBFunction10      "GUSET   "  //   "����"
#define PBFunction11      "COMBINE "  //   "�ϲ�"

#define PORAType1         "P.O.    "  // "����    "
#define PORAType2         "R.A.    "  // "���    "
#define PORAType3         "REFUND  "  //"IC���˿�"
#define PORAType4         "CHARGE  "  //"IC����ֵ"
#define PORAType5         "REDEEM  "  //"��ICѺ��"  ZWQ
#define PORAType6         "DEPOSIT "  //"��ICѺ��"  ZWQ

#define TendType1         "CASH    "  //"�ֽ�    "
#define TendType2         "CHECK   "  //"֧Ʊ    "
#define TendType3         "C.CARD  "  //"���ÿ�  "
#define TendType4         "COUPON  "  //"����ȯ  "
#define TendType5         "CREDIT  "  //"����"
#define TendType6         "CHIPCARD"  //"ICCard"

#define Modifier1         "MODIFIER"  //"˵��    "
#define ClerkRec1         "OPERATOR"  //"�տ�Ա  "
#define GroupRec1         "GROUP   "  //"����    "
#define DeptRec1          "DEPT    "  //"����    "
#define PLURec1           "PLU     "  //"��Ʒ    "
#define SalesPersonRec1   "S.PERSON"  //"ӪҵԱ  "	ZWQ
#define OffRec1           "OFFER   "  //"�������"
#define PortRec1		  "PORT "
#define AgreeRec1		  "AGREEMENT"
#define TeleRec1		  "TELE"		// ???


#if (defined(CASE_MALTA))
#define TAXType1	"F.VAT   "
#define TAXType2	"R.VAT   "
#define TAXType3	"E.VAT   "
#define TAXType4	"D.VAT   "
#define TAXType5	"E.VAT   "
#define TAXType6	"F.VAT   "
#define TAXType7	"G.VAT   "
#define TAXType8	"H.VAT   "
#else
#define TAXType1	"TAX 1   "
#define TAXType2	"TAX 2   "
#define TAXType3	"TAX 3   "
#define TAXType4	"TAX 4   "
#define TAXType5	"TAX 5   "
#define TAXType6	"TAX 6   "
#define TAXType7	"TAX 7   "
#define TAXType8	"TAX 8   "
#endif

//===end Def=


//===========Messages for Display:DMes==============
//DMes1,DMes2,DMes3,DMes4,DMes5,DMes6,DMes7,DMes8,DMes14,DMes16,DMes19,DMes20,DMes25�����������ʾPutsO(DMes1)
#if(DD_ZIP==1 || DD_ZIP_21==1 || DD_LCD_1601==1)
//ccr20140715 Max.Length<16 >>>>>>>>>>
#define DMes1    " CHANGE PRICE "		/* 0, Plu Price Change (PutsO)*/
#define DMes2    " INVENTORY ADD"		/* 1, Inventory ++  (PutsO)*/
#define DMes3    " INVENTORY SUB"		/* 2, Inventory --  (PutsO)*/
#define DMes4    " KP_GROUP"		/* 3, Kitchen Printer Group  (PutsO)*/
#define DMes5    " CORRECT"		/* 4, Correction (PutsO)*/
#define DMes6    " REFUND"			/* 5, Refund (PutsO)*/
#define DMes7    " CANCEL 1"		/* 6, Cancel 1 function (PutsO)*/
#define DMes8    " CANCEL 2"		/* 7, Cancel 2 function (PutsO)*/
#define DMes9    " RS232 ERROR"		/* 8, RS232 Test */
#define DMes10   " RS232 OK"		/* 9, RS232 Test */
#define DMes11   " RTC ERROR"		/* 10, RTC Test Error */
#define DMes12   " CTC ERROR"		/* 11, CTC Test Error */
#define DMes13   " FPROM ERROR"		/* 12, Fiscal Prom Error */
#define DMes14   "INITIALIZATION"		/* 13, Clearing RAM (PutsO)*/
#define DMes15   " INIT END"			/* 14, Initialising Application */
#define DMes16   " SLIP PAPER"		/* 15, Change Slip Paper (PutsO)*/
#define DMes17   " PASSWORD? "		/* 16, Secret Clerk Code */
#define DMes18   " ERROR- "			/* 17, Error code        */
#define DMes19   "PASSWORD ERROR"	/* 18, Error code   (PutsO)     */
#define DMes20   " ACCEPTED"		/* 19, Error code   (PutsO)     */
#define DMes21   "OPERATOR:"		/*20 �տ�Ա��  */
#define DMes22   "S.PERSON: "		/* 21 ӪҵԱ:  */
#define DMes23   "ECR#:"	/*22 �տ����  */  //ZWQ
#define DMes24   "LOCATION:"		/*23 λ��  */ //ZWQ
#define DMes25   "CONFIRM ?"		//24 (PutsO)
#define DMes26   "COMPLETED"			//25		???
#define DMes27   "VERSION:"		//26 "���а汾"	//
#define DMes28   "POINTS"			//27 "�������ѵ�"	 //
#define DMes29   "ADD PLU "			//28 "���ӵ�Ʒ:"	//
#define DMes30   "DELETE PLU:"		//29"ɾ����Ʒ:"	//
#define DMes31   "TEST STARTED>>"		//30"��ʼ���"	//
#define DMes32   "TEST COMPLETED"		//31"������"	// ZWQ
#define DMes33   "PRICE"			//32
#define DMes34   "INVENTORY"		//33
//<<<<<<<<<<<<<<<<<<<<
#else//ENGLISH
//ccr20140715 Max.Length<12 >>>>>>>>
#define DMes1    " PLU EPP"    /* 0, Plu Price Change */
#define DMes2    " INV.ADD"    /* 1, Inventory ++  */
#define DMes3    " INV.SUB"    /* 2, Inventory --  */
#define DMes4    " GROUP"    /* 3, Kitchen Printer Group  */
#define DMes5    " CORR."    /* 4, Correction */
#define DMes6    " REFUND"    /* 5, Refund */
#define DMes7    " CANCEL 1"    /* 6, Cancel 1 function */
#define DMes8    " CANCEL 2"    /* 7, Cancel 2 function */
#define DMes9    " RS232 ERR"    /* 8, RS232 Test */
#define DMes10    " RS232 OK"    /* 9, RS232 Test */
#define DMes11    " RTC ERR"    /* 10, RTC Test Error */
#define DMes12    " CTC ERR"    /* 11, CTC Test Error */
#define DMes13    " FPROMERR"    /* 12, Fiscal Prom Error */
#define DMes14    " INIT----"    /* 13, Clearing RAM */
#define DMes15    " INIT END"    /* 14, Initialising Application */
#define DMes16    " CHG SLIP"    /* 15, Change Slip Paper */
#define DMes17    " PASS ?"    /* 16, Secret Clerk Code */
#define DMes18    " ERROR-"     /* 17, Error code        */
#define DMes19    " PWD ERROR"     /* 18, Error code        */
#define DMes20    " ACCEPTED "     /* 19, Error code        */
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#if (PRTLEN<25)
//ccr20140715 Max.Length<6 >>>>>>>>>>>
#define DMes21    "OPER.:"	//*20 �տ�Ա��
#define DMes22    "S.PER.:"		//* 21 ӪҵԱ:
#define DMes23    "ECR#:"	//*22 �տ����
//<<<<<<<<<<<<<
#else
//ccr20140715 Max.Length<9 >>>>>>>>>>>
#define DMes21    "OPERATOR:"	//*20 �տ�Ա��
#define DMes22    "S.PERSON:"		//* 21 ӪҵԱ:
#define DMes23    "ECR#:"	//*22 �տ����
//<<<<<<<<<<<<<<<
#endif
#define DMes24    "LOCATION:"				//*23 λ��
#define DMes25    "CONFIRM ?"	 //24
#define DMes26    " FINISH "		 //25
#define DMes27	"VERSION:"	//26 "���а汾"	//
#define DMes28	"POINTS"	//27 "�������ѵ�"	 //
#define DMes29	"ADD PLU:"//28 "���ӵ�Ʒ:"	//
#define DMes30	"DEL PLU:"//29"ɾ����Ʒ:"	//
#define DMes31	"TEST START"//30"��ʼ���"	//
#define DMes32	"TEST COMPLETED"//31"������"	//
#define DMes33    "PRI_"								//32
#define DMes34    "INV_"							//33
#endif
//==end DMess

#define UPCOMM1    "UOK"			//0
#define UPCOMM2    "UCA"			//1
#define UPCOMM3    "UEN"			//2
#define UPCOMM4    "UER"			//3

//=========DText==========//
#if(DD_LCD_1601==1 || DD_ZIP==1 || DD_ZIP_21==1)
//#define DTEXTLEN 15
#define DText1    "CURRENCY"		/* 0, Foreign Currency */
#define DText2    "TOTAL"		/* 1, Sales Total */
#define DText3    "CHANGE"			/* 2, Change */
#define DText4    "SUBTOTAL"		/* 3, Subtotal */ //ZWQ
#define DText5    "DISCOUNT"		/* 4, Discount */
#define DText6    "P.O"			/* 5, Paid Out */	//ZWQ
#define DText7    "R.A"		/* 6, Received On Account */ //ZWQ
#define DText8    "DRAWER"		/* 7, Drawer */
#define DText9    "TABLE#"		/* 8, Table Number */
#define DText10   "SERVICE"			/* 9, Service */
#define DText11   "CHECKS PAID"		/* 10, Checks Paid */
#define DText12   "CHECK CANCEL"		/* 11, cancel Checks Paid */
#define DText13   "GUEST"			/* 12, Covers */
#define DText14   "OPERATOR"		/* 13, Clerk */
#define DText15   "MODIFIER"		/* 14, Modifier */
#define DText16   "HOLD"			/* 15, Suspend/Recall tekst */
#define DText17   "CANCEL"			/* 16, Transaction void */
#define DText18   "SALESPERSON"		/* 17, SalesPerson */

#define DText19   "OFF"			// 18, LOCK mode
#define DText20   "REGIST"			// 19,Reg mode
#define DText21   "X-REPORT"			// 20,X report mode
#define DText22   "Z-REPORT"		// 21,Z report mode
#define DText23   "PROGRAM"		// 22, SET mode
#define DText24   "MANAGEMENT"		// 23, Manager mode
                                    //
#define DText25   "PASSWORD"		// 24,Password for XMode
#define DText26   "PASSWORD 1"		// 25,New password for xMode
#define DText27   "PASSWORD 2"		// 26,Confirm new password for XMode
#define DText28   "PRICE:"			/* 27	���� */
#define DText29   "AMT.:"			/* 28  ��� */
#define DText30   "RETAIL"		// 29		ZWQ
#define DText31   "RESTAURANT"		// 30
#define DText32   "-"					/* 1 �� */
#define DText33   "-"					/* 32 ��  */
#define DText34   " "					/* 33 ��  */
#define DText35   "TEST MODE"		// 34
#define DText36   "RAM:"			//35
#define DText37   "OBLI."		/* 36  Subtotal */ //ZWQ
#define DText38     "FINISHED"		/* 37, cash finished  */

#else
//#define DTEXTLEN 6
//ccr20140715 Max.Length<6>>>>>>>>>>>>>>
#define DText1    "CUR"          /* 0, Foreign Currency */
#define DText2    "TOT"          /* 1, Sales Total */
#define DText3    "CHG"          /* 2, Change */
#define DText4    "SUB"          /* 3, Subtotal */
#define DText5    "DSC"          /* 4, Discount */
#define DText6    "PO"          /* 5, Paid Out */
#define DText7    "RA"          /* 6, Received On Account */
#define DText8    "DRAW"          /* 7, Drawer */
#define DText9    "TABLE"          /* 8, Table Number */
#define DText10   "SER"          /* 9, Service */
#define DText11   "CPA"          /* 10, Checks Paid */
#define DText12   "CCP"          /* 11, Cancel Checks Paid */
#define DText13   "COV"          /* 12, Covers */
#define DText14   "OPER"          /* 13, Clerk */
#define DText15   " ADD"          /* 14, Modifier */
#define DText16   "HOLD"          /* 15, Suspend/Recall tekst */
#define DText17   "CANC"          /* 16, Transaction void */
#define DText18   "SALP"          /* 17, SalesPerson */
#define DText19		"OFF"		  // 18, OFF mode ZWQ
#define DText20		"REG"		  // 19,Reg mode
#define DText21		"X-REP"		  // 20,X report mode
#define DText22		"Z-REP"		  // 21,Z report mode
#define DText23		"SET  "		  // 22, SET mode
#define DText24		"MAN"		  // 23, Manager mode
#define DText25		"Pwd"			  // 24,Password for XMode
#define DText26		"Pwd1"			  // 25,New password for xMode
#define DText27		"Pwd2"			  // 26,Confirm new password for XMode
#define DText28		"PRI.:"	  /* 27	���� */
#define DText29		"AMT.:"	  /* 28  ��� */
#define DText30		"RETAIL"					// 29
#define DText31		"HOSP."					// 30
#define DText32		"-"/* 31 �� */
#define DText33		"-"/* 32 ��  */
#define DText34		" "/* 33 ��  */
#define DText35		"TEST"		// 34
#define DText36     "RAM:"				//35
#define DText37     "OBLI."		/* 36, Subtotal */
#define DText38     "FINISHED"		/* 37, cash finished  */
#endif
//==end DText
//ccr20140715 Max.Length<6>>>>>>>>>>>>>>
#define	CusDText1	"TOT"
#define	CusDText2	"SUB"
#define	CusDText3	"CHG"
#define	CusDText4	"PRI"
#define	CusDText5	"CAN"
#define	CusDText6	"CUR"
#define	CusDText7	"COV"
//<<<<<<<<<<<<<<<<<<<<<
//=========XZTitle==============//
#if(DD_ZIP==1 || DD_ZIP_21==1  || DD_LCD_1601==1)

//ccr20140715 Max.Length<15>>>>>>>>>>>>>>
#define XZTitle1		"JOURNAL DAILY"
#define XZTitle2		"JOURNAL WEEKLY"
#define XZTitle3		"PLU REPORT"
#define XZTitle4		"TABLE REPORT"
#define XZTitle5		"TIME ZONE"
#define XZTitle6		"OPERATOR DAILY"
#define XZTitle7		"OP. WEEKLY"
#define XZTitle8		"ALL OP.DAILY"
#define XZTitle9		"ALL OP.WEEKLY"
#define XZTitle10		"S.PERSON.DAILY"
#define XZTitle11		"S.PERSON.WEEKLY"
#define XZTitle12		"ALL S.PER.DAILY"
#define XZTitle13		"ALL S.PER.WEEK."
#define XZTitle14		"MEMBERSHIP"
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#else
//ccr20140715 Max.Length<8>>>>>>>>>>>>>>
#define XZTitle1		"JOURN_D"
#define XZTitle2		"PERIOD"
#define XZTitle3		"PLU SEL_"
#define XZTitle4		"TABLE J_"
#define XZTitle5		"TIME ZON"
#define XZTitle6		"OPERAT_D"
#define XZTitle7		"OPERAT_W"
#define XZTitle8		"OPER_SD"
#define XZTitle9		"OPER_SW"
#define XZTitle10		"SALE_DAY"
#define XZTitle11		"SALE_WEK"
#define XZTitle12		"SALE_SD"
#define XZTitle13		"SALE_SW"
#define XZTitle14		"Bar_USER"
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#endif
//==end XZTitle

//==============PortType============//
#if(DD_ZIP==1 || DD_ZIP_21==1)
//ccr20140715 Max.Length<16>>>>>>>>>>>>>>
#define PortType1		"       HOST(PC)"
#define PortType2		"          RS485"
#define PortType3		"          MODEM"
#define PortType4		"         READER"
#define PortType5		"          SCALE"
#define PortType6		"KITCHEN PRINTER"
#define PortType7		"   SLIP PRINTER"
#define PortType8		"           EFT"	//ccr epos
//<<<<<<<<<<<<<<<<<<
#else
//ccr20140715 Max.Length<7>>>>>>>>>>>>>>
#define PortType1		"  HOST"
#define PortType2		" RS485"
#define PortType3		" MODEM"
#define PortType4		"READER"
#define PortType5		" SCALE"
#define PortType6		"KP_PRT"
#define PortType7		"  SLIP"
#define PortType8		"  EFT"	//ccr EFT POS ZWQ
//<<<<<<<<<<<<<<<<<<<<<<<<<
#endif
//==END PortType

//=============KPType=============//
#define KPType1		"   OFF"
#define KPType2		"INTERL"
#define KPType3		" EP-42",   //EPSON��ӡ��,ʹ��A����, 42�ַ�����
#define KPType4		"  EP-A",   //EPSON��ӡ��,ʹ��A����, 30�ַ�����
#define KPType5		"  EP-B",   //EPSON��ӡ��,ʹ��B����, 42�ַ�����
#define KPType6		" EP-48",   //EPSON��ӡ��,���е�, 48�ַ�����
#define KPType7		" CT-30",   //�����Ǵ�ӡ��, 30�ַ�����
#define KPType8		"PRT-58",   //POS58��ӡ��,���е�,30�ַ�����
//==end KPType

//=========SPType==============//
#define SPType1		"   OFF "
#define SPType2		"CTM-290"
#define SPType3		"TM290-2"
#define SPType4		"EP-C"
#define SPType5		"EP-NC"
//==end SPType

//================SysFlagUsed=============//
#if(DD_ZIP==1 || DD_ZIP_21==1 || DD_LCD_1601==1)
#define SysFlagUsed1	"ECR#:     "		//(1)0 	 0-255"ECR_no    "
#define SysFlagUsed1L	"LOCATE#:  "		//(1)0 	 0-255"LOCATION  "
#define SysFlagUsed2	"ROUNDING:      "		//(2)1 	 0,1,2,3,4"Round_    "
#define SysFlagUsed3	"PRICE VARIED:  "		//(3)2	 bit1"PLU_Free  "
#define SysFlagUsed4	"BUZZER:        "			//(4)3	 bit0"beep      "
#define SysFlagUsed5	"OPERATOR OBLI.:"	//(5)4	 bit0"Obl_Oper  "
#define SysFlagUsed6	"CHANGE OPER.?: "	//(6)5	 bit0"DisX_Oper "
#define SysFlagUsed7	"OPERATOR PWD:  "		//(7)6	 bit0"Pass_Oper "
#define SysFlagUsed8	"PRINT S.PERSON:"		//(8)7 bit0"Saleper_Num  "
#define SysFlagUsed9	"PRINT OPERATOR:"		//(9)8	 bit0"Prin_Oper "
#define SysFlagUsed10	"PRINT RECEIPT#:"		//(10)9   bit3"Prin_Recn "
#define SysFlagUsed11	"HEAVY PRINT"			//(11)10  1,2,3"Paper_Type  "
#define SysFlagUsed12	"S.PERSON OBLI.:"		//(12)11 bit6"Obl_Saleper_ "
#define SysFlagUsed13	"PRINT PLU#:    "		//(13)12 bit0"ArtCode   "
#define SysFlagUsed14	"SUBTOTAL OBLI.:"		//(14)13 bit0"Obl_Subt_ "
#define SysFlagUsed15	"PRINT ITEMS:"		//(15)14 bit0"Art_no_   "
#define SysFlagUsed16	"STUB PRINT:    "		//(16)15 bit7"TALLONS   "
#define SysFlagUsed17	"STUB FORMAT:   "		//(17)16 bit0"TALLON HEADER AND TAILER "
#define SysFlagUsed18	"SHIFT LOCKED:  "		//(18)17 bit7"En_Shift"
#define SysFlagUsed19	"IDLE TIME:     "			//(19)18 0..99"Time_IDLE "
#define SysFlagUsed20	"RECEIPT COPIES:"		//(20)19 0..15"CopyReceipt "
#define SysFlagUsed21	"PRICE CODE:    "			//(21)20 bit3 "EANSpec_"
#define SysFlagUsed22	"AMT POINT:"	//(22)21  bit4"select collect flow " //lyq2003
#define SysFlagUsed23	"PRT PRE.BALANCE"		//(23)22  bit4"select pb print " //lyq2003
#define SysFlagUsed24	"PRT STOCK:     "		//(24)23  bit4"select inv print " //lyq2003
#define SysFlagUsed25	"RECEIPT PRINT: "	//(25)24  bit5"allow press operator key to close printer" //lyq2003
#define SysFlagUsed26	"TABLE OBLI.:   "	//(26)25  "���뿪̨:"},
#define SysFlagUsed27	"KEEP R-NO#:    "		//(27)26  "�����վݺ�"},
#define SysFlagUsed28	"K.PRT COPY:    "			//(28)27   //ccr040810
#define SysFlagUsed29	"RESET R-NO:    "		//(29)28  "�վݺŸ�λ" //
#define SysFlagUsed30 	"CUTTER:        "            //    (29)28"ʹ���е�" //
#define SysFlagUsed31 	"DATE TYPE:     "          //    (30)29      0-2"Date Type "
#define SysFlagUsed32 	"TIME 24H:      "           //    (31)30  bit0 "time format 12 or 24"
#define SysFlags33      "HEAD CENTER:   "  // "Ʊͷ���д�ӡ"
#define SysFlags34      "TRAIL CENTER   "  // "Ʊβ���д�ӡ"

#else
#define SysFlagUsed1	 "ECR#:    "		//(1)0 	 0-255"ECR_no    "
#define SysFlagUsed1L	 "LOCATE#: "		//(1)0 	 0-255"LOCATION  "
#define SysFlagUsed2	 "ROUNDING:"		//(2)1 	 0,1,2,3,4"Round_    "
#define SysFlagUsed3	 "PRICE CHANGE:"	//(3)2	 bit1"PLU_Free  "
#define SysFlagUsed4	 "BUZZER:"			//(4)3	 bit0"beep      "
#define SysFlagUsed5	 "OPERATOR OBLI:"	//(5)4	 bit0"Obl_Oper  "
#define SysFlagUsed6	 "CHANGE OPER:"	//(6)5	 bit0"DisX_Oper "
#define SysFlagUsed7	 "OP.PASS OBLI.:"		//(7)6	 bit0"Pass_Oper "
#define SysFlagUsed8	 "PRINT S.PERSON:"		//(8)7 bit0"Saleper_Num  "
#define SysFlagUsed9	 "PRINT OPERAROR:"		//(9)8	 bit0"Prin_Oper "
#define SysFlagUsed10	 "PRINT RCP#:"		//(10)9   bit3"Prin_Recn "
#define SysFlagUsed11	 "DENSITY:"			//(11)10  1,2,3"Paper_Type  "
#define SysFlagUsed12	 "S.PERSON OBLI.:"		//(12)11 bit6"Obl_Saleper_ "
#define SysFlagUsed13	 "PRINT PLU#:"		//(13)12 bit0"ArtCode   "
#define SysFlagUsed14	 "SUBTOTAL OBLI."		//(14)13 bit0"Obl_Subt_ "
#define SysFlagUsed15	 "PRINT ITEMS:"		//(15)14 bit0"Art_no_   "
#define SysFlagUsed16	 "STUB PRINT:"		//(16)15 bit7"TALLONS   "
#define SysFlagUsed17	 "STUB FORMAT:"		//(17)16 bit0"TALLON HEADER AND TAILER "
#define SysFlagUsed18	 "SHIFT LOCK:"		//(18)17 bit7"En_Shift"
#define SysFlagUsed19	 "IDLE TIME:"			//(19)18 0..99"Time_IDLE "
#define SysFlagUsed20	 "COPY RECEIPT:"		//(20)19 0..15"CopyReceipt "
#define SysFlagUsed21	 "PRICE CODE:"			//(21)20 bit3 "EANSpec_"
#define SysFlagUsed22	 "AMT_POINT:"	//(22)21  bit4"select collect flow " //lyq2003
#define SysFlagUsed23	 "PR.BALANCE:"		//(23)22  bit4"select pb print " //lyq2003
#define SysFlagUsed24	 "PR.STOCK:"	//(24)23  bit4"select inv print " //lyq2003
#define SysFlagUsed25	 "RECEIPT PRINT:  "//(25)24  bit5"allow press operator key to close printer" //lyq2003
#define SysFlagUsed26	 "TABLE MUST:"	//(26)25  "���뿪̨:"},
#define SysFlagUsed27	 "KEEP RCP#:"	//(27)26  "�����վݺ�"},
#define SysFlagUsed28	 "COPY K.P:"		//(28)27   //ccr040810
#define SysFlagUsed29	 "RESET RCP#:"	//(29)28  "�վݺŸ�λ" //
#define SysFlagUsed30   "CUTTER:"            //    (29)28"ʹ���е�" //
#define SysFlagUsed31   "DATE TYPE:"          //    (30)29      0-2"Date Type "
#define SysFlagUsed32   "TIME 24H:"           //    (31)30  bit0 "time format 12 or 24"
#define SysFlags33      "HEAD CENTER"  // "Ʊͷ���д�ӡ"
#define SysFlags34      "TRAIL CENTER"  // "Ʊβ���д�ӡ"

#endif
//==end SysFlagUsed

//=============Grap============//
#define GrapType1		"SHOP TYPE"
#define GrapType2		"FESTIVAL "
#define GrapType3		"LOGO     "
#define GrapType4		"PROG_MSG?"
#define GrapSet1		"NUMBER   "
#define GrapSet2		"PICTURE  "
#define GrapSet3		"FROM     "
#define GrapSet4		"TO       "
//===end Grap

//=============ConfigTable=============//

#define ConfTab1		"FILES"
#define ConfTab2		"FILE MEMORY"		     //	"�ļ��ռ䣺"1
#define ConfTab3		"STATISTIC"		       //"ͳ���ļ�"2
#define ConfTab4		"TENDER"		         //"������Ϣ"	3
#define ConfTab5		"PO/RA"		           //"�������Ϣ"4
#define ConfTab6		"DRAWER"		         //"Ǯ����Ϣ"5
#define ConfTab7		"CORRECT"		         //"������Ϣ"6
#define ConfTab8		"CURRENCY"	  		   //"�����Ϣ"7
#define ConfTab9		"TAX"	               //"��˰"8
#define ConfTab10		"PREV. BALANCE"      //"��̨����"��9
#define ConfTab11		"OFFER"              //"��������ļ���"	10
#define ConfTab12		"AGREEMENT"          //"ǩ���ļ�:"11
#define ConfTab13		"PLU CODE"		       //"��Ʒ�����ļ���"12
#define ConfTab14		"PB FUNCTION"		             //"������Ϣ"13
#define ConfTab15		"PB BUFFER"          //"��̨������"14
#define ConfTab16		"SIZE OF EJ"		     //"��ˮ�ռ䣺"15
#define ConfTab17		"PORT"               //"����"	16
#define ConfTab18		"SIZE OF RAM"        //17
#define ConfTab19		"BLOCKED ID"            //18 GUASHIIC
#define ConfTab20		"SIZE OF FM"         //19

#define REMAINEJ		"FREE SPACE IN EJ"       //20"��ˮ�ռ䣺"15
#define REMAINFM		"BALANCE OF FM"

#define DATEOFZ		"Z-DATE"
#define DATEOFEJ	"EJ-DATE"



#if (PRTLEN<25)
#define ConfTi1		"FILE   RECORD   RAM "
#define ConfTi2 	"PORT   TYPE     PROT"
#else
#define ConfTi1		"FILE           RECORD       RAM "
#define ConfTi2 	"PORT         TYPE       PROTOCOL"
#endif

//==end ConfTab

//=============Msg================//
#if (DD_ZIP||DD_ZIP_21||DD_LCD_1601||DD_FISPRINTER) //======MAX LENGTH:16
#define MessageM1	"INVALID ENTRY"				//    CWXXI01//    Ccr "��Ч����!"
#define MessageM2	"INVALID DATE"					//    CWXXI02//    Ccr "��Ч����!"
#define MessageM3	"INVALID TIME"					//    CWXXI03//    Ccr "��Чʱ��!"
#define MessageM4	"NOT ALLOWED"					//    CWXXI04//    Ccr "��ֹ����!"
#define MessageM5	"NULL PLU"						//    CWXXI05//    Ccr "PLU����Ϊ��!"
#define MessageM6	"PLU OVERFLOW"					//    CWXXI06//    Ccr "PLU�ļ����!"
#define MessageM7	"TABLE OCCUPIED"					//    CWXXI07//    Ccr "��̨��ռ��!"
#define MessageM8	"TABLE OPENED"					//    CWXXI08//    Ccr "��̨�Ѵ�!"
#define MessageM9	"WRONG TABLE#"					//    CWXXI09//    Ccr "��̨�Ų���!"
#define MessageM10	"ENTER TABLE#"            		//    CWXXI10//    Ccr "��������̨��"
#define MessageM11	"NULL TABLE#"           		//    CWXXI11//    Ccr "��̨û�п�̨"
#define MessageM12	"PB OVERFLOW"            		//    CWXXI12//    Ccr "��̨�������"
#define MessageM13	"NOT ALLOWED"       			//    CWXXI13//    Ccr "��ֹ�޸�ʱ��"
#define MessageM14	"IN TRADING!"					//    CWXXI14//    Ccr "����������!"
#define MessageM15	"MEMORY OVERFLOW"              	//    CWXXI15//    Ccr "���ۻ�������"
#define MessageM16	"ITEM NOT SOLD"         		//    CWXXI16//    Ccr "��Ʒû���۳�"
#define MessageM17	"IN CHECKOUT"						//    CWXXI17//    Ccr "���ڽ�����!"
#define MessageM18	"ENTRY OVERFLOW"            			//    CWXXI18//    Ccr "�������ݳ���"
#define MessageM19	"IN TENDERING"					//    CWXXI19//    Ccr "���ڸ���!"
#define MessageM20	"GUEST OVERFLOW"						//    CWXXI20//    Ccr "�������!"
#define MessageM21	"CONFIRM NEEDED"						//    CWXXI21//    Ccr "û��ȷ�Ͻ���"
#define MessageM22	"NOT ALLOWED"        			//    CWXXI22//    Ccr "��ֹȡ������"
#define MessageM23	"NULL ITEM"        			//    CWXXI23//    Ccr "�޲���!"
#define MessageM24	"NULL OPERATOR"					//    CWXXI24//    Ccr "�޴��տ�Ա!"
#define MessageM25	"OPERATOR SHIFTED"              	//    CWXXI25//    Ccr "�տ�Ա�ı�"
#define MessageM26	"NULL REPORT"					//    CWXXI26//    Ccr "�޴��౨��!"
#define MessageM27	"REPORT.PRT FAIL"            		//    CWXXI27//    Ccr "������ӡ�ж�"
#define MessageM28	"MANAGER ONLY"					//    CWXXI28//    Ccr "�����ھ�����"
#define MessageM29	"IN SPLITTING"          		//    CWXXI29//    Ccr "���ܷ���ʱ��"
#define MessageM30	"INPUT CARD#"					//    CWXXI30//    Ccr "�����������"
#define MessageM31	"TRANSFER TO"        			//    CWXXI31//    Ccr "ת�뵽"
#define MessageM32	"UNAUTHORIZED"        			//    CWXXI32//    Ccr "δ��Ȩ!"
#define MessageM33	"OPERATOR OBLI."            		//    CWXXI33//    Ccr "��ָ���տ�Ա" obligatory
#define MessageM34	"SALESPERSON OBLI"            		//    CWXXI34//    Ccr "��ָ��ӪҵԱ"
#define MessageM35	"NOT ALLOWED"        			//    CWXXI35//    Ccr "��ֹPLU��ۣ�"
#define MessageM36	"PASSWORD ERROR"					//    CWXXI36//    Ccr "���벻��!"
#define MessageM37	"KITCHEN PRT ERR."            		//    CWXXI37//    Ccr "������ӡ����"
#define MessageM38	"SLIP PRT ERROR."            		//    CWXXI38//    Ccr "Ʊ�ݴ�ӡ����"
#define MessageM39	"PRINTER OPEN"            		//    CWXXI39//    Ccr "��ӡѹ��̧��"
#define MessageM40	"PAPER OUT"            		//    CWXXI40//    Ccr "��ӡֽ����!"
#define MessageM41	"PRINTER OVERHEAT"            			//    CWXXI41//    Ccr "��ӡ�¶�̫��"
#define MessageM42	"UNDEFINED KEY"					//    CWXXI42//    Ccr "����δ����!"
#define MessageM43	"AMOUNT OBLI."					//    CWXXI43//    Ccr "����������"
#define MessageM44	"SPLIT TENDER"         		 		//    CWXXI44//    Ccr "��ֹ���ָ���"
#define MessageM45	"NULL FUNCTION"        			 	//    CWXXI45//    Ccr "�����޴˹���"
#define MessageM46	"SUBTOTAL OBLI."        		 		//    CWXXI46//    Ccr "δ��С�Ƽ�!"
#define MessageM47	"STOCK TAKING"            		 	//    CWXXI47//    Ccr "���ڹ������"
#define MessageM48	"EJ ERROR"           		 	//    CWXXI48//    Ccr "������ˮ��"
#define MessageM49	"MODEM ERROR"			         	//    CWXXI49//    Ccr "MODEMͨѶ��!"
#define MessageM50	"ACCESS CARD ERR"               	 	//    CWXXI50//    Ccr "����������!"
#define MessageM51	"POS-CODE ERROR"                 		//    CWXXI51//    Ccr "POS�����!"
#define MessageM52	"READING ERROR"                  		//    CWXXI52//    Ccr "�����ݴ�!"
#define MessageM53	"EXPIRED CARD"               			//    CWXXI53//    Ccr "Ϊ���ڿ�!"
#define MessageM54	"BLOCKED CARD"                   		//    CWXXI54//    Ccr "Ϊ��ʧ��!"
#define MessageM55	"WRONG CARD TYPE"              	 		//    CWXXI55//    Ccr "�ͻ�����!"
#define MessageM56	"NEW CARD"                    			//    CWXXI56//    Ccr "Ϊ�¿�!"
#define MessageM57	"NOT CASH CARD"            			//    CWXXI57//    Ccr "���ǹ��￨!"
#define MessageM58	"WRITING ERROR"                 		//    CWXXI58//    Ccr "д������!"
#define MessageM59	"WRONG NUMBER"                  		//    CWXXI59//    Ccr "���Ų���!"
#define MessageM60	"DISC.FORBIDDEN"					//    CWXXI60//    Ccr "�����ۿۿ�!"
#define MessageM61	"CASH FORBIDDEN"					//    CWXXI61//    Ccr "�����ֽ�!"
#define MessageM62	"CREDIT FORBIDDEN"					//    CWXXI62//    Ccr "�������ʿ�!"
#define MessageM63	"CARD FORBIDDEN"					 	//    CWXXI63//    Ccr "����IC��!"
#define MessageM64	"CLEARANCE ERROR"				//    CWXXI64//    Ccr "�忨����!"
#define MessageM65	"DATA OVERFLOW"						//    CWXXI65//    Ccr "�������!"
#define MessageM66	"CARD CHARGE ERR"					//    CWXXI66//    Ccr "IC��ֵ����!"
#define MessageM67	"INIT. ERROR"					//    CWXXI67//    Ccr "IC��ʼ������"
#define MessageM68	"INIT. DISABLED"					 	//    CWXXI68//    Ccr "��ֹ��ʼ��!"
#define MessageM69	"LOWER BALANCE"					//    CWXXI69//    Ccr "IC����!"
#define MessageM70	"TENDERING ERROR"					//    CWXXI70//    Ccr "IC�������!"
#define MessageM71	"IP ADDRESS ERROR"				 		//    CWXXT71//    Hf "IP��ַ��"
#define MessageM72	"M1 ERROR"				//    CWXXI72//     ccr "��Ƶ������!"
#define MessageM73	"CONNECTION FAIL"				//    CWXXI73//    Cc "����ʧ��!"
#define MessageM74	"NO FISCAL MEMORY"   				//    CWXXI74>>>>>for fiscal
#define MessageM75	"Z-REPORT REQUIRE"   				//    CWXXI75
#define MessageM76	"WRITE FM ERROR"   				//    CWXXI76
#define MessageM77	"FM NEAR FULL"    				//    CWXXI77 FM���� //
#define MessageM78	"FM ERROR"     				//    CWXXI78
#define MessageM79	"FISCALIZED"    				//    CWXXI79
#define MessageM80	"TRAIN MODE"   				//    CWXXI80
#define MessageM81	"INITIALIZE FM"   				//    CWXXI81
#define MessageM82	"EJ DATA ERROR"   				//    CWXXI82 EJ�е������д� //
#define MessageM83	"NO EJ"        				//    CWXXI83
#define MessageM84	"ACCESSING EJ ERR"   				//    CWXXI84 EJ ��д���� //
#define MessageM85	"NO DATA IN EJ"   				//    CWXXI85 EJ������ //
#define MessageM86	"FM IS FULL"   				//    CWXXI86
#define MessageM87	"EJ NEAR FULL"   				//    CWXXI87 EJ���� //
#define MessageM88	"EJ IS FULL"   				//    CWXXI88
#define MessageM89	"EJ LIMIT: 100"    				//    CWXXI89
#define MessageM90	"NEW EJ"        				//    CWXXI90
#define MessageM91	"MAC LIMIT: 200"    				//    CWXXI91 ���200�μӵ��ʼ�� //
#define MessageM92	"CHECKSUM ERROR"  				//    CWXXI92
#define MessageM93	"FM NOT MATCH ECR"     				//    CWXXI93 FM ���տ����ƥ�� //
#define MessageM94	"NEW FM"        				//    CWXXI94
#define MessageM95	"O.Battery Low!"   				//    CWXXI95
#define MessageM96	"NOT ALLOWED"   				//    CWXXI96
#define MessageM97	"INITIALIZE EJ"   				//    CWXXI97
#define MessageM98	"EJ NOT MATCH ECR"     				//    CWXXI98 EJ���տ����ƥ�� //
#define MessageM99	"STOCK DISABLED"     				//    CWXXI99
#define MessageM100	"INVALID TAX"     				//    CWXXI100
#define MessageM101 "NEGATIVE TAX"          //CWXXI101 ˰��<0 //ccr2014-08-06 new

#if (defined(CASE_GPRS) || defined(CASE_ETHERNET))
#define CaptionGPRSERR  "GPRS ERROR!"          //CWXXI102 //GPRS����
#define CaptionSENDERR  "SEND ERROR!"          //CWXXI103 //�������ݳ���
#define CaptionRECVERR  "ERROR RECEIVED"          //CWXXI104 //�������ݳ���
#define CaptionNOSERVER "NO SERVER!"           //CWXXI105 //�޷����ӷ�����
#define CaptionIPERROR  "ERROR IP/PORT"         //CWXXI106 //�޷�����IP��ַ
#define CaptionNOSIM    "NO SIM CARD"          //CWXXI107 //��SIM��
#define CaptionGPRSKO   "GPRS NOT OK"          //CWXXI108 //GPRSδ����
#define CaptionLINEOFF  "NETWORK BREAK"          //(CWXXI109) //����δ���
#define CaptionTCPERROR "CREATE TCP FAIL"   // (CWXXI110) //����ͨѶʧ��
#endif


#endif	//(DD_ZIP||DD_ZIP_21)
#define SERVING		"Serving"			//ccro91127
#define INITEJPROMPT 	"Initial EJ ?"				//ccr091117
//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
#define MessageN1		"SERIAL#:"				//KAHAO//Ccr 	"����:"				//KAHAO
#define MessageN2		"CARD TYPE:"				//KLXING//Ccr 	"������:"				//KLXING
#define MessageN3		"BALANCE:"			//KNJE//Ccr 	"���ڽ��:"			//KNJE
#define MessageN4		"FOREGIFT:"				//KYJIN//Ccr 	"��Ѻ��:"				//KYJIN
#define MessageN5		"PAYMENT:"			//XFZE//Ccr 	"�����ܶ�:"			//XFZE
#define MessageN6		"CHARGE:"			//CHZHZE//Ccr 	"��ֵ�ܶ�:"			//CHZHZE
#define MessageN7		"TIMES:"		//SHYCSHU//Ccr 	"ʹ�ô���:"			//SHYCSHU
#define MessageN8		"PRI.LEVEL:"		//JGLBIE//Ccr 	"�۸񼶱�:"			//JGLBIE
#define MessageN9		"PIN CODE:"				//PINMA//Ccr 	"PIN��:"				//PINMA
#define MessageN10		"SECURITY LEVEL:"			//BHJBIE//Ccr 	"��������:"			//BHJBIE
#define MessageN11		"AUTO TENDER:"			//ZDJZHANG//Ccr 	"�Զ�����:"			//ZDJZHANG ZWQ
#define MessageN12		"OPEN DATE:"			//ZHKRQI//Ccr 	"�ƿ�����:"			//ZHKRQI ZWQ
#define MessageN13		"EXPIRED DATE:"			//KYXQI//Ccr 	"����Ч��:"			//KYXQI
#define MessageN14		"HOLDER:"			//KHMCHEN//Ccr 	"�ͻ�����:"			//KHMCHEN5
#define MessageN15		"INITIALIZATION"				//CHSHHICKA//ccr	"��ʼ��IC"								//CHSHHICKA
#define MessageN16		"CHARGE"						//ICKCHZHI//ccr	"IC����ֵ"									//ICKCHZHI
#define MessageN17		"CLEAR"						//QCHICKA//ccr	"���IC��"									//QCHICKA
#define MessageN18		"BLACKLIST"  //GUASHIIC//ccr "��ʧ����"     //GUASHIIC      //ICCard Part ccr chipcard 2004-06-28
#define MessageN19		"DISCOUNT:" //ZHEKOUCA//ccr "�ۿۿ�:"            //ZHEKOUCA
#define MessageN20		"CASH:"        //XIANJINKA//ccr "�ֽ�:"           //XIANJINKA
#define MessageN21		"CREDIT:"  //SHEZHANGKA//ccr "���ʿ�:"           //SHEZHANGKA
#define MessageN22		"POINT:"  // ���ѼƵ�:	//KAOQINKA
#define MessageN23		"DISCOUNT(%):"    //    ZHKLVF//    Ccr "�ۿ���(%):",        //    ZHKLVF
#define MessageN24		"WITHDRAWAL"        //    ICKTKUAN//    Ccr "IC���˿�",			//    ICKTKUAN
#define MessageN25		"POINT REDEEM"     //    ICKDJDIANG//    Ccr "IC���ҽ�����",			//    ICKDJDIANG
#define MessageN26		"GIFT POINTS"      //    ICKSDIAN//    Ccr "IC���͵���",			//    ICKSDIAN
#define MessageN27		"CHECK"               //    ZHUOTAI//    Ccr "��̨",                       //    ZHUOTAI
#define MessageN28		"RCP#_FROM"         //    Cc	"��ʼ�վݺ�",	//    RECNUMFR
#define MessageN29		"RCP#_END"         //    Cc	"�����վݺ�",	//    RECNUMTO

#define MessageN30		"EJ INITIALISATION:"       //    hf		"EJ��ʼ��"		//    EJCSHUA
#define MessageN31		"CODE"      //    hf 	"EJ���"			//    EJBHAO
#define MessageN32		"~E.~J. ~R~E~P~O~R~T"//    hf		"EJ ����"			//    EJBBIAO
#define MessageN33		"~G~.~T~."              //"~��~��~��",		//    HSJXSHOU
#if (defined(FISCAL) || DD_FISPRINTER==1)
#define MessageN34		"CHECK"
#if (defined(CASE_MALTA))
#define MessageN35		"F.VAT   "
#define MessageN36		"R.VAT   "
#define MessageN37		"E.VAT   "
#define MessageN38		"D.VAT   "
#define MessageN39		"E.VAT   "
#define MessageN40		"F.VAT   "
#define MessageN41		"G.VAT   "
#define MessageN42		"H.VAT   "
#else
#define MessageN35		" TAX A "
#define MessageN36		" TAX B "
#define MessageN37		" TAX C "
#define MessageN38		" TAX D "
#define MessageN39		" TAX E "
#define MessageN40		" TAX F "
#define MessageN41		" TAX G "
#define MessageN42		" TAX H "
#endif
#define MessageN43		"TAX SUM"      //TAXTOTAL
#define MessageN44		"NET SALE"
#define MessageN45		"RCP.NUMBER"    //???

#define MessageN46		"FM DISCONNECT"
#define MessageN47		"HEADER CHANGES"
#define MessageN48		" TAX A CHANGE"	//Cc	"����˰��A"		//TAXBCHG
#define MessageN49		" TAX B CHANGE"	//Cc	"����˰��B"		//TAXBCHG
#define MessageN50		" TAX C CHANGE"	//Cc	"����˰��C"		//TAXCCHG
#define MessageN51		" TAX D CHANGE"	//Cc	"����˰��D"		//TAXDCHG
#define MessageN52		" TAX E CHANGE"	//Cc	"����˰��E"		//TAXECHG
#define MessageN53		" TAX F CHANGE"	//Cc	"����˰��F"		//TAXFCHG
#define MessageN54		" TAX G CHANGE"	//Cc	"����˰��G"		//TAXGCHG
#define MessageN55		" TAX H CHANGE"	//Cc	"����˰��H"		//TAXHCHG
#define MessageN56		" FROM "			//Cc	"��ʼ����"		//TAXFROM
#define MessageN57		" TO "
#if(PRTLEN < 36)
#define MessageN58		"~F~M ~R~E~P~O~R~T"	//Cc"˰�ش洢������"//PRNFISCAL
#else
#define MessageN58		"~F~I~S~C~A~L ~M~E~M~O~R~Y ~R~E~P~O~R~T"
#endif
#define MessageN59		"PERIOD TOTALS"	//Cc	"�����ܼ�"		//PRNTOTAL
#define MessageN60		"Z-CLOSURES"		//Cc	"�����ܼ�"		//CLEARTOTAL
#define MessageN61		"MAC RESETS"		//Cc	"��λ�ܼ�"		//MACRESET
#define MessageN62		"TAX CHANGES"		//Cc"˰�ʸ����ܼ�"	//CHANGETAX
#if (PRTLEN <36 ) // liuj 0716
#define MessageN63		"~Z ~R~E~P~O~R~T"	//hf 	"˰���ձ���"	//SHKZBB
#else
#define MessageN63		"~F~I~S~C~A~L ~Z ~R~E~P~O~R~T"
#endif
#define MessageN64		"SERIAL:"		//hf 	"˰����"			//TAXCODE
#define MessageN65		"R.U.C:"		//PANAMA 	"RIF����"			//RIFCODE
#define MessageN67		"TAX-EXEMPT"	//hf		"��˰����"		//MIANSHUI
#define MessageN68		"TAX"		//hf 	"˰Ŀ A"			//SHUIMUA
#define MessageN69		"CUSTOMER: "		//hf		"�ͻ�����"		//KHMINGCH		//20070308
#define MessageN70		"SERIAL NUMBER: "			//hf		"������"			//JIQIHAO		//20070308
#define MessageN71		"DATE"						//hf		"����"			//RIQI			//20070308
#define MessageN72		"TIME"						//hf		"ʱ��"			//SHIJIAN		//20070308
#define MessageN73		"TAXABLE SUM"				//hf		"�����ܼ�"		//XSHZHJI
#if (VZLA_FORMAT)
#define MessageN74		"DEVOLUC.TAX SUM"		//hf		"�˻��ܼ�"		//THUOZHJI
#define MessageN75		"AJVSTES.TAX SUM"		//hf		"�ۿ��ܼ�"		//ZHKOUZHJI
#else
#define MessageN74		"Refund.TAX SUM"		//hf		"�˻��ܼ�"		//THUOZHJI
#define MessageN75		"Disc.TAX SUM"		//hf		"�ۿ��ܼ�"		//ZHKOUZHJI
#endif
#define MessageN76		"TAXABLE"					//XIAOSHOUA	"��ͨ����"
#if (VZLA_FORMAT)
#define MessageN77		" DEVOLUC"				// " �˻�����"
#define MessageN78		" AJVSTES"				////hf		"�ۿ�����"		//ZHKOUXSH
#define MessageN79		" DEVOLUC.TAX SUM"		//		"�˻�˰��"		//THZJSHUI
#define MessageN80		" AJVSTES.TAX SUM"		//		"�ۿ�˰��"		//ZHKZJSHUI
#else
#define MessageN77		" REFUND "				//    hf		" �˻�����"		//    THXIAOSHOU
#define MessageN78		"DISCOUNT"				//    hf		"�ۿ�����"		//    ZHKOUXSH
#define MessageN79		" Refund.TAX SUM"		//    hf		"�˻�˰��"		//    THZJSHUI
#define MessageN80		" Disc.TAX SUM"		//    hf		"�ۿ�˰��"		//    ZHKZJSHUI
#endif
#define MessageN81		"EJ INITIALIZED"		//    hf 	"EJ��Ϣ"			//    EJXINXI
#define MessageN82		"EJ INIT DATE"			//    hf "EJ��ʼ��ʱ��"		//    EJSHJIAN
#define MessageN83		"NON FISCAL"			//    Cc	"�Ƿ�Ʊ"			//    NONFISCAL
#define MessageN84		"ECR FISCALIZED"		//  SHKCSHUA
#define MessageN85		"DATE FROM"			//    Cc	"��ʼ����"		//    RIQIF
#define MessageN86		"TIME FROM"			//    Cc	"��ʼʱ��"		//    SHIJIANF
#define MessageN87		"DATE TO"				//    Cc	"��������"		//    JSHRQIF
#define MessageN88		"RECEIPTS"			//    hf		"�ܼƷ�Ʊ��"	//    ZHJIFPHAO
#define MessageN89		"NO.NC" 				//    hf		"�ܼ��˻���"	//    ZHJITHHAO ???
#define MessageN90		"NO.NF"				//    hf		"�ܼƷ�˰��"	//    ZHJIFSHHAO  ???
#define MessageN91		"# RECEIPTS"			//    hf		"��Ʊ��"			//    FAPIAOHAO  ???
#define MessageN92		"# NCD"				//    hf		"�˻���"			//    THUOHAO   ???
#define MessageN93		"# NFD"				//    hf		"��˰��"			//    FEISHUIHAO  ???
#define MessageN94		"# FMD"				//    hf		"˰�ر�����"	//    SHKBBHAO  ???
#define MessageN95		"Z:"					//    Cc	"���ʼ���"		//    QZHJSHU
#define MessageN96		"ZEROING. AVAILAB:"					//REPLEFT
#define MessageN97		"FM(KB)"							//SIZEFM
#endif //end fiscal
#define MessageN98		"SIZE OF EJ"							//SIZEEJ
#define MessageN99		"VALUE IN IC"			//    VALUEINIC
#define MessageN100		"LOWER BAT  "							//    LOWBAT
#define MessageN101		"CLEAR IC"				//    CLEARIC
#define MessageN102		"CHARGE IC"			//    CHARGEIC
#define MessageN103		"GIFT POINTS"		//    ADPOINTS
#define MessageN104		"INIT_ IC"				//    INITIC
#define MessageN105		"WAIT IC_____"			//WAITEICCARD
#define MessageN106		"IC CARD OK__"			//ICCARDOK
#define MessageN107		"CARD NO.:"			//ePOSTAC //ccr epos//ccr "ePOS��֤��:"			//ePOSTAC //ccr epos
#define MessageN108		"WAIT EPOS___"					//WAITEPOS
#define MessageN109		"ACCOUNTS:"			//ePOSCARNO//ccr "��ͨ����:"					//ePOSCARNO
#define MessageN110		"EFT BALANCE:"	//eCARREMAIN//ccr "��ͨ�����:"					//eCARREMAIN
#define MessageN111		" ID :"			//TMHYHAO//ccr "��Ա��:"			//TMHYHAO
#define MessageN112		"MEMBERSHIP"   //BARREPORT//ccr  �� Ա �� ��   //
#define MessageN113		"AMOUNT"				//XFJE//ccr "���ѽ��"				//XFJE
#define MessageN114		"TOTAL"                 //ZONGJI//Ccr "�ܼ�"                       //ZONGJI
#define MessageN115		"X           "						//    BREAK485
#define MessageN116		"=           "						//    LINK485
#define MessageWait		"Waiting....."          //WAITING
#define MessageInit     "Initializing......"    //INITWAITING

#define MessageRecFr	"RECEIPT FROM"         //    Cc	"��ʼ�վݺ�",	//    RECEIPTFROM
#define MessageRecTo	"RECEIPT TO"         //    Cc	"�����վݺ�",	//    RECEIPTTO

#define MessageEXC_VAT  "SUM EXCEPT.TAX"    //SUM_EXC_VAT ����˰���۽��
#define MessageVAT      "TAX AMOUNT"        //VAT_AMOUNT ˰��

//==end Msg

//==============Prompt=================//
#if( (DD_ZIP==1)||(DD_ZIP_21==1) || DD_LCD_1601==1)
#define Prompt1		"TOTAL"	// Ӧ�� 0 */
#define Prompt2		"SUBTOTAL"		// 1
#define Prompt3		"SPENDING"		// 2"�����ܶ� "
#define Prompt4		" NET AMOUNT"		// 3
#define Prompt5		" PRICE"				// 4
#define Prompt6		" TRANSACTIONS"	//5
#define Prompt7		" QUANTITIES"		//6
#define Prompt8		" AMOUNT"			//7
#define Prompt9		"COLLECT"		//8   ZWQ
#define Prompt10	"CHANGE"		//9
#define Prompt11	" "					/* 10 */
#define Prompt12	" "					/* 11 */
#define Prompt13	"-"					/* 12 */
#define Prompt14	"-"					/* 13 */
#define Prompt15	"STANDARD"		/* 14 */
#define Prompt16	"OPERATOR"		//15
#define Prompt17	" "			//16
#define Prompt18	" "					//17
#define Prompt19	"-"				//18
#define Prompt20	"REPORT"		/* 19 */
#define Prompt21	" REFUND"		/* 20 */
#define Prompt22	" DISCOUNT"		//21
#define Prompt23	" COST"		//22
#define Prompt24	"TABLE#"			//23
#define Prompt25	"CHECK#"		/* 24 used for Register ID with EFT */
#define Prompt26	"OPTIONS:"		//25
#define Prompt27	"GROSS SALES"		//26
#define Prompt28	" TAX"			//27
#define Prompt29	" PAGE"		//28   ???
#define Prompt30	"No.#:"		//29
#define Prompt31	"SERVICE"		//30
#define Prompt32	"PREV. BALANCE "		//31
#define Prompt33	"Z COUNT"		//32
#define Prompt34	"CLEAR"		//33
#define Prompt35	"SYSTEM REPORT"	//34
#define Prompt36	" GROSS PROFIT"		//35
#define Prompt37	"STOCK UPDATE"	//36
#define Prompt38	"FORMER PB:"		//37
#define Prompt39	"CREDIT CARD#"	//38
#define Prompt40	"NEW TABLE:"		//39
#define Prompt41	"GUESTS"		//40
#define Prompt42	"EXCHANGE"		//41
#define Prompt43	"INSERT"		//ccr  42 Add random number
#define Prompt44	"DELETE"		//ccr  43 delete random number
#define Prompt45	"DISCOUNT 1"		//44
#define Prompt46	"DISCOUNT 2"		//45
#define Prompt47	"SALES"		//46
#define Prompt48	"MIX-MATCH"		//47
#define Prompt49	"STOCK"		//48
#define Prompt50	"OFFER"		//49
#define Prompt51	"OPTIONS"			//50 for options
#define Prompt52	"KITCHEN PRT"		//51 for KP option
#define Prompt53	"FIXED DISCOUNT"	//52 Options for Discount
#define Prompt54	"FLOAT DISCOUNT"	//53
#define Prompt55	"FIXED+FLOAT"		//54
#define Prompt56	"OPEN()"		//55 Options for PBFunction
#define Prompt57	"OP_ADD"		//56
#define Prompt58	"SERVICE"		//57
#define Prompt59	"CONFIRM"		//58
#define Prompt60	"PRINT/OPEN"		//59
#define Prompt61	"PRINT BILL"		//50
#define Prompt62	"CANCEL"		//61
#define Prompt63	"SPLIT BILL"		//62
#define Prompt64	"TRANSFER"		//63
#define Prompt65	"MOVE TO"		//64
#define Prompt66	"GUEST"		//65
#define Prompt67	"JOLLY ?"		//66
#define Prompt68	"POINT ?"		//67
#define Prompt69	"DECREASE ?"		//68 ???
#define Prompt70	"CHIP CARD?"		//69
#define Prompt71	"DISCOUNT"		//70
#define Prompt72	"CASH"		//71
#define Prompt73	"CREDIT"	//72
#define Prompt74	"CARD INFO.PRT"		//73
#define Prompt75	"AUTO DISCOUNT "	//74
#define Prompt76	"POINTS"		//75
#define Prompt77	"<CASH> CLOSE"	//76 ZWQ
#define Prompt78	"CHARGE/DISCHG?"	//77
#define Prompt79	"EXPIRED DATE "		//78

//Option for dept==================

#define Prompt80	"ZERO PRICE:"		// 79	Ccr "��ֹ��۸�"		//JZHLJGE
#define Prompt81	"SEPARAT LINE"		// 80	Ccr "��ӡ�ָ���"		//DYFGXIAN
#define Prompt82	"SINGLE ITEM:"		// 81	Ccr "��������:"		//DXXSHOU
#define Prompt83	"DISCOUNT 1:"		// 82 	Ccr "�ۿ��� 1:"		//ZHKXIANG1
#define Prompt84	"DISCOUNT 2:"		// 83 	Ccr "�ۿ��� 2:"		//ZHKXIANG2
//Option for KP===================
#define Prompt85	"PRINT TOTAL:"		// 84	Ccr "��ӡ�ܶ�:"		//KPDYZE
#define Prompt86	"COMBINATION:"		// 85	Ccr "����ͬ��ӡ"		//KPCXTDY
#define Prompt87	"SORTED:"		// 86	Ccr "�˲�ͬ��ӡ"		//KPCBTDY  ZWQ
//Options for tend=================
#define Prompt88	"OPEN DRAWER:"		// 87	Ccr "��Ǯ��:"		//DKQXIANGF
#define Prompt89	"AMT.COMPULSORY"	// 88	Ccr "������:"		//SHRJE
#define Prompt90	"AMT.FORBIDDEN:"	// 89	Ccr "��ֹ����:"		//JZHSHRU
#define Prompt91	"INPUT CODE:"		// 90	Ccr "�������:"		//SHRHMA
#define Prompt92	"TIP:"			// 91	Ccr "����ΪС��"		//ZHLXFEI
//Options for PoRa=================
#define Prompt93	"OPEN DRAWER:"		// 92	Ccr "��Ǯ��:"		//DKQXIANGP
#define Prompt94	"<TENDER>:"		// 93	Ccr "���ʽ��"		//FKFSHJIAN
#define Prompt95	"DEPOSIT:"		// 94	Ccr "������:"		//CRJE
#define Prompt96	"TYPE:"			// 95	Ccr "���/����"		//RJCHJIN
//Option for Disc==================
#define Prompt97	"PRINT DISC.:"		// 96	Ccr "��ӡ�ۿ۶�"		//DYZHKE
#define Prompt98	"DISCOUNT 1:"		// 97	Ccr "ʹ���ۿ�1:"		//SHYZHK1
#define Prompt99	"DISCOUNT 2:"		// 98	Ccr "ʹ���ۿ�2:"		//SHYZHK2
//Options for currency==============
#define Prompt100	"CHANGE:"		// 99	Ccr "����������"		//MCHJZHLIN
//Options for Draw================
#define Prompt101	"NON DECIMAL:"		// 100	Ccr "��С����:"		//WXSHDIAN
#define Prompt102	"OPEN DRAWER:"		// 101	Ccr "��Ǯ��:"		//DKQXIANGD
//Options for Tax=================
#define Prompt103	"ADD ON:"		// 102	Ccr "Ӫҵ/��ֵ/"        //YYZZHI
#define Prompt104	"PRINT TAX:"		// 103	Ccr "��ӡ˰����"		//DYSHLXIANG
#define Prompt105	"PRINT ZERO:"		// 104	Ccr "��ӡ0˰��"		//DYLSHXXI
#define Prompt106	"GST:"			// 105	Ccr "ΪGST��˰"		//WGSTSHUI
#define Prompt107	"PRINT TAX.AMT:"		// 106	Ccr "��ӡ˰��:"		//DYSHE
//Options for clerk================
#define Prompt108	"VOID:"			// 107	Ccr "ȡ������:"		//QXXZHI
#define Prompt109	"CORRECT:"		// 108	Ccr "��������:"		//GGXZHI
#define Prompt110	"CANCEL:"		// 109	Ccr "ȡ������:"		//QXJYIXZHI
#define Prompt111	"REFUND:"		// 110	Ccr "�˻�����:"		//THXZHI
#define Prompt112	"%DISCOUNT:"		// 111	Ccr "%�ۿ�����:"		//BFBZHKXZHI
#define Prompt113	"%SURCHARGE:"	// 112	Ccr "%�ӳ�����:"		//BFBJCHXZHI
#define Prompt114	"NET DIS/SURCH."	// 113	Ccr "+-�������"		//JJJEXZHI
#define Prompt115	"TRAINING MODE:"	// 114	Ccr "��ѵģʽ:"		//PSHMSHI
////////////////////////////////////////////////////////////////
#define DayCap1		"MONDAY  "
#define DayCap2		"TUESDAY "
#define DayCap3		"WEDNSDAY"
#define DayCap4		"THURSDAY"
#define DayCap5		"FRIDAY  "
#define DayCap6		"SATURDAY"
#define DayCap7		"SUNDAY  "
#if (PRTLEN<25)
#define TitleN1		"ITEM     QTY    AMT"//======MAX LENGTH:20
#elif (PRTLEN<=36)
#define TitleN1		"ITEM      QTY      PRI     AMT"//======MAX LENGTH:32
#else
#define TitleN1		"ARTICLE       QUANTITY    PRICE       AMOUNT "//======MAX LENGTH:45
#endif
#define MessageF1	" INVALID ENTRY"		/* 1 */
#define MessageF2	"UNDEFINED CODE!"	/* 2 */
#define MessageF3	"IN TENDERING "		/* 3 */
#define MessageF4	"  INVALID DATE"		/* 4 */
#define MessageF5	"  INVALID TIME"			/* 5 */
#define MessageF6	" ENTER AMOUNT"		/* 6 */
#define MessageF7	"UNKNOWN ARTICLE"		/* 7 */
#define MessageF8	"NO ENTRY ALLOWED"         /* 8 */
#define MessageF9	"TABLE STILL OPEN"		/* 9 */
#define MessageF10	"NO SPLIT TENDER"		/* 10 */
#define MessageF11	"TABLE OPENED"		/* 11 */
#define MessageF12	"UNKNOWN TABLE"		/* 12 */
#define MessageF13	"TABLE REQUIRED"		/* 13 */
#define MessageF14	"TABLE NOT OPEN"		/* 14 */
#define MessageF15	"NO TRACK BUFFER"		/* 15 */
#define MessageF16	"TRACKBUFFER FULL"		/* 16 */
#define MessageF17	"** IN TRADING **"		/* 17 */
#define MessageF18	"UNKNOWN OPER."		/* 18 */
#define MessageF19	"UNKNOWN REPORT"		/* 19 */
#define MessageF20	"* BUF.OVERFLOW *"		/* 20 */
#define MessageF21	"ARTICLE NOT USED"		/* 21 */
#define MessageF22	" ENTRY TO HIGH"		/* 22 */ //???
#define MessageF23	"CHECK KP PRINTER"		/* 23 */
#define MessageF24	"NO PAPER IN SLIP"		/* 24 */
#define MessageF25	" NEW SLIP PAPER"		/* 25 */
#define MessageF26	"INVOICE NUMBER :"		/*"NOT CHECKED OUT"  26 */
#define MessageF27	"STILL IN CK OUT"		/* 27 */
#define MessageF28	"SUSPEND/RECALL"		/*"ONLY CHECK OUT"28 */
#define MessageF29	"OVER MAX COVERS"		/* 29 */
#define MessageF30	" ONLY WITH ITEM"		/* 30 */
#define MessageF31	"KP ERROR!"			/* 31 */
#define MessageF32	"MAX 4 MODIFIERS"		/* 32 */
#define MessageF33	"CHECK SLIP PRINT"		/* 33 */
#define MessageF34	"  WRONG OPER."		/* 34 */
#define MessageF35	"MANAGER KEY REQ"		/* 35 */
#define MessageF36	"**  **"					/* 36 */
#define MessageF37	"**RECEIPT COPY**"		/* 37 */
#define MessageF38	"* SPLIT - BILL *"			/* 38 */
#define MessageF39	"NEAREND R OR J !"		/* 39 */
#define MessageF40	"ENTER NUMBER !!"		/* 40 */
#define MessageF41	"NOT WITH SPLITBI"		/* 41 */
#define MessageF42	"TRANSFERRED TO :"		/* 42 */
#define MessageF43	"*TRAINNING MODE*"		/* 43 */
#define MessageF44	"**INITIALIZING**"		/* 44 */
#define MessageF45	"*** POWER ON ***"		/* 45 */
#define MessageF46	"NOT AUTHORIZED !"		/* 46 */
#define MessageF47	"*INVENTORY +/-*"		/* 47 */ //ZWQ
#define MessageF48	"**CHANGE PRICE**"		/* 48 *///Ccr 	"*** ��Ʒ��� ***"         /* 48 */
#define MessageF49	"KP #1"			/* 49 */
#define MessageF50	"KP #2"			/* 50 */
#define MessageF51	"KP #3"			/* 51 */
#define MessageF52	"KP #4"			/* 52 */
#define MessageF53	"KP #5"			/* 53 */
#define MessageF54	"KP #6"			/* 54 */
#define MessageF55	"KP #7"			/* 55 */
#define MessageF56	"KP #8"			/* 56 */
#define MessageF57	"**** CANCEL ****"		/* 57 *///Ccr 	"***** ȡ�� *****"         /* 57 */
#define MessageF58	"PROFORMA INVOICE"		/* 58 */
#define MessageF59	"KP TOTAL"			/* 59 */
#define MessageF60	"OPERATOR NIL"			/* 60 */

#define MonthCap1	"JANUARY "
#define MonthCap2	"FEBRUARY"
#define MonthCap3	"MARCH   "
#define MonthCap4	"APRIL   "
#define MonthCap5	"MAY     "
#define MonthCap6	"JUNE    "
#define MonthCap7	"JULY    "
#define MonthCap8	"AUGUST  "
#define MonthCap9	"SEPTMBER"
#define MonthCap10	"OCTOBER "
#define MonthCap11	"NOVEMBER"
#define MonthCap12	"DECEMBER"

#if (DD_LCD_1601==1) //  MAX LENGTH :8
#define LineCap1		"YES"			/*    0     */
#define LineCap2			"NO"			/*    1     */
#define LineCap3			"CAPTION"		/*    2     */
#define LineCap4			"DEPART"		/*    3     */
#define LineCap5			"GROUP"			/*    4     */
#define LineCap6			"SYS FLAG"			/*    5     */
#define LineCap7			"PRINT"			/*    6     */
#define LineCap8			"OPTION"			/*    7     */
#define LineCap9			"EXTRA KP"		/*    8 KP EP = extra printer     */
#define LineCap10			"TAX USED"		/*    9     */
#define LineCap11			"LOC"			/*    10     */
#define LineCap12			"PRICE 1"			/*    11     */
#define LineCap13			"PRICE 2"			/*    12    */
#define LineCap14			"PRICE 3"			/*    13    */
#define LineCap15			"PRICE 4"			/*    14    */
#define LineCap16			"COST"		/*    15     */  //ZWQ
#define LineCap17			"FIXED"			/*    16 fixed     */
#define LineCap18			"MAX"			/*     17 max      */
#define LineCap19			"FIXED"			/*    18     */
#define LineCap20			"MAX"			/*    19     */
#define LineCap21			"TAX RATE"		/*    20     */
#define LineCap22			"BUY RATE"		/*    21     */
#define LineCap23			"SEL RATE"		/*    22     */
#define LineCap24			"START"			/*    23     */
#define LineCap25			"DRAWER"		/*    24     */
#define LineCap26			"OTD"			/*    25 ��������С��    */
#define LineCap27			"PRT TYPE"		/*    26     */ //???
#define LineCap28			"PERIOD"			/*    27     */
#define LineCap29			"REP TYPE"		/*    28     */
#define LineCap30			"PREFIX"			/*    29     */
#define LineCap31			"LINK"			/*    30     */
#define LineCap32			"KEY CODE"	/*    31     */
#define LineCap33			"MANAGE-K"			/*    32     */
#define LineCap34			"TYPE"			/*    33     */
#define LineCap35			"DATE FR"		/*    34  MAX.Length<=7    */
#define LineCap36			"DATE TO"		/*    35  MAX.Length<=7     */
#define LineCap37			"TIME FR"		/*    36       */
#define LineCap38			"TIME TO"			/*    37     */
#define LineCap39			"WEEK DAY"		/*    38     */
#define LineCap40			"DISCOUNT"		/*    39     */
#define LineCap41			"PACK QTY"		/*    40     */
#define LineCap42			"U.PRICE"		//     41
#define LineCap43			"P.PRICE"		//     42
#define LineCap44			"PROTOCOL"		//     43
#define LineCap45			"TELE#"		    //     44
#define LineCap46			"PASSWORD"		//     45
#define LineCap47			"FREQUENT"		//     46
#define LineCap48			"MINIMUM"		//     47
#define LineCap49			"PORT"			//     48
#define LineCap50			"VALUE"			//     49
#define LineCap51			"GRAPHIC"		//     50
#define LineCap52			"SLIPTYPE"		//     51
#define LineCap53			"BLANKLIN"		//     52  ???
#define LineCap54			"LINEPAGE"		//     53
#define LineCap55			"PRT INFO"		//     54
#define LineCap56			"SECOND"			//     55
#define LineCap57			"LEFT MAR"		//     56
#define LineCap58			"POINT"			//     57
#define LineCap59			"PRILEVEL"			//     58
#define LineCap60			"CONFIRM?"		//     59
#define LineCap61			"FOREGIFT"		//     60
#define LineCap62			"POS CODE"		//     61
#define LineCap63			"USE CASH"		//     62
#define LineCap64			"DEADLINE"		//     63
#else //MAX LENGTH :12
#define LineCap1			"YES"			/*    0     */
#define LineCap2			"NO"			/*    1     */
#define LineCap3			"CAPTION"		/*    2     */
#define LineCap4			"DEPART"		/*    3     */
#define LineCap5			"GROUP"			/*    4     */
#define LineCap6			"SYSTEM FLAG"			/*    5     */
#define LineCap7			"PRINT"			/*    6     */
#define LineCap8			"OPTION"			/*    7     */
#define LineCap9			"EXTRA KP"		/*    8 KP EP = extra printer     */
#define LineCap10			"TAX USED"		/*    9     */
#define LineCap11			"LOC"			/*    10     */
#define LineCap12			"PRICE 1"			/*    11     */
#define LineCap13			"PRICE 2"			/*    12    */
#define LineCap14			"PRICE 3"			/*    13    */
#define LineCap15			"PRICE 4"			/*    14    */
#define LineCap16			"COST"		/*    15     */
#define LineCap17			"FIXED"			/*    16 fixed     */
#define LineCap18			"MAX"			/*     17 max      */
#define LineCap19			"FIXED"			/*    18     */
#define LineCap20			"MAX"			/*    19     */
#define LineCap21			"TAX RATE"		/*    20     */
#define LineCap22			"BUYING RATE"		/*    21     */
#define LineCap23			"SELLING RATE"		/*    22     */
#define LineCap24			"START"			/*    23     */
#define LineCap25			"DRAWER"		/*    24     */
#define LineCap26			"OUT DRAWER"			/*    25     */
#define LineCap27			"PRINTER TYPE"		/*    26     */
#define LineCap28			"PERIOD"			/*    27     */
#define LineCap29			"REPORT TYPE"		/*    28     */
#define LineCap30			"PREFIX"			/*    29     */
#define LineCap31			"LINK"			/*    30     */
#define LineCap32			"KEY CODE"	/*    31     */
#define LineCap33			"MANAGER KEY"			/*    32     */
#define LineCap34			"TYPE"			/*    33     */
#define LineCap35			"DATE FROM"		/*    34      */
#define LineCap36			"DATE TO"		/*    35       */
#define LineCap37			"TIME FROM"		/*    36       */
#define LineCap38			"TIME TO"			/*    37     */
#define LineCap39			"WEEK DAY"		/*    38     */
#define LineCap40			"DISCOUNT"		/*    39     */
#define LineCap41			"PACK QTY."		/*    40     */
#define LineCap42			"UNIT PRICE"		//     41
#define LineCap43			"PACK PRICE"		//     42
#define LineCap44			"PROTOCOL"		//     43
#define LineCap45			"TELEPHONE"		//     44
#define LineCap46			"PASSWORD"		//     45
#define LineCap47			"FREQUENCY:"		//     46
#define LineCap48			"MINIMUM"		//     47
#define LineCap49			"PORT"			//     48
#define LineCap50			"VALUE"			//     49
#define LineCap51			"GRAPHIC"		//     50
#define LineCap52			"SLIP TYPE"		//     51
#define LineCap53			"BLANK LINE"		//     52
#define LineCap54			"LINE OF PAGE"		//     53
#define LineCap55			"PRINT INFO"		//     54
#define LineCap56			"SECOND"			//     55
#define LineCap57			"LEFT MARGIN"		//     56
#define LineCap58			"POINT"			//     57
#define LineCap59			"PRI LEVEL"			//     58
#define LineCap60			"CONFIRM ?"		//     59
#define LineCap61			"FOREGIFT"		//     60
#define LineCap62			"POS CODE"		//     61
#define LineCap63			"USE <CASH>"		//     62
#define LineCap64			"DEADLINE"		//     63
#endif
//MAX LENGTH : 12(tCAPWIDTH),For SETUP
#define TypeCap1			"DEPARTMENT"		//SETDEPT    /*    0     */
#define TypeCap2			"PLU"			    //SETPLU     /*    1     */
#define TypeCap3			"TAX"			    //SETTAX     /*    2     */
#define TypeCap4			"HEADER"		    //SETHEAD    /*    3     */
#define TypeCap5			"DISCOUNT"		    //SETDISC    /*    4     */
#define TypeCap6			"SALESPERSON"		//SETSALER   /*    5     */
#define TypeCap7			"SYSTEM SETUP"		//SETSYSFLAG /*    6 system flags     */
#define TypeCap8			"CURRENCY"		    //SETCURR    /*    7     */
#define TypeCap9			"PORT 1"			//SETPORT1   /*    8     */
#define TypeCap10			"PORT 2"		    //SETPORT2   /*    9     */
#define TypeCap11			"PORT 3"			//SETPORT3   /*    18     */
#define TypeCap12			"DATE"			    //SETDATE    /*    10     */
#define TypeCap13			"TIME"			    //SETTIME    /*    11     */
#define TypeCap14			"GRAPHIC"		    //SETGRAP    /*    12     */
#define TypeCap15			"GROUP"			    //SETGROUP   /*    13     */
#define TypeCap16			"TENDER"		    //SETTEND    /*    14     */
#define TypeCap17			"CHIP CARD"		    //SETIC      /*    15     */
#define TypeCap18			"PROMOTION"		    //SETPROM    /*    16     */
#define TypeCap19			"PREV. BALANCE"		//SETPBF     /*    17     */
#define TypeCap20			"KITCHEN PRINTER"	//SETKP      	/*    21     */
#define TypeCap21			"OPERATOR"		    //SETCLERK   /*    23     */
#define TypeCap22			"MODIFIER"		    //SETMODIF   /*    23     */
#define TypeCap23			"TABLE NAME"		//SETPBINF   /*    24 PB Info     */
#define TypeCap24			"CORRECTION"		//SETCORR    /*    25     */
#define TypeCap25			"TIME ZONE"	        //SETZONES   /*    26     */
#define TypeCap26			"KEYBOARD"		    //SETKEYB    /*    27 keyboard     */
#define TypeCap27			"REPORT"		    //SETREPTYPE /*    28 user reports     */
#define TypeCap28			"REPORT CAPTION"	//SETREPORT  	/*    29 report messages     */
#define TypeCap29			"OFFER"			    //SETOFF     /*    30     */
#define TypeCap30			"PO&RA"			    //SETPORA    /*    31     */
#define TypeCap31			"DRAWER"		    //SETDRAWER  /*    32     */
#define TypeCap32			"TRAILER"			//SETTRAIL   /*    33     */
#define TypeCap33			"SLIP PRINTER"		//SETSP      /*    34     */
#define TypeCap34			"SLIP HEADER"		//SETSHEAD   /*    35 Slip head(lyq added 20040331)    */
#define TypeCap35			"BLOCKED CARD"		//SETBLOCKIC //     36 ccr chipcard
#define TypeCap36			"NET WORK"		    //SETIP      //     37 ccr IP address
#define TypeCap37			"GPRS FUNCTIONS"	//SETGPRSFUNC
#define TypeCap38           "NET  FUNCTIONS"    //SETETHERNETFUNC
#else//
#define Prompt1				"TOTAL   "
#define Prompt2				"SUBTOTAL"			//1
#define Prompt3				"SPENDING"
#define Prompt4				" NET AMT"			//3
#define Prompt5				" PRICE  "			//4
#define Prompt6				" TRADE  "	//5
#define Prompt7				" QUANTITY"			//6
#define Prompt8				" AMT    "			//7
#define Prompt9				"COLLECT "			//8 ZWQ
#define Prompt10			"CHANGE  "			//9
#define Prompt11			" "       		/* 10 */
#define Prompt12			" "		 		/* 11 */
#define Prompt13			"-"		 		/* 12 */
#define Prompt14			"-"		 		/* 13 */
#define Prompt15			"STANDARD"         /* 14 */
#define Prompt16			"OPERATOR"	//15
#define Prompt17			"    HOUR"				//16
#define Prompt18			" "				//17
#define Prompt19			" --"				//18
#define Prompt20			"REPORT  "         /* 19 */
#define Prompt21			" RETURN "         /* 20 */
#define Prompt22			" DISC   "			//21
#define Prompt23			" COST   "			//22
#define Prompt24			"TABLE#  "			//23
#define Prompt25			"CHECK# "   /* 24 used for Register ID with EFT */
#define Prompt26			"OPTIONS:"			//25
#define Prompt27			"GROSS SALES"       //26
#define Prompt28			" TAX    "         //27
#define Prompt29			" PAGE   "         //28
#define Prompt30			"No.#: "         //29
#define Prompt31			"SERVICE "   //30
#define Prompt32			"P.B.    "         //31
#define Prompt33			"Z COUNT " //32
#define Prompt34			"CLEAR   "         //33
#define Prompt35			"S-REPORT"         //34
#define Prompt36			" GROSS  "         //35
#define Prompt37			"STOCK   " //36
#define Prompt38			"FORMER: "       //37
#define Prompt39			"CREDIT# "       //38
#define Prompt40			"TABLE:  "       //39
#define Prompt41			"GUESTS  "         	//40
#define Prompt42			"EXCHANGE"         	//41
#define Prompt43			"INSERT  "         		//ccr  42 Add random number
#define Prompt44			"DELETE  "         		//ccr  43 delete random number
#define Prompt45			"DISC 1  "         //44
#define Prompt46			"DISC 2  "         //45
#define Prompt47			"SALE    "         //46
#define Prompt48			"PREFER  "		//47
#define Prompt49			"STOCK   "		//48
#define Prompt50			"OFFER   " 	//49
#define Prompt51			"OPTION  "								//50 for options
#define Prompt52			"USE KP  "								//51 for KP option
#define Prompt53			"FI_DIS  "								//52 Options for Discount
#define Prompt54			"FL_DIS  "                             //53
#define Prompt55			"F2_DIS  "                             //54
#define Prompt56			"OPEN()  "							//55 Options for PBFunction
#define Prompt57			"OP_ADD  "                             //56
#define Prompt58			"CLOS_T  "                             //57
#define Prompt59			"CONF_   "                             //58
#define Prompt60			"PROPEN  "                             //59
#define Prompt61			"PRBILL  "                             //50
#define Prompt62			"CANCEL  "                             //61
#define Prompt63			"S_BILL  "                            //62
#define Prompt64			"X_BILL  "                             //63
#define Prompt65			"X_CLERK "                             //64
#define Prompt66			"CUSTNO  "                             //65
#define Prompt67			"JOLLY?  "								//66
#define Prompt68			"POINT?  "								//67
#define Prompt69			"DECREASE"								//68
#define Prompt70			"ENABLE ?"								//69
#define Prompt71			"TYPE0 ? "								//70
#define Prompt72			"TYPE1 ? "								//71
#define Prompt73			"TYPE2 ? "								//72
#define Prompt74			"PRN.IC? "								//73
#define Prompt75			"AUTODIS?"								//74
#define Prompt76			"AUTOPOI?"								//75
#define Prompt77			"T_CC?   "								//76
#define Prompt78			"ADD/SUB?"								//77
#define Prompt79			"IC_DEAD?"								//78
#define Prompt80			"DUAL PRI"
#define DayCap1				"MONDAY  "
#define DayCap2				"TUESDAY "
#define DayCap3				"WEDNSDAY"
#define DayCap4				"THURSDAY"
#define DayCap5				"FRIDAY  "
#define DayCap6				"SATURDAY"
#define DayCap7				"SUNDAY  "
#if (PRTLEN<24)
#define TitleN1	"ITEM     QTY    AMT "
/*	             12345678901234567890123*/
#elif (PRTLEN<36)
#define TitleN1	"ITEM      QTY      PRI   AMT "
/*	             12345678901234567890123456789012*/
#else
#define TitleN1	"ITEM                 QUANTITY     PRICE      AMOUNT"
/*	             123456789012345678901234567890123456*/
#endif
//======MAX LENGTH:16
#define MessageF1	" INVALID ENTRY"		/* 1 */
#define MessageF2	"UNKNOWN KEYCODE!"	/* 2 */
#define MessageF3	"STILL IN TENDER"		/* 3 */
#define MessageF4	"  INVALID DATE"		/* 4 */
#define MessageF5	"  INVALID TIME"			/* 5 */
#define MessageF6	" ENTER AMOUNT"		/* 6 */
#define MessageF7	"UNKNOWN ARTICLE"		/* 7 */
#define MessageF8	"NO ENTRY ALLOWED"         /* 8 */
#define MessageF9	" PB STILL OPEN"		/* 9 */
#define MessageF10	"NO SPLIT TENDER"		/* 10 */
#define MessageF11	"PB ALREADY OPEN"		/* 11 */
#define MessageF12	" UNKNOWN  PB"		/* 12 */
#define MessageF13	" PB REQUIRED"		/* 13 */
#define MessageF14	"  PB NOT OPEN"		/* 14 */
#define MessageF15	"NO TRACK BUFFER"		/* 15 */
#define MessageF16	"TRACKBUFFER FULL"		/* 16 */
#define MessageF17	"** IN TRADING **"
#define MessageF18	"UNKNOWN OPER."         /* 18 */
#define MessageF19	"UNKNOWN REPORT"         /* 19 */
#define MessageF20	"* BUF.OVERFLOW *"
#define MessageF21	"ARTICLE NOT USED"		/* 21 */
#define MessageF22	" ENTRY TO HIGH"		/* 22 */
#define MessageF23	"CHECK KP PRINTER"		/* 23 */
#define MessageF24	"NO PAPER IN SLIP"		/* 24 */
#define MessageF25	" NEW SLIP PAPER"		/* 25 */
#define MessageF26	"INVOICE NUMBER :"		/*"NOT CHECKED OUT"  26 */
#define MessageF27	"**    **"
#define MessageF28	"SUSPEND/RECALL"         /*"ONLY CHECK OUT"28 */
#define MessageF29	"OVER MAX COVERS"         /* 29 */
#define MessageF30	" ONLY WITH ITEM"         /* 30 */
#define MessageF31	"KP ERROR!"
#define MessageF32	"MAX 4 MODIFIERS"         /* 32 */
#define MessageF33	"CHECK SLIP PRINT"         /* 33 */
#define MessageF34	"  WRONG OPER."        /* 34 */
#define MessageF35	"MANAGER KEY REQ"        /* 35 */
#define MessageF36	"**  **"         /* 36 *///Ccr 	"** �û��ж� ! **"         /* 36 */
#define MessageF37	"**COPY RECEIPT**"         /* 37 *///Ccr 	"*** �����վ� ***"         /* 37 */]
#define MessageF38	"* SPLIT - BILL *"         /* 38 */
#define MessageF39	"NEAREND R OR J !"         /* 39 */
#define MessageF40	"ENTER NUMBER !!"         /* 40 */
#define MessageF41	"NOT WITH SPLITBI"         /* 41 */
#define MessageF42	"TRANSFERRED TO :"         /* 42 */
#define MessageF43	"*TRAINNING MODE*"         /* 43 *///Ccr 	"*** ��ѵ״̬ ***"         /* 43 */
#define MessageF44	"**INITIALIZING**"         /* 44 *///Ccr 	"** �����ʼ�� **"         /* 44 */
#define MessageF45	"*** POWER ON ***"         /* 45 *///Ccr 	"***** �ӵ� *****"         /* 45 */
#define MessageF46	"NOT AUTHORIZED !"         /* 46 */
#define MessageF47	"*I/D INVENTORY*"         /* 47 *///Ccr 	"*** ������� ***"         /* 47 */
#define MessageF48	"**OTHER PRICE**"         /* 48 *///Ccr 	"*** ��Ʒ��� ***"         /* 48 */
#define MessageF49	"KP #1"         /* 49 */
#define MessageF50	"KP #2"         /* 50 */
#define MessageF51	"KP #3"         /* 51 */
#define MessageF52	"KP #4"         /* 52 */
#define MessageF53	"KP #5"         /* 53 */
#define MessageF54	"KP #6"         /* 54 */
#define MessageF55	"KP #7"         /* 55 */
#define MessageF56	"KP #8"         /* 56 */
#define MessageF57	"**** CANCEL ****"         /* 57 *///Ccr 	"***** ȡ�� *****"         /* 57 */
#define MessageF58	"PROFORMA INVOICE"         /* 58 */
#define MessageF59	"KP TOTAL"         /* 59 */
#define MessageF60	"OPERATOR NIL"         /* 60 */

#define MonthCap1	"JANUARY "
#define MonthCap2	"FEBRUARY"
#define MonthCap3	"MARCH   "
#define MonthCap4	"APRIL   "
#define MonthCap5	"MAY     "
#define MonthCap6	"JUNE    "
#define MonthCap7	"JULY    "
#define MonthCap8	"AUGUST  "
#define MonthCap9	"SEPTMBER"
#define MonthCap10	"OCTOBER "
#define MonthCap11	"NOVEMBER"
#define MonthCap12	"DECEMBER"
//======MAX LENGTH:4
#define LineCap1		"YES"     /* 0 */
#define LineCap2		"NO"     /* 1 */
#define LineCap3		"CAP-"     /* 2 */
#define LineCap4		"DEPT"     /* 3 */
#define LineCap5		"GROU"     /* 4 */
#define LineCap6		"SFG"     /* 5 */
#define LineCap7		"PRT"     /* 6 */
#define LineCap8		"OPT"     /* 7 */
#define LineCap9		"E_KP"     /* 8 KP EP = extra printer */
#define LineCap10		"TAX-"     /* 9 */
#define LineCap11		"LOC"     /* 10 */
#define LineCap12		"Pr1"     /* 11 */
#define LineCap13		"Pr2"     /* 12*/
#define LineCap14		"Pr3"     /* 13*/
#define LineCap15		"Pr4"     /* 14*/
#define LineCap16		"CPR"     /* 15 */
#define LineCap17		"FIX"     /* 16 fixed */
#define LineCap18		"MAX"     /*  17 max  */
#define LineCap19		"FIX_"     /* 18 */
#define LineCap20		"MAX_"     /* 19 */
#define LineCap21		"RAT"     /* 20 */
#define LineCap22		"BUY"     /* 21 */
#define LineCap23		"SEL"     /* 22 */
#define LineCap24		"STAT"     /* 23 */
#define LineCap25		"DR1"     /* 24 */
#define LineCap26		"OTD"     /* 25 */
#define LineCap27		"KP_"     /* 26 */
#define LineCap28		"PER"     /* 27 */
#define LineCap29		"POI"     /* 28 */
#define LineCap30		"PRE"     /* 29 */
#define LineCap31		"LINK"     /* 30 */
#define LineCap32		"CODE"     /* 31 */
#define LineCap33		"NGR"		/* 32 */
#define LineCap34		"Type"		/* 33 */
#define LineCap35		"DtFr"		/* 34  */
#define LineCap36		"DtTo"		/* 35   */
#define LineCap37		"TmFr"		/* 36   */
#define LineCap38		"TmTo"		/* 37 */
#define LineCap39		"WDay"		/* 38 */
#define LineCap40		"DISC"		/* 39 */
#define LineCap41		"PKGN"		/* 40 */
#define LineCap42		"PriU"		// 41
#define LineCap43		"PriP"		// 42
#define LineCap44		"Prot"		// 43
#define LineCap45		"Tele"		// 44
#define LineCap46		"Pass"		// 45
#define LineCap47		"Freq"		// 46
#define LineCap48		"Min_"		// 47
#define LineCap49		"Port"		// 48
#define LineCap50		"Val_"		// 49
#define LineCap51		"Gra_"		// 50
#define LineCap52		"SpTy"		// 51
#define LineCap53		"TBLs"    // 52
#define LineCap54		"PgLs"		// 53
#define LineCap55		"Pinf"		// 54
#define LineCap56		"Seco"		// 55
#define LineCap57		"Lmge"     // 56
#define LineCap58		"Poi_"			// 57
#define LineCap59		"PriL"			// 58
#define LineCap60		"Conf"			// 59
#define LineCap61		"Fore"			// 60
#define LineCap62		"Pos_"			// 61
#define LineCap63		"T_CC"			// 62
#define LineCap64		"Time"			//63
//======MAX LENGTH:9
#define TypeCap1		"DEPT"     /* 0 */
#define TypeCap2		"PLU"     /* 1 */
#define TypeCap3		"TAX"     /* 2 */
#define TypeCap4		"HEADER"     /* 3 */
#define TypeCap5		"DISCOUNT"     /* 4 */
#define TypeCap6		"SALESMAN"     /* 5 */
#define TypeCap7		"SYS SETUP"     /* 6 system flags */
#define TypeCap8		"CURRENCY"     /* 7 */
#define TypeCap9		"PORT1"     /* 8 */
#define TypeCap10		"PORT2"     /* 9 */
#define TypeCap11		"PORT3"     /* 9 */
#define TypeCap12		"DATE"     /* 10 */
#define TypeCap13		"TIME"     /* 11 */
#define TypeCap14		"GRAPHIC"     /* 12 */
#define TypeCap15		"GROUP"     /* 13 */
#define TypeCap16		"SUB TEND_"     /* 14 */
#define TypeCap17		"CHIP CARD"     /* 15 */
#define TypeCap18		"PROMOTION"     /* 16 */
#define TypeCap19		"PB FUNC"     /* 17 */
#define TypeCap20		"K_PRINTER"     /* 21 */
#define TypeCap21		"OPERATORS"     /* 23 */
#define TypeCap22		"MODIFIER"     /* 23 */
#define TypeCap23		"TABLE DES"     /* 24 PB Info */
#define TypeCap24		"CORREC"     /* 25 */
#define TypeCap25		"TIME ZONE"     /* 26 */
#define TypeCap26		"KEYBOARD"     /* 27 keyboard */
#define TypeCap27		"REPORT"     /* 28 user reports */
#define TypeCap28		"REPORTDES"     /* 29 report messages */
#define TypeCap29		"OFFER"     /* 30 */
#define TypeCap30		"PO-RA"     /* 31 */
#define TypeCap31		"DRAW"     /* 32 */
#define TypeCap32		"TRAI"     /* 33 */
#define TypeCap33		"SLIP"     /* 34 */
#define TypeCap34		"SLIPHEAD"     /* 35 Slip head(lyq added 20040331)*/
#define TypeCap35		"BLOCKIC"	  // 36 ccr chipcard
#define TypeCap36		"NET WORK"	  // 37 ccr IP address
#define TypeCap37		"GPRS FUNC"	//SETGPRSFUNC
#define TypeCap38       "NET FUNCS"    //SETETHERNETFUNC
#endif


#if(DD_ZIP==1)
#define MessageE1	"ERROR0 FROM HOST"
#define MessageE3   "ERROR1 FROM HOST"
#else
#define MessageE1	"ERR0 FR HOST"
#define MessageE3   "Err1 Fr Host"
#endif

#define MessageE2	"ERR: TOO LONG FROM HOST"


#define MessageE4       "END  HOST"

#define MessageE5       "!!!! MEMORY OVERFLOW !!!!"
#define MessageE6       "         PLU INFO"
#define MessageE12      "PIC:"
#define MessageE13      "1.NORMAL PRINTING" 		//Normale
#define MessageE14      "2.DOUBL HIGH" 				//Doppia altezza
#define MessageE15      "3.~D~O~U~B~L ~W~I~D~T~H" 	//Raddoppio caratteri
#define MessageE16      "4.~D~O~U~B~L ~W~I~D~T~H" 	//Raddoppio caratteri
#define MessageE17      "5.~D~O~U~B~L ~H~I~G~H"		//Dopia altezza + Raddoppio caratteri
#define MessageE18       "!!!! FAT(PLU) ERROR !!!!"

#define MessageE7       "PLU "
#define MessageE8       "STOCK"
#define MessageE9       "CODE"
#define MessageE10      "PRICE"

#define MessageE20      "GRAPHIC 1"
#define MessageE21      "GRAPHIC 2"
#define MessageE22      "GRAPHIC 3"
#define MessageE23      "GRAPHIC 4"
#define MessageE25      "RAM SIZE:"
#define MessageE26      "ERROR AT:"
#define MessageE27      "PG RAM SIZE:"
#define MessageE28      "FORMAT ERROR ON DATETIME."

#define MessageE24      "-SUM:"

#define MessageE29      "PORT 1 TEST ERROR!"
#define MessageE30      "PORT 1 TEST OK!"
#define MessageE31      "PORT 2 TEST ERROR!"
#define MessageE32      "PORT 2 TEST OK!"

#define MessageE33_Err  "PORT 3 TEST ERROR!"
#define MessageE33_OK   "PORT 3 TEST OK!"

#define MessageE33      "CURRENT TIME:"
#define MessageE34      "****  PRINT INTERRUPTED ****"
#define MessageE35		"MODEM CONN_"
#define MessageE36		"FROM HOST"
#define MessageE37		"MODEM CLOS_"
#define MessageE38		"@UPDATE IS GOING....."
#define MessageE39		"UPDATE BIOS"
#define MessageE40		"UPDATE CLIB"
#define MessageE41		"UPDATE GRAP"
#define MessageE42		"Send to host"
#define MessageE43		"Send End."
#define MessageE44		"READ ERROR"
#define MessageE45		"SEND ERROR"
#define MessageE46		"Write Err"
#define MessageE47		"PRINT DOT EPSON"
#define MessageE48		"RESERVED"
#define MessageE49		"PRINTER ON"
#define MessageE50		"PRINTER OFF"
#define MessageE51		"FM:"
#define MessageE52		"EJ:"
#define MessageE53		"SIZE OF  EJ:  "
#define MessageE54		"EJ ERROR AT:  "
#define MessageE55		"Clear Fiscal Memory"
#define MessageE56		"FM ERROR AT:"
#define MessageE57		"SIZE OF FM:  "
#define MessageE58		"CLEAR REPORT"
#define MessageE59		"ECR LOCKED"
#define MessageE60		"**Copy for paper out**"
#define MessageE61		"Fiscal Memory Cleard!"
#define MessageE62		"Fiscal Memory Error!"
#define MessageE63		"EJ IS FULL"			//ZWQ
#define MessageE64		"PLU TEST"
#define MessageE65		"PLUs TOO LARGE"

#define MainMenu1		"1.Report Z By Day"// -> daily  report
#define MainMenu2		"2.Report FM By Day"//  -> fiscal memory report by day
#define MainMenu3		"3.Report FM By Month"//   -> fiscal memory report by months
#define MainMenu4		"4.Report FM By #Z"	//    -> fiscal memory report by Z number	""
#define MainMenu5		"5.Printer Status"	//    -> Printe status,
#define MainMenu6		"Menu   Enter"


#if DD_FISPRINTER
#define MessageM0		"Printer Status:"
#else
#define MessageM0		"ECR Status:"
#endif

#if (PRTLEN>30)
#define FISCALMESSAGE "@   INFORMATION ON FM & EJ"
#else
#define FISCALMESSAGE "@INFORMATION ON FM & EJ"
#endif

#define STOPMESS    "<Clear> To Stop."
#define CLEANFILES  "Clear Files?"


#define BADEJBYZ		 "**Error When Write To EJ**"	//ccr091228
#define PRINTZBADEJ	"Replace EJ."					//ccr091228
#define ZONLY			"Z ONLY"

#define DEVICECODE  "DEVICE:"    //PANAMA
#define FISCALNAME  "NAME:"    //PANAMA
#define FISCALADDR  "ADDR:"    //PANAMA
#define RIFCUSTOMER "CUSTOMER RIF:"

#define SELECTMESS  "    <SELECT>MENU"
#define ENTERMESS   "         <ENTER>"
#define EXITMESS   "          <EXIT>"

#define BUTTONBATLOW "S.Battery Low!"
#define CHARGEBATNOW "O.Battery Low!"

#define REPRN_PWON  "Re-Print When Power ON........."
#define REPRN_PAPERON  "Re-Print When Paper OK......"

#define CUMULATIVE  "   CUMULATIVE TOTALS"

#define SRAMNOTFOUND "no SRAM!HALT!" 
#define MsgSRAMNOTFOUND "SRAM NOT FOUND!"

#define MESG_FCName   "NAME:"	//1-�˿�����
#define MESG_FCAddr   "ADDR:"	//2-�˿͵�ַ
#define MESG_FCRUC	  "RUC:"	//3-�˿�RUC,
#define MESG_FVatNo   "FIS:"   //4-��������վݵĹ˿�˰����
#define MESG_FCDebit  "RCP#:"	//5-�����վݺ�
//01234567890123456789012345678901
#define MESG_CUSTOMER   "------Messages of Customer------"
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#define MESG_Z_BALANCE   "FREE CLOSURES IN FM"  //ccr2014-08-04 new
#define MESG_Z_START     " FIRST CLOSURE IN FM"      //ccr2014-08-04 new
#define MESG_Z_LAST      " LAST CLOUSURE IN FM"             //ccr2014-08-04 new

#define MESG_EJ_START    " STARTING DATE"      //ccr2014-08-04 new
#define MESG_EJ_LAST     " LAST DATE"             //ccr2014-08-04 new

#define MESG_ERASE_EJ    "Erase EJ........"       //ccr2014-08-04 new

#define MESG_EJ_ID      "EJ ID."
#define MESG_EJ_REC     "EJ REC."

#define MESG_Z_REMAIN   "Z-CLOUSURE CAN"

#endif

