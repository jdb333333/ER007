#define  PLU_C 2
#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"



/***************************************************************/

void GetPluOffSet()
{
	RamOffSet = (UnLong)ApplVar.PluNumber*ApplVar.AP.Plu.RecordSize+ApplVar.AP.StartAddress[AddrPLU];
}


void AddPluTotal()
{
    GetPluOffSet();
	RamOffSet += ApplVar.AP.Plu.TotalOffSet;
    for (ApplVar.PointerType = 0; ApplVar.PointerType < REPDEFMAX; ApplVar.PointerType++)
    {
		ApplVar.Size = ApplVar.AP.Plu.Size[ApplVar.PointerType];
		AddPointerTotal();
    }
}


void WritePluInventory()
{
    GetPluOffSet();
	RamOffSet += (ApplVar.AP.Plu.TotalOffSet - ApplVar.AP.Plu.InvSize);
	if (ApplVar.AP.Plu.InvSize)
	    WriteRam((BYTE *)&ApplVar.PluInventory, ApplVar.AP.Plu.InvSize);
}


void WritePlu()
{
    BYTE i;

    if (ApplVar.PluNumber < ApplVar.AP.Plu.Number)
    {
		GetPluOffSet();

		WriteRam(ApplVar.Plu.Random, ApplVar.AP.Plu.RandomSize);
		WriteRam(ApplVar.Plu.Name, ApplVar.AP.Plu.CapSize);
	    if (ApplVar.AP.OFFPrice.Number)
		    WriteRam((BYTE *)&ApplVar.Plu.OFFIndex,sizeof(ApplVar.Plu.OFFIndex));
		WriteRam(&(ApplVar.Plu.Dept), sizeof(ApplVar.Plu.Dept));
		if (TESTBIT(ApplVar.AP.Options.Plu, BIT1))      /* Large ApplVar.Dept ? */
			WriteRam((BYTE *)&ApplVar.Plu.DeptHi, sizeof(ApplVar.Plu.DeptHi));
		for(i = 0; i < ApplVar.AP.Plu.Level; i++)
	    	WriteRam(ApplVar.Plu.Price[i], ApplVar.AP.Plu.PriceSize);
		if (ApplVar.AP.Plu.Cost)
			WriteRam(ApplVar.Plu.Cost, ApplVar.AP.Plu.PriceSize);
		if (TESTBIT(ApplVar.AP.Options.Plu, BIT0))              /* ApplVar.Plu Link */
			WriteRam((BYTE *)&ApplVar.Plu.Link, sizeof(ApplVar.Plu.Link));
		if (ApplVar.AP.Plu.InvSize)
	    	WriteRam((BYTE *)&ApplVar.Plu.Inventory, ApplVar.AP.Plu.InvSize);
    }
}

void ReadPlu()
{
    BYTE i;
    BYTE temp[BCDLEN];

    GetPluOffSet();
    ReadRam(ApplVar.Plu.Random, ApplVar.AP.Plu.RandomSize);
    ReadRam(ApplVar.Plu.Name, ApplVar.AP.Plu.CapSize);
    if (ApplVar.AP.OFFPrice.Number)
	    ReadRam((BYTE *)&ApplVar.Plu.OFFIndex,sizeof(ApplVar.Plu.OFFIndex));
	else
		ApplVar.Plu.OFFIndex = 0;
    ApplVar.Plu.Name[ApplVar.AP.Plu.CapSize] = 0;
    ReadRam((BYTE *)&ApplVar.Plu.Dept, sizeof(ApplVar.Plu.Dept));
	ApplVar.PluDept = ApplVar.Plu.Dept;
	if (TESTBIT(ApplVar.AP.Options.Plu, BIT1))      /* Large ApplVar.Dept ? */
	{
		ReadRam((BYTE *)&ApplVar.Plu.DeptHi, sizeof(ApplVar.Plu.DeptHi));
		*(((BYTE *)&ApplVar.PluDept)+1) = ApplVar.Plu.DeptHi;
	}
    for(i = 0; i < ApplVar.AP.Plu.Level; i++)
		ReadRam(ApplVar.Plu.Price[i], ApplVar.AP.Plu.PriceSize);
    if (ApplVar.AP.Plu.Cost)
		ReadRam(ApplVar.Plu.Cost, ApplVar.AP.Plu.PriceSize);
	if (TESTBIT(ApplVar.AP.Options.Plu, BIT0))              /* ApplVar.Plu Link */
		ReadRam((BYTE *)&ApplVar.Plu.Link, sizeof(ApplVar.Plu.Link));
    if (ApplVar.AP.Plu.InvSize)
    {
		ApplVar.PluInventory = ZERO;
		ReadRam((BYTE *)&ApplVar.PluInventory, ApplVar.AP.Plu.InvSize);
		ApplVar.Plu.Inventory = ApplVar.PluInventory;
    }
	RESETBIT(ApplVar.MyFlags,PLUOFF);//PLUPACK);//ccr 050613
	RESETBIT(ART_LEVEL, BIT2);
#if (BARCUSTOMER==1)
	if (ApplVar.FBarcode==6)
		return;
#endif
    if ((ApplVar.CentralLock == MG || ApplVar.CentralLock == RG))//add by ccr,for OFF
    {
#if (BARCUSTOMER==1)
		if (ApplVar.BarCustomer.OFFIndex>0 && ApplVar.BarCustomer.DeptHi>0 && ApplVar.BarCustomer.DeptHi<=ApplVar.AP.Plu.Level)
			ApplVar.PluPriceLevel = ApplVar.BarCustomer.DeptHi-1;		//ccr chipcard
		else
#endif
		if (ApplVar.Plu.OFFIndex && ApplVar.Plu.OFFIndex<=ApplVar.AP.OFFPrice.Number)
		{
			ApplVar.OFFNumber = ApplVar.Plu.OFFIndex-1;
	    	ReadOFFPrice();
	    	if (ApplVar.OFFPrice.Type)
	    	{
	    		GetTimeDate(&Now);
	    		temp[3] = Now.month;	temp[2]=Now.day;
	    		temp[1] = Now.hour; 	temp[0]=Now.min;

	    		if (CWORD(temp[2]) >= CWORD(ApplVar.OFFPrice.DateFrom[0]) &&
	    			CWORD(temp[0]) >= CWORD(ApplVar.OFFPrice.TimeFrom[0]) &&
	    			CWORD(temp[2]) <= CWORD(ApplVar.OFFPrice.DateTo[0]) &&
	    			CWORD(temp[0]) <= CWORD(ApplVar.OFFPrice.TimeTo[0]) &&
	    			(ApplVar.OFFPrice.WeekDay & (1<<(Now.dow-1))))
	    		{
				    memset(ApplVar.Plu.Price[1], 0, sizeof(ApplVar.Plu.Price[0]));
					SETBIT(ART_LEVEL, BIT2);
	    			if (ApplVar.OFFPrice.Type == 1)
	    			{
						SETBIT(ApplVar.MyFlags,PLUPACK);
                        memset(temp,0,sizeof(temp));//ccr20120101
						ULongToBCDValue(temp,ApplVar.OFFPrice.OFFVal.TYPE1.NumItems);
						memcpy(ApplVar.Plu.Cost, temp,sizeof(ApplVar.Plu.Cost));
					    memset(ApplVar.Plu.Price[0], 0, sizeof(ApplVar.Plu.Price[0]));
					    memcpy(ApplVar.Plu.Price[0],ApplVar.OFFPrice.OFFVal.TYPE1.PriceU, ApplVar.AP.OFFPrice.PriUSize);
					    memcpy(ApplVar.Plu.Price[1],ApplVar.OFFPrice.OFFVal.TYPE1.PriceP, sizeof(ApplVar.OFFPrice.OFFVal.TYPE1.PriceP));
	    			}
	    			else
	    			{
						SETBIT(ApplVar.MyFlags,PLUDISC);
					    memcpy(ApplVar.Plu.Price[1],ApplVar.OFFPrice.OFFVal.Discount, 2);
	    			}
	    		}
	    	}
		}
#if DD_CHIPC
		else if (IC.CHIP_Flag>=0 && (IC.REC_Customer[CC_CLIST] & 3)>0 && (IC.REC_Customer[CC_CLIST] & 3)<ApplVar.AP.Plu.Level)//ccr chipcard
		{//ccr040805>>>>>>
			ApplVar.PluPriceLevel = (IC.REC_Customer[CC_CLIST] & 3);		//ccr chipcard
/*			i = (IC.REC_Customer[CC_CLIST] & 3)-1;		//ccr chipcard
			if (i)
			    memcpy(ApplVar.Plu.Price[0],ApplVar.Plu.Price[i], sizeof(ApplVar.Plu.Price[0]));*/
		}//ccr040805<<<<<<<<<<<<
#endif
    }
}

WORD GetPluNumber(BYTE a,BYTE* b)
/* if update == 1 then also return already deleted PLU */
{
	WORD plunum;

	RamOffSet = ApplVar.AP.StartAddress[AddrPLU];    /* start plu table */
	plunum = BinarySearch(b, ApplVar.AP.Plu.RecordSize, ApplVar.AP.Plu.RandomSize, ApplVar.AP.Plu.RNumber);
	return plunum;
}

short CheckRandomPlu(BYTE delete1,BYTE comp)
//0-add plu Random not found,1-delete plu if Random found
//1-data from computer,0-data from keyboard
{
    WORD mcount, c, r;
    BYTE i;
    UnLong bcount, endaddr ;   /* unsigned long bcount, endaddr; */

    if (!comp)      /* via keyboard then confirm */
    {
		MemSet(SysBuf, DISLEN, ' ' );
		strcpy(SysBuf+1, Prompt.Caption[42 + delete1]);
		SysBuf[sizeof(Prompt.Caption[42])] = '?';
		ApplVar.PrintLayOut = 0x03;     /* receipt and journal */
		PutsO(SysBuf);
#if !defined(DEBUGBYPC)
		while (!KbHit()) FM_EJ_Exist();
#endif
		if (Getch() != ApplVar.AP.FirmKeys[ID_PRGENTER])  /* CR is accept */
		    return 0;

    }
    if (delete1)
    {
		ApplVar.AP.Plu.RNumber--;
		MemSet(&ApplVar.Plu, sizeof(ApplVar.Plu), 0);   /* clear plu record */
    }
    else if (ApplVar.AP.Plu.RNumber >= ApplVar.AP.Plu.Number) /* full ? */
    {
		if (!comp)
		    ApplVar.ErrorNumber=ERROR_ID(CWXXI06);
		return 0;
    }

    bcount = ApplVar.AP.Plu.RNumber;     /* calculate bytes to move  1st part */
    bcount = bcount * ApplVar.AP.Plu.RecordSize+ ApplVar.AP.StartAddress[AddrPLU];
    endaddr = bcount;       /* save endaddress for insertion */
    bcount -= RamOffSet;
    c = bcount / 128 ;        /* /128L number of 128 byte blocks */
    r = bcount % 128 ;        /*  %128L remainder */
    mcount = 128;
    i = 0;
    if (delete1)
    {
		for(;;)     /* move <-- length bcount */
		{
		    if (!c)
		    {
				if (!r)
				    break;
				mcount = r;     /* remainder */
				r = 0;
		    }
		    else
				c--;
		    if (!comp && !(c % 128))
		    {
				SysBuf[0] = ' ';
				SysBuf[1] = 0;
				if (!i)
				    strcpy(SysBuf + 1, Prompt.Caption[43]);
				PutsO(SysBuf);
				i ^= 1;
		    }
	      	RamOffSet += ApplVar.AP.Plu.RecordSize;
		    ReadRam(SysBuf, mcount);
	     	RamOffSet -= (ApplVar.AP.Plu.RecordSize + mcount);
		    WriteRam(SysBuf, mcount);
		}
		RamOffSet = endaddr;
    }
    else
    {
		bcount = RamOffSet;     /* save insert address */
		for(;;)     /* move --> length bcount */
		{
		    if (!c)
		    {
				if (!r)
				    break;
				mcount = r;     /* remainder */
				r = 0;
		    }
		    else
				c--;
		    if (!comp && !(c % 128))
		    {
				SysBuf[0] = ' ';
				SysBuf[1] = 0;
				if (!i)
				    strcpy(SysBuf + 1, Prompt.Caption[42]);
				PutsO(SysBuf);
				i ^= 1;
		    }
		    RamOffSet = endaddr - mcount;
		    endaddr = RamOffSet;
		    ReadRam(SysBuf, mcount);
			RamOffSet = endaddr + ApplVar.AP.Plu.RecordSize; /* move over length 1 record */;
		    WriteRam(SysBuf, mcount);
		}
		RamOffSet = bcount;
		if (!comp)
		    memcpy(ApplVar.Plu.Random, ApplVar.Entry.Value, ApplVar.AP.Plu.RandomSize);
     		ApplVar.AP.Plu.RNumber++;
    	}
    	WriteRam(ApplVar.Plu.Random, ApplVar.AP.Plu.RandomSize);    /* clear new or last record */
    MemSet(SysBuf, sizeof(SysBuf), 0);   /* clear plu record */
    WriteRam(SysBuf, ApplVar.AP.Plu.RecordSize - ApplVar.AP.Plu.RandomSize);    /* clear new or last record */
    if (!comp)
    {
		if (delete1)
	    	strcpy(ProgLineMes,DMes[29]);
    	else
	    	strcpy(ProgLineMes,DMes[28]);
		if(TESTBIT(PBPRINT,BIT5))	   //lyq20031230
		{
			SETBIT(ApplVar.MyFlags,PRNTRAI);
			PrintQty(ProgLineMes, &ApplVar.Entry);
		}
	}
    return 1;
}

void ProcessOnePlu()
{
    BYTE i;
    BCD	sSave,sPrice;

    if ((ApplVar.Key.Code == ApplVar.OldKey.Code && !ApplVar.OldMultiCount) || ApplVar.FVoid)
		ProcessDept();
    else
    {
		if (ApplVar.Key.Code == PLU1)
		{
		    ApplVar.PluNumber = 0;
			if (!ApplVar.FBarcode)          /* id code scanned then already checked */
			{
				CheckInStore(); /* also in store codes trhough keyboard */
				GetWordEntry();
			}
		    if (Appl_EntryCounter)
		    {
				if (ApplVar.AP.Plu.RandomSize)// && Appl_EntryCounter>4)//============================
				{
					if (Appl_EntryCounter <= (ApplVar.AP.Plu.RandomSize * 2))
						ApplVar.PluNumber = GetPluNumber(0, ApplVar.Entry.Value);
				}
				else if (ApplVar.FBarcode != 2)
				{
		    		ApplVar.PluNumber = ApplVar.NumberEntry;
					if (ApplVar.PluNumber && TESTBIT(ART_LEVEL, BIT4) && ApplVar.FPluEnq != 2)
						ApplVar.PluNumber += ApplVar.PluArtLevel;       /* add article shift ?*/
				}
		    }
		}
		else
		{
		    if (Appl_EntryCounter)
		    {
				if (TESTBIT(PLU_PRINT, BIT7) && !ApplVar.FInv && ApplVar.FPluEnq != 2)    /* no entry allowed */
				    ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
				else
				    CheckMultiply();
				if (ApplVar.ErrorNumber)
				    return;
		    }
		    ApplVar.PluNumber = ApplVar.Key.Code - PLU1;
			if (ApplVar.FPluEnq != 2)
		    	ApplVar.PluNumber += ApplVar.PluArtLevel;       /* add article shift */
		}
		if (!ApplVar.PluNumber || ApplVar.PluNumber > ApplVar.AP.Plu.Number)
		{
			if (ApplVar.FBarcode == 2 || ApplVar.FBarcode == 3)
			{
				ApplVar.Key.Code = DEPT + 1;    /* always in dept 1 */
				ApplVar.Entry = ApplVar.Price;
				ApplVar.FPrice = 0;
				ProcessDept();
			}
			else
			{
		    	ApplVar.ErrorNumber=ERROR_ID(CWXXI05);
		    }
		    return;
		}
		ApplVar.PluNumber--;        /* plunumber 1 is absolute number 0 */
		ReadPlu();
#if (BARCUSTOMER==1)
		if (ApplVar.FBarcode==6)
		{
			memset(&ApplVar.BarCustomer,0,sizeof(ApplVar.BarCustomer));
			ApplVar.PluDept = 0;
			ApplVar.BarCustomer.OFFIndex = ApplVar.PluNumber+1;
//			ApplVar.BarCustomer.Dept = 0;
			memcpy(&ApplVar.BarCustomer.Random,&ApplVar.Plu.Random,sizeof(ApplVar.Plu.Random));
			memcpy(&ApplVar.BarCustomer.Name,&ApplVar.Plu.Name,sizeof(ApplVar.Plu.Name));
			memcpy(&ApplVar.BarCustomer.Price[0],&ApplVar.Plu.Price[0],5);
			ApplVar.BarCustomer.DeptHi = (ApplVar.Entry.Value[0]>>4);
			if (!ApplVar.BarCustomer.DeptHi)
			{
				ApplVar.BarCustomer.Price[1][0] = ApplVar.Entry.Value[1];
				ApplVar.BarCustomer.Price[1][1] = ApplVar.Entry.Value[2];
			}

			sSave = ZERO;
			ApplVar.Price = ZERO;
			memcpy(&ApplVar.Price.Value,ApplVar.Plu.Price[0],5);
			memcpy(sSave.Value,ApplVar.Plu.Random,ApplVar.AP.Plu.RandomSize);
			strcpy(ProgLineMes,FormatQtyStr(0,&sSave,13));
			ProgLineMes[7] = 0;
			ProgLineMes[2] = 'C';
			PutsO(FormatAmtStr(ProgLineMes+2,&ApplVar.Price,DISLEN));

			return;
		}
#endif
		for(i = 0; i < ApplVar.AP.Plu.PriceSize; i++)
		{
		    if ((BYTE)ApplVar.Plu.Price[ApplVar.PluPriceLevel][i] != 0x99 || ApplVar.FInv)
		    {
#if 0 // liuj 0921
				if((ApplVar.FBarcode == 2 || ApplVar.FBarcode == 3))
				{
					ApplVar.Qty = ZERO;
					ApplVar.Entry = ApplVar.Price;
					memcpy(ApplVar.Price.Value, ApplVar.Plu.Price[ApplVar.PluPriceLevel], ApplVar.AP.Plu.PriceSize);
					if(CheckNotZero(&ApplVar.Price))
					{
						sSave = ApplVar.Entry;
						Divide(&ApplVar.Entry, &ApplVar.Price);
						ApplVar.DecimalPoint = ApplVar.Entry.Sign & 0x03;
						ChangePoint();
						if(ApplVar.DecimalPoint == 0)
						   	BcdMul10(&ApplVar.Entry);
						ApplVar.Qty = ApplVar.Entry;
						ApplVar.Qty.Sign = 0x03;
						ApplVar.MultiplyCount = 1;
						ApplVar.Entry = sSave;
					}
					else
						ApplVar.Price = ApplVar.Entry;
				}				   // LYQ ADDED for divide pricecode into ApplVar.Qty and ApplVar.Price end 20040402
#endif
				if((ApplVar.FBarcode == 2 || ApplVar.FBarcode == 3))				  // LYQ ADDED for divide pricecode into ApplVar.Qty and ApplVar.Price start 20040402
				{
					ApplVar.Qty = ZERO;
					ApplVar.Entry = ApplVar.Price;
					ApplVar.Price = ZERO;
					memcpy(ApplVar.Price.Value, ApplVar.Plu.Price[ApplVar.PluPriceLevel], ApplVar.AP.Plu.PriceSize);
					if(CheckNotZero(&ApplVar.Price))
					{
						sSave = ApplVar.Entry;
						//cc 20070920>>>>>>>>>>>>>>>>>
						sPrice = ApplVar.Price;
						BcdMul10(&ApplVar.Entry);
						ApplVar.Entry.Sign |= 0x03;
						BcdMul10(&sPrice);
						sPrice.Sign |= 0x03;
						//cc 20070920>>>>>>>>>>>>>>>>>
						Divide(&ApplVar.Entry, &ApplVar.Price);
						//cc 20070920>>>>>>>>>>>>>>>>>
						if(ApplVar.Entry.Sign != 0x03)
						{
							ApplVar.DecimalPoint = ApplVar.Entry.Sign & 0x03;
							ChangePoint();
							if(ApplVar.DecimalPoint == 0)
						   		BcdMul10(&ApplVar.Entry);
						}
						//cc 20070920>>>>>>>>>>>>>>>>>
						ApplVar.Qty = ApplVar.Entry;
						ApplVar.Qty.Sign = 0x03;
						ApplVar.Entry = sSave;
						ApplVar.MultiplyCount = 1;
					}
					else
						ApplVar.Price = ApplVar.Entry;
				}

				ProcessDept();
				return;
		    }           /* when price is 9999999999 then not active */
		}
		ApplVar.ErrorNumber=ERROR_ID(CWXXI01);    /* invalid entry */
    }
}

/* bufchk == 0 then print and calculate */
/* bufchk == 1 then print and check */
/* bufchk == 2 then only calculate ApplVar.DiscAmt */
void CheckMixMatch(short bufchk)
{
    BYTE scmd, sign;
    BCD matchqty, freeqty, soldqty;

    if (TESTBIT(ART_LEVEL, BIT2) && (ApplVar.AP.Plu.Cost || TESTBIT(ApplVar.MyFlags,PLUOFF)))// && !ApplVar.FPb) /* mix match active ? */
    {
    	scmd = 0;
    	if (TESTBIT(ApplVar.MyFlags,PLUPACK))
    	{// for PACKAGE sales use OFF Type-1
			matchqty = ZERO;

			memcpy(matchqty.Value, ApplVar.Plu.Cost, ApplVar.AP.Plu.PriceSize);
			if (!CheckNotZero(&matchqty))    /* not active */
			    return;
			if (bufchk == 1)
			{
			    ApplVar.MixQty = ZERO;
			    sign = ApplVar.BufCmd;
			    ApplVar.BufCmd = 3;     /* Count the PLU number has input */
			    StoreInBuffer();
			    ApplVar.BufCmd = sign;
			}
			freeqty = ApplVar.MixQty;
			freeqty.Sign = 0;
			soldqty = ZERO;
			while(CompareBCD(&freeqty, &matchqty) >= 0)
			{
			    Subtract(&freeqty, &matchqty);        /* get remainder already sold  */
			    Add(&soldqty, &ONE);            /* check number of free items */
			}//soldqty = ApplVar.MixQty - matchqty + 1;
			soldqty.Sign = ApplVar.MixQty.Sign;
			Add(&ApplVar.MixQty, &ApplVar.Qty);     /* add current sale qty */
			sign = ApplVar.MixQty.Sign;
			ApplVar.MixQty.Sign = 0;
			freeqty = ZERO;
			while(CompareBCD(&ApplVar.MixQty, &matchqty) >= 0)
			{
			    Subtract(&ApplVar.MixQty, &matchqty);        /* get remainder already sold  */
			    Add(&freeqty, &ONE);            /* check number of free items */
			}//soldqty = ApplVar.MixQty - matchqty + 1;
			freeqty.Sign = sign;
			Subtract(&freeqty, &soldqty);
			RoundBcd(&freeqty,0);	  //lyq added 2003\10\28
			if (CheckNotZero(&freeqty))    /* not zero */
			{
				ApplVar.DiscAmt = ZERO;
				memcpy(ApplVar.DiscAmt.Value, ApplVar.Plu.Price[1], ApplVar.AP.Plu.PriceSize);
			    Multiply(&ApplVar.DiscAmt, &freeqty);
			    ApplVar.DiscAmt.Sign ^= 0x80;
				if (bufchk != 2)
					scmd = 0x05;//Discount value
			}
		}
		else if (TESTBIT(ApplVar.MyFlags,PLUDISC))//ccr 050613
		{// for a PLU sales use OFF 	Type-2

				ApplVar.DiscAmt = ZERO;
				memcpy(ApplVar.DiscAmt.Value, ApplVar.Plu.Price[1], ApplVar.AP.Plu.PriceSize);
				ApplVar.DiscAmt.Sign = 4;
			    Multiply(&ApplVar.DiscAmt, &ApplVar.Price);
			    Multiply(&ApplVar.DiscAmt, &ApplVar.Qty);
				RoundBcd(&ApplVar.DiscAmt,0);
			    ApplVar.DiscAmt.Sign ^= 0x80;
				if (bufchk != 2)
					scmd = 0x11;//Discount value
		}
		if (scmd != 0)
		{
	    	PrintAmt(ApplVar.OFFPrice.Name, &ApplVar.DiscAmt);
			for (ApplVar.DiscNumber=0;ApplVar.DiscNumber<ApplVar.AP.Disc.Number;ApplVar.DiscNumber++)
			{
				GetDiscOffSet();
				ReadDisc();
				if (ApplVar.Disc.Options==scmd)
					break;
			}
			if (ApplVar.DiscNumber < ApplVar.AP.Disc.Number);
			{
				SETBIT(ApplVar.MyFlags,PLUDISC);//ccr 050613
				matchqty = ApplVar.Amt;
				ApplVar.Amt = ApplVar.DiscAmt;
				AddDiscTotal();
				ApplVar.Amt = matchqty;
			}
			if (bufchk != 0)
				Add(&ApplVar.Amt, &ApplVar.DiscAmt);
			ApplVar.FMixMatch = 1;          /* set item was match */
		}
    }
}


WORD GetLinkNumber()
{
	WORD keycode;
	BCD     temp;

	if (!ApplVar.AP.Plu.RandomSize)
		keycode = ApplVar.Plu.Link;
	else
	{
		temp = ZERO;
		WORDtoBCD(temp.Value, ApplVar.Plu.Link);
		keycode = GetPluNumber(0, temp.Value);
	}
	if (keycode)    /* not found */
		keycode += PLU1;

	return (keycode);
}

void ProcessPlu()
{
	BYTE ecnt, multicount, rcnt, correc;
	WORD saveplu, keycode;
	BCD     entr, price, qty1;


	ecnt = Appl_EntryCounter;
	entr = ApplVar.Entry;
    if (ApplVar.Key.Code == ApplVar.OldKey.Code || ApplVar.FVoid)
		multicount = ApplVar.OldMultiCount;//Select the same PLU
	else
		multicount = ApplVar.MultiplyCount;
	keycode = ApplVar.Key.Code;

	if (ApplVar.FVoid)
		correc = 1;
	else if (ApplVar.FCorr || ApplVar.FRefund)
		correc = 2;
	else
		correc = 0;
	ProcessOnePlu();

	rcnt = ApplVar.RepeatCount;
	price = ApplVar.Price;          /* Save data for repeat and void */

	if (!TESTBIT(ApplVar.AP.Options.Plu, BIT0) || ApplVar.FInv) /* no link with inventory */
		return;
	if (!ApplVar.Plu.Link)
		return;
	saveplu = ApplVar.PluNumber;    /* not link to itself again !! */
	qty1 = ApplVar.Qty1;
	if (correc == 1)        /* Void ? */
		ApplVar.Qty.Sign ^= 0x80;               /* Invert sign when void */
	ApplVar.FPluEnq = 2;            /* Indicate linked plu */
	while(!ApplVar.ErrorNumber && ApplVar.Plu.Link)
	{
		ApplVar.Key.Code = GetLinkNumber();     /* number in ApplVar.Plu.Link */
		if (!ApplVar.Key.Code)  /* Random Code not found */
			break;
		if (ApplVar.Key.Code == (saveplu + PLU1 + 1)) /*not link to itself */
			break;
		ApplVar.Entry = ApplVar.Qty;
		Appl_EntryCounter = 1;
		ProcessOnePlu();
		if (correc)
			AddCorrecTotal();               /* update correc report */
		ApplVar.RGRec.Key.Code = 0;             /* don't store link in ApplVar.PB and Trans buffer */
	}
	ApplVar.FPluEnq = 0;
	if (correc == 1)        /* Void ? */
		ApplVar.Qty.Sign ^= 0x80;               /* Invert sign when void */
	ApplVar.Qty1 = qty1;     /*     restore */
	ApplVar.RepeatCount = rcnt;
	ApplVar.Price = price;          /* restore data for repeat and void */
	ApplVar.Entry = entr;
	Appl_EntryCounter = ecnt;
	if (correc == 2)
		ApplVar.Key.Code = 0;
	else
		ApplVar.Key.Code = keycode;
	ApplVar.OldMultiCount = multicount;
	ApplVar.PluNumber = saveplu;
	ReadPlu();              /* Restore first PLU recrod */
	ApplVar.DeptNumber = ApplVar.PluDept;
	ReadDept();             /* Restore Department */
}

void LookPlu(BYTE pType)//pType=0,look price,pType>0 look inv
{
	BCD	sPrice;
	short i;

	if (ApplVar.PluNumber>ApplVar.AP.Plu.Number)
	{
		ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
		return;
	}
	else
	{
		ReadPlu();
		sPrice = ZERO;
		if (pType && ApplVar.AP.Plu.InvSize)
		{
//LYQ modify for display PLU inventory 2003\10\21 start
//			sPrice.Sign = ApplVar.Plu.Inventory.Sign;
//			for (i=0;i<ApplVar.AP.Plu.InvSize-1;i++)
//				sPrice.Value[i] = ApplVar.PluInventory.Value[i];
//			PutsO(FormatAmtStr(DMes[33] ,&sPrice,DISLEN));
			memcpy(&ApplVar.Entry,&ApplVar.Plu.Inventory,sizeof(ApplVar.Plu.Inventory));
			switch(ApplVar.Entry.Sign &0x7f)
			{
				case 0:
					BcdMul10(&ApplVar.Entry);
				case 1:
					BcdMul10(&ApplVar.Entry);
				case 2:
					BcdMul10(&ApplVar.Entry);
				default:
					break;
			}
			ApplVar.Entry.Sign = 3;
		    PutsO(DispQtyStr(DMes[33], &ApplVar.Entry,DISLEN));
//    LYQ modify for display PLU inventory 2003\10\21 end
		}
		else
		{
			for (i=0;i<ApplVar.AP.Plu.PriceSize;i++)
				sPrice.Value[i] = ApplVar.Plu.Price[0][i];
			PutsO(FormatAmtStr(DMes[32] ,&sPrice,DISLEN));
		}
	}
}
