#ifndef MESSAGE_H
#define MESSAGE_H

#if defined(DEBUGBYPC)
#include "MessageEN.h"//captions for current mode
#elif(VV_RUSSIA)
#include "MessageRU.h"
#elif (CASE_SPANISH)
#include "MessageSP.h"
#elif (CASE_ITALIA)
#include "MessageITA.h"
#else
#include "MessageEN.h"//captions for current mode
#endif

//ccr2016-12-20>>>>>>>>>>>>>>>>>>>
#if( (DD_ZIP==1)||(DD_ZIP_21==1))
#define MSG_CLIENTIP    "Client IP"
#define MSG_SERVERIP    "Server IP"
#define MSG_GATEWAY     "GATE WAY"
#define MSG_IPMASK      "IP MASK"

#define GPRSAPNNAME        "APN"           //GPRSAPNNAME
#define GPRSUSERNAME        "USER NAME"           //GPRSUSERNAME

#else
#define MSG_CLIENTIP    "IP-C"
#define MSG_SERVERIP    "IP-S"
#define MSG_GATEWAY     "GATE"
#define MSG_IPMASK      "MASK"

#define GPRSAPNNAME     "APN"           //GPRSAPNNAME
#define GPRSUSERNAME    "USER"           //GPRSUSERNAME
#endif

#if (defined(CASE_GPRS) || defined(CASE_ETHERNET))
#define GPRSPASSWORD    Prompt.LineCap[Line_PASSWORD]// "Password"           //GPRSPASSWORD

#define GPRSServerIP			"SERVER IP"//"������IP"
#define GPRSServerPort		    "PORT"//"�˿ں�"

#define GPRSSendMESS        "Send Message" //ccr2014-11-11 NEWSETUP
#define GPRSSetMode         "Set Sent Mode"    //gprsSETMODE //ccr2014-11-11 NEWSETUP-step2
#define GPRSSendECRLog      "Send NEW FM"       //gprsSendECRLog //ccr2014-11-11 NEWSETUP-step2
#define GPRSSendECRLogAll   "Send All FM"    //gprsSendECRLogAll //ccr2014-11-11 NEWSETUP-step2
#define GPRSDownloadPLU     "Update PLU"    //gprsDownloadPLU //ccr2014-11-11 NEWSETUP-step2
#define GPRSDownloadDEPT    "Update DEPT"    //gprsDownloadDEPT //ccr2014-11-11 NEWSETUP-step2
#define GPRSDownloadCLERK   "Update CLERK"    //gprsDownloadCLERK //ccr2014-11-11 NEWSETUP-step2
#define GPRSDownloadHEAD    "Update HEAD"       //gprsDownloadHEAD //ccr2014-11-11 NEWSETUP-step2
#define GPRSDownloadTRAIL   "Update TRAIL"      //gprsDownloadTRAIL //ccr2014-11-11 NEWSETUP-step2
#define GPRSDownloadALL     "Update ALL"      //gprsDownloadALL //ccr2016-08-18
#define GPRSRestart         "RESET GPRS"      //gprsRestart //ccr2016-08-26

#define GPRSstr1 "DATA ERROR!"  // "�������ʹ�"
#define GPRSstr2 "GPRS OK"
#define GPRSstr3 "GPRS NOT OK"
#define GPRSstr4 "CONFIRM?"
#define GPRSstr5 "IP/PORT:NULL"
#define GPRSstr6 "ERROR:IP/PORT"
#define GPRSstr7 "WAITING GPRS"
#define GPRSstr8 "YES"   // "��"
#define GPRSstr9 " NO"    // "fou "
#define GPRSstr10 "TRANSMITTING..."  // "���ݷ�����.. "
#define GPRSstr11 "FINISHED"  // "�����ѷ���.. "
#define GPRSstr28 "SUCCESS........"						// "���ͳɹ�.."
#define GPRSstr31 "FAILURE ON CONNECT"	//						// "����ʧ��"
#define GPRSstr32 "FAILURE ON READ"                                           // "����ʧ��"
#define GPRSstr33 "CONFIRMA ERR"			// "����ȷ��ʧ��"
#define GPRSstr34 "FAILURE........"							// "����ʧ��"
#define GPRSstr58 "CONNECT........."		// "���ڽ�������.."
#define GPRSstr59 "CONNECT........."		// " ׼����������.."
#define GPRSstr60 "RESTART GPRS"	// "���ڸ�λģ��.."
#define GPRSstr61 "END OF SEND." // "�������,���˳�"

#define GPRSxACK  "Wait ACK Error"
#endif

#if defined(CASE_ETHERNET)
#define ETHERNETSendMESS        "PING SERVER" //CCR2014-11-11 NEWSETUP
#define ETHERNETSetMode         "SET SENT MODE"    //ethernetSETMODE //ccr2014-11-11 NEWSETUP-step2
#define ETHERNETSendECRLog      "SEND NEW FISCAL"       //ethernetSendECRLog //ccr2014-11-11 NEWSETUP-step2
#define ETHERNETSendECRLogAll   "SEND ALL FISCAL"    //ethernetSendECRLogAll //ccr2014-11-11 NEWSETUP-step2
#define ETHERNETDownloadPLU     "UPDATE PLU"    //ethernetDownloadPLU //ccr2014-11-11 NEWSETUP-step2
#define ETHERNETDownloadDEPT    "UPDATE DEPT"    //ethernetDownloadDEPT //ccr2014-11-11 NEWSETUP-step2
#define ETHERNETDownloadCLERK   "UPDATE CLERK"    //ethernetDownloadCLERK //ccr2014-11-11 NEWSETUP-step2
#define ETHERNETDownloadHEAD    "UPDATE HEAD"       //ethernetDownloadHEAD //ccr2014-11-11 NEWSETUP-step2
#define ETHERNETDownloadTRAIL   "UPDATE TRAIL"      //ethernetDownloadTRAIL //ccr2014-11-11 NEWSETUP-step2
#define ETHERNETDownloadALL     "UPDATE ALL"      //ethernetDownloadALL //ccr2016-08-18
#define ETHERNETRestart         "RESET ETHERNET"      //ethernetRestart //ccr2016-08-26
#endif

#define SHANCHU         "DELETE ?"


#define PRESSANYKEY     "PRESS A KEY"

#define SENDLOGAUTO     "SEND AUTO:"
#define DAYSFORLOG      "DAYS FOR SEND:"
#define ACKMUSTNEED     "ACK NEEDED:"
#define WJKJYJIE        "FILE OVERFLOW!"  // "�ļ��ռ�Խ��",
#define FATERROR        "FAT(PLU) ERR"

//.......�������Ӧ������.........................................
#define MsgKEYCORR      "CORRECT"
#define MsgKEYCURR      "CURRENCY"
#define MsgKEYDISC      "DISCOUNT"
#define MsgKEYPBFUN     "PB-FUNC"
#define MsgKEYPORA      "PORA"
#define MsgKEYPO_RA      "PO/RA"
#define MsgKEYTEND      "TENDER"
#define MsgKEYCLEAR     "CLEAR"
#define MsgKEYFEED      "FEED"
#define MsgKEYMULT      "X"
#define MsgKEYSUBTOT    "SUBTOTAL"
#define MsgKEYPRICE     "PRICE"
#define MsgKEYPRICEN    "PRICE#"
#define MsgKEYPRICE1    "PRICE1"
#define MsgKEYPRICE2    "PRICE2"
#define MsgKEYPRICE3    "PRICE3"
#define MsgKEYPRICE4    "PRICE4"
#define MsgKEYSHIFT     "SHIFT"
#define MsgKEYDATE      "DATE"
#define MsgKEYWEIGHT    "WEIGHT"
#define MsgKEYCLERKN    "CLERK#"
#define MsgKEYDEPT      "DEPT~"
#define MsgKEYDEPTNo    "DEPT#"
#define MsgKEYPLUNo     "PLU#"
#define MsgKEYDRAW      "OPEN-DRAW"
#define MsgKEYMEMO      "MODIFIER"
#define MsgKEYCLERK     "CLERK*"
#define MsgKEYPLUDIR    "PLU~"
#define MsgKEYLOCK      "MODE KEY"
#define MsgKEYDRAWFUN   "DRAW FUNC*"
#define MsgKEYSALPN     "SALPER#"
#define MsgKEYSALP      "SALPER"
#define MsgKEYDOT       "'.'"
#define MsgKEYZERO2     "'00'"
#define MsgKEYNUMBER    "0~9"
#define MsgKEYSUSPEND   "HOLD"
#define MsgFUNCLOOK1    "FUNC LOOK1"
#define MsgFUNCLOOK2    "FUNC LOOK2"
#define MsgMODELOCK     "MODE KEY"
#define MsgVIPLOGIN     "ACCOUNT LOGIN"
#define MsgINPUTNUM     "INPUT CODE"
#define MsgCUSTOMER    "CUSTOMER"
#define MsgKEYNULL      "(OTHERS)"

#define MsgRHEADER      "Header*"
#define MsgRTRAILER     "Trail*"
#define MsgKEYBOARD     "Keyboard*"
#define MsgSYSFLAGS     "System*"
#define MsgSETDATE      "Datetime*"
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//ccr2016-12-20<<<<<<<<<<<<<<<<<<<
#endif
