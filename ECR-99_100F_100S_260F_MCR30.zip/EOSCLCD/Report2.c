#define REPORT2_C
#include "king.h"				/* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
#include "fiscal.h"

/*****************************************************************/

WORD SetUpReport()
{
    if (ApplVar.Report.Type > XZNUM || ApplVar.Report.Period > 3 || ApplVar.Report.PointerType > (REPDEFMAX-1))
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI26);
        return 1;
    }
    switch(ApplVar.Report.PointerType)
    {
        case 1:     /* ApplVar.Clerk report */
            ApplVar.Report.PointerEnd = ApplVar.AP.Clerk.Number;
			if (ApplVar.ClerkNumber)				//ccr 040513
				ApplVar.Report.Pointer = ApplVar.ClerkNumber - 1;
			else							//ccr 040513
				ApplVar.Report.Pointer = 0;			//ccr 040513
            break;

        case 2:     /* Time ApplVar.Zone report report */
            ApplVar.Report.PointerEnd = ApplVar.AP.Zone.Number;
            ApplVar.Report.Pointer = ApplVar.Zone;
            break;
        case 3:     /* ApplVar.Day report */
            ApplVar.Report.PointerEnd = ApplVar.AP.Day.Number;
            ApplVar.Report.Pointer = ApplVar.Day;
            break;
        case 4:     /* ApplVar.Month report */
            ApplVar.Report.PointerEnd = ApplVar.AP.Month.Number;
            ApplVar.Report.Pointer = ApplVar.Month;
            break;
        case REPDEFMAX-1:     /* saler report */
			if (ApplVar.AP.SalPer.Number)
			{
	            ApplVar.Report.PointerEnd = ApplVar.AP.SalPer.Number;
				if (ApplVar.SalPerNumber)				//ccr 040513
					ApplVar.Report.Pointer = ApplVar.SalPerNumber - 1;
				else							//ccr 040513
					ApplVar.Report.Pointer = 0;			//ccr 040513
			}
       	    break;
        default :  /* standard report */
            ApplVar.Report.PointerEnd = 1;
            break;
    }
    if (ApplVar.RepComputer)
        ApplVar.Report.Pointer = 0;
    if (ApplVar.Report.Pointer > ApplVar.Report.PointerEnd)
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI26);
        return 1;
    }
	ApplVar.CopyReceipt = ApplVar.RGNumber = 0;    /* reset trans buffer */
    ApplVar.SaveClerk = ApplVar.ClerkNumber;
	ApplVar.SaveSalPer = ApplVar.SalPerNumber;
    return 0;
}


void MakeTime(char *to,WORD time)
{
    if (TESTBIT(AM_PM, BIT0)) // am - pm
    {
        *(to + 6) = 'M';
        if (time > 0x1159)
            *(to + 5) = 'P';
        else
            *(to + 5) = 'A';
        if (time > 0x1959 && time < 0x2200)
            time -= 0x1800;
		else if (time > 0x1259)
			time -= 0x1200;
        else if (!time)
            time = 0x1200;
    }
    HEXtoASC(to, ((BYTE *)&time) + 1, 1);
    *(to + 2) = ':';
    HEXtoASC(to + 3, (BYTE *)&time, 1);
    if (*to == '0')
        *to = ' ';
}

void PrintPointType()
{
    CONSTCHAR *s;

    MemSet(SysBuf+7, 24, ' ');  /* clear record */
    switch(ApplVar.Report.PointerType)
    {
        case 0:
            s = 0;
            break;
        case 1:         /* clerk */
            ApplVar.ClerkNumber = ApplVar.Report.Pointer + 1;
            ReadClerk();
            s = ApplVar.Clerk.Name;
            break;
        case 2:         /* hour */
            SysBuf[25] = 0;
            SysBuf[15] = '-';
            SysBuf[16] = '-';
            MakeTime(SysBuf + 7, ApplVar.AP.Zone.Start[ApplVar.Report.Pointer]);
            if (ApplVar.Report.Pointer == (ApplVar.AP.Zone.Number - 1))
                MakeTime(SysBuf + 18, ApplVar.AP.Zone.Start[0]);
            else
                MakeTime(SysBuf + 18, ApplVar.AP.Zone.Start[ApplVar.Report.Pointer + 1]);
            s = SysBuf + 7;
            break;
        case 3:         /* day */
            s = Prompt.DayCap[ApplVar.Report.Pointer];
            break;
        case 4:         /* month */
            s = Prompt.MonthCap[ApplVar.Report.Pointer];
            break;
        case REPDEFMAX-1:         /* saler */
			if (ApplVar.AP.SalPer.Number)
			{
	            ApplVar.SalPerNumber = ApplVar.Report.Pointer + 1;
    	        ReadSalPer();
        	    s = ApplVar.SalPer.Name;
			}
            break;
		default:
            return;
    }
    if (ApplVar.RepComputer)
    {
        *((WORD *)SysBuf) = 3;
        SysBuf[2] = 1;      /* indicate text */
        SysBuf[3] = ApplVar.Report.Period;
        SysBuf[4] = ApplVar.Report.PointerType;
        *((WORD *)(SysBuf + 5)) = ApplVar.Report.Pointer;
        if (s)
            CopyFrStr(SysBuf + 7, s);
        SendRecord(SysBuf, 31);
    }
    else
    {
        if (s)
        {
            PrintStr(s);
            PrintLine('=');
        }
    }
}


/* print z-count and or message at report end */

void ReportEnd(BYTE AddZ)
{
    ApplVar.ClerkNumber = ApplVar.SaveClerk;        /* restore clerk */
    ReadClerk();

	ApplVar.SalPerNumber = ApplVar.SaveSalPer;
	ReadSalPer();
#if !defined(FISCAL)
    if (!TESTBIT(KEYTONE, BIT3))   /* print always on Journal ? */
        SETBIT(ApplVar.PrintLayOut, BIT0);  /* always on journal */
#endif
    if (ApplVar.RepComputer)
        ApplVar.PrintLayOut &= 0x01;        /* only journal */
    if (ApplVar.ErrorNumber== 27)
        PrintMessage(36);
#if 1//!defined(FISCAL)
    if (ApplVar.Report.Type < 12 && AddZ)
    {
        ApplVar.SaleQty = ZERO;
#if !defined(FISCAL)
        if (ApplVar.FReport == Z)
        {
            if (ApplVar.Report.PointerType == 1 && ApplVar.FTrain)   /* training clerk ? */
            {
            }/* not add with training clerk */
            else
            {
//               ApplVar.FisNumber.TotalClearNum++;
                ApplVar.ZCount[REPZNUM]++;
            }
        }
#endif
        WORDtoBCD(ApplVar.SaleQty.Value,ApplVar.ZCount[REPZNUM]);
        PrintQty(Prompt.Caption[32], &ApplVar.SaleQty);        /* print z-count */
        ApplVar.SaleQty = ZERO;
    }
#endif
    MemSet(SysBuf, PRTLEN, ' ');


#if (DD_FISPRINTER==0)
    if (ApplVar.Report.System & 0x01)
   	{
        CopyFrStr(SysBuf, Prompt.Caption[34]);
        WORDtoASC(SysBuf + 16,ApplVar.ReportNumber);//ccr20131120
//	    memcpy(SysBuf + 13, &EntryBuffer[sizeof(EntryBuffer) - 6], 5);
   	}
    else
   	{
        CopyFrStr(SysBuf, Prompt.Caption[19]);
        WORDtoASC(SysBuf + 10,ApplVar.ReportNumber);//ccr20131120
//	    memcpy(SysBuf + 10, &EntryBuffer[sizeof(EntryBuffer) - 6], 5);
   	}

    if (ApplVar.FReport == Z && ApplVar.Report.Type < 12 && ApplVar.ErrorNumber != 27)
    {
        CopyFrStr(SysBuf+19, Prompt.Caption[33]);
    }
    else
        SysBuf[22] = 'X';

    PrintStr(SysBuf);
#endif

#if defined(FISCAL)
	if(!TESTBIT(ApplVar.MyFlags, ENPRINTER)) //liuj0530
	{
		ApplVar.FReceipt = 1;
#if (DD_FISPRINTER==0)
		ReceiptIssue(1+BIT1);//ccr070609pm
#else
		ReceiptIssue(1);//ccr070609pm
#endif
	}
#else
		ReceiptIssue(1);//ccr070609pm
#endif

	if (!ApplVar.RepComputer || (ApplVar.RepComputer && ApplVar.FReport == Z))
	{
	    if (TESTBIT(CLERKFIX, BIT0+BIT5) && !ApplVar.ClerkLock)    /* clerk compulsory or secret, no key */
		{
    	    ApplVar.ClerkNumber = 0;
			PutsO(Prompt.Message[59]);
		}
	}
	if (TESTBIT(KEYTONE, BIT6))		/* sales person compulsory */
		ApplVar.SalPerNumber = 0;
	else if (TESTBIT(AM_PM, BIT4))		/* sales person to 1 */
	{
		ApplVar.SalPerNumber = 1;
		ReadSalPer();
	}
}

void PrintReportHeader()
{
    BYTE save;

    PrintLine(' ');

    if (ApplVar.Report.Type >= 12)
        memcpy(SysBuf + 4, ApplVar.TXT.ReportType[ApplVar.Report.Type], sizeof(ApplVar.TXT.ReportType[0]));
    else
    {
        CopyFrStr(SysBuf, Prompt.Caption[ApplVar.Report.Period + 10]);
		if (!(ApplVar.Report.PointerType == 5 && ApplVar.AP.SalPer.Number))
        	CopyFrStr(SysBuf + 8, Prompt.Caption[ApplVar.Report.PointerType + 14]);
        CopyFrStr(SysBuf + 16, Prompt.Caption[19]);
    }
    save = ApplVar.PrintLayOut;
    ApplVar.PrintLayOut &= 0xf8;
    PrintStr(SysBuf);   /* not double on slip */
    ApplVar.PrintLayOut = save & 0xe7;
    SETBIT(ApplVar.PrintLayOut, BIT2);      /* Double size */
    PrintStr(SysBuf);
    ApplVar.PrintLayOut = save;
    PrintLine('=');
}

void ClearAllReport()
{
    WORD  saveclerk ;

    saveclerk = ApplVar.ClerkNumber ;
    ApplVar.FReport = Z;
    ApplVar.PrintLayOut = 0;
    MemSet(&ApplVar.Report, sizeof(ApplVar.Report), 0);
    for (ApplVar.Report.Period = 0;ApplVar.Report.Period < 4;ApplVar.Report.Period++)
      for (ApplVar.Report.PointerType = 0;ApplVar.Report.PointerType < REPDEFMAX;	ApplVar.Report.PointerType++)
	    for (ApplVar.Report.Type = 0;ApplVar.Report.Type < REPTYPEMAX; ApplVar.Report.Type++)	//lyq 13
	    {
		    if (ApplVar.Report.Type == 12 && 			 //lyq
			    (ApplVar.Report.Period || ApplVar.Report.PointerType))
			    break;
		    SysBuf[0] = ' ';
		    SysBuf[1] = ApplVar.Report.Period + '0';
		    SysBuf[2] = ApplVar.Report.PointerType + '0';
		    SysBuf[3] = ApplVar.Report.Type / 10 + '0';
		    SysBuf[4] = (ApplVar.Report.Type % 10) + '0';
		    SysBuf[5] = 0;
		    PutsO(SysBuf);
		    GetSystemReport(1); /* clear all */
	    }

    ApplVar.ClerkNumber = saveclerk ;
    ReadClerk() ;

	if (TESTBIT(COPYRECEIP, BIT7))		//ccr090507 ��ӡ��0�ձ���ʱ,�Ƿ�λ�վݺ�   ///
	{
#if !defined(FISCAL)   //ccr091027
	    ApplVar.ZCount[REPZNUM] = ApplVar.ZCount[TRAINNUM]=1;
#endif
	    MemSet(ApplVar.FisNumber.ReceiptNum, sizeof(ApplVar.FisNumber.ReceiptNum), 0);     /* reset receiptnumber ?*/
	}

    ApplVar.FReport = 0;
    ApplVar.PrintLayOut = 0x05;
    if (ApplVar.AP.Plu.Number && ApplVar.AP.Plu.InvSize)	/* reset inventory */
    {
        ApplVar.PluInventory = ZERO;
		for (ApplVar.PluNumber = 0; ApplVar.PluNumber < ApplVar.AP.Plu.Number; ApplVar.PluNumber++)
		    WritePluInventory();	/* write zero */
    }
    PutsO(" CLEARED ");
	strcpy(SysBuf,"** REPORT CLEARED **");
    PrintStr(SysBuf);
	SETBIT(ApplVar.MyFlags,PRNTRAI);
	ApplVar.PrintLayOut = 0x03;				//force single heigth
	RESETBIT(ApplVar.MyFlags,ZREPORT);
#if DD_FISPRINTER == 1
	MemSet(&ApplVar.DiscountAmt, sizeof(ApplVar.DiscountAmt), 0);
	MemSet(&ApplVar.RefundAmt, sizeof(ApplVar.DiscountAmt), 0);
#endif
}
