

#include "king.h"
#include "exthead.h"
#include "exth.h"
#include "flowbill.h"
#include "fiscal.h"
#include "ejournal.h"
#include "message.h"
//the commmand of collect flow
#define ADJLOGADDR(addr) {if (addr>=FlowHeader.EndAddr) addr=FlowHeader.FromAddr+addr-FlowHeader.EndAddr;}
#if(CASE_RAMBILL)
void DispNULL();                              //    reserved
void DispPoRa();
void DispDept();
void DispPlu();
void DispEnd();
void DispNonAdd();
void DispOperator();
void DispTender();
void DispModeLock();
void DispPercentDisc();
void DispSubTotalDisc();
void DispDirectDisc();
void DispSubTotalDirDisc();
void DispNew();
void DispSubTotals();
void DispRPNew();
void DispRPEnd();
void DispInsertIC();
void DispRefreshIC();
void DispSetPrice();
void DispEcrNum();			//only send to manage systyem
void DispVoid();			//record the operation of close table
void DispPbClose();			//record the operation of close table
void DispPbOpen();			//record the operation of close table
void DispPbTransTo();			//record the operation of close table

void ClearLogFor(WORD sSize);
void Clear_FlowBuff();
void Init_Flow();
#endif
#if defined(FISCAL)
extern void PrintReceiptNum(void);
extern BYTE GetCRC(BYTE *Area,short pLen);

#if DD_MMC
extern unsigned long ReadEJIndex(WORD pTo);
#endif
#endif

#if(CASE_RAMBILL)
CONST struct ECRLOGDES LogSize[LOGTYPEMAX]={
    {0,                              &DispNULL},                              //reserved
    {sizeof(struct CDC_DPT),         &DispDept},
    {sizeof(struct CDC_ART),         &DispPlu},
    {sizeof(struct CDC_END),         &DispEnd},
    {sizeof(struct CDC_NOADD),       &DispNonAdd},
    {sizeof(struct CDC_OPER),        &DispOperator},
    {sizeof(struct CDC_GIVEN),       &DispTender},
    {sizeof(struct CDC_LOCK),        &DispModeLock},
    {sizeof(struct CDC_DISCADD),     &DispPercentDisc},
    {sizeof(struct CDC_SUBDISCADD),  &DispSubTotalDisc},
    {sizeof(struct CDC_DIRECT),      &DispDirectDisc},
    {sizeof(struct CDC_SUBDIRECT),   &DispSubTotalDirDisc},
    {sizeof(struct CDC_REGIS),       &DispNew},
    {sizeof(struct CDC_SUBTOTAL),    &DispSubTotals},
    {sizeof(struct CDC_SLIPREGIS),   &DispRPNew},
    {sizeof(struct CDC_SLIPEnd),     &DispRPEnd},
    {sizeof(struct CDC_EnterIC),     &DispInsertIC},
    {sizeof(struct CDC_REFRESHIC),   &DispRefreshIC},
    {sizeof(struct CDC_PRICELIST),   &DispSetPrice},
	{sizeof(struct CDC_ECRNUM),		 &DispEcrNum},			//only send to manage systyem

	{sizeof(struct CDC_VOID),	 	 &DispVoid},			//record the operation of close table
	{sizeof(struct CDC_PBCLOSE),	 &DispPbClose},			//record the operation of close table
	{sizeof(struct CDC_PBOPEN),	 	 &DispPbOpen},			//record the operation of close table
	{sizeof(struct CDC_PBTT),	 	 &DispPbTransTo},			//record the operation of close table
	{sizeof(struct CDC_PORA),	 	 &DispPoRa},			//record the operation of close table
};


struct 	FifoHeader FlowHeader;
struct 	GIVEN_DATA CollectGiven[TENDLOGMAX];
BYTE 	GCouter;
union  FLOWREC	FlowBuff;


//    ==========================================================================

void SUB_SCANFP(BYTE Size)
{
	FlowHeader.ReadP -= Size;
	return;
}

void ChangeQty(BCD *sBcd)
{
	BYTE Sign;

	Sign = sBcd->Sign;
	switch (Sign&0xf)
	{
	case 0:
	    BcdMul10(sBcd);
	case 1:
	    BcdMul10(sBcd);
	case 2:
	    BcdMul10(sBcd);
	}
	sBcd->Sign = Sign;
}

void Collect_Given()
{
	if(ApplVar.TendNumber < ApplVar.AP.Tend.Number && GCouter<TENDLOGMAX)
	{
		CollectGiven[GCouter].FTType = ApplVar.TendNumber+1;
		memcpy(CollectGiven[GCouter].FAmt, ApplVar.Amt.Value, sizeof(CollectGiven[0].FAmt));
		if((GCouter == 0) && (ApplVar.Amt.Sign & 0x80))
		{
			CollectGiven[GCouter].FTType |= 0x80;
		}
		GCouter++;
	}
}

UnLong CheckLogBuff()
{
	UnLong sFreeMem;

	if (FlowHeader.NextNP>= FlowHeader.HeadP)
		sFreeMem = FlowHeader.MAXNUMB - (FlowHeader.NextNP- FlowHeader.HeadP);
	else
		sFreeMem = FlowHeader.HeadP - FlowHeader.NextNP;

	if(sFreeMem<LOGALARMON && FlowHeader.OverCount<2)
	{
		PutsO(MessageE63);
		Bell(3);
		while (!KbHit() || Getch()!=ApplVar.AP.FirmKeys[ID_CLEAR]);

		FlowHeader.OverCount++;
		FlowHeader.HeadP = FlowHeader.ReadP;
		if (FlowHeader.NextNP>= FlowHeader.HeadP)
			sFreeMem = FlowHeader.MAXNUMB - (FlowHeader.NextNP- FlowHeader.HeadP);
		else
			sFreeMem = FlowHeader.HeadP - FlowHeader.NextNP;
	}
	if(sFreeMem<LOGALARMON)
		ClearLogFor(LOGALARMON);
	if (FlowHeader.NextNP>= FlowHeader.HeadP)
		return (FlowHeader.MAXNUMB - (FlowHeader.NextNP- FlowHeader.HeadP));
	else
		return (FlowHeader.HeadP - FlowHeader.NextNP);
}
//Free memory from log area
void ClearLogFor(WORD sSize)
{
	WORD	sLength;
	short 	i;
	char 	sBuf[1];
	BYTE	sCtrl;

	sLength = 0;
	sCtrl = (FlowHeader.ReadP<FlowHeader.NextNP)?1:2;

	while (sLength<=sSize && FlowHeader.ReadP!=FlowHeader.NextNP)
	{
		ReadFrLogRam(sBuf,(CONSTCHAR*)FlowHeader.ReadP,1);
		i =	sBuf[0] & 0x1f;
		if (i>0 && i<=LOGTYPEMAX)
		{
			if (i==GIVENLOG)
			{
				ReadFrLogRam(sBuf,(CONSTCHAR*)FlowHeader.ReadP+1,1);
				i = (sBuf[0] & 0x0f) * sizeof(struct GIVEN_DATA)+2;
			}
			else
				i = LogSize[i-1].RecSize;
			sLength += i;
		   	FlowHeader.ReadP = FlowHeader.ReadP + i;
		   	ADJLOGADDR(FlowHeader.ReadP);
		   	if (FlowHeader.ReadP>FlowHeader.NextNP)
		   	{
		   		if (sCtrl & 1)
		   		{
		   			FlowHeader.ReadP= FlowHeader.NextNP;
					FlowHeader.OverCount = 0;
		   			break;
		   		}
		   		else
		   			sCtrl |= 2;
		   	}
		   	if (FlowHeader.ReadP<FlowHeader.NextNP)
		   		sCtrl |= 1;
		}
		else
			break;
	}
	FlowHeader.HeadP = FlowHeader.ReadP;
}
//Read block data from log area
//pFrom:address for read
//pTo:Address for write
//pSize
void ReadFrLogRam(char *pTo,CONSTCHAR *pFrom,short pSize)
{
	short	   skip;
#ifdef LOGONRAM
	skip = pSize;
	if ((UnLong)pFrom+pSize>=FlowHeader.EndAddr)
	{
		skip = FlowHeader.EndAddr - (UnLong)pFrom;

		RamOffSet = (UnLong)pFrom;
		ReadRam(pTo,skip);
		pTo = pTo + skip;
		skip = pSize - skip;
		pFrom = (CONSTCHAR *)FlowHeader.FromAddr;
	}
	RamOffSet = (UnLong)pFrom;
	ReadRam(pTo,skip);

#else
	skip = pSize;
	if ((UnLong)pFrom+pSize>=FlowHeader.EndAddr)
	{
		skip = FlowHeader.EndAddr - (UnLong)pFrom;

    	mFlashBlockRead((UnLong)pFrom,skip,pTo);
    	pTo = pTo + skip;
    	skip = pSize - skip;
    	pFrom = (CONSTCHAR *)FlowHeader.FromAddr;
	}
   	mFlashBlockRead((UnLong)pFrom,skip,pTo);
#endif
}

//Read block data from log area
//pFrom:address for read
//pTo:Address for write
//pSize
void WriteToLogRam(CONSTCHAR *pTo,char *pFrom,short pSize)
{
	WORD   skip;
#ifdef LOGONRAM
	if (FlowHeader.MAXNUMB<LOGALARMON)
		return;
	if ((UnLong)pTo+pSize>=FlowHeader.EndAddr)
	{
		skip = FlowHeader.EndAddr - (UnLong)pTo;

		RamOffSet = (UnLong)pTo;
		WriteRam(pFrom,skip);
		pTo = (CONSTCHAR*)FlowHeader.FromAddr;
		pFrom = pFrom+skip;
		skip = pSize - skip;
	}
	else
		skip = pSize;
	RamOffSet = (UnLong)pTo;
	WriteRam(pFrom,skip);
#else
	char sAddrF,sAddrT;
	char sBlk[1];

	if (FlowHeader.MAXNUMB<LOGALARMON)
		return;
	sAddrF = ((UnLong)pTo>>16);
	sAddrT = (((UnLong)pTo+pSize)>>16);
	if (sAddrT>sAddrF)
	{//Out of range
		skip = 0xffff-(((UnLong)pTo+pSize)&0xffff)+1;
		if (skip == 0)
			skip = 0xffff;
	 	if (sAddrF==(FlowHeader.EndAddr>>16))
	 		sAddrT = (FlowHeader.FromAddr>>16);
	 	if (sAddrT==sAddrF)
	 	{//64K only
 			Init_Flow();
	 		pTo = (CONSTCHAR *)FlowHeader.NextNP;
		}
		else
		{
			if (sAddrT==(FlowHeader.ReadP>>16))
				ClearLogFor(skip);
			sBlk[0] = sAddrT;
			mFlashBlockErase(1,sBlk);
		}
	}
	if ((UnLong)pTo+pSize>=FlowHeader.EndAddr)
	{
		skip = FlowHeader.EndAddr - (UnLong)pTo;

    	mFlashProgram((UnLong)pTo,skip,pFrom);
    	pTo = (CONSTCHAR*)FlowHeader.FromAddr;
    	pFrom = pFrom+skip;
    	skip = pSize - skip;
	}
	else
		skip = pSize;
   	mFlashProgram((UnLong)pTo,skip,pFrom);
#endif
}

//read a log record to the buffer Area
//return:0--no log record
//	     -1--error on log record
short Read_Flow(BYTE *Area)
{
	short	sLength;
	short 	i;

	if (FlowHeader.ReadP==FlowHeader.NextNP)
		return 0;//no Log record

	ReadFrLogRam(Area,(CONSTCHAR*)FlowHeader.ReadP,1);
	i =	Area[0] & 0x1f;
	if (i>0 && i<=LOGTYPEMAX)
	{
		Area++;
		if (i==GIVENLOG)
		{
			ReadFrLogRam(Area,(CONSTCHAR*)FlowHeader.ReadP+1,1);
			sLength = (Area[0] & 0x0f) * sizeof(struct GIVEN_DATA);
			Area++;
			i = 2;
		}
		else
		{
			sLength = LogSize[i-1].RecSize-1;
			i = 1;
		}
		ReadFrLogRam(Area,(CONSTCHAR*)FlowHeader.ReadP+i,sLength);
	   	FlowHeader.ReadP = FlowHeader.ReadP + i + sLength;
	   	ADJLOGADDR(FlowHeader.ReadP);
		return i+sLength;
	}
	else
		return -1;
}


short Collect_Data(BYTE cmd)
{
	char 	Blk[1];
	short		Length,i;							// write flow record size every time
	BCD		Temp;
	WORD    sTime;
	WORD 	sDate;  //cc 2006-07-07 for MMC

#if(defined(FISCAL))	//cc 20071026
	if(ApplVar.FTrain)
		return 1;
#endif

    	if ((!TESTBIT(DOT,BIT2)&&(cmd==NOADDLOG || cmd==OPERLOG || cmd==LOCKLOG))
		|| FlowHeader.MAXNUMB<LOGALARMON)
		return 1;
	Length = 0;
	FlowBuff.CDC_dpt.FunN = cmd;
	switch(cmd)
	{
		case PORALOG:
		    if (!TESTBIT(ApplVar.PoRa.Options, BIT3))
				FlowBuff.CDC_PoRa.FunN |= 0x80;
			FlowBuff.CDC_PoRa.PoRaN = ApplVar.PoRaNumber+1;
			memcpy(FlowBuff.CDC_PoRa.FAmt, ApplVar.Amt.Value, sizeof(FlowBuff.CDC_PoRa.FAmt));
			Length = sizeof(FlowBuff.CDC_PoRa);
			break;
		case DPTLOG:
        	if (ApplVar.FRefund || ApplVar.FTrvoid)
				FlowBuff.CDC_dpt.FunN |= 0x80;
			if ((ApplVar.FVoid || ApplVar.FCorr) && TESTBIT(ApplVar.Qty.Sign,BIT7))
				FlowBuff.CDC_dpt.FunN |= 0xc0;
			FlowBuff.CDC_dpt.DeptN = ApplVar.DeptNumber+1;
			Temp = ApplVar.Qty;
			ChangeQty(&Temp);
			memcpy(FlowBuff.CDC_dpt.FQty, Temp.Value, sizeof(FlowBuff.CDC_dpt.FQty));
			memcpy(FlowBuff.CDC_dpt.FAmt, ApplVar.Amt.Value, sizeof(FlowBuff.CDC_dpt.FAmt));
			Length = sizeof(FlowBuff.CDC_dpt);
			break;
		case ARTLOG:
        	if (ApplVar.FRefund || ApplVar.FTrvoid)
				FlowBuff.CDC_art.FunN |= 0x80;
			if ((ApplVar.FVoid || ApplVar.FCorr) && TESTBIT(ApplVar.Qty.Sign,BIT7))
				FlowBuff.CDC_art.FunN |= 0xc0;
			memcpy(FlowBuff.CDC_art.ArtN, ApplVar.Plu.Random, sizeof(ApplVar.Plu.Random));
			FlowBuff.CDC_art.DeptN = ApplVar.DeptNumber+1;
			Temp = ApplVar.Qty;
			ChangeQty(&Temp);
			memcpy(FlowBuff.CDC_art.FQty, Temp.Value, sizeof(FlowBuff.CDC_art.FQty));
			memcpy(FlowBuff.CDC_art.FAmt, ApplVar.Amt.Value, sizeof(FlowBuff.CDC_art.FAmt));
            if (ApplVar.OFFNumber < ApplVar.AP.OFFPrice.Number)
				FlowBuff.CDC_art.OffNum = ApplVar.OFFNumber+1;
			else
				FlowBuff.CDC_art.OffNum = 0;
			Length = sizeof(FlowBuff.CDC_art);
			break;
		case ENDLOG:
        	if (ApplVar.FTrvoid || (ApplVar.SubTotal.Sign & 0x80))
				FlowBuff.CDC_end.FunN |= 0x80;
            memset(FlowBuff.CDC_end.ReceiptNum,0,sizeof(FlowBuff.CDC_end.ReceiptNum));//ccr20120101
			ULongToBCDValue(FlowBuff.CDC_end.ReceiptNum, ApplVar.FisNumber.TotalReceiptNum[FRECEIPTS]);//ccr091027
			memcpy(FlowBuff.CDC_end.Fcost, ApplVar.SubTotal.Value, sizeof(FlowBuff.CDC_end.Fcost));
			Now(&temp);
			FlowBuff.CDC_end.FDay = temp.day;
			FlowBuff.CDC_end.FMonth = temp.month;
			FlowBuff.CDC_end.FYear = (BYTE)temp.year;
			FlowBuff.CDC_end.FHour = temp.hour;
			FlowBuff.CDC_end.FMinute = temp.min;
			Length = sizeof(FlowBuff.CDC_end);
			break;
		case NOADDLOG:
#if !DEBUGBYPC
			if(ApplVar.NumberEntry != 0)
				memcpy(FlowBuff.CDC_noadd.Num,(char*)&ApplVar.NumberEntry,sizeof(FlowBuff.CDC_noadd.Num));
			else
				memcpy(FlowBuff.CDC_noadd.Num,(char*)&ApplVar.DrawNumber,sizeof(FlowBuff.CDC_noadd.Num));
#endif
			Length = sizeof(FlowBuff.CDC_noadd);
			break;
		case OPERLOG:
			FlowBuff.CDC_oper.OperN=(BYTE)ApplVar.ClerkNumber;
			Length = sizeof(FlowBuff.CDC_oper);
			break;
		case GIVENLOG:
			FlowBuff.CDC_given.Counter = GCouter;
        		if (ApplVar.FTrvoid || (CollectGiven[0].FTType & 0x80))
			{
				FlowBuff.CDC_given.FunN |= 0x80;
				CollectGiven[0].FTType &= 0x7f;
			}
			for(i=0;i<GCouter;i++)
				FlowBuff.CDC_given.GivenData[i]	= CollectGiven[i];
			Length = sizeof(struct GIVEN_DATA)*GCouter+2;
			GCouter = 0;
			break;
		case LOCKLOG:
			FlowBuff.CDC_lock.NoModeLock = ApplVar.NumberEntry;
			Length = sizeof(FlowBuff.CDC_lock);
			break;
		case DISCADDLOG:
			if(ApplVar.DiscNumber==1)
				FlowBuff.CDC_discadd.FunN |= 0x80;
			if(ApplVar.FVoid)
				FlowBuff.CDC_discadd.FunN ^= 0xc0;
//        	if (ApplVar.FRefund==1)	//ccr 050608 �˻�����  //
//				FlowBuff.CDC_discadd.FunN |= 0x40;

			memcpy(FlowBuff.CDC_discadd.Percent, ApplVar.Entry.Value, sizeof(FlowBuff.CDC_discadd.Percent));// percent
			memcpy(FlowBuff.CDC_discadd.FAmt, ApplVar.Amt.Value, sizeof(FlowBuff.CDC_discadd.FAmt));
			memcpy(FlowBuff.CDC_discadd.ArtN, ApplVar.Plu.Random, sizeof(ApplVar.Plu.Random));
			Length = sizeof(FlowBuff.CDC_discadd);
			break;
		case SUBDISCADDLOG:
			if(ApplVar.DiscNumber==1)
				FlowBuff.CDC_subdiscadd.FunN |= 0x80;
			if(ApplVar.FVoid)
				FlowBuff.CDC_subdiscadd.FunN ^= 0xc0;
//        	if (ApplVar.FRefund==1)   //ccr 050608 �˻�����  //
//				FlowBuff.CDC_discadd.FunN |= 0x40;

			memcpy(FlowBuff.CDC_subdiscadd.Percent, ApplVar.Entry.Value, sizeof(FlowBuff.CDC_subdiscadd.Percent));// percent
			memcpy(FlowBuff.CDC_subdiscadd.FAmt, ApplVar.Amt.Value, sizeof(FlowBuff.CDC_subdiscadd.FAmt));
			Length = sizeof(FlowBuff.CDC_subdiscadd);
			break;
		case DIRECTLOG:
			if(ApplVar.DiscNumber==3)
				FlowBuff.CDC_direct.FunN |= 0x80;
			if(ApplVar.FVoid)
				FlowBuff.CDC_direct.FunN ^= 0xc0;
			memcpy(FlowBuff.CDC_direct.FAmt, ApplVar.Amt.Value, sizeof(FlowBuff.CDC_direct.FAmt));
			memcpy(FlowBuff.CDC_direct.ArtN, ApplVar.Plu.Random, sizeof(ApplVar.Plu.Random));
			Length = sizeof(FlowBuff.CDC_direct);
			break;
		case SUBDIRECTLOG:
			if(ApplVar.DiscNumber==3)
				FlowBuff.CDC_subdirect.FunN |= 0x80;
			if(ApplVar.FVoid)
				FlowBuff.CDC_subdirect.FunN ^= 0xc0;
			memcpy(FlowBuff.CDC_subdirect.FAmt, ApplVar.Amt.Value, sizeof(FlowBuff.CDC_subdirect.FAmt));
			Length = sizeof(FlowBuff.CDC_subdirect);
			break;
		case REGISLOG:
            ApplVar.FlowBuff.CDC_regis.EcrNumber = ((WORD)LOCATION*256)+REGISTER;//ccr2014-11-14
			FlowBuff.CDC_regis.OperNo =	(BYTE)ApplVar.ClerkNumber;
			FlowBuff.CDC_regis.SalesPer = (BYTE)ApplVar.SalPerNumber;
            memset(FlowBuff.CDC_end.ReceiptNum,0,sizeof(FlowBuff.CDC_end.ReceiptNum));//ccr20120101
			ULongToBCDValue(FlowBuff.CDC_end.ReceiptNum, ApplVar.FisNumber.TotalReceiptNum[FRECEIPTS]);//ccr091027 ReceiptNum����̫С
			Now(&temp);
			FlowBuff.CDC_regis.FDay = temp.day;
			FlowBuff.CDC_regis.FMonth = temp.month;
			FlowBuff.CDC_regis.FYear = 	(BYTE)temp.year;
			FlowBuff.CDC_regis.FHour = temp.hour;
			FlowBuff.CDC_regis.FMinute = temp.min;
			FlowBuff.CDC_regis.FSecond = temp.sec;
			Length = sizeof(FlowBuff.CDC_regis);
			break;
		case SUBTOTALLOG:
        		if ((ApplVar.SubTotal.Sign & 0x80) == 0x80)
				FlowBuff.CDC_subtotal.FunN |= 0x80;
            memset(FlowBuff.CDC_end.ReceiptNum,0,sizeof(FlowBuff.CDC_end.ReceiptNum));//ccr20120101
			ULongToBCDValue(FlowBuff.CDC_end.ReceiptNum, ApplVar.FisNumber.TotalReceiptNum[FRECEIPTS]);//ccr091027 ReceiptNum����̫С
			memcpy(FlowBuff.CDC_subtotal.FAmt, ApplVar.SubTotal.Value, sizeof(FlowBuff.CDC_subtotal.FAmt));
			Now(&temp);
			FlowBuff.CDC_subtotal.FDay = temp.day;
			FlowBuff.CDC_subtotal.FMonth = temp.month;
			FlowBuff.CDC_subtotal.FYear = (BYTE)temp.year;
			FlowBuff.CDC_subtotal.FHour = temp.hour;
			FlowBuff.CDC_subtotal.FMinute = temp.min;
			Length = sizeof(FlowBuff.CDC_subtotal);
			break;
		case PRICELISTLOG:
			FlowBuff.CDC_pricelist.PListNo = ApplVar.PluPriceLevel+1;
			Length = sizeof(FlowBuff.CDC_pricelist);
			break;
		case TVOIDLOG:
			memcpy(FlowBuff.CDC_Void.FAmt, ApplVar.SubTotal.Value, sizeof(FlowBuff.CDC_Void.FAmt));
			Now(&temp);
			FlowBuff.CDC_Void.FDay = temp.day;
			FlowBuff.CDC_Void.FMonth = temp.month;
			FlowBuff.CDC_Void.FYear = (BYTE)temp.year;
			FlowBuff.CDC_Void.FHour = temp.hour;
			FlowBuff.CDC_Void.FMinute = temp.min;
			Length = sizeof(FlowBuff.CDC_Void);
			break;
		case PBCLOSELOG:
			FlowBuff.CDC_PbClose.PBNo = ApplVar.PbNumber;
			memcpy(FlowBuff.CDC_PbClose.FAmt, ApplVar.PB.Amt.Value, sizeof(FlowBuff.CDC_PbClose.FAmt));
			Now(&temp);
			FlowBuff.CDC_PbClose.FDay = temp.day;
			FlowBuff.CDC_PbClose.FMonth = temp.month;
			FlowBuff.CDC_PbClose.FYear = (BYTE)temp.year;
			FlowBuff.CDC_PbClose.FHour = temp.hour;
			FlowBuff.CDC_PbClose.FMinute = temp.min;
			Length = sizeof(FlowBuff.CDC_PbClose);
			break;
		case PBOPENLOG:
			FlowBuff.CDC_PbOpen.PBNo = ApplVar.NumberEntry;
			Now(&temp);
			FlowBuff.CDC_PbOpen.FDay = temp.day;
			FlowBuff.CDC_PbOpen.FMonth = temp.month;
			FlowBuff.CDC_PbOpen.FYear = (BYTE)temp.year;
			FlowBuff.CDC_PbOpen.FHour = temp.hour;
			FlowBuff.CDC_PbOpen.FMinute = temp.min;
			Length = sizeof(FlowBuff.CDC_PbOpen);
			break;
		case TRTABLELOG:
			FlowBuff.CDC_PbTt.PBFNo = ApplVar.PbNumber;
			FlowBuff.CDC_PbTt.PBTNo = ApplVar.NumberEntry;
			memcpy(FlowBuff.CDC_PbTt.FAmt, ApplVar.Amt.Value, sizeof(FlowBuff.CDC_PbTt.FAmt));
			Now(&temp);
			FlowBuff.CDC_PbTt.FDay = temp.day;
			FlowBuff.CDC_PbTt.FMonth = temp.month;
			FlowBuff.CDC_PbTt.FYear = (BYTE)temp.year;
			FlowBuff.CDC_PbTt.FHour = temp.hour;
			FlowBuff.CDC_PbTt.FMinute = temp.min;
			Length = sizeof(FlowBuff.CDC_PbTt);
			break;
#if (DD_CHIPC==1)
/*		case INSERTICLOG://ccr chipcard>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
			if (IC.CHIP_Flag>=0)
			{
				Now(&temp);
				FlowBuff.CDC_enteric.Serialum = IC.CardNo;
				FlowBuff.CDC_enteric.ICType = IC.CHIP_Flag;
				FlowBuff.CDC_enteric.ICFlag = IC.REC_INIT[CC_FTIPO];
				FlowBuff.CDC_enteric.FYear = (BYTE)temp.year;
				FlowBuff.CDC_enteric.FMonth = temp.month;						 //
				FlowBuff.CDC_enteric.FDay = temp.day;							 // date
				memcpy(FlowBuff.CDC_enteric.Custname,&IC.REC_Customer[CC_CNOME],sizeof(FlowBuff.CDC_enteric.Custname));
//				CWORD(FlowBuff.CDC_refreshic.Custflag) = CWORD(IC.REC_Customer[CC_CFLAGS]);


				sTime = (((temp.hour>>4)*10+(temp.hour & 0x0f))<<11)
						+ (((temp.min>>4)*10+(temp.min & 0x0f))<<5)
						+ (((temp.sec>>4)*10+(temp.sec & 0x0f))>>1);
				CWORD(FlowBuff.CDC_refreshic.Custflag) =  sTime;
				CWORD(FlowBuff.CDC_enteric.Discount) = CWORD(IC.REC_Customer[CC_CPERC]);

				icBCD2EcrBCD(&Temp,&IC.REC_VALATT[CC_VAL],CC_PRGVEN-CC_VAL);
				memcpy(FlowBuff.CDC_enteric.Value,Temp.Value,sizeof(FlowBuff.CDC_enteric.Value));
				icBCD2EcrBCD(&Temp,&IC.REC_VALATT[CC_PUNTI],CC_FORE-CC_PUNTI);
				memcpy(FlowBuff.CDC_enteric.Point,Temp.Value,sizeof(FlowBuff.CDC_enteric.Point));
				Length = sizeof(FlowBuff.CDC_enteric);
				break;
			}
			else
				return 0;
*/
		case REFRESHICLOG:
			if (IC.CHIP_Flag>=0)
			{
				Now(&temp);
				if (ApplVar.FRefund==1)	//ccr 050608 �˻�����  //
					FlowBuff.CDC_refreshic.FunN |= 0x80;

				FlowBuff.CDC_refreshic.Serialum = IC.CardNo;
				FlowBuff.CDC_refreshic.ICType = IC.CHIP_ICTYPE;
				FlowBuff.CDC_refreshic.ICFlag = IC.REC_INIT[CC_FTIPO];
				FlowBuff.CDC_refreshic.FYear = (BYTE)temp.year;
				FlowBuff.CDC_refreshic.FMonth = temp.month;						 //
				FlowBuff.CDC_refreshic.FDay = temp.day;							 // date
				memcpy(FlowBuff.CDC_refreshic.Custname,&IC.REC_Customer[CC_CNOME],sizeof(FlowBuff.CDC_refreshic.Custname));
//				CWORD(FlowBuff.CDC_refreshic.Custflag) = CWORD(IC.REC_Customer[CC_CFLAGS]);

				sTime = (((temp.hour>>4)*10+(temp.hour & 0x0f))<<11)
						+ (((temp.min>>4)*10+(temp.min & 0x0f))<<5)
						+ (((temp.sec>>4)*10+(temp.sec & 0x0f))>>1);
				CWORD(FlowBuff.CDC_refreshic.Custflag) =  sTime;

				CWORD(FlowBuff.CDC_refreshic.Discount) = CWORD(IC.REC_Customer[CC_CPERC]);
				icBCD2EcrBCD(&Temp,&IC.REC_VALATT[CC_VAL],CC_PRGVEN-CC_VAL);
				memcpy(FlowBuff.CDC_refreshic.CValue,Temp.Value,sizeof(FlowBuff.CDC_refreshic.CValue));
				icBCD2EcrBCD(&Temp,&IC.REC_VALATT[CC_PUNTI],CC_FORE-CC_PUNTI);
				memcpy(FlowBuff.CDC_refreshic.CPoint,Temp.Value,sizeof(FlowBuff.CDC_refreshic.CPoint));
				Length = sizeof(FlowBuff.CDC_refreshic);
				break;
			}
			else
				return 0;//ccr chipcard<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#endif
		case SLIPREGISLOG:
		case SLIPENDLOG:
		default:
			return 0;
	}

	i = 0;
	while (CheckLogBuff()<Length && i<3) i++;
	if (i<3)
	{

		WriteToLogRam((CONSTCHAR *)FlowHeader.NextNP,(char *)&FlowBuff,Length);
		FlowHeader.NextNP = FlowHeader.NextNP + Length;
		ADJLOGADDR(FlowHeader.NextNP);
	}
	memset((BYTE *)&FlowBuff,0,Length);
	return 1;
}


void Init_Flow()
{
#ifndef LOGONRAM
	short	i,sBlkFr,sBlkTo;
	char BlkBuf[8];

	sBlkFr = FLSTARTADDRE>>16;
	sBlkTo = (FLSTARTADDRE+FLOWMAXB-1)>>16;

	i = sBlkTo - sBlkFr + 1;
	for (i=0;i<=sBlkTo-sBlkFr;i++)
		BlkBuf[i]=(sBlkFr+i)&0x0f;
	if (i==8)
		mFlashChipErase();
	else
		if (i>0 && i<8)
			mFlashBlockErase(i,BlkBuf);
#endif
/*	FlowHeader.FromAddr = FLSTARTADDRE;
	FlowHeader.EndAddr = FLSTARTADDRE+FLOWMAXB;
   	FlowHeader.ReadP = 	FLSTARTADDRE;
   	FlowHeader.NextNP = 	FLSTARTADDRE;
 	FlowHeader.HeadP = 	FLSTARTADDRE;
   	FlowHeader.MAXNUMB = FLOWMAXB;
	FlowHeader.OverCount = 0;
*/
	FlowHeader.FromAddr = ApplVar.AP.StartAddress[AddrEndP]+8;
	FlowHeader.EndAddr = ApplVar.SIZE_EXTRAM;

 	if (FlowHeader.EndAddr <= FlowHeader.FromAddr || (FlowHeader.EndAddr-FlowHeader.FromAddr)<4*LOGALARMON)
 	{
		FlowHeader.FromAddr = 0;
		FlowHeader.EndAddr = 0;
	   	FlowHeader.ReadP = 0;
	   	FlowHeader.NextNP = 0;
	 	FlowHeader.HeadP = 0;
	   	FlowHeader.MAXNUMB = 0;
	}
	else
	{
   		FlowHeader.ReadP = 	FlowHeader.FromAddr;
   		FlowHeader.NextNP = FlowHeader.FromAddr;
	 	FlowHeader.HeadP = 	FlowHeader.FromAddr;
   		FlowHeader.MAXNUMB = FlowHeader.EndAddr - FlowHeader.FromAddr;
   	}
	FlowHeader.OverCount = 0;
	GCouter = 0;
	memset((BYTE *)&FlowBuff,0,sizeof(FlowBuff));
	memset((BYTE *)&CollectGiven,0,sizeof(CollectGiven));
}

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

BYTE PrintFlowQtyAmt(BCD *qty,CONSTCHAR *str,BCD *amt)
{
    BYTE l, rlen;


    if (amt)
	{
		if (qty)
		{
			rlen = strlen(str);
			while (*(str+rlen -1)==' ' && rlen)
				rlen--;

			if((rlen+BCDWidth(qty))>13)
			{
				PrintRJ(str);
				MemSet(SysBuf, sizeof(SysBuf), ' ');
				FormatAmt(SysBuf +PRTLEN - 1, amt);
				FormatQty(SysBuf + 6+(PRTLEN>32)*2, qty);
				PrintRJ(SysBuf);
			}
#if (PRTLEN<25)
		    else if (BCDWidth(&ApplVar.Price)>5 || BCDWidth(amt)>5)
#else
		    else if (BCDWidth(&ApplVar.Price)>6 || BCDWidth(amt)>6)
#endif
			{
				MemSet(ProgLineMes, sizeof(ProgLineMes), ' ');
				strcpy(ProgLineMes,FormatQtyStr(str,qty,14));
				PrintRJ(ProgLineMes);
				MemSet(SysBuf, sizeof(SysBuf), ' ');
				FormatAmt(SysBuf +PRTLEN - 1, amt);
				PrintRJ(SysBuf);
			}
			else
				PrintRJ(FormatStrQtyPriAmt(str, qty, 0, amt, PRTLEN));
		}
		else
	    	PrintRJ(FormatAmtStr(str, amt, PRTLEN));
    }
    else if (qty)
		PrintRJ(FormatQtyStr(str, qty, PRTLEN));
    else
		PrintRJ(str);
    return 0;
}
//    -----------------------------------------------------------------------------
void DispNULL()
{
}
//-----------------------------------------------------------------------------
void DispPoRa()
{
	BCD sQty,sAmt;
	short i;

	ApplVar.PoRaNumber = FlowBuff.CDC_PoRa.PoRaN-1;
	ReadPoRa();

	ApplVar.PoRa.Name[sizeof(ApplVar.PoRa.Name)-1] = 0;

	sAmt = ZERO;

	memcpy(sAmt.Value,(char *)&FlowBuff.CDC_PoRa.FAmt,sizeof(FlowBuff.CDC_PoRa.FAmt));

	sAmt.Sign |= 2;
	PrintFlowQtyAmt(0,ApplVar.PoRa.Name,&sAmt);
}
//-----------------------------------------------------------------------------
void DispDept()
{
	BCD sQty,sAmt;
	short i;

	ApplVar.DeptNumber = FlowBuff.CDC_dpt.DeptN-1;
	ReadDept();

	sQty = ZERO;
	sAmt = ZERO;

	memcpy(sQty.Value,(char *)&FlowBuff.CDC_dpt.FQty,sizeof(FlowBuff.CDC_dpt.FQty));
	memcpy(sAmt.Value,(char *)&FlowBuff.CDC_dpt.FAmt,sizeof(FlowBuff.CDC_dpt.FAmt));

	sQty.Sign |= 3;
	for (i=0;i<3;i++)
	{
		if (!(sQty.Value[0] & 0x0f))
		{
			BcdDiv10(&sQty);
			sQty.Sign--;
		}
		else
			break;
	}
	sAmt.Sign |= 2;

	if (FlowBuff.CDC_dpt.FunN & 0x40)
	{
		RJPrint(CMDP_DR,Def.Correc[0].Name);
		FlowBuff.CDC_dpt.FunN |= 0x80;
	}
	else if (FlowBuff.CDC_art.FunN & 0x80)
		RJPrint(CMDP_DR,Def.Correc[2].Name);
	if (FlowBuff.CDC_dpt.FunN & 0x80)
	{
		sQty.Sign |= 0x80;
		sAmt.Sign |= 0x80;
	}
	PrintFlowQtyAmt(&sQty,ApplVar.Dept.Name,&sAmt);
//	EcrLogForm->QtyTotal = EcrLogForm->QtyTotal + sQty;
//	EcrLogForm->AmtTotal = EcrLogForm->AmtTotal + sAmt;
}
//-----------------------------------------------------------------------------
void DispPlu()
{
	BCD sQty,sAmt;
	short i;

	if (ApplVar.AP.Plu.RandomSize)
	{
		ApplVar.PluNumber = GetPluNumber(1, FlowBuff.CDC_art.ArtN);
		if (ApplVar.PluNumber)
			ApplVar.PluNumber--;
	}
	else
	{
		ApplVar.PluNumber = Bcd2Long((char *)&FlowBuff.CDC_art.ArtN,sizeof(FlowBuff.CDC_art.ArtN));
	}

	ReadPlu();

	sQty = ZERO;
	sAmt = ZERO;

	memcpy(sQty.Value,(char *)&FlowBuff.CDC_art.FQty,sizeof(FlowBuff.CDC_art.FQty));
	memcpy(sAmt.Value,(char *)&FlowBuff.CDC_art.FAmt,sizeof(FlowBuff.CDC_art.FAmt));

	sQty.Sign |= 3;
	for (i=0;i<3;i++)
	{
		if (!(sQty.Value[0] & 0x0f))
		{
			BcdDiv10(&sQty);
			sQty.Sign--;
		}
		else
			break;
	}
	sAmt.Sign |= 2;

	if (FlowBuff.CDC_art.FunN & 0x40)
	{
		RJPrint(CMDP_DR,Def.Correc[0].Name);
		FlowBuff.CDC_art.FunN |= 0x80;
	}
	else if (FlowBuff.CDC_art.FunN & 0x80)
		RJPrint(CMDP_DR,Def.Correc[2].Name);
	if (FlowBuff.CDC_art.FunN & 0x80)
	{
		sQty.Sign |= 0x80;
		sAmt.Sign |= 0x80;
	}
	PrintFlowQtyAmt(&sQty,ApplVar.Plu.Name,&sAmt);
//	EcrLogForm->QtyTotal = EcrLogForm->QtyTotal + sQty;
//	EcrLogForm->AmtTotal = EcrLogForm->AmtTotal + sAmt;

}
//-----------------------------------------------------------------------------
void  DispEnd()
{
	BCD sAmt;
	short i;

	sAmt = ZERO;
	memcpy(sAmt.Value,(char *)&FlowBuff.CDC_end.Fcost,sizeof(FlowBuff.CDC_end.Fcost));

	PrintLine('-');
	PrintFlowQtyAmt(0,Prompt.Caption[0],&sAmt);
//	EcrLogForm->AmtTotal = EcrLogForm->AmtTotal + sAmt;
}
//-----------------------------------------------------------------------------
void  DispNonAdd()
{
//	RJPrint(0,Msg[DKQXIANG].str);
}
//-----------------------------------------------------------------------------
void  DispOperator()
{
	char sTmpBuf[20];
	short i = ApplVar.ClerkNumber;

	memset(sTmpBuf,' ',sizeof(sTmpBuf));
	ApplVar.ClerkNumber = FlowBuff.CDC_oper.OperN;
	ReadClerk();
	ApplVar.Clerk.Name[sizeof(ApplVar.Clerk.Name)-1] = 0;
    CopyFrStr(sTmpBuf,DMes[20]);
    CopyFrStr(sTmpBuf+8,ApplVar.Clerk.Name);
    RJPrint(0,sTmpBuf);

	ApplVar.ClerkNumber = i;
}
//-----------------------------------------------------------------------------
void  DispTender()
{
	BCD sAmt;
	short i,j,k,l;

	j = ApplVar.TendNumber;
	for (j=0;j<FlowBuff.CDC_given.Counter;j++)
	{
		ApplVar.TendNumber = FlowBuff.CDC_given.GivenData[j].FTType-1;
		ReadTender();
		ApplVar.Tend.Name[sizeof(ApplVar.Tend.Name)-1] = 0;
		sAmt = ZERO;
		memcpy(sAmt.Value,(char *)&FlowBuff.CDC_given.GivenData[j].FAmt,sizeof(FlowBuff.CDC_given.GivenData[j].FAmt));
		PrintFlowQtyAmt(0,ApplVar.Tend.Name,&sAmt);
	}
	PrintLine('*');
	ApplVar.TendNumber = j;
}
//-----------------------------------------------------------------------------


void  DispModeLock()
{
}
//-----------------------------------------------------------------------------
void  DispPercentDisc()
{
	BCD sQty,sAmt;
	short i;
	char sTmpBuf[20];

	sQty = sAmt = ZERO;
	memcpy(sQty.Value,(char *)&FlowBuff.CDC_discadd.Percent,sizeof(FlowBuff.CDC_discadd.Percent));
	memcpy(sAmt.Value,(char *)&FlowBuff.CDC_discadd.FAmt,sizeof(FlowBuff.CDC_discadd.FAmt));

	if (FlowBuff.CDC_discadd.FunN & 0x80)
	{
		sQty.Sign |= 0x80;
		sAmt.Sign |= 0x80;
		memcpy(&ApplVar.Disc,(CONSTCHAR *)&Def.Disc+sizeof(ApplVar.Disc),sizeof(ApplVar.Disc));
	}
	else
		memcpy(&ApplVar.Disc,(CONSTCHAR *)&Def.Disc,sizeof(ApplVar.Disc));
#if (PRTLEN<25)
	strcpy(sTmpBuf,FormatAmtStr(ApplVar.Disc.Name,&sQty,12));
	sTmpBuf[12] = '%';
	sTmpBuf[13] = 0;
#else
	strcpy(sTmpBuf,FormatAmtStr(ApplVar.Disc.Name,&sQty,15));
	sTmpBuf[15] = '%';
	sTmpBuf[16] = 0;
#endif
	PrintFlowQtyAmt(0,sTmpBuf,&sAmt);

//	EcrLogForm->QtyTotal = EcrLogForm->QtyTotal + sQty;
//	EcrLogForm->AmtTotal = EcrLogForm->AmtTotal + sAmt;
}
//-----------------------------------------------------------------------------
void  DispSubTotalDisc()
{
	BCD sQty,sAmt;
	short i;
	char sTmpBuf[20];

	sQty = sAmt = ZERO;
	memcpy(sQty.Value,(char *)&FlowBuff.CDC_subdiscadd.Percent,sizeof(FlowBuff.CDC_subdiscadd.Percent));
	memcpy(sAmt.Value,(char *)&FlowBuff.CDC_subdiscadd.FAmt,sizeof(FlowBuff.CDC_subdiscadd.FAmt));

	if (FlowBuff.CDC_subdiscadd.FunN & 0x80)
	{
		memcpy(&ApplVar.Disc,(CONSTCHAR *)&Def.Disc+sizeof(ApplVar.Disc),sizeof(ApplVar.Disc));
		sQty.Sign |= 0x80;
		sAmt.Sign |= 0x80;
//		EcrLogForm->sDiscPerTotalS = EcrLogForm->sDiscPerTotalS + sAmt;
	}
	else
	{
		memcpy(&ApplVar.Disc,(CONSTCHAR *)&Def.Disc,sizeof(ApplVar.Disc));
//		EcrLogForm->aDiscPerTotalS = EcrLogForm->aDiscPerTotalS + sAmt;
	}
#if (PRTLEN<25)
	strcpy(sTmpBuf,FormatAmtStr(ApplVar.Disc.Name,&sQty,12));
	sTmpBuf[12] = '%';
	sTmpBuf[13] = 0;
#else
	strcpy(sTmpBuf,FormatAmtStr(ApplVar.Disc.Name,&sQty,15));
	sTmpBuf[15] = '%';
	sTmpBuf[16] = 0;
#endif
	PrintFlowQtyAmt(0,sTmpBuf,&sAmt);
//	EcrLogForm->QtyTotal = EcrLogForm->QtyTotal + sQty;
//	EcrLogForm->AmtTotal = EcrLogForm->AmtTotal + sAmt;
}
//-----------------------------------------------------------------------------
void  DispDirectDisc()
{
	BCD sAmt;
	short i;

	sAmt = ZERO;
	memcpy(sAmt.Value,(char *)&FlowBuff.CDC_direct.FAmt,sizeof(FlowBuff.CDC_direct.FAmt));

	if (FlowBuff.CDC_subdiscadd.FunN & 0x80)
	{
		memcpy(&ApplVar.Disc,(CONSTCHAR *)&Def.Disc+3*sizeof(ApplVar.Disc),sizeof(ApplVar.Disc));
		sAmt.Sign |= 0x80;
//		EcrLogForm->sDiscDirTotal = EcrLogForm->sDiscDirTotal + sAmt;
	}
	else
	{
		memcpy(&ApplVar.Disc,(CONSTCHAR *)&Def.Disc+2*sizeof(ApplVar.Disc),sizeof(ApplVar.Disc));
//		EcrLogForm->aDiscDirTotal = EcrLogForm->aDiscDirTotal + sAmt;
	}
	PrintFlowQtyAmt(0,ApplVar.Disc.Name,&sAmt);
//	EcrLogForm->AmtTotal = EcrLogForm->AmtTotal + sAmt;
}
//-----------------------------------------------------------------------------
void  DispSubTotalDirDisc()
{
	BCD sAmt;
	short i;

	sAmt = ZERO;
	memcpy(sAmt.Value,(char *)&FlowBuff.CDC_subdirect.FAmt,sizeof(FlowBuff.CDC_subdirect.FAmt));

	if (FlowBuff.CDC_subdiscadd.FunN & 0x80)
	{
		memcpy(&ApplVar.Disc,(CONSTCHAR *)&Def.Disc+3*sizeof(ApplVar.Disc),sizeof(ApplVar.Disc));
		sAmt.Sign |= 0x80;
//		EcrLogForm->sDiscDirTotalS = EcrLogForm->sDiscDirTotalS + sAmt;
	}
	else
	{
		memcpy(&ApplVar.Disc,(CONSTCHAR *)&Def.Disc+2*sizeof(ApplVar.Disc),sizeof(ApplVar.Disc));
//		EcrLogForm->aDiscDirTotalS = EcrLogForm->aDiscDirTotalS + sAmt;
	}
//	EcrLogForm->AmtTotal = EcrLogForm->AmtTotal + sAmt;
	PrintFlowQtyAmt(0,ApplVar.Disc.Name,&sAmt);
}
//-----------------------------------------------------------------------------
void  DispNew()
{
	short i,j;
	BYTE cpClerk,cpSaler;

	cpClerk = ApplVar.ClerkNumber;
	cpSaler = ApplVar.SalPerNumber;

//	PrintLine('*');
	memset(SysBuf,' ',sizeof(SysBuf));
	i = 0;
	if (FlowBuff.CDC_regis.OperNo>0)
	{
		ApplVar.ClerkNumber = FlowBuff.CDC_regis.OperNo;
		ReadClerk();
		strcpy(SysBuf,DMes[20]);
		strncpy(SysBuf+9,ApplVar.Clerk.Name,8);
		i = 16;
	}
	if (FlowBuff.CDC_regis.SalesPer>0)
	{
		ApplVar.SalPerNumber = FlowBuff.CDC_regis.SalesPer;
		ReadSalPer();
		strcpy(SysBuf+i,DMes[21]);
		strncpy(SysBuf+9+i,ApplVar.SalPer.Name,8);
		i = 1;
	}
	if (i)
	{
		RJPrint(0,SysBuf);
		memset(SysBuf,' ',sizeof(SysBuf));
	}

	SysBuf[0] = '2';SysBuf[1] = '0';
	HEXtoASC(SysBuf+2,&FlowBuff.CDC_regis.FYear,1);SysBuf[4] = '-';
	HEXtoASC(SysBuf+6,&FlowBuff.CDC_regis.FMonth,1);SysBuf[8]='-';
	HEXtoASC(SysBuf+10,&FlowBuff.CDC_regis.FDay,1);SysBuf[12]= ' ';

	HEXtoASC(SysBuf+14,&FlowBuff.CDC_regis.FHour,1);SysBuf[16] = ':';
	HEXtoASC(SysBuf+17,&FlowBuff.CDC_regis.FMinute,1);SysBuf[19] = ':';
	HEXtoASC(SysBuf+20,&FlowBuff.CDC_regis.FSecond,1);
	SysBuf[25] = '#';
	HEXtoASC(SysBuf+26,FlowBuff.CDC_regis.ReceiptNum,RECEIPTLEN);
	RJPrint(0,SysBuf);
	ApplVar.PrintLayOut = 0x03;     /* R & J *///cc 2006-07-06 for MMC TEST
	PrintLine('.');
	RJPrint(0,Prompt.Title);
	PrintLine('=');

	ApplVar.ClerkNumber = cpClerk;
	ApplVar.SalPerNumber = cpSaler;
}
//-----------------------------------------------------------------------------
void  DispSubTotals()
{
	BCD sAmt;

	sAmt = ZERO;
	memcpy(sAmt.Value,(char *)&FlowBuff.CDC_subtotal.FAmt,sizeof(FlowBuff.CDC_subtotal.FAmt));
	PrintFlowQtyAmt(0,Prompt.Caption[1],&sAmt);
}
//-----------------------------------------------------------------------------
void  DispRPNew()
{
}
//-----------------------------------------------------------------------------
void  DispRPEnd()
{
}
//-----------------------------------------------------------------------------
void  DispInsertIC()
{
}
//-----------------------------------------------------------------------------
void  DispRefreshIC()
{
}
//-----------------------------------------------------------------------------
void  DispSetPrice()
{
}
//---------------------------------------------------------------------------

void DispEcrNum()
{
}
//---------------------------------------------------------------------------
void DispVoid()
{
	BCD sAmt;

	sAmt = ZERO;
	memcpy(sAmt.Value,(char *)&FlowBuff.CDC_Void.FAmt,sizeof(FlowBuff.CDC_Void.FAmt));
	sAmt.Sign |= 0x80;
	PrintFlowQtyAmt(0,Def.Correc[3].Name,&sAmt);
//	EcrLogForm->AmtTotal = EcrLogForm->AmtTotal + sAmt;
}
//---------------------------------------------------------------------------
void DispPbClose()
{
	BCD sAmt;

	sAmt = ZERO;
	memcpy(sAmt.Value,(char *)&FlowBuff.CDC_PbClose.FAmt,sizeof(FlowBuff.CDC_PbClose.FAmt));
//	EcrLogForm->AmtTotal = EcrLogForm->AmtTotal + sAmt;
	PrintFlowQtyAmt(0,Def.PbF[0].Name,&sAmt);
}
//---------------------------------------------------------------------------
void DispPbOpen()
{
	memset(SysBuf,' ',sizeof(SysBuf));
	CopyFrStr(SysBuf,Prompt.Caption[31]);
	CopyFrStr(SysBuf+6,Prompt.Caption[23]);
	WORDtoASC(SysBuf+15,FlowBuff.CDC_PbOpen.PBNo);
	RJPrint(0,SysBuf);
}
//---------------------------------------------------------------------------
void DispPbTransTo()
{
	BCD sAmt;
	short i;
	char sTmpBuf[20];

	sAmt = ZERO;
	memcpy(sAmt.Value,(char *)&FlowBuff.CDC_PbTt.FAmt,sizeof(FlowBuff.CDC_PbTt.FAmt));

	CopyFrStr(sTmpBuf,Prompt.Caption[23]);
	WORDtoASC(sTmpBuf+6,FlowBuff.CDC_PbTt.PBFNo);

	CopyFrStr(sTmpBuf+7,Def.PbF[8].Name);

	CopyFrStr(sTmpBuf+11,Prompt.Caption[23]);
	WORDtoASC(sTmpBuf+17,FlowBuff.CDC_PbTt.PBTNo);
	sTmpBuf[18]=0;

	PrintFlowQtyAmt(0,sTmpBuf,&sAmt);

//	EcrLogForm->AmtTotal = EcrLogForm->AmtTotal + sAmt;
}

//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

/**
 * ����ˮ��ȡָ��ָ��ʼλ��
 *
 * @author EutronSoftware (2014-12-01)
 */
void ResetECRFlow()
{
    ApplVar.FlowHeader.ReadP = ApplVar.FlowHeader.HeadP;
}

#endif

