#define PROGRAM_C
#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
#include "message.h"

//cc 2006-07-04 for MMC
#if(DD_MMC==1)
    #include "flowbill.h"
#endif
//cc 2006-07-04 for MMC


#include "fiscal.h"

CONST char Number0[]="Number=0";
BYTE ICBlockPrintFlag = 0;

short GrapNo;


void InitSysFlag()
{

    if (TESTBIT(COPYRECEIP, BIT7))      // ��ӡ��0�ձ���ʱ,�Ƿ�λ�վݺ�   ///
        SETBIT(ApplVar.AP.ReportList[2].Options, BIT2);
    else
        RESETBIT(ApplVar.AP.ReportList[2].Options, BIT2);

    ApplVar.AmtDecimal = NO_DECIMAL;
    Prefix1 = PREFIX_1;
    Prefix2 = PREFIX_2;
    if (TESTBIT(KEYTONE,BIT0))
    {
        Bios_1(BiosCmd_AutoClickOff);
    }
    else
    {
        Bios_1(BiosCmd_AutoClickOn);
    }

//    Density(0, DENSITY);      /* Density Receipt */
//    ApplVar.AP.Config.RDensity = DENSITY;
//    Density(1, DENSITY);       /* Density Journal */
//    ApplVar.AP.Config.JDensity = DENSITY;
//    ApplVar.AP.Config.Country = (CHARSET / 16);     /* set char set */
    if (ApplVar.AP.Config.Country > 4)
        ApplVar.AP.Config.Country = 0;
//    SetCountry(ApplVar.AP.Config.Country);      /* activate other character set */
#if !defined(FISCAL)
    Now.day--;      /* force new read of date and time incase format changed */
#endif

}


#if DD_FISPRINTER == 0
//BitNo:1..8  if (BitNo.Bit7=0),display it with caption
//����������1-No,0-Yesʱ,ʹ��sInv=YN������ȡ��
void CheckBitValue(short MsgIdx,char *Opt,BYTE BitNo,BYTE sInv)
{
    BYTE    BitV;

    BitV = BIT0<<((BitNo & 0x0f)-1);

    memset(ProgLineMes,' ',DISLEN+1);
    CopyFrStr(ProgLineMes+SETUPMARIN,Prompt.Caption[MsgIdx]);

#if (DD_ZIP==1 || DD_ZIP_21==1)
    memset(ProgLine1Mes,' ',DISLEN+1);
#endif

    if (!BitNumber)//ֻ��ʾ������ĵ�ǰֵ
        BitNumber = ((TESTBIT(*Opt,BitV)!=0) & 1)+1;
    else//�޸�������ĵ�ǰֵ
        SETBIT(ApplVar.MyFlags,CONFIGECR);
    if (BitNumber > 2)
        BitNumber = 1;
    if (BitNumber ==2)
    {
#if(DD_ZIP || DD_ZIP_21)
        ProgLine1Mes[DISLEN-1] = 'Y' ^ sInv;
#else
        ProgLineMes[DISLEN-1] = 'y' ^ sInv;
#endif
        SETBIT(*Opt,BitV);
    }
    else
    {
#if(DD_ZIP || DD_ZIP_21)
        ProgLine1Mes[DISLEN-1] = 'N' ^ sInv;
#else
        ProgLineMes[DISLEN-1] = 'n' ^ sInv;
#endif
        RESETBIT(*Opt,BitV);
    }


#if(DD_ZIP || DD_ZIP_21)
    if (ProgLine1Mes[DISLEN-1] == 'N')
    {
        ProgLine1Mes[DISLEN-3]='N';
        ProgLine1Mes[DISLEN-2] = 'o';
        ProgLine1Mes[DISLEN-1] = ' ';
    }
    else
    {
        ProgLine1Mes[DISLEN-3]='Y';
        ProgLine1Mes[DISLEN-2] = 'e';
        ProgLine1Mes[DISLEN-1] = 's';
    }
#endif

//#if(DD_ZIP==0 && DD_ZIP_21==0 || DD_LCD_1601==0)
    if (TESTBIT(BitNo,BIT7))//ֻ��Ե���
        WORDtoASCL(ProgLineMes+strlen(Prompt.Caption[MsgIdx])+SETUPMARIN,BitNo & 0x0f);
//#endif

}

void GetBCDValue(short MsgIdx,char *val,short BCDBytes,char IsQty)
{
    if (Appl_EntryCounter)
    {
        if (Appl_EntryCounter > (BCDBytes * 2))
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
        else
        {
            StrToBCDValue(val, &EntryBuffer[sizeof(EntryBuffer) - 2], BCDBytes);

            SETBIT(ApplVar.MyFlags,CONFIGECR);//�޸�������ĵ�ǰֵ
        }

    }

    ApplVar.Entry = ZERO;
    memcpy(ApplVar.Entry.Value, val, BCDBytes);
    strcpy(ProgLineMes+SETUPMARIN, Prompt.LineCap[MsgIdx]);
    ProgLineMes[lCAPWIDTH+1] = 0;
    if (IsQty)
    {
#if(DD_ZIP==1 || DD_ZIP_21==1)
        if (TESTBIT(ApplVar.MyFlags,PWDMODE))
            memset(ProgLine1Mes,'-',DISLEN);
        else
        {
//        		memset(ProgLine1Mes,' ',sizeof());
            strncpy(ProgLine1Mes, DispQtyStr(ProgLine1Mes, &ApplVar.Entry,DISLEN),sizeof(ProgLine1Mes));
        }
#else
        if (TESTBIT(ApplVar.MyFlags,PWDMODE))
            memset(ProgLineMes+lCAPWIDTH,'-',DISLEN-lCAPWIDTH);
        else
            strncpy(ProgLineMes, DispQtyStr(ProgLineMes, &ApplVar.Entry,DISLEN),sizeof(ProgLineMes));
#endif

    }
    else
    {
        if (Appl_EntryCounter)
        {
            if (ApplVar.DecimalPoint)
                ApplVar.DecimalPoint--;
            GetEntry();
            ChangePoint();
            memcpy(val,ApplVar.Entry.Value,BCDBytes);
        }

#if(DD_ZIP==1 || DD_ZIP_21==1)
        strncpy(ProgLine1Mes, DispAmtStr(ProgLine1Mes, &ApplVar.Entry,DISLEN),sizeof(ProgLine1Mes));
#else
        strncpy(ProgLineMes, DispAmtStr(ProgLineMes, &ApplVar.Entry,DISLEN),sizeof(ProgLineMes));
#endif

    }
}

void GetWordValue(short MsgIdx,WORD *val,WORD max)
{
    if (Appl_EntryCounter)
    {
        StrToBCDValue(ApplVar.Entry.Value, &EntryBuffer[sizeof(EntryBuffer) - 2], BCDLEN);
        GetWordEntry();
        if (ApplVar.NumberEntry>max)
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
        else
        {
            *val = ApplVar.NumberEntry;
            SETBIT(ApplVar.MyFlags,CONFIGECR);//�޸�������ĵ�ǰֵ
        }
    }

    CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[MsgIdx]);
//        ProgLineMes[lCAPWIDTH] = 0;

#if(DD_ZIP==1 || DD_ZIP_21==1)
    WORDtoASC(ProgLine1Mes + DISLEN-2, *val);
#else
    WORDtoASC(ProgLineMes + DISLEN-2, *val);
#endif

}

/**
 *
 *
 * @author EutronSoftware (2016-12-21)
 *
 * @param sMsg :���������
 * @param val :���������ַ���
 * @param size :��󳤶�
 *
 * @return BYTE :=0,������;=1,������
 */
BYTE GetString(char *sMsg,char *val,WORD size)
{
    short   sLp,sP;
    BYTE sByte;

    MemSet(ProgLineMes, DISLEN+1, ' ');//=================================

    if (size)
    {
        if (Appl_EntryCounter)
        {
            GetCaption((char *) val, size);
            SETBIT(ApplVar.MyFlags,CONFIGECR);//�޸�������ĵ�ǰֵ
        }
        if (sMsg)
            CopyFrStr(ProgLineMes, sMsg);

        sP = 4;
        for (sLp=0;sLp<size;sLp++)
        {
            sByte =((char *)val)[sLp];
            if (sByte>160)
            {//Ϊ����
                sByte -= 160;

#if(DD_ZIP==1 || DD_ZIP_21==1)

                ProgLine1Mes[sP++] = (sByte /10) | 0xB0;
#else
                ProgLineMes[sP++] = (sByte /10) | 0xB0;
#endif

                sByte = (sByte % 10) | 0xB0;
            }

#if(DD_ZIP==1 || DD_ZIP_21==1)
            ProgLine1Mes[sP++] = sByte;
#else
            ProgLineMes[sP++] = sByte;
#endif

        }
        ProgLineMes[DISLEN]=0;

#if(DD_ZIP==1 || DD_ZIP_21==1)
        ProgLine1Mes[DISLEN]=0;
#endif

        return 1;
    }
    else
    {
        ProgLine++;
        return 0;
    }
}

void GetByteValue(short MsgIdx,BYTE *val,BYTE max)
{
    WORD sVal;

    sVal = *val;
    GetWordValue(MsgIdx,&sVal,max);
    *val = sVal;
}

//============ hf added 20040908 ================
/*****************************************
*

* IPstr:��     	*
******************************************/
/**
 * �Ҷ��뷽ʽ�����ָ�ʽIPת��Ϊ�ַ���IP��ַ*
 *
 * @author EutronSoftware (2016-12-20)
 *
 * @param IPstr :ת�����IP��ַ�ַ���
 *       "192.168.123.234",15���ֽ�*
 *                IPstr-^          *
 *
 * @param Num :��ת����IP ���飬4�ֽ� *
 * @return BYTE :ת����IP��ַ����
 */
BYTE NumToIP(char *IPstr,BYTE *Num)
{
    int i,j,k;
    BYTE sDot=0;

    k = 0;
    for  (i=3;i>=0;i--)
    {
        j = WORDtoASC(IPstr,Num[i]);

#if(DD_ZIP_21 || DD_ZIP || DD_LCD_1601 || defined(DEBUGBYPC))
        IPstr -= j;
        if (i)
        {
            *IPstr-- = '.';
            j++;
        }
#else
        *IPstr |= sDot;
        sDot = 0x80;
        IPstr -= j;
#endif
        k += j;
    }
    return k;
}

/*****************************************
* ��IP ��ַ��ʽת��Ϊ���ָ�ʽ    *
* IPstr:��ת����IP ��ַ�ַ�����   *
*         ��ʽ��:192.168.0.1�����16 �� *
*         �ֽ�(����'\0')                                 *
* Num:ת�����IP ���飬4 ���ֽ� *
******************************************/
BYTE IPToNum(BYTE *Num,char *IPstr,short Counter)
{
    short ip = 0;
    BYTE i,j;

    for (i = 0,j = 0;i < Counter;i++)
    {
        /*�ǿո�������*/
        if (IPstr[i] == ' ')
            continue;
        else if (IPstr[i] != '.')
            ip = (IPstr[i] & 0x0f) + ip * 10;
        else
        {
            if (ip < 256)
            {
                Num[j] = ip;
                ip = 0;
                j++;
            }
            else
                return CWXXI71 - CWXXI01 + 1;
        }
    }
    if (j == 3 && ip < 256)
    {
        Num[j] = ip;
        return 0;
    }
    else
        return CWXXI71 - CWXXI01 + 1;
}

/**
 * �������IP��ַת��Ϊ����,����val
 *
 * @author EutronSoftware (2016-12-20)
 *
 * @param sMsg :������ʾ����Ϣ
 * @param val :�������IP,����Ϊ4�ֽ�
 */
void GetIP(char *sMsg,BYTE *val)
{
    short sP,slen,sCp;
    BYTE  sip[4];

    if (Appl_EntryCounter)
    {
        if ((ApplVar.ErrorNumber=IPToNum(sip, &AtEntryBuffer(Appl_EntryCounter), Appl_EntryCounter))==0);
        {
            memcpy(val,sip,4);
            SETBIT(ApplVar.MyFlags,CONFIGECR);//�޸�������ĵ�ǰֵ
        }
    }
//        memcpy(EntryBuffer + sizeof(EntryBuffer) - sP- 1,ProgLineMes+DISLEN-sP-1,sP);

#if(DD_ZIP_21 || DD_ZIP)
    if (sMsg)
        CopyFrStr(ProgLineMes,sMsg);
    sP = NumToIP(ProgLine1Mes+DISLEN-1, val);
    ProgLine1Mes[DISLEN]=0;
#else
    //�鲢С����
    if (sMsg)
        CopyFrStr(ProgLineMes,sMsg);
    sP = NumToIP(ProgLineMes+DISLEN-1, val);
    ProgLineMes[DISLEN]=0;
#endif
}
//====================== hf added end ==================


void ProgPlu()
{
    WORD i;
    BYTE sBuf[10];

    if (ApplVar.ProgNumber >= ApplVar.AP.Plu.Number)
    {
        if (ApplVar.AP.Plu.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            ApplVar.ProgNumber = -1;
            ProgLine = 0;//
        }
        return;
    }
    ApplVar.PluNumber = ApplVar.ProgNumber;
    ReadPlu();
    switch (ProgLine)
    {
    case 1:
        if (ApplVar.AP.Plu.RandomSize)
            Appl_MaxEntry = ApplVar.AP.Plu.RandomSize * 2;
        break;
    case 2:     /* PLU name */
        SetInputMode('a');
        Appl_MaxEntry = ApplVar.AP.Plu.CapSize;
        GetOpt(0, ApplVar.Plu.Name, ApplVar.AP.Plu.CapSize);
        break;
    case 3:     /*Get PLU bar code*/
        SetInputMode('9');
/*		if (ApplVar.AP.Plu.RandomSize)
        {
            Appl_MaxEntry = 0;//ApplVar.AP.Plu.RandomSize * 2;
            if (Appl_EntryCounter)
            {
                StrToBCDValue(ApplVar.Entry.Value, &EntryBuffer[sizeof(EntryBuffer) - 2], BCDLEN);
                memset(ApplVar.Plu.Random,0,sizeof(ApplVar.Plu.Random));
                memcpy(ApplVar.Plu.Random,ApplVar.Entry.Value,ApplVar.AP.Plu.RandomSize);
            }
            CopyFrStr(ProgLineMes + 1, Prompt.LineCap[Line_KEYCODE]);
            HEXtoASC(ProgLineMes + DISLEN - Appl_MaxEntry,ApplVar.Plu.Random,ApplVar.AP.Plu.RandomSize);
            for (i=0;i<ApplVar.AP.Plu.RandomSize;i++)
            {
                if (ProgLineMes[DISLEN - Appl_MaxEntry + i]=='0')
                    ProgLineMes[DISLEN - Appl_MaxEntry + i]=' ';
                else
                    break;
            }
            break;
        }
        else */
        ProgLine = 4;
    case 4:     /* price 1 */
    case 5:     /* price 2 */
    case 6:     /* price 3 */
    case 7:     /* price 4 */
        Appl_MaxEntry = 10;
        if ((ProgLine - 3) > ApplVar.AP.Plu.Level)
            ProgLine = 8;
        else if (GetOpt(4 + ProgLine, ApplVar.Plu.Price[ProgLine - 4], ApplVar.AP.Plu.PriceSize))
            break;
    case 8:     /* plu dept */
        Appl_MaxEntry = 3;
        i =  ApplVar.PluDept;
        GetOpt(1, &i, ApplVar.AP.Dept.Number);
        ApplVar.PluDept = i;
        ApplVar.Plu.Dept = *((BYTE *)&ApplVar.PluDept);
        ApplVar.Plu.DeptHi = *(((BYTE *)&ApplVar.PluDept)+1);
        break;
    case 9:     /* costprice */
        Appl_MaxEntry = 10;
        memcpy(sBuf,ApplVar.Plu.Cost,sizeof(ApplVar.Plu.Cost));
        if (ApplVar.AP.Plu.Cost && GetOpt(12, sBuf, ApplVar.AP.Plu.PriceSize))
        {
            memcpy(ApplVar.Plu.Cost,sBuf,sizeof(ApplVar.Plu.Cost));
            break;
        }
        else
            ProgLine = 10;
    case 10:        //OFF index for PLU
        Appl_MaxEntry = 4;
        i = ApplVar.Plu.OFFIndex;
        if (ApplVar.AP.OFFPrice.Number && GetOpt(33, &i, ApplVar.AP.OFFPrice.Number))
        {
            ApplVar.Plu.OFFIndex = i;
            break;
        }
        else
            ProgLine = 11;
    case 11:         /* Linked ApplVar.Plu */
        Appl_MaxEntry = 4;
        i = ApplVar.Plu.Link;
        if (TESTBIT(ApplVar.AP.Options.Plu, BIT0) &&
            GetOpt(32, &i, ApplVar.AP.Plu.Number))
        {
            ApplVar.Plu.Link = i;
            break;
        }
    default:
        Appl_MaxEntry = 4;
        ProgLine = 0;//�ظ���ǰPLU������
        break;
    }
    WritePlu();
}

void ProgDept()
{
    //ccr2014-07-26>>>>>>>�жϳ�����ӡ��
    struct PRINTER *SetKP;
    unsigned int i;
    //<<<<<<<
    if (ApplVar.ProgNumber >= ApplVar.AP.Dept.Number)
    {
        if (ApplVar.AP.Dept.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            ApplVar.ProgNumber = -1;
            ProgLine = 0;
        }
        return;
    }
    ApplVar.DeptNumber = ApplVar.ProgNumber;
    ReadDept();
    switch (ProgLine)
    {
    case 1:
        break;
    case 2:     /* dept name */
        SetInputMode('a');
        Appl_MaxEntry = ApplVar.AP.Dept.CapSize;
        GetOpt(0, ApplVar.Dept.Name, ApplVar.AP.Dept.CapSize);
        break;
    case 3:     /* ApplVar.Dept price */
        SetInputMode('9');
        Appl_MaxEntry = 10;
        GetOpt(8, ApplVar.Dept.Price, ApplVar.AP.Dept.PriceSize);
        break;
    case 4:     /* ApplVar.Dept price */
        Appl_MaxEntry = 10;
        GetOpt(14, ApplVar.Dept.PriceMax, ApplVar.AP.Dept.PriMaxSize);
        break;
    case 5:     /* tax */
//ccr070723>>>>>>>>>>
        Appl_MaxEntry = ApplVar.AP.Tax.Number;
        GetOpt(46, &ApplVar.Dept.Tax, ApplVar.AP.Tax.Number);
        break;
//    <<<<<<<<<<<<<<<<<<<

    case 6:     /*    group     */
        Appl_MaxEntry = 3;
        BitNumber = 0;
        GetOpt(2, &ApplVar.Dept.Group, ApplVar.AP.Group.Number);
        break;
    case 7:  //���ó�����ӡ��(1-8)
    case 8:
    case 9:
    case 10:
    case 11:
    case 12:
    case 13:
    case 14:
        //ccr2014-07-26>>>>>>>>>>>
        i = ProgLine-7;
        SetKP = (struct PRINTER *) &KPSTART;
        SetKP += i;
        do {
            if (SetKP->type & 0x0f)
                break;
            else
            {//������ӡ��������
                i++;
                SetKP++;
            }
        } while (i<8);
        if (i<8)
        {
            ProgLine = i + 7;
            Appl_MaxEntry = 0;
            Appl_EntryCounter = 0;
            CheckBitValue(51,&ApplVar.Dept.Kp,1+(ProgLine-7)+0x80,0);
            break;
        }
        else
            ProgLine = 15;
        //<<<<<<<<<<<
    case 15:     /* options */
        ProgLine = 16;

#if( (DD_ZIP==1)||(DD_ZIP_21==1)||DD_LCD_1601==1)
    case 16:
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        CheckBitValue(79,&ApplVar.Dept.Options,1+(ProgLine-16+1),0);
        break;
    case 17:
    case 18:
    case 19:
    case 20:
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        CheckBitValue(ProgLine-17+80,&ApplVar.Dept.Options,1+(ProgLine-17+4),0);
        break;
#else
    case 16:
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        CheckBitValue(50,&ApplVar.Dept.Options,1+(ProgLine-16+1)+0x80,0);
        break;
    case 17:
    case 18:
    case 19:
    case 20:
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        CheckBitValue(50,&ApplVar.Dept.Options,1+(ProgLine-17+4)+0x80,0);
        break;
#endif

//	case 9:     /* print */
//		Appl_MaxEntry = 8;
//	    if (GetOpt(3, &ApplVar.Dept.Print, 8))
//		break;
    default:
        Appl_MaxEntry = 4;
        ProgLine = 0;//�ظ���ǰDepart������
        break;
    }
    WriteDept();
}


void ProgGroup()
{
    WORD tmpW;

    if (ApplVar.ProgNumber >= ApplVar.AP.Group.Number)
    {
        if (ApplVar.AP.Group.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            ApplVar.ProgNumber = -1;
            ProgLine = 0;
        }
        return;
    }
    ApplVar.GroupNumber = ApplVar.ProgNumber;
    ReadGroup();
    switch (ProgLine)
    {
    case 1:
        break;
    case 2:     /* group name */
        SetInputMode('a');
        Appl_MaxEntry = ApplVar.AP.Group.CapSize;
        GetOpt(0, ApplVar.Group.Name, ApplVar.AP.Group.CapSize);
        break;
    case 3:     /* Family now used for maxentry */
        SetInputMode('9');
        Appl_MaxEntry = 3;
        tmpW = ApplVar.Group.Family;

        if (GetOpt(30, &tmpW, 99))
        {
            ApplVar.Group.Family = tmpW;
            break;
        }

    default:
        Appl_MaxEntry = 4;
        ProgLine = 0;
        break;
    }
    WriteGroup();
}


void ProgTend()
{
    if (ApplVar.ProgNumber >= ApplVar.AP.Tend.Number)
    {
        if (ApplVar.AP.Tend.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            ApplVar.ProgNumber = -1;
            ProgLine = 0;
        }
        return;
    }
    ApplVar.TendNumber = ApplVar.ProgNumber;
    ReadTender();
    switch (ProgLine)
    {
    case 1:
        break;
    case 2:     /* tendering name */
        BitNumber = 0;
        Appl_MaxEntry = ApplVar.AP.Tend.CapSize;
        SetInputMode('a');
        GetOpt(0, ApplVar.Tend.Name, ApplVar.AP.Tend.CapSize);
        break;
    case 3:     /* options */
    case 4:     /* options */
    case 5:     /* options */
    case 6:     /* options */
    case 7:     /* options */
        SetInputMode('9');
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;

#if( (DD_ZIP==1)||(DD_ZIP_21==1)||DD_LCD_1601==1)
        CheckBitValue(ProgLine-3+87,&ApplVar.Tend.Options,1+(ProgLine-3),0);
#else
        CheckBitValue(50,&ApplVar.Tend.Options,1+(ProgLine-3)+0x80,0);
#endif

        break;
//	case 4:     /* print */
//		Appl_MaxEntry = 8;
//	    if (GetOpt(3, &ApplVar.Tend.Print, 8))
//		break;
    case 8:     /* Drawer */
        Appl_MaxEntry = 8;
        GetOpt(21, &ApplVar.Tend.Drawer, ApplVar.AP.Draw.Number);
        break;
    case 9:     /* Over */
        Appl_MaxEntry = 8;
        GetOpt(22, &ApplVar.Tend.Over, ApplVar.AP.Draw.Number);
        break;
    default:
        Appl_MaxEntry = 4;
        ProgLine = 0;
        break;
    }
    WriteTender();
}


void ProgPoRa()
{
    if (ApplVar.ProgNumber >= ApplVar.AP.PoRa.Number)
    {
        if (ApplVar.AP.PoRa.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            ApplVar.ProgNumber = -1;
            ProgLine = 0;
        }
        return;
    }
    ApplVar.PoRaNumber = ApplVar.ProgNumber;
    ReadPoRa();
    switch (ProgLine)
    {
    case 1:
        break;
    case 2:     /* pora name */
        Appl_MaxEntry = ApplVar.AP.PoRa.CapSize;
        SetInputMode('a');

        BitNumber = 0;
        GetOpt(0, ApplVar.PoRa.Name, ApplVar.AP.PoRa.CapSize);
        break;
    case 3:     /* options */
    case 4:     /* options */
    case 5:     /* options */
    case 6:     /* options */
        SetInputMode('9');
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;

#if(DD_ZIP==1 || DD_ZIP_21==1||DD_LCD_1601==1)
        CheckBitValue(ProgLine-3+92,&ApplVar.PoRa.Options,1+(ProgLine-3),0);
#else
        CheckBitValue(50,&ApplVar.PoRa.Options,1+(ProgLine-3)+0x80,0);
#endif

        break;
//	case 4:     /* print */
//		Appl_MaxEntry = 8;
//	    if (GetOpt(3, &ApplVar.PoRa.Print, 8))
//			break;
    case 7:     /* Drawer 1 */
        Appl_MaxEntry = 8;
        GetOpt(21, &ApplVar.PoRa.Drawer, ApplVar.AP.Draw.Number);
        break;
    default:
        Appl_MaxEntry = 4;
        ProgLine = 0;
        break;
    }
    WritePoRa();
}


void ProgCorrec()
{
    if (ApplVar.ProgNumber >= ApplVar.AP.Correc.Number)
    {
        if (ApplVar.AP.Correc.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            ApplVar.ProgNumber = -1;
            ProgLine = 0;
        }
        return;
    }
    ApplVar.CorrecNumber = ApplVar.ProgNumber;
    ReadCorrec();
    switch (ProgLine)
    {
    case 1:
        break;
    case 2:     /* name */
        Appl_MaxEntry = ApplVar.AP.Correc.CapSize;
        SetInputMode('a');
        BitNumber = 0;
        GetOpt(0, ApplVar.Correc.Name, ApplVar.AP.Correc.CapSize);
        break;
//	case 3:     /* options */
/*		Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        if (!BitNumber)
            BitNumber = ApplVar.Correc.Options+1;
        if (BitNumber > 4 )
            BitNumber = 1;
        ApplVar.Correc.Options = BitNumber - 1;
        CopyFrStr(ProgLineMes , Prompt.LineCap[Line_TYPE]);
        CopyFrStr(ProgLineMes+ DISLEN - 5,Prompt.Caption[BitNumber - 1 + 80]);
        break;*/
//	case 4:     /* print */
//		Appl_MaxEntry = 8;
//	    if (GetOpt(3, &ApplVar.Correc.Print, 8))
//		break;
    default:
        SetInputMode('9');
        Appl_MaxEntry = 4;
        ProgLine = 0;
        break;
    }
    WriteCorrec();
}

void ProgDisc()
{
    if (ApplVar.ProgNumber >= ApplVar.AP.Disc.Number)
    {
        if (ApplVar.AP.Disc.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            ApplVar.ProgNumber = -1;
            ProgLine = 0;
        }
        return;
    }
    ApplVar.DiscNumber = ApplVar.ProgNumber;
    ReadDisc();
    switch (ProgLine)
    {
    case 1:
        break;
    case 2:     /* name */
        SetInputMode('a');
        Appl_MaxEntry = ApplVar.AP.Disc.CapSize;
        if (GetOpt(0, ApplVar.Disc.Name, ApplVar.AP.Disc.CapSize))
            break;
    case 3:
        SetInputMode('9');
        Appl_MaxEntry = 8;
        if (TESTBIT(ApplVar.Disc.Options, BIT0))    /* amount ? */
            GetOpt(13, ApplVar.Disc.Fixed, sizeof(ApplVar.Disc.Fixed));
        else
            GetOpt(15, ApplVar.Disc.Fixed, sizeof(ApplVar.Disc.Fixed));
        break;
    case 4: /* max */
        BitNumber = 0;
        Appl_MaxEntry = 8;
        if (TESTBIT(ApplVar.Disc.Options, BIT0))    /* amount ? */
            GetOpt(14, ApplVar.Disc.Max, sizeof(ApplVar.Disc.Max));
        else
            GetOpt(16, ApplVar.Disc.Max, sizeof(ApplVar.Disc.Max));
        break;
    case 5:     /* options */
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        if (!BitNumber)
            BitNumber = (ApplVar.Disc.Options & 0x3)+1;
        if (BitNumber > 3 )
            BitNumber = 1;
        ApplVar.Disc.Options &= 0xfc;
        ApplVar.Disc.Options |= (BitNumber - 1);
        CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[Line_TYPE]);

#if(DD_ZIP==1 || DD_ZIP_21==1)
        CopyFrStr(ProgLine1Mes+ DISLEN - (CAPWIDTH-1),Prompt.Caption[BitNumber - 1 + 52]);
#else
        CopyFrStr(ProgLineMes+ DISLEN - 6,Prompt.Caption[BitNumber - 1 + 52]);
#endif

        break;
    case 6:
/*		Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        if (!BitNumber)
            BitNumber = ((ApplVar.Disc.Options>>2) & 0x07)+1;
        if (BitNumber > 5)
            BitNumber = 5;
        ApplVar.Disc.Options &= 0xc3;
        ApplVar.Disc.Options |= ((BitNumber - 1)<<2);
        CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[Line_TYPE]);
        CopyFrStr(ProgLineMes+ DISLEN - 6,Prompt.Caption[BitNumber - 1 + 87]);
        break;*/
        ProgLine = 7;
    case 7:
    case 8:
    case 9:
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;

#if(DD_ZIP==1 || DD_ZIP_21==1 ||DD_LCD_1601==1)
        CheckBitValue(ProgLine-7+96,&ApplVar.Disc.Options,1+(ProgLine- 7 + 5),0);
#else
        CheckBitValue(50,&ApplVar.Disc.Options,1+(ProgLine- 7 + 5)+0x80,0);
#endif

//ccr090108>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        if (TESTBIT(ApplVar.Disc.Options,BIT2))
        {// �ֽ��ۿ۽�ֹ�����ۿ� //
            RESETBIT(ApplVar.Disc.Options,BIT6+BIT7);
        }
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

        break;
//	case 6:     /* print */
//		Appl_MaxEntry = 8;
//	    if (GetOpt(3, &ApplVar.Disc.Print, 8))
//		break;
    case 10:     /* tax */
//ccr070723>>>>>>>>>>
        Appl_MaxEntry = ApplVar.AP.Tax.Number;
        GetOpt(46, &ApplVar.Disc.Tax, ApplVar.AP.Tax.Number);
        break;
//<<<<<<<<<<<<<<<<<<<
    default:
        Appl_MaxEntry = 4;
        ProgLine = 0;
        break;
    }
    WriteDisc();
}



void ProgCurr()
{
    if (ApplVar.ProgNumber >= ApplVar.AP.Curr.Number)
    {
        if (ApplVar.AP.Curr.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            ApplVar.ProgNumber = -1;
            ProgLine = 0;
        }
        return;
    }
    ApplVar.CurrNumber = ApplVar.ProgNumber;
    ReadCurr();

    switch (ProgLine)
    {
    case 1:
        break;
    case 2:     /* name */
        SetInputMode('a');
        Appl_MaxEntry = ApplVar.AP.Curr.CapSize;
        if (GetOpt(0, ApplVar.Curr.Name, ApplVar.AP.Curr.CapSize))
            break;
    case 3:
        SetInputMode('9');
        Appl_MaxEntry = 8;
        GetOpt(18, ApplVar.Curr.BuyRate, sizeof(ApplVar.Curr.BuyRate));
        break;
    case 4:
        BitNumber = 0;
        Appl_MaxEntry = 8;
        GetOpt(19, ApplVar.Curr.SellRate, sizeof(ApplVar.Curr.SellRate));
        break;
    case 5:     /* options */
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
#if(DD_ZIP==1 || DD_ZIP_21==1||DD_LCD_1601==1)
        CheckBitValue(99,&ApplVar.Curr.Options,1+(ProgLine- 4),0);
#else
        CheckBitValue(50,&ApplVar.Curr.Options,1+(ProgLine- 4),0);
#endif
        break;
    case 6:
        Appl_MaxEntry = 8;
        GetOpt(21, &ApplVar.Curr.Drawer, ApplVar.AP.Draw.Number);
        break;
    case 7:
        Appl_MaxEntry = 8;
        GetOpt(26, &ApplVar.Curr.Prefix1, 255);
        break;
    case 8:
        Appl_MaxEntry = 8;
        GetOpt(27, &ApplVar.Curr.Prefix2, 255);
        break;
    default:
        Appl_MaxEntry = 4;
        ProgLine = 0;
        break;
    }
    WriteCurr();
}

void ProgDraw()
{
    if (ApplVar.ProgNumber >= ApplVar.AP.Draw.Number)
    {
        if (ApplVar.AP.Draw.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            ApplVar.ProgNumber = -1;
            ProgLine = 0;
        }
        return;
    }
    ApplVar.DrawNumber = ApplVar.ProgNumber;
    ReadDrawer();
    switch (ProgLine)
    {
    case 1:
        break;
    case 2:     /* name */
        BitNumber = 0;
        SetInputMode('a');
        Appl_MaxEntry = ApplVar.AP.Draw.CapSize;
        if (GetOpt(0, ApplVar.Draw.Name, ApplVar.AP.Draw.CapSize))
            break;
    case 3:     /* options */
//	    case 4:     /* options */
        SetInputMode('9');
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
#if(DD_ZIP==1 || DD_ZIP_21==1||DD_LCD_1601==1)
        CheckBitValue(101,&ApplVar.Draw.Options,2,0);
#else
        CheckBitValue(55,&ApplVar.Draw.Options,2,0);
#endif
        break;
    default:
        Appl_MaxEntry = 4;
        ProgLine = 0;
        break;
    }
    WriteDrawer();
}


void ProgPbF()
{
    if (!ApplVar.AP.Pb.NumberOfPb || ApplVar.ProgNumber >= ApplVar.AP.Pb.Number)
    {
        if (ApplVar.AP.Pb.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            ApplVar.ProgNumber = -1;
            ProgLine = 0;
        }
        return;
    }
    ApplVar.PbFNumber = ApplVar.ProgNumber;
    ReadPbF();
    switch (ProgLine)
    {
    case 1:
        break;
    case 2:     /* name */
        SetInputMode('a');
        Appl_MaxEntry = 32;
        if (GetOpt(0, ApplVar.PbF.Name, ApplVar.AP.Pb.CapSize))
            break;
    case 3:     /* options */
        SetInputMode('9');
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        if (!BitNumber)
            BitNumber = ApplVar.PbF.Options+1;
        if (BitNumber > 11)
            BitNumber = 1;
        ApplVar.PbF.Options = BitNumber - 1;
        CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[Line_TYPE]);
#if( (DD_ZIP==1)||(DD_ZIP_21==1) )
        CopyFrStr(ProgLine1Mes+ DISLEN - (CAPWIDTH - 1),Prompt.Caption[ApplVar.PbF.Options + 55]);
#else
        CopyFrStr(ProgLineMes+ DISLEN - 6,Prompt.Caption[ApplVar.PbF.Options + 55]);
#endif
        break;
//	    case 4:     /* print */
//			Appl_MaxEntry = 8;
//			if (GetOpt(3, &ApplVar.PbF.Print, 8))
//			    break;
    default:
        Appl_MaxEntry = 4;
        ProgLine = 0;
        break;
    }
    WritePbF();
}

void ProgPbInfo()
{
    if (ApplVar.ProgNumber > ApplVar.AP.Pb.NumberOfPb || !ApplVar.AP.Pb.Text)
    {
        if (ApplVar.AP.Pb.NumberOfPb==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            ApplVar.ProgNumber = -1;
            ProgLine = 0;
        }
        return;
    }
    ApplVar.PbNumber = ApplVar.ProgNumber + 1;

    if (!ApplVar.AP.Pb.Text)
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
        return;
    }
    PbTotal(ApplVar.PbNumber, 0);     /* read */
    switch (ProgLine)
    {
    case 1:
        break;
    case 2:     /* ApplVar.PB text */
        SetInputMode('a');
        Appl_MaxEntry = ApplVar.AP.Pb.Text * 2;
        if (GetOpt(0, ApplVar.PB.Text, ApplVar.AP.Pb.Text))
            break;
    case 3:
        SetInputMode('9');
        Appl_MaxEntry = 16;
        if (!TESTBIT(PBINFO, BIT2) && !(PBPRINT & 0x80)
            && (ApplVar.AP.Pb.Random & 0x0f))  /* random number ? */
        {
            if (GetOpt(31, ApplVar.PB.Random, ApplVar.AP.Pb.Random & 0x0f))
                break;
        }
    default:
        Appl_MaxEntry = 4;
        ProgLine = 0;
        break;
    }
    PbTotal(ApplVar.PbNumber, 3);     /* write text + Random */
}

void ProgTax()
{
    BYTE invF=0,setOP=0;

    if (ApplVar.ProgNumber >= ApplVar.AP.Tax.Number)
    {
        if (ApplVar.AP.Tax.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            ApplVar.ProgNumber = -1;
            ProgLine = 0;
        }
        return;
    }
    ApplVar.TaxNumber = ApplVar.ProgNumber;
    ReadTax();
    switch (ProgLine)
    {
    case 1:
        break;
    case 2:     /* name */
        SetInputMode('a');
        Appl_MaxEntry = ApplVar.AP.Tax.CapSize;
#if !defined(CASE_ITALIA)
        Appl_EntryCounter = 0;//ccr070614 Replace Tax.Name not allowed
#endif
        if (GetOpt(0, ApplVar.Tax.Name, ApplVar.AP.Tax.CapSize))
            break;
    case 3:
        SetInputMode('9');
        BitNumber = 0;
        Appl_MaxEntry = 8;
#if defined(FISCAL)
        if (Appl_EntryCounter>0)
        {
            if (ApplVar.FisNumber.TotalTaxChangeNum<FTAXCHGMAX)//˰���޸Ĵ�������
                ApplVar.FMPullOut[NEWTAX_FLAG]=0x69;
            else
                Appl_EntryCounter = 0;
        }
#endif
        GetOpt(17, ApplVar.Tax.Rate, sizeof(ApplVar.Tax.Rate));
        break;
    case 4:     /*    options:1:VAT����˰/0:(Add on)����˰(Ӫҵ˰) */
        if (ProgLine==4)  invF = YN;//ccr2014-07-22
        setOP = 1;
        break;
    case 5:     /*    options:��ӡ˰����,ֻ��VAT��˰ģʽ������     */
        setOP = 1;
        if (!TESTBIT(ApplVar.Tax.Options,BIT0))//only for VAT type
            ProgLine=7;
        break;
    case 6:     /*    options:��ӡ0˰��     */
        setOP = 1;
        if (!TESTBIT(ApplVar.Tax.Options,BIT1))//only for VAT type
            ProgLine=7;
        break;
    case 7:     /*    options:ΪGST��˰    */
        setOP = 1;
        break;
    case 8:     /*    options:��ӡ˰��     */
        //ccr2014-07-22>>>>>>>>>>
        if (TESTBIT(ApplVar.Tax.Options,BIT1 + BIT0)==(BIT1 + BIT0))
        {//only for VAT type
            setOP = 1;
            break;
        }//<<<<<<<<<<<<<<<<
    default:
        Appl_MaxEntry = 4;
        ProgLine = 0;
        break;
    }
    if ((setOP))
    {
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
#if( (DD_ZIP==1)||(DD_ZIP_21==1)||DD_LCD_1601==1 )
        CheckBitValue(ProgLine-4+102,&ApplVar.Tax.Options,1+(ProgLine-4),invF);
#else
        CheckBitValue(50,&ApplVar.Tax.Options,1+(ProgLine-4)+0x80,invF);
#endif
    }
    WriteTax();
}


void ProgClerk()
{
    WORD saveClerk;     //cc 20071023
    BYTE saveOption;

    if (ApplVar.ProgNumber >= ApplVar.AP.Clerk.Number)
    {
        if (ApplVar.AP.Clerk.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            ApplVar.ProgNumber = -1;
            ProgLine = 0;
        }
        return;
    }
    saveClerk = ApplVar.ClerkNumber;    //cc 20071023
    saveOption = ApplVar.Clerk.Options & BIT7;
    ApplVar.ClerkNumber = ApplVar.ProgNumber + 1;
    ReadClerk();
    switch (ProgLine)
    {
    case 1:
        break;
    case 2:     /* name */
        Appl_MaxEntry = ApplVar.AP.Clerk.CapSize;
        SetInputMode('a');
        BitNumber = 0;
        if (GetOpt(0, ApplVar.Clerk.Name, ApplVar.AP.Clerk.CapSize))
            break;
    case 3:
        SetInputMode('9');
        if (TESTBIT(CLERKFIX,BIT5))
        {
            Appl_MaxEntry = sizeof(ApplVar.Clerk.Passwd) * 2;
//				SETBIT(ApplVar.MyFlags,PWDMODE);
            BitNumber = 0;
            GetBCDValue(Line_PASSWORD,ApplVar.Clerk.Passwd,3,TRUE);
            break;
        }
        else
            ProgLine = 4;
    case 4:
    case 5:
    case 6:
    case 7:
    case 8:
    case 9:
    case 10:
    case 11:
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
#if( (DD_ZIP==1)||(DD_ZIP_21==1)||DD_LCD_1601==1 )
        CheckBitValue(ProgLine-4+107,&ApplVar.Clerk.Options,1+(ProgLine-4),YN);
#else
        CheckBitValue(50,&ApplVar.Clerk.Options,1+(ProgLine-4)+0x80,YN);
#endif
        break;
    default:
        Appl_MaxEntry = 4;
        ProgLine = 0;
        break;
    }
//ccr100330>>>>>>>>>>>>>
    if (ApplVar.ClerkNumber == saveClerk && (ApplVar.Clerk.Options & BIT7)!=saveOption)
    {// ��ֹ�ı䵱ǰ��¼���տ�Ա����ѵģʽ //

        if (TESTBIT(ApplVar.MyFlags,ZREPORT))   /* z report taken ? */
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI75);
            INVERTBIT(ApplVar.Clerk.Options,BIT7);
        }
        else
        {
            SetTrainMode();
        }
    }
    WriteClerk();
    if (ApplVar.ClerkNumber != saveClerk)
    {
        ApplVar.ClerkNumber = saveClerk;
        ReadClerk();
    }
//<<<<<<<<<<<<<<<<<<<<<
}


void ProgSalPer()
{
    if (ApplVar.ProgNumber >= ApplVar.AP.SalPer.Number)
    {
        if (ApplVar.AP.SalPer.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            ApplVar.ProgNumber = -1;
            ProgLine = 0;
        }
        return;
    }
    ApplVar.SalPerNumber = ApplVar.ProgNumber + 1;
    ReadSalPer();
    switch (ProgLine)
    {
    case 1:
        break;
    case 2:     /* name */
        Appl_MaxEntry = ApplVar.AP.SalPer.CapSize;
        SetInputMode('a');
        if (GetOpt(0, ApplVar.SalPer.Name, ApplVar.AP.SalPer.CapSize))
            break;
    default:
        SetInputMode('9');
        ProgLine = 0;
        Appl_MaxEntry = 4;
        break;
    }
    WriteSalPer();
}

void ProgZone()
{
    if (ApplVar.ProgNumber >= ApplVar.AP.Zone.Number)
    {
        if (ApplVar.AP.Zone.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            ApplVar.ProgNumber = -1;
            ProgLine = 0;
        }
        return;
    }
    if (ProgLine == 1)
        return;
    else if (ProgLine > 2)
    {
        ProgLine = 0;
        Appl_MaxEntry = 4;
    }
    else
        GetOpt(20, &ApplVar.AP.Zone.Start[ApplVar.ProgNumber], 2);
    Appl_MaxEntry = 5;
}

void ProgModi()
{
#if 1
    if (ApplVar.AP.Modi.Number==0)
        strcpy(ProgLineMes,Number0);
    else
        ProgCaptions(SETMODIF,ApplVar.AP.Modi.Number,ApplVar.AP.Modi.CapSize);
#else
    int sP,sLp,idx;

    if (ApplVar.ProgNumber >= ApplVar.AP.Modi.Number)
    {
        if (ApplVar.AP.Modi.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            SetInputMode('9');
            ApplVar.ProgNumber = -1;
            ProgLine = 0;
        }
        return;
    }

    if (ProgLine==1)
    {
        ProgLine = ApplVar.ProgNumber+2;
        SetInputMode('a');
        ApplVar.ProgNumber = 0;
    }

    if (ProgLine>=2 && ProgLine<=ApplVar.AP.Modi.Number+2)
    {
        Appl_MaxEntry = ApplVar.AP.Modi.CapSize;
        idx = ProgLine-2;

        ApplVar.ModiNumber = idx;
        ReadModi();

        if (Appl_EntryCounter)
        {
            sLp=GetCaption(ApplVar.Modi.Name, ApplVar.AP.Modi.CapSize);
            SETBIT(ApplVar.MyFlags,CONFIGECR);//�޸�������ĵ�ǰֵ
            ApplVar.Modi.Name[sLp]=0;

            if (sLp==1 && ApplVar.Modi.Name[0]==' ')
                memset(ApplVar.Modi.Name,0, ApplVar.AP.Modi.CapSize);
            WriteModi();
        }

        sP = strlen(Prompt.LineCap[Line_CAPTION]);//lCAPWIDTH;
        CopyFrStr(ProgLineMes, Prompt.LineCap[Line_CAPTION]);
        sP += WORDtoASCL(ProgLineMes+sP,idx+1);
        ProgLineMes[sP++]=':';

        for (sLp=0;sLp<DISLEN;sLp++)
        {
#if(DD_ZIP==1 || DD_ZIP_21==1)
            ProgLine1Mes[sLp] = ApplVar.Modi.Name[sLp];
#else
            ProgLineMes[sP++] = ApplVar.Modi.Name[sLp];
            if (sP>=DISLEN) break;
#endif
        }
    }
    else
    {
        SetInputMode('9');
        ProgLine = 0;
        ApplVar.ProgNumber = 0;
        Appl_MaxEntry = ApplVar.AP.Modi.CapSize;
    }
#endif
}

void ProgHeader()
{
    ProgCaptions(SETHEAD,8,PRTLEN);
}

void ProgTrailer()
{
#if 1
    ProgCaptions(SETTRAIL,6,PRTLEN);
#else
    int sP,sLp,idx;

    if (ApplVar.ProgNumber >= 6)
    {
        SetInputMode('9');
        ApplVar.ProgNumber = -1;
        ProgLine = 0;
        return;
    }
    if (ProgLine==1)
    {
        ProgLine = ApplVar.ProgNumber+2;
        SetInputMode('a');
        ApplVar.ProgNumber = 0;
    }

    if (ProgLine>=2 && ProgLine<=7)
    {
        Appl_MaxEntry = PRTLEN;
        idx = ProgLine-2;

        if (Appl_EntryCounter)
        {
            sLp=GetCaption(ApplVar.TXT.Trailer[idx], PRTLEN);
            SETBIT(ApplVar.MyFlags,CONFIGECR);//�޸�������ĵ�ǰֵ
            ApplVar.TXT.Trailer[idx][sLp]=0;

            if (sLp==1 && ApplVar.TXT.Trailer[idx][0]==' ')
                memset(ApplVar.TXT.Trailer[idx],0, PRTLEN+1);
        }

        sP = strlen(Prompt.LineCap[Line_CAPTION]);//lCAPWIDTH;
        CopyFrStr(ProgLineMes, Prompt.LineCap[Line_CAPTION]);
        ProgLineMes[sP++] = idx+'1';
        ProgLineMes[sP++] = ':';

        for (sLp=0;sLp<DISLEN;sLp++)
        {
#if(DD_ZIP==1 || DD_ZIP_21==1)
            ProgLine1Mes[sLp] = ApplVar.TXT.Trailer[idx][sLp];
#else
            ProgLineMes[sP++] = ApplVar.TXT.Trailer[idx][sLp];
            if (sP>=DISLEN) break;
#endif
        }
    }
    else
    {
        SetInputMode('9');
        ProgLine = 0;
        ApplVar.ProgNumber = 0;
        Appl_MaxEntry = PRTLEN;
    }
#endif
}

void ProgSlipHead()
{
#if 1
    ProgCaptions(SETSHEAD,6,SHEADWIDTH);
#else
    int sP,sLp,idx;

    if (ApplVar.ProgNumber >= 6)
    {
        SetInputMode('9');
        ApplVar.ProgNumber = -1;
        ProgLine = 0;
        return;
    }
    if (ProgLine==1)
    {
        ProgLine = ApplVar.ProgNumber+2;
        SetInputMode('a');
        ApplVar.ProgNumber = 0;
    }

    if (ProgLine>=2 && ProgLine<=7)
    {
        Appl_MaxEntry = SHEADWIDTH;
        idx = ProgLine-2;

        if (Appl_EntryCounter)
        {
            sLp=GetCaption(ApplVar.TXT.SlipHeader[idx], SHEADWIDTH);
            SETBIT(ApplVar.MyFlags,CONFIGECR);//�޸�������ĵ�ǰֵ
            ApplVar.TXT.SlipHeader[idx][sLp]=0;

            if (sLp==1 && ApplVar.TXT.SlipHeader[idx][0]==' ')
                memset(ApplVar.TXT.SlipHeader[idx],0, SHEADWIDTH+1);
        }

        sP = strlen(Prompt.LineCap[Line_CAPTION]);//lCAPWIDTH;
        CopyFrStr(ProgLineMes, Prompt.LineCap[Line_CAPTION]);
        ProgLineMes[sP++] = idx+'1';
        ProgLineMes[sP++] = ':';

        for (sLp=0;sLp<DISLEN;sLp++)
        {
#if(DD_ZIP==1 || DD_ZIP_21==1)
            ProgLine1Mes[sLp] = ApplVar.TXT.SlipHeader[idx][sLp];
#else
            ProgLineMes[sP++] = ApplVar.TXT.SlipHeader[idx][sLp];
            if (sP>=DISLEN) break;
#endif
        }
    }
    else
    {
        SetInputMode('9');
        ProgLine = 0;
        ApplVar.ProgNumber = 0;
        Appl_MaxEntry = SHEADWIDTH;
    }
#endif
}


void ProgSysFlag()
{
    BYTE BitV, i;
    short   sIdx;

    if (ProgLine==1 || ProgLine>=SYSUSED+2)
        ProgLine = 2;
    if (ProgLine>=2 && ProgLine<SYSUSED+2)
    {
        sIdx = SysFlagUsed[ProgLine-2].Index;

#if(DD_ZIP==1 || DD_ZIP_21==1 || DD_LCD_1601==1)
        CopyFrStr(ProgLineMes , SysFlagUsed[ProgLine-2].Name);
#else
        CopyFrStr(ProgLineMes , Prompt.Caption[50]);//    SysOpt
        WORDtoASC(ProgLineMes+7,ProgLine-1);
        if (ProgLineMes[6]==' ')
            ProgLineMes[6] = '_';
#endif
        if (SysFlagUsed[ProgLine-2].Bit)
        {

            BitV = BIT0<<(SysFlagUsed[ProgLine-2].Bit-1);
            Appl_MaxEntry = 0;
            Appl_EntryCounter = 0;
            if (!BitNumber)
                BitNumber = ((ApplVar.AP.Flag[sIdx] & BitV)!=0)+1;
            else
                SETBIT(ApplVar.MyFlags,CONFIGECR);//�޸�������ĵ�ǰֵ

            if (BitNumber > 2)
                BitNumber = 1;
            if (BitNumber ==2)
            {
#if( (DD_ZIP==1)||(DD_ZIP_21==1) )
                ProgLine1Mes[DISLEN-3] = 'N' ^ SysFlagUsed[ProgLine-2].Invert;
#else
                ProgLineMes[DISLEN-1] = 'n' ^ SysFlagUsed[ProgLine-2].Invert;
#endif
                ApplVar.AP.Flag[sIdx] |= BitV;
            }
            else
            {
#if( (DD_ZIP==1)||(DD_ZIP_21==1) )
                ProgLine1Mes[DISLEN-3] = 'Y' ^ SysFlagUsed[ProgLine-2].Invert;
#else
                ProgLineMes[DISLEN-1] = 'y' ^ SysFlagUsed[ProgLine-2].Invert;
#endif
                ApplVar.AP.Flag[sIdx] &= ~(BitV);
            }
#if( (DD_ZIP==1)||(DD_ZIP_21==1) )
            if (ProgLine1Mes[DISLEN-3] == 'N')
            {
                ProgLine1Mes[DISLEN-2] = 'o';
                ProgLine1Mes[DISLEN-1] = ' ';
            }
            else
            {
                ProgLine1Mes[DISLEN-2] = 'e';
                ProgLine1Mes[DISLEN-1] = 's';
            }
#endif
            SETBIT(ApplVar.MyFlags,CONFIGECR);//�޸�������ĵ�ǰֵ

        }
        else
        {
            Appl_MaxEntry = 3;   BitNumber = 0;
            i = ApplVar.AP.Flag[sIdx];
            if (sIdx==62)
            {               //��4λΪ��־,��4ΪΪ��ֵ  //
                i = ApplVar.AP.Flag[sIdx] & 0xf0;
                ApplVar.AP.Flag[sIdx] &= 0x0f;
            }
            else
                i = 0;
            if (Appl_EntryCounter)
            {
                if (ApplVar.NumberEntry>SysFlagUsed[ProgLine-2].Max)
                {
                    ApplVar.AP.Flag[sIdx] |= i;
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                    return;
                }
                SETBIT(ApplVar.MyFlags,CONFIGECR);//�޸�������ĵ�ǰֵ
                ApplVar.AP.Flag[sIdx] = ApplVar.NumberEntry;
            }
#if( (DD_ZIP==1)||(DD_ZIP_21==1) )
            WORDtoASC(ProgLine1Mes + DISLEN-1, ApplVar.AP.Flag[sIdx]);
#else
            WORDtoASC(ProgLineMes + DISLEN-1, ApplVar.AP.Flag[sIdx]);
#endif
            ApplVar.AP.Flag[sIdx] |= i;
        }
    }

    //if (ProgStart != 2)
    {
        InitSysFlag();
    }
}


void ProgSysMes()
{
    BYTE max;

    switch (ProgLine)
    {
    case 1:
        break;
    case 2:     /* name */
        SetInputMode('a');
        Appl_MaxEntry = 32;
        if (!(ProgType == SETFIXCAP || ProgType == SETERRMSG||ProgType == SETWEEKCAP||ProgType == SETMONTHCAP))
        {
            GetOpt(0, ApplVar.TXT.ReportType[ApplVar.ProgNumber], 16);
            max = 13;
        }
        if (ApplVar.ProgNumber > max)
        {
            ApplVar.ProgNumber = -1;
            ProgLine = 0;
        }
        Now.day--;  /* force new read of date and time incase */
        /* caption changed */
        break;
    default:
        SetInputMode('9');
        Appl_MaxEntry = 4;
        ProgLine = 0;
        break;
    }
}

void ProgReport()
{
    short i;

    if (ApplVar.ProgNumber > XZNUM-1)
    {
        ApplVar.ProgNumber = -1;
        ProgLine = 0;
        return;
    }
    i = XZTitle[ApplVar.ProgNumber].Index-1;

    switch (ProgLine)
    {
    case 1:
        break;
    case 2:     /* name */
        SetInputMode('a');

        Appl_MaxEntry = 32;
        GetOpt(0, ApplVar.AP.ReportList[i].Name, 16);
        BitNumber = 0;
        break;
//	case 3:
//		Appl_MaxEntry = 8;
//	    if (GetOpt(3, &ApplVar.AP.ReportList[i].PrintLayOut, 8))
//			break;
    case 3:     /* options */
//lyq delete 2003\10\27 start
//	case 4:     /* options */
//	case 5:     /* options */
//	case 6:     /* options */
//lyq delete 2003\10\27 end
        SetInputMode('9');
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
#if( (DD_ZIP==1)||(DD_ZIP_21==1)|| DD_LCD_1601==1)
        CheckBitValue(101,&ApplVar.AP.ReportList[i].Options,1+(ProgLine-3),0);
#else
        CheckBitValue(50,&ApplVar.AP.ReportList[i].Options,1+(ProgLine-3),0);
#endif
        break;
    case 4:    /* period */
        Appl_MaxEntry = 8;
        GetOpt(24, &ApplVar.AP.ReportList[i].Period, 3);
        break;
    case 5:     /* pointer type */
        Appl_MaxEntry = 8;
        GetOpt(25, &ApplVar.AP.ReportList[i].PointerType, 4);
        break;
    default:     /* link */
        if (ProgLine < (6+16))
            GetOpt(28, &ApplVar.AP.ReportList[i].Link[ProgLine - 6], REPTYPEMAX+1);//9--6 lyq
        else
            ProgLine = 0;
        break;
    }
}
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
void ProgDate()
{
    switch (ProgLine)
    {
    case 1:
        SetDateFlg = 1;
        Appl_MaxEntry = 10;
        CheckTime(true | 0x80);
        MemSet(ProgLineMes, sizeof(ProgLineMes), ' ');
#if( (DD_ZIP==1)||(DD_ZIP_21==1) )
//ccr2014-10-29        memset(ProgLine1Mes,' ',sizeof(ProgLine1Mes));
        strcpy(ProgLine1Mes,EXITMESS);//ccr2014-10-29
#endif
        memcpy(ProgLineMes+SETUPMARIN,DateAsci+4, 10);
        break;
    case 2:     /* set date */
        if (Appl_EntryCounter>0)
        {
            if (TESTBIT(ApplVar.MyFlags,ZREPORT))   /* z report taken ? */
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI13);
            }
            else
            {
                SetDateFlg = 2;
                NewTimeDate(1);
                ProgLine = 1;

                CheckTime(TRUE | 0x80);
                memcpy(SysBuf,DateAsci+4,10);
                SysBuf[10]=0;
                PutsO(SysBuf);

#if(DD_ZIP==1 || DD_ZIP_21==1)
                Puts1(EXITMESS);//ccr20131120
#endif
            }
        }
        else
            SetDateFlg = 3;
        break;
    default:
        Appl_MaxEntry = 4;
        ProgLine = 0;
        break;
    }
}

void ProgTime()
{
    switch (ProgLine)
    {
    case 1:
        SetDateFlg = 1;
        Appl_MaxEntry = 8;
        CheckTime(true | 0x80);
        MemSet(ProgLineMes, sizeof(ProgLineMes), ' ');
#if( (DD_ZIP==1)||(DD_ZIP_21==1) )
//ccr2014-10-29        memset(ProgLine1Mes,' ',sizeof(ProgLine1Mes));
        strcpy(ProgLine1Mes,EXITMESS);//ccr2014-10-29
#endif
        memcpy(ProgLineMes+2,TimeAsci, 8);
        break;
    case 2:     /* set time */
        if (Appl_EntryCounter>0)
        {
            if (TESTBIT(ApplVar.MyFlags,ZREPORT))   /* z report taken ? */
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI13);
            }
            else
            {
                SetDateFlg = 2;
                ProgLine = 1;
                NewTimeDate(2);
#if(DD_ZIP==1 || DD_ZIP_21==1)
                Puts1(EXITMESS);//ccr20131120
#endif
            }
        }
        else
            SetDateFlg = 3;
        break;
    default:
        Appl_MaxEntry = 4;
        ProgLine = 0;
        break;
    }
}


void ProgPort(BYTE port)
{
    short i;
    BYTE    oldICPort;

    ApplVar.PortNumber = port;
    ReadPort();
    switch (ProgLine)
    {
    case 1:
        ProgLine = 2;
    case 2:     /* ApplVar.Port type (Option)*/
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        if (BitNumber==0)
            BitNumber = ApplVar.Port.Type-'0';
        if (COMPUTER && COMPUTER!=TCPIPPORT && COMPUTER_1 != port && BitNumber<4)
        {// ����һ����������Ϊ������ʱ����ֹ��������������  ccr 050227//
            ApplVar.Port.Type = '4';
            BitNumber = '4'-'0';
        }
        else if (port==0 && BitNumber==2)
        {// ����1��ֹ485��ʽ  //
            ApplVar.Port.Type = '3';
            BitNumber = '3'-'0';
        }

        GetOpt(44, &ApplVar.Port.Type, portTypeNum);
        if (COMPUTER && COMPUTER!=TCPIPPORT && COMPUTER_1 != port && ApplVar.Port.Type<'4')
        {// ����һ����������Ϊ������ʱ����ֹ��������������  //
            ApplVar.Port.Type = '4';
            BitNumber = '4'-'0';
            GetOpt(44, &ApplVar.Port.Type, portTypeNum);
        }
        break;
    case 3:     /* Protocl string */
        Appl_MaxEntry = 5;
        BitNumber = 0;
        GetOpt(45, &ApplVar.Port.Prot[ApplVar.Port.Type - 0x31], 5);
        if (Appl_EntryCounter)
            i = 1;
        if (ApplVar.Port.Type == '3' && !InitModem())
            ApplVar.ErrorNumber=ERROR_ID(CWXXI49);
        break;
    case 4:     /* Telephone code for modem mode*/
        if (ApplVar.Port.Type=='3')
        {
            Appl_MaxEntry = sizeof(ApplVar.Port.Tele)-1;
            BitNumber = 0;

            if (Appl_EntryCounter)
                memcpy(ApplVar.Port.Tele,EntryBuffer+sizeof(EntryBuffer)-Appl_EntryCounter-1,Appl_EntryCounter+1);

            i = strlen(ApplVar.Port.Tele);
            if (i>sizeof(ApplVar.Port.Tele))
            {
                i = sizeof(ApplVar.Port.Tele);
                ApplVar.Port.Tele[i-1] = 0;
            }
            CopyFrStr(ProgLineMes , Prompt.LineCap[Line_TELE]);
            memcpy(ProgLineMes+DISLEN - i - 1,ApplVar.Port.Tele, i);
            break;
        }
    default:
        Appl_MaxEntry = 4;
        ProgLine = 0;
        break;
    }

    oldICPort = ApplVar.MFRCardPort;
    ApplVar.MFRCardPort = COMPUTER = BALANCE =0;
    BARCODE &= 0xf8;
    PCCounter = CCDCounter = BalCounter = 0;
    WritePort();
    SetComm(ApplVar.PortNumber);
    EmptyComm(ApplVar.PortNumber);

    if (ApplVar.Port.Type >= '1' && ApplVar.Port.Type <= '3')
    {
        COMPUTER = ApplVar.PortNumber+1;
        DialSkiped = 0;
    }
    else if (ApplVar.Port.Type == '4')
        BARCODE = (BARCODE & 0xf8) | (ApplVar.PortNumber+1);
    else if (ApplVar.Port.Type == '5')
        BALANCE = ApplVar.PortNumber+1;
#if 0	//cc 20070930
    else if (ApplVar.Port.Type == '8')  //ccr mifareIC
        ApplVar.MFRCardPort = ApplVar.PortNumber+1;
    else if (ApplVar.Port.Type == '9')  //ccr epos
        ApplVar.ePosPort = ApplVar.PortNumber+1;
#endif
    for (ApplVar.PortNumber = 0;ApplVar.PortNumber < ApplVar.AP.Port.Number;ApplVar.PortNumber++)
    {
        ReadPort();
        switch (ApplVar.Port.Type)
        {
        case '1':
        case '2':
        case '3':
            if (!COMPUTER)
                COMPUTER = ApplVar.PortNumber+1;
            break;
        case '4':
            if (!(BARCODE & 0x07))
                BARCODE = (BARCODE & 0xf8) | (ApplVar.PortNumber+1);
            break;
        case '5':
            if (!BALANCE)
                BALANCE = ApplVar.PortNumber+1;
            break;
#if 0	//cc 20070930
        case '8'://ccr
            if (!ApplVar.MFRCardPort)
                ApplVar.MFRCardPort = ApplVar.PortNumber+1;
            break;
        case '9'://ccr epos
            if (!ApplVar.ePosPort)
                ApplVar.ePosPort = ApplVar.PortNumber+1;
            break;
#endif
        }
    }

#if 0	//cc 20070930
#if (CASE_MFRIC==1)
    if (ApplVar.MFRCardPort  && oldICPort!=ApplVar.MFRCardPort && TESTBIT(ApplVar.ICCardSet.Options,IC_CHIPCARD))//MI_OK)
    {
        PutsO(Msg[WAITEICCARD].str);
        if (mifs_config()!=0)
        {
            ApplVar.ErrorNumber=CWXXI72-CWXXI01+1;
            ApplVar.MFRCardPort = 0;
        }
    }
#endif
#endif
}

void ProgPrnGraph()
{
    BYTE    sIdx;

    if (ApplVar.ProgNumber==3)
    {
        if (ProgLine==1)
            return;

        if (ProgLine>=2 && ProgLine<TEXTSOFGRAPH+2)
        {
            Appl_MaxEntry = PRTLEN;
            SetInputMode('a');
            GetOpt(0,ApplVar.GrafTexts[ProgLine-2], PRTLEN);
            ProgLineMes[0]='C';
            ProgLineMes[1]='A';
            WORDtoASC(ProgLineMes+2,ProgLine-1);
        }
        else
        {
            SetInputMode('9');
            ProgLine = 0;
        }
        return;
    }
    else if (ApplVar.ProgNumber ==2)
        GrapNo = GRAFESTMAX+1;
    else if (ApplVar.ProgNumber==0)
        GrapNo = 0;
    else if (!GrapNo && ApplVar.ProgNumber ==1)
        GrapNo = 1;
    switch (ProgLine)
    {
    case 1:
        break;
    case 2://Festival number
        if (GrapNo==0 || GrapNo == GRAFESTMAX+1)
        {
            ProgLine = 3;
            ProgPrnGraph();
            return;
        }
        else
        {
            if (Appl_EntryCounter)
            {
                sIdx = ApplVar.NumberEntry;
                if (sIdx==0 || sIdx>GRAFESTMAX)
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                    return;
                }
                GrapNo = sIdx;
            }
            CopyFrStr(ProgLineMes+SETUPMARIN,GrapSet[ProgLine-2]);
            WORDtoASC(ProgLineMes+DISLEN-1,GrapNo);
            break;
        }
    case 3://Picture number
        if (!Appl_EntryCounter)
            sIdx = ApplVar.Graph[GrapNo].PictNo;
        else
        {
            if (ApplVar.NumberEntry>GRAPHICMAX)
            {//=1ʱ��Ϊ�û��Զ���ͼƬ
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                return;
            }
            sIdx = ApplVar.NumberEntry;
        }
        CopyFrStr(ProgLineMes+SETUPMARIN,GrapSet[ProgLine-2]);
        WORDtoASC(ProgLineMes+DISLEN-1,sIdx);
        ApplVar.Graph[GrapNo].PictNo = sIdx;

        break;
    case 4://Date from
        if (GrapNo==0 || GrapNo == GRAFESTMAX+1)
        {
            ProgLine = 6;
            ProgPrnGraph();
            return;
        }
        else
        {
            Appl_MaxEntry = 8;
            GetOpt(35, ApplVar.Graph[GrapNo].DateFrom, sizeof(ApplVar.Graph[GrapNo].DateFrom));
            break;
        }
    case 5://date to
        if (GrapNo==0 || GrapNo == GRAFESTMAX+1)
        {
            ProgLine = 6;
            ProgPrnGraph();
            return;
        }
        else
        {
            Appl_MaxEntry = 8;
            GetOpt(36, ApplVar.Graph[GrapNo].DateTo, sizeof(ApplVar.Graph[GrapNo].DateTo));
            break;
        }
    default:
        GrapNo++;
        if (GrapNo > GRAFESTMAX+1)
            GrapNo = 0;
        Appl_MaxEntry = 4;
        ProgLine = 0;
        break;
    }
}


void ProgIC()  //ccr chipcard 2004-06-28
{
#if DD_CHIPC
    BYTE TempStr[15];
    short i;
    UnLong  sLong;


    switch (ProgLine)
    {
    case 1 :
        RESETBIT(ApplVar.MyFlags,SETCONFIRM);//ccr040809
        ProgLine = 2;
    case 2 ://ICCard Enable
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        CheckBitValue(69,(BYTE *)&ApplVar.ICCardSet.Options,1 + 0x80,0);
        break;
    case 3 ://Manager PASSWORD VERIFY
/*	           if (TESTBIT(ApplVar.ICCardSet.Options,BIT0))
               {
                Appl_MaxEntry = sizeof(ApplVar.ICCardSet.Password) * 2;
                BitNumber = 0;
                SETBIT(ApplVar.MyFlags,PWDMODE);
                GetBCDValue(ICSZMIMA,ApplVar.ICCardSet.Password,3,TRUE);
                break;
               }
               else
               {
                Appl_MaxEntry = 0;
                ProgLine = 0;
                break;
               }
*/
        if (!TESTBIT(ApplVar.ICCardSet.Options, IC_CHIPCARD))
        {
            Appl_MaxEntry = 4;
            ProgLine = 0;
            break;
        }
        else
            ProgLine = 4;
    case 4 : //POSCODE SET
        Appl_MaxEntry = sizeof(ApplVar.ICCardSet.PosCode) * 2;
        BitNumber = 0;
        memset(TempStr,0,sizeof(TempStr));//ccr20120101
        ULongToBCDValue(TempStr,ApplVar.ICCardSet.PosCode);
        SETBIT(ApplVar.MyFlags,PWDMODE);
        GetBCDValue(Line_POSCODE,TempStr,4,TRUE);
        if (Appl_EntryCounter)
        {
            BCDValueToULong(TempStr,&sLong);
					  ApplVar.ICCardSet.PosCode=sLong;
            IC.CHIP_PSWD[2] = 0xff;
            ProgLine = 5;
            Appl_EntryCounter = 0;
        }
        else
            break;
    case 5 : //POSCODE confirm
        if (ApplVar.ICCardSet.PosCode)
        {
            SETBIT(ApplVar.MyFlags,SETCONFIRM);//ccr040809
            Appl_MaxEntry = sizeof(ApplVar.ICCardSet.PosCode) * 2;
            BitNumber = 0;
            memset(TempStr,0,sizeof(TempStr));
            SETBIT(ApplVar.MyFlags,PWDMODE);
            GetBCDValue(Line_CONFIRM,TempStr,4,TRUE);
            sLong = 0;                              //ccr020809
            if (Appl_EntryCounter)
            {
                BCDValueToULong(TempStr,&sLong);
                if (sLong != ApplVar.ICCardSet.PosCode)
                {
                    ApplVar.ErrorNumber=CWXXI51 - CWXXI01 + 1;
                    break;
                }
                else
                {
                    ProgLine = 6;
                    Appl_EntryCounter = 0;
                }
            }
            else
                break;
        }
        else
            ProgLine = 6;
    case 6 : //Type 0 Card Enable
    case 7 : //Type 1 Card Enable
    case 8 : //Type 2 Card Enable
    case 9 : //ApplVar.Report
    case 10 : //Discount
    case 11://Points
        RESETBIT(ApplVar.MyFlags,SETCONFIRM);//ccr040809
        Appl_MaxEntry = 0;
        CheckBitValue(70+ProgLine-6,(BYTE *)&ApplVar.ICCardSet.Options,2+(ProgLine-6) + 0x80,0);
        break;
    case 12://Value
        if (TESTBIT(ApplVar.ICCardSet.Options,BIT6))
        {
            Appl_MaxEntry = 6;
            BitNumber = 0;
            GetBCDValue(Line_VALUE,ApplVar.ICCardSet.Value,3,FALSE);
            break;
        }
        else  ProgLine = 13;
    case 13://MIniNum
        if (TESTBIT(ApplVar.ICCardSet.Options,BIT6))
        {
            Appl_MaxEntry = 6;
            BitNumber = 0;
            GetBCDValue(Line_MINIMUM,ApplVar.ICCardSet.MiniNum,3,FALSE);
            break;
        }
        else ProgLine = 14;
    case 14://Toc_CC
        Appl_MaxEntry = 0;
        CheckBitValue(76,(BYTE *)&ApplVar.ICCardSet.Options,8 + 0x80,0);
        break;
    case 15://IC_DEAD
        Appl_MaxEntry = 0;
        CheckBitValue(78,(BYTE *)&ApplVar.ICCardSet.Options+1,1 + 0x80,0);// ָ��Options�ĸ��ֽ�  //
        break;
    default:
        Appl_MaxEntry = 4;
        ProgLine = 0;
        break;
    }
#endif
}

void ProgPromotion()
{
    WORD i;

    switch (ProgLine)
    {
    case 1:
        BitNumber = 0;
        ProgLine = 2;
    case 2:     /* JOLLY ?*/
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        CheckBitValue(66,&PROMOTION,1,YN);
        break;
    case 3:
        if (!TESTBIT(PROMOTION,BIT0))
        {
            Appl_MaxEntry = 4;
            BitNumber = 0;
            i = ApplVar.AP.Promotion.Freq;
            GetWordValue(Line_FREQUENT,&i,9999);
            ApplVar.AP.Promotion.Freq = i;
            break;
        }
        else
            ProgLine = 4;
    case 4:
        if (!TESTBIT(PROMOTION,BIT0))
        {
            Appl_MaxEntry = 8;
            BitNumber = 0;
            GetBCDValue(Line_MINIMUM,ApplVar.AP.Promotion.JollyMin,4,TRUE);
            break;
        }
        else
            ProgLine = 5;
    case 5:
        if (!TESTBIT(PROMOTION,BIT0))
        {
            Appl_MaxEntry = 2;
            GetByteValue(Line_GRAPHIC,&ApplVar.AP.Promotion.GrapIdx,22);
            break;
        }
        else
            ProgLine = 6;
    case 6:
        if (!TESTBIT(PROMOTION,BIT0))
        {
            SetInputMode('a');

            Appl_MaxEntry = 32;
            GetOpt(0, ApplVar.AP.Promotion.Memo, sizeof(ApplVar.AP.Promotion.Memo)-1);
            break;
        }
        else
            ProgLine = 7;
    case 7:
        SetInputMode('9');
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        CheckBitValue(67,&PROMOTION,2,YN);
        break;
    case 8:
        if (!TESTBIT(PROMOTION,BIT1))
        {
            Appl_MaxEntry = 8;
            BitNumber = 0;
            GetBCDValue(Line_VALUE,ApplVar.AP.Promotion.PointVal,4,FALSE);
            break;
        }
        else
            ProgLine = 9;
    case 9:
        if (!TESTBIT(PROMOTION,BIT1))
        {
            Appl_MaxEntry = 8;
            BitNumber = 0;
            GetBCDValue(Line_MINIMUM,ApplVar.AP.Promotion.PointMin,4,FALSE);
            break;
        }
        else
            ProgLine = 9;
    default:
        Appl_MaxEntry = 4;
        ProgLine = 0;
        break;
    }
}

void ProgNULL()
{
    switch (ProgLine)
    {
    case 1:
        break;
    case 2:
        break;
    default:
        ProgLine = 0;
        break;
    }
}

void ProgOFF()
{
    if (ApplVar.ProgNumber >= ApplVar.AP.OFFPrice.Number)
    {
        if (ApplVar.AP.OFFPrice.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            ApplVar.ProgNumber = -1;
            ProgLine = 0;
        }
        return;
    }
    ApplVar.OFFNumber = ApplVar.ProgNumber;
    ReadOFFPrice();
    switch (ProgLine)
    {
    case 1:
        break;
    case 2:     /* ApplVar.OFFPrice name */
        SetInputMode('a');
        Appl_MaxEntry = ApplVar.AP.OFFPrice.CapSize;
        if (GetOpt(0, ApplVar.OFFPrice.Name, ApplVar.AP.OFFPrice.CapSize))
            break;
    case 3:     /* OFF type */
        SetInputMode('9');
        Appl_MaxEntry = 1;
        if (GetOpt(34, &ApplVar.OFFPrice.Type, 3))
            break;
    case 4:     /* DateFrom */
        if (ApplVar.OFFPrice.Type>0)
        {
            Appl_MaxEntry = 4;
            GetOpt(35, ApplVar.OFFPrice.DateFrom, sizeof(ApplVar.OFFPrice.DateFrom));
            break;
        }
    case 5:     /* DateTo */
        if (ApplVar.OFFPrice.Type>0)
        {
            Appl_MaxEntry = 4;
            if (GetOpt(36, ApplVar.OFFPrice.DateTo, sizeof(ApplVar.OFFPrice.DateFrom)))
                break;
        }
    case 6:     /* TimeFrom */
        if (ApplVar.OFFPrice.Type>0)
        {
            Appl_MaxEntry = 4;
            if (GetOpt(37, ApplVar.OFFPrice.TimeFrom, sizeof(ApplVar.OFFPrice.DateFrom)))
                break;
        }
    case 7:     /* TimeTo */
        if (ApplVar.OFFPrice.Type>0)
        {
            Appl_MaxEntry = 4;
            if (GetOpt(38, ApplVar.OFFPrice.TimeTo, sizeof(ApplVar.OFFPrice.DateFrom)))
                break;
        }
    case 8:     /* WeekDay */
        if (ApplVar.OFFPrice.Type>0)
        {
            Appl_MaxEntry = 7;
            GetOpt(39, &ApplVar.OFFPrice.WeekDay, 7);
            break;
        }
    case 9:     /* Discount or Package */
        if (ApplVar.OFFPrice.Type>0)
        {
            if (ApplVar.OFFPrice.Type==1)
            {
                Appl_MaxEntry = 3;
                GetOpt(41, &ApplVar.OFFPrice.OFFVal.TYPE1.NumItems, 255);
                break;
            }
            else if (ApplVar.OFFPrice.Type==2)
            {
                Appl_MaxEntry = 5;
                GetOpt(40, ApplVar.OFFPrice.OFFVal.Discount, 2);
                break;
            }
        }
        else
            ProgLine = 10;
    case 10:        //OFF ApplVar.Price for a unit
        if (ApplVar.OFFPrice.Type==1)
        {
            Appl_MaxEntry = 4;
            GetOpt(42, ApplVar.OFFPrice.OFFVal.TYPE1.PriceU,ApplVar.AP.OFFPrice.PriUSize);
            break;
        }
        else
            ProgLine = 11;
    case 11:        //OFF ApplVar.Price for a package
        if (ApplVar.OFFPrice.Type==1)
        {
            Appl_MaxEntry = 4;
            GetOpt(43, ApplVar.OFFPrice.OFFVal.TYPE1.PriceP,sizeof(ApplVar.OFFPrice.OFFVal.TYPE1.PriceP));
            break;
        }
    default:
        Appl_MaxEntry = 4;
        ProgLine = 0;
        break;
    }
    WriteOFFPrice();
}



void ProgAgree()
{
    if (ApplVar.ProgNumber >= ApplVar.AP.Agree.Number)
    {
        if (ApplVar.AP.Agree.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            ApplVar.ProgNumber = -1;
            ProgLine = 0;
        }
        return;
    }
    ApplVar.AgreeNumber = ApplVar.ProgNumber;
    ReadAgree();
    switch (ProgLine)
    {
    case 1:
        break;
    case 2:     /* ApplVar.Agree name */
        SetInputMode('a');
        Appl_MaxEntry = ApplVar.AP.Agree.CapSize * 2;
        if (GetOpt(0, ApplVar.Agree.Name, ApplVar.AP.Agree.CapSize))
            break;
    case 3:     /* ApplVar.Agree name */
        SetInputMode('a');
        Appl_MaxEntry = sizeof(ApplVar.Agree.Addr) * 2;
        GetString((char*)Prompt.LineCap[30],ApplVar.Agree.Addr, sizeof(ApplVar.Agree.Addr));
        break;
    case 4:     /* ApplVar.Agree ApplVar.Tax */
        SetInputMode('9');
        Appl_MaxEntry = sizeof(ApplVar.Agree.Tax) * 2;
        GetString((char*)Prompt.LineCap[9],ApplVar.Agree.Tax, sizeof(ApplVar.Agree.Tax));
        break;
    default:
        Appl_MaxEntry = 4;
        ProgLine = 0;
        break;
    }
    WriteAgree();
}

void ProgKPrn()
{
    struct PRINTER *SetKP;

    SetKP = (struct PRINTER *) &KPSTART;
    if (ApplVar.ProgNumber > 8)
    {
        ApplVar.ProgNumber = -1;
        ProgLine = 0;
        return;
    }
    SetKP = SetKP + ApplVar.ProgNumber;
    switch (ProgLine)
    {
    case 1:
        break;
    case 2:     /* Type of printer */
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        if (!BitNumber)
            BitNumber = (SetKP->type & 0x0f) + 1;
        if (BitNumber > KPTypeNum )
            BitNumber = 1;
        SetKP->type = (SetKP->type & 0xf0) + BitNumber-1;

        CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[Line_PRTTYPE]);
#if( (DD_ZIP==1)||(DD_ZIP_21==1) )
        memcpy(ProgLine1Mes+ DISLEN - 7,KPType[BitNumber-1],6);
#else
        memcpy(ProgLineMes+ DISLEN - sizeof(KPType[0]),KPType[BitNumber-1],sizeof(KPType[0]));
#endif
        break;
    case 3:
    case 4:
    case 5:
        //ccr2014-07-26>>>>>>>>>>>>>
        if (SetKP->type & 0x0f)
        {
            Appl_MaxEntry = 0;
            Appl_EntryCounter = 0;

#if( (DD_ZIP==1)||(DD_ZIP_21==1) || DD_LCD_1601==1)
            CheckBitValue(ProgLine-3+84,&SetKP->type,1+(ProgLine-3+5),0);
#else
            CheckBitValue(50,&SetKP->type,1+(ProgLine-3+5)+0x80,0);
#endif
        }
        else
        {//���رճ�����ӡ��ʱ,������к�������
            Appl_MaxEntry = 4;
            ProgLine = 0;
        }
        //<<<<<<<<<<<<<<<<<<<<<<<<<<
        break;
    case 6:     /* ApplVar.Port */
        BitNumber = 0;
        Appl_MaxEntry = 1;
        GetByteValue(Line_PORT,&SetKP->port,ApplVar.AP.Port.Number);
        //ccr2014-07-26>>>>ǿ�����ô�������
        if (SetKP->port)
        {
            ApplVar.PortNumber = SetKP->port-1;
            ReadPort();
            switch (ApplVar.Port.Type)
            {
            case '1':
            case '2':
            case '3':
                COMPUTER = 0; PCCounter = 0;
                break;
            case '4':
                CCDCounter = 0;BARCODE &= 0xf0;
                break;
            case '5':
                BALANCE = 0;   BalCounter = 0;
                break;
            }
            ApplVar.Port.Type = '6';
            WritePort();
        }//<<<<<<<<<<<<
        break;
    case 7:     /* link with another ApplVar.KP */
        BitNumber = 0;
        Appl_MaxEntry = 1;
        SetKP->alter++;
        GetByteValue(Line_EXTRAKP,&SetKP->alter,8);
        if (SetKP->alter>0)
            SetKP->alter--;
        break;
    default:
        Appl_MaxEntry = 4;
        ProgLine = 0;
        break;
    }
}


void ProgSlip()      //Lyq added for set the control message of slip  20040331
{
//    BYTE  SP;
    if (ApplVar.ProgNumber > 4)
    {
        ApplVar.ProgNumber = -1;
        ProgLine = 0;
        return;
    }
    switch (ProgLine)
    {
    case 1:
        break;
    case 2:
        Appl_MaxEntry = 0;
        //Appl_EntryCounter = 0;
        if (!BitNumber)
            BitNumber = (SLIP & 0x0f) + 1;
        if (BitNumber > SPTypeNum  )
            BitNumber = 1;
        SLIP = BitNumber - 1;

        CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[Line_SLIPTYPE]);

#if( (DD_ZIP==1)||(DD_ZIP_21==1) )
        memcpy(ProgLine1Mes+ DISLEN - 8,SPType[BitNumber - 1],7);
#else
        memcpy(ProgLineMes+ DISLEN - sizeof(SPType[0]-1),SPType[BitNumber - 1],sizeof(SPType[0]));
#endif
        Appl_EntryCounter = 0;
        break;
    case 3:
        if (SLIP>0)
        {
            BitNumber = 0;
            Appl_MaxEntry = 2;
            GetByteValue(Line_BLANKLIN,&SLIP_TOP, 10);
            break;
        }
    case 4:
        if (SLIP>0)
        {
            BitNumber = 0;
            Appl_MaxEntry = 2;
            GetByteValue(Line_LINEPAGE,&SLIP_MAX,255);
            break;
        }
    case 5:
        if (SLIP>0)
        {
            MemSet(ProgLineMes, sizeof(ProgLineMes), ' ');
#if( (DD_ZIP==1)||(DD_ZIP_21==1) )
            memset(ProgLine1Mes,' ',sizeof(ProgLine1Mes));
#endif
            CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[Line_PRTINFO]);
            Appl_MaxEntry = 0;
            if (BitNumber<2)
                BitNumber = 1;
//			GetByteValue(Line_PRTINFO,&SLIPINFO);
            if (BitNumber==2)
            {
                BitNumber = 1;
                SLIPINFO ^= 0x08;
            }
#if( (DD_ZIP==1)||(DD_ZIP_21==1) )
            if (TESTBIT(SLIPINFO, BIT3))
            {
                ProgLine1Mes[DISLEN-3] = 'Y';
                ProgLine1Mes[DISLEN-2] = 'e';
                ProgLine1Mes[DISLEN-1] = 's';
            }
            else
            {
                ProgLine1Mes[DISLEN-3] = 'N';
                ProgLine1Mes[DISLEN-2] = 'o';
                ProgLine1Mes[DISLEN-1] = ' ';
            }
#else
            if (TESTBIT(SLIPINFO, BIT3))
                ProgLineMes[DISLEN-2] = 'y';
            else
                ProgLineMes[DISLEN-2] = 'n';
#endif
            break;
        }
    case 6:     /* ApplVar.Port */
//		if(SLIP>0)
//		{
//			BitNumber = 0;
//			Appl_MaxEntry = 2;
//			SP = SECOND &0xf0;
//			SECOND &= 0x0f;
//			GetByteValue(Line_SECOND,&SECOND);
//			SECOND |= SP;
//			break;
//		}
//	case 7:     /* link with another ApplVar.KP */
        if (SLIP>0)
        {
            BitNumber = 0;
            Appl_MaxEntry = 2;
            GetByteValue(Line_LEFTMAR,&LMARGE, 50);
            break;
        }
    case 7:     /* port */
        if (SLIP>0)
        {
            BitNumber = 0;
            Appl_MaxEntry = 1;
            GetByteValue(Line_PORT,&ApplVar.AP.Flag[32],ApplVar.AP.Port.Number);
            break;
        }
    default:
        Appl_MaxEntry = 4;
        ProgLine = 0;
        break;
    }
}



void ProgICBlock()  //ccr chipcard 2004-07-01
{
    BYTE TempStr[15];
    unsigned long ICCardNOBK;

    if (ProgLine == 1)
    {
//		ApplVar.ProgNumber = 0;
//		ProgLine = 2;
        return;
    }
    else if (ProgLine > 2)
    {
        ApplVar.ProgNumber++;
        ProgLine = 2;
    }
    if (ApplVar.ProgNumber >= ApplVar.AP.ICBlock.Number)
    {
        if (ApplVar.AP.ICBlock.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            ApplVar.ProgNumber = -1;
            ProgLine = 0;
        }
        return;
    }

    ApplVar.ICBlockNumber = ApplVar.ProgNumber;
    ReadICBlock();
/*
    if(ICBlockPrintFlag == 1)
    {
        ICBlockPrintFlag = 0;
        ApplVar.ProgNumber = -1;
        ProgLine = 0;
        PrintICBlock();
        return;
    }
    ICBlockPrintFlag = 0;
*/
    Appl_MaxEntry = 8;
    memset(TempStr,0,sizeof(TempStr));//ccr20120101
    if (Appl_EntryCounter==0)
        ULongToBCDValue(TempStr,ApplVar.ICBlock.ICCardNO);

    GetBCDValue(Line_BUYRATE,TempStr,4,TRUE);

    memset(SysBuf,' ',8);                   //ccr040809
    WORDtoASCZero(SysBuf+4,ApplVar.ProgNumber+1);
    ProgLineMes[1] = SysBuf[2];
    ProgLineMes[2] = SysBuf[3];
    ProgLineMes[3] = SysBuf[4];

    ICCardNOBK = ApplVar.ICBlock.ICCardNO;
    BCDValueToULong(TempStr,&ICCardNOBK);
    ApplVar.ICBlock.ICCardNO = ICCardNOBK;
    if (Appl_EntryCounter)
    {
        if (ApplVar.ICBlock.ICCardNO == 99999999)
        {
            PrintICBlock();//ICBlockPrintFlag = 1;
            if (ApplVar.ProgNumber>0)
                ApplVar.ProgNumber--;

        }
        else
        {
            WriteICBlock();
//			ApplVar.ProgNumber++;
        }
    }
}

//
void ProgIP()
{
    WORD pPort;

    switch (ProgLine)
    {
    case 1:
        Appl_MaxEntry = 15;
        Appl_EntryCounter = 0;
        SetInputMode('0');
        ProgLine = 2;//ccr2015-10-12
    case 2:
        MemSet(ProgLineMes, sizeof(ProgLineMes), ' ');
#if( (DD_ZIP==1)||(DD_ZIP_21==1) )
        memset(ProgLine1Mes,' ',sizeof(ProgLine1Mes));
#endif
        GetIP(MSG_CLIENTIP,ApplVar.IP.IPAddress);
        if (Appl_EntryCounter>0)
        {
            REGISTER = ApplVar.IP.IPAddress[3];//ccr 050111
#if (0)//defined(CASE_ETHERNET)
            Ethernet_Start();
#endif
        }
        break;
    case 3:
        SetInputMode('9');
        Appl_MaxEntry = 5;
        BitNumber = 0;
        if (ApplVar.IP.ClientPort==0)
            ApplVar.IP.ClientPort = 11024;//Ĭ��11024
        pPort = ApplVar.IP.ClientPort;
        GetWordValue(Line_PORT,&pPort,65530);
        ApplVar.IP.ClientPort = pPort;
#if (0)//defined(CASE_ETHERNET)
        if (Appl_EntryCounter)
            Ethernet_Start();
#endif
        break;
    case 4:
        Appl_MaxEntry = 15;
        SetInputMode('0');
        MemSet(ProgLineMes, sizeof(ProgLineMes), ' ');
#if( (DD_ZIP==1)||(DD_ZIP_21==1) )
        memset(ProgLine1Mes,' ',sizeof(ProgLine1Mes));
#endif
        GetIP(MSG_SERVERIP,ApplVar.IP.ServerIP);
        break;
    case 5:
        SetInputMode('9');
        Appl_MaxEntry = 5;
        BitNumber = 0;
        if (ApplVar.IP.ServerPort==0)
            ApplVar.IP.ServerPort = 11024;//Ĭ��11024
        pPort = ApplVar.IP.ServerPort;
        GetWordValue(Line_PORT,&pPort,65530);
        ApplVar.IP.ServerPort = pPort;
        break;
    case 6://��������
        Appl_MaxEntry = 15;
        SetInputMode('0');
        MemSet(ProgLineMes, sizeof(ProgLineMes), ' ');
#if( (DD_ZIP==1)||(DD_ZIP_21==1) )
        memset(ProgLine1Mes,' ',sizeof(ProgLine1Mes));
#endif
        GetIP(MSG_GATEWAY,ApplVar.IP.GateWay);
#if (0)//defined(CASE_ETHERNET)
        if (Appl_EntryCounter)
            Ethernet_Start();
#endif
        break;
    case 7://����MASK
        Appl_MaxEntry = 15;
        SetInputMode('0');
        MemSet(ProgLineMes, sizeof(ProgLineMes), ' ');
#if( (DD_ZIP==1)||(DD_ZIP_21==1) )
        memset(ProgLine1Mes,' ',sizeof(ProgLine1Mes));
#endif
        GetIP(MSG_IPMASK,ApplVar.IP.IPMask);
#if !defined(CASE_GPRS) //ccr2016-12-21>>>>>>>>>>
        if (!Appl_EntryCounter)//�������µĶ˿�����ʱ,�Զ��˳�����
            break;
#if (0)//defined(CASE_ETHERNET)
        else
            Ethernet_Start();
#endif
#else
        break;
    case 8://ccr2015-03-24>>>>>>>>
        SetInputMode('a');
        Appl_MaxEntry=sizeof(ApplVar.IP.APN)-1;
        ApplVar.IP.APN[Appl_MaxEntry]=0;
        if (GetString(GPRSAPNNAME, ApplVar.IP.APN, Appl_MaxEntry))
            break;
    case 9://ccr2015-03-11>>>>>>>>
        SetInputMode('a');
        Appl_MaxEntry=sizeof(ApplVar.IP.UserName)-1;
        ApplVar.IP.UserName[Appl_MaxEntry]=0;
        if (GetString(GPRSUSERNAME, ApplVar.IP.UserName, Appl_MaxEntry))
            break;
    case 10:
        if (ApplVar.IP.UserName[0])
        {
            SetInputMode('a');
            Appl_MaxEntry=sizeof(ApplVar.IP.Password)-1;
            ApplVar.IP.Password[Appl_MaxEntry]=0;
            if (GetString((char*)GPRSPASSWORD, ApplVar.IP.Password, Appl_MaxEntry))
                break;
        }//ccr2015-03-11<<<<<<<<<<<

#endif//ccr2016-12-21<<<<<<<<<<<
    default:
        Appl_MaxEntry = 4;
        ProgLine = 0;
        KeyFrHost=ApplVar.AP.FirmKeys[ID_CANCEL];//ccr2015-10-12�˳�����
        break;
    }
}

#endif

#if defined(CASE_GPRS)
void  ProgGPRSFuncs()
{
    WORD sInput;
    do
    {
        sInput = ListItems(SETGPRSFUNC,0,"GPRS",true);
        switch (sInput)
        {
        case (gprsSENDMESS -gprsSENDMESS+1)://
            TestSendMess();                    //Ccr���Ͷ���Ϣ//
            break;
        case (gprsSETMODE -gprsSENDMESS+1):
            GPRS_SetSendMode();                //Ccr���÷��ͷ�ʽ//
            break;
        case (gprsSendECRLog -gprsSENDMESS+1):
            GPRSSendECR_FM();                 //Ccr������ˮ//
            break;
        case (gprsSendECRLogAll -gprsSENDMESS+1):
            GPRSSendECR_FM_All();                 //Ccr����ȫ����ˮ//
            break;
        case (gprsDownloadPLU -gprsSENDMESS+1):
            GPRS_DownloadPLU();         //"���ص�Ʒ�ļ�"
            break;
        case (gprsDownloadDEPT -gprsSENDMESS+1):
            GPRS_DownloadDEPT();            //"���ز����ļ�"
            break;
        case (gprsDownloadCLERK -gprsSENDMESS+1):
            GPRS_DownloadCLERK();          //"�����տ�Ա"
            break;
        case (gprsDownloadHEAD -gprsSENDMESS+1):
            GPRS_DownloadHEAD();           //"����Ʊͷ"
            break;
        case (gprsDownloadTRAIL -gprsSENDMESS+1):
            GPRS_DownloadPTRAIL();          //"����Ʊβ"
            break;
        case (gprsDownloadALL -gprsSENDMESS+1):
            GPRS_DownloadALL();          //"����ȫ������"
            break;
        case (gprsRestart -gprsSENDMESS+1):
            GPRS_Restart();          //"��λGPRS"
            //break;
        case 0:
        case It_EXIT:
        default:
            Appl_MaxEntry = 4;
            ProgLine = 0;
            KeyFrHost=ApplVar.AP.FirmKeys[ID_CANCEL];//ccr2015-10-12�˳�����
            return;
        }
    } while(true);

}
#endif

#if defined(CASE_ETHERNET)

void  ProgEthernetFuncs()
{
    WORD sInput;
    do
    {
        sInput = ListItems(SETETHERNETFUNC,0,0,true);
        switch (sInput)
        {
        case (ethernetPINGMESS -ethernetPINGMESS+1)://
            PingEthernet();                    //Ccr�������//
            break;
        case (ethernetSETMODE -ethernetPINGMESS+1):
            ETHERNET_SetSendMode();                //Ccr���÷��ͷ�ʽ//
            break;
        case (ethernetSendECRLog -ethernetPINGMESS+1):
            ETHERNETSendECR_FM();                 //Ccr������ˮ//
            break;
        case (ethernetSendECRLogAll -ethernetPINGMESS+1):
            ETHERNETSendECR_FM_All();                 //Ccr����ȫ����ˮ//
            break;
        case (ethernetDownloadPLU -ethernetPINGMESS+1):
            ETHERNET_DownloadPLU();         //"���ص�Ʒ�ļ�"
            break;
        case (ethernetDownloadDEPT -ethernetPINGMESS+1):
            ETHERNET_DownloadDEPT();            //"���ز����ļ�"
            break;
        case (ethernetDownloadCLERK -ethernetPINGMESS+1):
            ETHERNET_DownloadCLERK();          //"�����տ�Ա"
            break;
        case (ethernetDownloadHEAD -ethernetPINGMESS+1):
            ETHERNET_DownloadHEAD();           //"����Ʊͷ"
            break;
        case (ethernetDownloadTRAIL -ethernetPINGMESS+1):
            ETHERNET_DownloadPTRAIL();          //"����Ʊβ"
            break;
        case (ethernetDownloadALL -ethernetPINGMESS+1):
            ETHERNET_DownloadALL();          //"����ȫ������"
            break;
        case (ethernetRestart -ethernetPINGMESS+1):
            ETHERNET_Restart();          //"��λETHERNET"
            break;
        case 0:
        case It_EXIT:
        default:
            Appl_MaxEntry = 4;
            ProgLine = 0;
            KeyFrHost=ApplVar.AP.FirmKeys[ID_CANCEL];//ccr2015-10-12�˳�����
            return;
        }
    } while(true);

}

/**
 * ����MAC��ַ------
 *
 * @author EutronSoftware (2017-02-28)
 */
BYTE OTPFlash_WriteMAC(BYTE* pBuffer);
void ProgMAC()
{
    BYTE sMAC[6];
    BYTE sKey;

#if !defined(DEBUGBYPC)
    sMAC[5]=MAC_ADDR[0];
    sMAC[4]=MAC_ADDR[1];
    sMAC[3]=MAC_ADDR[2];
    sMAC[2]=MAC_ADDR[3];
    sMAC[1]=MAC_ADDR[4];
    sMAC[0]=MAC_ADDR[5];
#endif
    Appl_EntryCounter=0;
    PutsO("MAC");
    DisplayHex(sMAC,6,1);
    if (CLONG(sMAC[0])==0xffffffff)
    {
        GetStrFrKBD('*',0,0);
        StrToBCDValue(sMAC, &AtEntryBuffer(1), 6);
        DisplayHex(sMAC,6,0);
#if( (DD_ZIP==1)||(DD_ZIP_21==1) )
        Puts1("Confirm?");
#endif
        WAIT_INPUT(sKey);
#if( (DD_ZIP==1)||(DD_ZIP_21==1) )
        Puts1(Msg[SPACE].str);
#endif
        if (sKey==ApplVar.AP.FirmKeys[ID_ENTER])
        {
            sKey=sMAC[0];sMAC[0]=sMAC[5];sMAC[5]=sKey;
            sKey=sMAC[1];sMAC[1]=sMAC[4];sMAC[4]=sKey;
            sKey=sMAC[2];sMAC[2]=sMAC[3];sMAC[3]=sKey;
#if !defined(DEBUGBYPC)
            OTPFlash_WriteMAC(sMAC);
#endif
        }
    }
    else
    {
        WAIT_INPUT(sKey);
    }
}
#endif


