#define GENERAL_C 4
#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
#include "flowbill.h"	  //lyq2003
#include "ejournal.h"
#include "fiscal.h"

extern BYTE	Alarm;

WORD	LEDDelay;		// ������Ϣ��˸������� //

//ccr080901  �Ƚϲ�����ͳ�����ֵ //
void SaveTotalMax(BCD *bcd)
{
	BYTE	sSign;

	sSign = bcd->Sign;
	bcd->Sign = 0;

	if (CompareBCD(bcd,&ApplVar.TotalMax)>0)
	{
		memcpy(ApplVar.TotalMax.Value,bcd->Value,sizeof(ApplVar.TotalMax.Value));
	}

	bcd->Sign = sSign;
}
//<<<<<<<<<<<<<<<<<<<<<<<<<




void CheckBreakKey()
{
	BYTE key;

	if (KbHit())
    {
		key = Getch();
		if (key > 65)       /* central or clerk lock */
		{
		   	if (key < NOCLERK)      /* central Lock */
		   	{
			    ApplVar.CentralLock = key;
				while(ApplVar.CentralLock == OFF)       /* lock off then wait */
				{
				    key = Getch();
				    if (key > 65 && key < NOCLERK)
					    ApplVar.CentralLock = key;
				}
		     }
		     else
		     {
			     if (key == NOCLERK)
				 {
					 if (ApplVar.ClerkLock)
				     {
						 ApplVar.ClerkLock = 0;
						 ApplVar.SaveClerk = 0;
				     }
				 }
				else if (key != ApplVar.ClerkLock)
				{
				     ApplVar.ClerkLock = key;
				     ApplVar.SaveClerk = key - NOCLERK;
				     if (ApplVar.SaveClerk > ApplVar.AP.Clerk.Number)
				     {
						 ApplVar.SaveClerk = 0;
						 ApplVar.ClerkLock = 0;
				     }
				 }
		    }
		 }
		 else if (key == ApplVar.AP.FirmKeys[ID_CLEAR] && ApplVar.FReport != Z && !ApplVar.RepComputer)  /* clear is break */
		 {
		    ApplVar.ErrorNumber=ERROR_ID(CWXXI27);   /* user break*/
		    return;
		 }
    }
}

void ReadTotal()
{
    if (ApplVar.BufCC)     /* reset Customer count added ?*/
    {
		ReadRam(&ApplVar.Total.Qty.Sign, 1);
		return;
    }
    MemSet(&ApplVar.Total, sizeof(ApplVar.Total), 0);
    ReadRam((BYTE *)&ApplVar.Total.Qty, ApplVar.Size.Qty + 1);
    if (!TESTBIT(ApplVar.Total.Qty.Sign, BIT2))    /* already used then clear by not read */
    {
		ApplVar.Total.Qty = ZERO;
		return;
    }
    if (ApplVar.Size.Cc)
		ReadRam(ApplVar.Total.Cc.Value, ApplVar.Size.Cc);
    if (ApplVar.Size.Amt)
    {
		ReadRam(ApplVar.Total.Amt.Value, ApplVar.Size.Amt);
		if (TESTBIT(ApplVar.Total.Qty.Sign, BIT6))     /* qty negative ? */
		    SETBIT(ApplVar.Total.Amt.Sign, BIT7);
    }
    if (ApplVar.Size.RetQty)
    {
		ReadRam(ApplVar.Total.RetQty.Value, ApplVar.Size.RetQty);
		ApplVar.Total.RetQty.Sign = ApplVar.Total.Qty.Sign & 0x03;    /* same decimal */
    }
    if (ApplVar.Size.Disc)
    {
		ReadRam(ApplVar.Total.Disc.Value, ApplVar.Size.Disc);
		if (TESTBIT(ApplVar.Total.Qty.Sign, BIT4))     /* disc negative ? */
		    SETBIT(ApplVar.Total.Disc.Sign, BIT7);
    }
    if (ApplVar.Size.Cost)
    {
		ReadRam(ApplVar.Total.Cost.Value, ApplVar.Size.Cost);
		if (TESTBIT(ApplVar.Total.Qty.Sign, BIT5))     /* cost  negative ? */
		    SETBIT(ApplVar.Total.Cost.Sign, BIT7);
    }
}


void WriteTotal()
{
    if (ApplVar.BufCC)     /* reset Customer count added ?*/
    {
		RESETBIT(ApplVar.Total.Qty.Sign, BIT3);
		WriteRam(&ApplVar.Total.Qty.Sign, 1);    /* write back sign */
		return;
    }
    if (TESTBIT(ApplVar.Total.Amt.Sign, BIT7))
		SETBIT(ApplVar.Total.Qty.Sign, BIT6);
    else
		RESETBIT(ApplVar.Total.Qty.Sign, BIT6);
    if (TESTBIT(ApplVar.Total.Cost.Sign, BIT7))
		SETBIT(ApplVar.Total.Qty.Sign, BIT5);
    else
		RESETBIT(ApplVar.Total.Qty.Sign, BIT5);
    if (TESTBIT(ApplVar.Total.Disc.Sign, BIT7))
		SETBIT(ApplVar.Total.Qty.Sign, BIT4);
    else
		RESETBIT(ApplVar.Total.Qty.Sign, BIT4);
    SETBIT(ApplVar.Total.Qty.Sign, BIT2 + BIT3);   /* set bit 4 & 5 to indicate used */
    WriteRam((BYTE *)&ApplVar.Total.Qty, ApplVar.Size.Qty + 1);
    if (ApplVar.Size.Cc)
		WriteRam(ApplVar.Total.Cc.Value, ApplVar.Size.Cc);
    if (ApplVar.Size.Amt)
		WriteRam(ApplVar.Total.Amt.Value, ApplVar.Size.Amt);
    if (ApplVar.Size.RetQty)
		WriteRam(ApplVar.Total.RetQty.Value, ApplVar.Size.RetQty);
    if (ApplVar.Size.Disc)
		WriteRam(ApplVar.Total.Disc.Value, ApplVar.Size.Disc);
    if (ApplVar.Size.Cost)
		WriteRam(ApplVar.Total.Cost.Value, ApplVar.Size.Cost);
}

void PrintMultiply()
{
    BYTE saveprint;

    if (!ApplVar.MultiplyCount)     /* if not used no print */
		return;
    if (ApplVar.MultiplyCount == 1 && !CompareBCD(&ApplVar.Qty, &ONE))
		return;     /* don't print qty of one */
#if (defined(CASE_MALTA))
	Prefix1 = 0;
	Prefix2 = 0;
#endif
	saveprint = ApplVar.PrintLayOut;
    if (!TESTBIT(SLIPINFO, BIT0))
		ApplVar.PrintLayOut &= 0xe7;
    MemSet(SysBuf, sizeof(SysBuf), ' ');
    SysBuf[sizeof(SysBuf) - 1] = 0;
    if (ApplVar.MultiplyCount > 2)
    {
#if PRTLEN < 25
		FormatQty(SysBuf + sizeof(SysBuf) - 12, &ApplVar.Qty1);
		SysBuf[sizeof(SysBuf) - 10] = 'X';
		PrintStr(SysBuf + sizeof(SysBuf) - 1 - PRTLEN);
		MemSet(SysBuf, sizeof(SysBuf), ' ');
		SysBuf[sizeof(SysBuf) - 1] = 0;
#endif
		FormatQty(SysBuf + sizeof(SysBuf) - 4, &ApplVar.Qty3);
		SysBuf[sizeof(SysBuf) - 10] = 'X';
    }
	if (ApplVar.MultiplyCount > 1)
	{
		FormatQty(SysBuf + sizeof(SysBuf) - 12, &ApplVar.Qty2);
#if PRTLEN < 25 //ccr2014-05-29
		if (ApplVar.MultiplyCount == 2)
#endif
		{
		    SysBuf[sizeof(SysBuf) - 18] = 'X';
		    FormatQty(SysBuf + sizeof(SysBuf) - 20, &ApplVar.Qty1);
		}
		if (ApplVar.MultiplyCount > 2)
		    SysBuf[sizeof(SysBuf) - 2] = '=';
		else
		    SysBuf[sizeof(SysBuf) - 10] = '=';

#if PRTLEN < 25 //ccr2014-05-29
		if (ApplVar.MultiplyCount ==2)
		    PrintStr(SysBuf + sizeof(SysBuf) - 1 - PRTLEN - 8);
		else
#endif
			PrintStr(SysBuf + sizeof(SysBuf) - 1 - PRTLEN);
		MemSet(SysBuf, sizeof(SysBuf), ' ');
		SysBuf[sizeof(SysBuf) - 1] = 0;
    }
#if PRTLEN == 18
    FormatQty(SysBuf + sizeof(SysBuf) - 14, &ApplVar.Qty);
    FormatAmt(SysBuf + sizeof(SysBuf) - 3, &ApplVar.Price);
    SysBuf[sizeof(SysBuf) - 12] = 'X';
#else
    FormatQty(SysBuf + sizeof(SysBuf) - 16, &ApplVar.Qty);
    FormatAmt(SysBuf + sizeof(SysBuf) - 4, &ApplVar.Price);
    SysBuf[sizeof(SysBuf) - 14] = 'X';
#endif
	if (SysBuf[sizeof(SysBuf) - 1 - PRTLEN + 4] == ' ')
	    PrintStr(SysBuf + sizeof(SysBuf) - 1 - PRTLEN + 5);
	else
	    PrintStr(SysBuf + sizeof(SysBuf) - 1 - PRTLEN);
   	 ApplVar.PrintLayOut = saveprint;
#if (defined(CASE_MALTA))
	Prefix1 = PREFIX_1;
	Prefix2 = PREFIX_2;
#endif
}

//��ӡ������Ŀ��Ŀ
void PrintSaleQty()
{
    if (!QTY_I || !ApplVar.FReceipt)
		return;
    if (CheckNotZero(&ApplVar.SaleQty))    /* print item counter */
    {
		if (ApplVar.FPb)
		    ApplVar.PrintLayOut &= 0x02;
		else
		    ApplVar.PrintLayOut = 0x02;     /* set receipt */
 //		FormatQtyStr(Prompt.Caption[25], &ApplVar.SaleQty, 14);
		PrintStr(FormatQtyStr(Prompt.Caption[25], &ApplVar.SaleQty, 14));
    }
}

void PrintMessage(WORD number)
{
    number--;
    if (Prompt.Message[number][0])
		PrintStr(Prompt.Message[number]);
}

void PrintPbTrailer()
{
    BYTE saveprint;
    short i;

    if (ApplVar.PbNumber && TESTBIT(ApplVar.AP.Pb.Random, BIT7)
		    && TESTBIT(ApplVar.PrintLayOut, BIT1)
			&& TESTBIT(ApplVar.FNoPb, BIT2))
    {
		saveprint = ApplVar.PrintLayOut;
		ApplVar.PrintLayOut = 0x02;
	  	RamOffSet = (ApplVar.AP.Pb.Random & 0x0f) + ApplVar.AP.Pb.Text + ApplVar.AP.Pb.AmtSize + 6;
	    if (TESTBIT(PBINFO, BIT7))  /* Discount item stored ? */
			RamOffSet += ((ApplVar.AP.Pb.AmtSize + 1) * 2);
	    RamOffSet = RamOffSet * ApplVar.AP.Pb.NumberOfPb + ApplVar.AP.StartAddress[AddrPBt];      /*Start Pb Trailer */
		SysBuf[24] = 0;
		for (i = 0; i < 50; i++)
		{
		    ReadRam(SysBuf, 24);     /* read Line */
		    if (!SysBuf[0])     /* end line ? */
				break;
		    PrintRJ(SysBuf);
		}
		ApplVar.PrintLayOut = saveprint;
    }
}

void GetWordEntry()
{
	UnLong TempL ;
    ApplVar.NumberEntry = 0;
    if (CompareBCD(&ApplVar.Entry, &MAXWORD) < 1)   /* entry < 65535 */
		ApplVar.NumberEntry = (WORD)BCDValueToULong(ApplVar.Entry.Value, &TempL);
}

/* add corresponding totals */

void AddTotal()
{
	UnLong    save ;             /* unsigned long save;  */

    if (ApplVar.FTrain && ApplVar.PointerType != 1)
    {
   		RamOffSet += ApplVar.Size.Length; /* next period or total */
		return;         /* only add in clerk when training */
    }
    save = RamOffSet;      /* save OffSet for Writing */
    ReadTotal();
    RamOffSet = save;
    if (ApplVar.BufCC)             /* reset customer added ? customer count ? */
    {
		WriteTotal();
	    RamOffSet = save + ApplVar.Size.Length;  /* next period or total */
    }
    else
    {
		if (ApplVar.Size.Cc)
		{
	    	if (!TESTBIT(ApplVar.Total.Qty.Sign, BIT3))
			{
				if (!ApplVar.FTrvoid && !ApplVar.FCanc) /* already added ?*/
					Add(&ApplVar.Total.Cc, &ONE);
			}
		}
		if (ApplVar.Size.Qty)
		{
		    ApplVar.Total.Qty.Sign &= 0x83;         /* skip bits */
		    Add(&ApplVar.Total.Qty, &ApplVar.Qty);
		}
		if (ApplVar.Size.Amt)
//		{
	    	Add(&ApplVar.Total.Amt, &ApplVar.Amt);
//			PrintAmt(Prompt.Caption[47], &ApplVar.Total.Amt);
//		}
		if (ApplVar.Size.RetQty)
		{
		    Subtract(&ApplVar.Total.RetQty, &ApplVar.RetQty);   /* no Sign in memory so always subtract !!*/
		    if (TESTBIT(ApplVar.Total.RetQty.Sign, BIT7))       /* Result negative? ? */
				ApplVar.Total.RetQty = ZERO;
		}
		if (ApplVar.Size.Disc)
		    Add(&ApplVar.Total.Disc, &ApplVar.DiscAmt);
		if (ApplVar.Size.Cost)
		    Add(&ApplVar.Total.Cost, &ApplVar.Cost);
		WriteTotal();
    }
}


void AddPointerTotal()
{
    WORD skip, next;

    if (ApplVar.FProforma)
		return;
    if (!ApplVar.Size.Periods)
		return;
    if (!ApplVar.Size.Length)     /* active ? */
		return;
    if (ApplVar.FSplit)
		return;             /* don't add when split bill */
    skip = 0;
    if (TESTBIT(ApplVar.Size.Periods, BIT0))      /* calculate size of 1 pointer */
		skip += ApplVar.Size.Length;
    if (TESTBIT(ApplVar.Size.Periods, BIT1))
		skip += ApplVar.Size.Length;
    if (TESTBIT(ApplVar.Size.Periods, BIT2))
		skip += ApplVar.Size.Length;
    if (TESTBIT(ApplVar.Size.Periods, BIT3))
		skip += ApplVar.Size.Length;
    next = skip;
    switch (ApplVar.PointerType)
    {
	case 0:
	    skip = 0;
	    next = 0;
	    break;
	case 1:         /* Clerks */
	    if (!ApplVar.AP.Clerk.Number)
			return;
	    next *= (ApplVar.AP.Clerk.Number - ApplVar.ClerkNumber);
	    skip *= (ApplVar.ClerkNumber - 1);
	    break;
	case 2:         /* Hour */
	    if (!ApplVar.AP.Zone.Number)
			return;
	    next *= (ApplVar.AP.Zone.Number - ApplVar.Zone - 1);
	    skip *= ApplVar.Zone;
	    break;
	case 3:         /* day of week */
	    if (!ApplVar.AP.Day.Number)
			return;
	    next *= (ApplVar.AP.Day.Number - ApplVar.Day - 1);
	    skip *= ApplVar.Day;
	    break;
	case 4:         /* ApplVar.Month of Year */
	    if (!ApplVar.AP.Month.Number)
			return;
	    next *= (ApplVar.AP.Month.Number - ApplVar.Month - 1);
	    skip *= ApplVar.Month;
	    break;
	case REPDEFMAX-1:
	    if (ApplVar.AP.SalPer.Number)
		{
			next *= (ApplVar.AP.SalPer.Number - ApplVar.SalPerNumber);
		    skip *= (ApplVar.SalPerNumber - 1);
		}
		break;
	default:
	    break;
    }
   	RamOffSet += skip;
    if (TESTBIT(ApplVar.Size.Periods, BIT0))
		AddTotal();
    if (TESTBIT(ApplVar.Size.Periods, BIT1))
		AddTotal();
    if (TESTBIT(ApplVar.Size.Periods, BIT2))
		AddTotal();
    if (TESTBIT(ApplVar.Size.Periods, BIT3))
		AddTotal();
	RamOffSet += next;     /* start next pointer totals */
}

void ClearEntry()
{
	MemSet(EntryBuffer, sizeof(EntryBuffer), ' ');
	//ccr20131120>>>>>>>>>>>>>>>>>>
    if (ApplVar.CentralLock==RG || ApplVar.CentralLock==MG)
    {
        AtEntryBuffer(4) = '0';
        AtEntryBuffer(3) = '.';
        AtEntryBuffer(2) = '0';
    }
    AtEntryBuffer(1) = '0';
	//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
	AtEntryBuffer(0) = 0;
	Appl_EntryCounter = 0;
	ApplVar.DecimalPoint = 0;
}



short CheckMaxEntry(BCD *bcd,BYTE a)
/* max / 10 is digit and max % 10 is number of zeroes */
{
    BCD mx;
    BYTE i;

    if (!a)       /* not active */
		return 0;

    mx = ZERO;
    i = (a % 10) / 2;
    mx.Value[i] = a / 10;
    if (a % 2)
		mx.Value[i] *= 0x10;
    if (CompareBCD(bcd, &mx) < 1)        /* amt <= max */
		return 0;
    else
		return 1;
}


/* When "err" is non zero only display "err" else */
/* display ApplVar.ErrorNumber */
void CheckError(short err)
{
	char dbuf[DISLEN+1];

#if (DD_FISPRINTER==0)
	if (Alarm)//ccr091201
    {
        Alarm--;
		return;
    }
#endif

	if (!err)
		err = ApplVar.ErrorNumber;
	if (err==255)
	{
		Bell(0);
		if (ApplVar.ErrorNumber==255)
			ApplVar.ErrorNumber=0;
	}
	else if (err)
	{

#if DD_FISPRINTER
		LEDDelay-=16;
		if (LEDDelay>20)
			return;
		LEDDelay = 0;
#endif

		if (TESTBIT(ApplVar.ErrorNumber, BIT7))
		{
            if (GetTimerDelay1()==0)
            {
                RESETBIT(ApplVar.ErrorNumber, BIT7);
    #if DD_FISPRINTER
                PutsO(Msg[SPACE].str);
    #endif
            }
		}
		else
		{
#if (DD_FISPRINTER && !defined(DEBUGBYPC))
			if (ApplVar.ErrorNumber<ERROR_ID(CWXXI74))
				SwitchLedON(50);
			else
				SwitchLedON(25);
#endif
			memset(dbuf,' ',sizeof(dbuf));
#if(DD_ZIP==1 || DD_ZIP_21==1)
//			CopyFrStr(dbuf, DMes[17]);
//			WORDtoASC(dbuf + DISLEN-1, err);
//			PutsC(dbuf);
			Puts1(Msg[err].str);
#elif (DD_LCD_1601==1)
			PutsO(Msg[err].str);
#else
			CopyFrStr(dbuf, DMes[17]);
			WORDtoASC(dbuf + DISLEN-1, err);
			PutsO(dbuf);
#endif
            SetTimerDelay1(500);
			Bell(0);
			SETBIT(ApplVar.ErrorNumber,BIT7);
		}
	}
#if (DD_FISPRINTER)
	else
	{
		if (TestLED())
		{
			PutsO(Msg[SPACE].str);
			SwitchLedOFF();
		}
		LEDDelay = 20;// һ������,������ʾ���� //
	}
#endif

}

WORD RegiInit()
{
    if (ApplVar.FCanc)
		ApplVar.PrintLayOut &= ApplVar.CancPrint;
    if (!ApplVar.FRegi)   /* already in registration ? */
    {
		if (!ApplVar.ClerkNumber)
		{
		    ApplVar.ErrorNumber=ERROR_ID(CWXXI33);       /* select clerk */
		    return 1;
		}
		if (ApplVar.AP.SalPer.Number && !ApplVar.SalPerNumber)
		{
            // lyq added 2003\10\23 start
			if (!TESTBIT(KEYTONE, BIT6))
			{
				ApplVar.SalPerNumber = 1;
			}
			else// lyq added 2003\10\23 end
			{
			    ApplVar.ErrorNumber=ERROR_ID(CWXXI34);	    /* select salesperson */
			    return 1;
			}
		}
		ApplVar.SlipPage = 0;
		if (CheckSlip())
		    return 1;
		Now.sec = 0x61;     /*    force read of new time     */
		CheckTime(0x80);        /*    read correct time     */
		GetTimeZones();      /*    set up correct time, day, month     */
//ccr091027>>>>>>>>>>>>>>>>>>>>
		if (!(ApplVar.FPb && TESTBIT(PBINFO, BIT4)))
		{
		    AddReceiptNumber();
			ApplVar.SaleReceipts++;
		}
//<<<<<<<<<<<<<<<<<<<<<<<<<<<
		ApplVar.SaleAmt = ApplVar.SaleQty = ApplVar.SubTotal = ZERO;//ccr091125

		ApplVar.TendFlags = 0;
		MemSet(ApplVar.TaxItem, sizeof(ApplVar.TaxItem), 0);
		MemSet(ApplVar.DiscItem, sizeof(ApplVar.DiscItem), 0);
		ApplVar.CopyReceipt = ApplVar.RGNumber = 0;    /* reset trans buffer */
		if (ApplVar.AP.SalPer.Number)
		{
		    ApplVar.RGRec.Key.Code = SALPER + ApplVar.SalPerNumber;  /* store in buffer for correct CC update */
			StoreInBuffer();
		}
		ApplVar.RGRec.Key.Code = CLERK + ApplVar.ClerkNumber;
		ApplVar.FTend = 0;  /* reset incase post-tendering */
		ApplVar.FRegi = 1;

#if defined(FISCAL)    // liuj 0805
        if (!ApplVar.FPb)
    		Print_NonFiscal();//liuj 0601

		SETBIT(ApplVar.Fiscal_PrintFlag,BIT0);
#endif
		ApplVar.FNoTax = 0;
		SETBIT(ARROWS, BIT1);
#if(CASE_RAMBILL)
		Collect_Data(REGISLOG);
#endif
    }
    else if (ApplVar.FTend)  /* in tender ? */
    {
		ApplVar.ErrorNumber=ERROR_ID(CWXXI17);
		return 1;
    }
    else if (!ApplVar.SlipLines && CheckSlip())
		return 1;
    else if (ApplVar.FBuffer)       /* regi buffer full */
    {
		ApplVar.ErrorNumber=ERROR_ID(CWXXI15);
		return 1;
    }
    if (!ApplVar.FReceipt && !ApplVar.FInv)   /* receipt already used ? */
    {
		if (TESTBIT(ARROWS, BIT0) &&     /* receipt on ? */
		    TESTBIT(ApplVar.PrintLayOut, BIT1))
		{
			 	PrintHead1(PREHEADER);
#if defined(FISCAL)
			if(ApplVar.ZReport == 1)	//cc 20071102
				ApplVar.FisNumber.LastZDate = EncordDate(Now.year & 0xff, Now.month, Now.day);	//liuj0831
			ApplVar.ZReport = 0;    /* clear z report taken */
#if (!defined(CASE_MALTA))
			if(ApplVar.ClerkNumber != ApplVar.OldClerk) // 0526
				   FiscalHeader();
#endif
//ccr2014-08-07			ApplVar.FReceipt = 0;   //ccr2015-01-12:�����0,�����������һ�ʴ�ӡһ��Ʊͷ������
#endif
            if (!(CUTTER & 3) && !ApplVar.FRegi)
    			RFeed(1);
		}
    }
    return 0;
}
//���վ��ϴ�ӡtitle
WORD RegiStart()           /* registration start */
{
    BYTE saveprint;

    saveprint = ApplVar.PrintLayOut;
    ApplVar.PrintLayOut &= 0xfb;        /* skip double height */

#if defined(FISCAL)
	if(ApplVar.FisCardFlag == TESTFM)
	{
		ApplVar.ErrorNumber=ERROR_ID(CWXXI78) ;
		return 1;
	}
#endif
    if (RegiInit())
		return 1;
#if DD_MMC == 1
	SETBIT(ApplVar.ContFlag, ENSTORE);
	if(ApplVar.FTrain				//trainning mode?
#if defined(FISCAL)
		|| ApplVar.FisCardFlag == FMISNEW
#endif
		)			//new card
		ApplVar.EJContent = TXTCONT;

//	if(!saveFRegi )
//		SETBIT(ApplVar.ContFlag, ENHEADER);
#endif

    if (!ApplVar.FReceipt)
    {
    	if (ApplVar.FCanc == 1)
    	    PrintMessage(57);
    }
    if (ApplVar.AP.SalPer.Number && ApplVar.SalPerNumber != ApplVar.OldSalPer)    /* print salp when changed ? */
    {
		if (TESTBIT(ApplVar.SalPer.Options, BIT0))      /* double heigth ? */
			SETBIT(ApplVar.PrintLayOut, BIT2);
//		PrintStr(ApplVar.SalPer.Name);
	    ApplVar.PrintLayOut &= 0xfb;        /* reset double height */
		ApplVar.OldSalPer = ApplVar.SalPerNumber;
    }
    if (TESTBIT(CLERKFIX, BIT4) && ApplVar.ClerkNumber != ApplVar.OldClerk)    /* print clerk when changed ? */
    {
		if(TESTBIT(ApplVar.MyFlags, ENSLIPPB))
		{
			RESETBIT(ApplVar.MyFlags, ENSLIPPB);	 //lyq added for slip 20040324
			RESETBIT(ApplVar.PrintLayOut,BIT3);
		}
		if((ApplVar.FPb==0 && (ApplVar.PbF.Options & 0x0f) != 3) ||(ApplVar.PbF.Options & 0x0f) == 0  || ApplVar.PbNumber==0)
		{
			if ((ApplVar.Graph[0].PictNo>0 && ApplVar.Graph[0].PictNo<=GRAPHICMAX) && !TESTBIT(ApplVar.MyFlags, PRNONPB+ENPRINTER))
			{//=1ʱ��Ϊ�û��Զ���ͼƬ
				if (!TESTBIT(ApplVar.MyFlags, ENPRINTER))
					Bios(BiosCmd_PrintGraph, (void*)(ApplVar.Graph[0].PictNo), 1 , 0); //Stampa msg ram
		    	PrintLine('=');
			}
#if DD_FISPRINTER == 0
#if (defined(CASE_MALTA))
			if (ApplVar.CentralLock==RG || ApplVar.CentralLock==MG)
				PrintUserInput();

            if (!(CUTTER & 3))
                RFeed(1);
#else
            PrintStr(Prompt.Title);
#endif
		 	//PrintLine('='); //��Լֽ��
#endif
		}

		ApplVar.OldClerk = ApplVar.ClerkNumber;
    }
    ApplVar.PrintLayOut = saveprint;    /* restore print CONSTruction */
    return 0;
}

void PromotionBeep()
{
	short i;
	for (i=0;i<5;i++)
	{
		memset(ProgLineMes,'8',DISLEN+1);
		PutsO(ProgLineMes);
		Bell(1);
		Delay(ASECOND/2);
		memset(ProgLineMes,' ',DISLEN+1);
		PutsO(ProgLineMes);
		Delay(ASECOND/2);
	}
	memset(ProgLineMes,'8',DISLEN+1);
	PutsO(ProgLineMes);
}

void PromtionCheck()
{
	BCD	sVal1,sVal2;

	if (!TESTBIT(PROMOTION,BIT0))
	{
		sVal1 = ZERO;
		memcpy(sVal1.Value,ApplVar.AP.Promotion.JollyMin,sizeof(ApplVar.AP.Promotion.JollyMin));
	    if (CompareBCD(&ApplVar.SubTotal,&sVal1) >= 0)
		    ApplVar.PromCounter++;
	    if (ApplVar.PromCounter==ApplVar.AP.Promotion.Freq)
	    {
	    	if (ApplVar.AP.Promotion.GrapIdx>0 && !TESTBIT(ApplVar.MyFlags, ENPRINTER))
				Bios(BiosCmd_PrintGraph, (void*)(ApplVar.AP.Promotion.GrapIdx), 1 , 0); //Stampa msg ram
			RJPrint(0,ApplVar.AP.Promotion.Memo);
	    	ApplVar.PromCounter = 0;
	    	PromotionBeep();
	    }
    }
	if (!TESTBIT(PROMOTION,BIT1))
	{
		sVal1 = ZERO;
		memcpy(sVal1.Value,ApplVar.AP.Promotion.PointMin,sizeof(ApplVar.AP.Promotion.PointMin));
	    if (CompareBCD(&ApplVar.SubTotal,&sVal1) >= 0)
	    {
			sVal1 = ZERO;
			memcpy(sVal1.Value,ApplVar.AP.Promotion.PointVal,sizeof(ApplVar.AP.Promotion.PointVal));
			sVal2 = ApplVar.SubTotal;
			if (CheckNotZero(&sVal1))
			{
				Divide(&sVal2,&sVal1);
				SetBCDPoint(&sVal2,0);
				PrintRJ(FormatQtyStr(DMes[27], &sVal2, PRTLEN));

/*				if (CompareBCD(&sVal2,&TEN) >= 0)
				{
			    	if (ApplVar.AP.Promotion.GrapIdx>0 && !TESTBIT(ApplVar.MyFlags, ENPRINTER))
						Bios(BiosCmd_PrintGraph, ApplVar.AP.Promotion.GrapIdx-1, 0 , 0); //Stampa msg ram
					RJPrint(0,ApplVar.AP.Promotion.Memo);
			    	PromotionBeep();
		    	}*/
		    }
	    }
    }
}

void RegiEnd()
{

    if (PRICE_LEVEL & 0x02)       /* to zero at end of trans action ? */
		ApplVar.PluPriceLevel = 0;
    if ((ART_LEVEL & 0x03) == 2)         /* to zero at end of transaction ? */
		ApplVar.PluArtLevel = 0;
    ApplVar.TaxPerm = 0;            /* reset perm tax shift */
	ApplVar.FNFolio = 0;
    if (!ApplVar.FSale)   /* no sale then don't print total */
	{
		if (!ApplVar.PbNumber || (ApplVar.PbNumber && !TESTBIT(PBINFO, BIT3)))
		{
			return;
		}
	}
#if (defined(CASE_MALTA))
    if (!ApplVar.PbNumber || ApplVar.PBOpenFlag.bit.Confirm && (ApplVar.PBOpenFlag.bit.Print || ApplVar.PBOpenFlag.bit.FirstOpen))//ccr091208
   // CalculateTax(2);        /* only print and calculate tax */
	    CalculateTax(1);        /* not add in report and calculate add on tax */
#else
    if (!ApplVar.PbNumber || ApplVar.PBOpenFlag.bit.Confirm && (ApplVar.PBOpenFlag.bit.Print || ApplVar.PBOpenFlag.bit.FirstOpen))//ccr091208
	    CalculateTax(2);        /* only print and calculate tax */  //@@@@@@@@@@@@@@
#endif
    //PrintLine('-');//��Լֽ��
	if (!ApplVar.FPb) /* also when no check out function */
	{
		SETBIT(ApplVar.PrintLayOut, BIT2);  /* double size */
		ApplVar.SlipDouble = 1;
//#if (defined(CASE_MALTA))
	    Prefix1 = PREFIX_1;
		Prefix2 = PREFIX_2;
//#endif
		PrintAmt(Prompt.Caption[0], &ApplVar.SubTotal);	//ApplVar.Total
		RESETBIT(ApplVar.PrintLayOut, BIT2);  /* double size */
	}
}


void PrintTotal()
{
#if (defined(CASE_MALTA))
	Prefix1 = Prefix2 = 0;
#endif
    if (ApplVar.Size.Cc)
    {
		if (!SendComp(2, &ApplVar.Total.Cc))
		    PrintQty(Prompt.Caption[5], &ApplVar.Total.Cc);
    }
    if (ApplVar.Size.Qty)
    {
		if (!SendComp(3, &ApplVar.Total.Qty))
		    PrintQty(Prompt.Caption[6], &ApplVar.Total.Qty);
    }
    if (ApplVar.Size.RetQty)
    {
		if (!SendComp(4, &ApplVar.Total.RetQty))
		    PrintQty(Prompt.Caption[20], &ApplVar.Total.RetQty);
    }
    if (ApplVar.Size.Amt)
    {
		if (ApplVar.Report.Type == 10)       /* tax report ? */
		{
		    if (!SendComp(9, &ApplVar.Total.Amt))       /* taxable */
				PrintAmt(Prompt.Caption[26], &ApplVar.Total.Amt);
		}
		else if (ApplVar.Report.Type == 11 && (ApplVar.PbF.Options & 0x0f) == 10)       /* PB info report */
		{
		    if (!SendComp(3, &ApplVar.Total.Amt))
				PrintQty(Prompt.Caption[6], &ApplVar.Total.Amt);   /* and cover function ?*/
		}
		else if (!ApplVar.Size.Disc)
		{
		    if (ApplVar.Report.Type == 6)    /* drawer report */
		    {
//ccr2014-09-03				if (TESTBIT(ApplVar.Draw.Options, BIT1))
//ccr2014-09-03				{
//ccr2014-09-03				    if (!SendComp(3, &ApplVar.Total.Amt))
//ccr2014-09-03						PrintQty(Prompt.Caption[6], &ApplVar.Total.Amt);
//ccr2014-09-03				}
//ccr2014-09-03				else
                if (!SendComp(7, &ApplVar.Total.Amt))
				{
					if (TESTBIT(ApplVar.Draw.Options, BIT2))
						ApplVar.AmtDecimal = 2;
					else
						ApplVar.AmtDecimal = 0;
					ApplVar.AmtDecimal += ApplVar.Draw.Options & BIT0;
				    Prefix1 = 0;
				    Prefix2 = 0;    /* no prefix */
				    PrintAmt(Prompt.Caption[7], &ApplVar.Total.Amt);
				    ApplVar.AmtDecimal = NO_DECIMAL;
				    Prefix1 = PREFIX_1;
				    Prefix2 = PREFIX_2;
				}
		    }
		    else if (!SendComp(7, &ApplVar.Total.Amt))
				PrintAmt(Prompt.Caption[7], &ApplVar.Total.Amt);
		}
		else
		{
		    ApplVar.Amt = ApplVar.Total.Amt;
		    Subtract(&ApplVar.Amt, &ApplVar.Total.Disc);       /* calculate gross */
//lyq added 2003\10\27 start
			if(((ApplVar.Total.Amt.Sign & 0x80)==0) && ((ApplVar.Total.Disc.Sign & 0x80)!=0))
				ApplVar.Amt.Sign = ApplVar.Total.Amt.Sign;
		    if (!SendComp(5, &ApplVar.Amt))
				PrintAmt(Prompt.Caption[7], &ApplVar.Amt);
		}
		if (ApplVar.Report.Type == 9 && TESTBIT(ApplVar.Curr.Options, BIT2))   /* currency */
		{
		    GetCurrency(0, &ApplVar.Total.Amt);
		    if (!SendComp(7, &ApplVar.Total.Amt))
		    {
				ApplVar.AmtDecimal = ApplVar.Curr.Options & BIT0;
				Prefix1 = ApplVar.Curr.Prefix1;
				Prefix2 = ApplVar.Curr.Prefix2;
				PrintAmt(Prompt.Caption[7], &ApplVar.Total.Amt);
				ApplVar.AmtDecimal = NO_DECIMAL;
				Prefix1 = PREFIX_1;
				Prefix2 = PREFIX_2;
		    }
		}
    }
    if (ApplVar.Size.Disc)
    {
		if (!SendComp(6, &ApplVar.Total.Disc))
		    PrintAmt(Prompt.Caption[21], &ApplVar.Total.Disc);
		if (!SendComp(7, &ApplVar.Total.Amt))
		    PrintAmt(Prompt.Caption[3], &ApplVar.Total.Amt);
    }
    if (ApplVar.Size.Cost)
    {
		if (ApplVar.Report.Type == 10)
		{
			if (!SendComp(7, &ApplVar.Total.Disc))       /* NET tax report ? */
#if !defined(FISCAL)    // liuj 0805
			    PrintAmt(Prompt.Caption[46], &ApplVar.Total.Disc);
#else
			  	PrintAmt(Msg[XIAOSHOUA].str,&ApplVar.Total.Disc);	//liuj 0613
#endif
		    if (!SendComp(10, &ApplVar.Total.Cost))       /* tax report ? */
				PrintAmt(Prompt.Caption[27], &ApplVar.Total.Cost);
		}
/*
#if defined(FISCAL)
		else if (ApplVar.Report.Type == 7 || ApplVar.Report.Type == 8  )
		{
		    if (!SendComp(10, &ApplVar.Total.Cost))
				PrintAmt(Prompt.Caption[27], &ApplVar.Total.Cost);
		}
#endif
*/
		else
		{
			if (!SendComp(8, &ApplVar.Total.Cost))
			    PrintAmt(Prompt.Caption[22], &ApplVar.Total.Cost);
			ApplVar.Amt = ApplVar.Total.Amt;
			Subtract(&ApplVar.Amt, &ApplVar.Total.Cost);
			if (!SendComp(12, &ApplVar.Amt))
				PrintAmt(Prompt.Caption[35], &ApplVar.Amt);
		}
    }
#if (defined(CASE_MALTA))
	Prefix1 = PREFIX_1;
	Prefix2 = PREFIX_2;
#endif
}

//ccr 050301 ��ʾ��������>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> //
/* add corresponding totals */

void DisplayTotal()
{
	UnLong    save ;             /* unsigned long save;  */

    if (ApplVar.FTrain && ApplVar.PointerType != 1)
    {
   		RamOffSet += ApplVar.Size.Length; /* next period or total */
		return;         /* only add in clerk when training */
    }
    save = RamOffSet;      /* save OffSet for Writing */
    ReadTotal();
    RamOffSet = save;


//    SETBIT(ApplVar.Total.Qty.Sign, BIT2 + BIT3);   /* set bit 4 & 5 to indicate used */
//    WriteRam((BYTE *)&ApplVar.Total.Qty, ApplVar.Size.Qty + 1);
//    if (ApplVar.Size.Cc && BCDWidth(ApplVar.Total.Cc))
//   		PutsO(DispQtyStr("Cc", &ApplVar.Total.Cc));
    if (ApplVar.Size.Amt && BCDWidth(&ApplVar.Total.Amt))
   		PutsO(DispAmtStr("AMT", &ApplVar.Total.Amt,DISLEN));
//        if (ApplVar.Size.RetQty && BCDWidth(ApplVar.Total.RetQty))
//       		PutsO(DispQtyStr("ApplVar.Qty", &ApplVar.Total.RetQty));
//        if (ApplVar.Size.Disc && BCDWidth(ApplVar.Total.Disc))
//       		PutsO(DispAmtStr("ApplVar.Disc", &ApplVar.Total.Disc));
//        if (ApplVar.Size.Cost && BCDWidth(ApplVar.Total.Cost))
//       		PutsO(DispAmtStr("ApplVar.Cost", &ApplVar.Total.Cost));
}


void DisplayPointerTotal(char *sFile)
{
    WORD skip, next;

    if (ApplVar.FProforma)
		return;
    if (!ApplVar.Size.Periods)
		return;
    if (!ApplVar.Size.Length)     /* active ? */
		return;
    if (ApplVar.FSplit)
		return;             /* don't add when split bill */
    skip = 0;
    if (TESTBIT(ApplVar.Size.Periods, BIT0))      /* calculate size of 1 pointer */
		skip += ApplVar.Size.Length;
    if (TESTBIT(ApplVar.Size.Periods, BIT1))
		skip += ApplVar.Size.Length;
    if (TESTBIT(ApplVar.Size.Periods, BIT2))
		skip += ApplVar.Size.Length;
    if (TESTBIT(ApplVar.Size.Periods, BIT3))
		skip += ApplVar.Size.Length;
    next = skip;
    switch (ApplVar.PointerType)
    {
	case 0:
	    skip = 0;
	    next = 0;
	    break;
	case 1:         /* Clerks */
	    if (!ApplVar.AP.Clerk.Number)
			return;
	    next *= (ApplVar.AP.Clerk.Number - ApplVar.ClerkNumber);
	    skip *= (ApplVar.ClerkNumber - 1);
	    break;
	case 2:         /* Hour */
	    if (!ApplVar.AP.Zone.Number)
			return;
	    next *= (ApplVar.AP.Zone.Number - ApplVar.Zone - 1);
	    skip *= ApplVar.Zone;
	    break;
	case 3:         /* day of week */
	    if (!ApplVar.AP.Day.Number)
			return;
	    next *= (ApplVar.AP.Day.Number - ApplVar.Day - 1);
	    skip *= ApplVar.Day;
	    break;
	case 4:         /* ApplVar.Month of Year */
	    if (!ApplVar.AP.Month.Number)
			return;
	    next *= (ApplVar.AP.Month.Number - ApplVar.Month - 1);
	    skip *= ApplVar.Month;
	    break;
	case REPDEFMAX-1:
	    if (ApplVar.AP.SalPer.Number)
		{
			next *= (ApplVar.AP.SalPer.Number - ApplVar.SalPerNumber);
		    skip *= (ApplVar.SalPerNumber - 1);
		}
		break;
	default:
	    break;
    }
   	RamOffSet += skip;
    if (TESTBIT(ApplVar.Size.Periods, BIT0))
		DisplayTotal();
	else if (TESTBIT(ApplVar.Size.Periods, BIT1))
		DisplayTotal();
	else if (TESTBIT(ApplVar.Size.Periods, BIT2))
		DisplayTotal();
    else if (TESTBIT(ApplVar.Size.Periods, BIT3))
		DisplayTotal();
	RamOffSet += next;     /* start next pointer totals */
}
//ccr 050301 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< //

