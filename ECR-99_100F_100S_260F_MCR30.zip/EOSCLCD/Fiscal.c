#define FISCAL_C
#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
#include "fiscal.h"
#include "EJournal.h"
#include "message.h"
#if (PC_EMUKEY==1)
    #include "FEcrTest.h"
#endif

#define PRN_SHCP	0	// ī����汾 //
#define SHCP_S		28
#define SHCP_H		29
#define SHCP_C		30
#define SHCP_P		31


#if DD_MMC == 1
extern void  CheckEJ(void);
#endif
void FiscalTrailer(void);
short Fiscal_RecallData(void);
short Fiscal_AddResetData(void);
short Fiscal_AddFMPullData(void);


//ccr2014-PANAMA>>>>
const FSTRING USERPROMPT[cUSERMAX]={
    MESG_FCName ,//'Name:'	//1-�˿�����
    MESG_FCRUC	,//'RUC:'	//2-�˿�RUC,
    MESG_FCDebit,//'RNo:'	//3-�����վݺ�
    MESG_FCAddr ,//'Addr:'	//4-�˿͵�ַ
    MESG_FVatNo //'FNo:'   //5-��������վݵĹ˿�˰����
};
//<<<<PANAMA

/***************************************************************/
#if defined(FISCAL)
WORD    sStartZ, sEndZ;

//ccr2014-07-29>>>>>>>>>>>>>>
/**
 * ����FM��EJ�Ƿ����,������ʱ,��������
 *
 * @author EutronSoftware (2014-07-29)
 *
 * @return NONE
 */
void FM_EJ_Exist(void)
{
    if (ApplVar.FisCardFlag == NOFM || !Bios_FM_CheckPresence())
    {
        ApplVar.FMPullOut[NOFM_FLAG] = 0x69;//ccr071212
        ApplVar.FisCardFlag = NOFM;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI74);

        Save_Config(true);
        do
        {//ccr2014-07-29 block the ECR
            CheckError(0);
        }  while (1);//(!MMC_CheckPresence());
    }

#if DD_MMC == 1
    if (!MMC_CheckPresence())//ccr2014-07-29
//ccr2014-07-29             && (ApplVar.FisCardFlag==FISCALOK || ApplVar.FisCardFlag==FMISNEW || ApplVar.FisCardFlag==FM_X_EJ))//ֻ�е�����FISCALOKʱ,�ż��EJ�Ƿ����.
    {
        ApplVar.FisCardFlag = NOEJ;     // no EJ //
        ApplVar.ErrorNumber=ERROR_ID(CWXXI83);
        do
        {//ccr20140617 block the ECR
            CheckError(0);
        }  while (1);//(!MMC_CheckPresence());
    }
#endif
}
//<<<<<<<<<<<<<<<<
void    PrintFiscalAttribute(void)
{//ccr071212
    BCD sVal;

//    RFeed(1);
    PrintLine2('=');

    memset(SysBuf,' ',PRTLEN);
    CopyFrStr(SysBuf, Msg[FMPULLOUT].str);
    WORDtoASC(SysBuf+PRTLEN-1, FFMPULLMAX);
    WORDtoASC(SysBuf+PRTLEN-6, ApplVar.FisNumber.TotalFMNum);
    SysBuf[PRTLEN-4]='/';    SysBuf[PRTLEN]=0;
    RJPrint(0,SysBuf);


    memset(SysBuf,' ',PRTLEN);
    CopyFrStr(SysBuf, Msg[MACRESET].str);
    WORDtoASC(SysBuf+PRTLEN-1, FRESETMAX);
    WORDtoASC(SysBuf+PRTLEN-6, ApplVar.FisNumber.TotalResetNum);
    SysBuf[PRTLEN-4]='/';    SysBuf[PRTLEN]=0;
    RJPrint(0,SysBuf);


    memset(SysBuf,' ',PRTLEN);
    CopyFrStr(SysBuf, Msg[CHANGETAX].str);
    WORDtoASC(SysBuf+PRTLEN-1, FTAXCHGMAX);
    WORDtoASC(SysBuf+PRTLEN-6, ApplVar.FisNumber.TotalTaxChangeNum);
    SysBuf[PRTLEN-4]='/';    SysBuf[PRTLEN]=0;
    RJPrint(0,SysBuf);


    memset(SysBuf,' ',PRTLEN);
    CopyFrStr(SysBuf, Msg[CHANGEHEAD].str);
    WORDtoASC(SysBuf+PRTLEN-1, FHEADCHGMAX);
    WORDtoASC(SysBuf+PRTLEN-6, ApplVar.FisNumber.TotalHeadChangeNum);
    SysBuf[PRTLEN-4]='/';    SysBuf[PRTLEN]=0;
    RJPrint(0,SysBuf);

    memset(SysBuf,' ',PRTLEN);
    CopyFrStr(SysBuf, MESG_Z_REMAIN);
    WORDtoASC(SysBuf+PRTLEN-1, (FISMEMERYSIZE-ApplVar.FiscalHead.MaxP)/FISRECORDLEN);
    SysBuf[PRTLEN] = 0;
    RJPrint(0, SysBuf);

    PrintLine2('=');
}


void EncodeTimeFiscal(BYTE* pD0,char toTime[])
{
    toTime[0] = ((pD0[0] >> 4) & 0x0f) + '0';
    toTime[1] = (pD0[0] & 0x0f) + '0';
    toTime[2] = ':';
    toTime[3] = ((pD0[1] >> 4) & 0x0f) + '0';
    toTime[4] = (pD0[1] & 0x0f) + '0';
    toTime[5] = ':';
    toTime[6] = ((pD0[2] >> 4) & 0x0f) + '0';
    toTime[7] = (pD0[2] & 0x0f) + '0';
}
#endif
/**
 * ��ӡ��Ϣ:��StrMess׷����strType֮���ӡ
 * strType����,  StrMess����
 * @author EutronSoftware (2014-07-21)
 *
 * @param strType :��ӡ����������
 * @param StrMess :��Ҫ��ӡ����Ϣ
 * @param width :StrMess�Ŀ���,<PRTLEN
 */
void PrintMessagesBy(char *strType,char *StrMess,int width)
{
    char pBuf[PRTLEN+1];
    int  i=strlen(strType);

    if (width>PRTLEN) width = PRTLEN;
    if (i>PRTLEN) i = PRTLEN;

    memset(pBuf,' ',PRTLEN);
    memcpy(pBuf,strType,i);
    i = strlen(StrMess);
    if (i>width) i=width;
    memcpy(pBuf+PRTLEN-i,StrMess,i);
    pBuf[PRTLEN]=0;
    RJPrint(0,pBuf);//��ӡ�����˰����
}
//ccr091027>>>>>>>>>>>>>>>>>>>>>>>>>
void AddReceiptNumber()
{
#if defined(FISCAL)
    ApplVar.SaleQty = ZERO;
//liuj 0531 PM
//	if(Bios_FM_Read(&ApplVar.Fis_Header, FISHEADERADDR, sizeof(ApplVar.Fis_Header)) && ApplVar.Fis_Header.FFlag != FMINITEDFLAG)
//		ApplVar.FStatus = 0;
    if ( ApplVar.FTrain  )
    {// ��ѵ�վݺ� //
        ApplVar.FisNumber.ReceiptNum[TRECEIPTS]++;
        ApplVar.FisNumber.TotalReceiptNum[TRECEIPTS]++;
    }
#if (DD_FISPRINTER==0)
    else if (!ApplVar.FStatus || ApplVar.FInv)
    {// ��˰�վݺ� //
        ApplVar.FisNumber.ReceiptNum[NRECEIPTS]++;
        ApplVar.FisNumber.TotalReceiptNum[NRECEIPTS]++;
    }
    else
    {// ��˰�վݺ� //
        ApplVar.FisNumber.ReceiptNum[FRECEIPTS]++;
        ApplVar.FisNumber.TotalReceiptNum[FRECEIPTS]++;
    }
#else
    else if (ApplVar.FStatus || TESTBIT(ApplVar.Fiscal_Status,FISCALDOC))
    {
        ApplVar.FisNumber.ReceiptNum[FRECEIPTS]++;
        ApplVar.FisNumber.TotalReceiptNum[FRECEIPTS]++;
        i = 3;  // ��˰�վݺ� //
    }
    else
    {// ��˰�վݺ� //
        ApplVar.FisNumber.ReceiptNum[NRECEIPTS]++;
        ApplVar.FisNumber.TotalReceiptNum[NRECEIPTS]++;
    }
#endif
#else
    if (!ApplVar.FInv && ApplVar.FCanc != 2 && !ApplVar.FProforma)
    {
        if (ApplVar.FTrain)
            ApplVar.FisNumber.ReceiptNum[TRECEIPTS]++;
        else
            ApplVar.FisNumber.ReceiptNum[FRECEIPTS]++;
    }
#endif
}
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//Get the index of clerk and convert it into ascii string for print.
void GetReceiptNumber(char *to)
{

#if defined(FISCAL)
#if defined(CASE_ITALIA)//ccr2014-09-15>>>>>>>>>
    //��ӡZ������,Fiscal/None Fiscal�վݺŴ�1��ʼ
    if ( ApplVar.FTrain )   //  PenGH 2008-11-27
    {
        sprintf(to,"SCONTRINO TRAIN N.%lu",ApplVar.FisNumber.ReceiptNum[TRECEIPTS]);/* ccr091027 is in fiscal training */
    }
#if (DD_FISPRINTER==0)
    else if (!ApplVar.FStatus || ApplVar.FInv)
    {
        sprintf(to,"SCONTRINO NON FISCALE N.%lu",ApplVar.FisNumber.ReceiptNum[NRECEIPTS]);/* ccr091027 is none fiscal  */
    }
    else
    {
        sprintf(to,"SCONTRINO FISCALE N.%lu",ApplVar.FisNumber.ReceiptNum[FRECEIPTS]);/* ccr091027 is in  fiscal  */
    }

#else
    else if (ApplVar.FStatus || TESTBIT(ApplVar.Fiscal_Status, FISCALDOC))
    {
#if (VV_RUSSIA)
        *to = 212;  // Fiscal flag for RUSSIA
#else
        *to = 'F';
#endif
        sprintf(to+1,"%.8lu",ApplVar.FisNumber.ReceiptNum[FRECEIPTS]);/* ccr091027 is none fiscal  */
    }
    else// if (!ApplVar.FStatus || ApplVar.FInv || !TESTBIT(ApplVar.Fiscal_Status, FISCALDOC))
    {
#if (VV_RUSSIA)
        *to = 205;  // None Fiscal flag for RUSSIA
#else
        *to = 'N';
#endif
        sprintf(to+1,"%.8lu",ApplVar.FisNumber.ReceiptNum[NRECEIPTS]);/* ccr091027 is none fiscal  */
    }
#endif

#else//ccr2014-09-15-----------------------------------------------------------------------------

    if ( ApplVar.FTrain )   //  PenGH 2008-11-27
    {
        sprintf(to,"#%.8lu",ApplVar.FisNumber.TotalReceiptNum[TRECEIPTS]);/* ccr091027 is in fiscal training */
    }
#if (DD_FISPRINTER==0)
    else if (!ApplVar.FStatus || ApplVar.FInv)
    {
        sprintf(to,"N%.8lu",ApplVar.FisNumber.TotalReceiptNum[NRECEIPTS]);/* ccr091027 is none fiscal  */
    }
    else
    {
        sprintf(to,"F%.8lu",ApplVar.FisNumber.TotalReceiptNum[FRECEIPTS]);/* ccr091027 is in  fiscal  */
    }

#else
    else if (ApplVar.FStatus || TESTBIT(ApplVar.Fiscal_Status, FISCALDOC))
    {
#if (VV_RUSSIA)
        *to = 212;  // Fiscal flag for RUSSIA
#else
        *to = 'F';
#endif
        sprintf(to+1,"%.8lu",ApplVar.FisNumber.TotalReceiptNum[FRECEIPTS]);/* ccr091027 is none fiscal  */
    }
    else// if (!ApplVar.FStatus || ApplVar.FInv || !TESTBIT(ApplVar.Fiscal_Status, FISCALDOC))
    {
#if (VV_RUSSIA)
        *to = 205;  // None Fiscal flag for RUSSIA
#else
        *to = 'N';
#endif
        sprintf(to+1,"%.8lu",ApplVar.FisNumber.TotalReceiptNum[NRECEIPTS]);/* ccr091027 is none fiscal  */
    }
#endif
#endif//ccr2014-09-15<<<<<<<
    ApplVar.LastInvoiceDate = EncordDate((WORD)(Now.year & 0x00ff), (WORD)Now.month, (WORD)Now.day);      //last invoice date		20070118
    ApplVar.LastInvoiceTime[0] = Now.hour;      //last invoice time		20070118
    ApplVar.LastInvoiceTime[1] = Now.min;
    ApplVar.LastInvoiceTime[2] = Now.sec;

#else
    {
        if ((CHARSET & 0xf0) == 0x10 || (SLIP != 4 && ((CHARSET & 0x0f) == 3 || (CHARSET & 0x0f) == 7)))  /* number sign not available */
            *to = 'N';
        else
            *to = '#';
//ccr091027>>>>>>>>
        if (ApplVar.FTrain)
            sprintf(to+1,"%.8lu",ApplVar.FisNumber.TotalReceiptNum[TRECEIPTS]);/* ccr091027 is train  */
        else
            sprintf(to+1,"%.8lu",ApplVar.FisNumber.TotalReceiptNum[FRECEIPTS]);/* ccr091027 is fiscal  */
/* ccr091027
        if (TESTBIT(KPPRICE, BIT7))
            CWORD(to[1])=CWORD(sbuf[4]);
        else
        {
            CWORD(to[1])=CWORD(sbuf[1]);
            CWORD(to[3])=CWORD(sbuf[3]);
            to[5]=sbuf[5];
        }
*/
//<<<<<<<<<<<<<<<<<
    }
#endif
}

#if defined(FISCAL)
BYTE VerifyCRC(BYTE *Area,short pLen,short EnCode)
{
    BYTE sCRC;
    short i;

    sCRC = 0;
    for (i=0;i<pLen-2;i++)
        sCRC ^= Area[i];

    if (EnCode)
        return(sCRC + 1);
    else if ((sCRC+1) == Area[pLen-2])
        return 1;

    return 0;
}

/***************************************************************/
BYTE Read_FiscalRam(VOIDFAR *Dest, UnLong SrcAdr, WORD Num)
{
    if (ApplVar.FisCardFlag == NOFM)
        return 0;

    if (Bios_FM_Read(Dest,SrcAdr,Num))
        return 1;

    ApplVar.FisCardFlag = FMERROR;
#if DD_FISPRINTER

    SETBIT(ApplVar.Fiscal_Status, FM_ERR);

#endif
    return 0;
}

BYTE Write_FiscalRam(UnLong DestAdr, VOIDFAR *Src, WORD Num)
{
    if (ApplVar.FisCardFlag == NOFM)
        return 0;


    if (ApplVar.FTrain)
        return 0;

    if (DestAdr > FISDATAADDR)
    {
        if (DestAdr>= FISMEMERYSIZE - FISRECORDLEN)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI86);ApplVar.FisCardFlag = FMFULL;
#if DD_FISPRINTER
            SETBIT(ApplVar.Fiscal_Status, FM_FULL);
#endif
            return 1;
        }
        else if (DestAdr>=(FISMEMERYSIZE - FISMEMERYFULLSIZE_LESS))//ccr091104
        {
            ApplVar.FisCardFlag = FMFULL;ApplVar.ErrorNumber=ERROR_ID(CWXXI86);     // FM FULL

#if DD_FISPRINTER
            SETBIT(ApplVar.Fiscal_Status, FM_FULL);
#endif

        }
        else if (DestAdr>=(FISMEMERYSIZE - ( FISMEMERYFULLSIZE_LESS*10))
                 && DestAdr<(FISMEMERYSIZE - (FISMEMERYFULLSIZE_LESS*10)+Num))//ccr091104
        {
//			ApplVar.ErrorNumber=ERROR_ID(CWXXI77);		//ccr091104 low FM
            ApplVar.FisCardFlag = FMLESS;
#if DD_FISPRINTER
            SETBIT(ApplVar.Fiscal_Status, FM_100);
#endif

        }
    }

    if (Bios_FM_Write(DestAdr,Src,Num))
    {
        return 1;
    }
#if DD_FISPRINTER
    SETBIT(ApplVar.Fiscal_Status, FM_ERR);
#endif

    ApplVar.FisCardFlag = BADFM;
    ApplVar.ErrorNumber=ERROR_ID(CWXXI76);
    return 0;
}
#endif
//--------------------------------------------------------------
//20070313 VZLA format >>>>>>>>>>>>>>>>>>>>>>
void PrintReceiptNum()
{
    //print date time
    memset(SysBuf,' ', sizeof(SysBuf));
    DateTimeToStr(SysBuf,0);

    //AddReceiptNumber();	//

    if (((SLIPINFO & (BIT1+BIT2)) != BIT1+BIT2) ||
        (COMMA & (BIT3+BIT6+BIT7)) != (BIT3+BIT6+BIT7))  // print something //
    {
        SysBuf[PRTLEN] = 0;
        PrintStr(SysBuf);

/* #if (!(PRTLEN<25))
        memset(SysBuf,' ', sizeof(SysBuf));
        if (!TESTBIT(COMMA, BIT3))         // print receipt number ? //
            GetReceiptNumber(SysBuf);
#endif
        if (TESTBIT(COMMA, BIT2))          // double heigth ? //
            SETBIT(ApplVar.PrintLayOut, BIT2);
        SysBuf[PRTLEN] = 0;
        PrintStr(SysBuf);
        RESETBIT(ApplVar.PrintLayOut, BIT2);	*/
//liuj debug
/*		GetReceiptNumber(TRUE);
        if (TESTBIT(COMMA, BIT2))          // double heigth ? //
            SETBIT(ApplVar.PrintLayOut, BIT2);
        if(SysBuf[0])
            PrintStr(SysBuf);
        GetReceiptNumber(FALSE);
        if(SysBuf[0])
            PrintStr(SysBuf);*/
        RESETBIT(ApplVar.PrintLayOut, BIT2);
        if (TESTBIT(SLIPINFO, BIT3) && (ApplVar.Key.Code>PORA + 100 && ApplVar.Key.Code < TEND + 100))     // print on slip ? // // lyq added for slip  start 20040324 //
        {
            SlipMargin();
            PrintSlip(SysBuf);
            //RESETBIT(ApplVar.MyFlags, ENSLIPPB);	 //lyq added for slip 20040324
        }   // lyq added for slip end 20040324 //
    }
    RFeed(1);
}

void Print_NonFiscal()
{
#if defined(FISCAL)

    if (!ApplVar.FStatus || ApplVar.FTrain)   //cc 20071026
    {
        RFeed(1);
        PrintLine2('=');
        PrintStr_Center((char *)Msg[NONFISCAL].str,true);
        PrintLine2('=');
        RFeed(1);
    }
#endif
}


#if defined(FISCAL)

void PrintAgain()
{
    WORD saveclerk ;
    BYTE SaveRGNumber,saveCp, SaveSP,SavePrintLayOut;

    if (ApplVar.RGNumber && TESTBIT(ApplVar.Fiscal_PrintFlag,(BIT0 | BIT1)))
    {
        if (!TESTBIT(ApplVar.Fiscal_PrintFlag,BIT1))
        {
//			PCBuffer[0] = ApplVar.Fiscal_PrintFlag;
//			PrnBuffer(PCBuffer,1);
            StoreInBuffer();

#if DD_MMC == 1
            ApplVar.EJContent = ENDCONT;        //liuj 0528
            memset(SysBuf,' ',PRTLEN);
#if (RIFMUST)//PANAMA
            strcpy(SysBuf, Msg[RIFCODE].str);
            strcat(SysBuf, ApplVar.Fis_Header.FRIFNumber);
            saveclerk =strlen(SysBuf);
            SysBuf[saveclerk]=' ';
#elif (DEVICEMUST)//PANAMA
            strcpy(SysBuf, DEVICECODE, strlen(DEVICECODE));
            strcat(SysBuf, ApplVar.Fis_Header.FDeviceCode);
            saveclerk =strlen(SysBuf);
            SysBuf[saveclerk]=' ';
#endif
            sprintf(SysBuf+PRTLEN-9,"E%.8lu",ApplVar.EJLogHeader.DocNumber_EJ);//ccr091103
            RJPrint(0, SysBuf);     //liuj 0528

#if (RIFMUST && DEVICEMUST)//PANAMA
            memset(SysBuf, ' ', sizeof(SysBuf));
            memcpy(SysBuf, DEVICECODE, strlen(DEVICECODE));
            strcpy(SysBuf+PRTLEN-strlen(ApplVar.Fis_Header.FDeviceCode), ApplVar.Fis_Header.FDeviceCode);
            SysBuf[PRTLEN] = 0;
            RJPrint(0, SysBuf);
#endif

#else //DD_MMC == 1

#if (RIFMUST)//PANAMA
            memset(SysBuf, ' ', sizeof(SysBuf));
            memcpy(SysBuf, Msg[RIFCODE].str, strlen(Msg[RIFCODE].str));
            strcpy(SysBuf+PRTLEN-strlen(ApplVar.Fis_Header.FRIFNumber), ApplVar.Fis_Header.FRIFNumber);
            SysBuf[PRTLEN] = 0;
            RJPrint(0, SysBuf);
#endif
#if (DEVICEMUST)//PANAMA
            memset(SysBuf, ' ', sizeof(SysBuf));
            memcpy(SysBuf, DEVICECODE, strlen(DEVICECODE));
            strcpy(SysBuf+PRTLEN-strlen(ApplVar.Fis_Header.FDeviceCode), ApplVar.Fis_Header.FDeviceCode);
            SysBuf[PRTLEN] = 0;
            RJPrint(0, SysBuf);
#endif
#endif


//liuj 0528

            RFeed(10);
#if DD_MMC == 1

            ApplVar.EJContent = REGICONT ;      //liuj 0603
            SETBIT(ApplVar.ContFlag, (ENSTORE|ENHEADER));       //liuj 0603
#endif
            PrintHead1(0);
        }
        RFeed(1);
        saveCp = ApplVar.CopyReceipt+1;
        saveclerk = ApplVar.ClerkNumber ;
        SaveSP = SLIP;
        SLIP = 0;
        ApplVar.BufRec = 1;
        SaveRGNumber = ApplVar.RGNumber;
#if DD_MMC == 1  //liuj 0528
//		ApplVar.EJContent = REGICONT ;		//20070118
//		SETBIT(ApplVar.ContFlag, (ENSTORE|ENHEADER));		//20070118

        RJPrint(0, "**COPY RECEIPT FOR PAPER OUT!!**");

#endif
        ProcessBuffer();    /* second receipt */
        ApplVar.RGNumber = SaveRGNumber;
        ApplVar.ClerkNumber = saveclerk ;
        ApplVar.CopyReceipt = saveCp;
        SLIP = SaveSP;

        ApplVar.Fiscal_PrintFlag = 0;
        ApplVar.OldClerk = ApplVar.ClerkNumber; //  /* force clerk not  print start transaction */

    }
//cc 20070524>>>>>>>>>>>>>>>>
}


//ccr070424>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
void AddBcdWithLong(BCD* addTo,long addFr)
{
    BCD sVal;

    if (addFr)//ccr070424
    {
        LongToBCD(&sVal, addFr);
        Add(addTo,&sVal);
    }
}
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

void DecordDateFiscal(WORD pD0,char toDate[])
{
    WORD  sYear, sDay, sMonth;
    memset(toDate,' ',10);

    sYear = (pD0 >> 9) + 2000;
    sMonth = (pD0 >> 5) & 0x0f;
    sDay = pD0 & 0x1f;

    if (sMonth<1 || sMonth>12)
        sMonth = 1;
    if (sDay<1 || sDay>31)
        sDay=1;

/*	WORDtoASC(toDate+3, sYear);
    WORDtoASC(toDate+6, sMonth);
    WORDtoASC(toDate+9, sDay);

    if (toDate[5]==' ')
        toDate[5]='0';
    if (toDate[8]==' ')
        toDate[8]='0';
    toDate[4]=toDate[7]='-';
    toDate[10] = 0;	*/

    switch (TIME_DATE)
    {
    case 1:/*"Mon,MM-DD-YYYY" */
        WORDtoASC(toDate+9, sYear);
        WORDtoASC(toDate+1, sMonth);
        WORDtoASC(toDate+4, sDay);

        if (toDate[0]==' ')
            toDate[0]='0';
        if (toDate[3]==' ')
            toDate[3]='0';
        toDate[2]=toDate[5]=DATECHAR;
        toDate[10] = 0;
        break;
    case 2:/*"Mon,YYYY-MM-DD" */
        WORDtoASC(toDate+3, sYear);
        WORDtoASC(toDate+6, sMonth);
        WORDtoASC(toDate+9, sDay);

        if (toDate[5]==' ')
            toDate[5]='0';
        if (toDate[8]==' ')
            toDate[8]='0';
        toDate[4]=toDate[7]=DATECHAR;
        toDate[10] = 0;
        break;
    default:/*"Mon,DD-MM-YYYY" */
        WORDtoASC(toDate+9, sYear);
        WORDtoASC(toDate+4, sMonth);
        WORDtoASC(toDate+1, sDay);

        if (toDate[0]==' ')
            toDate[0]='0';
        if (toDate[3]==' ')
            toDate[3]='0';
        toDate[2]=toDate[5]=DATECHAR;
        toDate[10] = 0;
        break;
    }
}

//write produced date to fiscal card
void ProducedDate()
{
    short i;


//ccr070531>>>>>>>>>>>>>>>>>>>>>
    memset(&ApplVar.FiscalHead,0,sizeof(ApplVar.FiscalHead));
    memset(&ApplVar.FisNumber,0,sizeof(ApplVar.FisNumber));
    ApplVar.ZCount[REPZNUM]= ApplVar.ZCount[TRAINNUM]=1;//ccr091027

    ApplVar.FisNumber.TotalClearNum = 1; // liuj 0526

    ApplVar.FiscalHead.MaxP = FISDATAADDR;
    ApplVar.FiscalHead.EJTblP =  FISEJADDR ;
    ApplVar.FiscalHead.ReadP = FISDATAADDR;
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    memset(&ApplVar.Fis_Header,0xff, sizeof(ApplVar.Fis_Header));
    memcpy(&ApplVar.Fis_Header.FFirst,FirmCode,16);
    GetTimeDate(&Now);
    ApplVar.Fis_Header.FPFirst[0] = (Now.year & 0xff);      /* YY */
    ApplVar.Fis_Header.FPFirst[1] = Now.month;              /* MM */
    ApplVar.Fis_Header.FPFirst[2] = Now.day;                /* DD */
    ApplVar.Fis_Header.FPFirst[3] = Now.hour;               /* HH */
    ApplVar.Fis_Header.FPFirst[4] = Now.min;                /* MM */
    ApplVar.Fis_Header.FPFirst[5] = Now.sec;                /* SS */


    if (!Bios_FM_Write(FISHEADERADDR,
                       &ApplVar.Fis_Header.FFirst,
                       sizeof(ApplVar.Fis_Header.FFirst) +
                       sizeof(ApplVar.Fis_Header.FPFirst)))
    {
        ApplVar.FisCardFlag = BADFM;    //20070302 FISINVALID;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI76);     /* write fiscal date error */
    }
    else
    {
#if (DD_MMC)
        memset(&ApplVar.EJLogHeader,0,HEADSIZE);//ccr20140617
#endif
        ApplVar.FisCardFlag = FMISNEW;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI94);
    }
}

//���˰�ػ���״̬(�Ƿ������˰�س�ʼ��
//ecrUsed��ʾ�տ���Ƿ�ʹ�ù���ʹ�ù����տ�������˰�ش洢���лָ�����
void CheckFiscal(bool ecrUsed)
{
    struct FIS_HEADER temphead;
    BYTE sFlag,sTp;


    if (ApplVar.FisCardFlag == NOFM || !Bios_FM_CheckPresence()) //ccr070719
    {
        ApplVar.FMPullOut[NOFM_FLAG] = 0x69;//ccr071212
        ApplVar.FisCardFlag = NOFM;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI74);//ccr070719

        Save_Config(true);
        return;
    }
    else if (!ecrUsed)// It is reset by MAC
    {
        if (!Read_FiscalRam(&ApplVar.Fis_Header, FISHEADERADDR, sizeof(ApplVar.Fis_Header)))
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI76);     /* write fiscal date error */
            return;
        }
        memcpy(&temphead,&ApplVar.Fis_Header, sizeof(ApplVar.Fis_Header));
    }
    else if (!ApplVar.FRegi && ApplVar.ZReport == 2)     /* check if day changed when not in transaction */
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI75);       /* first take fiscal Z-ApplVar.Report */
        return;
    }

    if (!ecrUsed || Read_FiscalRam(&temphead,FISHEADERADDR,sizeof(temphead)))
    {
        memcpy(PCBuffer,FMSetCard, 16);     // liuj 0601
        if (CompareBCDValue(temphead.FFirst,(BYTE*)PCBuffer, 16) == 0)       // is test FM
        {
            if (!ecrUsed)  // init
                ApplVar.FisCardFlag = TESTFM;
            else
                ApplVar.FisCardFlag = FMERROR;
            return;
        }

/*
            if(temphead.FCRC != ApplVar.Fis_Header.FCRC && MACSwitch==FALSE)  // the code check sum is changed
            {
                ApplVar.FisCardFlag = CHECKSUMCHANGED;

                return ;
            }*/

        for (sTp=0,sFlag=0;sTp < 16;sTp++)
        {
            if (temphead.FFirst[sTp] == 0xff)
            {
                sFlag ++;
                continue;
            }
            else if (temphead.FFirst[sTp] != (BYTE)FirmCode[sTp])
            {
                ApplVar.FisCardFlag = BADFM;//˰�ش洢���쳣
                ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
                return ;
            }

        }

        if (sFlag == 16 )
        {//New FM card,Ϊ�»���,δ����˰�س�ʼ��
            ProducedDate();
            return;
        }
        if (temphead.FFlag == FMINITEDFLAG)      // the FM init success
        {
            if (!ecrUsed || //ccr070531
                strcmp(temphead.FFisCode,ApplVar.Fis_Header.FFisCode)==0
#if (DD_FISPRINTER || RIFMUST) // liuj 0806
                &&    strcmp(temphead.FRIFNumber,ApplVar.Fis_Header.FRIFNumber)==0
#endif
               )
            {
                //ccr2014-PANAMA>>>>
                for (sTp=sFlag=0;sTp < sizeof(ApplVar.Fis_Header.FFisCode);sTp++)
                {
                    if (ApplVar.Fis_Header.FFisCode[sTp] == 0xff)
                        sFlag++;
                }

                if (sFlag == sizeof(ApplVar.Fis_Header.FFisCode) )
                {//����δ����˰�س�ʼ��
                    ApplVar.FisCardFlag = FMISNEW;
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI94);
#if DD_MMC
                    memset(&ApplVar.EJLogHeader,0,HEADSIZE);//ccr20140617
#endif
                    return;
                }
                if (sFlag)
                {
                    ApplVar.FisCardFlag = BADFM;//˰�ش洢���쳣
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
                    return;
                }

                //<<<<PANAMA

                sTp = ApplVar.FisCardFlag;//ccr091105
                ApplVar.FisCardFlag = FISCALOK;
                if (!ecrUsed)
                {//Fiscal initialize finished
                    if (!Fiscal_RecallData() || !Fiscal_AddResetData())//ccr070719
                    {
#if DD_MMC
                        if (ApplVar.FisCardFlag == FMFULL || ApplVar.FisCardFlag == FMMACFULL)
                        {//ccr091203>>>>>FMFULL��,���Բ�ѯEJ�ϵ�����
                            sFlag = ApplVar.FisCardFlag;
                            sTp = ApplVar.ErrorNumber;
                            ApplVar.ErrorNumber=0;//ccr091105
                            ApplVar.FisCardFlag = FISCALOK;
                            CheckEJ();      // check EJ
                            ApplVar.FisCardFlag = sFlag;
                            ApplVar.ErrorNumber = sTp;
                        }//<<<<<<<<<<<<<<<<<<<<<
#endif
                        return ;
                    }

                }

                if (ApplVar.FisNumber.TotalResetNum > FRESETMAX)
                {
                    ApplVar.FisCardFlag = FMMACFULL;
                    return ;
                }


                if (ApplVar.FisNumber.TotalFMNum>FFMPULLMAX)//ccr071212
                {
                    ApplVar.FisCardFlag = FMERROR;
                    return;
                }

                if (ApplVar.FisCardFlag == FISCALOK)
                {//ccr2014-08-07>>>>
                    if (ApplVar.FMPullOut[NOFM_FLAG]==0x69)
                    {
                        ApplVar.FMPullOut[NOFM_FLAG] = 0;
                        Fiscal_AddFMPullData();
                    }
                    ProcessTax(true);//����ػ�ǰû�б������˰�ʺ���Ʊͷ
                    ProcessHead(false);
                }//<<<<<<<<<<<<<<<<<<<<<<

                if (ApplVar.FiscalHead.MaxP >= (FISMEMERYSIZE - FISMEMERYFULLSIZE_LESS))
                {
                    ApplVar.FisCardFlag = FMFULL;
                    return ;
                }
#if DD_MMC
                else if (ApplVar.FisNumber.TotalEJNum >= FEJTBLMAX)
                {
                    ApplVar.FisCardFlag = EJFULL;
                    return ;
                }
                ApplVar.ErrorNumber=0;//ccr091105
                CheckEJ();      // check EJ
				//ccr20140630!!!!>>>>
                if (ApplVar.FisCardFlag != FISCALOK && ApplVar.FisCardFlag != MUSTINITEJ)    //cc 20071012
                    return ;
                else//<<<<<<<<<<<
                    if (ApplVar.FisCardFlag != MUSTINITEJ && sTp==BADEJ)
                    ApplVar.FisCardFlag = sTp;
#endif
            }
            else        // not the FM for this ECR
            {
                ApplVar.FisCardFlag = FM_X_ECR;

                return ;
            }
        }
        else
        {
            if (temphead.FFlag == 0xff)
            {
#if (DD_MMC)
	          	memset(&ApplVar.EJLogHeader,0,HEADSIZE);//ccr20140617
#endif
                ApplVar.FisCardFlag = FMISNEW;          // the FM have not init
            }
            else
            {
                ApplVar.FisCardFlag = BADFM;
                ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
            }
            return ;
        }

    }
    return ;
}
/**
 * ��ӡ��ѯ��Z������������
 * @author EutronSoftware (2014-07-25)
 */
void Print_FiscalTotal()
{
    int i;
    BCD sVal;
    BCD sTotalSale, sTotalTax;//ccr070424

#if (defined(CASE_MALTA))
    Prefix1 = Prefix2 = 0;
#endif
    PrintRJ(Msg[PRNTOTAL].str);

    //20070313	print Z counter
    //memset(&sVal,0,sizeof(BCD));
    //WORDtoBCD(sVal.Value,ApplVar.FiscalTotal.FClearCount);
    //RJPrint(0,FormatQtyStr(Msg[CLEARTOTAL].str,&sVal,PRTLEN));
    memset(SysBuf, ' ', sizeof(SysBuf));
    CopyFrStr(SysBuf, Msg[CLEARTOTAL].str);
    WORDtoASCZero(SysBuf+PRTLEN-1, ApplVar.FiscalTotal.FClearCount);
    SysBuf[PRTLEN] = 0;
    RJPrint(0, SysBuf);

//hf 20070118 >>>>>>>>>>>>>>>>>>>
    //TAX-EXEMPT
    PrintAmt(Msg[MIANSHUI].str,&ApplVar.FiscalTotal.NoTaxSale); //ccr070424

    //TAX SALE
//ccr20140725 һ����Ʒ�ж��ּ�˰ʱ����������    sTotalSale = ZERO;

    sTotalTax = ZERO;
    for (i=0;i<ApplVar.AP.Tax.Number;i++)
    {
/*ccr20140725 һ����Ʒ�ж��ּ�˰ʱ����������>>>>>>>>>>>>>
        if (CheckNotZero(&ApplVar.FiscalTotal.FTaxSale[i]))
        {//TAX SALE
            Add(&sTotalSale, &ApplVar.FiscalTotal.FTaxSale[i]);//ccr070424
        }
<<<<<<<<<<<<<<<<<<<*/

        if (CheckNotZero(&ApplVar.FiscalTotal.FTaxAmt[i]))
        {//TAX AMT
            Add(&sTotalTax, &ApplVar.FiscalTotal.FTaxAmt[i]);//ccr070424
            RJPrint(0,FormatAmtStr(Msg[VATA+i].str,&ApplVar.FiscalTotal.FTaxAmt[i],PRTLEN));//ccr070424
        }
    }


    //TAX AMT TOTAL
    RJPrint(0,FormatAmtStr(Msg[TAXTOTAL].str,&sTotalTax,PRTLEN));

    //SALE TOTAL ccr070424>>>>>
//ccr070614	Add(&sTotalSale,&ApplVar.FiscalTotal.NoTaxSale);
//ccr20140725 һ����Ʒ�ж��ּ�˰ʱ����������    RJPrint(0,FormatAmtStr(Msg[XSHZHJI].str,&sTotalSale,PRTLEN));   //TAXABLE SUM

    //<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    PrintLine('-');
    RJPrint(0, Msg[ZONGJI].str);
//liuj 0613
    for (i=0;i<ApplVar.AP.Tax.Number;i++)
    {
        if (CheckNotZero(&ApplVar.FTaxTotal[i]))
        {
            RJPrint(0,FormatAmtStr(Msg[VATA+i].str,&ApplVar.FTaxTotal[i],PRTLEN));//ccr070424
        }
    }

//	for(i = 0; i < 1; i++)
    {//ccr071212
        sVal = ZERO;
    //��ӡƱ��ͳ������
        ULongToBCDValue(sVal.Value, ApplVar.FiscalTotal.FInvSum[0]);
#if PRTLEN<25 // liuj 0716
        RJPrint(0, Msg[FAPIAOHAO].str);
        FormatQtyStr(0, &sVal, PRTLEN);
#else
        FormatQtyStr(Msg[FAPIAOHAO].str, &sVal, PRTLEN);
#endif
//		j = BCDWidth(&sVal);
//		if (j<8)
//			memset(SysBuf+PRTLEN-8, '0', 8-j);
        RJPrint(0, SysBuf);
//		j++;
    }

    PrintAmt(Msg[HSJXSHOU].str, &ApplVar.FTotal);  //liuj 0606

//    liuj 0613

#if 0
    //REFUND SALE	//20070118
    sLong = labs(ApplVar.FiscalTotal.ReturnAmt);
    ULongToBCDValue(sVal.Value,sLong);
    if (ApplVar.FiscalTotal.ReturnAmt < 0)
        SETBIT(sVal.Sign, BIT7);
    else
        RESETBIT(sVal.Sign, BIT7);
    PrintAmt(Msg[THUOZHJI].str,&sVal);

    //REFUND TAX	//20070118
    sLong = labs(ApplVar.FiscalTotal.ReturnTax);
    ULongToBCDValue(sVal.Value,sLong);
    if (ApplVar.FiscalTotal.ReturnTax < 0)
        SETBIT(sVal.Sign, BIT7);
    else
        RESETBIT(sVal.Sign, BIT7);
    PrintAmt(Msg[THZJSHUI].str,&sVal);

    RFeed(1);

//hf end <<<<<<<<<<<<<<<<<<<<<<<
#endif
    //20070313
    //memset(&sVal,0,sizeof(BCD));
    //WORDtoBCD(sVal.Value,ApplVar.FiscalTotal.FInvSum);
    //RJPrint(0,FormatQtyStr(Msg[RECNUMBER].str,&sVal,PRTLEN));
    //total invoice, refund, No Fiscal number

    PrintFiscalAttribute();//ccr071212

}
//�ӵ縴λʱ,��˰�ش洢���и�ԭ˰������
short Fiscal_RecallData()
{
    BYTE i,j,k;
    WORD sBegin;
    ULONG sMid,sAddr;

    memset(&ApplVar.FiscalHead,0,sizeof(ApplVar.FiscalHead));
    memset(&ApplVar.FisNumber,0,sizeof(ApplVar.FisNumber));
    ApplVar.FiscalHead.ReadP = FISDATAADDR;

//ccr070531>>>>>>>>>>>>>>>>>>>>>>
//	Bios_FM_Read(&ApplVar.Fis_Header, FISHEADERADDR, sizeof(ApplVar.Fis_Header)) ; // liuj modify for new FM but init

#if(DD_MMC==1)
    for (sBegin=0;sBegin<FEJTBLMAX;sBegin++)
    {

        if (!Bios_FM_Read(SysBuf,FISEJADDR+sBegin*sizeof(ApplVar.Fis_EJTbl),sizeof(ApplVar.Fis_EJTbl)))
        {//ccr070719>>>>>>
            ApplVar.FisCardFlag = FMERROR;
            ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
            return 0;
        }//<<<<<<<<<<<<<<
        if (CWORD(SysBuf)==0xffff)
            break;
        memcpy(&ApplVar.Fis_EJTbl,SysBuf,sizeof(ApplVar.Fis_EJTbl));
    }

    ApplVar.FisNumber.TotalEJNum = sBegin;
    ApplVar.FiscalHead.EJTblP =  FISEJADDR + sBegin*sizeof(ApplVar.Fis_EJTbl);
#endif
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    if (!Bios_FM_Read(&ApplVar.FiscalBuff,FISDATAADDR,FISRECORDLEN))
    {//ccr070719>>>>>>>>>
        ApplVar.FisCardFlag = FMERROR;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
        return 0;
    }//<<<<<<<<<<<<<<<<<<<<<<<<
    if (CWORD(ApplVar.FiscalBuff)==0xffff)// û���κμ�¼//
    {
        ApplVar.FiscalHead.MaxP = FISDATAADDR;
        ApplVar.ZCount[REPZNUM]= ApplVar.ZCount[TRAINNUM]=1;//ccr091027
        ApplVar.FisNumber.TotalClearNum = 1; // liuj 0526
        if (ApplVar.Fis_Header.FFlag == FMINITEDFLAG)
        {
            ApplVar.FisNumber.FiscalDate = EncordDate(ApplVar.Fis_Header.FInitDate[0], ApplVar.Fis_Header.FInitDate[1], ApplVar.Fis_Header.FInitDate[2]);
            if (!ApplVar.FisNumber.LastZDate)    //have not print Z report, set fiscal date as LastZDate
                ApplVar.FisNumber.LastZDate =   ApplVar.FisNumber.FiscalDate;
        }
        return 0;
    }

    ApplVar.FTotal = ZERO;
    memset(&ApplVar.FTaxTotal,0,sizeof(ApplVar.FTaxTotal));//cr070615
    memset(ApplVar.FisNumber.TotalReceiptNum,0, sizeof(ApplVar.FisNumber.TotalReceiptNum));//ccr091027
    ApplVar.SaleReceipts = 0; // liuj 0829
    sBegin = 0;

#if (DD_FISPRINTER)//ccr091104>>>>>>>
    SwitchLedON(100);
#else
    PutsO(Msg[WAITING].str);
#endif
    for (sMid=FISDATAADDR;sMid<FISMEMERYSIZE;sMid += FISRECORDLEN)
    {
        if (sMid+FISRECORDLEN>FISMEMERYSIZE)
        {//ccr20130314
            ApplVar.FisCardFlag = FMFULL;ApplVar.ErrorNumber=ERROR_ID(CWXXI86);
            return 0;
        }
        else if (!Bios_FM_Read(&ApplVar.FiscalBuff,sMid,FISRECORDLEN))
        {//ccr070719>>>>>>>>>
            ApplVar.FisCardFlag = FMERROR;ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
            return 0;
        }//<<<<<<<<<<<<<<<<<<<<<<<<

        ApplVar.FiscalHead.MaxP =sMid;
        if (CWORD(ApplVar.FiscalBuff)==0xffff)// û�м�¼//
            break;


        switch (ApplVar.FiscalBuff.Fis_ClearRecord.FunN)
        {
        case  FISCLEARLOG:
            ApplVar.FisNumber.TotalClearNum = ApplVar.FiscalBuff.Fis_ClearRecord.FCount;

            memcpy(ApplVar.FisNumber.TotalReceiptNum, ApplVar.FiscalBuff.Fis_ClearRecord.FInvSum, sizeof(ApplVar.FiscalBuff.Fis_ClearRecord.FInvSum));
            ApplVar.FisNumber.LastZDate = ApplVar.FiscalBuff.Fis_ClearRecord.FDate;
            memcpy(ApplVar.FisNumber.LastZTime, ApplVar.FiscalBuff.Fis_ClearRecord.FTime, sizeof(ApplVar.FisNumber.LastZTime));

            ApplVar.FiscalHead.ClearP = sMid;

            for (i=0;i<ApplVar.AP.Tax.Number;i++)//ccr070615
            {
                AddBcdWithLong(&ApplVar.FTaxTotal[i], ApplVar.FiscalBuff.Fis_ClearRecord.FTaxAmt[i]);
                AddBcdWithLong(&ApplVar.FTotal,ApplVar.FiscalBuff.Fis_ClearRecord.FTaxSale[i]);
            }
            break;
        case  FISRESETLOG:
            ApplVar.FisNumber.TotalResetNum = ApplVar.FiscalBuff.Fis_ReSet.FCount;
            ApplVar.FiscalHead.ReSetP= sMid;
            break;
        case  FISHEADCHGLOG:
            ApplVar.FisNumber.TotalHeadChangeNum = ApplVar.FiscalBuff.Fis_HeadPointer.FChgCount;
            ApplVar.FiscalHead.FisHeadChgP = sMid;
            break;
        case   FISTAXLOG:
            memcpy(ApplVar.CurrentTaxRate,ApplVar.FiscalBuff.Fis_TaxRate.FNTaxRate,sizeof(ApplVar.CurrentTaxRate));//ccr070615
            ApplVar.FisNumber.TotalTaxChangeNum = ApplVar.FiscalBuff.Fis_TaxRate.FChgCount;
            ApplVar.FiscalHead.TaxRateP = sMid;
            break;
        case FISFMPULLLOG://ccr071212
            ApplVar.FisNumber.TotalFMNum = ApplVar.FiscalBuff.Fis_FMPull.FPullCount;
            ApplVar.FiscalHead.FMPullP = sMid;
            break;
        }
    }

#if (DD_FISPRINTER)//ccr091104
    SwitchLedOFF();
#else
    PutsO(ModeHead);
#endif

    if (ApplVar.FiscalHead.FisHeadChgP)
    {
        if (!Bios_FM_Read(&ApplVar.FiscalBuff,ApplVar.FiscalHead.FisHeadChgP,FISRECORDLEN))
        {//ccr070719>>>>>>>>>
            ApplVar.FisCardFlag = FMERROR;
            ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
            return 0;
        }//<<<<<<<<<<<<<<<<<<<<<<<<
        sAddr = ApplVar.FiscalBuff.Fis_HeadPointer.FNewPointer;
        memset(&ApplVar.Fis_HeadChg,0xff,sizeof(ApplVar.Fis_HeadChg));
        if (!Bios_FM_Read((BYTE *)&ApplVar.Fis_HeadChg+FHEADCHGLEN-2,sAddr+FHEADCHGLEN-2,2))
        {//ccr070719>>>>>>>>>
            ApplVar.FisCardFlag = FMERROR;
            ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
            return 0;
        }//<<<<<<<<<<<<<<<<<<<<<<<<
        for (j=0;j<8;j++)
        {
            if (!Bios_FM_Read((BYTE *)&ApplVar.Fis_HeadChg+(PRTLEN*j),sAddr,PRTLEN))
            {//ccr070719>>>>>>>>>
                ApplVar.FisCardFlag = FMERROR;
                ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
                return 0;
            }//<<<<<<<<<<<<<<<<<<<<<<<<
            sAddr += PRTLEN;
        }
        if (VerifyCRC((BYTE *)&ApplVar.Fis_HeadChg,FHEADCHGLEN,0))
        {
            for (j=0;j<8;j++)
            {
                for (k=0;k<PRTLEN;k++)
                    ApplVar.TXT.Header[j][k] = ApplVar.Fis_HeadChg.FNewHead[(j*PRTLEN)+k];
            }
        }
    }

//ccr070615>>>>>>>>>>>
    if (ApplVar.FiscalHead.TaxRateP)
    {
        for (ApplVar.TaxNumber=0;ApplVar.TaxNumber<ApplVar.AP.Tax.Number;ApplVar.TaxNumber++)
        {
            ReadTax();
            CWORD(ApplVar.Tax.Rate[0]) = CWORD(ApplVar.CurrentTaxRate[ApplVar.TaxNumber][0]);
            WriteTax();
        }
    }
//<<<<<<<<<<<<<<<<<<<<<

    if (Bios_FM_Read(&ApplVar.Fis_Header, FISHEADERADDR, sizeof(ApplVar.Fis_Header)) && ApplVar.Fis_Header.FFlag == FMINITEDFLAG)
    {
        ApplVar.FisNumber.FiscalDate = EncordDate(ApplVar.Fis_Header.FInitDate[0], ApplVar.Fis_Header.FInitDate[1], ApplVar.Fis_Header.FInitDate[2]);
        if (!ApplVar.FisNumber.LastZDate)    //have not print Z report, set fiscal date as LastZDate
            ApplVar.FisNumber.LastZDate =   ApplVar.FisNumber.FiscalDate;
        GetTimeDate(&Now);
        if (CompDate(&Now, ApplVar.FisNumber.LastZDate)<0)   //Now < LastZDate
        {
            Now.year = 0x2000 + ApplVar.Fis_Header.FInitDate[0];
            Now.month= ApplVar.Fis_Header.FInitDate[1];
            Now.day= ApplVar.Fis_Header.FInitDate[2];
            Now.dow = 8;
            SetTimeDate(&Now);
            SetDateFlg = 0;
        }
    }

    if (ApplVar.FisNumber.TotalEJNum >= FEJTBLMAX)
    {
        ApplVar.FisCardFlag = EJFULL;
#if DD_FISPRINTER
        SETBIT(ApplVar.Fiscal_Status, EJ_100);
#endif

    }
    else if (ApplVar.FisNumber.TotalResetNum > FRESETMAX)
        ApplVar.FisCardFlag = FMMACFULL;
    else if (ApplVar.FiscalHead.MaxP >= (FISMEMERYSIZE - FISMEMERYFULLSIZE_LESS))
    {
        ApplVar.FisCardFlag = FMFULL;
#if DD_FISPRINTER
        SETBIT(ApplVar.Fiscal_Status, FM_100);
#endif
        return 0;//ccr091104
    }

    ApplVar.FisNumber.TotalClearNum ++;     // liuj 0526

    ApplVar.ZCount[REPZNUM] = ApplVar.FisNumber.TotalClearNum;
    return 1;
}

//-------------------------------------
//   13-12-2012 09:34:13        00001
//    TAX-EXEMPT                 0.00
//    TAXABLE A  7.00%          11.72
//    TAXABLE B 10.00%          21.42
//    TAXABLE C 15.00%          22.10
//    TAX SUM                    0.00
//    TAXABLE SUM               55.24
//    # RECEIPTS                    1
//   --------------------------------
void Print_FiscalData(short sType)
{
    BCD sVal,sVal1;
    int i,j;
    BYTE saveTaxNumber;
    long  sLong;
    BYTE slen;  //20070313
    long sTotalSale, sTotalTax;

#if (defined(CASE_MALTA))
    Prefix1 = Prefix2 = 0;
#endif

    switch (sType)
    {
    case FISCLEARLOG:
        //Date & Time>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        memset(ProgLineMes,' ',PRTLEN);
        DecordDateFiscal(ApplVar.FiscalBuff.Fis_ClearRecord.FDate,ProgLineMes);
        ProgLineMes[10] = ' ';

        //20070313
        EncodeTimeFiscal(ApplVar.FiscalBuff.Fis_ClearRecord.FTime, ProgLineMes+11);
        ProgLineMes[19] = ' ';

        //20070313	print Z counter
        //SysBuf[17] = '#';
        //WORDtoBCD(sVal.Value,ApplVar.FiscalBuff.Fis_ClearRecord.FCount);
        //PrintQty(ProgLineMes,&sVal);
#if PRTLEN<25 // liuj 0716
        PrintStr(ProgLineMes);
        memset(ProgLineMes,' ',PRTLEN);
#endif
        WORDtoASCZero(ProgLineMes+PRTLEN-1, ApplVar.FiscalBuff.Fis_ClearRecord.FCount);
        SysBuf[PRTLEN] = 0;
        RJPrint(0, ProgLineMes);//13-12-2012 09:34:13        00001


        //TAX-EXEMPT
        LongToBCD(&sVal,ApplVar.FiscalBuff.Fis_ClearRecord.NoTaxSale);

        PrintAmt(Msg[MIANSHUI].str,&sVal);//TAX-EXEMPT

        //VATA to VATH>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        saveTaxNumber = ApplVar.TaxNumber;
        //"TAX SALE  "
//ccr20140725 һ����Ʒ�ж��ּ�˰ʱ����������        sTotalSale = 0;
        sTotalTax = 0;
        for (i=0;i<ApplVar.AP.Tax.Number;i++)
        {

             sVal1 = ZERO;
//ccr20140725 һ����Ʒ�ж��ּ�˰ʱ����������            sTotalSale += ApplVar.FiscalBuff.Fis_ClearRecord.FTaxSale[i];   //20070313
            sLong = (ApplVar.FiscalBuff.Fis_ClearRecord.FTaxSale[i]);

            if (sLong!=0)//ccr070424
            {
                memset(ProgLineMes,' ',PRTLEN);
                LongToBCD(&sVal, sLong);

                CopyFrStr(ProgLineMes,Msg[XIAOSHOUA].str);
                slen = strlen(Msg[XIAOSHOUA].str);
                ProgLineMes[slen+1] = 'A' + i;  //ProgLineMes[6] = 'A' + i;	//20070313

                CWORD(sVal1.Value[0]) = CWORD(ApplVar.CurrentTaxRate[i][0]);
                sVal1.Sign = 2;

                FormatQty(ProgLineMes+15,&sVal1);//cr070424
                ProgLineMes[16] = '%';
                ProgLineMes[17] = 0;
//liuj 0716
#if PRTLEN<25
                ProgLineMes[PRTLEN] = 0;
                PrintStr(ProgLineMes);
                PrintAmt(0,&sVal);
#else
                PrintAmt(ProgLineMes,&sVal);//TAXABLE A  7.00%
#endif
            }


             sVal1 =ZERO;
             sLong = (ApplVar.FiscalBuff.Fis_ClearRecord.FTaxAmt[i]);
            sTotalTax += sLong;
            if (sLong!=0)//ccr070424
            {
                memset(ProgLineMes,' ',PRTLEN);
                LongToBCD(&sVal,sLong);

                CopyFrStr(ProgLineMes,Msg[VATA+i].str);

                CWORD(sVal1.Value[0]) = CWORD(ApplVar.CurrentTaxRate[i][0]);

                sVal1.Sign = 2;
                FormatQty(ProgLineMes+15,&sVal1);//ccr070424
                ProgLineMes[16] = '%';
                ProgLineMes[17] = 0;
//liuj 0716
#if PRTLEN<25
                ProgLineMes[PRTLEN] = 0;
                PrintStr(ProgLineMes);
                PrintAmt(0,&sVal);
#else
                PrintAmt(ProgLineMes,&sVal);
#endif
            }


        }
        ApplVar.TaxNumber = saveTaxNumber;


        //TAX TOTAL>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        LongToBCD(&sVal,sTotalTax);

        PrintAmt(Msg[TAXTOTAL].str,&sVal);  //TAX SUM

        //TOTAL SALE >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
//ccr070614			sTotalSale += ApplVar.FiscalBuff.Fis_ClearRecord.NoTaxSale;
/*ccr20140725 һ����Ʒ�ж��ּ�˰ʱ����������>>>>>>>>>>>>>
        sLong = (sTotalSale);
        LongToBCD(&sVal,sLong);
         PrintAmt(Msg[XSHZHJI].str,&sVal);//TAXABLE SUM
<<<<<<<<<<<<<<<<<<<<<<<<<*/
//ccr091027>>>>
        sVal = ZERO;
        ULongToBCDValue(sVal.Value, ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice[FRECEIPTS]) ;
        RJPrint(0, FormatQtyStr(Msg[FAPIAOHAO].str, &sVal, PRTLEN)); // # RECEIPTS
//<<<<<<<<<<<<
#if 0
        //DISCOUNT SALE					//20070313
        sLong = (ApplVar.FiscalBuff.Fis_ClearRecord.DiscAmt);
        LongToBCD(&sVal,sLong);
        PrintAmt(Msg[ZHKOUZHJI].str,&sVal);

        //DISCOUNT TAX					//20070313
        sLong = (ApplVar.FiscalBuff.Fis_ClearRecord.DiscTax);
        LongToBCD(&sVal,sLong);
        PrintAmt(Msg[ZHKZJSHUI].str,&sVal);

        //REFUND SALE	//20070118
        LongToBCD(&sVal,ApplVar.FiscalBuff.Fis_ClearRecord.ReturnAmt);
        PrintAmt(Msg[THUOZHJI].str,&sVal);

        //REFUND TAX	//20070118
        LongToBCD(&sVal,ApplVar.FiscalBuff.Fis_ClearRecord.ReturnTax);
        PrintAmt(Msg[THZJSHUI].str,&sVal);
#endif
        //20070313	REC.NUMBER>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        //memset(&sVal,0,sizeof(BCD));
        //WORDtoBCD(sVal.Value,ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice);
        //PrintQty(Msg[RECNUMBER].str, &sVal);

        //invoice, refund, no fiscal number of the date
#if 0
        j = FAPIAOHAO;
        for (i = 0; i < 1;i++)
        {
            memset(SysBuf, ' ', sizeof(SysBuf));
            CopyFrStr(SysBuf, Msg[FAPIAOHAO].str);
            WORDtoASCZero(SysBuf+PRTLEN-1, ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice[i]);
            SysBuf[PRTLEN] = 0;
            RJPrint(0, SysBuf);
            j++;
        }

//liuj 0613
        for (i=0;i<ApplVar.AP.Tax.Number;i++)
        {
            if (CheckNotZero(&ApplVar.FTaxTotal[i]))
            {
                RJPrint(0,FormatAmtStr(Msg[VATA+i].str,&ApplVar.FTaxTotal[i],PRTLEN));
            }
        }

        PrintAmt(Msg[HSJXSHOU].str, &ApplVar.FTotal);  //liuj 0606
//liuj 0613
#endif
        break;
    case FISRESETLOG:
        memset(ProgLineMes,' ',PRTLEN);
        DecordDateFiscal(ApplVar.FiscalBuff.Fis_ReSet.FDate,ProgLineMes);
        ProgLineMes[10]=' ';//ccr071212
        CopyFrStr(ProgLineMes+11,Msg[MACRESET].str);//ccr071212
        sVal = ZERO;
        WORDtoBCD(sVal.Value,ApplVar.FiscalBuff.Fis_ReSet.FCount);
        RJPrint(0,FormatQtyStr(ProgLineMes,&sVal,PRTLEN));
        break;

    case FISFMPULLLOG://ccr071212
        memset(ProgLineMes,' ',PRTLEN);
        DecordDateFiscal(ApplVar.FiscalBuff.Fis_FMPull.FDate,ProgLineMes);
        ProgLineMes[10]=' ';
        CopyFrStr(ProgLineMes+11,Msg[FMPULLOUT].str);
        sVal = ZERO;
        WORDtoBCD(sVal.Value,ApplVar.FiscalBuff.Fis_FMPull.FPullCount);
        RJPrint(0,FormatQtyStr(ProgLineMes,&sVal,PRTLEN));
        break;

    case FISHEADCHGLOG:
        memset(SysBuf,' ',PRTLEN);
        DecordDateFiscal(ApplVar.FiscalBuff.Fis_HeadPointer.FDate,SysBuf);
        SysBuf[10] = ' ';
        strcpy(SysBuf+12,Msg[CHANGEHEAD].str);

        RJPrint(0,SysBuf);
        for (i=0;i<8;i++)
        {
            memset(SysBuf,' ',PRTLEN);
            for (j=0;j<PRTLEN;j++)
            {
                SysBuf[j] = ApplVar.Fis_HeadChg.FNewHead[(i*PRTLEN)+j];
            }
            SysBuf[PRTLEN] = 0;
            RJPrint(0, SysBuf);
        }
        break;
    case FISTAXLOG:
        //Date & Time>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        memset(SysBuf,' ',PRTLEN);
        DecordDateFiscal(ApplVar.FiscalBuff.Fis_TaxRate.FDate,SysBuf);
        SysBuf[10] = ' ';
        strcpy(SysBuf+12,Msg[CHANGETAX].str);
        RJPrint(0,SysBuf);
        //TAX CHANGE>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        for (i=0;i<ApplVar.AP.Tax.Number;i++)
        {
            sVal=sVal1=ZERO;
            memset(SysBuf,' ',PRTLEN);

            CWORD(sVal.Value[0]) = CWORD(ApplVar.FiscalBuff.Fis_TaxRate.FNTaxRate[i][0]);

            CWORD(sVal1.Value[0]) = CWORD(ApplVar.FiscalBuff.Fis_TaxRate.FOTaxRate[i][0]);

            if (CompareBCD(&sVal,&sVal1) != 0)
            {
                RJPrint(1,Msg[TAXACHG+i].str);
#if PRTLEN<25 //liuj 0716
                sVal1.Sign = 2;
                FormatQty(SysBuf+6,&sVal1);//ccr070424
                SysBuf[7] = '%';
                CopyFrStr(SysBuf+8,Msg[TAXTO].str);
                sVal.Sign = 2;
                FormatQty(SysBuf+17,&sVal);;//ccr070424
                SysBuf[18] = '%';       SysBuf[PRTLEN] = 0;
                RJPrint(0,SysBuf);

#else
                CopyFrStr(SysBuf,Msg[TAXFROM].str);
                sVal1.Sign = 2;
                FormatQty(SysBuf+11,&sVal1);//ccr070424
                SysBuf[12] = '%';
                CopyFrStr(SysBuf+13,Msg[TAXTO].str);
                sVal.Sign = 2;
                FormatQty(SysBuf+22,&sVal);;//ccr070424
                SysBuf[23] = '%';       SysBuf[24] = 0;
                RJPrint(0,SysBuf);
#endif
            }
        }
        break;
    }
    PrintLine2('-');
}


//ccr20121212>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
// �������ڲ���z�������ݵĴ�ŵ�ַ //
// ZOnly:=true,ֻ��ѯZ���� //
// pDate:ѹ����ʽ������
// return -1:�޴����ڵ����ݣ������ҵ�һ����ӽ������ڵ�ַ //
//        0: �ҵ������ڵĵ�ַ //
//        1: ����������δ����ָ������ //
// RamOffset �ͳ���Ч��ַ //
short GetZAddrByDate(WORD pDate,bool ZOnly)
{
    ULONG sRamOffsetFr,sRamOffsetTo,sMid;

    struct 	FIS_CLEARRECORD sClearRecord;

    if (ApplVar.FiscalHead.ClearP<FISDATAADDR)
        return 1;

    RamOffSet = FISDATAADDR;
    sRamOffsetFr = 1;
    sRamOffsetTo = (ApplVar.FiscalHead.ClearP-FISDATAADDR)/FISRECORDLEN+1;
    /*���ȼ���ṩ�����ڲ����Ƿ���˰�����ݼ�¼��Χ��*/
    if (!Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,FISDATAADDR,FISRECORDLEN))
    {
        ApplVar.FisCardFlag = FMERROR;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
        return 1;
    }

    if (pDate < ApplVar.FiscalBuff.Fis_ClearRecord.FDate)
        return -1;

    if (pDate == ApplVar.FiscalBuff.Fis_ClearRecord.FDate && !ZOnly)
        return 0;

    if (!Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,ApplVar.FiscalHead.ClearP,FISRECORDLEN))
    {
        ApplVar.FisCardFlag = FMERROR;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
        return 1;
    }

    if (pDate > ApplVar.FiscalBuff.Fis_ClearRecord.FDate)
        return 1;

    while (sRamOffsetFr <= sRamOffsetTo)
    {
        sMid = (sRamOffsetTo + sRamOffsetFr) / 2;
        RamOffSet = (sMid-1)*FISRECORDLEN+FISDATAADDR;

        if (!Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,RamOffSet,FISRECORDLEN))
            ApplVar.FisCardFlag = BADFM;

        if (ApplVar.FiscalBuff.Fis_ClearRecord.FDate == pDate)
        {//�ҵ�ƥ��ļ�¼
            sRamOffsetFr = RamOffSet;
            sRamOffsetTo = 0;// �ȼ�����Z�������� //
            while (RamOffSet>FISDATAADDR)
            {// ������ǰ�ҵ�һ��ƥ�����ڵ�����  //
                if (ApplVar.FiscalBuff.Fis_ClearRecord.FunN==FISCLEARLOG)
                    sRamOffsetTo = RamOffSet;// ��¼Z��������λ�� //
                RamOffSet-=FISRECORDLEN;//
                Bios_FM_Read(&sClearRecord,RamOffSet,FISRECORDLEN);
                if (sClearRecord.FDate != pDate)
                {
                    RamOffSet=sRamOffsetTo;//�ָ�Z����λ��
                    break;
                }
                memcpy(&ApplVar.FiscalBuff.Fis_ClearRecord,&sClearRecord,FISRECORDLEN);
            }
            if (ZOnly && (sRamOffsetTo==0))// û��Z����,���������� //
            {
                RamOffSet = sRamOffsetFr;
                while (RamOffSet<ApplVar.FiscalHead.ClearP)
                {// �ҵ�һ��ƥ�����ڵ�����  //
                    RamOffSet+=FISRECORDLEN;
                    Bios_FM_Read(&sClearRecord,RamOffSet,FISRECORDLEN);
                    if (sClearRecord.FDate != pDate)
                        break;

                    if (sClearRecord.FunN==FISCLEARLOG)
                    {
                        memcpy(&ApplVar.FiscalBuff.Fis_ClearRecord,&sClearRecord,FISRECORDLEN);
                        sRamOffsetTo = RamOffSet;// ��¼Z��������λ�� //
                        break;
                    }
                }
            }
            if (ZOnly)
                RamOffSet=sRamOffsetTo;
            if (RamOffSet)
                return 0;
            else
                return -1;// �޶�Ӧ���ڵ�Z��������  //
        }
        else if (pDate < ApplVar.FiscalBuff.Fis_ClearRecord.FDate)
            sRamOffsetTo = sMid - 1;
        else
            sRamOffsetFr = sMid + 1;
    }
//	RamOffSet = sRamOffsetFr*FISRECORDLEN+FISDATAADDR;
    return -1;
}
// ����Z��������z�������ݵĴ�ŵ�ַ(���������������˼������ݣ��˺���������) //
// return -1:�޴�Z#�����ݣ������ҵ�һ����ӽ������ڵ�ַ //
//        0: �ҵ���Z#�ĵ�ַ //
//        1: ����Z#��δ����ָ������ //
// RamOffset �ͳ���Ч��ַ //
    #if 0
short GetZAddrByNum(WORD pNum)
{
    WORD sRamOffsetFr,sRamOffsetTo,sMid;

    RamOffSet = FISDATAADDR;

    if (ApplVar.FiscalHead.ClearP<FISDATAADDR)
        return 1;

    sRamOffsetFr = 1;
    sRamOffsetTo = (ApplVar.FiscalHead.ClearP-FISDATAADDR)/FISRECORDLEN+1;

    if (!Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,FISDATAADDR,FISRECORDLEN))
    {
        ApplVar.FisCardFlag = FMERROR;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
        return 1;
    }

    if (pNum < ApplVar.FiscalBuff.Fis_ClearRecord.FCount)
        return -1;

    if (pNum == ApplVar.FiscalBuff.Fis_ClearRecord.FCount)
        return 0;

    if (!Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,ApplVar.FiscalHead.ClearP,FISRECORDLEN))
    {
        ApplVar.FisCardFlag = FMERROR;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
        return 1;
    }

    if (pNum > ApplVar.FiscalBuff.Fis_ClearRecord.FCount)
        return 1;

    while (sRamOffsetFr <= sRamOffsetTo)
    {
        sMid = (sRamOffsetTo + sRamOffsetFr) / 2;
        RamOffSet = (sMid-1)*FISRECORDLEN+FISDATAADDR;

        if (!Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,RamOffSet,FISRECORDLEN))
            ApplVar.FisCardFlag = BADFM;


        if (ApplVar.FiscalBuff.Fis_ClearRecord.FCount == pNum)
        {
            do
            {
                Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,RamOffSet-FISRECORDLEN,FISRECORDLEN);
                if (ApplVar.FiscalBuff.Fis_ClearRecord.FCount != pNum)
                    break;
                RamOffSet-=FISRECORDLEN;
            } while (1);
            return 0;
        }
        else if (pNum < ApplVar.FiscalBuff.Fis_ClearRecord.FCount)
            sRamOffsetTo = sMid - 1;
        else
            sRamOffsetFr = sMid + 1;
    }
//	RamOffSet = sRamOffsetFr*FISRECORDLEN+FISDATAADDR;
    return -1;
}
    #endif
//--------------------------------------------------------------
/**
 * ������ѯ��ӡ˰�����ݱ���
 *
 * @author EutronSoftware (2014-08-04)
 *
 * @param sType :Bit7=1ʱ,ֻ��ѯ��ӡZ��������
 *          PRNALL:��������ӡFM�е�ȫ������
 *          PRNNUM:����������վݺŲ�ѯ��ӡFM����
 *          PRNDATE:�������ڷ�Χ��ѯ��ӡFM����
 *          PRNDATEWD:��ѯͳ�����ڷ�Χ�ڵ�Z��������
 * @return short
 */
short Read_FiscalData(BYTE sType)
{
    int   i;
    BYTE    sActive,sTotal,sExit,sZOnly;
    UnLong  sAddr,sHeadAddr;
    WORD    sDate;
    BCD     sVal;
    BYTE    bCRC;
    BYTE    sSaveCurrent[8][2];

    sStartZ  = sEndZ = 0;

    if (ApplVar.FiscalHead.MaxP <= FISDATAADDR)
        return 0;

    sZOnly = sType & 0x80;
    sType &= 0x7f;
    memset((char *)&ApplVar.FiscalTotal,0,sizeof(ApplVar.FiscalTotal));//ccr070424

//ccr070609pm>>>>>>>>>>>
    StoreEJEnd();
#if DD_MMC
    ApplVar.EJContent = FMCONT;
    SETBIT(ApplVar.ContFlag, (ENSTORE|ENHEADER));
#endif
    //Print_NonFiscal();
    //PrintHead1(0);			//liuj 0610
    RFeed(1);
//<<<<<<<<<<<<<<<<<<<<<<<<<<

    memcpy(sSaveCurrent,ApplVar.CurrentTaxRate, sizeof(ApplVar.CurrentTaxRate));// restore the current tax
    memset(&sVal,0,sizeof(BCD));

    PrintStr_Center((char *)Msg[PRNFISCAL].str,true);
    PrintLine2('=');

    if (sType == PRNNUM)
    {
        sAddr = FISDATAADDR;
//		i = GetZAddrByNum(ApplVar.FiscalDefine.RecNumFr);
//		if (i>0)
//			return 0;
//		else
//			sAddr = RamOffSet;

        memset(SysBuf,' ',PRTLEN);
        memset(&sVal,0,sizeof(BCD));
        CopyFrStr(SysBuf,Msg[RECEIPTFROM].str);
        WORDtoBCD(sVal.Value,ApplVar.FiscalDefine.RecNumFr);
        FormatQty(SysBuf+15,&sVal);
        RJPrint(0,SysBuf);
        memset(SysBuf,' ',PRTLEN);
        memset(&sVal,0,sizeof(BCD));
        CopyFrStr(SysBuf,Msg[RECEIPTTO].str);
        WORDtoBCD(sVal.Value,ApplVar.FiscalDefine.RecNumTo);
        FormatQty(SysBuf+15,&sVal);
        RJPrint(0,SysBuf);
    }
    else if (sType == PRNDATE || sType == PRNDATEWD)
    {
        i = GetZAddrByDate(ApplVar.FiscalDefine.DateFr,false);
        if (i>0)
            return 0;
        else
            sAddr = RamOffSet;

        memset(SysBuf,' ',PRTLEN);
        CopyFrStr(SysBuf,Msg[RIQIF].str);
        DecordDateFiscal(ApplVar.FiscalDefine.DateFr,SysBuf+11);
        RJPrint(0,SysBuf);
        memset(SysBuf,' ',PRTLEN);
        CopyFrStr(SysBuf,Msg[JSHRQIF].str);
        DecordDateFiscal(ApplVar.FiscalDefine.DateTo,SysBuf+11);
        RJPrint(0,SysBuf);
    }
    else
        sAddr = FISDATAADDR;

    RFeed(1);
    sActive = sExit = sTotal = false;
#if (DD_FISPRINTER)
    SwitchLedON(100);
    while (sAddr < ApplVar.FiscalHead.MaxP && !sExit)
    {
#else
    PutsO(Msg[WAITING].str);
    while (sAddr < ApplVar.FiscalHead.MaxP && !KbHit() && !sExit)
    {
        FM_EJ_Exist();
#endif
        if (sAddr+FISRECORDLEN>FISMEMERYSIZE)
        {//ccr20130314
            ApplVar.FisCardFlag = FMFULL;ApplVar.ErrorNumber=ERROR_ID(CWXXI86);
            return 0;
        }
        else  if (!Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,sAddr,FISRECORDLEN))
        {//ccr070719>>>>>>>>>
            ApplVar.FisCardFlag = FMERROR; ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
            return 0;
        }//<<<<<<<<<<<<<<<<<<<<<<<<
        bCRC = VerifyCRC((BYTE *)&ApplVar.FiscalBuff.Fis_ClearRecord,FISRECORDLEN,1);
        if (bCRC!= ApplVar.FiscalBuff.Fis_ClearRecord.FCRC )//(BYTE *)&ApplVar.FiscalBuff,FISRECORDLEN,1
        {
            sTotal = FALSE;
            break;  //return 0;
        }

        sActive = false;//ccr100329
        switch (ApplVar.FiscalBuff.Fis_ClearRecord.FunN)
        {
        case FISCLEARLOG:
            if (sType == PRNNUM)
            {
                if (ApplVar.FiscalBuff.Fis_ClearRecord.FCount >=  ApplVar.FiscalDefine.RecNumFr &&
                    ApplVar.FiscalBuff.Fis_ClearRecord.FCount <= ApplVar.FiscalDefine.RecNumTo)
                {
                    sActive = true;
                }
                else
                {//ccr091116
                    sActive = false;
                    if (ApplVar.FiscalBuff.Fis_ClearRecord.FCount > ApplVar.FiscalDefine.RecNumTo)
                        sExit = true;
                }
            }
            sDate = ApplVar.FiscalBuff.Fis_ClearRecord.FDate;
            break;
        case FISRESETLOG:
            sDate = ApplVar.FiscalBuff.Fis_ReSet.FDate;
            break;
        case FISFMPULLLOG://ccr071212
            sDate = ApplVar.FiscalBuff.Fis_FMPull.FDate;
            break;
        case FISHEADCHGLOG:
            sDate = ApplVar.FiscalBuff.Fis_HeadPointer.FDate;
            sHeadAddr = ApplVar.FiscalBuff.Fis_HeadPointer.FNewPointer;
            memset(&ApplVar.Fis_HeadChg,0xff,sizeof(ApplVar.Fis_HeadChg));
            if (!Bios_FM_Read((BYTE *)&ApplVar.Fis_HeadChg+FHEADCHGLEN-2,sHeadAddr+FHEADCHGLEN-2,2))
            {//ccr070719>>>>>>>>>
                ApplVar.FisCardFlag = FMERROR;
                ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
                return 0;
            }//<<<<<<<<<<<<<<<<<<<<<<<<
            for (i=0;i<8;i++)
            {
                if (!Bios_FM_Read((BYTE *)&ApplVar.Fis_HeadChg+(PRTLEN*i),sHeadAddr,PRTLEN))
                {//ccr070719>>>>>>>>>
                    ApplVar.FisCardFlag = FMERROR;
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
                    return 0;
                }//<<<<<<<<<<<<<<<<<<<<<<<<
                sHeadAddr += PRTLEN;
            }
            if (!VerifyCRC((BYTE *)&ApplVar.Fis_HeadChg,FHEADCHGLEN,0))
            {
                sTotal = FALSE;
                break;  //return 0;
            }
            break;
        case FISTAXLOG:
            sDate = ApplVar.FiscalBuff.Fis_TaxRate.FDate;
            memcpy(ApplVar.CurrentTaxRate,ApplVar.FiscalBuff.Fis_TaxRate.FNTaxRate,sizeof(ApplVar.CurrentTaxRate));//ccr060715
            break;
        }


        if ((sType==PRNDATE || sType==PRNDATEWD) && sDate > ApplVar.FiscalDefine.DateTo)//ccr091116
            sExit = true;
//ccr100329>>>>>>>>>>>>>>>>>
        if (sDate >= ApplVar.FiscalDefine.DateFr && sDate <= ApplVar.FiscalDefine.DateTo)
        {
            if ((sType==PRNDATE || sType==PRNDATEWD))
            {
                sActive = !sZOnly || (ApplVar.FiscalBuff.Fis_ClearRecord.FunN==FISCLEARLOG);
            }
        }
//<<<<<<<<<<<<<<<<<<<<<<<<<<
        if (sActive || sType==PRNALL)//ccr100329
        {
            if (sType != PRNDATEWD)
                Print_FiscalData(ApplVar.FiscalBuff.Fis_ClearRecord.FunN);
            switch (ApplVar.FiscalBuff.Fis_ClearRecord.FunN)
            {
            case FISCLEARLOG:
                ApplVar.FiscalTotal.FClearCount ++;
                for (i=0;i<ApplVar.AP.Tax.Number;i++)
                {
                    AddBcdWithLong(&ApplVar.FiscalTotal.FTaxAmt[i],ApplVar.FiscalBuff.Fis_ClearRecord.FTaxAmt[i]);//ccr070424
                    AddBcdWithLong(&ApplVar.FiscalTotal.FTaxSale[i], ApplVar.FiscalBuff.Fis_ClearRecord.FTaxSale[i]);//ccr070424
                }
                ApplVar.FiscalTotal.FInvSum[0] += ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice[0];
                ApplVar.FiscalTotal.FInvSum[1] += ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice[1];
                ApplVar.FiscalTotal.FInvSum[2] += ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice[2];
                AddBcdWithLong(&ApplVar.FiscalTotal.NoTaxSale, ApplVar.FiscalBuff.Fis_ClearRecord.NoTaxSale);//ccr070424
                ApplVar.FiscalTotal.DiscAmt+= ApplVar.FiscalBuff.Fis_ClearRecord.DiscAmt;       //20070313
                ApplVar.FiscalTotal.DiscTax+= ApplVar.FiscalBuff.Fis_ClearRecord.DiscTax;           //20070313
                ApplVar.FiscalTotal.ReturnAmt += ApplVar.FiscalBuff.Fis_ClearRecord.ReturnAmt;  //20070118
                ApplVar.FiscalTotal.ReturnTax += ApplVar.FiscalBuff.Fis_ClearRecord.ReturnTax;  //20070118


                //for printer
                if (!sStartZ)
                    sStartZ = ApplVar.FiscalBuff.Fis_ClearRecord.FCount;
                sEndZ = ApplVar.FiscalBuff.Fis_ClearRecord.FCount;
                break;
            case FISRESETLOG:
                ApplVar.FiscalTotal.FReSetCount ++;
                break;
            case FISTAXLOG:
                ApplVar.FiscalTotal.FTaxChgCount ++;
                break;
            case FISHEADCHGLOG:
                ApplVar.FiscalTotal.FHeadChgCount ++;
                break;
            }
            sTotal = true;
        }
        sAddr += FISRECORDLEN;
    }

//-------------------liuj modify 070419 ------------------
    if (sTotal && sType != PRNNUM)
        Print_FiscalTotal();

//ccr070615>>>>>>
    memcpy(ApplVar.CurrentTaxRate, sSaveCurrent,sizeof(ApplVar.CurrentTaxRate));// restore the current tax
//<<<<<<<<<<<<<<<<

    ApplVar.FStatus = 1;
    AddReceiptNumber();     //20070118

    i = ApplVar.FReceipt;
    ApplVar.FReceipt = 1;
#if (DD_FISPRINTER)
    SwitchLedOFF();
    ReceiptIssue(0);//ccr090819 1+BIT1
#else
    PutsO(ModeHead);
    ReceiptIssue(1+BIT1);//ccr090819 1+BIT1
#endif
    ApplVar.FReceipt = i;
    RFeed(1);
    return sTotal;  //return 1;
}


    #if 0

short Fiscal_AddClearData()
{
    short i,j,k;
    short sOld,sCount;
    WORD sY,sM,sD;
    BYTE sH;
    struct TimeDate sDate;

    if (ApplVar.FiscalHead.MaxP>=FISMEMERYSIZE)
        return 0;

    sOld = ApplVar.FiscalHead.ClearP;
    if (sOld == 0)
        memset(&ApplVar.FiscalBuff,0,sizeof(ApplVar.FiscalBuff.Fis_ClearRecord));
    else
        Bios_FM_Read(&ApplVar.FiscalBuff,sOld,sizeof(ApplVar.FiscalBuff.Fis_ClearRecord));

    GetTimeDate(&sDate);
    sY = sDate.year & 0x00ff;
    sM = sDate.month;
    sD = sDate.day;

    ApplVar.FiscalBuff.Fis_ClearRecord.FDate = EncordDate(sY,sM,sD);
    ApplVar.FiscalBuff.Fis_ClearRecord.FCount++;
    ApplVar.FiscalBuff.Fis_ClearRecord.FTime[0] = sDate.hour;
    ApplVar.FiscalBuff.Fis_ClearRecord.FTime[1] = sDate.min;
    ApplVar.FiscalBuff.Fis_ClearRecord.FTotal = 0;
    for (j=0;j<ApplVar.AP.Tax.Number;j++)
    {
        ApplVar.FiscalBuff.Fis_ClearRecord.FTaxAmt[j] = 30000+ApplVar.FiscalBuff.Fis_ClearRecord.FCount;
        ApplVar.FiscalBuff.Fis_ClearRecord.FTotal += ApplVar.FiscalBuff.Fis_ClearRecord.FTaxAmt[j];
    }

    ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice =300+ApplVar.FiscalBuff.Fis_ClearRecord.FCount;
    ApplVar.FiscalBuff.Fis_ClearRecord.FInvSum += ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice;
    ApplVar.FiscalBuff.Fis_ClearRecord.FEJID = 0;
    ApplVar.FiscalBuff.Fis_ClearRecord.FGross = 0;
    ApplVar.FiscalBuff.Fis_ClearRecord.FCRC = 0;
    ApplVar.FiscalBuff.Fis_ClearRecord.FunN = FISCLEARLOG;

    ApplVar.FisNumber.TotalClearNum++;
    ApplVar.FiscalHead.ClearP = ApplVar.FiscalHead.MaxP;
    ApplVar.FiscalHead.MaxP += sizeof(ApplVar.FiscalBuff.Fis_ClearRecord);
    ApplVar.FiscalBuff.Fis_ReSet.FCRC = VerifyCRC((BYTE *)&ApplVar.FiscalBuff.Fis_ReSet,FRECORDLEN,1);
    Bios_FM_Write(ApplVar.FiscalHead.ClearP, &ApplVar.FiscalBuff, sizeof(ApplVar.FiscalBuff.Fis_ClearRecord));
    return 1;
}

    #endif
short Fiscal_AddResetData()
{
    struct TimeDate sDate;
    WORD sY,sM,sD;

    if (ApplVar.FisNumber.TotalResetNum > FRESETMAX)//ccr091104>>>
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI91);
        ApplVar.FisCardFlag = FMMACFULL;
        return 0;
    }//<<<<<

    if (ApplVar.FiscalHead.ReSetP == 0)
        memset(&ApplVar.FiscalBuff,0,sizeof(ApplVar.FiscalBuff.Fis_ReSet));
    else
        if (!Bios_FM_Read(&ApplVar.FiscalBuff,ApplVar.FiscalHead.ReSetP,sizeof(ApplVar.FiscalBuff.Fis_ReSet)))
    {//ccr070719>>>>>>>>>
        ApplVar.FisCardFlag = FMERROR;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
        return 0;
    }//<<<<<<<<<<<<<<<<<<<<<<<<

    GetTimeDate(&sDate);
    sY = sDate.year & 0x00ff;
    sM = sDate.month;
    sD = sDate.day;

    ApplVar.FiscalBuff.Fis_ReSet.FDate = EncordDate(sY,sM,sD);
    ApplVar.FiscalBuff.Fis_ReSet.FCount++;
    ApplVar.FiscalBuff.Fis_ReSet.FTime[0] = sDate.hour;
    ApplVar.FiscalBuff.Fis_ReSet.FTime[1] = sDate.min;

    ApplVar.FiscalBuff.Fis_ReSet.FCRC = 0;
    ApplVar.FiscalBuff.Fis_ReSet.FunN = FISRESETLOG;

    ApplVar.FisNumber.TotalResetNum++;
    ApplVar.FiscalHead.ReSetP = ApplVar.FiscalHead.MaxP;
    ApplVar.FiscalHead.MaxP += sizeof(ApplVar.FiscalBuff.Fis_ReSet);

    ApplVar.FiscalBuff.Fis_ReSet.FCRC = VerifyCRC((BYTE *)&ApplVar.FiscalBuff.Fis_ReSet,FRECORDLEN,1);
    if (!Bios_FM_Write(ApplVar.FiscalHead.ReSetP, &ApplVar.FiscalBuff, sizeof(ApplVar.FiscalBuff.Fis_ReSet)))
    {//ccr070719>>>>>>>>>
        ApplVar.FisCardFlag = BADFM;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI76);
        return 0;
    }//<<<<<<<<<<<<<<<<<<<<<<<<
    return 1;
}

    #if 0
short Fiscal_AddHeadData()
{
    short i,j,k;
    struct TimeDate sDate;
    short sOld,sCount;
    WORD sY,sM,sD;
    BYTE sH;

    if (ApplVar.FiscalHead.MaxP>=FISMEMRYSIZE)
        return 0;

    sOld = ApplVar.FiscalHead.FisHeadChgP;
    if (sOld == 0)
        memset(&ApplVar.FiscalBuff,0,sizeof(ApplVar.FiscalBuff.Fis_HeadPointer));
    else
        Bios_FM_Read(&ApplVar.FiscalBuff,sOld,sizeof(ApplVar.FiscalBuff.Fis_HeadPointer));

    GetTimeDate(&sDate);
    sY = sDate.year & 0x00ff;
    sM = sDate.month;
    sD = sDate.day;

    ApplVar.FiscalBuff.Fis_HeadPointer.FDate = EncordDate(sY,sM,sD);
    ApplVar.FiscalBuff.Fis_HeadPointer.FChgCount++;
    ApplVar.FiscalBuff.Fis_HeadPointer.FTime[0] = sDate.hour;
    sH = 14;
    ApplVar.FiscalBuff.Fis_HeadPointer.FTime[1] = sDate.min;
    ApplVar.FiscalBuff.Fis_HeadPointer.FCRC = 0;
    ApplVar.FiscalBuff.Fis_HeadPointer.FunN = FISHEADCHGLOG;

    ApplVar.FisNumber.TotalHeadChangeNum++;
    ApplVar.FiscalHead.FisHeadChgP = ApplVar.FiscalHead.MaxP;
    ApplVar.FiscalHead.MaxP += sizeof(ApplVar.FiscalBuff.Fis_HeadPointer);
    ApplVar.FiscalBuff.Fis_ReSet.FCRC = VerifyCRC((BYTE *)&ApplVar.FiscalBuff.Fis_ReSet,FRECORDLEN,1);
    Bios_FM_Write(ApplVar.FiscalHead.FisHeadChgP, &ApplVar.FiscalBuff, sizeof(ApplVar.FiscalBuff.Fis_HeadPointer));
    return 1;
}
    #endif

// ��˰�ؿ��ο���¼��FM����  //
short Fiscal_AddFMPullData()
{//ccr071212
    struct TimeDate sDate;

    if (ApplVar.FiscalHead.MaxP>=FISMEMERYSIZE)
        return 0;

    if (ApplVar.FiscalHead.FMPullP == 0)
        memset(&ApplVar.FiscalBuff,0,sizeof(ApplVar.FiscalBuff.Fis_FMPull));
    else
        if (!Bios_FM_Read(&ApplVar.FiscalBuff,ApplVar.FiscalHead.FMPullP,sizeof(ApplVar.FiscalBuff.Fis_FMPull)))
    {// error found when read from FM //
        ApplVar.FisCardFlag = FMERROR;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
        return 0;
    }

    GetTimeDate(&sDate);

    ApplVar.FiscalBuff.Fis_FMPull.FDate = EncordDate((sDate.year & 0x00ff),sDate.month,sDate.day);
    ApplVar.FiscalBuff.Fis_FMPull.FPullCount++;
    ApplVar.FiscalBuff.Fis_FMPull.FTime[0] = sDate.hour;
    ApplVar.FiscalBuff.Fis_FMPull.FTime[1] = sDate.min;
    ApplVar.FiscalBuff.Fis_FMPull.FTime[2] = sDate.sec;

    ApplVar.FiscalBuff.Fis_FMPull.FCRC = 0;
    ApplVar.FiscalBuff.Fis_FMPull.FunN = FISFMPULLLOG;

    ApplVar.FisNumber.TotalFMNum++;
    ApplVar.FiscalHead.FMPullP = ApplVar.FiscalHead.MaxP;
    ApplVar.FiscalHead.MaxP += sizeof(ApplVar.FiscalBuff.Fis_FMPull);

    ApplVar.FiscalBuff.Fis_FMPull.FCRC = VerifyCRC((BYTE *)&ApplVar.FiscalBuff.Fis_FMPull,FRECORDLEN,1);
    if (!Bios_FM_Write(ApplVar.FiscalHead.FMPullP, &ApplVar.FiscalBuff, sizeof(ApplVar.FiscalBuff.Fis_FMPull)))
    {//ccr070719>>>>>>>>>
        ApplVar.FisCardFlag = BADFM;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI76);
        return 0;
    }//<<<<<<<<<<<<<<<<<<<<<<<<

    return 1;
}
//��Z������ӡ��Ϻ�,����FiscalReport_End������д��FM
void FiscalReport_End()
{
    UnLong sLastZ;
//Write to FiscalRam-------------------------------
    if (Write_FiscalRam( ApplVar.FiscalHead.MaxP,&ApplVar.FiscalBuff.Fis_ClearRecord,FISRECORDLEN))
    {
        RESETBIT(ApplVar.Fiscal_PrintFlag,BIT2);
        ApplVar.FiscalHead.ClearP = ApplVar.FiscalHead.MaxP;//ccr070615
        ApplVar.FiscalHead.MaxP += FISRECORDLEN;

        memset(ApplVar.FisNumber.ReceiptNum,0,sizeof(ApplVar.FisNumber.ReceiptNum));//ccr091027
        ApplVar.SaleReceipts = 0;//ccr091027

        ApplVar.ZReport = 1;        /* set fiscal report taken */
        if (ApplVar.FReport == Z)
        {
            if (ApplVar.FTrain)//ccr090507 ApplVar.Report.PointerType == 1 && ApplVar.FTrain)   /* training clerk ? */
            {//ccr090507>>>>>>>>>>>>>>>>>>>>
                ApplVar.ZCount[TRAINNUM]++;//ccr090507
            }/* <<<<<<<<<not add with training clerk */
            else
            {
                ApplVar.FisNumber.TotalClearNum++;
                ApplVar.ZCount[REPZNUM] = ApplVar.FisNumber.TotalClearNum;//ccr091027 add to z -count
            }
        }

        //Clear ApplVar.Report-------------------------------
        SETBIT(ApplVar.MyFlags, ENPRINTER);//set the flag to clear data only
        SETBIT(ApplVar.Fiscal_PrintFlag, BIT5);//set the flag to clear data only
        GetReport(ApplVar.ReportNumber);
        RESETBIT(ApplVar.Fiscal_PrintFlag, BIT5);
        RESETBIT(ApplVar.MyFlags, ENPRINTER);
        //Clear ApplVar.Report-------------------------------
        //liuj 0602
        ApplVar.TotalMax = ApplVar.FExento = ZERO;     /* ccr090113 clear daily itemizers */
        ApplVar.FRetAmt = ApplVar.FRetTax = ZERO;
        ApplVar.FDiscAmt=ZERO;

//			 ApplVar.FTotal = ZERO;      /* ApplVar.FTax is soft total and cleared at start of report */

        memset(&ApplVar.FTotalItem,0,sizeof(ApplVar.FTotalItem));
        memset(&ApplVar.FTax,0,sizeof(ApplVar.FTax));

        ApplVar.FTotal_Flags = 0;
        ApplVar.Fiscal_PrintFlag = 0;   //Reset ApplVar.Fiscal_PrintFlag--
#if DD_FISPRINTER
        MemSet(&ApplVar.DiscountAmt, sizeof(ApplVar.DiscountAmt), 0);
        MemSet(&ApplVar.RefundAmt, sizeof(ApplVar.RefundAmt), 0);

        RESETBIT(ApplVar.Fiscal_Status, OVERDATE);
#endif

        sLastZ = (FISMEMERYSIZE-ApplVar.FiscalHead.MaxP)/FISRECORDLEN;
        if (!sLastZ )        /* only less then 60  reports left ? */
            ApplVar.ErrorNumber=ERROR_ID(CWXXI86);       /* memory broken */
        else if (sLastZ <= FISRECORD_LESS)
            ApplVar.ErrorNumber=ERROR_ID(CWXXI77) ;

#if defined(CASE_GPRS)
        if (TESTBIT(ApplVar.DaysMust,BIT7))//���Զ��������ݣ�����˰������
        {
            GPRSSendECR_FM();
        }
#endif
#if defined(CASE_ETHERNET)
        if (TESTBIT(ApplVar.DaysMust,BIT7))//���Զ��������ݣ�����˰������
        {
            ETHERNETSendECR_FM();
        }
#endif
    }
    else
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI76);     // write fiscal date error //
        ApplVar.FisCardFlag = BADFM;
        ApplVar.ZReport = 2;        /* take Z ApplVar.Report */
    }
//Write to FiscalRam-------------------------------
}
//cc 20070524>>>>>>>>>>>>>>>>>>>>>>>>

//��ӡZ����
void Print_FiscalReport()
{
//BYTE sTp;

    RESETBIT(ApplVar.Fiscal_PrintFlag,BIT7);

/*
#if DD_FISPRINTER == 1
            for(sTp=0;sTp<ApplVar.AP.Tax.Number;sTp++)
            {
                ApplVar.FTotalItem[sTp]= ZERO;
                ApplVar.FTax[sTp] = ZERO;
            }
#endif
*/
    do
    {
        if (TESTBIT(ApplVar.Fiscal_PrintFlag,BIT7))  //liuj 0528
        {
            RJPrint(0, MessageE60);
        }

        RESETBIT(ApplVar.Fiscal_PrintFlag,BIT7+BIT5);
        SETBIT(ApplVar.Fiscal_PrintFlag,BIT2);
        ApplVar.ErrorNumber=0;
        ApplVar.FReport = Z;
        ApplVar.ReportNumber = 1;
        ApplVar.RepComputer = 0;
        //��GetReport�е���PrintFiscalTax���Z�������ݵ����ɺʹ�ӡ
        GetReport(ApplVar.ReportNumber);
    }while (TESTBIT(ApplVar.Fiscal_PrintFlag,BIT7));

//ccr091228>>>>>>>>>>>>>>>>>>>>>
    if (ApplVar.FisCardFlag == BADEJ)
    {// ��ӡZ����ʱ,EJ������,��ʾ�Ƿ����  //
        RJPrint(0, BADEJBYZ);
        PutsO(PRINTZBADEJ);
        return;
    }
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    if (!ApplVar.FTrain) // ����ѵģʽ //
        FiscalReport_End();//����Z��������
    else
    {
        ApplVar.ZReport = 1;        /* set fiscal report taken */   //cc 20071026
        ApplVar.FTotal_Flags = 0;
    }

}

//��ӡ������۹�����Ŀ��Z�������ݺ�,��ӡ�ʹ洢Z�����Ļ�������
void PrintFiscalTax()
{
    int i ;
    WORD sYear,sMonth,sDay;
    BCD bcdtemp;


    if (ApplVar.FReport == Z)
    {
        PrintStr_Center((char *)Msg[SHKZBB].str,true);//~Z ~R~E~P~O~R~T
        PrintLine('=');

        memset(&ApplVar.FiscalBuff.Fis_ClearRecord,0,FRECORDLEN);//ccr2017-02-23
        ApplVar.FiscalBuff.Fis_ClearRecord.FCount = ApplVar.FisNumber.TotalClearNum;//ccr091027

        GetTimeDate(&Now);
        sYear = Now.year & 0x00ff;  sMonth = Now.month; sDay = Now.day;
        ApplVar.FiscalBuff.Fis_ClearRecord.FDate = EncordDate(sYear,sMonth,sDay);
        //time
        ApplVar.FiscalBuff.Fis_ClearRecord.FTime[0] = Now.hour;
        ApplVar.FiscalBuff.Fis_ClearRecord.FTime[1] = Now.min;
        ApplVar.FiscalBuff.Fis_ClearRecord.FTime[2] = Now.sec;

        //receipt number
        //ccr091027>>>>>>>>>
        ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice[FRECEIPTS] = ApplVar.SaleReceipts;//ccr091027
        ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice[NRECEIPTS] = ApplVar.FisNumber.ReceiptNum[NRECEIPTS];
        ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice[TRECEIPTS] = ApplVar.FisNumber.ReceiptNum[TRECEIPTS];

        ApplVar.FiscalBuff.Fis_ClearRecord.FInvSum[FRECEIPTS] = ApplVar.FisNumber.TotalReceiptNum[FRECEIPTS];//ccr091027
        ApplVar.FiscalBuff.Fis_ClearRecord.FInvSum[NRECEIPTS] = ApplVar.FisNumber.TotalReceiptNum[NRECEIPTS];//ccr091027
        ApplVar.FiscalBuff.Fis_ClearRecord.FInvSum[TRECEIPTS] = ApplVar.FisNumber.TotalReceiptNum[TRECEIPTS];//ccr091027
        //<<<<<<<<<<<<<<<<<<

        ApplVar.FiscalBuff.Fis_ClearRecord.FInvoiceDate = ApplVar.LastInvoiceDate;
        memcpy(ApplVar.FiscalBuff.Fis_ClearRecord.FInvoiceTime, ApplVar.LastInvoiceTime, 3);

#if(DD_MMC)
        ApplVar.FiscalBuff.Fis_ClearRecord.FEJID = ApplVar.Fis_EJTbl.FAddCode;
#else
        ApplVar.FiscalBuff.Fis_ClearRecord.FEJID = 1;       //20070118
#endif


        //Func Num = 0xa0
        ApplVar.FiscalBuff.Fis_ClearRecord.FunN = FISCLEARLOG;

        BCDValueToULong(ApplVar.FExento.Value, (unsigned long *)&ApplVar.FiscalBuff.Fis_ClearRecord.NoTaxSale);
        if (ApplVar.FExento.Sign & 0x80)
            ApplVar.FiscalBuff.Fis_ClearRecord.NoTaxSale = -ApplVar.FiscalBuff.Fis_ClearRecord.NoTaxSale;
#if defined(CASE_MALTA)
        for(ApplVar.TaxNumber=0;ApplVar.TaxNumber<ApplVar.AP.Tax.Number;ApplVar.TaxNumber++)
		{
			BCDValueToULong(ApplVar.FTotalItem[ApplVar.TaxNumber].Value, (unsigned long *)&ApplVar.FiscalBuff.Fis_ClearRecord.FTaxSale[ApplVar.TaxNumber]);
	        if(ApplVar.FTotalItem[ApplVar.TaxNumber].Sign & 0x80) // liuj 0912 e
	               ApplVar.FiscalBuff.Fis_ClearRecord.FTaxSale[ApplVar.TaxNumber] =
                        -ApplVar.FiscalBuff.Fis_ClearRecord.FTaxSale[ApplVar.TaxNumber];
			BCDValueToULong(ApplVar.FTax[ApplVar.TaxNumber].Value, (unsigned long *)&ApplVar.FiscalBuff.Fis_ClearRecord.FTaxAmt[ApplVar.TaxNumber]);
	        if(ApplVar.FTax[ApplVar.TaxNumber].Sign & 0x80)// liuj 0912 e
	              ApplVar.FiscalBuff.Fis_ClearRecord.FTaxAmt[ApplVar.TaxNumber] =
                        -ApplVar.FiscalBuff.Fis_ClearRecord.FTaxAmt[ApplVar.TaxNumber];

            ReadTax();
            CWORD(ApplVar.CurrentTaxRate[ApplVar.TaxNumber][0]) = CWORD(ApplVar.Tax.Rate[0]);

		}

		BCDValueToULong(ApplVar.FRetAmt.Value, (unsigned long *)&ApplVar.FiscalBuff.Fis_ClearRecord.ReturnAmt);
		BCDValueToULong(ApplVar.FRetTax.Value, (unsigned long *)&ApplVar.FiscalBuff.Fis_ClearRecord.ReturnTax);
		memset(&ApplVar.FRetAmt,0,sizeof(ApplVar.FRetAmt));
		memset(&ApplVar.FRetTax,0,sizeof(ApplVar.FRetTax));

		ApplVar.FiscalBuff.Fis_ClearRecord.FCRC = VerifyCRC((BYTE *)&ApplVar.FiscalBuff.Fis_ClearRecord,FISRECORDLEN,1);

#endif

        Print_FiscalData(FISCLEARLOG);

#if (defined(CASE_MALTA))  // liuj 0810
        //PrintLine('=');//��Լֽ��
        RJPrint(0, CUMULATIVE);//"   CUMULATIVE TOTALS"
        PrintLine('=');
#endif

        RJPrint(0, Msg[ZONGJI].str);//Total
#if (defined(CASE_MALTA))
        ApplVar.Qty3 =ZERO;
#endif

        for (i=0;i<ApplVar.AP.Tax.Number;i++)
        {
            if (CheckNotZero(&ApplVar.FTaxTotal[i]))
            {
#if (defined(CASE_MALTA))
                //ReadTax();
                Add(&ApplVar.Qty3,&ApplVar.FTaxTotal[i]);
#else
                RJPrint(0,FormatAmtStr(Msg[VATA+i].str,&ApplVar.FTaxTotal[i],PRTLEN));//ccr070424
#endif
            }
        }
#if (defined(CASE_MALTA))
        RJPrint(0,FormatAmtStr(Msg[TAXTOTAL].str,&ApplVar.Qty3,PRTLEN));//TAX SUM
#endif
        bcdtemp = ZERO;
        ULongToBCDValue(bcdtemp.Value, ApplVar.FisNumber.TotalReceiptNum[FRECEIPTS]);//ccr091027
        RJPrint(0, FormatQtyStr(Msg[FAPIAOHAO].str, &bcdtemp, PRTLEN)); // liuj 0829

        PrintAmt(Msg[HSJXSHOU].str, &ApplVar.FTotal);  //liuj 0606

    }

    ApplVar.FisNumber.LastZDate= ApplVar.FiscalBuff.Fis_ClearRecord.FDate;            //20070313
    memcpy(ApplVar.FisNumber.LastZTime, ApplVar.FiscalBuff.Fis_ClearRecord.FTime, sizeof(ApplVar.FisNumber.LastZTime));

    Bell(2);

    PrintFiscalAttribute();//ccr071212

}


void FiscalTrailer()
{
    BYTE i;
#if (defined(CASE_MALTA))

#if DD_MMC == 1
    if (TESTBIT(ApplVar.ContFlag,ENSTORE))   // liuj 0528
    {
#if !defined(CASE_ITALIA)
            memset(SysBuf,' ',PRTLEN);
#if (RIFMUST)//PANAMA
            strcpy(SysBuf, Msg[RIFCODE].str);
            strcat(SysBuf, ApplVar.Fis_Header.FRIFNumber);
            i =strlen(SysBuf);
            SysBuf[i]=' ';
#elif (DEVICEMUST)//PANAMA
            strcpy(SysBuf, DEVICECODE, strlen(DEVICECODE));
            strcat(SysBuf, ApplVar.Fis_Header.FDeviceCode);
            i =strlen(SysBuf);
            SysBuf[i]=' ';
#else
            CopyFrStr(SysBuf,MESG_EJ_REC);
#endif
            sprintf(SysBuf+PRTLEN-9,"E%.8lu",ApplVar.EJLogHeader.DocNumber_EJ);//ccr091103
            RJPrint(0, SysBuf);     //liuj 0528

#if (RIFMUST && DEVICEMUST)//PANAMA
            memset(SysBuf, ' ', PRTLEN);
            CopyFrStr(SysBuf, DEVICECODE);
            strcpy(SysBuf+PRTLEN-strlen(ApplVar.Fis_Header.FDeviceCode), ApplVar.Fis_Header.FDeviceCode);
            SysBuf[PRTLEN] = 0;
            RJPrint(0, SysBuf);
#endif
#endif
    }

#else //DD_MMC == 1

#if (RIFMUST)//PANAMA
            memset(SysBuf, ' ', PRTLEN);
            CopyFrStr(SysBuf, Msg[RIFCODE].str);
            strcpy(SysBuf+PRTLEN-strlen(ApplVar.Fis_Header.FRIFNumber), ApplVar.Fis_Header.FRIFNumber);
            SysBuf[PRTLEN] = 0;
            RJPrint(0, SysBuf);
#endif
#if (DEVICEMUST)//PANAMA
            memset(SysBuf, ' ', PRTLEN);
            memcpy(SysBuf, DEVICECODE, strlen(DEVICECODE));
            strcpy(SysBuf+PRTLEN-strlen(ApplVar.Fis_Header.FDeviceCode), ApplVar.Fis_Header.FDeviceCode);
            SysBuf[PRTLEN] = 0;
            RJPrint(0, SysBuf);
#endif
#endif

    memcpy(SysBuf, ApplVar.GrafTexts[0], sizeof(ApplVar.GrafTexts[0]));//����GrafTexts[0]��GrafTexts[1]
    SysBuf[PRTLEN+2]=ApplVar.GrafTexts[1][0];

    //copy serial number to graphic text
    memset(&ApplVar.GrafTexts[0][0], ' ', sizeof(ApplVar.GrafTexts[0]));
#if (PRTLEN<25)
#if CASE_ITALIA
    ApplVar.GrafTexts[0][9] = 'T';
    ApplVar.GrafTexts[0][10] = 'W' ;
    strncpy(&ApplVar.GrafTexts[0][11], ApplVar.Fis_Header.FFisCode,MAX_FISCAL_CODE);
#elif defined(CASE_MALTA)
    ApplVar.GrafTexts[0][9] = 'K';
    ApplVar.GrafTexts[0][10] = 'G' ;
    strncpy(&ApplVar.GrafTexts[0][12], ApplVar.Fis_Header.FFisCode,MAX_FISCAL_CODE);
#else
    strncpy(&ApplVar.GrafTexts[0][9], ApplVar.Fis_Header.FFisCode,MAX_FISCAL_CODE);
#endif
#else
#if CASE_ITALIA
    ApplVar.GrafTexts[0][15] = 'T';
    ApplVar.GrafTexts[0][16] = 'W' ;
    strncpy(&ApplVar.GrafTexts[0][18], ApplVar.Fis_Header.FFisCode,MAX_FISCAL_CODE);
#elif defined(CASE_MALTA)
    ApplVar.GrafTexts[0][15] = 'K';
    ApplVar.GrafTexts[0][16] = 'G' ;
    strncpy(&ApplVar.GrafTexts[0][18], ApplVar.Fis_Header.FFisCode,MAX_FISCAL_CODE);
#else
    strncpy(&ApplVar.GrafTexts[0][15], ApplVar.Fis_Header.FFisCode,MAX_FISCAL_CODE);
#endif
#endif
    ApplVar.GrafTexts[0][PRTLEN] = 0;
    ApplVar.GrafTexts[1][0]=0;

#if !defined(DEBUGBYPC)
#if (PC_EMUKEY)
    if (!FisTestTask.PrnOFF)  //ccr080519 added for control the printing of pb message
#endif
        if (!TESTBIT(ApplVar.MyFlags, ENPRINTER))//��ӡ˰��ͼ��(LOGO),����˰����
#if (PRTLEN<25)
            Bios(BiosCmd_PrintGraph, (void*)(GRAPHICMAX), 1 , 7); //�ڵ�7���ַ�λ�ô�ӡ˰��Logo,����GrafTexts[0]������
#else
        Bios(BiosCmd_PrintGraph, (void*)(GRAPHICMAX), 1 , 0); //�ڵ�7���ַ�λ�ô�ӡ˰��Logo,����GrafTexts[0]������
#endif

    memcpy(ApplVar.GrafTexts[0], SysBuf, sizeof(ApplVar.GrafTexts[0]));//�ָ�GrafTexts[0]��GrafTexts[1]
    ApplVar.GrafTexts[1][0]=SysBuf[PRTLEN+2];

    RFeed(1);
#else
    CopyFrStr(SysBuf+(PRTLEN-strlen(ApplVar.Fis_Header.FFisCode)-3)/2, (CONSTCHAR*)"@LG");
    CopyFrStr(SysBuf+(PRTLEN-strlen(ApplVar.Fis_Header.FFisCode)+3)/2, (CONSTCHAR*)ApplVar.Fis_Header.FFisCode);
    SysBuf[PRTLEN] = 0;
    RJPrint(0, SysBuf);
#endif

#else//defined(CASE_MALTA)

    memset(SysBuf, ' ', PRTLEN);
#if DD_MMC == 1 // liuj 0531 PM
    if (TESTBIT(ApplVar.ContFlag,ENSTORE))   // liuj 0528
    {
        i = sprintf(SysBuf,"E%.8lu",ApplVar.EJLogHeader.DocNumber_EJ);//ccr091103
        SysBuf[i]=' ';

        CopyFrStr(SysBuf+(PRTLEN-strlen(ApplVar.Fis_Header.FFisCode)-strlen(Msg[TAXCODE].str))/2+5, (CONSTCHAR*)Msg[TAXCODE].str);
        CopyFrStr(SysBuf+(PRTLEN-strlen(ApplVar.Fis_Header.FFisCode)+strlen(Msg[TAXCODE].str))/2+5, (CONSTCHAR*)ApplVar.Fis_Header.FFisCode);
    }
    else
#endif
    {
/*		CopyFrStr(SysBuf+(PRTLEN-strlen(ApplVar.Fis_Header.FFisCode)-strlen(Msg[TAXCODE].str))/2, (CONSTCHAR*)Msg[TAXCODE].str);
        CopyFrStr(SysBuf+(PRTLEN-strlen(ApplVar.Fis_Header.FFisCode)+strlen(Msg[TAXCODE].str))/2, (CONSTCHAR*)ApplVar.Fis_Header.FFisCode);*/


#if (PRN_SHCP)
        i = 10;
        SysBuf[i++] = '~'; SysBuf[i++] = SHCP_S;
        SysBuf[i++] = '~'; SysBuf[i++] = SHCP_H;
        SysBuf[PRTLEN] = 0;
        PrintStr(SysBuf);
        i = 11;
        memset(SysBuf, ' ', PRTLEN);
        SysBuf[i++] = '~'; SysBuf[i++] = SHCP_C;
        SysBuf[i++] = '~'; SysBuf[i++] = SHCP_P;
        i+=4;
        CopyFrStr(SysBuf+i, (CONSTCHAR*)ApplVar.Fis_Header.FFisCode);
#else
        CopyFrStr(SysBuf+(PRTLEN-strlen(ApplVar.Fis_Header.FFisCode)-strlen(Msg[TAXCODE].str))/2, (CONSTCHAR*)Msg[TAXCODE].str);
        CopyFrStr(SysBuf+(PRTLEN-strlen(ApplVar.Fis_Header.FFisCode)+strlen(Msg[TAXCODE].str))/2, (CONSTCHAR*)ApplVar.Fis_Header.FFisCode);
#endif

    }
    SysBuf[PRTLEN] = 0;
    PrintStr(SysBuf);

#if (RIFMUST)//PANAMA
    PrintMessagesBy(Msg[RIFCODE].str,ApplVar.Fis_Header.FRIFNumber,strlen(ApplVar.Fis_Header.FRIFNumber));
#endif
#if (DEVICEMUST)//PANAMA
    PrintMessagesBy(DEVICECODE,ApplVar.Fis_Header.FDeviceCode,strlen(ApplVar.Fis_Header.FDeviceCode));
#endif

#if (VV_RUSSIA)
    memset(SysBuf,0x1d,PRTLEN);
    SysBuf[PRTLEN/2-1]=0x1e;    SysBuf[PRTLEN/2]=0x1f;
    SysBuf[PRTLEN] = 0;
    PrintStr(SysBuf);// print fiscal flag line
#endif

#endif
}
/*ccr2014-PANAMA>>>>��ӡ����Ĺ˿���Ϣ
#define cFCName   BIT0	//1-�˿�����
#define cFCRUC	  BIT1	//2-�˿�RUC,
#define cFCDebit  BIT3	//3-�����վݺ�
#define cFCAddr   BIT4	//4-�˿͵�ַ
#define cFVatNo   BIT5   //5-��������վݵĹ˿�˰����
*/
void   PrintUserInput()
{
    int i;
    if (ApplVar.UserInfo.InputType)//������ʱ,�Ŵ�ӡ
    {
        RJPrint(0,MESG_CUSTOMER);
        if (TESTBIT(ApplVar.UserInfo.InputType,cFCName))
        {//��ӡ�����û�RUC������
            memset(SysBuf,0,PRTLEN);

            i = strlen(USERPROMPT[cFCNameID].str);
            CopyFrStr(SysBuf,USERPROMPT[cFCNameID].str);
            strncpy(SysBuf+i, ApplVar.UserInfo.FCName,PRTLEN-i);
            SysBuf[PRTLEN] = 0;
            RJPrint(0,SysBuf);
            //RESETBIT(ApplVar.UserInfo.InputType,cFCName);
        }
        if (TESTBIT(ApplVar.UserInfo.InputType,cFCRUC))
        {//��ӡ�����û�RUC������
            memset(SysBuf,0,PRTLEN);

            i = strlen(USERPROMPT[cFCRUCID].str);
            CopyFrStr(SysBuf,USERPROMPT[cFCRUCID].str);
            strncpy(SysBuf+i, ApplVar.UserInfo.FCRUC,PRTLEN-i);
            SysBuf[PRTLEN] = 0;
            RJPrint(0,SysBuf);
            //RESETBIT(ApplVar.UserInfo.InputType,cFCRUC);
        }
        if (TESTBIT(ApplVar.UserInfo.InputType,cFCDebit))
        {//��ӡ�����û�RUC������
            memset(SysBuf,0,PRTLEN);

            i = strlen(USERPROMPT[cFCDebitID].str);
            CopyFrStr(SysBuf,USERPROMPT[cFCDebitID].str);
            strncpy(SysBuf+i, ApplVar.UserInfo.FCDebit,PRTLEN-i);
            SysBuf[PRTLEN] = 0;
            RJPrint(0,SysBuf);
            //RESETBIT(ApplVar.UserInfo.InputType,cFCDebit);
        }
        if (TESTBIT(ApplVar.UserInfo.InputType,cFCAddr))
        {//��ӡ�����û�RUC������
            memset(SysBuf,0,PRTLEN);

            i = strlen(USERPROMPT[cFCAddrID].str);
            CopyFrStr(SysBuf,USERPROMPT[cFCAddrID].str);
            strncpy(SysBuf+i, ApplVar.UserInfo.FCAddr,PRTLEN-i);
            SysBuf[PRTLEN] = 0;
            RJPrint(0,SysBuf);
            //RESETBIT(ApplVar.UserInfo.InputType,cFCAddr);
        }
        if (TESTBIT(ApplVar.UserInfo.InputType,cFVatNo))
        {//��ӡ�����û�RUC������
            memset(SysBuf,0,PRTLEN);

            i = strlen(USERPROMPT[cFVatNoID].str);
            CopyFrStr(SysBuf,USERPROMPT[cFVatNoID].str);
            strncpy(SysBuf+i, ApplVar.UserInfo.FVatNo,PRTLEN-i);
            SysBuf[PRTLEN] = 0;
            RJPrint(0,SysBuf);
            //RESETBIT(ApplVar.UserInfo.InputType,cFVatNo);
        }
        PrintLine2('-');
    }
}
//<<<<PANAMA
//��Ʊͷ��ӡ˰����Ϣ
void FiscalHeader()
{
/* liuj 0529
        memset(SysBuf,' ',sizeof(SysBuf));
        CopyFrStr(SysBuf+((PRTLEN-strlen(Msg[SENIAT].str))/2),Msg[SENIAT].str);
        SysBuf[PRTLEN] = 0;
        RJPrint(0,SysBuf);
*/
//* 20070313 VZLA format

#if (0)//(RIFMUST)// DD_FISPRINTER // liuj 0806

        memset(SysBuf, ' ', sizeof(SysBuf));
        memcpy(SysBuf, Msg[RIFCODE].str, strlen(Msg[RIFCODE].str));
        strcpy(SysBuf+PRTLEN-strlen(ApplVar.Fis_Header.FRIFNumber), ApplVar.Fis_Header.FRIFNumber);
        SysBuf[PRTLEN] = 0;
        RJPrint(0, SysBuf);
#endif
/*		memset(SysBuf, ' ', sizeof(SysBuf));
        CopyFrStr(SysBuf+(PRTLEN-strlen(ApplVar.Fis_Header.FRIFNumber))/2, (CONSTCHAR*)ApplVar.Fis_Header.FRIFNumber);
        SysBuf[PRTLEN] = 0;
        RJPrint(0, SysBuf);	*/
}

// liuj for debug
BYTE CheckExento()
{
    return 	1;
}

//write heading change info to fiscal card
//printIT:������Ƿ��ӡ
void ProcessHead(bool printIT)
{
    BYTE sTpt,j;
    WORD sYear,sMonth,sDay;
    ULONG HeadAdr,sLastZ;
    short sActive;
    BCD sVal;

#if DD_FISPRINTER == 0
    if (ApplVar.FMPullOut[NEWHEAD_FLAG]!=0x69)//ccr070609pm
        return;
    else
        ApplVar.FMPullOut[NEWHEAD_FLAG]=0;
#endif
    sYear = (PRTLEN>50)?50:PRTLEN;

    sActive = false;
    for (sTpt=0;sTpt<8;sTpt++)
    {
        for (j=0;j<sYear;j++)
        {
            if (ApplVar.Fis_HeadChg.FNewHead[(sTpt*sYear)+j] != ApplVar.TXT.Header[sTpt][j])
            {
                ApplVar.Fis_HeadChg.FNewHead[(sTpt*sYear)+j] = ApplVar.TXT.Header[sTpt][j];
                sActive = true;
            }
        }
    }

    if (!sActive)
        return;
/*ccr070423/------------------liuj modify 070410 ----------------
    if( ApplVar.FisNumber.TotalHeadChangeNum>FHEADCHGMAX)
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI76);		// ccr070423 write fiscal date error
        return;
    }
//------------------liuj modify 070410 ----------------	*/
    //process head string
    //CRC
    ApplVar.Fis_HeadChg.FCRC = VerifyCRC((BYTE *)&ApplVar.Fis_HeadChg,FHEADCHGLEN,1);
    ApplVar.Fis_HeadChg.FunN = FISHEADLOG;

    HeadAdr = FISHEADCHGADDR+ApplVar.FisNumber.TotalHeadChangeNum*FHEADCHGLEN;
    if (!Write_FiscalRam(HeadAdr+400,&ApplVar.Fis_HeadChg.FCRC,2))
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI76);     /* write fiscal date error */
    }
    for (sTpt=0;sTpt<8;sTpt++)
    {
        if (!Write_FiscalRam(HeadAdr,&ApplVar.Fis_HeadChg.FNewHead[sTpt*sYear], sYear))
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI76);     /* write fiscal date error */
        }
        HeadAdr += PRTLEN;
    }
    if (ApplVar.ErrorNumber)
        return;


    //process head pointer
    memset(&ApplVar.FiscalBuff.Fis_HeadPointer,0,sizeof(ApplVar.FiscalBuff.Fis_HeadPointer));
    GetTimeDate(&Now);
    sYear = Now.year & 0x00ff;  sMonth = Now.month; sDay = Now.day;
    ApplVar.FiscalBuff.Fis_HeadPointer.FDate = EncordDate(sYear,sMonth,sDay);

    //time
    ApplVar.FiscalBuff.Fis_HeadPointer.FTime[0] = Now.hour;
    ApplVar.FiscalBuff.Fis_HeadPointer.FTime[1] = Now.min;
    ApplVar.FiscalBuff.Fis_HeadPointer.FTime[2] = Now.sec;

    //Count
//	ApplVar.FiscalBuff.Fis_HeadPointer.FChgCount = ApplVar.FisNumber.HeadChangeNum + 1;
    ApplVar.FiscalBuff.Fis_HeadPointer.FChgCount = ApplVar.FisNumber.TotalHeadChangeNum + 1; // liuj modify 080527

    //new pointer of heading
    HeadAdr = FISHEADCHGADDR+ApplVar.FisNumber.TotalHeadChangeNum*FHEADCHGLEN;
    ApplVar.FiscalBuff.Fis_HeadPointer.FNewPointer = HeadAdr;

    //old pointer of heading
    //ApplVar.FiscalBuff.Fis_HeadPointer.FOldPointer = 0;

    //CRC
    ApplVar.FiscalBuff.Fis_HeadPointer.FCRC = VerifyCRC((BYTE *)&ApplVar.FiscalBuff.Fis_HeadPointer,FISRECORDLEN,1);

    ApplVar.FiscalBuff.Fis_HeadPointer.FunN = FISHEADCHGLOG;

    if (Write_FiscalRam( ApplVar.FiscalHead.MaxP,&ApplVar.FiscalBuff.Fis_HeadPointer,sizeof(ApplVar.FiscalBuff.Fis_HeadPointer)))
    {
        ApplVar.FiscalHead.FisHeadChgP = ApplVar.FiscalHead.MaxP;//ccr070615
        ApplVar.FiscalHead.MaxP += FISRECORDLEN;

        ApplVar.FisNumber.HeadChangeNum++;
        ApplVar.FisNumber.TotalHeadChangeNum++;
///////////////liuj 0612
        sLastZ = (FISMEMERYSIZE-ApplVar.FiscalHead.MaxP)/FISRECORDLEN;
        if (!sLastZ )        /* only less then 60  reports left ? */
            ApplVar.ErrorNumber=ERROR_ID(CWXXI86);       /* memory broken */
        else if (sLastZ <= FISRECORD_LESS)
            ApplVar.ErrorNumber=ERROR_ID(CWXXI77) ;
///////////////liuj 0612

    }
    else
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI76);     /* write fiscal date error */
        return;
    }

    Save_ConfigVar(true);

    if (printIT)
    {
    #if DD_FISPRINTER == 0

    #if DD_MMC //ccr070610>>>>>>>>>>>>>>>>>>
        StoreEJEnd();
        ApplVar.EJContent = TXTCONT;
        SETBIT(ApplVar.ContFlag, (ENSTORE|ENHEADER));
    #endif//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

        PrintLine('=');

        sVal = ZERO;//ccr071212
        WORDtoBCD(sVal.Value, ApplVar.FisNumber.TotalHeadChangeNum);
        FormatQtyStr(Msg[CHANGEHEAD].str,&sVal,PRTLEN-5);
        SysBuf[PRTLEN-5]=' ';   SysBuf[PRTLEN-4]='/';
        WORDtoASC(SysBuf+PRTLEN-1,FHEADCHGMAX);
        SysBuf[PRTLEN]=0;
        RJPrint(0,SysBuf);

        PrintLine('-');
        if (ApplVar.TXT.Header[0][0])
        {
            RFeed(1);
            for (j = 0; j < 8; j++)
            {
                if (ApplVar.TXT.Header[j][0])
                {
                    PrintRJ(ApplVar.TXT.Header[j]);
                }
                else
                    break;
            }
        }
    //	FiscalTrailer();//ccr070610??????????????????
        PrintLine2('=');

    /*
    #if DD_MMC//ccr070610
        ApplVar.EJContent = ENDCONT;
        SETBIT(ApplVar.ContFlag, ENSTORE);
    #endif
        PrintLine2('=');

    */
    //liuj 0610
        ApplVar.FStatus = 0;
        AddReceiptNumber();
        ApplVar.FReceipt =1;
        ReceiptIssue(1);
        RESETBIT(ApplVar.MyFlags,PRNTRAI);  //liuj 0610
    #endif
    //liuj 0610
    }

}


//write tax change info to fiscal card
//sSaveFM:=true Store TAX to FM only,not print
void ProcessTax(BYTE sSaveFM)
{
    WORD sYear,sMonth,sDay;
    UnLong sLastZ;
    BCD sVal;

//ccr070615>>>>>>
#if DD_FISPRINTER == 0
    if (ApplVar.FMPullOut[NEWTAX_FLAG]!=0x69)//ccr070609pm
        return;
    else
        ApplVar.FMPullOut[NEWTAX_FLAG]=0;
#endif
    memset(&ApplVar.FiscalBuff.Fis_TaxRate,0,sizeof(ApplVar.FiscalBuff.Fis_TaxRate));
    for (ApplVar.TaxNumber=0;ApplVar.TaxNumber<ApplVar.AP.Tax.Number;ApplVar.TaxNumber++)
    {
        ReadTax();
        CWORD(ApplVar.FiscalBuff.Fis_TaxRate.FNTaxRate[ApplVar.TaxNumber][0]) = CWORD(ApplVar.Tax.Rate[0]);
        if (CWORD(ApplVar.CurrentTaxRate[ApplVar.TaxNumber][0]) != CWORD(ApplVar.Tax.Rate[0]))
        {
            ApplVar.FMPullOut[NEWTAX_FLAG]=0x69;
        }
    }
#if DD_FISPRINTER == 0
    if (ApplVar.FMPullOut[NEWTAX_FLAG]!=0x69 && !sSaveFM)
        return;
#endif
    ApplVar.FMPullOut[NEWTAX_FLAG]=0;

    memcpy(ApplVar.FiscalBuff.Fis_TaxRate.FOTaxRate,ApplVar.CurrentTaxRate,sizeof(ApplVar.FiscalBuff.Fis_TaxRate.FOTaxRate));//ccr070615
    //Date
    GetTimeDate(&Now);
    sYear = Now.year & 0x00ff;  sMonth = Now.month; sDay = Now.day;
    ApplVar.FiscalBuff.Fis_TaxRate.FDate = EncordDate(sYear,sMonth,sDay);

    //time
    ApplVar.FiscalBuff.Fis_TaxRate.FTime[0] = Now.hour;
    ApplVar.FiscalBuff.Fis_TaxRate.FTime[1] = Now.min;
    ApplVar.FiscalBuff.Fis_TaxRate.FTime[2] = Now.sec;

    //change count
    ApplVar.FiscalBuff.Fis_TaxRate.FChgCount = ApplVar.FisNumber.TaxChangeNum + 1;

    //CRC
    ApplVar.FiscalBuff.Fis_TaxRate.FCRC = VerifyCRC((BYTE *)&ApplVar.FiscalBuff.Fis_TaxRate,FISRECORDLEN,1);

    //Func Num = 0xa3
    ApplVar.FiscalBuff.Fis_TaxRate.FunN = FISTAXLOG;

    if (Write_FiscalRam(ApplVar.FiscalHead.MaxP,&ApplVar.FiscalBuff.Fis_TaxRate,FISRECORDLEN))
    {
        memcpy(ApplVar.CurrentTaxRate, ApplVar.FiscalBuff.Fis_TaxRate.FNTaxRate,sizeof(ApplVar.FiscalBuff.Fis_TaxRate.FOTaxRate));//ccr070615
        ApplVar.FiscalHead.TaxRateP = ApplVar.FiscalHead.MaxP;//ccr070615

        ApplVar.FiscalHead.MaxP += FISRECORDLEN;

        ApplVar.FisNumber.TaxChangeNum++;
        ApplVar.FisNumber.TotalTaxChangeNum++;
//ccr070615		memset(&ApplVar.FiscalBuff.Fis_TaxRate,0,sizeof(ApplVar.FiscalBuff.Fis_TaxRate));
        sLastZ = (FISMEMERYSIZE-ApplVar.FiscalHead.MaxP)/FISRECORDLEN;
        if (!sLastZ )        /* only less then 60  reports left ? */
            ApplVar.ErrorNumber=ERROR_ID(CWXXI86);       /* memory broken */
        else if (sLastZ <= FISRECORD_LESS)
            ApplVar.ErrorNumber=ERROR_ID(CWXXI77) ;

    }
    else
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI76);     /* write fiscal date error */
        return;//ccr070610
    }
#if DD_FISPRINTER == 0
    if (!sSaveFM)
    {
#if DD_MMC //ccr070610>>>>>>>>>>>>>>>>>>
        StoreEJEnd();
        ApplVar.EJContent = TXTCONT;
        SETBIT(ApplVar.ContFlag, (ENSTORE|ENHEADER));
#endif//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        PrintLine('=');

        sVal = ZERO;//ccr071212
        WORDtoBCD(sVal.Value,ApplVar.FisNumber.TotalTaxChangeNum);
        FormatQtyStr(Msg[CHANGETAX].str,&sVal,PRTLEN-5);
        SysBuf[PRTLEN-5]=' ';   SysBuf[PRTLEN-4]='/';
        WORDtoASC(SysBuf+PRTLEN-1,FTAXCHGMAX);
        SysBuf[PRTLEN]=0;
        RJPrint(0,SysBuf);


        PrintLine('-');
        DumpTax();

        PrintLine('=');

        ApplVar.FStatus = 0;
        AddReceiptNumber();
        ApplVar.FReceipt =1;
        ReceiptIssue(1);
        RESETBIT(ApplVar.MyFlags,PRNTRAI);  //liuj 0610
        //liuj 0610
    }
#endif
}
////////////////////////////////////////////////////////
#if DD_FISPRINTER == 0
//ccr2014-PANAMA>>>>
/* return:length of input */
BYTE GetUserOpt(BYTE type, char *opt,BYTE  size)
{
	int	sLp,sP;
	BYTE  sByte,sLen=0;

	MemSet(ProgLineMes, sizeof(ProgLineMes), ' ');
#if(DD_ZIP==1 || DD_ZIP_21==1)
	MemSet(ProgLine1Mes,sizeof(ProgLine1Mes),' ');
#endif

    if (size)
    {
        if (Appl_EntryCounter)
        {
            GetCaption(opt, size);
            if (Appl_EntryCounter<size)
                opt[Appl_EntryCounter]=0;
            SETBIT(ApplVar.MyFlags,CONFIGECR);//�޸�������ĵ�ǰֵ
        }

        if (ProgStart == 2)
            sP = 0;
        else
        {
            sP = strlen(USERPROMPT[type].str);//lCAPWIDTH;
            CopyFrStr(ProgLineMes, USERPROMPT[type].str);
        }
        for (sLp=0;sLp<Appl_EntryCounter;sLp++)
        {
            sByte =opt[sLp];

#if(DD_ZIP==1 || DD_ZIP_21==1)
            ProgLine1Mes[sLp] = sByte;
#else
            ProgLineMes[sP++] = sByte;
#endif
            if (sByte==0)
                break;
            if (sByte!=' ')
                sLen = sLp+1;
        }
        if (Appl_EntryCounter==0)
        {//��ʾ��ǰ���뷽��
            if (TESTBIT(ApplVar.MyFlags, NUM_ASCII))//��ǰ��ʽΪ�������뷽ʽ
                ProgLineMes[DISLEN-1]='9';
            else if (TESTBIT(ApplVar.MyFlags, UPASCII))//��ǰ��ʽΪA
                ProgLineMes[DISLEN-1]='A';
            else//��ǰ��ʽΪa
                ProgLineMes[DISLEN-1]='a';
        }
        if (ProgStart == 2)
            return sLen;
    }
    ProgLine++;
    return sLen;
}
/*
SETUSERINFO:
#define cFCNameID   0	//1-�˿�����
#define cFCRUCID	1	//2-�˿�RUC,
#define cFCDebitID  2	//3-�����վݺ�
#define cFCAddrID   3	//4-�˿͵�ַ
#define cFVatNoID   4   //5-��������վݵĹ˿�˰����
*/
void ProgUserInfo(int type)
{
    char *sUser;

    switch (ProgLine)
    {
    case 1:
        switch (type)
        {
        case cFCNameID:memset(ApplVar.UserInfo.FCName,0,sizeof(ApplVar.UserInfo.FCName));   SetInputMode('a');  break;
        case cFCAddrID:memset(ApplVar.UserInfo.FCAddr,0,sizeof(ApplVar.UserInfo.FCAddr));   SetInputMode('a');  break;
        case cFCRUCID:memset(ApplVar.UserInfo.FCRUC,0,sizeof(ApplVar.UserInfo.FCRUC));      SetInputMode('a');  break;
        case cFVatNoID:memset(ApplVar.UserInfo.FVatNo,0,sizeof(ApplVar.UserInfo.FVatNo));   SetInputMode('9');  break;
        case cFCDebitID:memset(ApplVar.UserInfo.FCDebit,0,sizeof(ApplVar.UserInfo.FCDebit));SetInputMode('9');  break;
        }
     case 2:
     case 3:
        switch (type)
        {
        case cFCNameID:Appl_MaxEntry=sizeof(ApplVar.UserInfo.FCName);sUser=ApplVar.UserInfo.FCName;   break;
        case cFCAddrID:Appl_MaxEntry=sizeof(ApplVar.UserInfo.FCAddr);sUser=ApplVar.UserInfo.FCAddr;   break;
        case cFCRUCID:Appl_MaxEntry=sizeof(ApplVar.UserInfo.FCRUC); sUser=ApplVar.UserInfo.FCRUC;  break;
        case cFVatNoID:Appl_MaxEntry=sizeof(ApplVar.UserInfo.FVatNo); sUser=ApplVar.UserInfo.FVatNo;  break;
        case cFCDebitID:Appl_MaxEntry=sizeof(ApplVar.UserInfo.FCDebit);sUser=ApplVar.UserInfo.FCDebit;   break;
        }

        if (GetUserOpt(type, sUser, Appl_MaxEntry) && Appl_EntryCounter)
            ApplVar.UserInfo.InputType |= 1<<ApplVar.UserInfo.InputIDX;//����������

        if (ProgLine == 3)
        {
            ClearEntry();
            ProgLine = 0;
            SetInputMode(0);
            Appl_MaxEntry = sizeof(EntryBuffer)-2;
            ApplVar.CentralLock &=( ~SETUPMG);

        }
        if (Appl_EntryCounter)
            ProgLine++;

        break;
    default:
        ClearEntry();
        ProgLine = 0;

        SetInputMode(0);
        Appl_MaxEntry = sizeof(EntryBuffer)-2;
        ApplVar.CentralLock &=( ~SETUPMG);
        break;
    }
}
//<<<<PANAMA
/*---------------------------------------------------------------------
˰�س�ʼ��:����˰������,��ApplVar.FiscalDefine.idxֻ�ǵ�ǰ�����ĸ�����
tryAgain:=true,������ʾ������Ŀ����;
---------------------------------------------------------------------*/
void Initial_Fiscal(bool tryAgain)
{
    UnLong sAddr;
    int   i;

    if (tryAgain && ApplVar.FiscalDefine.idx)
    {
        ApplVar.FiscalDefine.idx--;
    }
    ApplVar.ErrorNumber = 0;
    switch (ApplVar.FiscalDefine.idx)
    {
    case 0://��ʾ����˰����:
        memset((char *)&ApplVar.FiscalDefine,0,sizeof(ApplVar.FiscalDefine));
        memset((char *)&ApplVar.Fis_Header,0,sizeof(ApplVar.Fis_Header));
        memset((char *)&ApplVar.FisNumber,0,sizeof(ApplVar.FisNumber));

        SetInputMode('0');
        Appl_MaxEntry = MAX_FISCAL_CODE;
        ClearEntry();
        ClearLine2();
#if(DD_ZIP==1 || DD_ZIP_21==1)
        //    	ProgType = 1 ;
        strcpy(ProgLineMes,Msg[TAXCODE].str);
#endif
        PutsO(Msg[TAXCODE].str);//��ʾ����˰�����к�
        ApplVar.FiscalDefine.idx=1;//��������

        break;
    case 1://���������Ϊ˰�����к�,�������ApplVar.Fis_Header.FFisCode��
        if (!Appl_EntryCounter)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            break;
        }

#if defined(CASE_ITALIA)
        memset(ApplVar.Fis_Header.FFisCode, ' ', sizeof(ApplVar.Fis_Header.FFisCode));
        i = GetInput(ApplVar.Fis_Header.FFisCode,MAX_FISCAL_CODE,false);
        if (i!=MAX_FISCAL_CODE)
        {
            memset(ApplVar.Fis_Header.FFisCode, 0, sizeof(ApplVar.Fis_Header.FFisCode));
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            break;
        }
#else
        memset(ApplVar.Fis_Header.FFisCode, '0', sizeof(ApplVar.Fis_Header.FFisCode));
        i = GetInput(ApplVar.Fis_Header.FFisCode,MAX_FISCAL_CODE,false);
#endif

        memset(ApplVar.Fis_Header.FRelease,' ',sizeof(ApplVar.Fis_Header.FRelease));
        memcpy(ApplVar.Fis_Header.FRelease,Release,strlen(Release));

#if(DD_ZIP==1 || DD_ZIP_21==1)
        Puts1(ApplVar.Fis_Header.FFisCode);  // liuj 0604 display the input
        // TODO PutsC(ApplVar.Fis_Header.FFisCode);  // liuj 0604 display the input
#else
        PutsO(ApplVar.Fis_Header.FFisCode);  //liuj 0604 display the input
#endif
        Appl_MaxEntry = 0;
        ApplVar.FiscalDefine.idx++;//��������
        ClearEntry();
        break;
    case 2://��ʾ������һ����Ŀ������
        ApplVar.FiscalDefine.idx++;
        ClearEntry();
        ClearLine2();

#if (RIFMUST)//>>>>>>>��ʾ����˰��ʶ����RIF
        SetInputMode('0');

        Appl_MaxEntry = RIFMAX;

#if(DD_ZIP==1 || DD_ZIP_21==1)
        strcpy(ProgLineMes, Msg[RIFCODE].str);
#endif
        PutsO(Msg[RIFCODE].str);
        break;
    case INPUTRIF: //���������RIF
        if (!Appl_EntryCounter)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            break;
        }

        memset(ApplVar.Fis_Header.FRIFNumber, '0', sizeof(ApplVar.Fis_Header.FRIFNumber));//����ʱ,��ǰ�油'0' //
        GetInput(ApplVar.Fis_Header.FRIFNumber,RIFLENDTH,false);

#if(DD_ZIP==1 || DD_ZIP_21==1)
        Puts1(ApplVar.Fis_Header.FRIFNumber);  // liuj 0604
#else
        PutsO(ApplVar.Fis_Header.FRIFNumber);  //liuj 0604
#endif
        ApplVar.FiscalDefine.idx++;
        ClearEntry();
        Appl_MaxEntry = 0;
        break;
    case INPUTRIF+1:
        ApplVar.FiscalDefine.idx++;
#endif  //<<<<<<<<<<<<RIFMUST


#if (DEVICEMUST)//PANAMA >>>>>>>>>>>��ʾ�����豸����
        SetInputMode('0');
        Appl_MaxEntry = sizeof(ApplVar.Fis_Header.FDeviceCode)-1;
        PutsO(DEVICECODE);

#if(DD_ZIP==1 || DD_ZIP_21==1)
        ClearLine2();
        strcpy(ProgLineMes, DEVICECODE);
#endif
        break;
    case INPUTDEV: //����������豸����
        if (!Appl_EntryCounter)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            break;
        }
        memset(ApplVar.Fis_Header.FDeviceCode, '0', sizeof(ApplVar.Fis_Header.FDeviceCode));//����ʱ,��ǰ�油0 //
        GetInput(ApplVar.Fis_Header.FDeviceCode,DEVICEMAX,false);

#if(DD_ZIP==1 || DD_ZIP_21==1)
        Puts1(ApplVar.Fis_Header.FDeviceCode);  //    liuj 0604
        //    TODO PutsC(ApplVar.RIFNumber);  //    liuj 0604
#else
        PutsO(ApplVar.Fis_Header.FDeviceCode);  //liuj 0604
#endif
        ApplVar.FiscalDefine.idx++;
        ClearEntry();
        Appl_MaxEntry = 0;
        break;
    case INPUTDEV+1:
        ApplVar.FiscalDefine.idx++;
#endif  //<<<<<<<<<<<<DEVICEMUST


#if (NAMEMUST)//PANAMA ��ʾ����ͻ�����>>>>>>>>>>>>>>>>>>>>>>>>
//�û�������ΪƱͷ��1��,��������ApplVar.TXT.Header[0]��

        SetInputMode('a');

        Appl_MaxEntry = NAMEMAX;

        PutsO(FISCALNAME);

#if(DD_ZIP==1 || DD_ZIP_21==1)
        ClearLine2();
        strcpy(ProgLineMes, FISCALNAME);
#endif
        break;
    case INPUTNAME: //��������Ŀͻ�����
        if (!Appl_EntryCounter)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            break;
        }
        memset(ApplVar.TXT.Header[0], 0, PRTLEN+1);//
        GetInput(ApplVar.TXT.Header[0],NAMEMAX,false);


#if(DD_ZIP==1 || DD_ZIP_21==1)
        Puts1(ApplVar.TXT.Header[0]);  //    liuj 0604
        //    TODO PutsC(ApplVar.RIFNumber);  //    liuj 0604
#else
        PutsO(ApplVar.TXT.Header[0]);  //liuj 0604
#endif
        ApplVar.FiscalDefine.idx++;
        ClearEntry();
        Appl_MaxEntry = 0;
        break;
    case INPUTNAME+1:
        ApplVar.FiscalDefine.idx++;
#endif  //<<<<<<<<<<<<NAMEMUST

#if (ADDRESSMUST)//PANAMA ��ʾ����ͻ���ַ>>>>>>>>>>>>>>>>>>>>>>>>
//�û���ַ��ΪƱͷ��2�͵�3��,��������ApplVar.TXT.Header[1]��ApplVar.TXT.Header[2]��,
//�����,Ҫ��ApplVar.TXT.Header[1]�е����һ���ַ��Ƶ�ApplVar.TXT.Header[2]�ĵ�һ��λ��

        SetInputMode('a');

        Appl_MaxEntry = ADDRESSMAX;

        PutsO(FISCALADDR);
#if(DD_ZIP==1 || DD_ZIP_21==1)
        ClearLine2();
        strcpy(ProgLineMes, FISCALADDR);
#endif
        break;
    case INPUTADDRESS: //��������Ŀͻ���ַ
        if (!Appl_EntryCounter)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            break;
        }
        memset(ApplVar.TXT.Header[1], 0, (PRTLEN+1)*2);//
        GetInput(ApplVar.TXT.Header[1],ADDRESSMAX,false);

#if(DD_ZIP==1 || DD_ZIP_21==1)
        Puts1(ApplVar.TXT.Header[1]);  // liuj 0604
        // TODO PutsC(ApplVar.Fis_Header.FRIFNumber);  // liuj 0604
#else
        PutsO(ApplVar.TXT.Header[1]);  //liuj 0604
#endif
        for (i=(PRTLEN+1)*2-1;i>PRTLEN;i--)
        {
            ApplVar.TXT.Header[1][i]=ApplVar.TXT.Header[1][i-1];
        }
        ApplVar.TXT.Header[1][PRTLEN]=0;//׷�ӽ�����־
        ApplVar.TXT.Header[2][PRTLEN]=0;//׷�ӽ�����־

        ApplVar.FiscalDefine.idx++;
        ClearEntry();
        Appl_MaxEntry = 0;
        break;
    case INPUTADDRESS+1:
        ApplVar.FiscalDefine.idx++;
#endif  //<<<<<<<<<<<<ADDRESSMUST

        SetInputMode('0');
        Appl_MaxEntry = 8;

        sAddr = (((UnLong)Now.year)<<16) +  //YY
                ((UnLong)Now.month<<8) +        //MM
                ((UnLong)Now.day);      //DD

        DateForDisplay(0);

#if(DD_ZIP==1 || DD_ZIP_21==1)
        strcpy(ProgLineMes,Msg[RIQI].str);
        PutsO(ProgLineMes);
        Puts1(SysBuf);
//								PutsC(SysBuf+4);
#else
        CopyFrStr(SysBuf,Msg[RIQI].str);
        PutsO(SysBuf);
#endif
        ClearEntry();
        break;
    case INPUTDATE:// 4  Input date // liuj 0806
        if (Appl_EntryCounter)
        {
            NewTimeDate(0x11);
            if (ApplVar.ErrorNumber)
            {
//                ApplVar.FuncOnEnter = 0; //liuj 0528
                break;
            }
        }
        ApplVar.Fis_Header.FInitDate[2] = Now.day;          // DD //
        ApplVar.Fis_Header.FInitDate[1] = Now.month;        // MM //
        ApplVar.Fis_Header.FInitDate[0] = (Now.year & 0xff);    // YY //

        ApplVar.FiscalDefine.idx++;

        sAddr = (((UnLong)Now.hour)<<16) +  //YY
                ((UnLong)Now.min<<8) +      //MM
                ((UnLong)Now.sec);      //DD
        memset(SysBuf,' ',DISLEN);
        HEXtoASC(SysBuf+DISLEN-6,(char*)(&sAddr),3);
        SysBuf[DISLEN] = 0;

#if(DD_ZIP==1)
        strcpy(ProgLineMes,Msg[SHIJIAN].str);
        PutsO(ProgLineMes);
        Puts1(SysBuf);
#elif(DD_ZIP_21==1)
        strcpy(ProgLineMes,Msg[SHIJIAN].str);
        PutsO(ProgLineMes);
        Puts1(SysBuf);
//								PutsC(SysBuf+4);
#else
        CopyFrStr(SysBuf,Msg[SHIJIAN].str);
        PutsO(SysBuf);
#endif

        ClearEntry();
        Appl_MaxEntry = 6;
        break;

    case INPUTTIME:// input time // liuj 0806
        if (Appl_EntryCounter)
        {
            SetDateFlg = 2;
            NewTimeDate(0x12);
            SetDateFlg = 0;
            if (ApplVar.ErrorNumber)
            {
//                ApplVar.FuncOnEnter = 0; //liuj 0528
                break;
            }
            ApplVar.Fis_Header.FInitDate[3] = ApplVar.Entry.Value[2];   /* HH */
            ApplVar.Fis_Header.FInitDate[4] = ApplVar.Entry.Value[1];   /* MM */
            ApplVar.Fis_Header.FInitDate[5] = ApplVar.Entry.Value[0];   /* SS */
        }
        else
        {
            ApplVar.Fis_Header.FInitDate[3] = Now.hour; /* HH */
            ApplVar.Fis_Header.FInitDate[4] = Now.min;  /* MM */
            ApplVar.Fis_Header.FInitDate[5] = Now.sec;  /* SS */
        }
        SetDateFlg = 2;
        Now.year = 0x2000+ApplVar.Fis_Header.FInitDate[0];
        Now.month= ApplVar.Fis_Header.FInitDate[1];
        Now.day= ApplVar.Fis_Header.FInitDate[2];

        SetTimeDate(&Now);
        SetDateFlg = 0;

        ApplVar.FisNumber.FiscalDate = EncordDate(ApplVar.Fis_Header.FInitDate[0],
                                                        ApplVar.Fis_Header.FInitDate[1],
                                                        ApplVar.Fis_Header.FInitDate[2]);//ccr070531
        ApplVar.LastInvoiceDate = ApplVar.FisNumber.LastZDate = ApplVar.FisNumber.FiscalDate;//ccr070531
        memcpy(ApplVar.LastInvoiceTime,ApplVar.Fis_Header.FInitDate+3,3);
        ApplVar.FiscalDefine.idx++;

        ClearEntry();
        ClearLine2();

        Appl_MaxEntry = 5;
#if DD_MMC == 1
        ApplVar.ContFlag = 0;
#endif

        //��ӡ���������Ϣ,ȷ�����������Ϣ
        PrintMessagesBy((char*)Msg[TAXCODE].str,(char*)ApplVar.Fis_Header.FFisCode,MAX_FISCAL_CODE);

#if (RIFMUST)//>>>>>>>��ʾ����˰��ʶ����RIF
        PrintMessagesBy((char*)Msg[RIFCODE].str,(char*)ApplVar.Fis_Header.FRIFNumber,RIFMAX);
#endif
#if (DEVICEMUST)//PANAMA >>>>>>>>>>>��ʾ�����豸����
        PrintMessagesBy((char*)DEVICECODE,(char*)ApplVar.Fis_Header.FDeviceCode,DEVICEMAX);
#endif
#if (NAMEMUST)//PANAMA ��ʾ����ͻ�����>>>>>>>>>>>>>>>>>>>>>>>>
        RJPrint(0,FISCALNAME);
        RJPrint(0,ApplVar.TXT.Header[0]);
#endif
#if (ADDRESSMUST)//PANAMA ��ʾ����ͻ���ַ>>>>>>>>>>>>>>>>>>>>>>>>
        RJPrint(0,FISCALADDR);
        RJPrint(0,ApplVar.TXT.Header[1]);
        RJPrint(0,ApplVar.TXT.Header[2]);
#endif
        memset(SysBuf,' ',sizeof(SysBuf));
        DateTimeToStr(SysBuf,3);
        SysBuf[22] = 0;
        PrintMessagesBy((char*)Msg[RIQI].str,SysBuf,22);

        RFeed(5);

        PutsO(DMes[24]);//confirm
#if !defined(DEBUGBYPC)
        while (1)
        {
            FM_EJ_Exist();
           if (KbHit())
           {
               i = Getch();
               if (i==ApplVar.AP.FirmKeys[ID_RJFEED])
               {
                   RFeed(1);
               }
               else if (i == ApplVar.AP.FirmKeys[ID_PRGENTER] && !ApplVar.FTrain)
               {//ȷ�ϳ�ʼ������
                   break;
               }
               else
               {//ȡ��˰�س�ʼ��,��ѵģʽʱ,��������˰�س�ʼ����Ϣ,���ǲ�����˰�س�ʼ��
                   ApplVar.FuncOnEnter = 0;
#if (DD_MMC)
                   memset(&ApplVar.EJLogHeader,0,HEADSIZE);//ccr20140617
#endif
                   memset(ApplVar.Fis_Header.FFisCode, 0, sizeof(ApplVar.Fis_Header.FFisCode));
                   ApplVar.FisCardFlag = FMISNEW;
                   CheckFisError();
                   return;
               }
           }
        }
#endif

//								memset(sVal1.Value,0,sizeof(BCD));
        ApplVar.Fis_Header.FFlag = FMINITEDFLAG;

        if (!ApplVar.FTrain)    /* not in trainning mode */
        {

            if (!Write_FiscalRam(FISHEADERADDR + sizeof(ApplVar.Fis_Header.FFirst) +
                                sizeof(ApplVar.Fis_Header.FPFirst),
                                ApplVar.Fis_Header.FRelease,
                                sizeof(ApplVar.Fis_Header) - sizeof(ApplVar.Fis_Header.FFirst) - sizeof(ApplVar.Fis_Header.FPFirst)))//ccr070531
            {
                ApplVar.FisCardFlag = FMERROR;  //20070302 FISINVALID;

                memset(ApplVar.Fis_Header.FFisCode, 0, sizeof(ApplVar.Fis_Header.FFisCode));
#if (RIFMUST)
                memset(ApplVar.Fis_Header.FRIFNumber, 0, sizeof(ApplVar.Fis_Header.FRIFNumber));
#endif
                ApplVar.FuncOnEnter = 0; // liuj 0605
                CheckFisError();
                return;
            }

//FLASH_ApplRAM					ClearAllReport();		/* Clear ApplVar.Report. */
            ApplVar.FisCardFlag = FISCALOK;
            ApplVar.FMPullOut[NOFM_FLAG] = 0;
            ApplVar.ZReport = 1 ;// ccr090507 ��ʾ�����ӡZ���� //
            //init ApplVar.FiscalHead
            memset(&ApplVar.FiscalHead, 0, sizeof(ApplVar.FiscalHead));
            ApplVar.FiscalHead.MaxP = FISDATAADDR;
            ApplVar.FiscalHead.EJTblP = FISEJADDR;

            ApplVar.ZCount[REPZNUM]= ApplVar.ZCount[TRAINNUM]=1;//ccr091027
            ApplVar.FisNumber.TotalClearNum = 1; //ccr070531 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!liuj 0526
        }

        Bell(2);
        ApplVar.FStatus = 1;
        AddReceiptNumber();

        ApplVar.PrintLayOut = 0x03;
        PrintLine2('=');
        RJPrint(0,Msg[SHKCSHUA].str);
        memset(SysBuf, ' ', sizeof(SysBuf));
        CopyFrStr(SysBuf, Msg[TAXCODE].str);
        strcpy(SysBuf+PRTLEN-strlen(ApplVar.Fis_Header.FFisCode), ApplVar.Fis_Header.FFisCode);
        SysBuf[PRTLEN] = 0;
        RJPrint(0, SysBuf);
#if (RIFMUST)
//liuj 0531 PM
        memset(SysBuf, ' ', sizeof(SysBuf));
        CopyFrStr(SysBuf, Msg[RIFCODE].str);
        strcpy(SysBuf+PRTLEN-strlen(ApplVar.Fis_Header.FRIFNumber), ApplVar.Fis_Header.FRIFNumber);
        SysBuf[PRTLEN] = 0;
        RJPrint(0, SysBuf);
//liuj 0531 PM
#endif

        /*if(!ApplVar.FTrain)	// not in trainning mode //
        {
            memset(ApplVar.Fis_Header.FFisCode, 0, sizeof(ApplVar.Fis_Header.FFisCode));
        }*/

        PrintRegiInfo(false);
        PrintLine2('=');
        RFeed(1);

        ProgLine = 0;
        ApplVar.FExento = ZERO;     /*    clear daily itemizers     */
        ApplVar.FTotal = ZERO;      /*    ApplVar.FTax is soft total and cleared at start of report     */
        ApplVar.TotalMax = ZERO;


        memset(&ApplVar.FTaxTotal,0,sizeof(ApplVar.FTaxTotal));//    ccr070615

        MemSet(ApplVar.CurrentTaxRate,0,sizeof(ApplVar.CurrentTaxRate));
        ApplVar.FMPullOut[NEWTAX_FLAG]=0x69;
        ProcessTax(true);
#if (NAMEMUST || ADDRESSMUST)
        ApplVar.FMPullOut[NEWHEAD_FLAG]=0x69;
        ProcessHead(false);//Ʊͷ���ݴ���FM
#endif
        ApplVar.FuncOnEnter = 0;
#if(DD_MMC == 1)
        CheckEJ();
        ApplVar.ErrorNumber=ERROR_ID(CWXXI97); //liuj 0531 PM
#endif
        SetInputMode(0);
#if (DD_ZIP || DD_ZIP21)
        PutsO(ModeHead);
#endif
        ClearEntry();
        ApplVar.FStatus = 0;
        break;
    }
}
#endif
#endif

void CheckFisError()
{

#if defined(FISCAL)
    if (!Bios_FM_CheckPresence())
        ApplVar.FisCardFlag = NOFM;
#endif
    if (ApplVar.FisCardFlag==FISCALOK)
        return;
    if (!ApplVar.ErrorNumber)
        switch (ApplVar.FisCardFlag)
        {
/*		case FMLESS:		// 3: already 100 EJs
            ApplVar.ErrorNumber=ERROR_ID(CWXXI89);
            break;*/
        case NOFM:      //  4: no Card //
            ApplVar.ErrorNumber |=  ERROR_ID(CWXXI74);
            break;
        case BADFM:     //  5: invalid Card //
            ApplVar.ErrorNumber |=  ERROR_ID(CWXXI76);
            break;
        case FMFULL:        //  6: fm  full
            ApplVar.ErrorNumber |=  ERROR_ID(CWXXI86);
            break;
        case FMMACFULL:     //  7: mac > 200
            ApplVar.ErrorNumber |=  ERROR_ID(CWXXI91);
            break;
        case FMERROR:   //  8: data error
            ApplVar.ErrorNumber |=  ERROR_ID(CWXXI78);
            break;
        case CHECKSUMCHANGED:
            ApplVar.ErrorNumber |= ERROR_ID(CWXXI92);//ERROR_ID(CWXXI92)
            break;
        case FM_X_ECR:
            ApplVar.ErrorNumber |= ERROR_ID(CWXXI93);//ERROR_ID(CWXXI93)
            break;
        case FM_X_EJ:
            ApplVar.ErrorNumber |= ERROR_ID(CWXXI98);//ERROR_ID(CWXXI98)
            break;
//        case MUSTINITFM:
        case FMISNEW:
            ApplVar.ErrorNumber |= ERROR_ID(CWXXI94);//ERROR_ID(CWXXI94)
            break;
        case BADEJ:
            ApplVar.ErrorNumber |= ERROR_ID(CWXXI84);
            break;
        case EJFULL :
            ApplVar.ErrorNumber |= ERROR_ID(CWXXI88) ;
            break;
        case MUSTINITEJ :
            ApplVar.ErrorNumber |= ERROR_ID(CWXXI97);//ERROR_ID(CWXXI97)
            break;
        case NOEJ:
            ApplVar.ErrorNumber |= ERROR_ID(CWXXI83);
            break;
        case EJLESS:
            ApplVar.ErrorNumber |= ERROR_ID(CWXXI87);
            ApplVar.FisCardFlag = FISCALOK;
            break;
        case FMLESS://ccr091104
            ApplVar.ErrorNumber |= ERROR_ID(CWXXI77);
            ApplVar.FisCardFlag = FISCALOK;
            break;
        default:
            ApplVar.ErrorNumber |= ApplVar.FisCardFlag;//ERROR_ID(CWXXI99)
            break;
        }
}
//ccr20131106>>>>>>>>>>>>>>>>>>>>>>>>>>
//------�����տ���Ƿ���˰������״̬-----------
//���տ��˰�س�ʼ��֮��,�տ���ʹ���˰������״̬
BOOL CheckInFiscalMode()
{
    return  (ApplVar.FisCardFlag == FISCALOK ||     //�տ��˰������״̬
             ApplVar.FisCardFlag == FMLESS ||       //�տ����˰�ش洢������
             ApplVar.FisCardFlag == FMMACFULL ||    //�տ���ļӵ��ʼ��������
             ApplVar.FisCardFlag == FMFULL ||       //�տ����˰�ش洢����
             ApplVar.FisCardFlag == EJFULL ||       //�տ����EJ��
             ApplVar.FisCardFlag == EJLESS);        //�տ����EJ����
}
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
