CONST  BYTE MFRCtrlBlock[16] = { 0xff,0xff,0xff,0xff,0xff,0xff,		//ApplVar.Key A     //�ɶ��������ݿ�Ϳ����ֽ�,����д //
		    		  0x78,0x77,0x88,0x69,				    //control bit
					  0xff,0xff,0xff,0xff,0xff,0xff};		//ApplVar.Key B     //������ԿAͬ����д�������п� //

//------------------------------------------------------------------------------
extern CONST BYTE TTbPswd[10][3];// Table of passwords
//----------------------------------------------------------------------------
extern CONST BYTE TbCript[40];// Table of codified areas decodification
//----------------------------------------------------------------------------
BYTE OldPwd[6];//save the old password of KEYB
BYTE CommIDX;
//BYTE MFRFlags;//  ��Ƶ��������־   //
//---------------------------------------------------------------------------
BYTE SendSTX()
{
	BYTE retry = 2,buf;
    short j;

	buf = STX0;
	//SendByte(STX0);
	Bios_PortWrite(ApplVar.MFRCardPort,&buf,1, 1);
	while(retry > 0/* �ȴ�ʱ��С��10ms */)
	{
        j = ReadComm(ApplVar.MFRCardPort-1);
        if(j != -1 && (j & 0xff) == ACK)
            return COMM_OK;
		else
        {
            retry--;
			//SendByte(STX0);
			Bios_PortWrite(ApplVar.MFRCardPort,&buf,1, 1);
        }
	}
	return COMM_ERR;
}
//----------------------------------------------------------
BYTE ReceSTX()
{
	short retry = 10,j;
	BYTE buf = ACK;
	while(retry > 0/* �ȴ�ʱ��С��300ms */)
	{
        j = ReadComm(ApplVar.MFRCardPort-1);
        if(j != -1 && (j & 0xff) == STX0)
        {
            //SendByte(ACK);
            Bios_PortWrite(ApplVar.MFRCardPort,&buf,1, 1);
            return COMM_OK;
        }
        else
            retry--;
    }
    return COMM_ERR;
}
//----------------------------------------------------------
BYTE SendData(BYTE *ser_buffer)
{
    BYTE send_len=*(ser_buffer + LENGTH) + 5,send_cnt;

	if(SendSTX() != COMM_OK)
		return COMM_ERR;

	*(ser_buffer + send_len - 2) = 0;      //BCC = 0
	*ser_buffer = CommIDX++;
	*(ser_buffer + send_len - 1) = ETX;    //�������	//
	for(send_cnt=0;send_cnt<send_len;send_cnt++)
	{
		if(send_cnt < (send_len - 2))
			*(ser_buffer + send_len - 2) ^= *(ser_buffer + send_cnt);
		if(send_cnt == send_len-3)
			*(ser_buffer + send_len - 2) = ~*(ser_buffer + send_len - 2);
	}
	//SendString(ser_buffer,send_len);
	Bios_PortWrite(ApplVar.MFRCardPort,ser_buffer,send_len, 1);

	return	COMM_OK;
}
//----------------------------------------------------------
BYTE ReceData(BYTE *Data,BYTE size)
{
	BYTE i,len,retry = 0;
    short j;
    BYTE k;
	i = 0;

    if(COMM_ERR == ReceSTX())
        return COMM_ERR;
	while (i<size && retry < 5 )
    {
		j = ReadComm(ApplVar.MFRCardPort-1);
		if (j!=-1)
		{
			*(Data + i) = j & 0xff;
            if(i == 1 && j != 0)    //��״̬��0��ı����ݳ���Ϊ5//
                size = DEFAULTLENGTH;
			i++;
			//*(Data + i) = 0;
            retry = 0;
		}
		else
        {
            //Sleep(10); //100
            Delay(10);
			retry++;
        }
    }

    len = *(Data + LENGTH) + 3;
    k = 0;
    for(i = 0;i < len;i++)
        k ^= *(Data + i);
    k = ~k;

    if(k == *(Data + LENGTH + 1))
        return COMM_OK;
    else
        return COMM_ERR;
}
//----------------------------------------------------------
// ���� //
BYTE mifs_request(BYTE _Mode,BYTE *_TagType)
{
    BYTE ser_buffer[30];

	ser_buffer[COMMAND] = 0x41;
	ser_buffer[LENGTH] = 0x01;
	ser_buffer[DATA] = _Mode;

    if(COMM_OK != SendData(ser_buffer))
        return COMM_ERR;
	ReceData(ser_buffer,REQUEST_ANSWER_LEN);

	if(ser_buffer[STATUS]==MI_OK)
	{
        *_TagType = ser_buffer[DATA];
		*(_TagType + 1) = ser_buffer[DATA+1];
	}
	return ser_buffer[STATUS];

}
//---------------------------------------------------------
// ����ײ��� //
BYTE mifs_anticoll(BYTE _Bcnt,BYTE *_SNR)
{
    BYTE ser_buffer[30];

	ser_buffer[COMMAND]=0x42;
	ser_buffer[LENGTH]=0x01;
	ser_buffer[DATA]=_Bcnt;

    if(COMM_OK != SendData(ser_buffer))
        return COMM_ERR;
	ReceData(ser_buffer,ANTICOLL_ANSWER_LEN);

	if(ser_buffer[STATUS]==MI_OK)
	{
		memcpy(_SNR,&ser_buffer[DATA],4);
	}
	return ser_buffer[STATUS];
}
//-------------------------------------------------------------
// ����ײ��⺯��2 //
BYTE mifs_anticoll2(BYTE _Encoll,BYTE _Bcnt,BYTE *_SNR)
{
    BYTE ser_buffer[30];

	ser_buffer[COMMAND]=0x71;
	ser_buffer[LENGTH]=0x02;
	ser_buffer[DATA]=_Encoll;
	ser_buffer[DATA+1]=_Bcnt;

    if(COMM_OK != SendData(ser_buffer))
        return COMM_ERR;
	ReceData(ser_buffer,ANTICOLL_ANSWER_LEN);

	if(ser_buffer[STATUS]==MI_OK)
	{
		memcpy(_SNR,&ser_buffer[DATA],4);
	}
	return ser_buffer[STATUS];
}
//----------------------------------------------------------
// ѡ�� //
BYTE mifs_select(BYTE *_SNR,BYTE *_Size)
{
    BYTE ser_buffer[30];

	ser_buffer[COMMAND]=0x43;
	ser_buffer[LENGTH]=0x04;
	memcpy(&ser_buffer[DATA],_SNR,4);

    if(COMM_OK != SendData(ser_buffer))
        return COMM_ERR;
	ReceData(ser_buffer,SELECT_ANSWER_LEN);

	if(ser_buffer[STATUS]==MI_OK)
	{
		*_Size=ser_buffer[DATA];
	}
	return ser_buffer[STATUS];
}
//------------------------------------------------------------
// ֱ����֤����Կ //
BYTE mifs_authkey(BYTE _Mode,BYTE _SecNr,BYTE *_Key)
{
    BYTE ser_buffer[30];

	ser_buffer[COMMAND]=0x73;
	ser_buffer[LENGTH]=0x08;
	ser_buffer[DATA]=_Mode;
	if(_SecNr<=32)
		ser_buffer[DATA+1]=_SecNr;
	else
		ser_buffer[DATA+1]=32+((_SecNr-32)<<2);	//Ϊ��֧��S70�� //
	memcpy(&ser_buffer[DATA+2],_Key,6);

    if(COMM_OK != SendData(ser_buffer))
        return COMM_ERR;
	ReceData(ser_buffer,AUTHKEY_ANSWER_LEN);

	return ser_buffer[STATUS];
}
//--------------------------------------------------------------
// ��ͣ��Ƶ�� //
BYTE mifs_halt()
{
    BYTE ser_buffer[30];

	ser_buffer[COMMAND]=0x45;
	ser_buffer[LENGTH]=0x00;

    if(COMM_OK != SendData(ser_buffer))
        return COMM_ERR;
	ReceData(ser_buffer,HALT_ANSWER_LEN);

	return ser_buffer[STATUS];
}
//--------------------------------------------------------------
// ���� //
BYTE mifs_read(BYTE _Adr,BYTE *_Data)
{
    BYTE ser_buffer[30];

	ser_buffer[COMMAND]=0x46;
	ser_buffer[LENGTH]=0x01;
	ser_buffer[DATA]=_Adr;

    if(COMM_OK != SendData(ser_buffer))
        return COMM_ERR;
	ReceData(ser_buffer,READ_ANSWER_LEN);

	if(ser_buffer[STATUS]==MI_OK)
	{
		memcpy(_Data,&ser_buffer[DATA],16);
	}
	return ser_buffer[STATUS];
}
//--------------------------------------------------------------
// д�� //
BYTE mifs_write(BYTE _Adr,BYTE *_Data)
{
    BYTE ser_buffer[30];

	ser_buffer[COMMAND]=0x47;
	ser_buffer[LENGTH]=17;
	ser_buffer[DATA]=_Adr;
	memcpy(&ser_buffer[DATA+1],_Data,16);

    if(COMM_OK != SendData(ser_buffer))
        return COMM_ERR;
	ReceData(ser_buffer,WRITE_ANSWER_LEN);

	return ser_buffer[STATUS];
}
//---------------------------------------------------------------
// ����RC500оƬ //
BYTE mifs_config()
{
    BYTE ser_buffer[30];

	ser_buffer[SEQNR]=0;
	ser_buffer[COMMAND]=0x52;
	ser_buffer[LENGTH]=0;

    if(COMM_OK != SendData(ser_buffer))
        return COMM_ERR;
    if(COMM_OK != ReceData(ser_buffer,CONFIG_ANSWER_LEN))
        return COMM_ERR;

	return ser_buffer[STATUS];
}
//---------------------------------------------------------------
// �������� //
BYTE mifs_buzzer(BYTE _Frquence,BYTE _Opentm,BYTE _Closetm,BYTE _Repcnt)
{
    BYTE ser_buffer[30];

	ser_buffer[COMMAND]=0x60;
	ser_buffer[LENGTH]=4;
	ser_buffer[DATA]=_Frquence;
	ser_buffer[DATA+1]=_Opentm;
	ser_buffer[DATA+2]=_Closetm;
	ser_buffer[DATA+3]=_Repcnt;

    if(COMM_OK != SendData(ser_buffer))
        return COMM_ERR;
	ReceData(ser_buffer,BUZZER_ANSWER_LEN);

	return ser_buffer[STATUS];
}
//---------------------------------------------------------------------------
BYTE VeriKey(short fatFr,short Mode)
{
    BYTE state,i;
    BYTE keydata[6];

    if(Mode == KEYA)
    {
		memset(keydata,0xff,sizeof(keydata));
        if((state = mifs_authkey(KEYA,fatFr,keydata)) != MI_OK)
            return state;
    }
    else
    {
    	if (fatFr>FATLAST)
			memset(keydata,0xff,sizeof(keydata));
		else
	        for(i = 0;i < 3;i++)
    	        keydata[i] = keydata[i + 3] = IC.CHIP_PSWD[i];
        if((state = mifs_authkey(KEYB,fatFr,keydata)) != MI_OK)
            return state;
    }
	return MI_OK;
}
//---------------------------------------------------------------------------

BYTE CC_Read(char *Dest,WORD ChipAdr, WORD NumBytes)
{
    WORD actBytes,actEnd,blockFr,fatFr;
    char  sKeyA=1;//=1,����У������A����0,����У������A  //
    WORD   sDest,i,sCurrBytes;
    BYTE state;
	BYTE   tmpBuff[M1BLOCKSIZE];

    sDest = (ChipAdr & 0x0f);
    actBytes = NumBytes + sDest;
    ChipAdr &= 0xfff0;

	sCurrBytes = M1BLOCKSIZE-sDest;
	if (sCurrBytes>NumBytes)	sCurrBytes = NumBytes;
    actEnd = ChipAdr +  actBytes;
    if (actEnd & 0x000f)
        actBytes = (((actEnd + M1BLOCKSIZE) & 0xfff0) - ChipAdr);
    actEnd = actBytes / (M1BLOCKSIZE*3);     // ÿ������ֻ��1��2��3���飬��48���ֽ� //
    fatFr = ChipAdr / (3 * M1BLOCKSIZE);            // ÿ������Ϊֻ��3�� //
    blockFr = (ChipAdr / M1BLOCKSIZE) +fatFr + 4*FATSTART;         //��ʼ���(ÿ����Ϊ16�ֽڣ���������ÿ�������ĵ�3��) //
    fatFr+=FATSTART;                        //��ʼ���� //

    for (i=0;i<(actBytes / M1BLOCKSIZE);i++)
    {
        if (sKeyA)
        {
            if((state = VeriKey(fatFr,KEYA)) != MI_OK) // У������fatFr������A //
                return FALSE;//ccr state;
            sKeyA = 0;
        }

        if((state = mifs_read(blockFr,tmpBuff)) != MI_OK)
            return FALSE;//ccr state;

		memcpy(Dest,tmpBuff+sDest,sCurrBytes);

		sDest = 0;
        Dest+=sCurrBytes;
		NumBytes-=sCurrBytes;

		sCurrBytes = M1BLOCKSIZE;
		if (sCurrBytes>NumBytes)	sCurrBytes = NumBytes;

        blockFr++;
        if ((blockFr & 3)==3)
        {
            fatFr++;
            blockFr++;
            sKeyA = 1;
        }
    }
    return true;//ccr MI_OK;
}
//---------------------------------------------------------------------------
BYTE CC_Write(char *Source,WORD ChipAdr, WORD NumBytes)
{
    WORD actBytes,actEnd,blockFr,fatFr;
    char  sKeyB=1;//=1,����У������B����0,����У������B  //
    char  veriBuff[M1BLOCKSIZE],tmpBuff[M1BLOCKSIZE];
    WORD   sSource,i,sCurrBytes;
    BYTE state,sKeyA=1;

    sSource = (ChipAdr & 0x0f);
    actBytes = NumBytes + sSource;
	sCurrBytes = M1BLOCKSIZE-sSource;
	if (sCurrBytes>NumBytes)	sCurrBytes = NumBytes;

    ChipAdr &= 0xfff0;

    actEnd = ChipAdr +  actBytes;
    if (actEnd & 0x000f)
        actBytes = (((actEnd + M1BLOCKSIZE) & 0xfff0) - ChipAdr);
    actEnd = actBytes / (M1BLOCKSIZE*3);     //ÿ������ֻ��1��2��3���飬��48���ֽ� //
    fatFr = ChipAdr / (3 * M1BLOCKSIZE);            //ÿ������Ϊֻ��3�� //
    blockFr = (ChipAdr / M1BLOCKSIZE) +fatFr + 4 * FATSTART;         //��ʼ���(ÿ����Ϊ16�ֽڣ���������ÿ�������ĵ�3��) //
    fatFr +=FATSTART;                        //��ʼ���� //

    for (i=0;i<(actBytes / M1BLOCKSIZE);i++)
    {
    	if (fatFr>FATLAST && sKeyA)
   		{
            if(sKeyA && VeriKey(fatFr,KEYA) != MI_OK) // У������fatFr������A //
                return FALSE;//ccr state;
            sKeyA = 0;
   		}
	    if (sCurrBytes!=M1BLOCKSIZE)
	   	{
            if(sKeyA && VeriKey(fatFr,KEYA) != MI_OK) // У������fatFr������A //
                return FALSE;//ccr state;
            sKeyA = 0;sKeyB = 1;

            if(mifs_read(blockFr,tmpBuff) != MI_OK)// read old data first
                return FALSE;//ccr state;
	   	}

		memcpy(tmpBuff+sSource,Source,sCurrBytes);

        if (sKeyB && fatFr<=FATLAST)
        {
            if((state = VeriKey(fatFr,KEYB)) != MI_OK) //У������fatFr������B  //
                return FALSE;//ccr state;
            sKeyB = 0;
        }

        if((state = mifs_write(blockFr,tmpBuff)) != MI_OK)
            return FALSE;//ccr state;
        if((state = mifs_read(blockFr,veriBuff)) != MI_OK)//
            return FALSE;//ccr state;
        // У��д�������  //
        if (memcmp(veriBuff,tmpBuff,M1BLOCKSIZE))         //У��д�������//
                return FALSE;//ccr MI_VERIERR;                       //У��ʧ�� //

		sSource = 0;
        Source+=sCurrBytes;
		NumBytes-=sCurrBytes;

		sCurrBytes = M1BLOCKSIZE;
		if (sCurrBytes>NumBytes)	sCurrBytes = NumBytes;

        blockFr++;

        if ((blockFr & 3)==3)
        {
            fatFr++;
            blockFr++;
            sKeyB = sKeyA = 1;
        }
    }
    return TRUE;//ccr MI_OK;
}
//---------------------------------------------------------------------------
BYTE CC_Request(BYTE Mode)
{
	BYTE SecNr,state;
    BYTE sTagType[2],sCardNo[4],sSize;

    if((state = mifs_request(Mode,sTagType)) != MI_OK)	// ���� //
		return state;
    if((state = mifs_anticoll(0,sCardNo)) != MI_OK)		// ����ײ��� //
		return state;
    if((state = mifs_select(sCardNo,&sSize)) != MI_OK)	// ѡ�� //
		return state;

	return MI_OK;
}
//---------------------------------------------------------------------------
//NewPwdΪ3λBYTE����
//cmd = MAKECARD,CHARGECARD	�ƿ����ֵ //
//cmd = CLEARCARD 	�忨       //
BYTE CC_WritePWD(BYTE *pNewPwd)
{
    BYTE Data[16];
				// { 0xff,0xff,0xff,0xff,0xff,0xff,		//ApplVar.Key A     //�ɶ��������ݿ�Ϳ����ֽ�,����д //
		    	//  0x78,0x77,0x88,0x69,				    //control bit
				//0xff,0xff,0xff,0xff,0xff,0xff};		//ApplVar.Key B     //������ԿAͬ����д�������п� //
    BYTE state,FatNo;

    for(FatNo = 0;FatNo < 4;FatNo++)
    {
		memcpy(Data,MFRCtrlBlock,sizeof(MFRCtrlBlock));
		if (pNewPwd)
		{
			Data[10] = pNewPwd[0];    Data[11] = pNewPwd[1];    Data[12] = pNewPwd[2];
	    	Data[13] = pNewPwd[0];    Data[14] = pNewPwd[1];    Data[15] = pNewPwd[2];
		}

	    if((state = mifs_authkey(KEYB,(FatNo + FATSTART),OldPwd)) != MI_OK)
	        return false;//ccr state;
	    if((state = mifs_write(4 * (FatNo + FATSTART) + 3,Data)) != MI_OK)
	        return false;//ccr state;
	    if((state = mifs_read(4 * (FatNo + FATSTART) + 3,Data)) != MI_OK)
	        return false;//ccr state;
    }
    return TRUE;//ccr MI_OK;
}
//------------------------------------------------------------------------------
//   ������Ƶ���Ƿ�׼����   //
WORD CC_Insert(void)
{
	WORD retry;

	retry = 0;
	if (ApplVar.MFRCardPort)
		for (retry=5;retry>0;retry--)
		{
			if(CC_Request(ALL) != MI_OK)
				Delay(100);
			else
				break;
		}

	return retry;
}


