#include "king.h"
#include "Release.h"
#include "message.h"

/* comment of Release:
	Release[0..4]:  Type name
	Release[5]:		PRTLEN
	Release[6]:		C-CortexM3
	Release[7]:		E-SD card,P-Print
	Release[8]:		2-IC4442,8-IC4428,M-ICmifare,X-no IC
	Release[9]:		Keyboard type N-7x8,L-7x6,W-8x7,C-6x7
	Release[10]:	N-New MCU,O-Old type MCU,\0-Old verssion
*/


#if(DD_MMC==1)
#define EJ_2		'E'
#else
#define EJ_2		'P'
#endif

#if (DD_CHIPC==1)
#if (CASE_MFRIC==1)
#define MYIC		'M'
#elif (DD_4442IC==1)
#define MYIC		'2'
#else
#define MYIC		'8'
#endif
#else
#define MYIC		'X'
#endif

#define PRNTYPE	'T'

#if defined(FISCAL)
//������˰�ش洢����ʾ����,������00-15�ֽ���
CONST char FMSetCard[17]={FMINITEDFLAG,0xFF,0x55,0xAA,'E','U',',T','R','O','N','T','E','S','T','F','M'};
//˰�ش洢����ʾ����,������00-15�ֽ���
CONST char FirmCode[17] ={FMINITEDFLAG,0xff,0x55,0xaa,0x00,0xff,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x20,0x20};

#endif


#if (DD_ZIP)
#define DISPO    '2'
#define DISPC    '2'
#elif(DD_ZIP_21)
#define DISPO    '2'
#define DISPC    '1'
#else
#define DISPO    '1'
#define DISPC    '1'
#endif

/* comment of Release:
	Release[0..4]:  Type name
	Release[5]:		PRTLEN
	Release[6]:		M-MMC card,P-Print
	Release[7]:		2-IC4442,8-IC4428,M-ICmifare,X-no IC
	Release[8]:		Lines of operator
	Release[9]:		Lines of Customer
	Release[10~18]:	verssion
    ע�����¸���:
    memcpy(ApplVar.Fis_Header.FRelease,Release,8);
    memcpy(ApplVar.Fis_Header.FRelease+8,Release+10,8);
*/

//Release�ĳ��Ȳ��ó���Fis_Header.FRelease�ĳ���

#if(CASE_ITALIA)
CONST char Release[16] = {'F','E','C','R','1','0','0','1',DISPO,DISPC,'V','1','.','0','1',0};

#elif (CASE_PCR01)
CONST char Release[16] = {'P','C','R','1','-',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};

#elif(CASE_ER28S)
CONST char Release[16] = {'E','2','8','S','-',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};

#elif(CASE_ER28T)
CONST char Release[16] = {'E','2','8','T','-',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};

#elif(CASE_ER50)
CONST char Release[16] = {'E','R','5','0','-',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};

#elif(CASE_ER220)
CONST char Release[16] = {'E','2','2','0','-',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};

#elif (defined(CASE_ER100))
CONST char Release[16] = {'E','1','0','0','-',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};

#elif (defined(CASE_ECR100F))
CONST char Release[16] = {'E','1','0','0','F',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};

#elif (CASE_ER260)
CONST char Release[16] = {'E','2','6','0','-',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};

#elif (CASE_ER260F)
CONST char Release[16] = {'E','2','6','0','F',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};

#elif(CASE_WISE158)
CONST char Release[16] = {'W','1','5','8','-',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};

#elif (DD_FISPRINTER)
CONST char Release[16] = {'F','P','8','0','-',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};

#elif (CASE_MCR30)
CONST char Release[16] = {'M','C','R','3','0',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};
#else
CONST char Release[16] = {'M','3','1','5','-',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};
#endif


CONST WORD SORT[] = {17, 9, 5, 3, 2, 1} ;


//cc 2006-07-14 for EN>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

CONST struct APPTEXT DefaultText = {
    {       /* Header[8][37] */
	Header1,
	Header2,
	Header3,
	Header4,
	"",
	"",
	"",
	},

    {    /* ReportType[16][16] */
   		ReportType0,
		ReportType1,
		ReportType2,
		ReportType3,
		ReportType4,
		ReportType5,
		ReportType6,
		ReportType7,
		ReportType8,
		ReportType9,
		ReportType10,
		ReportType11,
		ReportType12,
		ReportType13,
		ReportType14,
		ReportType15,
		ReportType16,
    },
    {   /* SlipHeader[6][35] */
	"",
	"",
	"",
	"",
	"",
	"",
    },

    {       /* Trailer[6][24] */
	Trailer1,
//Ccr 	"     ~��  ~л  ~��  ~��     ",
	Trailer2,
//Ccr 	"          ~��  ~��         ",
	"",
	"",
	"",
	"",
    },

};


//cc 2006-07-14 for EN>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

CONST struct APPLICATION Default = {
    {   /* FirmKeys[FIRMKEYS],Can't exchange position of the list */
		fCLEAR		,		// 0,firmkey clear. It must be the first byte!!!!!!.
		fOCPRINTER	,		// 1,Set Time
		fDATE		,		// 2,Display Date
		fREPORT		,		// 3,ReportList Trigger
		fPRGTYPE	,       // 4 programming Type key
		fPRGNUM		,       // 5 Programming number
		fPRGENTER	,       // 6 programming Enter
		fPRGUP		,       // 7 Programming UP
		fSYSREP		,       // 8 system report trigger
		fHARDTEST	,       // 9 Machine test key
		fDOWN		,       //10 Dump Program key
		fSHIFTDEPT		,       // 11 Alfa Shift 1
		fSHIFTKEY		,       // 12 Alfa Shift 2
		fLOCK		,      	// 13 mode lock
		fCANCEL		,		// 14 Mode lock
		fRJFEED		,		// 15 confirm OK
    },
    {   /* Manager[16] */
		0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    },
    {       /* Flag[SYSFLAGS] */
    	//0	 1	  2		3	4	  5		6	7	8	  9	   10	11	 12	  13   14   15
#if defined(CASE_ITALIA)//ʹ��','��ΪС����
        0x00,0x00,0x00,0x00,0x28,0x00,0x00, 0x00,0x00,0x10,0x00,0x00,0x00,0x00,0x00,0x00,
#else
		0x00,0x01,0x00,0x00,0x28,0x00,0x00, 0x00,0x00,0x10,0x00,0x00,0x00,0x00,0x00,0x00,
#endif

#if (DD_FISPRINTER || CASE_FTP628MCL401 || defined(DEBUGBYPC))
		0x03,0x00,0x9a,0x30,0x02,0x05,0x01,0x58,0x42,0x01,0x00,0x03,0x00,0x00,0xd1,0x00,
#else
		0x03,0x00,0x9a,0x30,0x02,0x05,0x00,0x58,0x42,0x01,0x00,0x03,0x00,0x00,0xd1,0x00,
#endif
		0x01,0x00,0x07,0x02,0x00,0x00,0x02,0x00,0x00,0x02,0x00,0x00,0x02,0x00,0x00,0x02,
		0x00,0x00,0x02,0x00,0x00,0x02,0x00,0x00,0x02,0x00,0x42,0x00,0x00,0x2d,0x01,0x00,
    },

#if (CASE_PCR01)
	{// KeyTable[128]
			JPF,		INPUTVATNO,	CLERK,		CORREC+2,	CORREC+3,	DISC+2,	//00-05
			MODELOCK,	0,			NPRICE,		CORREC+1,	CORREC+4,	DISC+4,		//07-11
			CLEAR,		MULT,		PLU1,		DEPT+5,		DEPT+8,		PORA+1,		//12-17
			'7',		'8',		'9',		DEPT+4,		DEPT+7,		PORA+2,		//18-23
			'4',		'5',		'6',		DEPT+3,		DEPT+6,		SUB,		//24-29
			'1',		'2',		'3',		DEPT+2,		0,			TEND+1,		//30-35
			'0',		ZERO2,		'.',		DEPT+1,		0,			0,		//36-41
			0,			0,			0,			0,			0,			0,			//42-47
			0,			0,			0,			0,			0,			0,			//48-53
			0,			0,			0,			0,			0,			0,			//54-59
			0,			0,			0,			0,									//60-63
	},
#elif (CASE_ER50)
	{//     KeyTable[128]
			JPF,        MODELOCK,   CORREC+3,   SHIFT1,     DISC+2,
			PLU1,	    NPRICE,	    CORREC+1,	DEPT+6,		DISC+1,
			CLEAR,	    MULT,	    CLERK,	    DEPT+5,		PORA+1,
			'7',        '8',        '9',	    DEPT+4,		PORA+2,
			'4',        '5',        '6',	    DEPT+3	,	SUB,
			'1',        '2',        '3',	    DEPT+2,		TEND+1,
			'0',        ZERO2,      '.',	    DEPT+1,		TEND+1,
			0,			0,		    0,		    0,			0,
			0,			0,		    0,		    0,			0,
			0,

	},

#elif (defined(CASE_MCR30))
	{//     KeyTable[128]
#if PC_EMUKEY
            MODELOCK,	JPF,	CLEAR,	MULT,		PLU1,		NPRICE,	    DISC+2, //����������ҪNPRICE
#else
			MODELOCK,	JPF,	CLEAR,	MULT,		PLU1,		NPRICE,	    DISC+2,
#endif
			CLERK,   	'7',	'8',	'9',		DEPT+4,		DEPT+8,		PORA+1,
			CORREC+2,	'4',	'5',	'6',		DEPT+3,		DEPT+7,		PORA+2,
			CORREC+1,	'1',	'2',	'3',		DEPT+2,		DEPT+6,		SUB,
			CORREC+3,	'0',	ZERO2,  '.',		DEPT+1,		DEPT+5,		TEND+1,
			0,			0,		0,		0,			0,			0,			0,
			0,			0,		0,		0,			0,			0,			0,
			0,			0,		0,		0,			0,			0,			0,
			0,			0,		0,		0,			0,			0,			0,
			0,

	},
#elif (defined(CASE_ER220)||defined(CASE_ER100)||defined(CASE_ECR100F))
#if CASE_ITALIA
    {//     KeyTable[128]
            MODELOCK,	JPF,	CLEAR,	MULT,		PLU1,		NPRICE,	    CORREC+3,
#if (PC_EMUKEY)
            CLERK,	    '7',	'8',	'9',		DISC+2,		DISC+1,		DISC+4, //����������ҪDISC+4(�ֽ��ۿ�)
#else
            CLERK,	    '7',	'8',	'9',		DISC+2,		DISC+1,		TEND+3,
#endif
            CORREC+2,	'4',	'5',	'6',		DEPT+3,		DEPT+6,		TEND+5,
            CORREC+1,	'1',	'2',	'3',		DEPT+2,		DEPT+5,		SUB,
            CORREC+4,	'0',	ZERO2,  '.',		DEPT+1,		DEPT+4,		TEND+1,
            0,			0,		0,		0,			0,			0,			0,
            0,			0,		0,		0,			0,			0,			0,
            0,			0,		0,		0,			0,			0,			0,
            0,			0,		0,		0,			0,			0,			0,
            0,
    },
#elif (defined(CASE_MALTA))
	{//     KeyTable[128]
#if PC_EMUKEY
            MODELOCK,	JPF,	CLEAR,	MULT,		PLU1,		NPRICE,	    DISC+2, //����������ҪNPRICE
#else
			MODELOCK,	JPF,	CLEAR,	MULT,		PLU1,		INPUTVATNO,	DISC+2,
#endif
			CORREC+4,	'7',	'8',	'9',		DEPT+4,		DEPT+8,		DISC+4,
			CORREC+2,	'4',	'5',	'6',		DEPT+3,		DEPT+7,		TEND+3,
			CORREC+1,	'1',	'2',	'3',		DEPT+2,		DEPT+6,		SUB,
			ODRAW,		'0',	ZERO2,  '.',		DEPT+1,		DEPT+5,		TEND+1,
			0,			0,		0,		0,			0,			0,			0,
			0,			0,		0,		0,			0,			0,			0,
			0,			0,		0,		0,			0,			0,			0,
			0,			0,		0,		0,			0,			0,			0,
			0,

	},
#else
	{//     KeyTable[128]

            MODELOCK,	JPF,	CLEAR,	MULT,		PLU1,		NPRICE,	    DISC+2, //����������ҪNPRICE
			CORREC+4,	'7',	'8',	'9',		DEPT+4,		DEPT+8,		DISC+4,
			CORREC+2,	'4',	'5',	'6',		DEPT+3,		DEPT+7,		TEND+3,
			CORREC+1,	'1',	'2',	'3',		DEPT+2,		DEPT+6,		SUB,
			ODRAW,		'0',	ZERO2,  '.',		DEPT+1,		DEPT+5,		TEND+1,
			0,			0,		0,		0,			0,			0,			0,
			0,			0,		0,		0,			0,			0,			0,
			0,			0,		0,		0,			0,			0,			0,
			0,			0,		0,		0,			0,			0,			0,
			0,
#if 0
            MODELOCK,	JPF,	CLEAR,	MULT,		PLU1,		NPRICE,		PORA+1,
			DEPT,		'7',	'8',	'9',		DISC+2,		DISC+1,		PORA+2,
			CORREC+2,	'4',	'5',	'6',		DEPT+3,		DEPT+6,		TEND+2,
			CORREC+1,	'1',	'2',	'3',		DEPT+2,		DEPT+5,		SUB,
			CORREC+4,	'0',	ZERO2,  '.',		DEPT+1,		DEPT+4,		TEND+1,
			0,			0,		0,		0,			0,			0,			0,
			0,			0,		0,		0,			0,			0,			0,
			0,			0,		0,		0,			0,			0,			0,
			0,			0,		0,		0,			0,			0,			0,
			0,
#endif
	},
#endif

#elif (defined(CASE_ER260F) || defined(CASE_ER260))
	{
        JPF,		MULT,	NPRICE,	PLU1,	DEPT+9,	DEPT+10,	DISC+2,		PORA+2,		//00-07
        MODELOCK,	'7',	'8',	'9',	DEPT+7,	DEPT+8,		DISC+4,	    PORA+1,		//08-15
        CLERK,		'4',	'5',	'6',	DEPT+5,	DEPT+6,		CORREC+1,	CORREC+4,	//16-23
        DISC+1,		'1',	'2',	'3',	DEPT+3,	DEPT+4,		CORREC+2,	SUB,		//24-31
        CLEAR,		'0',	ZERO2,	'.',	DEPT+1,	DEPT+2,		TEND+4,		TEND+1,		//32-39
            0,			0,		0,		0,		0,		0,			0,			0,			//40-47
            0,			0,		0,		0,		0,		0,			0,			0,			//48-55
            0,			0,		0,		0,		0,		0,			0,			0,			//56-63
    },

#elif (defined(CASE_ER260))
	{
            JPF,		MULT,	NPRICE,	PLU1,	DEPT+9,	DEPT+10,	DISC+4,		DISC+2,		//00-07
			MODELOCK,	'7',	'8',	'9',	DEPT+7,	DEPT+8,		DISC+1,		CLERK,		//08-15
			PORA+1,		'4',	'5',	'6',	DEPT+5,	DEPT+6,		CORREC+3,	CORREC+1,	//16-23
			PORA+2,		'1',	'2',	'3',	DEPT+3,	DEPT+4,		CORREC+2,	SUB,		//24-31
			CLEAR,		'0',	ZERO2,	'.',	DEPT+1,	DEPT+2,		TEND+4,		TEND+1,		//32-39
			0,			0,		0,		0,		0,		0,			0,			0,			//40-47
			0,			0,		0,		0,		0,		0,			0,			0,			//48-55
			0,			0,		0,		0,		0,		0,			0,			0,			//56-63
	},
#elif (CASE_ER28S)
	{
		CLEAR,	MODELOCK,	MULT,		PLU1,		CLERK,		DISC+2,		//00-05
		'7',	'8',		'9',		DEPT+7,		DEPT+8,		CORREC+2,	//06-11
		'4',	'5',		'6',		DEPT+5,		DEPT+6,		CORREC+1,	//12-17
		'1',	'2',		'3',		DEPT+3,		DEPT+4,		SUB,		//18-23
		'0',	ZERO2,		'.',		DEPT+1,		DEPT+2,		TEND+1,		//24-29
		0,		0,			0,			0,			0,			0,			//30-35
		0,		0,			0,			0,			0,			0,			//36-41
		0,		0,			0,			0,			0,			0,			//42-47
		0,		0,			0,			0,			0,			0,			//48-53
		0,		0,			0,			0,			0,			0,			//54-59
		0,		0,			0,			0,									//60-63
	},

#elif (CASE_ER28T)
	{//     KeyTable[128]
		JPF,		MULT,	NPRICE,	PLU1,	DEPT+9,	DEPT+10,	DISC+4,		DISC+2,		//    00-07
		MODELOCK,	'7',	'8',	'9',	DEPT+7,	DEPT+8,		DISC+1,		CLERK,		//    08-15
		PORA+1,		'4',	'5',	'6',	DEPT+5,	DEPT+6,		CORREC+3,	CORREC+1,	//    16-23
		PORA+2,		'1',	'2',	'3',	DEPT+3,	DEPT+4,		CORREC+2,	SUB,		//    24-31
		CLEAR,		'0',	ZERO2,	'.',	DEPT+1,	DEPT+2,		TEND+4,		TEND+1,		//    32-39
		0,			0,		0,		0,		0,		0,			0,			0,			//    40-47
		0,			0,		0,		0,		0,		0,			0,			0,			//    48-55
		0,			0,		0,		0,		0,		0,			0,			0,			//    56-63
	},

//cc 20070312
#elif (CASE_WISE158)
	{
#if(defined(CASE_MALTA))	//cc 20071102
																								MODELOCK,	MULT,	INPUTVATNO,	DISC+2,	DISC+4,		CORREC+3,
#else
																								MODELOCK,	MULT,	DISC+1,	DISC+2,	DISC+4,		CORREC+3,
#endif
		DEPT+4,	DEPT+8,		DEPT+12,	DEPT+16,	DEPT+20,DEPT+24,	SHIFT1,		JPF,			PLU1,		'7',	 	'8',		'9',		CORREC+2,	CORREC+1,
		DEPT+3,	DEPT+7,		DEPT+11,	DEPT+15,	DEPT+19,DEPT+23,	DEPT,		NPRICE,		PORA+2,		'4',	 	'5',		'6',		CORREC+4,	CURR,
#if (defined(FISCAL))
		DEPT+2,	DEPT+6,		DEPT+10,	DEPT+14,	DEPT+18,DEPT+22,	USERINFO,	DATETIME,	PORA+1,		'1',	 	'2',		'3',		TEND+4,		SUB,
#else
		DEPT+2,	DEPT+6,		DEPT+10,	DEPT+14,	DEPT+18,DEPT+22,	SALPER,	DATETIME,	PORA+1,		'1',	 	'2',		'3',		TEND+4,		SUB,
#endif

		DEPT+1,	DEPT+5,		DEPT+9,		DEPT+13,	DEPT+17,DEPT+21,	CLERK,		ODRAW,		CLEAR,		'0', 	 	ZERO2,	'.',		TEND+1,		TEND+1,
		0,		0,
	},
#elif CASE_ER380
	{// KeyTable[128]

        JPF,		CLERK,		DATETIME,	LOOKPLU,	DEPT+7,		SHIFT1,		CORREC+3,	DISC+4,		//00-07
        MODELOCK,	0,	        NPRICE,		PLU1,		DEPT+6,		DEPT+13,	DISC+2,		DISC+1,		//08-15
        CORREC+2,	CORREC+4,	CORREC+1,	MULT,		DEPT+5,		DEPT+12,	PORA+1,		PORA+2,		//16-23
        ODRAW,		'7',		'8',		'9',		DEPT+4,		DEPT+11,	TEND+2,		TEND+4,		//24-31
        SALPER,		'4',		'5',		'6',		DEPT+3,		DEPT+10,	TEND+2,		CURR,		//32-39
        CLEAR,		'1',		'2',		'3',		DEPT+2,		DEPT+9,		SUB,		0,		    //40-47
        0,		    '0',		ZERO2,		'.',		DEPT+1,		DEPT+8,		TEND+1,		0,		    //48-55
        0,			0,			0,			0,			0,			0,			0,			0,			//56-63

	},
#endif

    {   /*    StartAddress[AddrMAX]     */
		(RamOfTotal),                      /*    ApplVar.Total Sales start address     */
		(RamOfGroup),                     /*    ApplVar.Group Start Address     */
		(RamOfDept),                      /*    ApplVar.Dept start address     */
		(RamOfPLU),                      	/*    ApplVar.Plu start address     */
		(RamOfPort),						/*    ApplVar.Port start address     */
		(RamOfTend),                      /*    tendering function start address     */
		(RamOfPoRa),                      /*    Po Ra functions     */
		(RamOfDrawer),                    /*    Drawer start     */
		(RamOfCorr),                      /*    correc start     */
		(RamOfDisc),                      /*    discount start     */
		(RamOfCurr),                      /*    Foreign currency start     */
		(RamOfTax),                      	/*    ApplVar.Tax start     */
		(RamOfPBf),                      	/*    ApplVar.PB-Function start     */
		(RamOfModi),                      /*    modifier start     */
		(RamOfClerk),                     /*    clerk start     */
		(RamOfOFF),						/*    ApplVar.OFFPrice start    */
		(RamOfICBlock),                  	/*      //    ccr chipcard 2004-07-01     */
		(RamOFSalPer),                  	/*         */
		(RamOFAgree),						/*         */
		(RamOfRPLU),                  	/*    Random PLU's used (low word)     */
		(RamOfEndP),                      /*    PROGRAM END Address     */
		(RamOfPBt),                      	/*    ApplVar.PB table start     */
		(RamOfTrack)                      /*    track buffer start     */
    },

    {	//    struct PASSWORD ModePwd
    	{0,0,0,0,0,0,0,0,0,0,0,0,0},	//    PwdX[MAXPWD];
    	{0,0,0,0,0,0,0,0,0,0,0,0,0},    //    PwdZ[MAXPWD];
    	{0,0,0,0,0,0,0,0,0,0,0,0,0},    //    PwdSET[MAXPWD];
    	{0,0,0,0,0,0,0,0,0,0,0,0,0}     //    PwdMG[MAXPWD];
    },

    {   /* struct CLERKTABLE ApplVar.Clerk */
		clrkNumber		,
		clrkRecordSize	,
		clrkCapSize
    },
    {   /* struct CCONFIG Config */
		  0,        /* country code (0 = Europe) */
		  2,        /* display (2 = 9 digit numeric) */
		  3,      /* lock (2 = Central Lock, 3 = central & clerk) */
		128,    /* Journal density */
		128,    /* Receipt density */
		  2,        /* Keyboard (2 = MA  60 keys) */
		 15,        /* Clear key */
		 -1,        /* ApplVar.Key Click 0 = disabled -1 = enabled) */
		{
		    0x88,   /* disabled key locations each bit one key */
		    0xff,
		    0xff,
			0xff,
		    0xff,
		    0xff,
		    0xff,
		    0xbf,
		    0xff,
		    0xff,
		    0xff,
		    0xff,
		}
    },

    {   /* struct CORRECTABLE ApplVar.Correc */
		corrNumber		,          /* number of correction functions */
		corrRecordSize	,
		corrTotalOffSet	,
		corrCapSize		,
		{
		    {0x03, 9, 0, 3, 5, 0, 0, 0},   /*    standard tlzr lay out     */
		    {0x03, 9, 0, 3, 5, 0, 0, 0},   /*    clerk tlzr lay-out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    Time zones tlzr lay-out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    ApplVar.Day tlzr lay-out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    ApplVar.Month tlzr lay-out     */
		    {0x03, 9, 0, 3, 5, 0, 0, 0},   /*    saler tlzr lay-out     */
		}
    },

    {   /* struct CURRTABLE ApplVar.Curr */
		currNumber		,          /* number of foreign currencies */
		currRecordSize	,
		currTotalOffSet	,
		currCapSize		,
		{
		    {0x03, 7, 2, 0, 4, 0, 0, 0},   /* standard tlzr lay out */
		    {0x03, 5, 0, 0, 4, 0, 0, 0},   /* clerk tlzr lay out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Time zones tlzr lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* ApplVar.Day tlzr lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* ApplVar.Month tlzr lay-out */
		    {0x03, 5, 0, 0, 4, 0, 0, 0},   /* saler tlzr lay out */
		}
    },

    {   /* struct DAYTABLE Day */
		dayNumber
    },


    {   /* struct DEPTTABLE ApplVar.Dept */
		depNumber		,        /* number of ApplVar.Dept */
		depRecordSize	,         /* Record size */
		depTotalOffSet	,         /* ApplVar.Total offset */
		depRandomSize	,          /* Random Number ApplVar.Size */
		depCapSize		,            /* Caption Length */
		depPriceSize	,		/* max size is 4 */
		depPriMaxSize	,		/* max size is 4 */
		{
                  /*|����|����|���۶�|�˻�����|�ۿۻ���|COST���� */
            {0x03,16, 2, 3, 5, 0, 5, 0},   /*    standard tlzr lay out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    ApplVar.Clerk tlzr lay-out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    Time zones tlzr lay-out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    ApplVar.Day tlzr lay-out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    ApplVar.Month tlzr lay-out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    ApplVar.Clerk tlzr lay-out     */
		}
    },
    {       /* struct DISCTABLE ApplVar.Disc */
		discNumber		,          /* number of discount functions */
		discRecordSize	,
		discTotalOffSet	,
		discCapSize		,
		{
		    {0x03, 7, 0, 2, 4, 0, 0, 0},   /* standard tlzr lay out */
		    {0x03, 7, 0, 2, 4, 0, 0, 0},   /* clerk tlzr lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Time zones tlzr lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},    /* ApplVar.Day tlzr lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* ApplVar.Month tlzr lay-out */
		    {0x03, 7, 0, 2, 4, 0, 0, 0},   /* saler tlzr lay-out */
		}
    },
    {       /* struct DRAWERTABLE ApplVar.Draw */
		drawNumber		,          /* number of drawer tlzr */
		drawRecordSize	,
		drawTotalOffSet	,          /* 1 byte for options, 1 for print */
		drawCapSize		,
		{
		    {0x03, 7, 0, 0, 6, 0, 0, 0},   /*    standard tlzr lay-out     */
		    {0x03, 7, 0, 0, 6, 0, 0, 0},   /*    clerk tlzr lay-out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    Time zones tlzr lay-out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    ApplVar.Day tlzr lay-out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    ApplVar.Month tlzr lay-out     */
		    {0x03, 7, 0, 0, 6, 0, 0, 0},   /*    saler tlzr lay-out     */
		}
    },

    {       /* struct FIXEDREPORT ReportList[9] */
		{
			{ReportList1},//Ccr 	    {" �� �� Ա �� �� "},
		    PLAYOUT,   /* print */
		    0x02,   /* options */
		    0x00,  /* number */
		    0x00,   /* period */
		    0x01,   /* pointer type */
		    {1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 0, 0, 0, 0}/* link information modul */
		},
		{
			{ReportList2},//Ccr 		    {" �� �� Ա �� �� "},
	    	PLAYOUT,   /* print */
	    	0x02,   /* options */
	    	0x00,  /* number */
	    	0x01,   /* period */
	    	0x01,   /* pointer type */
	    	{1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 0, 0, 0, 0}
		},
		{
			{ReportList3},//ccr 	    {" ��  ��  ��  �� "},
		    PLAYOUT,   /* print */
#if defined(FISCAL)
		    0x06,   /* options */
#else
		    0x02,
#endif
		    0x00,  /* number */
		    0x00,   /* period */
		    0x00,   /* pointer type */
		    {1, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13, 0, 0, 0, 0, 0}
		},
		{
			{ReportList4},//ccr 	    {" ��  ��  ��  �� "},
		    PLAYOUT,   /* print */
		    0x02,   /* options */
		    0x00,  /* number */
		    0x01,   /* period */
		    0x00,   /* pointer type */
		    {1, 3, 5, 6, 7, 8, 9, 10, 11, 12, 13, 0, 0, 0, 0, 0}
		},
		{
			{ReportList5},//ccr 	    {" ��  Ʒ  ��  �� "},
		    PLAYOUT,   /* print */
		    0x02,   /* options */
		    0x00,  /* number */
		    0x00,   /* period */
		    0x00,   /* pointer type */
		    {4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
		},
		{
			{ReportList6},//ccr 	    {" ��  ��  ��  �� "},
		    PLAYOUT,   /* print */
		    0x02,   /* options */
		    0x00,  /* number */
		    0x00,   /* period */
		    0x00,   /* pointer type */
		    {13, 14, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
		},
		{
			{ReportList7},//ccr 	    {" ʱ  ��  ��  �� "},
		    PLAYOUT,   /* print */
		    0x02,   /* options */
		    0x00,  /* number */
		    0x00,   /* period */
		    0x02,   /* pointer type */
		    {1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}
		},
		{
			{ReportList8},//ccr 	    {"  ȫ�տ�Ա�ձ�  "},
		    PLAYOUT,   /* print */
		    0x02,   /* options */
		    0x00,  /* number */
		    0x00,   /* period */
		    0x01,   /* pointer type */
		    {1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 0, 0, 0, 0}
		},
		{
			{ReportList9},//ccr 	    {"  ȫ�տ�Ա�ܱ�  "},
		    PLAYOUT,   /* print */
		    0x02,   /* options */
		    0x00,  /* number */
		    0x01,   /* period */
		    0x01,   /* pointer type */
		    {1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 0, 0, 0, 0}
		},
		{
			{ReportList10},/*Ӫ ҵ Ա �� ��*/
		    PLAYOUT,   /* print */
		    0x02,   /* options */
		    0x00,  /* number */
		    0x00,   /* period */
		    0x05,   /* pointer type */
		    {1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 0, 0, 0, 0}
		},
		{
			{ReportList11},//Ccr Ӫ ҵ Ա �� ��
	    	PLAYOUT,   /* print */
	    	0x02,   /* options */
	    	0x00,  /* number */
	    	0x01,   /* period */
	    	0x05,   /* pointer type */
	    	{1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 0, 0, 0, 0}
		},
		{
			{ReportList12},//ccr 	    {"  ȫӪҵԱ�ձ�  "},
		    PLAYOUT,   /* print */
		    0x02,   /* options */
		    0x00,  /* number */
		    0x00,   /* period */
		    0x05,   /* pointer type */
		    {1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 0, 0, 0, 0}
		},
		{
			{ReportList13},//ccr 	    {"  ȫӪҵԱ�ܱ�  "},
		    PLAYOUT,   /* print */
		    0x02,   /* options */
		    0x00,  /* number */
		    0x01,   /* period */
		    0x05,   /* pointer type */
		    {1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 0, 0, 0, 0}
		},
    },

    {       /* struct GROUPTABLE ApplVar.Group */
		grpNumber,
		grpRecordSize,
		grpTotalOffSet,
		grpCapSize,
		{
		    {0x03,20, 2, 3, 5, 5, 4, 0},   /*    standard tlzr lay out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    clerk tlzr lay out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    Time zones tlzr lay-out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    ApplVar.Day tlzr lay-out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    ApplVar.Month tlzr lay-out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    saler tlzr lay out     */
		}
    },
    {   /* struct MODITABLE ApplVar.Modi */
		modiNumber	,
		modiCapSize ,
    },
    {       /* struct MONTHTABLE ApplVar.Month */
		monthNumber
    },
    {       /* struct PBTABLE Pb */
		pbNumber		,          /* number of PB functions */
		pbRecordSize	,            /* record size PB function */
		pbTotalOffSet	,         /* total offset */
		pbCapSize		,          /* caption length */

		pbNumberOfPb	,        /* number of PB's */
		pbRandom		,          /* Pb random */
		pbText			,          /* Pb text */
		pbAmtSize		,          /* ApplVar.PB amount size is 5 (table contains also block clerk and lines */
		pbArtAmt		,          /* max art amount 999999 */
//#if pbAmtDisc
//		pbAmtDisc		,			//ccr091208
//#endif
		pbQty			,          /* max qty 999999 */
		pbArtSize		,          /* amt + qty + sign + keycode */
		pbNumberOfItems	,         /* number of items in block */
		pbNumberOfBlocks,         /* number of blocks */
		pbBlockSize		,        /* block size maximum is 128 bytes */
        pbtRecordSize,          // Record size for PBTable report ccr 2003-10-31
        pbtTotalOffset,         //ccr 2003-10-31
		{//For pb function
		    {0x03, 6, 0, 0, 5, 0, 0, 0},   /* standard tlzr lay-out */
		    {0x03, 6, 0, 0, 5, 0, 0, 0},   /* clerk tlzr lay out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Time zones tlzr lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* ApplVar.Day tlzr lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* ApplVar.Month tlzr lay-out */
		    {0x03, 6, 0, 0, 5, 0, 0, 0},   /* saler tlzr lay out */
		},
		{//for pb table  ccr 2003-10-31
		    {0x01, 7, 0, 2, 4, 0, 0, 0},   /* standard tlzr lay-out */
		    {0x01, 5, 0, 0, 4, 0, 0, 0},   /* clerk tlzr lay out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Time zones tlzr lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* ApplVar.Day tlzr lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* ApplVar.Month tlzr lay-out */
		    {0x01, 5, 0, 0, 4, 0, 0, 0},   /* saler tlzr lay out */
		}
    },
    {       /*    struct PLUTABLE ApplVar.Plu     */
		pluNumber		,        /*    number of plus     */
		0,						/*    number of RandomPLU     */
		pluRecordSize	,         /*    Record size (+ ApplVar.Dept selection)    */
		pluTotalOffSet	,         /*    ApplVar.Total offset     */
		pluRandomSize	,          /*    Random Number ApplVar.Size     */
		pluCapSize		,         /*    Caption Length     */
		pluLevel		,          /*    Number of ApplVar.Price Levels     */
		pluPriceSize	,          /*    ApplVar.Price size in bytes     */
		pluCost			,          /*    if not zero then cost price     */
		pluInvSize		,          /*    inventory size (sign + size)     */
		{
		    {0x01, 14, 0, 3, 5, 0, 0, 5},       /* standard tlzr lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   		/*    ApplVar.Clerk tlzr lay-out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},    	/*    Time zones tlzr lay-out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   		/*    ApplVar.Day tlzr lay-out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},    	/*    ApplVar.Month tlzr lay-out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   		/*    saler tlzr lay-out     */
		}
    },
    {       /* struct PORATABLE ApplVar.PoRa */
		poraNumber		,          /* number of PO  & RA functions */
		poraRecordSize	,
		poraTotalOffSet	,
		poraCapSize		,
		{
		    {0x03, 8, 2, 0, 5, 0, 0, 0},   /* standard tlzr lay out */
		    {0x03, 6, 0, 0, 5, 0, 0, 0},   /* clerk tlzr lay out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Time zones tlzr lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* ApplVar.Day tlzr lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* ApplVar.Month tlzr lay-out */
		    {0x03, 6, 0, 0, 5, 0, 0, 0},   /* saler tlzr lay out */
		}
    },
    {       /* struct TAXTABLE ApplVar.Tax */
		taxNumber		,              /* (3) number of tax itemizers max 8 */
		taxRecordSize	,
		taxTotalOffSet	,
		taxCapSize		,
		{
		    {0x03,13, 0, 0, 6, 0, 0, 6},   /*    standard tlzr lay out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    Clerks TLZR layout     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    Time zones tlzr lay-out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    ApplVar.Day tlzr lay-out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    ApplVar.Month tlzr lay-out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    Saler TLZR layout     */
		}
    },
    {       /* struct TENDTABLE ApplVar.Tend */
		tendNumber		,          /* number of tendering functions */
		tendRecordSize	,
		tendTotalOffSet	,
		tendCapSize		,
		{
		    {0x03, 9, 2, 0, 6, 0, 0, 0},   /*    standard tlzr lay out     */
		    {0x03, 7, 0, 0, 6, 0, 0, 0},   /*    clerk tlzr lay out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    Time zones tlzr lay-out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    ApplVar.Day tlzr lay-out     */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    ApplVar.Month tlzr lay-out     */
		    {0x03, 7, 0, 0, 6, 0, 0, 0},   /*    clerk tlzr lay out     */
		}
    },
   	{       /* struct TOTALSALES Sales */
		totalRecordSize, //ApplVar.Size[0].Length*2+ApplVar.Size[1].Length*clerkNumber + ApplVar.Size[2].Length * zoneNumber
		{
    	/*   Periods,	Length,Cc,ApplVar.Qty,ApplVar.Amt,ApplVar.RetQty,ApplVar.Disc,ApplVar.Cost    */
		    {0x03, 	12, 	2, 3, 6, 	0, 		0, 0},   /*    standard tlzr lay-out     */
		    {0x03, 	7, 		0, 0, 6, 	0, 		0, 0},   /*    Clerk tlzr lay-out     */
		    {0x01, 	9, 		2, 0, 6, 	0, 		0, 0},   /*    Time zones tlzr lay-out     */
		    {0x00, 	0, 		0, 0, 0, 	0, 		0, 0},   /*    ApplVar.Day tlzr lay-out     */
		    {0x00, 	0, 		0, 0, 0, 	0, 		0, 0},   /*    ApplVar.Month tlzr lay-out     */
		    {0x03, 	7, 		0, 0, 6, 	0, 		0, 0},   /*    Saler tlzr lay-out     */
		}
    },
    {       /* struct ZONETABLE ApplVar.Zone */
		zoneNumber,
		{
		    0x0000,         /* zone start */
		    0x0200,
		    0x0400,
		    0x0600,
		    0x0800,
		    0x1000,
		    0x1200,
		    0x1400,
		    0x1600,
		    0x1800,
		    0x2000,
		    0x2200,
		    0,0,0,0,0,0,0,0,0,0,0,0     /* notused */
		},
	},
	//	struct SALPERTABLE ApplVar.SalPer
	{                                       /* Salesperson */
		salNumber		,
		salRecordSize	,
		salCapSize
	},
	{//struct OPTIONTABLE                      /* Option */
		0,0,0,0,0,0,0,0,"",0,
	},
	{// struct OFFTABLE ApplVar.OFFPrice
		offNumber,
		offRecordSize,
		offCapSize,
		offPriUSize,
	},
	{// struct PORTTABLE ApplVar.Port
		portNumber,
		portRecordSize,
		portCapSize,
	},

	{//struct PROMRECORD 	Promotion;
		1000,
		{0x00,0x00,0x01,0x00},
		{0x00,0x00,0x01,0x00},
		{0x00,0x00,0x01,0x00},
		2,
		Promotion1,//		"  ~��  ~ϲ  ~��  ~��",
	},

	{//strcut AGREETABLE ApplVar.Agree
		agreeNumber,
		agreeRecordSize,
		agreeTotalOffSet,
		agreeCapSize,
	},
	{   /* struct ICBLOCKTABLE ApplVar.ICBlock */  //ccr chipcard 2004-07-01
		icblockNumber	,
		icblockSize ,
   	},
};


CONST struct DEFAULT Def = {
	{               /* CORREC */
		{ PLAYOUT, 0x00, Correc1},//Ccr 		{ PLAYOUT, 0x00, "ȡ��    "},
		{ PLAYOUT, 0x01, Correc2},//Ccr 		{ PLAYOUT, 0x01, "����    "},
		{ PLAYOUT, 0x02, Correc3},//Ccr 		{ PLAYOUT, 0x02, "�˻�    "},
		{ PLAYOUT, 0x03, Correc4},//ccr "ȡ������" //
//		{ PLAYOUT, 0x04, "CANCEL 1"},
//		{ PLAYOUT, 0x05, "CANCEL 2"},
	},
	{
	/* CURRENCY */
#if defined(CASE_MALTA)
		{0x80, 0, 'L', 'm', {0x93,0x42,0, 0}, {0,0,0,0}, CURRENCY1},
#else
		{0, 8, 0, 0, {0,0,0,0}, {0,0,0,0}, CURRENCY1},//Ccr 		{0, 0, 0, 0, {0,0,0,0}, {0,0,0,0}, "��Ԫ    "},
#endif
		{0, 0, 0, 0, {0,0,0,0}, {0,0,0,0}, CURRENCY2},//Ccr 		{0, 0, 0, 0, {0,0,0,0}, {0,0,0,0}, "��Ԫ    "},
		{0, 0, 0, 0, {0,0,0,0}, {0,0,0,0}, CURRENCY3},//Ccr 		{0, 0, 0, 0, {0,0,0,0}, {0,0,0,0}, "�۱�    "},
		{0, 0, 0, 0, {0,0,0,0}, {0,0,0,0}, CURRENCY4},//Ccr 		{0, 0, 0, 0, {0,0,0,0}, {0,0,0,0}, "���1   "},
		{0, 0, 0, 0, {0,0,0,0}, {0,0,0,0}, CURRENCY5},//Ccr 		{0, 0, 0, 0, {0,0,0,0}, {0,0,0,0}, "���2   "},
	},
	{       /* DISCOUNT */
		{PLAYOUT, 0x19, {0, 0, 0}, 0, {0x00,0x99,0x00,0x00}, DISCOUNT1},         /*  DISC 1 "+%�ӳ�" */
		{PLAYOUT, 0x11, {0, 0, 0}, 0, {0x00,0x99,0x00,0x00}, DISCOUNT2},         /*  DISC 2  "(-%)�ۿ�" */
		{PLAYOUT, 0x1d, {0, 0, 0}, 0, {0x00,0x99,0x99,0x99}, DISCOUNT3},         /*  DISC 3 "���ӳ�" */
		{PLAYOUT, 0x15, {0, 0, 0}, 0, {0x00,0x99,0x99,0x99}, DISCOUNT4},         /* DISC 4 "����ۿ�" */
//		{PLAYOUT, 0x00, {0, 0, 0}, 0, {0x00,0x99,0x99,0}, "\xB5\xA5\xCF\xEE\xBC\xD3\xB3\xC9"},          /* DISC 5 "����ӳ�" */
	},
	{       /* DRAWER */
		{PLAYOUT, 0, DRAWER1},// 		{PLAYOUT, 0, "�ֽ�    "},
		{PLAYOUT, 0, DRAWER2},// 		{PLAYOUT, 0, "֧Ʊ    "},
		{PLAYOUT, 0, DRAWER3},// 		{PLAYOUT, 0, "���ÿ�  "},
		{PLAYOUT, 0, DRAWER4},//	{PLAYOUT, 0, "����ȯ  "},
		{PLAYOUT, 0, DRAWER5},//		{PLAYOUT, 0, "����    "},
		{PLAYOUT, 0, DRAWER6},//		{PLAYOUT, 0, "IC��    "},
		{PLAYOUT, 0, DRAWER7},//		{PLAYOUT, 0, "С��    "},
		{PLAYOUT, 0, DRAWER8},
	},
	{       /*    PB FUNCTIONS     */
		{PLAYOUT, 0x00,PBFunction0},    //     ��̨����  PB-F 1  //
#if pbNumber==12
		{PLAYOUT, 0x01, PBFunction1},    //     ��̨���� PB-F 2 //
		{PLAYOUT, 0x02, PBFunction2},    //      �ݽ�  PB-F 3 //
		{PLAYOUT, 0x03, PBFunction3},    //     ȷ�Ͻ���  PB-F 4 //
		{PLAYOUT, 0x04, PBFunction4},    //     ��ӡ��̨PB-F 5 //
		{PLAYOUT, 0x05, PBFunction5},    //     ��ӡ�ʵ� PB-F 6 //
		{PLAYOUT, 0x06, PBFunction6},    //     ȡ��ȷ�� PB-F 7 //
		{PLAYOUT, 0x07, PBFunction7},    //     ���� PB-F 8 //
		{PLAYOUT, 0x08, PBFunction8},    //      ת�� PB-F 9 //
		{PLAYOUT, 0x09, PBFunction9},	//     ת����  PB-F 10 //
		{PLAYOUT, 0x0A, PBFunction10},	//      ���� PB-F 11 //
		{PLAYOUT, 0x0B, PBFunction11},	//     �ϲ� PB-F 12 //     liuj 0716
#endif
	},
	{       /*    PORA     */
		{PLAYOUT, 0x01, 1, 0, PORAType1},         /*    PORA 1     *///    Ccr 		{PLAYOUT, 0x01, 1, 0, "����    "},         /*    PORA 1     */
		{PLAYOUT, 0x09, 1, 0, PORAType2},         /*    PORA 2     *///    Ccr 		{PLAYOUT, 0x09, 1, 0, "���    "},         /*    PORA 2     */
		{PLAYOUT, 0x01, 1, 0,PORAType3},         /*    PORA 3     *///    ccr		{PLAYOUT, 0x09, 1, 0, "IC���˿�"},         /*    PORA 3     */
		{PLAYOUT, 0x09, 1, 0, PORAType4},         /*    PORA 4     *///    ccr 		{PLAYOUT, 0x01, 1, 0, "IC����ֵ"},         /*    PORA 4     */
		{PLAYOUT, 0x01, 1, 0, PORAType5},         /*    PORA 5     *///    ccr		{PLAYOUT, 0x09, 1, 0, "��ICѺ��"},         /*    PORA 5     */
		{PLAYOUT, 0x09, 1, 0, PORAType6},         /*    PORA 6     *///    ccr 		{PLAYOUT, 0x01, 1, 0, "��ICѺ��"},         /*    PORA 6     */
	},
	{       /*    TEND     */
#if defined(CASE_MALTA)
		{PLAYOUT, 0x41, 1, 0, 0, TendType1},		//"�ֽ�    "
		{PLAYOUT, 0x4d, 2, 0, 0, TendType2},        //"֧Ʊ    "
		{PLAYOUT, 0x45, 3, 0, 0, TendType3},        //"���ÿ�  "
		{PLAYOUT, 0x51, 4, 7, 0, TendType4},        //"����ȯ  "
		{PLAYOUT, 0x45, 5, 0, 0, TendType5},        //"����"
		{PLAYOUT, 0x45, 6, 0, 0, TendType6},        //"ICCard"

#else
		{PLAYOUT, 0x01, 1, 0, 0,TendType1},         /*    TEND 1     *///    Ccr 		{PLAYOUT, 0x01, 1, 0, 0, "�ֽ�    "},         /*    TEND 1     */
		{PLAYOUT, 0x05, 2, 0, 0, TendType2},         /*    TEND 3     *///    Ccr 		{PLAYOUT, 0x05, 3, 7, 0, "���ÿ�  "},         /*    TEND 3     */
		{PLAYOUT, 0x05, 3, 0, 0, TendType3},          /*    TEND 5 ����    *///    		{PLAYOUT, 0x05, 5, 7, 0, "����"},         /*    TEND 5     */
		{PLAYOUT, 0x05, 4, 0, 0,TendType4},         /*    TEND 2     *///    Ccr 		{PLAYOUT, 0x05, 2, 7, 0, "֧Ʊ    "},         /*    TEND 2     */
		{PLAYOUT, 0x11, 5, 7, 0, TendType5},         /*    TEND 4     *///    		{PLAYOUT, 0x11, 4, 7, 0, "����ȯ  "},         /*    TEND 4     */
		{PLAYOUT, 0x05, 6, 0, 0, TendType6},         /*    TEND 6     *///    		{PLAYOUT, 0x05, 6, 7, 0, "ICCard"},         /*    TEND 6     */
#endif
	},
	{       /* TAX */
#if !defined(FISCAL)
		{TAXType1, {0,0,0}, 0},
		{TAXType2, {0,0,0}, 0},
		{TAXType3, {0,0,0}, 0},
#elif (defined(CASE_ITALIA))
		{TAXType1, {0,0x22,0}, 0x01},//ITALIA
		{TAXType2, {0,0x10,0}, 0x01},//ITALIA
		{TAXType3, {0,0x04,0}, 0x01},//ITALIA

		{TAXType4, {0,0x00,0}, 0x01},
		{TAXType5, {0,0x00,0}, 0x01},
		{TAXType6, {0,0x00,0}, 0x01},
		{TAXType7, {0,0x00,0}, 0x01},
		{TAXType8, {0,0x00,0}, 0x01},
#elif (defined(CASE_MALTA))
		{TAXType1, {0,0x18,0}, 0x13},//MALTA
		{TAXType2, {0,0x5, 0}, 0x13},//MALTA
		{TAXType3, {0,0x00,0}, 0x13},//MALTA

		{TAXType4, {0,0x00,0}, 0x13},
		{TAXType5, {0,0x00,0}, 0x13},
		{TAXType6, {0,0x00,0}, 0x13},
		{TAXType7, {0,0x00,0}, 0x13},
		{TAXType8, {0,0x00,0}, 0x13},

#else
		{TAXType1, {0,0x13,0}, 0x02},
		{TAXType2, {0,0x08,0}, 0x02},
		{TAXType3, {0,0x17,0}, 0x02},
		{TAXType4, {0,0,0}, 2},
#if taxNumber==8
		{TAXType5, {0,0,0}, 2},
		{TAXType6, {0,0,0}, 2},
		{TAXType7, {0,0,0}, 2},
		{TAXType8, {0,0,0}, 2}
#endif
#endif
	},
	{
		Modifier1,             /* Modifier *///Ccr 		"˵��    ",             /* Modifier */
	},
	{
		ClerkRec1, 0xff,{0,0,0},                /* Clerk */
//Ccr 		"�տ�Ա  ", 0x10                /* Clerk */
	},
	{
		99, GroupRec1,             /* ApplVar.Group GROUPRECORD */
//Ccr 		0x0000, "����    ",             /* ApplVar.Group */
	},
	{ /* DEPTRECORD */
		{0,0,0,0,0,0,0}, 	//Random
		DeptRec1,	//name
		01,PLAYOUT,0xc0,0,0,
		{0,0,0,0,0},		//ApplVar.Price
		{0,0,0,0,0}         //PriceMax
//Ccr 		{0,0,0,0,0,0,0}, "����    ",0,PLAYOUT,0,0,0,0           /* Department */
	},
	{	/* PLU */
		{0,0,0,0,0,0,0}, 			//Random
		PLURec1,		//Name
		0,							//OFFIndex
		2,							//ApplVar.Dept
		0,							/* High ApplVar.Dept Number */
//Ccr 		{0,0,0,0,0,0,0}, "��Ʒ    ",0,
		{							//ApplVar.Price
			{0,0,0,0,0},
			{0,0,0,0,0},
			{0,0,0,0,0},
			{0,0,0,0,0}
		},
		{0,0,0,0,0},				//ApplVar.Cost
		0,							/* PLU Link */
		{0,0,0,0,0,0}				//NotUsed
	},
	{
		SalesPersonRec1, 0x00                /* Salesperson */
//Ccr 		"ӪҵԱ  ", 0x00                /* Salesperson */
	},
	{// struct OFFRECORD OFFPrice
		OffRec1,
		0,								//Type
		{0x01,0x01},							//Date From
		{0x01,0x01},							//Date to
		{0x01,0x01},							//Time from
		{0x01,0x01},							//Time to
		0,								//Week day
		0,//{0,{0,0,0,0},{0,0,0,0}},			//discount
	},
	{// struct PORTRECORD Port
		PortRec1,
		'1',								//Type,host
#if 0	//cc 20070930
		{0x47,0x47,0x47,0x43,0x43,0x43,0x43,0x46,0x47},//80181
#endif
		{0x47,0x47,0x47,0x43,0x43,0x43,0x43},//80181
		"0",
	},
	{//struct GRAPFORPRN Graph
		0,{0,0,0,0},{0,0,0,0},
	},
	{//strcut AGREERECORD Agree
		AgreeRec1,
		TeleRec1,
		"10000000",
		0,
	},
    {//struct ICBLOCKRECORD ICBlock;
        0
    },
    {//struct IPSETRECORD IP;
        {192,168,1,123},//    IPAddress[4];
        10248,//    ClientPort;
        {192,168,1,200},//    ServerIP[4];
        10249,//    ServerPort;
        {192,168,1,1},//    GateWay[4];//ccr2017-02-15
        {255,255,255,0},//    IPMask[4];//ccr2017-02-15
    #if defined(CASE_GPRS)
        "",//    APN[16];//ccr2015-03-10
        "",//    UserName[16];//ccr2015-03-10
        "",//    Password[16];//ccr2015-03-10
    #endif
        {1,2,3,4,5,6,7,8},//    ECR_ID[8];         //For example:unitID=0x123456789ABCDEF0, 8 bytes
    },
};

//cc 2006-07-14 for EN>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>



CONSTCHAR DMes[][lenDMes] = {//lenDMes=15
/*    These are messages for the display they MUST start with a SPACE     */
	DMes1,  //PutsO() only
	DMes2,  //PutsO() only
	DMes3,  //PutsO() only
	DMes4,  //PutsO() only
	DMes5,  //PutsO() only
	DMes6,  //PutsO() only
	DMes7,  //PutsO() only
	DMes8,  //PutsO() only
	DMes9,
	DMes10,
	DMes11,
	DMes12,
	DMes13,
	DMes14,  //PutsO() only
	DMes15,
	DMes16,  //PutsO() only
	DMes17,
	DMes18,
	DMes19,  //PutsO() only
	DMes20,  //PutsO() only
	DMes21,
	DMes22,
	DMes23,
	DMes24,
	DMes25,  //PutsO() only
	DMes26,
	DMes27,
	DMes28,
	DMes29,
	DMes30,
	DMes31,
	DMes32,
	DMes33,
	DMes34,
};


CONST char UPCOMM[][4]={
    UPCOMM1,			//    0
    UPCOMM2,			//    1
    UPCOMM3,			//    2
    UPCOMM4,			//    3
};


CONSTCHAR DText[][lenDText] = {//lenDText=15,end by \0, lenDText <  sizeof(ModeHead)
    DText1,		/* 0, Foreign Currency */
    DText2,		/* 1, Sales ApplVar.Total */
    DText3,			/* 2, Change */
    DText4,		/* 3, Subtotal */
    DText5,		/* 4, Discount */
    DText6,			/* 5, Paid Out */
    DText7,		/* 6, Received On Account */
    DText8,		/* 7, Drawer */
    DText9,		/* 8, Table Number */
    DText10,			/* 9, Service */
    DText11,		/* 10, Checks Paid */
    DText12,		/* 11, Checks Paid */
    DText13,			/* 12, Covers */
    DText14,		/* 13, ApplVar.Clerk */
    DText15,		/* 14, Modifier */
    DText16,			/* 15, Suspend/Recall tekst */
    DText17,			/* 16, Transaction void */
    DText18,		/* 17, SalesPerson */
    DText19,			// 18, LOCK mode
    DText20,			// 19,Reg mode
    DText21,			// 20,X report mode
    DText22,		// 21,Z report mode
    DText23,		// 22, SET mode
    DText24,		// 23, Manager mode
    DText25,		// 24,Password for XMode
    DText26,		// 25,New password for xMode
    DText27,		// 26,Confirm new password for XMode
    DText28,			/* 27	���� */
    DText29,			/* 28  ��� */
    DText30,		// 29
    DText31,		// 30
    "-",					/* 31 �� */
    "-",					/* 32 ��  */
    " ",					/* 33 ��  */
    DText35,		// 34
    DText36,			//35
    DText37,         //36 MUST
    DText38         //37 finished
};

#if(DD_ZIP_21==1)
CONSTCHAR CusDText[][4]={
	CusDText1,
	CusDText2,
	CusDText3,
	CusDText4,
	CusDText5,
	CusDText6,
	CusDText7,
};
#endif

#if COMPOSEIN
CONST char CodeASC[NUMASC][4]={
		"10 ",
		"14!",
		"30\"",
		"24#",
		"34$",
		"44%",
		"40&",
		"20'",
		"54(",
		"64)",
		"74*",
		"60+",
		"80,",
		"50-",
		"70.",
		"90/",
		"000",
		"011",
		"022",
		"033",
		"044",
		"055",
		"066",
		"077",
		"088",
		"099",
		"84:",
		"94;",
		"15<",
		"35=",
		"25>",
		"45?",
		"95@",
		"11A",
		"12B",
		"13C",
		"21D",
		"22E",
		"23F",
		"31G",
		"32H",
		"33I",
		"41J",
		"42K",
		"43L",
		"51M",
		"52N",
		"53O",
		"61P",
		"62Q",
		"63R",
		"71S",
		"72T",
		"73U",
		"81V",
		"82W",
		"83X",
		"91Y",
		"92Z",
		"68_",
		"99~",
	};
#endif

//    Captions for XZ report
CONST struct XZREPORT XZTitle[XZNUM]={
		{3, XZTitle1},
		{4, XZTitle2},
		{5, XZTitle3},
		{6, XZTitle4},
		{7, XZTitle5},
		{1, XZTitle6},
		{2, XZTitle7},
		{8, XZTitle8},
		{9, XZTitle9},
		{10,XZTitle10},
		{11,XZTitle11},
		{12,XZTitle12},
		{13,XZTitle13},
//		{14,XZTitle14},
	};




CONST char PortType[portTypeNum][PORTTYPELEN]={
		PortType1,
		PortType2,
		PortType3,
		PortType4,
		PortType5,
		PortType6,
		PortType7
#if 0	//cc 20070930
		"         MF1_IC",	//ccr epos
		"           EPOS"	//ccr epos
#endif
	};


CONST char KPType[KPTypeNum][7]={
		KPType1,
		KPType2,
		"EPS-42",   //EPSON��ӡ��,ʹ��A����, 42�ַ�����
		"EPSONA",   //EPSON��ӡ��,ʹ��A����, 30�ַ�����
		"EPSONB",   //EPSON��ӡ��,ʹ��B����, 42�ַ�����
		"EPS-48",   //EPSON��ӡ��,���е�, 48�ַ�����
		"CITIZN",   //�����Ǵ�ӡ��, 30�ַ�����
		" POS58",   //POS58��ӡ��,���е�,30�ַ�����
};

CONST char SPType[SPTypeNum][8]={	  // Lyq added for slip 20040331 start
		SPType1,
		SPType2,
		SPType3,
		SPType4,
		SPType5,
};									  // Lyq added for slip 20040331 end

// PB-F1   PB-F2    PB-F3  PB-F4    PB-F5    PB-F6    PB-F7    PB-F8 PB-F9 PB-F10  PB-F11
//��̨���� ��̨���� �ݽ�   ȷ�Ͻ��� ��ӡ��̨ ��ӡ�ʵ� ȡ��ȷ�� ����  ת��  ת����  ����
#if (CASE_PCR01)
CONST WORD  KeyTablePBF[MAXKEYB] ={// KeyTable[128]
			JPF,		INPUTVATNO,	CLERK,		CORREC+2,	CORREC+3,	DISC+2,	//00-05
			MODELOCK,	0,			NPRICE,		CORREC+1,	CORREC+4,	DISC+4,		//07-11
			CLEAR,		MULT,		PLU1,		DEPT+5,		PBF+4,		PBF+1,		//12-17
			'7',		'8',		'9',		DEPT+4,		PBF+7,		PBF+5, 		// 2,		//18-23
			'4',		'5',		'6',		DEPT+3,		DEPT+6,		SUB,		//24-29
			'1',		'2',		'3',		DEPT+2,		0,			TEND+1,		//30-35
			'0',		ZERO2,		'.',		DEPT+1,		0,			0,			//36-41
			0,			0,			0,			0,			0,			0,			//42-47
			0,			0,			0,			0,			0,			0,			//48-53
			0,			0,			0,			0,			0,			0,			//54-59
			0,			0,			0,			0xffff,									//60-63
	};

#elif (CASE_ER50)
CONST WORD  KeyTablePBF[MAXKEYB] =
	{//     KeyTable[128]
			JPF,        MODELOCK,   CORREC+3,   SHIFT1,     DISC+2,
			PLU1,	    NPRICE,	    CORREC+1,	DEPT+6,		DISC+1,
			CLEAR,	    MULT,	    CLERK,	    DEPT+5,		PORA+1,
			'7',        '8',        '9',	    DEPT+4,		PORA+12,
			'4',        '5',        '6',	    DEPT+3	,	SUB,
			'1',        '2',        '3',	    DEPT+2,		TEND+1,
			'0',        ZERO2,      '.',	    DEPT+1,		TEND+1,
			0,			0,		    0,		    0,			0,
			0,			0,		    0,		    0,			0,
			0,

	};

#elif (defined(CASE_ER220)||defined(CASE_ER100)||defined(CASE_ECR100F)||defined(CASE_MCR30))
CONST WORD  KeyTablePBF[MAXKEYB] =
#if CASE_ITALIA
	{//     KeyTable[128]

        MODELOCK,	JPF,	CLEAR,	MULT,		PLU1,		NPRICE,	    DISC+2,
        CLERK,	    '7',	'8',	'9',		PBF+1,		PBF+7,      DISC+1,//��̨��ȡ��ȷ��
        CORREC+1,	'4',	'5',	'6',		PBF+4,		PBF+5,		TEND+3,//ȷ�ϡ���ӡ��̨
        CORREC+2,	'1',	'2',	'3',		DEPT+2,		DEPT+4,		SUB,
        CORREC+4,	'0',	ZERO2,  '.',		DEPT+1,		DEPT+3,		TEND+1,
        0,			0,		0,		0,			0,			0,			0,
        0,			0,		0,		0,			0,			0,			0,
        0,			0,		0,		0,			0,			0,			0,
        0,			0,		0,		0,			0,			0,			0,
        0,

	};
#elif (defined(CASE_MALTA))
	{//     KeyTable[128]
        MODELOCK,	JPF,	CLEAR,	MULT,		PLU1,		INPUTVATNO,	DISC+2,
        CORREC+4,	'7',	'8',	'9',		PBF+4,		PBF+1,		DISC+4,
        CORREC+2,	'4',	'5',	'6',		PBF+7,		PBF+5,		TEND+2,
        CORREC+1,	'1',	'2',	'3',		DEPT+2,		DEPT+4,		SUB,
        ODRAW,		'0',	ZERO2,  '.',		DEPT+1,		DEPT+3,		TEND+1,
        0,			0,		0,		0,			0,			0,			0,
        0,			0,		0,		0,			0,			0,			0,
        0,			0,		0,		0,			0,			0,			0,
        0,			0,		0,		0,			0,			0,			0,
        0,
	};
#else
    {//     KeyTable[128]
        MODELOCK,	JPF,	CLEAR,	MULT,		PLU1,		NPRICE,	    DISC+2,
        CORREC+4,	'7',	'8',	'9',		PBF+4,		PBF+1,		DISC+4,
        CORREC+2,	'4',	'5',	'6',		PBF+7,		PBF+5,		TEND+2,
        CORREC+1,	'1',	'2',	'3',		DEPT+2,		DEPT+4,		SUB,
        ODRAW,		'0',	ZERO2,  '.',		DEPT+1,		DEPT+3,		TEND+1,
        0,			0,		0,		0,			0,			0,			0,
        0,			0,		0,		0,			0,			0,			0,
        0,			0,		0,		0,			0,			0,			0,
        0,			0,		0,		0,			0,			0,			0,
        0,
    };
#endif

#elif (defined(CASE_ER260) || defined(CASE_ER260F))

CONST WORD  KeyTablePBF[MAXKEYB] ={// KeyTable[128]
			JPF,		MULT,	NPRICE,	PLU1,	PBF+4,	PBF+1,	    DISC+4,		DISC+2,		//00-07
			MODELOCK,	'7',	'8',	'9',	PBF+7,	PBF+5,		CORREC+3,	CORREC+2,	//08-15
			CLERK,		'4',	'5',	'6',	DEPT+5,	DEPT+6,		PORA+1,		CORREC+1,	//16-23
			ODRAW,		'1',	'2',	'3',	DEPT+3,	DEPT+4,		PORA+2,		SUB,		//24-31
			CLEAR,		'0',	ZERO2,	'.',	DEPT+1,	DEPT+2,		TEND+4,		TEND+1,		//32-39
			0,			0,		0,		0,		0,		0,			0,			0,			//40-47
			0,			0,		0,		0,		0,		0,			0,			0,			//48-55
			0,			0,		0,		0,		0,		0,			0,			0,		//56-63
	};

#elif (CASE_ER28S)
CONST WORD  KeyTablePBF[MAXKEYB] ={//     KeyTable[128]
		CLEAR,	MODELOCK,	MULT,		PLU1,		CLERK,		DISC+2,		//00-05
		'7',	'8',		'9',		DEPT+7,		DEPT+8,		CORREC+2,	//06-11
		'4',	'5',		'6',		DEPT+5,		DEPT+6,		CORREC+1,	//12-17
		'1',	'2',		'3',		DEPT+3,		DEPT+4,		SUB,		//18-23
		'0',	ZERO2,		'.',		DEPT+1,		DEPT+2,		TEND+1,		//24-29
		0,		0,			0,			0,			0,			0,			//30-35
		0,		0,			0,			0,			0,			0,			//36-41
		0,		0,			0,			0,			0,			0,			//42-47
		0,		0,			0,			0,			0,			0,			//48-53
		0,		0,			0,			0,			0,			0,			//54-59
		0,		0,			0,			0,									//60-63
};

#elif (CASE_ER28T)

CONST WORD  KeyTablePBF[MAXKEYB] ={//     KeyTable[128]
			JPF,	MULT,NPRICE,PLU1,DEPT+9,DEPT+10,DISC+4,DISC+2,		//    00-07
			MODELOCK,	'7','8','9',DEPT+7,DEPT+8,CORREC+3,CORREC+2,	//    08-15
			CLERK,'4','5','6',DEPT+5,DEPT+6,PORA+1,CORREC+1,	//    16-23
			ODRAW,'1','2','3',DEPT+3,DEPT+4,PORA+2,SUB,	//    24-31
			CLEAR,'0',ZERO2,	'.',DEPT+1,DEPT+2,TEND+4,TEND+1,		//    32-39
			0,		0,	0,	0,	0,	0,			0,			0,			//    40-47
			 0,		0,	0,	0,	0,	0,			0,			0,			//    48-55
			 0,		0,	0,	0,	0,	0,			0,			0,			//    56-63
	};

#elif (CASE_WISE158)

CONST WORD  KeyTablePBF[MAXKEYB] ={//     KeyTable[128]
#if (0)//!defined(FISCAL)
																					PLU1,  NPRICE,MULT, DISC+1,DISC+2,    DISC+4,
			DEPT+4,	DEPT+8,	DEPT+12,SHIFT1,		JPF,	   DATETIME,ODRAW,MODELOCK,		DEPT,   '7',	 '8',	    '9',	  CORREC+3,CORREC+1,
			DEPT+3,	DEPT+7,	DEPT+11,DEPT+15,	PBF+1,PBF+9,	     PBF+8,  PBF+11,		CLERK, '4',	 '5',	    '6',	  CORREC+4,CORREC+2,
			DEPT+2,	DEPT+6,	DEPT+10,DEPT+14,	PBF+5,PBF+6,	     PBF+10,MODI,			SALPER,'1',	 '2',	    '3',	  TEND+4,     SUB,
			DEPT+1,	DEPT+5,	DEPT+9,	DEPT+13,	PBF+4,PBF+7,	     PORA+2,PORA+1,		CLEAR, '0', 	 ZERO2,'.',	  TEND+1, TEND+1,
			0,		0xffff,	//0 	//hf_20060519 discard restaruant switch
#else
/* liuj 0606
																						PLU1,	NPRICE,	MULT,	DISC+1,	DISC+2,		DISC+4,
		DEPT+4,	DEPT+8,	DEPT+12,	SHIFT1,		JPF,		DATETIME,	ODRAW,	MODELOCK,	DEPT,	'7',	 	'8',	    	'9',	  	CORREC+3,	CORREC+1,
		DEPT+3,	DEPT+7,	DEPT+11,	DEPT+15,	PBF+1,	PBF+9,		PBF+8,	PBF+11,		CLERK,	'4',	 	'5',	    	'6',	  	CORREC+4,	CORREC+2,
		DEPT+2,	DEPT+6,	DEPT+10,	DEPT+14,	PBF+5,	PBF+6,		PBF+10,	MODI,		SALPER,	'1',	 	'2',	    	'3',	  	TEND+4,		SUB,
		DEPT+1,	DEPT+5,	DEPT+9,		DEPT+13,	PBF+4,	PBF+7,		PORA+2,	PORA+1,		CLEAR,	'0', 	 	ZERO2,	'.',	  	TEND+1,		0,
		0,		0xffff,
*/
																								MODELOCK,	MULT,	DISC+1,	DISC+2,	DISC+4,		CORREC+3,
		DEPT+4,	DEPT+8,		DEPT+12,	DEPT+16,	PBF+1,PBF+7,	SHIFT1,		JPF,			PLU1,		'7',	 	'8',		'9',		CORREC+2,	CORREC+1,
		DEPT+3,	DEPT+7,		DEPT+11,	DEPT+15,	PBF+4,PBF+8,	DEPT,		NPRICE,		PORA+2,		'4',	 	'5',		'6',		CORREC+4,	CURR,
		DEPT+2,	DEPT+6,		DEPT+10,	DEPT+14,	PBF+5,PBF+9,	USERINFO,	PBF+11,	PORA+1,		'1',	 	'2',		'3',		TEND+4,		SUB,
		DEPT+1,	DEPT+5,		DEPT+9,		DEPT+13,	PBF+6,PBF+10,	CLERK,		PBF+12,		CLEAR,		'0', 	 	ZERO2,	'.',		TEND+1,		TEND+1,
		0,		0,

#endif
	};
//cc 20070312

#elif CASE_ER380
//lyq added for giada din keyboard 2003\10\23 end
CONST WORD  KeyTablePBF[MAXKEYB] ={// KeyTable[128]
			JPF,		CLERK,		DATETIME,	PBF+11,		PBF+1,		SHIFT1,		CORREC+3,	DISC+4,		//00-07
			MODELOCK,	0,			NPRICE,		PLU1,		MODI,		PBF+6,		DISC+2,		DISC+1,		//08-15
			CORREC+2,	CORREC+4,	CORREC+1,	MULT,		PBF+8,		PBF+9,		PBF+4,		PBF+7,		//16-23
			ODRAW,		'7',		'8',		'9',		PBF+5,		PBF+10,		TEND+2,		TEND+4,		//24-31
			SALPER,		'4',		'5',		'6',		DEPT+3,		DEPT+6,		TEND+2,		CURR,		//32-39
			CLEAR,		'1',		'2',		'3',		DEPT+2,		DEPT+5,		SUB,		0,			//40-47
			0,			'0',		ZERO2,		'.',		DEPT+1,		DEPT+4,		TEND+1,		0,			//48-55
			0,			0,			0,			0,			0,			0,			0,			0xffff,		//56-63
	};
#endif

CONST struct SYSFLAGIDX SysFlagUsed[SYSUSED] ={
//     ��YN�Ŀ����������ʾ0ΪON,1ΪOFF;//
#if(DD_ZIP==1 || DD_ZIP_21==1 || DD_LCD_1601==1)
		{15,	255,0,	0,	SysFlagUsed1},		//    (1)0 	 0-255"ECR_no"
		{14,	255,0,	0,	SysFlagUsed1L},		//    (1)0 	 0-255"ECR_no"
		{63,	4,	0,	0,	SysFlagUsed2},		//    (2)1 	 0,1,2,3,4"Round_"
		{24,	0,	6,	0,	SysFlagUsed3},		//    (3)2	 bit1"PLU_Free"
		{4,		0,	1,	0,	SysFlagUsed4},			//    (4)3	 bit0"beep"
		{9,		0,	1,	YN,	SysFlagUsed5},	//    (5)4	 bit0"Obl_Oper"
//		{9,		0,	3,	YN,	SysFlagUsed6},	//    (6)5	 bit0"DisX_Oper"
		{9,		0,	6,	YN,	SysFlagUsed7},		//    (7)6	 bit0"Pass_Oper"
		{24,	0,	5,	YN,	SysFlagUsed8},		//    (8)7 bit0"Saleper_Num"
		{9,		0,	4,	YN,	SysFlagUsed9},		//    (9)8	 bit0"Prin_Oper"
//		{1,		0,	4,	0,	SysFlagUsed10},		//    (10)9   bit3"Prin_Recn"
//ccr2014		{17,	0,	1,	YN,	SysFlagUsed11},			//    (11)10  1,2,3"Paper_Type"
		{4,		0,	7,	YN,	SysFlagUsed12},		//    (12)11 bit6"Obl_Saleper_"
		{24,	0,	1,	YN,	SysFlagUsed13},		//    (13)12 bit0"ArtCode"
		{9,		0,	8,	YN,	SysFlagUsed14},		//    (14)13 bit0"Obl_Subt_"
		{5,		0,	1,	YN,	SysFlagUsed15},		//    (15)14 bit0"Art_no_"
		{24,	0,	7,	0,	SysFlagUsed16},		//    (16)15 bit7"TALLONS"
		{25,	0,	5,	YN,	SysFlagUsed17},		//    (17)16 bit0"TALLON HEADER AND TAILER"
		{60,	0,	8,	YN,	SysFlagUsed18},		//    (18)17 bit7"En_Shift"
		{21,	99,	0,	0,	SysFlagUsed19},			//    (19)18 0..99"Time_IDLE"
		{62,	15,	0,	0,	SysFlagUsed20},		//    (20)19 0..15"CopyReceipt"
		{23,	0,	4,	YN,	SysFlagUsed21},			//    (21)20 bit3"EANSpec_"
		{1,		0,	1,	0,	SysFlagUsed22},			//    (22)21  bit0"ApplVar.Amt Point or COMMA" //
		{19,	0,	5,	YN,	SysFlagUsed23},			//    (23)22  bit4"select pb print" //    lyq2003
		{19,	0,	6,	YN,	SysFlagUsed24},			//    (24)23  bit4"select inv print" //    lyq2003
#if(!defined(FISCAL))	//    cc 20070929
		{25,	0,	6,	YN,	SysFlagUsed25},		//    (25)24  bit5"allow press operator key to close printer" //    lyq2003
#endif
		{18,	0,	1,	YN,	SysFlagUsed26},			//    (25)24"���뿪̨:"},
		{18,	0,	5,	YN,	SysFlagUsed27},			//    (26)25"�����վݺ�"},
		{19,	0,	7,	YN,	SysFlagUsed28},			//    (27)26   //    ccr040810
//		{62,	0,	8,	YN,	SysFlagUsed29},			//    (28)27"�վݺŸ�λ" //
		{22,	0,  1,	YN, SysFlagUsed30},				//    (29)28"ʹ���е�" //
		{3, 	2,	0,	0, 	SysFlagUsed31},			//    (30)29 	 0-2"Date Type "
		{2, 	0, 	1, 	0, 	SysFlagUsed32}, 			//    (31)30  bit0 "time format 12 or 24"
        {26,    0,  4,  YN, SysFlags33},       // 31 bit3 "Ʊͷ���д�ӡ"
        {26,    0,  5,  YN, SysFlags34},       // 32 bit4 "Ʊβ���д�ӡ"

#else
		{15,	255,	0,0, },		//    (1)0 	 0-255"ECR_no    "
        {14,	255,0,	0,	},		//    (1)0 	 0-255"LOC_no"
		{63,	4,	0,0, },		//    (2)1 	 0,1,2,3,4"Round_    "
		{24,	0,	6,0, },		//    (3)2	 bit1"PLU_Free  "
		{4,	0,	1,0, },		//    (4)3	 bit0"beep      "
		{9,	0,	1,YN,},		//    (5)4	 bit0"Obl_Oper  "
//		{9,	0,	3,YN,},		//    (6)5	 bit0"DisX_Oper "
		{9,	0,	6,YN,},		//    (7)6	 bit0"Pass_Oper "
		{24,	0,	5,YN,},		//    (8)7 bit0"Saleper_Num  "
		{9,	0,	4,YN,},	//    (9)8	 bit0"Prin_Oper "
//		{1,	0,	4,0, },		//    (10)9   bit3"Prin_Recn "
//ccr2014		{17,	0,	1,YN,},		//    (11)10  1,2,3"Paper_Type  "
		{4,	0,	7,YN,},		//    (12)11 bit6"Obl_Saleper_ "
		{24,	0,	1,YN,},		//    (13)12 bit0"ArtCode   "
		{9,	0,	8,YN,},	//    (14)13 bit0"Obl_Subt_ "
		{5,	0,	1,YN,},		//    (15)14 bit0"Art_no_   "
		{24,	0,	7,0, },		//    (16)15 bit7"TALLONS   "
		{25,	0,	5,YN,},		//    (17)16 bit0"TALLON HEADER AND TAILER "
		{60,	0,	8,YN,},	//    (18)17 bit7"En_Shift"
		{21,	99,	0,0, },		//    (19)18 0..99"Time_IDLE "
		{62,	15,	0,0, },		//    (20)19 0..15"ApplVar.CopyReceipt "
		{23,	0,	4,YN,},	//    (21)20 bit3 "EANSpec_"
		{1,	0,	1,0, },			//    (22)21  bit0"ApplVar.Amt Point or COMMA" //
		{19,	0,	5,YN,},		//    (23)22  bit4"select pb print " //    lyq2003
		{19,	0,	6,YN,},		//    (24)23  bit4"select inv print " //    lyq2003
#if(!defined(FISCAL))	//    cc 20070929
		{25,0,	6,YN,},		//    (25)24  bit5"allow press operator key to close printer" //    lyq2003
#endif
		{18,	0,	1,YN,},				//    (25)24  "���뿪̨:"},
		{18,	0,	5,YN,},				//    (26)25  "�����վݺ�"},
		{19,	0,	7,YN,},				//    (27)26   //    ccr040810
//		{62,	0,	8,YN,},				//    (28)27  "�վݺŸ�λ" //
		{22,	0,	1,YN,},				//    (29)28  "ʹ���е�" //
		{3,	    2,	0,0, },			//    (30)29 	 0-2"Date Type "
		{2,	    0,	1,0, }, 			//    (31)30  bit0 "time format 12 or 24"
        {26,    0,  4,YN,},       // 31 bit3 "Ʊͷ���д�ӡ"
        {26,    0,  5,YN,},       // 32 bit4 "Ʊβ���д�ӡ"

#endif

};


CONST char GrapType[GRASETMAX][tCAPWIDTH]={
		GrapType1,
		GrapType2,
		GrapType3,
		GrapType4,
};

CONST char GrapSet[4][tCAPWIDTH]={
		GrapSet1,
		GrapSet2,
		GrapSet3,
		GrapSet4,
};


//    cc 20070312 for EN>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

CONSTCHAR ConfTab[][17] =
{
		ConfTab1,		//	"�ļ�����"��0
		ConfTab2,		//	"�ļ��ռ䣺" 1
		ConfTab3,		// "ͳ���ļ�"	2
		ConfTab4,		//��������Ϣ��	3
		ConfTab5,		//���������Ϣ��4
		ConfTab6,		// ��Ǯ����Ϣ�� 5
		ConfTab7,		// ��������Ϣ�� 6
		ConfTab8,		// �������Ϣ�� 7
		ConfTab9,		// ����˰��8
		ConfTab10,		//	"��̨����"��9
		ConfTab11,		//	"��������ļ���"					10
		ConfTab12,		//	��ǩ���ļ�:��11
		ConfTab13,		//	"��Ʒ�����ļ���"12
		ConfTab14,		// ��������Ϣ��13
		ConfTab15,		// ����̨��������14
		ConfTab16,		//	"��ˮ�ռ䣺"15
		ConfTab17,		// �����ڡ�	16
		ConfTab18,		//17 RAM size
		ConfTab19,  	//18 GUASHIIC
		ConfTab20,		// size of FM
};

CONSTCHAR ConfTi[2][PRTLEN+1] =
{
	ConfTi1,
	ConfTi2
};
//    #endif


//    cc 20070312 for EN>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


//#if defined(FISCAL)
/*
CONST BYTE	ASCIIKEY[MAXKEYB]={
									0,	0,	0,	0,	0,	0,
	'@',	'~',	0,	0,	0,	0,	0,	0,	'P',	'7',	'8',	'9',	0,	0,
	'Q',	'W',	'E',	'R',	'T',	'Y',	'U',	'I',	'O',	'4',	'5',	'6',	0,	0,
	'A',	'S',	'D',	'F',	'G',	'H',	'J',	'K',	'L',	'1',	'2',	'3',	0,	0,
	'Z',	'X',	'C',	'V',	'B',	'N',	'M',	' ',	0,	'0',	0,	'.',	0,	0,
	0,	0,
};

CONST BYTE	NUMASC_KEYBOARD[MAXKEYB]={
												0,	0,	0,	0,	0,	0,
	'@',	'~',		'!',		0x22,	'#',	'$',	0,	0,	0,	'7',	'8',	'9',	0,	0,
	'%',	'&',		0x27,	'(',		')',	'*',	'+',	',',	0,	'4',	'5',	'6',	0,	0,
	'-',	'/',		':',		';',		'<',	'=',	'>',	'?',	0,	'1',	'2',	'3',	0,	0,
	'[',	0x5c,	']',		'^',		'_',	'{',	'|',	'}',	0,	'0',	0,	'.',	0,	0,
	0,	0,
};
*/
#if (CASE_PCR01)
CONST BYTE	ASCIIKEY[MAXKEYB]=
	{
        0,      'a',	'b',	'c',	'd',	0,	//00-05
        0,	    0,	    'e',	'f',	'g',	0,	//06-11
        0,	    0,	    'h',	'i',	'j',	'~',	//12-17
        'k',	'l',	'm',	'n',	'o',	0,		//18-23
        'p',	'q',	'r',	's',	't',	0,		//24-29
        'u',	'v',	'w',	'x',    0,	    0,		//30-35
        'y',	0,	    '.',	'z',    0,	    0,		//36-41

        0,	0,	0,	0,	0,	0,			//42-47
        0,	0,	0,	0,	0,	0,			//48-53
        0,	0,	0,	0,	0,	0,			//54-59
        0,	0,	0,	0,							//60-63
    };

CONST BYTE	NUMASC_KEYBOARD[MAXKEYB]=
	{
        0,	    '#',	'$',	'%',	'^',	0,	//00-05
        0,	    0,	    '(',	')',	'-',	0,	//06-11
        0,	    0,	    '{',	'}',	'@',	'~',	//12-17
        '7',	'8',	'9',	'\'',	'?',	0,		//18-23
        '4',	'5',	'6',	':',	';',	0,		//24-29
        '1',	'2',	'3',	'[',    0,	    0,		//30-35
        '0',	0,	    '.',	']',    0,	    0,		//36-41

        0,	0,	0,	0,	0,	0,			//42-47
        0,	0,	0,	0,	0,	0,			//48-53
        0,	0,	0,	0,	0,	0,			//54-59
        0,	0,	0,	0,							//60-63

	};

#elif CASE_ER50
CONST BYTE	ASCIIKEY[MAXKEYB]=
	{

        0,	    0,	    'x',	'y',	'z',
        's',	't',    'u',    'v',	'w',
        0,	    0,      'q',    'r',	0,
        'm',	'n',    'o',    'p',	0,
        'i',	'j',    'k',    'l',	0,
        'e',	'f',    'g',    'h',	0,
        'a',	'b',    'c',    'd',	0,
        0,	    0,	    0,	    0,		0,
        0,	    0,	    0,	    0,		0,

	};
CONST BYTE	NUMASC_KEYBOARD[MAXKEYB]=
	{
        0,	    0,	    '~',	'!',	'@',
        '#',	'$',    '%',    '&',	'*',
        0,	    0,      '-',    '+',	0,
        '7',	'8',    '9',    '(',	0,
        '4',	'5',    '6',    ')',	0,
        '1',	'2',    '3',    ';',	0,
        '0',	',',    '.',    '"',	0,
        0,	    0,	    0,	    0,		0,
        0,	    0,	    0,	    0,		0,

	};

#elif (defined(CASE_ER220)||defined(CASE_ER100)||defined(CASE_ECR100F)||defined(CASE_MCR30))
CONST BYTE	ASCIIKEY[MAXKEYB]=
	{
			0,	    0,	    0,	    0,		'a',	'b',	0,
			'c',    'd',    'e',    'f',	'g',	'h',	0,
			'i',    'j',    'k',    'l',	'm',	'n',	0,
			'o',    'p',    'q',    'r',	's',	't',	0,
			'u',    'v',    'w',    'x',	'y',	'z',	0,
			0,	    0,	    0,	    0,		0,		0,		0,
			0,	    0,	    0,	    0,		0,		0,		0,
			0,	    0,	    0,	    0,		0,		0,		0,
			0,	    0,	    0,	    0,		0,		0,		0,
			0,

	};
CONST BYTE	NUMASC_KEYBOARD[MAXKEYB]=
	{
			0,	    0,	    0,	    0,		'!',	 '&',	0,
			'(',	'7',	'8',	'9',	128,	 '~',	0,
			')',	'4',	'5',	'6',	'-',	 ' ',	0,
			'%',	'1',	'2',	'3',	'?',	 '@',	0,
			'+',	'0',	';',   '.',		':',	 0x27,	0,
			0,	    0,	    0,	    0,		0,		0,		0,
			0,	    0,	    0,	    0,		0,		0,		0,
			0,	    0,	    0,	    0,		0,		0,		0,
			0,	    0,	    0,	    0,		0,		0,		0,
			0,

	};
#elif (defined(CASE_ER260) || defined(CASE_ER260F))
CONST BYTE	ASCIIKEY[MAXKEYB]=
	{
        0,		0,	    'a',	'b',	'c',	'd',	    '~',	0,		//00-07
        0,	    'e',	'f',	'g',	'h',	'i',		'j',	0,	//08-15
        'k',	'l',	'm',	'n',	'o',	'p',		'q',	0,	//16-23
		'r',	's',	't',	'u',	'v',	'w',		'x',	0,	//24-31
        0,		',',    0,	    '.',	'@',	'y',		'z',	0,		//32-39
                                                                             //
        0,		0,		0,		0,		0,		0,			0,		0,			//40-47
        0,		0,		0,		0,		0,		0,			0,		0,			//48-55
        0,		0,		0,		0,		0,		0,			0,		0,		//56-63

};
CONST BYTE	NUMASC_KEYBOARD[MAXKEYB]=
{
        0,		0,	    '!',	':',	'#',	'$',	    '~',	0,		//00-07
        0,	    '7',	'8',	'9',	'%',	'^',		'&',	0,	//08-15
        '*',	'4',	'5',	'6',	'[',	']',		'/',	0,	//16-23
        '=',	'1',	'2',	'3',	'(',	')',		'-',	0,		//24-31
        0,		'0',    0,	    '.',	'@',	'"',		'\'',	0,		//32-39
                                                                                        //
        0,		0,		0,		0,		0,		0,			0,		0,			//40-47
        0,		0,		0,		0,		0,		0,			0,		0,			//48-55
        0,		0,		0,		0,		0,		0,			0,		0,		//56-63

};

#elif CASE_WISE158
CONST BYTE	ASCIIKEY[MAXKEYB]={
                                '`','*','-', 0, 0 ,0 ,
    '~','!','@','#','$','%','(',')','p','7','8','9','+',0 ,
    'q','w','e','r','t','y','u','i','o','4','5','6','-',0,
    'a','s','d','f','g','h','j','k','l','1','2','3','[',']',
    'z','x','c','v','b','n','m',',',8  ,'0',';','.','=',0,
};

CONST BYTE	NUMASC_KEYBOARD[MAXKEYB]={
												0,	0,	0,	0,	0,	0,
	'@',	'~',		'!',		0x22,	'#',	'$',	0,	0,	0,	'7',	'8',	'9',	0,	0,
	'%',	'&',		0x27,	'(',		')',	'*',	'+',	',',	0,	'4',	'5',	'6',	0,	0,
	'-',	'/',		':',		';',		'<',	'=',	'>',	'?',	0,	'1',	'2',	'3',	0,	0,
	'[',	0x5c,	']',		'^',		'_',	'{',	'|',	'}',	0,	'0',	0,	'.',	0,	0,
	0,	0,
};
#elif CASE_ER380
CONST BYTE	ASCIIKEY[MAXKEYB] = {
	0,	'a','b','c','d','e','f','g',
	0,	0,	'h','i','j','k','l','m',
	'n','o','p',0,	'q','r',' ',0,
	'@','7','8','9','s','t',0,	0,
	'~','4','5','6','u','v',0,	0,
	0,	'1','2','3','w','x',0,	0,
	0,	'0',0,	'.','y','z',0,	0,
	0,	0,	0,	0,	0,	0,	0,	0,
};

CONST BYTE	NUMASC_KEYBOARD[MAXKEYB] = {
	0,	'!',0x22,'#','$',	'%',	'&',0x27,
	0,	0,	'(', ')','*',	'+',	',','-',
	'/',':',';', 0,	 '<',	'=',	'>','?',
	'@','7','8', '9','[',	0x5c,	0,	0,
	'~','4','5', '6',']',	'^',	0,	0,
	0,	'1','2', '3','_',	'{',	0,	0,
	0,	'0',0,	 '.','|',	'}',	0,	0,
	0,	0,	0,	 0,	  0,	0,		0,	0,
};
#endif

