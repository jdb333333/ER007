#define PORT_C 4
#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"

/***************************************************************/

void WritePort()
{
    if (ApplVar.PortNumber < ApplVar.AP.Port.Number)
		ApplVar.PortList[ApplVar.PortNumber] = ApplVar.Port;
}

void ReadPort()
{
    if (ApplVar.PortNumber < ApplVar.AP.Port.Number)
		ApplVar.Port = ApplVar.PortList[ApplVar.PortNumber];
}


BYTE EnCodeProto(char *pro)
{
	 return((pro[0] - 0x31) |
 		   ((pro[1] - 0x30)<<3) |
 		   ((pro[2] - 0x31)<<5) |
 		   ((pro[3] - 0x37)<<6));
}


void DeCodeProto(BYTE In, char *out)
{
	 out[0] = (In&0x07) + 0x31;//speed
	 out[1] = ((In>>3)&0x03)+ 0x30 ;//odd
	 out[2] = ((In>>5)&1) + 0x31 ;//stop bits
	 out[3] = ((In>>6)&1) + 0x37;//length
	 out[4] = '1';
}
