/*******************************************************/
/********************* M1Card.h ************************/
/*******************************************************/
//---------------------------------------------------------------------------
#define M1BLOCKSIZE	16	//  ÿ�ζ�ȡ�����ݿ���ֽ���   //

//PICC Command
#define IDLE		    0x00	//
#define ALL		        0x01	//

//
#define ANTICOLL1     	0x93			// anticollision level 1
#define ANTICOLL2     	0x95			// anticollision level 2
#define ANTICOLL3     	0x97			// anticollision level 3
#define KEYA		    0x00
#define KEYB		    0x04
#define PICC_DECREMENT	0xC0
#define PICC_INCREMENT	0xC1
#define PICC_RESTORE	0xC2

//  ����ͨ��֡����  //
#define STX0		0x20

#define SEQNR		0
#define COMMAND		1
#define STATUS		1
#define LENGTH		2
#define DATA		3

//Communication Error
#define COMM_OK		0x00
#define COMM_ERR	0xff

//mifare error
#define MI_OK				0
#define MI_NOTAGERR         1
#define MI_CRCERR           2
#define MI_EMPTY			3
#define MI_AUTHERR			4
#define MI_PARITYERR		5
#define MI_CODEERR			6
#define MI_VERIERR			7
#define MI_SERNRERR			8
#define MI_NOTAUTHERR		10
#define MI_BITCOUNTERR		11
#define MI_BYTECOUNTERR		12
#define MI_TRANSERR			14
#define MI_WRITEERR			15
#define MI_INCRERR			16
#define MI_DECRERR			17
#define MI_READERR			18
#define MI_QUIT				30

//check write Error
#define MIS_CHK_OK          0
#define MIS_CHK_FAILED      1
#define MIS_CHK_COMPERR     2

#define MAXLEN					30
#define DEFAULTLENGTH           5

#define REQUEST_ANSWER_LEN  	7
#define READ_ANSWER_LEN			21
#define WRITE_ANSWER_LEN		5
#define ANTICOLL_ANSWER_LEN		9
#define SELECT_ANSWER_LEN		6
#define AUTHKEY_ANSWER_LEN		5
#define HALT_ANSWER_LEN			5
#define CONFIG_ANSWER_LEN		5
#define BUZZER_ANSWER_LEN		5


#define CASCANTICOLL_ANSWER_LEN 9
#define LOADKEY_ANSWER_LEN		5
#define RESET_ANSWER_LEN		5
#define GETINFO_ANSWER_LEN		15
#define CLOSE_ANSWER_LEN		5

#define AUTHENTICATION_ANSWER_LEN 	5
#define AUTHENTICATION2_ANSWER_LEN 	5
#define CHECK_ANSWER_LEN		5
#define CONTROL_ANSWER_LEN		5
#define CLRCONT_ANSWER_LEN		5
#define READE2_ANSWER_LEN		MAXLEN
#define WRITEE2_ANSWER_LEN		5
#define VALUE_ANSWER_LEN		5
#define CASCSELECT_ANSWER_LEN 	6
#define ULWRITE_ANSWER_LEN		5
#define VALUEDEBIT_ANSWER_LEN	5
#define WRITEREG_ANSWER_LEN		5
#define READREG_ANSWER_LEN		6
#define INCREMENT_ANSWER_LEN    5
#define DECREMENT_ANSWER_LEN    5
#define RESTORE_ANSWER_LEN      5
#define TRANSFER_ANSWER_LEN     5

#define CLOGINCARD  82641937L	// ������ //
#define MAKECARD	0
#define CHARGECARD	1
#define CLEARCARD	2
#define FATSTART   1     //  ��Ƶ��������ʼ����  //
#define FATLAST		(FATSTART+3) // ��Ƶ�����ݽ�������  //

// MFRFlags;//  ��Ƶ��������־   //
#define MFRREADER	1		// ��Ƶ����д��׼����



extern  BYTE mifs_config();
extern  BYTE mifs_halt();
extern  BYTE mifs_buzzer(BYTE _Frquence,BYTE _Opentm,BYTE _Closetm,BYTE _Repcnt);
extern  BYTE VeriKey(short fatFr,short Mode);
extern  BYTE CC_Read(char *Dest,WORD ChipAdr, WORD NumBytes);
extern  BYTE CC_Write(char *Source,WORD ChipAdr, WORD NumBytes);
extern  BYTE CC_Request(BYTE Mode);
extern  BYTE CC_WritePWD(BYTE *pNewPwd);
extern  void SCC_SetPswd(short pType);

 /*
extern  BYTE mifs_request(BYTE _Mode,BYTE *_TagType);
extern  BYTE mifs_anticoll(BYTE _Bcnt,BYTE *_SNR);
extern  BYTE mifs_anticoll2(BYTE _Encoll,BYTE _Bcnt,BYTE *_SNR);
extern  BYTE mifs_select(BYTE *_SNR,BYTE *_Size);
extern  BYTE mifs_authkey(BYTE _Mode,BYTE _SecNr,BYTE *_Key);
extern  BYTE mifs_read(BYTE _Adr,BYTE *_Data);
extern  BYTE mifs_write(BYTE _Adr,BYTE *_Data);
*/
