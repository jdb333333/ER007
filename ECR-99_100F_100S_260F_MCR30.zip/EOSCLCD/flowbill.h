#if defined(DEBUGBYPC)
#pragma option -a1
#else
#pragma pack(1)
#endif

#ifndef FLOW_H

#define FLOW_H
//define the flow function No//

/*=============================================*/
#define  RESERVERLOG    1
#define	 DPTLOG		    2
#define	 ARTLOG		    3
#define	 ENDLOG		    4
#define	 NOADDLOG		5
#define	 OPERLOG		6       //
#define	 GIVENLOG		7
#define	 LOCKLOG		8
#define	 DISCADDLOG	    9
#define	 SUBDISCADDLOG	10
#define	 DIRECTLOG		11
#define	 SUBDIRECTLOG	12
#define	 REGISLOG		13
#define	 SUBTOTALLOG	14
#define	 SLIPREGISLOG	15
#define	 SLIPENDLOG	    16
#define	 INSERTICLOG	17
#define	 REFRESHICLOG	18
#define	 PRICELISTLOG	19
#define  ECRNOLOG       20
#define  TVOIDLOG		21
#define	 PBCLOSELOG		22
#define  PBOPENLOG		23
#define	 TRTABLELOG		24			//transfer table
#define  PORALOG		25
#define  NETIDLOG		26      //ccr2014-12-26 Net ID
#define  TAXLOG		    27      //ccr2014-12-29 TAX Log

#define  LOGTYPEMAX  	25

#define TENDLOGMAX		8		//��ˮ��¼�У�ÿһ�ʽ����������8�θ��ʽ //

#define LOGONRAM	1	//

#ifdef  LOGONRAM
#define FLSTARTADDRE 0xa8000
#define FLOWMAXB	512*1024L
#else
#define FLSTARTADDRE 0x00000L
#define FLOWMAXB	 512*1024L
#endif

#define SHEETDEPT	0
#define SHEETPLU	(SHEETDEPT+1)
#define SHEETREC    (SHEETPLU+1)
#define SHEETDISC   (SHEETREC+1)
#define SHEETOPER   (SHEETDISC+1)
#define SHEETSALPER (SHEETOPER+1)
#define SHEETLOG    (SHEETSALPER+1)
#define SHEETPBLOG  (SHEETLOG+1)

#define LOGALARMON	1024
#define RECEIPTLEN      3

struct CDC_DPT							//dept record
{
	BYTE FunN;
	WORD DeptN;							// department number
	BYTE FQty[4];						// translate quantity
	BYTE FAmt[5];						// translate value
//	BYTE Reserve[SERNUM];				// reserve
};
struct CDC_ART							//Plu record
{
	BYTE FunN;
	BYTE ArtN[7];						// Plu number
	WORD DeptN;							// dept number
	BYTE FQty[4];						// translate quantity
	BYTE FAmt[5];						// translate value
	WORD OffNum;						// offset number
//	BYTE Reserve[SERNUM];				// reserve
};
struct CDC_END							//translat end record
{
	BYTE FunN;
	BYTE ReceiptNum[RECEIPTLEN];	// receipt number
	BYTE Fcost[6];						//	cost
	BYTE FYear;
	BYTE FMonth;						 //
	BYTE FDay;							 // date
	BYTE FHour;
	BYTE FMinute;
//	BYTE Reserve[SERNUM];				// reserve
};
struct CDC_NOADD						//no added record
{
	BYTE FunN;
	BYTE Num[5];						// input number
//	BYTE Reserve[SERNUM];				// reserve
};
struct CDC_OPER							//operator record
{
	BYTE FunN;
	BYTE OperN;							// operator number
//	BYTE Reserve[SERNUM];				// reserve
};
struct GIVEN_DATA
{
	BYTE FTType;						// type
	BYTE FAmt[5];
}; 						// amount
struct CDC_GIVEN						//currency record
{
	BYTE FunN;
	BYTE Counter;
	struct GIVEN_DATA GivenData[TENDLOGMAX];
//	BYTE Reserve[SERNUM];				// reserve
};
struct CDC_LOCK				   			//mode_lock record
{
	BYTE FunN;
	BYTE NoModeLock;				   		// mode number
//	BYTE Reserve[SERNUM];				// reserve
};
struct CDC_DISCADD						//discount and add record
{
	BYTE FunN;
	BYTE Percent[2];					// percent
	BYTE FAmt[5];
	BYTE ArtN[7];						//
//	BYTE Reserve[SERNUM];				// reserve
};
struct CDC_SUBDISCADD					//subtotal discount and add record
{
	BYTE FunN;
	BYTE Percent[2];					// percent
	BYTE FAmt[5];
//	BYTE Reserve[SERNUM];				// reserve
};
struct CDC_DIRECT						//direct sum discount record
{
	BYTE FunN;
	BYTE FAmt[5];
	BYTE ArtN[7];
//	BYTE Reserve[SERNUM];				// reserve
};
struct CDC_SUBDIRECT					//subtotal sum discount record
{
	BYTE FunN;
	BYTE FAmt[5];
//	BYTE Reserve[SERNUM];				// reserve
};
struct CDC_REGIS						//start register record
{
	BYTE FunN;
	WORD EcrNumber;						// ccr2014-11-14  Ecr number
	BYTE OperNo;						// operator number
	BYTE SalesPer;						// SalesPerson number
	BYTE ReceiptNum[RECEIPTLEN];	// receipt number
	BYTE FYear;
	BYTE FMonth;						 //
	BYTE FDay;							 // date
	BYTE FHour;
	BYTE FMinute;
	BYTE FSecond;				// reserve
//	BYTE Reserve[SERNUM];				// reserve
};
struct CDC_SUBTOTAL						//subtotal record
{
	BYTE FunN;
	BYTE ReceiptNum[RECEIPTLEN];	 // receipt number
	BYTE FAmt[5];
	BYTE FYear;
	BYTE FMonth;						 //
	BYTE FDay;							 // date
	BYTE FHour;
	BYTE FMinute;
//	BYTE Reserve[SERNUM];				// reserve
};
struct CDC_SLIPREGIS					//
{
	BYTE FunN;
	BYTE FileT;							// file type
	BYTE FileNo[3];
	WORD CustNO;						// customer number
	BYTE OperNo;
	BYTE InvoiceNo[2];					// invoice number
//	BYTE Reserve[SERNUM];				// reserve
};
struct CDC_SLIPEnd						//
{
	BYTE FunN;
	BYTE FileT;							// file type
	BYTE FileNo[3];
	BYTE InvoiceNo[2];					// invoice number
	BYTE FAmt[5];						// fair amount
	BYTE FYear;
	BYTE FMonth;						 //
	BYTE FDay;							 // date
	BYTE FHour;
	BYTE FMinute;
//	BYTE Reserve[SERNUM];				// reserve
};

struct CDC_EnterIC						//record of enter ic
{
	BYTE FunN;
	UnLong Serialum;
	BYTE ICType;
	BYTE ICFlag;
	BYTE FYear;
	BYTE FMonth;						 //
	BYTE FDay;							 // date
	BYTE Custname[10];
	BYTE Custflag[2];
	BYTE Discount[2];
	BYTE Value[4];
	BYTE Point[4];
//	BYTE Reserve[SERNUM];				// reserve
};
struct CDC_REFRESHIC					//record of refresh IC
{
	BYTE FunN;
	UnLong Serialum;					//serial number of IC
	BYTE ICType;						//IC type
	BYTE ICFlag;						//IC flag
	BYTE FYear;
	BYTE FMonth;						 //
	BYTE FDay;							 // date
	BYTE Custname[10];
	BYTE Custflag[2];
	BYTE Discount[2];
	BYTE CValue[5];						//currency value
	BYTE CPoint[4];
	BYTE OpType;						//0=NO VAT TRANSLATE,1=Clear Chipcard,2=ADD,3=SUB,4=Charge value,5=Initital chipcard
	BYTE RValue[5];						//refresh value
	BYTE RPoint[4];						// refresh point
//	BYTE Reserve[SERNUM];				// reserve
};
struct CDC_PRICELIST 					//19 relative price list
{
	BYTE FunN;
	BYTE PListNo;						//value = 1,2 or 3
//	BYTE Reserve[SERNUM];				// reserve
};

struct CDC_ECRNUM
{
	BYTE FunN;
	WORD EcrNumber;						//value = 1,2 or 3
};

struct CDC_VOID 						 //for r_version close table
{
	BYTE FunN;
	BYTE FAmt[5];
	BYTE FYear;
	BYTE FMonth;						 //
	BYTE FDay;							 // date
	BYTE FHour;
	BYTE FMinute;
};

struct CDC_PBCLOSE						 //for r_version close table
{
	BYTE FunN;
    	WORD PBNo;
	BYTE FAmt[5];
	BYTE FYear;
	BYTE FMonth;						 //
	BYTE FDay;							 // date
	BYTE FHour;
	BYTE FMinute;
};

struct CDC_PBOPEN						 //for r_version close table
{
	BYTE FunN;
    WORD PBNo;
	BYTE FYear;
	BYTE FMonth;						 //
	BYTE FDay;							 // date
	BYTE FHour;
	BYTE FMinute;
};

struct CDC_PBTT						 //for r_version close table
{
	BYTE FunN;
    WORD PBFNo;						 //from table
    WORD PBTNo;						 //to table
	BYTE FAmt[5];
	BYTE FYear;
	BYTE FMonth;						 //
	BYTE FDay;							 // date
	BYTE FHour;
	BYTE FMinute;
};

struct CDC_PORA							//Pora record
{
	BYTE FunN;
	WORD PoRaN;							// department number
	BYTE FAmt[5];						// translate value
//	BYTE Reserve[SERNUM];				// reserve
};


union FLOWREC
{
	struct CDC_DPT			 CDC_dpt;				//dept record
	struct CDC_ART			 CDC_art;				//Plu record
	struct CDC_END			 CDC_end;				//translat end record
	struct CDC_NOADD		 CDC_noadd;				//no added record
	struct CDC_OPER			 CDC_oper;				//operator record
	struct CDC_GIVEN		 CDC_given;				//currency record
	struct CDC_LOCK			 CDC_lock;	   			//mode_lock record
	struct CDC_DISCADD		 CDC_discadd;			//discount and add record
	struct CDC_SUBDISCADD	 CDC_subdiscadd;		//subtotal discount and add record
	struct CDC_DIRECT		 CDC_direct;			//direct sum discount record
	struct CDC_SUBDIRECT	 CDC_subdirect;			//subtotal sum discount record
	struct CDC_REGIS		 CDC_regis;				//start register record
	struct CDC_SUBTOTAL		 CDC_subtotal;			//subtotal record
	struct CDC_SLIPREGIS	 CDC_slipregis;			//
	struct CDC_SLIPEnd		 CDC_slipend;
	struct CDC_EnterIC		 CDC_enteric;			//record of enter ic
	struct CDC_REFRESHIC	 CDC_refreshic;			//record of refresh IC
	struct CDC_PRICELIST 	 CDC_pricelist; 		//19 relative price list
	struct CDC_ECRNUM		 CDC_EcrNum;			//only send to manage systyem
	struct CDC_VOID 		 CDC_Void;				 //for r_version close table
	struct CDC_PBCLOSE		 CDC_PbClose;			//record the operation of close table
	struct CDC_PBOPEN		 CDC_PbOpen;			//record the operation of open table
	struct CDC_PBTT			 CDC_PbTt;				//record the operation of translate table
	struct CDC_PORA			 CDC_PoRa;				//record the operation of translate table
};

//---------------------------------------------------------------------------
struct ECRLOGDES {
    short    RecSize;
	void  (*Get1Record)();
};

extern struct 	FifoHeader FlowHeader;

extern void Collect_Given(void);
extern short Read_Flow(BYTE *Area);
extern void	Init_Flow(void);
extern short Collect_Data(BYTE cmd);
extern void SUB_SCANFP(BYTE Size);
extern void WriteToLogRam(CONSTCHAR *pTo,char *pFrom,short pSize);
extern void ReadFrLogRam(char *pTo,CONSTCHAR *pFrom,short pSize);
extern void ResetECRFlow(void);
extern struct 	FifoHeader FlowHeader;

extern union  FLOWREC	FlowBuff;

#endif



