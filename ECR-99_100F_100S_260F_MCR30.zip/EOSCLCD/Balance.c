#define BALANCE_C
#include "king.h"                               /* Kingtron library and I/O routines */

#include "exthead.h"
#include "exth.h"

#define BALBUFMAX  50

short   BalCounter;
BYTE    BalBuff[BALBUFMAX];

#if (0)//defined(CASE_GREECE)
/********ϣ�����ӳ�PS1X PRICE COMPUTING SCALE -M-M6-21**********************************
Read current weight:
PC sends 0X05, after receiving scale response 0x06, sends 0x11, scale will response weight package.
Weight Package formats:SOH STX STA SIGN WEIGHT_ASCII WEIGHT_UNIT BCC ETX EOT
SOH: start to sending symbol, one byte, fixed at 01H.
STX: start symbol of data item, one byte, fixed at 02H.
STA: words to describe weight status, one byte, only possible to be 53H or 55H46H.
     53H �Cweight is stable,
     55H �C weight is unstable,
     46H �Cweight is abnormal.
SIGN: sign of weight, one byte, only possible to be 2DH or 20H. 2DH-weight is negative, 20H-weight is positive.
WEIGHT_ASCII: character string of weight. 5~6 byte, only possible to be 30H~39H, decimal (2EH), space (20H)
WEIGHT_UNIT : character string of weight unit. 1~2 byte, only possible to be :
     ��TJ��: catty of Taiwan,
     ��TL��: tael of Taiwan,
     ��SJ��: jin,
     ��LB��: pound,
     ��kg��: kilogram,
     ��g��: gram.
BCC: character of data verify. One byte. Set STA to D1, SIGN to D2, byte before BCC to DN, so:
     BCC=D1^D2^. .^DN.'^�� is a logic XOR operator.
ETX: symbol of ending data item, one byte, fixed at 03H.
EOT: symbol of ending sending, one byte, fixed at 04H.
******************************************************************************/

short BalanceWeight(short sType)
{

    BYTE bport,sOK;
    short c;
    BYTE sLow,sHigh;        //cc 2006-06-30 for Balance

    bport = BALANCE & 0x07;
    if (!bport || ApplVar.ErrorNumber || ApplVar.CentralLock == OFF)
        return 0;

    if (sType)
    {
        SendComm(bport-1,0x05);
        sLow = 8;
        sHigh = 13;
    } else
    {
        sLow = 2;
        sHigh = 7;
    }

    sOK = FALSE;
    while (!sOK)
    {
        if (sType)
        {
            if (BalCounter == 10)        //cc 20070917 for DIBAL>>>>>>>>>>>>>>>
                BalBuff[BalCounter++] = '.';
            if ((c=ReadComm(bport-1))==-1)
                return 0;
        } else
        {
            if (!CheckComm(bport-1) || (c = ReadComm(bport-1))==-1)
                return 0;
        }

        BalBuff[BalCounter++] = c;
        if (BalCounter>=BALBUFMAX)
        {
            BalCounter = 0;
            return 0;
        }

        switch (c)
        {
        case 0x0a:
            BalCounter = 0;
            return 0;
        case 0x0d:              //End of a Bar code
            BalCounter --;
            BalBuff[BalCounter]=0;
            sOK = TRUE;
            break;
        default:;
        }
    }
    ClearEntry();

    InActive = 0;//Disable display datetime
    sOK = FALSE;

    if (BalCounter > sHigh)
        BalCounter = sHigh;

    for (c = sLow;c<=BalCounter;c++)
    {
        if ( (BalBuff[c]>='0' && BalBuff[c]<='9') || BalBuff[c]=='.')
        {
            ApplVar.OldKey.Code = 0;
            ApplVar.Key.Code = BalBuff[c];

            //KeyInput(ApplVar.Key.Code);	//ccr 040420
            ProcessKey(); // liuj 0921
            Bell(1);
            sOK=TRUE;
        } else if (sOK)
            break;
    }

    BalCounter = 0;

    if (!sOK)
        return 0;

    if (ApplVar.CentralLock == RG || ApplVar.CentralLock == MG)
    {
        ApplVar.OldKey.Code = 0;
        ApplVar.Key.Code = MULT;

        if (sType)
            ProcessKey();

        ApplVar.FBalance = 1;
        return 1;
    } else
        return 0;
}

#else

short BalanceWeight(short sType)
{
#if (DD_FISPRINTER==0)
    BYTE bport,sOK;
    short c;
    BYTE sLow,sHigh;        //cc 2006-06-30 for Balance

    bport = BALANCE & 0x07;
    if (!bport || ApplVar.ErrorNumber || ApplVar.CentralLock == OFF)
        return 0;

//cc 20070917 for DIBAL>>>>>>>>>>>>>>>
    if (sType)
    {
        SendComm(bport-1,0x05);
        sLow = 8;
        sHigh = 13;
    } else
    {
        sLow = 2;
        sHigh = 7;
    }
//cc 20070917 for DIBAL>>>>>>>>>>>>>>>

    sOK = FALSE;
    while (!sOK)
    {
        //if (!CheckComm(bport-1) || (c = ReadComm(bport-1))==-1)
        //if((c = ReadComm(bport-1))==-1)
        if (sType)
        {
            if (BalCounter == 10)        //cc 20070917 for DIBAL>>>>>>>>>>>>>>>
                BalBuff[BalCounter++] = '.';
            if ((c=ReadComm(bport-1))==-1)
                return 0;
        } else
        {
            if (!CheckComm(bport-1) || (c = ReadComm(bport-1))==-1)
                return 0;
        }

        BalBuff[BalCounter++] = c;
        if (BalCounter>=BALBUFMAX)
        {
            BalCounter = 0;
            return 0;
        }

        switch (c)
        {
        case 0x0a:
            BalCounter = 0;
            return 0;
        case 0x0d:              //End of a Bar code
            BalCounter --;
            BalBuff[BalCounter]=0;
            sOK = TRUE;
            break;
        default:;
        }
    }
    ClearEntry();

    InActive = 0;//Disable display datetime
    sOK = FALSE;
//cc 2006-06-29 for Balance>>>>>>>>>>>>>
    //if (BalCounter>BalRange[BALTYPE].High)
    //BalCounter =BalRange[BALTYPE].High;//ccr 050513
    if (BalCounter > sHigh)
        BalCounter = sHigh;

    //for (c = BalRange[BALTYPE].Low;c<=BalCounter;c++)
    for (c = sLow;c<=BalCounter;c++)
    //cc 2006-06-29 for Balance>>>>>>>>>>>>>
    {
        if ( (BalBuff[c]>='0' && BalBuff[c]<='9') || BalBuff[c]=='.')
        {
            ApplVar.OldKey.Code = 0;
            ApplVar.Key.Code = BalBuff[c];

            //KeyInput(ApplVar.Key.Code);	//ccr 040420
            ProcessKey(); // liuj 0921
            Bell(1);
            sOK=TRUE;
        } else if (sOK)
            break;
    }

    BalCounter = 0;

    if (!sOK)
        return 0;

    if (ApplVar.CentralLock == RG || ApplVar.CentralLock == MG)
    {
        ApplVar.OldKey.Code = 0;
        ApplVar.Key.Code = MULT;
//cc 2006-06-29 for Balance>>>>>>>>>>>>>
        if (sType)
            ProcessKey();
//cc 2006-06-29 for Balance>>>>>>>>>>>>>
        ApplVar.FBalance = 1;
        return 1;
    } else
#endif
        return 0;
}
#endif

