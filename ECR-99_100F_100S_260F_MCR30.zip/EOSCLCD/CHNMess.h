//---------------------------------------------------------------------------
#ifndef CHNMESS
#define CHNMESS
#define SPACE      0

#define CWXXI01    1                     //="��Ч����!"
#define CWXXI02    (CWXXI01+1)           //="��Ч����!"
#define CWXXI03    (CWXXI02+1)           //="��Чʱ��!"
#define CWXXI04    (CWXXI03+1)           //="��ֹ����!"
#define CWXXI05    (CWXXI04+1)           //="PLU����Ϊ��!"
#define CWXXI06    (CWXXI05+1)           //="PLU�ļ����!"
#define CWXXI07    (CWXXI06+1)           //="��̨��ռ��!"
#define CWXXI08    (CWXXI07+1)           //="��̨�Ѵ�!"
#define CWXXI09    (CWXXI08+1)           //="��̨�Ų���!"
#define CWXXI10    (CWXXI09+1)           //="��������̨��"
#define CWXXI11    (CWXXI10+1)           //="��̨û�п�̨"
#define CWXXI12    (CWXXI11+1)           //="��̨�������"
#define CWXXI13    (CWXXI12+1)           //="��ֹ�޸�ʱ��"
#define CWXXI14    (CWXXI13+1)           //="����������!"
#define CWXXI15    (CWXXI14+1)           //="���ۻ�������"
#define CWXXI16    (CWXXI15+1)           //="��Ʒû���۳�"
#define CWXXI17    (CWXXI16+1)           //="���ڽ�����!"
#define CWXXI18    (CWXXI17+1)           //="�������ݳ���"
#define CWXXI19    (CWXXI18+1)           //="���ڸ���!"
#define CWXXI20    (CWXXI19+1)           //="�������!"
#define CWXXI21    (CWXXI20+1)           //="û��ȷ�Ͻ���"
#define CWXXI22    (CWXXI21+1)           //="��ֹȡ������"
#define CWXXI23    (CWXXI22+1)           //="�޲���!"
#define CWXXI24    (CWXXI23+1)           //="�޴��տ�Ա!"
#define CWXXI25    (CWXXI24+1)           //="�տ�Ա�ı�"
#define CWXXI26    (CWXXI25+1)           //="�޴��౨��!"
#define CWXXI27    (CWXXI26+1)           //="������ӡ�ж�"
#define CWXXI28    (CWXXI27+1)           //="�����ھ�����"
#define CWXXI29    (CWXXI28+1)           //="���ܷ���ʱ��"
#define CWXXI30    (CWXXI29+1)           //="�����������"
#define CWXXI31    (CWXXI30+1)           //="ת�뵽"
#define CWXXI32    (CWXXI31+1)           //="δ��Ȩ!"
#define CWXXI33    (CWXXI32+1)           //="��ָ���տ�Ա"
#define CWXXI34    (CWXXI33+1)           //="��ָ��ӪҵԱ"
#define CWXXI35    (CWXXI34+1)           //="��ֹPLU��ۣ�"
#define CWXXI36    (CWXXI35+1)           //="���벻��!"
#define CWXXI37    (CWXXI36+1)           //="������ӡ����"
#define CWXXI38    (CWXXI37+1)           //="Ʊ�ݴ�ӡ����"
#define CWXXI39    (CWXXI38+1)           //="��ӡѹ��̧��"
#define CWXXI40    (CWXXI39+1)           //="��ӡֽ����!"
#define CWXXI41    (CWXXI40+1)           //="��ӡ�¶�̫��"
#define CWXXI42    (CWXXI41+1)           //="����δ����!"
#define CWXXI43    (CWXXI42+1)           //="����������"
#define CWXXI44    (CWXXI43+1)           //="��ֹ���ָ���"
#define CWXXI45    (CWXXI44+1)           //="�����޴˹���"
#define CWXXI46    (CWXXI45+1)           //="δ��С�Ƽ�!"
#define CWXXI47    (CWXXI46+1)           //="���ڹ������"
#define CWXXI48    (CWXXI47+1)           //="������ˮ��"
#define CWXXI49    (CWXXI48+1)           //="MODEMͨѶ��!"
#define CWXXI50     (CWXXI49+1)          //="����������!"
#define CWXXI51     (CWXXI50+1)          //="POS�����!"
#define CWXXI52     (CWXXI51+1)          //="�����ݴ�!"
#define CWXXI53     (CWXXI52+1)          //="Ϊ���ڿ�!"
#define CWXXI54     (CWXXI53+1)          //="Ϊ��ʧ��!"
#define CWXXI55     (CWXXI54+1)          //="�ͻ�����!"
#define CWXXI56     (CWXXI55+1)          //="Ϊ�¿�!"
#define CWXXI57     (CWXXI56+1)          //="���ǹ��￨!"
#define CWXXI58     (CWXXI57+1)          //="д������!"
#define CWXXI59     (CWXXI58+1)          //="���Ų���!"
#define CWXXI60     (CWXXI59+1)          //="�����ۿۿ�!"
#define CWXXI61     (CWXXI60+1)          //="�����ֽ�!"
#define CWXXI62     (CWXXI61+1)          //="�������ʿ�!"
#define CWXXI63     (CWXXI62+1)          //="����IC��!"
#define CWXXI64     (CWXXI63+1)          //="�忨����!"
#define CWXXI65     (CWXXI64+1)          //="�������!"
#define CWXXI66     (CWXXI65+1)          //="IC��ֵ����!"
#define CWXXI67     (CWXXI66+1)          //="IC��ʼ������"
#define CWXXI68     (CWXXI67+1)          //="��ֹ��ʼ��!"
#define CWXXI69     (CWXXI68+1)          //="IC����!"
#define CWXXI70     (CWXXI69+1)          //="IC�������!"
#define CWXXI71     (CWXXI70+1)          //="IP��ַ��"
#define CWXXI72	 (CWXXI71+1)             //="��Ƶ������!"
#define CWXXI73	 (CWXXI72+1)             //="����ʧ��!"
#define CWXXI74	 (CWXXI73+1)             //="NO FISCAL MEMORY"
#define CWXXI75  (CWXXI74+1)             //="PRINT Z-REPORT"
#define CWXXI76  (CWXXI75+1)             //="WRITE FM ERROR"
#define CWXXI77  (CWXXI76+1)             //=FM����//
#define CWXXI78  (CWXXI77+1)             //="FM ERROR"
#define CWXXI79  (CWXXI78+1)             //="FISCALIZED"
#define CWXXI80  (CWXXI79+1)             //="Train Mode"
#define CWXXI81  (CWXXI80+1)             //="INITIALIZE FM"
#define CWXXI82  (CWXXI81+1)             //=EJ�е������д�//
#define CWXXI83  (CWXXI82+1)             //="NO EJ"
#define CWXXI84  (CWXXI83+1)             //=EJ ��д����//
#define CWXXI85  (CWXXI84+1)             //=EJ������//
#define CWXXI86  (CWXXI85+1)             //="FM IS FULL"
#define CWXXI87  (CWXXI86+1)             //=EJ����//
#define CWXXI88  (CWXXI87+1)             //="EJ IS FULL"
#define CWXXI89  (CWXXI88+1)             //="EJ LIMIT: 100"
#define CWXXI90  (CWXXI89+1)             //="New EJ"
#define CWXXI91  (CWXXI90+1)             //=���200�μӵ��ʼ��//
#define CWXXI92  (CWXXI91+1)             //="CHECKSUM ERROR"
#define CWXXI93  (CWXXI92+1)             //=FM ���տ����ƥ��//
#define CWXXI94  (CWXXI93+1)             //="NEW FM"
#define CWXXI95  (CWXXI94+1)             //="O.Battery Low!"
#define CWXXI96  (CWXXI95+1)             //="NOT ALLOWED"
#define CWXXI97  (CWXXI96+1)             //="INITIALIZE EJ"
#define CWXXI98  (CWXXI97+1)             //=EJ���տ����ƥ��//
#define CWXXI99  (CWXXI98+1)             //="STOCK DISABLED"
#define CWXXI100  (CWXXI99+1)            //="INVALID TAX"
#define CWXXI101  (CWXXI100+1)   //TAX<0

#if (defined(CASE_GPRS) || defined(CASE_ETHERNET))
#define CWXXI102 (CWXXI101+1) //GPRS����
#define CWXXI103 (CWXXI102+1) //�������ݳ���
#define CWXXI104 (CWXXI103+1) //�������ݳ���
#define CWXXI105 (CWXXI104+1) //�޷����ӷ�����
#define CWXXI106 (CWXXI105+1) //�޷�����IP��ַ
#define CWXXI107 (CWXXI106+1) //��SIM��
#define CWXXI108 (CWXXI107+1) //GPRSδ����
#define CWXXI109 (CWXXI108+1) //����δ���
#define CWXXI110 (CWXXI109+1) //����ͨѶʧ��

#if(DD_ZIP==1 || DD_ZIP_21==1||DD_LCD_1601)
#define KAHAO    (CWXXI110+1)   //101
#define TRAINMODE   CWXXI80
#else
#define KAHAO           1
#endif

#else

#if(DD_ZIP==1 || DD_ZIP_21==1||DD_LCD_1601)
#define KAHAO    (CWXXI101+1)   //101
#define TRAINMODE   CWXXI80
#else
#define KAHAO           1
#endif

#endif

#define KLXING          (KAHAO      +1)
#define KNJE            (KLXING     +1)
#define KYJIN           (KNJE       +1)
#define XFZE            (KYJIN      +1)
#define CHZHZE          (XFZE       +1)
#define SHYCSHU         (CHZHZE     +1)
#define JGLBIE          (SHYCSHU    +1)
#define PINMA           (JGLBIE     +1)
#define BHJBIE          (PINMA      +1)
#define ZDJZHANG        (BHJBIE     +1)
#define ZHKRQI          (ZDJZHANG   +1)
#define KYXQI           (ZHKRQI     +1)
#define KHMCHEN         (KYXQI      +1)
#define CHSHHICKA       (KHMCHEN    +1)
#define ICKCHZHI        (CHSHHICKA  +1)
#define QCHICKA         (ICKCHZHI   +1)
#define GUASHIIC	       (QCHICKA   +1)
#define ZHEKOUCA		(GUASHIIC   +1)
#define XIANJINKA		(ZHEKOUCA   +1)
#define SHEZHANGKA		(XIANJINKA   +1)
#define XFJIDIAN	(SHEZHANGKA    +1)

#define ZHKLVF		(XFJIDIAN    +1)

#define ICKTKUAN        (ZHKLVF    +1)
#define ICKDJDIANG      (ICKTKUAN   +1)
#define ICKSDIAN        (ICKDJDIANG +1)
#define ZHUOTAI        (ICKSDIAN +1)

// liuj 0813
#define RECNUMFR	(ZHUOTAI+1)
#define RECNUMTO	(RECNUMFR+1)

#define EJCSHUA		(RECNUMTO+1)
#define EJBHAO		(EJCSHUA+1)
#define EJBBIAO		(EJBHAO+1)
#define HSJXSHOU	(EJBBIAO+1)

// liuj 0813


#if (defined(FISCAL) || DD_FISPRINTER==1)
//cc 2006-09-19 for Fiscal>>>>>>>>>>>>>>>>>>
#define VATA			(HSJXSHOU+1)
#define VATB			(VATA+1)
#define VATC			(VATB+1)
#define VATD			(VATC+1)
#define VATE			(VATD+1)
#define VATF			(VATE+1)
#define VATG			(VATF+1)
#define VATH			(VATG+1)
#define TAXTOTAL		(VATH+1)
#define NETSALE		(TAXTOTAL+1)
#define RECNUMBER		(NETSALE+1)
#define FMPULLOUT		(RECNUMBER+1)	//ccr071212
#define CHANGEHEAD		(FMPULLOUT+1)
#define TAXACHG		(CHANGEHEAD+1)
#define TAXBCHG		(TAXACHG+1)
#define TAXCCHG		(TAXBCHG+1)
#define TAXDCHG		(TAXCCHG+1)
#define TAXECHG		(TAXDCHG+1)
#define TAXFCHG		(TAXECHG+1)
#define TAXGCHG		(TAXFCHG+1)
#define TAXHCHG		(TAXGCHG+1)
#define TAXFROM		(TAXHCHG+1)
#define TAXTO		(TAXFROM+1)
//#define RECNUMFR	(TAXTO+1)
//#define RECNUMTO	(RECNUMFR+1)
#define PRNFISCAL	(TAXTO+1)
#define PRNTOTAL	(PRNFISCAL+1)
#define CLEARTOTAL	(PRNTOTAL+1)
#define MACRESET	(CLEARTOTAL+1)
#define CHANGETAX	(MACRESET+1)

//#define ICSZMIMA    	(DYJKAI    +1)
//cc 2006-09-19 for Fiscal>>>>>>>>>>>>>>>>>>
//hf 20060919 for fiscal >>>>>>>>>>>>>>>>>>>>>>>>>>>
#define SHKZBB		(CHANGETAX+1)
#define TAXCODE		(SHKZBB+1)
#define RIFCODE		(TAXCODE+1)
#define MIANSHUI	(RIFCODE+1)
#define SHUIMUA		(MIANSHUI+1)
#define KHMINGCH	(SHUIMUA+1)
#define JIQIHAO		(KHMINGCH+1)
#define RIQI			(JIQIHAO+1)
#define SHIJIAN		(RIQI+1)
#define XSHZHJI		(SHIJIAN+1)
#define THUOZHJI	(XSHZHJI+1)
#define ZHKOUZHJI	(THUOZHJI+1)
#define XIAOSHOUA	(ZHKOUZHJI+1)
#define THXIAOSHOU	(XIAOSHOUA+1)
#define ZHKOUXSH	(THXIAOSHOU+1)
#define THZJSHUI		(ZHKOUXSH+1)
#define ZHKZJSHUI	(THZJSHUI+1)


#define EJXINXI		(ZHKZJSHUI+1)
//hf end <<<<<<<<<<<<<<<<<<<<<<<<<<<<
#define EJSHJIAN		(EJXINXI+1)
#define NONFISCAL	(EJSHJIAN+1)
#define SHKCSHUA 	(NONFISCAL+1)
#define RIQIF		(SHKCSHUA+1)
#define SHIJIANF		(RIQIF+1)
#define JSHRQIF		(SHIJIANF+1)
#define ZHJIFPHAO	(JSHRQIF+1)
#define ZHJITHHAO	(ZHJIFPHAO+1)
#define ZHJIFSHHAO	(ZHJITHHAO+1)
#define FAPIAOHAO	(ZHJIFSHHAO+1)
#define THUOHAO		(FAPIAOHAO+1)
#define FEISHUIHAO	(THUOHAO+1)
#define SHKBBHAO	(FEISHUIHAO+1)

#define QZHJSHU		(SHKBBHAO+1)

#define REPLEFT		 (QZHJSHU   +1)

#define SIZEFM		(REPLEFT+1)
#define SIZEEJ		(SIZEFM+1)

#else
#define SIZEEJ		(HSJXSHOU+1)
#endif

#define VALUEINIC       (SIZEEJ   +1)
#define LOWBAT           (VALUEINIC +1)
#define CLEARIC	        (LOWBAT  +1)
#define CHARGEIC        (CLEARIC	+1)
#define ADPOINTS        (CHARGEIC   +1)
#define INITIC          (ADPOINTS   +1)
#define WAITEICCARD     (INITIC   +1)
#define ICCARDOK		(WAITEICCARD+1)	//
//ChipCard<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#define ePOSTAC			(ICCARDOK+1)	//ccr epos
#define WAITEPOS		(ePOSTAC+1)//ccr epos
#define ePOSCARNO		(WAITEPOS+1)
#define eCARREMAIN		(ePOSCARNO+1)
#define TMHYHAO			(eCARREMAIN+1)
#define BARREPORT		(TMHYHAO+1)
#define XFJE			(BARREPORT+1)
#define ZONGJI			(XFJE+1)


#define	BREAK485  		(ZONGJI+1)
#define	LINK485			(BREAK485+1)
#define WAITING		    (LINK485+1)
#define INITWAITING     (WAITING+1)

#define RECEIPTFROM	    (INITWAITING+1)         //    Cc	"��ʼ�վݺ�",	//
#define RECEIPTTO	    (RECEIPTFROM+1)       //    Cc	"�����վݺ�",	//

#define SUM_EXC_VAT     (RECEIPTTO+1)//����˰���۽��
#define VAT_AMOUNT       (SUM_EXC_VAT+1) //˰��

#if (!defined(CASE_GPRS))		// ADD BY LQW 090827
#define HZMESSMAX_GPRS  	    (VAT_AMOUNT+1)
#else
//ccr2014-11-11 NEWSETUP Step-4 �Ӳ˵���Ŀ��Ϣ���>>>>>>>>>>>>>>

#define gprsSENDMESS    (VAT_AMOUNT+1)
#define gprsSETMODE  (gprsSENDMESS+1)
#define gprsSendECRLog (gprsSETMODE+1)
#define gprsSendECRLogAll (gprsSendECRLog+1)
#define gprsDownloadPLU     (gprsSendECRLogAll+1) //"���ص�Ʒ�ļ�"
#define gprsDownloadDEPT    (gprsDownloadPLU+1)     //"���ز����ļ�"
#define gprsDownloadCLERK   (gprsDownloadDEPT+1) //"�����տ�Ա"
#define gprsDownloadHEAD    (gprsDownloadCLERK+1) //"����Ʊͷ"
#define gprsDownloadTRAIL   (gprsDownloadHEAD+1) //"����Ʊβ"
#define gprsDownloadALL   (gprsDownloadTRAIL+1) //"����ȫ������"
#define gprsRestart         (gprsDownloadALL+1)//  "��λGPRS"    //gprsRestart //ccr2016-08-26

#define GPRSFUNCTION    gprsSENDMESS
#define gprsMAINITEMS   (gprsRestart-gprsSENDMESS+1)        //�Ӳ˵���Ŀ��,��Ҫ�޸�MENUGPRSFUNSMAX

#define HZMESSMAX_GPRS	    (gprsRestart+1) //<<<<<<<<
#endif

#if (!defined(CASE_ETHERNET))		// ADD BY LQW 090827
#define HZMESSMAX  	    (HZMESSMAX_GPRS)
#else
//ccr2014-11-11 NEWSETUP Step-4 �Ӳ˵���Ŀ��Ϣ���>>>>>>>>>>>>>>

#define ethernetPINGMESS    (HZMESSMAX_GPRS)
#define ethernetSETMODE  (ethernetPINGMESS+1)
#define ethernetSendECRLog (ethernetSETMODE+1)
#define ethernetSendECRLogAll (ethernetSendECRLog+1)
#define ethernetDownloadPLU     (ethernetSendECRLogAll+1) //"���ص�Ʒ�ļ�"
#define ethernetDownloadDEPT    (ethernetDownloadPLU+1)     //"���ز����ļ�"
#define ethernetDownloadCLERK   (ethernetDownloadDEPT+1) //"�����տ�Ա"
#define ethernetDownloadHEAD    (ethernetDownloadCLERK+1) //"����Ʊͷ"
#define ethernetDownloadTRAIL   (ethernetDownloadHEAD+1) //"����Ʊβ"
#define ethernetDownloadALL   (ethernetDownloadTRAIL+1) //"����ȫ������"
#define ethernetRestart         (ethernetDownloadALL+1)//  "��λGPRS"    //ethernetRestart //ccr2016-08-26

#define ETHERNETFUNCTION    ethernetPINGMESS
#define ethernetMAINITEMS   (ethernetSendECRLogAll-ethernetPINGMESS+1)        //�Ӳ˵���Ŀ��,��Ҫ�޸�MENUGPRSFUNSMAX
//#define ethernetMAINITEMS   (ethernetRestart-ethernetPINGMESS+1)        //�Ӳ˵���Ŀ��,��Ҫ�޸�MENUGPRSFUNSMAX

#define HZMESSMAX	    (ethernetRestart+1) //<<<<<<<<
#endif
// MSg[]<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

//index of LineCap>>>>>>>>>>>>>>>>>>>
#define Line_YES    	0
#define Line_NO    		1
#define Line_CAPTION    2
#define Line_DEPART    	3
#define Line_GROUP    	4
#define Line_SYS_FLAG   5
#define Line_PRINT    	6
#define Line_OPTION    	7
#define Line_EXTRAKP    8 //KP EP = extra printer
#define Line_TAXUSED    9
#define Line_LOC    	10
#define Line_PRICE1    	11
#define Line_PRICE2    	12
#define Line_PRICE3    	13
#define Line_PRICE4    	14
#define Line_COST    	15
#define Line_FIXED    	16
#define Line_MAX     	17
#define Line_FIXED1   	18
#define Line_MAX1   	19
#define Line_TAXRATE    20
#define Line_BUYRATE    21
#define Line_SELRATE    22
#define Line_START    	23
#define Line_DRAWER    	24
#define Line_OTD    	25 //��������С��
#define Line_PRTTYPE    26
#define Line_PERIOD    	27
#define Line_REPTYPE    28
#define Line_PREFIX    	29
#define Line_LINK    	30
#define Line_KEYCODE    31
#define Line_MANAGE    	32
#define Line_TYPE    	33
#define Line_DATEFR    	34  //MAX.Length<=7
#define Line_DATETO    	35  //MAX.Length<=7
#define Line_TIMEFR    	36
#define Line_TIMETO    	37
#define Line_WEEKDAY    38
#define Line_DISCOUNT   39
#define Line_PACKQTY    40
#define Line_UPRICE     41
#define Line_PPRICE     42
#define Line_PROTOCOL   43
#define Line_TELE     	44
#define Line_PASSWORD   45
#define Line_FREQUENT   46
#define Line_MINIMUM    47
#define Line_PORT     	48
#define Line_VALUE     	49
#define Line_GRAPHIC    50
#define Line_SLIPTYPE   51
#define Line_BLANKLIN   52  //???
#define Line_LINEPAGE   53
#define Line_PRTINFO    54
#define Line_SECOND     55
#define Line_LEFTMAR    56
#define Line_POINT     	57
#define Line_PRILEVEL   58
#define Line_CONFIRM    59
#define Line_FOREGIFT   60
#define Line_POSCODE    61
#define Line_USECASH    62
#define Line_DEADLINE   63

#define Line_Items      64
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

//------message index for TXT.Caption-----------------------------------------------------
#define QUERENF		58
//------message index for TXT.LineCap-----------------------------------------------------
#define JINEF      49
#if (defined(CASE_MALTA))
#define SHYQXIAN 79
#endif

#define ERROR_ID(err) (err-CWXXI01+1)

extern const char cSRAMNOTFOUND[];

#if (defined(CASE_GPRS) || defined(CASE_ETHERNET))
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>added by lqw 09-08-02
#define G_xDATATYPE 0                                            //ccr"�������ʹ�"
#define G_GPRSOK                  (G_xDATATYPE+1)                //ccr"GPRS READY"
#define G_GPRSNOTOK               (G_GPRSOK+1)                   //ccr"GPRS ERROR"
#define G_CONFIRM                 (G_GPRSNOTOK+1)                //ccr"��ȷ��"
#define G_SERVERIP_NULL           (G_CONFIRM+1)                 //ccr"������IP��˿ڲ���:"
#define G_X_IPPORT                (G_SERVERIP_NULL+1)           //ccr"������IP��˿ڲ���:"
#define G_WAITFOR                 (G_X_IPPORT+1)                 //ccr�ȴ�GPRS
#define G_SHUJUFASONGZHONG        (G_WAITFOR+1)                      //"���ݷ�����.."
#define G_SHUJUYIFACHU            (G_SHUJUFASONGZHONG+1)         //"�����ѷ���.."
#define G_FASONGCHENGGONG         (G_SHUJUYIFACHU+1)      //"���ͳɹ�.."
#define G_LIANJIESERVERSHIBAI     (G_FASONGCHENGGONG+1)   //"���ӷ�����ʧ��"
#define G_JIESHOUSHIBAI           (G_LIANJIESERVERSHIBAI+1)      //"����ʧ��"
#define G_FASONGSHIBAI            (G_JIESHOUSHIBAI+1)       //"����ʧ��"
#define G_SERVERIP	              (G_FASONGSHIBAI+1)               //
#define G_SERVERPORT              (G_SERVERIP+1)                 //
#define G_CONNECTING              (G_SERVERPORT+1)          // "���ڽ�������.."
#define G_TOCONNECTING            (G_CONNECTING+1)               // "׼����������.."
#define G_FUWEIMOKUAI             (G_TOCONNECTING+1)            // "���ڸ�λģ��.."
#define G_CHENGGONGTUICHU         (G_FUWEIMOKUAI+1)              // "�������,���˳�.."
#define G_GPRSMessMax             (G_CHENGGONGTUICHU+1)

extern CONST FSTRING GPRSMess[G_GPRSMessMax]; //ADD BY LQW. 090802
#endif

extern const char
    cFATERROR[],
    cWJKJYJIE[],       //"FILE OVERFLOW!"  // "�ļ��ռ�Խ��",
    cPRESSANYKEY[];

#endif
