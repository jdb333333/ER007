#define FIXED_C
#include "king.h"                               /*    Kingtron library and I/O routines     */
#include "exthead.h"
#include "exth.h"
#include "flowbill.h"  //    lyq2003
#include "ejournal.h"
#include "fiscal.h"
/*   *************************************************************    */

/*    Routine for performing fixed function of type 1
    KEYCODE	Function
    CLEAR      Clear ApplVar.Key
    RPF      RPF receipt paper feed
    JPF      JPF journal paper feed
    RON      RON Receipt On/Off key
    MULT      Multiply ApplVar.Key
    SUB      Subtotal
    NEWRECEIPT	Only Issue receipt
    LEVEL1	plu price level 1
    LEVEL2	plu price level 2
    LEVEL3	plu price level 3
    LEVEL4	plu price level 4
    NPRICE	new plu price
    NUMBER	number entry
    ODRAW      drawer open
    */


void CheckMultiply()
{
    switch (ApplVar.MultiplyCount)
    {
    case 0:
        ApplVar.Qty1 = ApplVar.Entry;
        ApplVar.Qty = ApplVar.Qty1;
        break;
    case 1:
        ApplVar.Qty2 = ApplVar.Entry;
        Multiply(&ApplVar.Qty, &ApplVar.Qty2);
        break;
    case 2:
        ApplVar.Qty3 = ApplVar.Entry;
        Multiply(&ApplVar.Qty, &ApplVar.Qty3);
        break;
    default:
        ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
        return;
    }
    if ((ApplVar.Qty.Sign & 0x0f) > 0x03)
        RoundBcd(&ApplVar.Qty, 3);
    ApplVar.MultiplyCount++;
    ClearEntry();
}


void NewReceipt()
{
    if (ApplVar.FReceipt)    /* Receipt Used ? */
    {
        ApplVar.BufKp = 2;  /* set so no feed on issue */
        ApplVar.PrintLayOut = 0x06; /* set double size for table number */
        KpEnd(0);   /* issue internal kp receipt */
        ApplVar.BufKp = 0;
        ApplVar.FReceipt = 0;
        ApplVar.FRecIssue = 1;  /* set receipt issue used */
    }
}

void PrintNumber(BCD *num)
{
    BCD temp;

    CONSTCHAR *str;
    temp = *num;
    temp.Sign &= 0x03;
    str = FormatQtyStr(Prompt.Caption[29], &temp, PRTLEN);
    PrintStr(str);      /* print first part */
//	PrintStr(str+11);	/* print second */
    if (!ApplVar.BufRec)
    {
        ApplVar.RGRec.Qty = *num;
        ApplVar.RGRec.Key.Code = NUMBER;    /* number entry */
        StoreInBuffer();
        ApplVar.RGRec.Key.Code = 0;
    }
}
/*      ��������      */
void Fixed()
{
    WORD saveclerk ;
    BYTE SaveRGNumber,saveCp, SaveSP,sLp;

    char temp[18];

    switch (ApplVar.Key.Code)
    {
    case NEWRECEIPT:
        NewReceipt();  //        �µ��� PenGH
        break;
    case RON:     //

        if (ApplVar.FRegi)   /*       registration       */
        {
            /*      ���������ģʽ�£�����ʾδ������Ϣ      */
            ApplVar.ErrorNumber=ERROR_ID(CWXXI14);
            break;
        }
        else
        {
            /*       ��������RON�����       */
            INVERTBIT(ARROWS, BIT0);    /*       invert RON       */
        }
    case CLEAR: /* clear function */
        ClearEntry();
        if (ProgType && ProgLine)  /*    not programming     */
        {
            PutsO(ProgLineMes);
#if(DD_ZIP==1 || DD_ZIP_21==1)
            Puts1(ProgLine1Mes);
#endif
        }
        else
        {
#if(DD_ZIP==1)
            PutsO(ModeHead);
            if (ApplVar.FTrain)
                Puts1_Right(Msg[TRAINMODE].str);
            else
                Puts1(EntryBuffer + sizeof(EntryBuffer) - DISLEN - 1);

#elif(DD_ZIP_21==1)   /*       PenGH 2008-06-03      */
            PutsO(ModeHead);
            if (ApplVar.FTrain)
                Puts1_Right(Msg[TRAINMODE].str);
            else
                Puts1(EntryBuffer + sizeof(EntryBuffer) - DISLEN - 1);
            if ( (ApplVar.CentralLock==RG)||(ApplVar.CentralLock==MG)  )
            {
                PutsC(EntryBuffer + sizeof(EntryBuffer) - DISLEN - 1+4);
            }
#else
            if (ModeHead[0] && !ApplVar.FRegi)
            {
                PutsO(ModeHead);
                if (ApplVar.FTrain)
                    PutsO_At('T',DISLEN-1);
            }
            else
            {
                PutsO(EntryBuffer + sizeof(EntryBuffer) - DISLEN - 1);
                if (ApplVar.FTrain)
                    PutsO_At('T',0);
            }
#endif

            //ClearLine2();////ccr20131120 ����ڶ���

            ProgType = 0;  //      δѡ����ģʽ //
        }
        if (ApplVar.Key.Code > FIXED ) /*       RON key ?        */
            break;
        if (TESTBIT(KPPRICE, BIT5))     /*       german system then clear modifiers       */
            ApplVar.ModiCount = 0;
        ApplVar.FPrice = 0;
        if (ApplVar.FVoid || ApplVar.FCorr || ApplVar.FRefund)
            ApplVar.RGRec.Key.Code = 0; /*       clear temporary record       */
        ApplVar.FVoid = 0;
        ApplVar.FCorr = 0;
        ApplVar.FRefund = 0;
        ApplVar.FCurr = 0;
        ApplVar.ErrorNumber=0;
        ApplVar.MultiplyCount = 0;
        ApplVar.TaxTemp = 0;
        ApplVar.CentralLock &=( ~SETUPMG);  //     liuj modify 080528

        //ccr20130809(������������ۿ�����)>>>>>>>>>>>
        if (ApplVar.FRegi)
        {
            if (ApplVar.RGRec.Key.Code<DEPT || ApplVar.RGRec.Key.Code>PLU3)
                ApplVar.RepeatCount = 0;
        }
        else// if (!ApplVar.FRegi)     /*       if not used clear inventory flag       */
        {
            ApplVar.RepeatCount = 0;
            ApplVar.FNFolio = 0;
            ApplVar.TaxPerm = 0;
            ApplVar.FCanc = 0;
            ApplVar.FProforma = 0;
            ApplVar.FKpGroup = 0;
        }
        //<<<<<<<<<
        ApplVar.FBalance = 0;   //    cc 2006-06-30 for Balance
#if defined(FISCAL) //     liuj 0528
        if (ApplVar.FuncOnEnter == FUNC800)
        {//����˰�س�ʼ��
            //SetInputMode('9');
            Initial_Fiscal(true);  //������ʾ����˰�س�ʼ����Ϣ
        }
        else
#endif
            ApplVar.FuncOnEnter = 0;
        break;
    case RPF:
        RFeed(1);
        break;
    case JPF:
        JFeed();
        break;
    case TAXST1:        /*       tax shift transaction       */
        if (ApplVar.FRegi)
            ApplVar.ErrorNumber=ERROR_ID(CWXXI14);
        else
            ApplVar.TaxPerm = 0x03;
        break;
    case TAXSA1:        /*       tax shift article       */
        if (ApplVar.FPb)
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
        else
            ApplVar.TaxTemp = 0x03;
        break;
    case MULT:     /*       multiply key       */
        if (!Appl_EntryCounter)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            break;
        }
        if ((ApplVar.CentralLock & 0xf000)!=SETUPMG)//ccr2014-03-10,�������û���Ϣʱ,X����Ч
        {
            CheckMultiply();
            if (ApplVar.CentralLock==MG && ApplVar.FInv==3)
                PutsO(DispAmtStr(0, &ApplVar.Qty,DISLEN));
            else
                PutsO(DispQtyStr("X", &ApplVar.Qty,DISLEN));
        }
        break;
    case SUB:     /*       Subtotal function       */
    case SUB1:  /*       Subtotal with Print       */
        ApplVar.FSubAmt = ApplVar.Amt;        //    cc 2006-02-15>>>>>>>>>>>>>>

#if (DD_FISPRINTER==0)
        if (Appl_EntryCounter)
        {
            if (!ApplVar.FRegi && !ApplVar.FInv && ApplVar.AP.Plu.Number)
            {
                if (ApplVar.CentralLock != MG) //    ���ڹ���ģʽ
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI28);   /*       only manager       */
                    break;
                }
                //     liuj 0806
                if (!ApplVar.NumberEntry || ApplVar.NumberEntry >7)
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI04);  /*      The function not allowed   PenGH      */
                    break;
                }
                //     liuj 0806
#if	(DD_CHIPC==0)  //    =1:SI gestione chip-card     PenGH
                if (ApplVar.NumberEntry &&  ApplVar.NumberEntry <= 3)//    ccr chipcard
                {
                    ClearEntry();
#else
                if (ApplVar.NumberEntry &&  ApplVar.NumberEntry <= 7)//    ccr chipcard
                {
                    ClearEntry();
                    //    ccr chipcard>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#if (CASE_MFRIC==1)
                    if (ApplVar.NumberEntry>=4 && ApplVar.NumberEntry<=7)
                    {
                        ChipCard();
#else
                    if (ApplVar.NumberEntry>=4 && ApplVar.NumberEntry<=7 && (IC.CHIP_Flag>=0 || IC.CHIP_Flag==IC_NEWERR || IC.CHIP_Flag==IC_DATEERR))
                    {
#endif
                        ProgType = ApplVar.NumberEntry-4+MGSETUPIC;
                        /*      if (IC.CHIP_Flag!=1 && ProgType==SETCHARGIC ||
                        IC.CHIP_Flag!=IC_NEWERR && ProgType==SETINITIC ||
                        IC.CHIP_Flag==IC_DATEERR && ProgType!=SETCLEARIC)//    ccr040805      */
                        if ((IC.CHIP_Flag!=1 && IC.CHIP_Flag!=2) && ProgType==SETCHARGIC ||
                            IC.CHIP_Flag!=IC_NEWERR && ProgType==SETINITIC ||
                            IC.CHIP_Flag==IC_DATEERR && ProgType!=SETCLEARIC)//    cc20050817
                        {
                            ApplVar.ErrorNumber=CWXXI50-CWXXI01+1;
                        }
                        else
                        {
                            ApplVar.CentralLock = SETUPMG | MG;
                            ProgStart = 0;
                            ApplVar.ProgNumber = 0;
                            ProgLine = 0;
                            BitNumber = 0;
                            ApplVar.KeyNo = ApplVar.AP.FirmKeys[ID_PRGENTER];
                            ApplVar.ErrorNumber=0;
                            CheckFirmKey();
                        }
                        break;
                    }
#endif
                    //    ccr chipcard<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                    //    ApplVar.PrintLayOut = 0x07;
                    if (ApplVar.NumberEntry == 3)
                    {
                        ApplVar.FInv = 3;
                        PutsO(DMes[0]);
                        if (TESTBIT(PBPRINT,BIT5))    //    lyq20031230
                            PrintMessage(48);
                        break;
                    }
                    else if (ApplVar.AP.Plu.InvSize)
                    {
                        if (TESTBIT(PBPRINT,BIT5))    //    lyq20031230
                            PrintMessage(47);
                        if (ApplVar.NumberEntry == 1)
                        {
                            ApplVar.FInv = 1;
                            PutsO(DMes[1]);
                        }
                        else if (ApplVar.NumberEntry == 2)
                        {
                            ApplVar.FInv = 2;
                            PutsO(DMes[2]);
                        }
                        else
                            ApplVar.ErrorNumber=ERROR_ID(CWXXI04);
                        break;
                    }
                    else        //     liuj 0806
                    {
                        ApplVar.ErrorNumber=ERROR_ID(CWXXI99);
                        break;
                    }
                }
            }
            ApplVar.ErrorNumber=ERROR_ID(CWXXI04);
            break;
        }
        else if (ApplVar.FInv)  /*       inventory adjustment ?       */
        {
#if !defined(FISCAL)
            if (TESTBIT(PBPRINT,BIT5))    //    lyq20031230
#endif
                ReceiptIssue(1);
            ApplVar.FInv = 0;
            ApplVar.FRegi = 0;
            ApplVar.FSale = 0;
            ApplVar.OldClerk = 0;     /*       force clerk print start transaction       */
            ApplVar.OldSalPer = 0;

            RESETBIT(ARROWS, BIT1); /*       reset RG led       */
            PutsO(&EntryBuffer[sizeof(EntryBuffer) - DISLEN - 1]);
            break;
        }
        else
#endif//DD_FISPRINTER
        {
            if (!ApplVar.FRegi && !ApplVar.FTend && (COPYRECEIP & 0x0f) && ApplVar.CopyReceipt<(COPYRECEIP & 0x0f))
            {
                if (ApplVar.RGNumber)
                {
                    saveCp = ApplVar.CopyReceipt+1;
                    saveclerk = ApplVar.ClerkNumber ;
                    SaveSP = SLIP;          //    20040330
                    SLIP = 0;              //    20040330
                    ApplVar.BufRec = 1;
                    SaveRGNumber = ApplVar.RGNumber;
#if DD_MMC == 1
                    ApplVar.EJContent = TXTCONT;        //    20070118
//    						SETBIT(ApplVar.ContFlag, (ENSTORE|ENHEADER));		//    20070118
#endif
                    ProcessBuffer();    /*       second receipt       */
//     liuj 0523

                    ApplVar.RGNumber = SaveRGNumber;
                    ApplVar.ClerkNumber = saveclerk ;
                    ApplVar.CopyReceipt = saveCp;
                    SLIP = SaveSP;                   //    20040330
                    break;
                }
                ApplVar.SubTotal = ZERO;
            }
            if (ApplVar.FRegi && !ApplVar.FTend)   /*       not tendering       */
            {
                if (ApplVar.PbNumber && !ApplVar.FSplit)//ccr091210>>>>>
                {
                    CalculateTax(1);        /*ccr100513 Split       calculate and not add report       */
                    Add(&ApplVar.SubTotal,&ApplVar.PB.Amt);
                    if (CheckNotZero(&ApplVar.PB.Amt))     //ccr100513 Split
                        PrintAmt(Prompt.Caption[1], &ApplVar.PB.Amt); //ccr100513 Split     subtotal
                }
                else//<<<<<<<<<<<<<<<<<<<<<<<
                    CalculateTax(1);        /*       calculate and not add report       */
                ApplVar.FSub = 1;       /*       set subtotal pressed       */
            }
#if(CASE_RAMBILL)
            Collect_Data(SUBTOTALLOG);
#endif
        }
        ApplVar.RepeatCount = 0;
        //��ʾС�ƽ��
#if(DD_ZIP==1)
        PutsO(DText[3]);
        Puts1(DispAmtStr(0, &ApplVar.SubTotal,DISLEN));
#elif(DD_ZIP_21==1)
        PutsO(DText[3]);
        Puts1(DispAmtStr(0, &ApplVar.SubTotal,DISLEN));
        if (SysBuf[sizeof(SysBuf)- DISLENC + 3]==' ')
            CopyFrStr(&SysBuf[sizeof(SysBuf)- DISLENC], CusDText[cusSUB]);
        PutsC(&SysBuf[sizeof(SysBuf)- DISLENC]);
#else
        PutsO(DispAmtStr(DText[3], &ApplVar.SubTotal,DISLEN));
#endif
        ApplVar.FCurr = 0;

        if (ApplVar.Key.Code == SUB && ApplVar.FRegi && !ApplVar.FTend) //ccr101111
        {
            ApplVar.PrintLayOut = 0x0b; /*       print R/J and Slip       */
            if (CheckNotZero(&ApplVar.SaleAmt))     //ccr100513 Split
                PrintAmt(Prompt.Caption[1], &ApplVar.SaleAmt); //     subtotal
        }
        if (ApplVar.FBuffer)    /*       Trans buffer full ?       */
        {
            ApplVar.BufKp = 1;
            ApplVar.BufCC = 1;
            temp[0] = ApplVar.FReceipt;
            ProcessBuffer();
            ApplVar.BufKp = 0;
            ApplVar.BufCC = 0;
            ApplVar.CopyReceipt = ApplVar.RGNumber = 0;    /*       reset trans buffer       */
            ApplVar.FReceipt = temp[0];
            if (ApplVar.AP.SalPer.Number)
            {
                ApplVar.RGRec.Key.Code = SALPER + ApplVar.SalPerNumber;  /*       store in buffer for correct CC update       */
                StoreInBuffer();
            }
            ApplVar.RGRec.Key.Code = CLERK + ApplVar.ClerkNumber;
        }
        break;
    case NPRICE:      /*       new price entry for PLU      */
        if (AmtInputMask())
            return;
        if (Appl_EntryCounter && !ApplVar.DecimalPoint)
        {
            ApplVar.Price = ApplVar.Entry;
            ApplVar.FPrice = 1;
            ClearEntry();
        }
        else
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
        break;
    case NUMBER2:   /*       same as NUMBER1 but when no entry Open Drawer       */
    case NUMBER1:   /*       number entry with direct print       */
    case NUMBER:  /*       number entry       */
        if (Appl_EntryCounter)
        {
            if (Appl_EntryCounter < 17)
            {
                ApplVar.NumberEntered = ApplVar.Entry;
                ApplVar.NumberEntered.Sign |= Appl_EntryCounter * 4;
                if (ApplVar.Key.Code != NUMBER)
                {

                    ApplVar.PrintLayOut = 0x0b; /*       Slip, R, J       */
#if defined(FISCAL)
                    if (!ApplVar.FRegi)
                        ApplVar.FStatus = 1;            /*       set fiscal receipt       */
#endif

                    if (RegiStart())
                        return;
                    StoreInBuffer();
                    PrintNumber(&ApplVar.NumberEntered);
                    ApplVar.FNum = 2;
                }
                else
                {
                    EntryBuffer[sizeof(EntryBuffer)-Appl_EntryCounter-2]='#';
                    PutsO(EntryBuffer+sizeof(EntryBuffer)-Appl_EntryCounter-3);
                    ApplVar.FNum = 1;
                }
                ClearEntry();
            }
            else
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            break;
        }
        else if (ApplVar.Key.Code != NUMBER2)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            break;
        }
    case ODRAW:  /*       drawer open       */
        if (!ApplVar.ClerkNumber)
            ApplVar.ErrorNumber=ERROR_ID(CWXXI33); /*       select clerk       */
        else if (ApplVar.AP.SalPer.Number && !ApplVar.SalPerNumber)
        {
            if (!TESTBIT(KEYTONE, BIT6))
            {
                ApplVar.SalPerNumber = 1;
            }
            else
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI34);     /*       select salesperson       */
                return;
            }
        }
        else
        {
            OpenDrawer();
            if (!ApplVar.FRegi)
            {
                if (TESTBIT(CLERKFIX, BIT0) && !ApplVar.ClerkLock)    /*       clerk compulsory, no key       */
                {
                    ApplVar.ClerkNumber = 0;
                    ApplVar.FTrain = 0;
                }
                if (TESTBIT(KEYTONE, BIT6))    /*       Salesp compulsory       */
                    ApplVar.SalPerNumber = 0;
                else if (TESTBIT(AM_PM, BIT4))    /*       Salesp to 1       */
                {
                    ApplVar.SalPerNumber = 1;
                    ReadSalPer();
                }
            }
        }
#if (CASE_RAMBILL)
        Collect_Data(NOADDLOG);
#endif

        break;
    case KPGROUP :
        PutsO(DMes[3]);
        ApplVar.FKpGroup = 1;
        break;
    case PROFORMA:  /*       proforma invoice only receipt       */
    case PROFORMA1: /*       print on receipt and journal       */
        if (ApplVar.FRegi)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            break;
        }
        strncpy(temp + 1, Prompt.Message[57],sizeof(temp)-2);
        temp[0] = ' ';
        temp[17] = 0;
        if (!Appl_EntryCounter)
        {
            PutsO(temp);
            if (ApplVar.Key.Code == PROFORMA)
                ApplVar.FProforma = 1;
            else
                ApplVar.FProforma = 2;
            break;          /*       set proforma receipt       */
        }
        if (AmtInputMask())
            break;
        ApplVar.PrintLayOut = 0x08;     /*       print receipt or slip       */
        CheckSlip();    /*       slip active ?       */
        if (!ApplVar.SlipLines)
        {
            RFeed(1);
            ApplVar.PrintLayOut = 0x02;
        }
        if (ApplVar.Key.Code == PROFORMA1)
            ApplVar.PrintLayOut |= 0x01;        /*       also journal       */
        else
        {
            ApplVar.FCanc = 1;  /*       skip journal printing       */
            ApplVar.CancPrint = 0xfe;
        }
        MemSet(ApplVar.TaxItem, sizeof(ApplVar.TaxItem), 0);
        ApplVar.SaleAmt = ApplVar.Entry;
        ApplVar.TaxItem[0][0] = ApplVar.Entry;     /*ccr090108       always tax 0       */
        PrintAmt(temp + 1, &ApplVar.SaleAmt);
        ApplVar.FSale = 1;
        RegiEnd();

        ApplVar.FSale = 0;
        ApplVar.TendNumber = 0;
        ReadTender();
        PrintAmt(ApplVar.Tend.Name, &ApplVar.SubTotal);

        if (PVAT)
            CalculateTax(3);    /*       print inclusive tax       */
        ReceiptIssue(1);

        //    PromtionCheck();

        ApplVar.CopyReceipt = ApplVar.RGNumber = 0;    /*       reset trans buffer       */
        ApplVar.FCanc = 0;
        ClearEntry();
        break;
    case NFOLIO:        /*       new Folio key only outside transaction       */
        if (ApplVar.FRegi)
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
        else
        {
            PutsO(" NFOLIO ");
            ApplVar.FNFolio = 1;
        }
        break;
    case ARTLEVEL:
        if (ApplVar.NumberEntry && ApplVar.NumberEntry < 5)
        {
            ApplVar.PluArtLevel = (ApplVar.NumberEntry - 1)*ApplVar.PluKeys;
            memset(SysBuf,' ',DISLEN);
            CopyFrStr(SysBuf,Prompt.TypeCap[SETPLU-1]);
            WORDtoASC(SysBuf+7,ApplVar.PluArtLevel+1);  SysBuf[8] = '-'; WORDtoASC(SysBuf+10,ApplVar.PluArtLevel*2);
            PutsO(SysBuf);
            ClearEntry();
        }
        else
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
        break;
    case ARTLEVEL1:      /*       plu article levels       */
    case ARTLEVEL2:
    case ARTLEVEL3:
    case ARTLEVEL4:
    case ARTLEVEL5:
    case ARTLEVEL6:
    case ARTLEVEL7:
    case ARTLEVEL8:
    case ARTLEVEL9:
        ApplVar.PluArtLevel = (ApplVar.Key.Code - ARTLEVEL1)*ApplVar.PluKeys;
        memset(SysBuf,' ',DISLEN);
        CopyFrStr(SysBuf,Prompt.TypeCap[SETPLU-1]);
        WORDtoASC(SysBuf+7,ApplVar.PluArtLevel+1);  SysBuf[8] = '-'; WORDtoASC(SysBuf+10,ApplVar.PluArtLevel*2);
        PutsO(SysBuf);
        break;
    case LEVEL:
        if (ApplVar.NumberEntry && ApplVar.NumberEntry <= ApplVar.AP.Plu.Level)
        {
            ApplVar.PluPriceLevel = ApplVar.NumberEntry - 1;
            ClearEntry();
#if(CASE_RAMBILL)
            Collect_Data(PRICELISTLOG);
#endif
        }
        else
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
        break;
    case LEVEL1:      /*       plu price levels       */
    case LEVEL2:
    case LEVEL3:
    case LEVEL4:
        SysBuf[0] = ApplVar.Key.Code - LEVEL1;
        if ((BYTE)SysBuf[0] < ApplVar.AP.Plu.Level)
        {
            ApplVar.PluPriceLevel = SysBuf[0];
#if(CASE_RAMBILL)
            Collect_Data(PRICELISTLOG);
#endif
            break;
        }
    case LOOKPLU:
        if (Appl_EntryCounter)
        {
            ApplVar.Entry.Sign =  0;
            StrToBCDValue(ApplVar.Entry.Value, &EntryBuffer[sizeof(EntryBuffer) - 2], BCDLEN);

            if (ApplVar.AP.Plu.RandomSize)//     && Appl_EntryCounter>4)//    ============================
            {
                if (Appl_EntryCounter <= (ApplVar.AP.Plu.RandomSize * 2))
                    ApplVar.PluNumber = GetPluNumber(0, ApplVar.Entry.Value);
                if (!ApplVar.PluNumber)
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI05);
                else
                    ApplVar.PluNumber--;
            }
            else
                ApplVar.PluNumber = ApplVar.NumberEntry-1;
            RESETBIT(ApplVar.MyFlags,LOCKPLU);
        }
        else
            INVERTBIT(ApplVar.MyFlags,LOCKPLU);
        if (!ApplVar.ErrorNumber)
            LookPlu(ApplVar.MyFlags & LOCKPLU);
        ClearEntry();
        break;
//    cc 2006-06-29 for Balance>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    case WEIGHT:
        for (sLp=0;sLp<3;sLp++)
        {
            if (sLp == 2)
                break;
            ApplVar.PortNumber = sLp;
            ReadPort();
            if (ApplVar.Port.Type == '5')
                break;
        }
        if (sLp == 2)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI04);
            return;
        }
        if (ApplVar.FBalance==1 || !BalanceWeight(1))
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI04);
            return;
        }
        break;
//    cc 2006-06-29 for Balance>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#if (defined(FISCAL) && DD_FISPRINTER==0)
    case USERINFO:       /*      �û���Ϣ����  PenGH  2008-06-06      */
        if (ApplVar.CentralLock != MG && ApplVar.CentralLock != RG || ApplVar.FRegi)
        {   // �û���Ϣֻ���ڹ���������ģʽ��ʹ�á�����Լ������վ�,Ҳ��ֹ����
            ApplVar.ErrorNumber=ERROR_ID(CWXXI04);   /*       only in MG and RG      */
            break;
        }
        //ccr2014-PANAMA>>>>
        if (Appl_EntryCounter==0)//Ĭ��Ϊ����˿�����
        {
            ApplVar.NumberEntry = 1;
        }
        if (ApplVar.NumberEntry>cUSERMAX || ApplVar.NumberEntry==0)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            break;
        }
        ApplVar.NumberEntry--;
        ApplVar.UserInfo.InputIDX=ApplVar.NumberEntry;//��Ϣ����
        ClearEntry();  // ������뻺�档��Ϊ�����û���Ϣ����ռ䡣
        ApplVar.CentralLock |= SETUPMG;
        ProgType = SETUSERINFO;
        ProgStart = 0;
        ApplVar.ProgNumber = 0;
        RESETBIT(ApplVar.MyFlags,SETCONFIRM);/*       ccr040809       */
        ProgLine = 0;
        BitNumber = 0;
        ApplVar.KeyNo = ApplVar.AP.FirmKeys[ID_PRGENTER];
        ApplVar.ErrorNumber=0;
        CheckFirmKey();
        //<<<<PANAMA
        break;

#endif


#if (defined(CASE_MALTA))
    case INPUTVATNO:
        if (ApplVar.CentralLock != MG && ApplVar.CentralLock != RG)
        {
            ApplVar.ErrorNumber = 4;   /* only in MG and RG*/
            break;
        }
        ClearEntry();
        memset((char *)&ApplVar.FVatNo,0,sizeof(ApplVar.FVatNo));
        Appl_MaxEntry = sizeof(ApplVar.FVatNo);
        SetInputMode('9');
        PutsO(Msg[RIFCODE].str);//"VAT NO:");

        ApplVar.FuncOnEnter = FUNCVATNO;
        ProgLine = 2;//let the input area on the main screen
        ClearEntry();

        break;
#endif
    case NONKEY:    //    cc 20071102
        break;
    default:
        ApplVar.ErrorNumber=ERROR_ID(CWXXI42);
        break;
    }
}

