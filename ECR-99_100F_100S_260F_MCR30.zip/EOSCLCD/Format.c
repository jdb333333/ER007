#define FORMAT_C
#include "king.h"
#include "exthead.h"


//����˵��:toָ���ַ����洢��,ת����������ɺ���ǰ�洢
//"                 12,345"
//                 <--to_^
//ת�����������С��,��ǰ׺��,���������������Ƿ���зָ�
void FormatAmtFix(char *to,BCD *amt)
{
    WORD format;
    format = BCDLEN * 2 | 0x6800;//��С��,��ǰ׺
    if (TESTBIT(COMMA, BIT0)) /* comma instead of point */
	    format |= 0x1000;   //��,�ָ�
    FormatBCD(to, amt, format);
}
//����˵��:toָ���ַ����洢��,ת����������ɺ���ǰ�洢
//"                 12345.67"
//                <--to_^
void FormatAmt(char *to,BCD *amt)
{
    WORD format;

    format = BCDLEN * 2;
    if (ApplVar.AmtDecimal == 1) /* no decimal in amount ? */
	    format |= 0x0800;
    else if (ApplVar.AmtDecimal == 2)
	    format |= 0x8000;
	else if (ApplVar.AmtDecimal == 3)
		format |= 0x8800;
    if (TESTBIT(COMMA, BIT0)) /* comma instead of point */
	    format |= 0x1000;
    FormatBCD(to, amt, format);
}

//����˵��:toָ���ַ����洢��,ת����������ɺ���ǰ�洢
//"                 12345.67"
//                <--to_^

void FormatQty(char *to ,BCD *qty )
{
    WORD format;

    format = (BCDLEN<<1) + 0x6400;
// liuj 0813
    if (TESTBIT(COMMA, BIT0)) /* comma instead of point */
	    format |= 0x1000;

    FormatBCD(to, qty, format);
}

CONSTCHAR *FormatAmtStr(CONSTCHAR *str ,BCD *amt,short width )
{
	short slen;

    MemSet(SysBuf, sizeof(SysBuf), ' ');
	SysBuf[width] =  0;
    FormatAmt(SysBuf + width - 1, amt);

    if (str && str[0])    /* copy string ? */
	{
		slen = strlen(str);
		if (slen > width)
			slen = width;
		while (SysBuf[slen -1]!=' ' && slen)
			slen--;
		if (slen>0)
			memcpy(SysBuf, str, slen);
	}
	return(SysBuf);
}


CONSTCHAR *FormatQtyStr(CONSTCHAR *str,BCD *qty,short width)
{
	short slen;

    MemSet(SysBuf, sizeof(SysBuf), ' ');
	SysBuf[width] =  0;
    FormatQty(SysBuf + width - 1, qty);


    if (str && str[0])    /* copy string ? */
	{
		slen = strlen(str);
		if (slen > width)
			slen = width;
		while (SysBuf[slen -1]!=' ' && slen)
			slen--;
		if (slen>0)
			memcpy(SysBuf, str, slen);
	}
	return(SysBuf);
}


CONSTCHAR *DispQtyStr(CONSTCHAR *str ,BCD *qty ,BYTE length)
{
    short width=0, slen;

    width = length;//    DISLEN;

    MemSet(SysBuf, sizeof(SysBuf), ' ');
//ccr2014-09-12    if (qty->Sign & 0x03)   /* decimal point ? */
	width++;
    if (str && str[0])    /* copy string ? */
	{
		slen = strlen(str);
		if (slen > width)
			slen = width;
		memcpy(SysBuf + sizeof(SysBuf) - width, str, slen);
	}
    FormatQty(SysBuf + sizeof(SysBuf) - 2, qty);
	SysBuf[sizeof(SysBuf)-1]=0;
	return((CONSTCHAR*)SysBuf + sizeof(SysBuf)- width );//ccr "DISLEN"==>"width"
}


CONSTCHAR *DispAmtStr(CONSTCHAR *str,BCD *amt,BYTE length )
{
    short width, slen;
    WORD format;

    width = length;//      PenGH   2008-08-18 16:37:17  DISLEN;

    if (!ApplVar.AmtDecimal) /* decimal in amount ? */
		width++;
    else if (CompareBCD(amt, &THOUSAND) != -1 || ApplVar.AmtDecimal == 2)
		width++;
    MemSet(SysBuf, sizeof(SysBuf), ' ');
    if (str && str[0])    /* copy string ? */
	{
		slen = strlen(str);
		if (slen > width)
			slen = width;
		memcpy(SysBuf + sizeof(SysBuf) - width, str, slen);
	}
    format = BCDLEN * 2;
    if (ApplVar.AmtDecimal == 1) /* no decimal in amount ? */
		format |= 0x0800;
    else if (ApplVar.AmtDecimal == 2)
		format |= 0x8000;
    else if (ApplVar.AmtDecimal == 3)
		format |= 0x8800;
    if (TESTBIT(COMMA, BIT0)) /* comma instead of point */
		format |= 0x1000;
    format |= 0x6000;       /* no prefix and not extended */
    FormatBCD(SysBuf+sizeof(SysBuf) - 2, amt, format);
    SysBuf[sizeof(SysBuf) - 1]=0;

#if (0)//ccr090121 ���ô˶γ���ʱ,�����ֹ���ϵ�if (str && str[0])    /* copy string ? */
    if (str && str[0])    /* copy string ? */
		for (slen=0,format=sizeof(SysBuf)- width;slen<width && str[slen] && SysBuf[format+1]==' ';slen++)
		{
			SysBuf[format] = str[slen];
		}
#endif

  	return(SysBuf + sizeof(SysBuf)- width);//    ccr "DISLEN"==>"width"
}


CONSTCHAR *FormatStrQtyPriAmt(CONSTCHAR *str,BCD *qty,BCD *pri,BCD *amt,short width)
{
	short slen,i;

    MemSet(SysBuf, sizeof(SysBuf), ' ');
	SysBuf[width] =  0;
    FormatAmt(SysBuf +width - 1, amt);
    i = 13;
    if (pri)
	    FormatAmt(SysBuf + 22+(PRTLEN>32)*2 , pri);
#if (PRTLEN>24)
	else
		i = 19;
#endif

	if(qty)
        FormatQty(SysBuf + i +(PRTLEN>32)*2, qty);

    if (str && str[0])    /* copy string ? */
	{
		slen = strlen(str);
		if (slen > width)
			slen = width;
		for (i=0;i<slen;i++)
		{
			if (SysBuf[i+1]!=' ') //ʹ��i+1ȷ����������֮����һ���ո�
				break;
		}
		slen = i;
		memcpy(SysBuf, str, slen);
	}
	return(SysBuf);
}


