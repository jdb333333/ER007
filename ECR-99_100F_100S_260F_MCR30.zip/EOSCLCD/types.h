//
//
// File : TYPES.H
//     -------
//
// Cont : Definizione di tipi di dati comuni a TUTTI I  moduli
//     ----------------------------------------------------
//
// In questo file vengono definiti alcuni tipi di dati ausiliari.
// Questo file deve essere incluso all'inizio di tutti i sorgenti
//

#ifndef TYPES_H
#define TYPES_H

#define BCDLEN	8
#define SIGN	1

//==========================================================================
//Definizione di alcuni tipi di dati ausiliari
//==========================================================================
#if defined(DEBUGBYPC)
#pragma option -a1

typedef  unsigned __int64 UINT64;
typedef unsigned long ULONG;

#else

#pragma pack(1)

#define UINT64 uint64_t

#endif

typedef  unsigned char BYTE;
typedef unsigned long UnLong;

typedef  unsigned short WORD;

typedef char STRZ;			//stringhe ascii-z
typedef char STR;			//stringhe ascii

typedef struct {
	CONSTCHAR * str;
} FSTRING;

typedef struct
{
    BYTE    Sign;
    BYTE    Value[BCDLEN];
} BCD;

struct word {
    BYTE    Low;
    BYTE    High;
};

union KEY {
    WORD    Code;
    struct word C;
};
//��BCD���ʹ洢����������
struct	TimeDate {
	WORD year;	/* current year 0x2018 */
	BYTE month;	/* month (1 = Jan) 0x01 */
	BYTE day;	/* day of month 0x18 */
	BYTE dow;	/* day of week (0 = Monday) 0x00~0x06 */
	BYTE hour;	/* hours 0x23 */
	BYTE min;	/* minutes 0x59 */
	BYTE sec;	/* seconds 0x59 */
	};

struct CCONFIG {	/* default value between brackets */
	BYTE	Country;	/* (0) country code for printer */
	BYTE	Display;	/* (2) 0 -- 3 */
				/* 0 = not present or not enabled */
				/* 1 = alphanumeric 20 char 1 line */
				/* 2 = numeric 9 digit + 6 arrows */
				/* 3 = not used */
	BYTE	Lock;		/* (2) 0 -- 3 */
				/* 0 = not present */
				/* 1 = badge (not implemented) */
				/* 2 = Central lock */
				/* 3 = Central & Clerk Lock */
	BYTE	JDensity;	/* (128) 0 - 255, density on journal printer */
	BYTE	RDensity;	/* (128) 0 - 255, density on receipt printer */
	BYTE	KeyBoard;	/* (2) 0 -- 3  not used by controller,
			    used by XTGEN */
				/* 0 =	*/
				/* 1 = Super Micro */
				/* 2 = MA  - 60 keys */
				/* 3 =	*/
	BYTE	ClearKey;	/* (0) keynumber for the clear key */
	BYTE	Click;		/* (-1) key click, 0 is disabled */
	BYTE	KeyMask[12];	/* (0) disable keynumber on keyboard 12 */
	};


//Tipo per bytes da vedere a bit-flags
//------------------------------------
//
typedef struct{
		char	b0:1;
		char	b1:1;
		char	b2:1;
		char	b3:1;
		char	b4:1;
		char	b5:1;
		char	b6:1;
		char	b7:1;
} BIT_8;



// Tipo ausiliario per vedere un BYTE sia come BYTE che come bit-flags
//
typedef union {
	BIT_8	bit;
	BYTE	byte;
} BYTEBIT;



//tipo per gestione date (BCD, 4 bytes) :
typedef struct{
	 	BYTE dd;	//giorno
	 	BYTE mm;	//mese
	 	BYTE yy;	//anno
	 	BYTE w;		//giorno della settimana
} DATE_BCD;


//tipo per gestione date (BCD, 4 bytes) :
typedef struct{
	 	BYTE hh;	//ora
	 	BYTE mm;	//minuti
	 	BYTE ss;	//secondi
	 	BYTE w;   	//dummy : used to have even align
} TIME_BCD;

//-----------------------




//Tipo per struttura di controllo I/O su/da porte
//
typedef struct {

	short		BytesRead;		//numero di bytes letti
	short		BytesToRead;	//numero di bytes da leggere
	WORD	TimeOutR;		//time-out per lettura
	short		BytesWritten;	//bytes scritti
	short		BytesToWrite;	//numero di bytes da scrivere
	WORD	TimeOutW;		//time-out per scrittura
	WORD	Status;			//bit-flags stato


} PORTCTRL_TYP;



//---------------------------------------------------------------------------
struct LOGCOND {
	char idx;
	ULONG RecNumFr;
	ULONG RecNumTo;
	ULONG DateFr;
	ULONG DateTo;
	BYTE  Type;
};


struct FifoHeader 						//header
{
	ULONG HeadP;
	ULONG ReadP;				//scanf pointer
	ULONG NextNP;
	ULONG FromAddr;
	ULONG EndAddr;
	ULONG MAXNUMB;
	BYTE  	OverCount;
//cc 2006-07-07 for MMC>>>>>>>
#ifdef CASE_FATFS_EJ
	WORD DateTime;
	ULONG RecordCount;
#endif
//    cc 2006-07-07 for MMC>>>>>>>

};


//ccr091127>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
// PBFLAGS ������ʾ��̨��״̬ //
//-------------------------------------------------------------------
//
typedef struct{
		char	FirstOpen:		1;	// =1,Ϊ��һ�δ�,=0,Ϊ������//
		char	PBOpend:	1;		// =1,�й������̨;=0,�޹������̨ //
		char 	Confirm:	1;		// =1,ȷ�Ͻ��� //
		char	Print:		1;		// =1,��̨���۱�������ӡ //
} PBFLAGS;

typedef union {
	PBFLAGS	bit;
	BYTE	byte;
} PBOPENFLAG;
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
// =============================================================================
// Definizione di Macro
// =============================================================================

//CBYTE : per vedere un BIT8 come un BYTE
#define CBYTE(a) (*(BYTE*)&a)

//CBIT8 : per vedere un BYTE come un BIT8
#define CBIT8(a) (*(BIT_8*)&a)

#define CWORD(a) (*(WORD*)&a)
#define CWORDF(a) (*(WORDFAR *)&(a))
#define CLONG(a) (*(ULONG*)&a)

// CVI :
#define CVI(a)  ( ( (unsigned short)*(a) & 255 ) + ( (unsigned short)(*(a+1)<<8) & 0xFF00 ) )


// COFFSET : torna l'offset di un membro "m" di una struttura "s"
#define COFFSET(s,m) ((WORD)((ULONG)&(s.m) - (ULONG)&(s)))


// Macro MAKEEVEN : rende pari un numero sommando 1 se il numero e' dispari
#define MAKEEVEN(n) (2*((n/2)+(n%2)))

// --------------------------------------------------------------------------------

typedef enum {
		Graph_GM=1,
		Graph_000,
		Graph_001,
		Graph_002,
		Graph_003,
		Graph_004,
		Graph_005,
		Graph_006,
		Graph_007,
		Graph_008,
		Graph_009,
		Graph_010,
		Graph_011,
		Graph_012,
		Graph_013,
		Graph_014,
		Graph_015,
   		Graph_016,
		Graph_017,
		Graph_018,
		Graph_019,
		Graph_020,
		Graph_021,
} GraphIndex;



struct DISPLAY_RGBUF
{/* ���������Ŀ���ݿ��� */
    short FirstRGNum; /* ��ǰ��ʾ��������Ŀ��һ����Ŀ */
    short LastRGNum; /* ��ǰ��Ļ����ʾ��������Ŀ�����һ����Ŀ */
    WORD  RGCount;  /* ��������ʾ��������Ŀ���� */
};


typedef struct  {
	int		IndexS;//���뿪ʼ���
	int		IndexE;//���뿪ʼ���
	char	*KeyType;//������������
	WORD	SetupIDX;//�������,��������ListItem;=0ʱ,��ʹ��ListItem
}TKEYDES;

//ccr2016-11-01>>>>>>>>>>
typedef struct {//Ϊ���ڱȽϴ���,��Ҫ�ı�����˳��
    BYTE second;	/* seconds BCD*/
    BYTE minute;	/* minutes BCD*/
    BYTE hour;	/* hours BCD*/
    BYTE day;	/* day of month BCD*/
    BYTE month;	/* month (1 = Jan) BCD*/
	BYTE year;	/* current year BCD*/
}TDATETIME;

#endif
