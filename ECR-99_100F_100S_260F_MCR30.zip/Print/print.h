/****************************************Copyright (c)**************************************************
*        EUTRON Human Information Equipment Co.,Ltd.
*                    www.eutron.com.cn
* File name:		Print.H
* Descriptions:     DEFINITIONS FOR PRINTE
*------------------------------------------------------------------------------------------------------
*  Created by:			chen churong
* Created date:        2011-10-01
* Version: 1.0
********************************************************************************************************/

#ifndef __PRINT_H
#define __PRINT_H


#if (!defined(DEBUGBYPC))
#include "monitor.h"
#endif

#define sDEBUG(msg) UART_PutString(msg)
#define cDEBUG(c)   UART_PutChar(c)

/////////////////////////////////////////////////////////////////////////////////////
#define DEBUGONPC   0   //debug on pc if set to 1

#define DCPOWER     1   //1-Use DC Adapter��0-Use battery����ʱ���ȴ�����GROUPMODE�޹�

#define WORDorBYTE  0   //����WORD(1)������BYTE(0)���ӡ����������
#define GROUPMODE   2   //=0:��������һ�η���,��GROUPS�涨�������������
                        //=1:ÿ�η���һ����������������,��������ÿ����һ�η���һ�Σ���GROUPS�޹�
                        //=2:�������ݷ�����ϳ�һ��������������������,��������һ�η��ͣ���GROUPS�޹�
// SPI_DEV_Init
//#define HZTIMES     (12.78*uSECOND)  // SPI��ȡ3�ֽں��ֵ�������Ҫ��ʱ��(΢��)
#define HZTIMES     (10.1*uSECOND)     //SPI_CLOCKRATE_HIGH:25M SSP0��ȡ3�ֽں��ֵ�������Ҫ��ʱ��(΢��)
//#define HZTIMES      (9.2*uSECOND)  //SPI_CLOCKRATE_33M SSP0��ȡ3�ֽں��ֵ�������Ҫ��ʱ��(΢��)

#define ASCTIMES     (uSECOND)  //����һ��ASCII��������Ҫ��ʱ��(΢��)
#define PDATATIME    (62*uSECOND) //��һ�д�ӡ��������Ҫ��ʱ��(΢��)

#define PORTHOST    1//ouhs  0 // port used for link to host
/////////////////////////////////////////////////////////////////////////////////////

#ifndef BARIMGHIGH
#define BARIMGHIGH   50     //����ͼƬ�ĸ߶�
                           //ϣ����Ҫ��ӡ27���ַ����վݽ��˽�������:"EUT17000001000007400005632"
#if defined(CASE_GREECE)
#define BARCODESIZE  ((BARIMGHIGH+1)*27) //ccr2017-08-09 ʵ����Ҫ���ֽ���Ϊ1350�ֽ�
#else
#define BARCODESIZE 0  //ccr2017-08-09 ʵ����Ҫ���ֽ���Ϊ2160�ֽ�
#endif
#endif

/////////////////////////////////////////////////////////////////////////////////////
#define SELFGRASIZE 5120 //ccr2017-08-09 8192   //max size of self graphic

#if BARCODESIZE
#define GRAPHICMAX  25     //MAXIUM number of graphics can be used for
#define BARCODE_GRP_ID  25
#else
#define GRAPHICMAX  24     //MAXIUM number of graphics can be used for
#endif

///////////// type definitions of printer ////////////////////////////
//#define CASE_LTP1245    0
//#define CASE_CAPD247    0   //Seiko Instruments Inc.(SII)
//#define CASE_CAPD347    0   //Seiko Instruments Inc.(SII)
//#define CASE_LTPZ245   0   //Seiko Instruments Inc.(SII)
//#define CASE_CAPD245   0   //Seiko Instruments Inc.(SII)

#if CASE_ER380
#define CASE_PT486F    0   //Same as FTP628?
#define	CASE_FTP628MCL401	1
#define	CASE_PT723F_RJ	0

#elif defined(CASE_RJ)  //ΪƱ��R�ʹ��J˫վ��ӡ

#define CASE_PT486F    0   //Same as FTP628?
#define	CASE_FTP628MCL401	0
#define	CASE_PT723F_RJ	1   //RJ˫վ��ӡ

#else

#define CASE_PT486F    1   //Same as FTP628?
#define	CASE_FTP628MCL401	0
#define	CASE_PT723F_RJ	0   //RJ˫վ��ӡ

#endif

#define ENCUTTER    CASE_FTP628MCL401   //The autocutter machanism is ok

///////////////////////////////////////////////////////////////////////

#if defined(DEBUGBYPC)

#include "TypeDef.h"
#define uSECOND 1

#define CONST

#else

#include "include.h"

#define CONST const
#endif

#define CASE_HANDUP	0	//hand flag,0ʱ��ѹ�˼��

/////////////////////////// task definitions /////////////////////////////////////
#define TASK00_Stop				0
#define TASK01_Start			1
#define TASK02_PrintChar		2
#define TASK03_PrintGraphic     3
#define TASK04_FeedPaper        4
#define TASK05_FeedHalf         5
#define TASK10_StopCutter       10
#define TASK11_ResetCutter      11
#define TASK12_FeedCutter       12
#define TASK13_FeedStepCA       13
#define TASK14_FeedStepE        14
#define TASK15_FeedStepAlpha    15
#define TASK16_CutPaper         16
#define TASK17_FeedStepB        17
#define TASK18_FeedStepC        18
#define TASK19_RevFeed8Line     19


/////////// bit Command of print:ApplVar.Prn_Command ///////////////////////////////////////
#define PRN_STUB_Mode        BIT0    //print on stub printer
#define PRN_RECEIPT_Mode     BIT1    //print on receipt printer
#define PRN_DBLH_Mode        BIT2    //double high print mode for text
#define PRN_DBLW_Mode        BIT3    //double with print mode for text
#define PRN_GRAPHIC_Mode     BIT4    //print a graphic
#define PRN_CUTF_Mode        BIT5    //Cut paper full
//#define PRN_CUTH_Mode        BIT6    //Cut paper half
#define PRN_RECEIPT_LINE     BIT6       //ccr2018-01-31 ��ӡ�վ���
#define PRN_BOLD_MODE        BIT7    //ccr2018-07-30 ��ӡ������

#define PRN_CUTRESET_Mode    BIT8    //reset cutter//ccr2018-07-30 N/A

//* command list for print*/
#define PRNCMD_rTEXT        1   //print text on receipt
#define PRNCMD_sTEXT        2   //print text on stub
#define PRNCMD_rsTEXT       3   //print text on Receipt & stub

#define PRNCMD_rTEXT_DW     4   //print text on receipt double with mode
#define PRNCMD_sTEXT_DW     5   //print text on stub double with mode
#define PRNCMD_rsTEXT_DW    6   //print text on Receipt & stub double with mode

#define PRNCMD_rTEXT_DH     7   //print text on receipt double high mode
#define PRNCMD_sTEXT_DH     8   //print text on stub double high mode
#define PRNCMD_rsTEXT_DH    9   //print text on Receipt & stub double high mode

#define PRNCMD_rTEXT_DWH    10   //print text on receipt double high & double width mode
#define PRNCMD_sTEXT_DWH    11   //print text on stub double high & double width mode
#define PRNCMD_rsTEXT_DWH   12   //print text on Receipt & stub double high & double width mode

#define PRNCMD_rGRA         14   //Print Graphic on receipt
#define PRNCMD_sGRA         15   //Print Graphic on stub
#define PRNCMD_RSGRA        16   //Print Graphic on receipt & stub

#define PRNCMD_rCUT         17   //cut receipt paper
#define PRNCMD_sCUT         18   //cut stub paper
#define PRNCMD_rsCUT        19   //cut receipt & stub paper

#define PRNCMD_rCUTRESET    20   //reset receipt cutter
#define PRNCMD_sCUTRESET    21   //reset stub cutter

#define PRNCMD_MAX          22  //

//////////// Status for printer /////////////////////////////////////
#define ENDOFPAPER      1   //��ֽno paper
#define TOOHOT          2   //̫��
#define HANDUP          4   //ѹ��̧��

///////////////////////////////////////////////////////////////////


#define PB_ONLYMOVEMOTOR 0
#define PB_ACTCMD 1
#define PB_DATA   2

#define PRINT_MAJOR 202
#define PRINT_MINOR 0

#define ErrNOMEM      1
#define ErrFAULT      2
/* definitions for printer*/

#if (!CASE_FTP628MCL401)
//////////// Phase definitions for printer(GPIOF) ///////////////////////////
#ifdef CASE_ER50	//by ouhs

#define RPH1     GPIO_Pin_11       //PA   pf.7
#define RPH2     GPIO_Pin_10       //PB   pf.9
#define RPH3     GPIO_Pin_9       //PA-  pf.6
#define RPH4     GPIO_Pin_8       //PB-  pf.8

#elif CASE_PT723F_RJ //Ϊ˫վ��ӡ

#define RPH2     0x80 	// paper motor
#define RPH1     0x40
#define RPH4     0x20
#define RPH3     0x10

#elif defined(CASE_ECR100F) || defined(CASE_ECR100S)

#define RPH1     GPIO_Pin_9 	// paper motor
#define RPH2     GPIO_Pin_8
#define RPH3     GPIO_Pin_7
#define RPH4     GPIO_Pin_6
#define BEATS_PER_CYCLE 8 		//�����������Ϊ8��

#elif	defined(CASE_ECR99) || defined(CASE_MCR30)

#define RPH1     GPIO_Pin_6
#define RPH2     0				//RPH1��RPH2����Ӳ����·��ʵ�ַ���
#define RPH3     GPIO_Pin_7
#define RPH4     0 				//RPH3��RPH4����Ӳ����·��ʵ�ַ���
#define BEATS_PER_CYCLE 4 		//�����������Ϊ4��

#endif



#else
//////////// Phase definitions for printer FSMC bus ///////////////////////////

#define RPH1     0x10//0x80 	// paper motor
#define RPH2     0x20//0x40
#define RPH3     0x40//0x20
#define RPH4     0x80//0x10

#endif

#define RPHMASK  (RPH1 | RPH2 | RPH3 | RPH4)

#if CASE_CAPD245 //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#define GROUPS          6             //groups for hot �����������
#define STEPS1LINE      4             //steps for feed 1 line
#define PHASEMAX        8

#define VMAXSPEED       72
#define PRNWIDTH        32              //characters can print out of 1 line

#define PHSTART        (RPH1)      		        // L L H H

#define TIMESTART       (5000*uSECOND)      //us
#define TIMESTOP        (2000l*uSECOND)      //us

extern CONST ULONG TABSTROBE24V[32][15];
#elif CASE_PT486F //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


#define GROUPS          6             //groups for hot ����������� //δʹ�� HJ
#if (BEATS_PER_CYCLE==8)
#define STEPS1LINE      4   //ÿ�м���4��,�����Ҹ�2��
#define PHASEMAX        8	//��������Ϊ8��
#define VMAXSPEED       60	//����ӡ�ٶ�80mm/s
#else
#define STEPS1LINE      2   //ÿ�м�������,�����Ҹ�һ��
#define PHASEMAX        4	//��������Ϊ4��
#define VMAXSPEED       8	//����ӡ�ٶ�70mm/s

#endif
#define PRNWIDTH        32              //��ӡ����

#define HEATWIDTH		32              //��ӡ��һ�м������ַ���

#define PHSTART        (RPH2 | RPH4)      		        // HJ

#define TIMESTART       (2000*uSECOND)      //us
#define TIMESTOP        (2000l*uSECOND)      //us
#if (BEATS_PER_CYCLE==8)
extern CONST ULONG TABSTROBE24V[32][15]; //HJ
#else
extern CONST ULONG TABSTROBE24V[32][6];
#endif
extern CONST ULONG TABSTROBE24VB[32];

#elif CASE_PT723F_RJ  //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#define GROUPS          6             //groups for hot �����������
#define STEPS1LINE      4             //HJ steps for feed 1 line

#define PHASEMAX        8	//HJ

#define VMAXSPEED       50	//HJ
#define PRNWIDTH        20              //��ӡ����

#define HEATWIDTH		48     //��ӡ��һ�м������ַ���(R+J)

#define PHSTART        (RPH2 | RPH4)      		        // HJ

#define TIMESTART       (2000*uSECOND)      //us
#define TIMESTOP        (2000l*uSECOND)      //us

extern CONST ULONG TABSTROBE24V[32][15]; //HJ
extern CONST ULONG TABSTROBE24VB[32];


#elif	CASE_FTP628MCL401   //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#define GROUPS          6             //groups for hot �����������
#define STEPS1LINE      4             //steps for feed 1 line
#define PHASEMAX        8

#define VMAXSPEED       26				//HJ ��ӡ���ٲ���
#define PRNWIDTH        32              //��ӡ����

#define HEATWIDTH		32      //��ӡ��һ�м������ַ���

#define PHSTART        	RPH1

#define TIMESTART       (5000*uSECOND)      //HJ 5000us
#define TIMESTOP        (2000l*uSECOND)      //us

extern CONST ULONG TABSTROBE24V[32][15];  	//HJ ����CAPD245�ļ��ȱ�

#define HUPR	 0x02    // handup
#define BM     	 0x04
#define PEJ	     0x08
#define HUPJ     0x10
#define PER      0x20 	 //detect paper


#elif CASE_LTPZ245 //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#define GROUPS          6             //groups for hot �����������
#define STEPS1LINE      2             //steps for feed 1 line
#define PHASEMAX        4

#define VMAXSPEED       17	//CASE_LTPZ245
#define PRNWIDTH        32              //characters can print out of 1 line

#define PHSTART        (RPH2 | RPH3)      		        // L L H H

#define TIMESTART       (2000*uSECOND)      //us
#define TIMESTOP        (2000l*uSECOND)      //us

extern CONST ULONG TABSTROBE24V[32][6];

#endif //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#if (!CASE_FTP628MCL401)

#define Drive_On(PH)  	{GPIOF->BSRRH = PH ^ RPHMASK;GPIOF->BSRRL = PH;}//{*(WORD *)PRT_PH_ADDR = PH; GPIOB->BSRRH = PHOEBIT; }
#define Drive_Off()    {GPIOF->BSRRH = RPHMASK;}//{*(WORD *)PRT_PH_ADDR = 0; GPIOB->BSRRL = PHOEBIT;}

#else

#define RMCL     GPIO_Pin_7      //PB.7

#define Drive_On(PH)   	{*(uint8_t *)PRT_PH_ADDR = PH; GPIOB->BSRRL = RMCL; GPIOB->BSRRH = PHOEBIT; }	//{GPIOF->BSRRH = PH ^ RPHMASK;GPIOF->BSRRL = PH;}
#define Drive_Off()    	{/**(uint8_t *)PRT_PH_ADDR = 0x0;*/ GPIOB->BSRRH = RMCL; /*GPIOB->BSRRL = PHOEBIT;*/} //{GPIOF->BSRRH = RPHMASK;}

#endif

//#define TESTCUTS()    (LPC_GPIO0->FIOPIN & CUTS)
//////////// Hot definitions for printer(GPIO2) ///////////////////////////
#define HOT1_PIN     BIT1//GPIO_Pin_9 //BIT0       //hot for group 1,FSMC_D0
#define HOT2_PIN     HOT1_PIN		  //BIT1       //hot for group 2,FSMC_D1
#define HOT3_PIN     HOT1_PIN         //BIT2       //hot for group 3,FSMC_D2
#define HOT4_PIN     BIT0//GPIO_Pin_8 //BIT3       //hot for group 4,FSMC_D3
#define HOT5_PIN     HOT4_PIN         //BIT4       //hot for group 5,FSMC_D4
#define HOT6_PIN     HOT4_PIN         //BIT5       //hot for group 6,FSMC_D5


#define HOTMASK0  (HOT1_PIN | HOT4_PIN | HOT5_PIN | HOT2_PIN | HOT3_PIN | HOT6_PIN)

#define Hot_On0(bit)  {GPIOB->BSRRH = bit ^ (HOTBIT123 | HOTBIT456);GPIOB->BSRRL = bit;} //*(WORD *)PRT_DST_ADDR=bit

#define PrnHotON() { }     //�򿪼���
#define PrnHotOFF() {GPIOB->BSRRH = HOTBIT123 | HOTBIT456;}    //�رռ���

#define Latch_Data()  {GPIOB->BSRRH = LATCHBIT;__NOP();__NOP();__NOP();GPIOB->BSRRL = LATCHBIT;}


#define START_HOT_TIMER()   {StartTimer(TIM3); PrnHotON();}  //�𶯼��ȼ�ʱ��
#define Set_HotTime(t)      {TIM3->ARR = t;START_HOT_TIMER();}
#if (!CASE_FTP628MCL401) //HJ

#if (CASE_PT486F) //HJ

#define PrnPowerON() {GPIOD->BSRRL = POWERBIT;} //�򿪵�Դ
#define PrnPowerOFF() {GPIOD->BSRRH = POWERBIT;}    //�رյ�Դ
//#define PrnPowerOFF() {GPIOC->BSRRL = POWERBIT;}    //�رյ�Դ

#elif (CASE_PT723F_RJ) //HJ

#define POWER_J_BIT    (GPIO_Pin_11)      // PC.2 ��ӡ����Դ����λ//
#define PAPER_J_BIT    (GPIO_Pin_8)       //paper end flag PG.6//

#define PrnPowerON() {GPIOC->BSRRL = POWERBIT; GPIOG->BSRRL = POWER_J_BIT;} //�򿪵�Դ
#define PrnPowerOFF() {GPIOC->BSRRH = POWERBIT; GPIOG->BSRRH = POWER_J_BIT;}    //�رյ�Դ
#endif

#define PRN_DS1         BIT1//GPIO_Pin_9 //BIT0
#define PRN_DS2         PRN_DS1    		 //BIT1
#define PRN_DS3         PRN_DS1          //BIT2
#define PRN_DS4         BIT0//GPIO_Pin_8 //BIT3
#define PRN_DS5         PRN_DS4          //BIT4
#define PRN_DS6         PRN_DS4          //BIT5

#if defined(CASE_ECR100F) || defined(CASE_ECR100S)
#define PAPERBIT    GPIO_Pin_6       //paper end flag PD.6
#define PAPER_PORT	GPIOD
#elif defined(CASE_ECR99) || defined(CASE_MCR30)
#define PAPERBIT    GPIO_Pin_8       //paper end flag PG.8
#define PAPER_PORT	GPIOG
#endif

#define LATCHBIT    GPIO_Pin_4      // PB.4 ��������λ
#define POWERBIT    GPIO_Pin_3      // PD.3 ��ӡ����Դ����λ
//#define HOTBIT    GPIO_Pin_0      // PB.0 ��ӡ�����ȿ���λ
//#define PHOEBIT   GPIO_Pin_1      // PB.1 ��ֽ���е��������λ
#define HOTBIT123	GPIO_Pin_9 	    //PB.09
#define HOTBIT456	GPIO_Pin_8 	    //PB.08
//--------------------------------------------------------------------------//

#else


#define PrnPowerON() {GPIOB->BSRRL = POWERBIT;} //�򿪵�Դ
#define PrnPowerOFF() {GPIOB->BSRRH = POWERBIT;}    //�رյ�Դ

#define PRN_DS1         0x01
#define PRN_DS2         0x02
#define PRN_DS3         0x04
#define PRN_DS4         0x08
#define PRN_DS5         0x10
#define PRN_DS6         0x20

#define	LATCHBIT	GPIO_Pin_4		// PB.4
#define POWERBIT    GPIO_Pin_6      // PB.6 ��ӡ����Դ����λ

#define HOTBIT      GPIO_Pin_0      // PB.0 ��ӡ�����ȿ���λ
#define PHOEBIT    	GPIO_Pin_1      // PB.1 ��ֽ���е��������λ

#endif

#define FEEDMAX         0x10000000L     //����������������Ĳ���


#if (0)//#elif CASE_CAPD247 //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#define STEPS1LINE    2             //steps for feed 1 line
#define PHASEMAX      4

#define CUTMAXSPEED (72+1)
#define VMAXSPEED   120
#define PRNWIDTH    36              //characters can print out of 1 line

#define PHSTART     ( RPH1 | PH2 )

#define CPHSTART     ( CPH1 | CPH4)   //cutter start
#define CPHSTOP      0                      //cutter stop

#define TIMESTART   (5000l*uSECOND)      //us
#define TIMESTOP    (2000l*uSECOND)      //us

#define FEEDMAX     0x10000000L     //����������������Ĳ���

//#elif CASE_CAPD347 //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#define GROUPS        0             //groups for hot
#define STEPS1LINE    2             //steps for feed 1 line
#define PHASEMAX      4             //phase for printe motor
#define CPHASEMAX     8             //phase for cutter motor

#define CUTMAXSPEED 73
#define VMAXSPEED   120
#define PRNWIDTH    48              //characters can print out of 1 line

#define PHSTART     (RMCL | RPH1 | RPH2)

#define CPHSTART     (CMCL | CPH1 | CPH2)   //cutter start
#define CPHSTOP      (CPH3 | CPH4)         //cutter stop

#define TIMESTART   (5000l*uSECOND)      //us
#define TIMESTOP    (2000l*uSECOND)      //us

#define FEEDMAX     0x10000000L     //����������������Ĳ���

extern CONST ULONG TABSTROBE24V[32][13];

//////////// Phase definitions for Cutter(GPIO1) ///////////////////////////
#define CPH1     BIT25       //Phase 1
#define CPH2     BIT26       //Phase 2
#define CPH3     BIT30       //Phase 3
#define CPH4     BIT31       //Phase 4
//......
#define CMCL     BIT25      //Drive on p3.25

#define CUTS     BIT20        //flag for cuts (GPIO0)

#define CPHMASK  (CMCL | CPH1 | CPH2 | CPH3 | CPH4)

#define CutDrive_On(PH)  {LPC_GPIO1->FIOCLR = PH ^ CPHMASK;LPC_GPIO1->FIOSET = PH;}

#define CutDrive_Off()    LPC_GPIO1->FIOCLR = RMCL

#define FULLCUTSTEPS    620
#define HALFCUTSTEPS    544

#define CUTSTEPA        (230)//*STEPS1LINE)
#define CUTSTEPB_F      (620)//*STEPS1LINE)    //step B for full cute
#define CUTSTEPB_H      (544)//*STEPS1LINE)     //step B for halif cut
#define CUTSTEPC_F      (820)//*STEPS1LINE)     //step C for full cut
#define CUTSTEPC_H      (744)//*STEPS1LINE)     //step C for half cut
#define CUTSTEPD_F      (420)//*STEPS1LINE)     //step D for full cut
#define CUTSTEPD_H      (344)//*STEPS1LINE)     //step D for ahlf cut
#define CUTSTEPE        (30 )//*STEPS1LINE)
#define CUTSTEPALPHA    (200)//*STEPS1LINE)
#endif

#if	ENCUTTER
#if	CASE_FTP628MCL401 //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


#define CPH1     0x01 	// cutter motor
#define CPH2     0x02
#define CPH3     0x04
#define CPH4     0x08


#define CMCL     GPIO_Pin_8		 //PB.8

#define CUTS     0x01  	 // cutter
#define CPHMASK  (CPH1 | CPH2 | CPH3 | CPH4)

#define CutDrive_On(PH) {*(uint8_t *)PRT_PH_ADDR = PH; GPIOB->BSRRL = CMCL; GPIOB->BSRRH = PHOEBIT; } //{LPC_GPIO1->FIOCLR = PH ^ CPHMASK;LPC_GPIO1->FIOSET = PH;}

#define CutDrive_Off()  {/**(uint8_t *)PRT_PH_ADDR = 0x0;*/ GPIOB->BSRRH = CMCL; /*GPIOB->BSRRL = PHOEBIT;*/} // LPC_GPIO1->FIOCLR = RMCL




#define CPHASEMAX     	8             	//phase for cutter motor
#define CUTMAXSPEED 	48				//HJ ��ֽ���ٲ���
#define CPHSTART     	(CPH1 | CPH4)   			//cutter start
#define CPHSTOP      	0               //cutter stop

#define FULLCUTSTEPS    500
#define HALFCUTSTEPS    370

//HJ ��ֽ�����̵Ĳ�������
#define CUTSTEPA        (230)//*STEPS1LINE)
#define CUTSTEPB_F      (500)//*STEPS1LINE)    //step B for full cute
#define CUTSTEPB_H      (370)//*STEPS1LINE)     //step B for halif cut
#define CUTSTEPC_F      (700)//*STEPS1LINE)     //step C for full cut
#define CUTSTEPC_H      (570)//*STEPS1LINE)     //step C for half cut

#define CUTSTEPE        (40 )//*STEPS1LINE)
#define CUTSTEPALPHA    (200)//*STEPS1LINE)
#endif	//CASE_FTP628MCL401//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#endif	//ENCUTTER


#define PRNPAUSEMAX  30000           //��ӡ������ʱ,��ͣ30��

#define PRNDOTS		(HEATWIDTH*12)		//HJ ����ͷ�ɴ�ӡ�ĵ���//
#define DOTSBUFF	(PRNDOTS/8)					//HJ ����ͷ�ɴ�ӡ���ֽ���//

#define DOTS_OF_HEAT_LINE     	(HEATWIDTH*12)    //dots of 1 line
#define BYTES_OF_HEAT_LINE     	(DOTS_OF_HEAT_LINE/8)     //size of dot ApplVar.PoolForPrint

#define DOTS_OF_PAPER_LINE     	(PRNWIDTH*12)    //dots of 1 line
#define BYTES_OF_PAPER_LINE     	(DOTS_OF_PAPER_LINE/8)     //size of dot ApplVar.PoolForPrint

#define DOTS1GROUP  (PRNDOTS/GROUPS) //dots for 1 group
#define BYTES1GROUP  (DOTSBUFF/GROUPS) //dots for 1 group

//////// Attribute for print: saved in FontsOffset[]//////////////////////////////////////////
#define DBHFLAG     0x80000000      //double high print mode flag
#define DBWFLAG     0x40000000      //double width print mode flag
#define HANZFLAG    0x20000000      //hanzi flag
#define BODFLAG     0x10000000      //BOLD_MODE

//-------------------------------------------------------------------
// PRNSTATUS ������ʾ��ӡ����״̬ //
typedef volatile struct
{
    ULONG g_bNOPAPER         :1;     //no paper on prnter
    ULONG g_bHANDUP          :1;     //hand is put up
    ULONG g_bTOOHOT          :1;     //too hot,can't print
    ULONG g_bWaitPaper       :1;     //waiting for paper
    ULONG g_bPaperIn         :1;     //paper is insert after paper out
    ULONG g_bHANDDN          :1;      //hand is preee down
    ULONG g_bSuspend         :1;     //printer motor paused for moment

    ULONG g_bTextForGraph    :1;     // text print over the graphic
    ULONG g_bHold            :1;     //ccr2018-03-01 ���ݼ�����к�������ӡ
    ULONG g_bPrintOver       :1;     //not any data in POOL, POOL is empty
    ULONG g_bDoublHight      :1;
    ULONG g_bPrintGraph      :1;     //  Print graphic mode
    ULONG g_bGraphicOver     :1;     //  A task for print graphic finished

    ULONG g_bHotOver         :1;     // ����ʱ����ڲ���ʱ��
    ULONG g_bClean           :1;     //ccr2018-01-26������д�ӡ����
#if (CASE_FTP628MCL401) //HJ
    ULONG g_bHotLatch         :1;     //HJֻ����������,�������ƶ��μ���
#endif
    ULONG g_bDisconnect       :1;    //ccr2018-04-02 û�д�ӡ��
} PRNSTATUS;

// PRNSTATUS ������ʾ��ӡ����״̬ //
typedef struct
{
    WORD g_bCutOK           :1;     //It's readey for cutter
    WORD g_bFirst           :1;     //First flag for cuttor
    WORD g_bReverse         :1;     //Move reverse
    WORD g_bStop            :1;     //Stop cut motor must
    WORD g_bStepC1st        :1;     //for task18 only

} CUTSTATUS;

/////////////////////////////////////////////////////////
//strcuture of print pool

struct TPRN_POOL
{
    BYTE Length;    //Length of the text for print
    BYTE GraphicNo; //=0,print text;>0,print a graphic and ApplVar.Prn_Command is the  lines of text for graphic
    WORD Prn_Command;   //ccr2018-07-30 //command for print or text lines for graphic
    BYTE data[PRNWIDTH];//text for print
};


typedef struct{					// ����䴦�������   //
	BYTE	Command;				// �����ַ�   //
    void    (*Procedure)();    	// ���������  //
} type_Command;
//////////////////////////////////////////////////////////

//#define GRA_SIZE 3204
#define TEXT_HIGH   24      //text high print
#define LINE_BLANK	  4     //blank for line

#define ASCII_SIZE	48  //24*12(24*2 bytes)
#define HZ_SIZE			72  //24*24(24*3 bytes)

#define TEXTSOFGRAPH  8             //����������ͼƬ���ı�����
#define MAX_PRNPOOL 	121         //<250 && >TEXTSOFGRAPH && >TRANSITEMS+20 must

//graphic for printe
extern CONST BYTE photo_data_eutron[];
extern CONST BYTE photo_data_caffe[];
extern CONST BYTE photo_data_abbigl[];

extern CONST BYTE photo_data_appetito[];
extern CONST BYTE photo_data_carneval[];
extern CONST BYTE photo_data_cornetto[];
extern CONST BYTE photo_data_cucina[];
extern CONST BYTE photo_data_donna[];
extern CONST BYTE photo_data_fiori[];
extern CONST BYTE photo_data_gelato[];
extern CONST BYTE photo_data_jolly[];
extern CONST BYTE photo_data_mamma[];

extern CONST BYTE photo_data_natale[];
extern CONST BYTE photo_data_pane[];
extern CONST BYTE photo_data_papa[];
extern CONST BYTE photo_data_pasqua[];
extern CONST BYTE photo_data_pesce[];
extern CONST BYTE photo_data_risparmi[];
extern CONST BYTE photo_data_salumi[];
extern CONST BYTE photo_data_selfdef[];
extern CONST BYTE photo_data_sport[];
extern CONST BYTE photo_data_vacanze[];
extern CONST BYTE photo_data_valentin[];
extern CONST BYTE photo_data_panama[];
extern CONST BYTE photo_data_MALTA[];
extern CONST BYTE photo_data_ITALIA[];

//definitions for graphic

extern CONST struct GRAPH_DEFINE graph_info_ITALIA;
extern CONST struct GRAPH_DEFINE graph_info_MALTA;
extern CONST struct GRAPH_DEFINE graph_info_panama;
extern CONST struct GRAPH_DEFINE graph_info_caffe;
extern CONST struct GRAPH_DEFINE graph_info_eutron;
extern CONST struct GRAPH_DEFINE graph_info_abbigl;
extern CONST struct GRAPH_DEFINE graph_info_appetito;
extern CONST struct GRAPH_DEFINE graph_info_carneval;
extern CONST struct GRAPH_DEFINE graph_info_cornetto;
extern CONST struct GRAPH_DEFINE graph_info_cucina;
extern CONST struct GRAPH_DEFINE graph_info_donna;
extern CONST struct GRAPH_DEFINE graph_info_fiori;
extern CONST struct GRAPH_DEFINE graph_info_gelato;
extern CONST struct GRAPH_DEFINE graph_info_jolly;
extern CONST struct GRAPH_DEFINE graph_info_mamma;

extern CONST struct GRAPH_DEFINE graph_info_natale;
extern CONST struct GRAPH_DEFINE graph_info_pane;
extern CONST struct GRAPH_DEFINE graph_info_papa;
extern CONST struct GRAPH_DEFINE graph_info_pasqua;
extern CONST struct GRAPH_DEFINE graph_info_pesce;
extern CONST struct GRAPH_DEFINE graph_info_risparmi;
extern CONST struct GRAPH_DEFINE graph_info_salumi;
extern CONST struct GRAPH_DEFINE graph_info_selfdef;
extern CONST struct GRAPH_DEFINE graph_info_sport;
extern CONST struct GRAPH_DEFINE graph_info_vacanze;
extern CONST struct GRAPH_DEFINE graph_info_valentin;

extern CONST BYTE Prn_command[];
extern CONST BYTE BitsInByte[];
extern CONST WORD TAB_PHASEJ[];

#if ENCUTTER
extern CONST WORD TAB_PHASECUT[];
extern CONST ULONG TAB_CUTTIME[];
#endif
extern CONST ULONG TAB_PRTIME[];


extern CONST BYTE * Graphic_Data[GRAPHICMAX];
extern CONST struct GRAPH_DEFINE * gra_info[] ;

//#ifndef _PRINT_DEF_
//definitions for print

extern ULONG FontsOffset[PRNWIDTH];//offset of the characters current line
extern BYTE DotsOfCurrent[DOTSBUFF];//Used for store the dots of current line

extern BYTE Prn_PoolCurrent ;

extern struct TPRN_POOL GraphForPrint[TEXTSOFGRAPH+1];
extern struct TPRN_POOL DataFromHost;//received from host
extern BYTE Graph_TextCount ;   // Lines of the text attach for graphic.

extern BYTE SelfGrpReady;
extern struct GRAPH_DEFINE InfoSelf_Graph;
extern BYTE Self_Graph[SELFGRASIZE];

//ccr2017-08-09>>>����ͼƬ�����>>>
//#if BARCODESIZE
//extern struct GRAPH_DEFINE InfoBarCode_Graph;
//extern BYTE BarCode_Graph[BARCODESIZE];
//#endif

#define BarCode_Graph       Self_Graph
#define InfoBarCode_Graph   InfoSelf_Graph

//ccr2017-08-09<<<<<<<<<<<<<<<<<<<


extern BYTE Feed_BlankLines ;    // Feed lines after print
extern BYTE TextIdx_ForGraph ;  //lines for graphic printed

extern WORD Graph_SizeInBytes,
    Graph_DotsLineMax,      //high of the graphic in DOTS-line
    Graph_Remain;           //

extern BYTE Graph_TextLineMax;      //high of the graphic in TEXT-line
extern int Graph_LineCurrent ;

extern PRNSTATUS Prn_Status ;

#if ENCUTTER
extern CUTSTATUS Cut_Status ;
extern WORD CutMotorMax;
#endif

extern BYTE Prn_LineIndex ;     //Dot-line index of print for current line
extern WORD Prn_BlankAppend ;//space lines after 1 line
extern ULONG Prn_MotorTime;         //speed time for motor
extern ULONG Prn_HotTime;            //hot time for Thermal
extern WORD Prn_VNTCR;
extern SCHAR Prn_TaskNow ;  //task num current
extern SCHAR Prn_TaskNext;  //task num after feed
extern BYTE Prn_Jphase ;
extern WORD Prn_AccStep,Prn_AccCopy  ;

extern BYTE Prn_GraphTextMax;      //high of the graphic in TEXT-line
extern BYTE Prn_LineChars;         // chars for current line
extern WORD Prn_LineDots;          // dots for current line
#if GROUPMODE==2
extern BYTE Prn_GroupHot[GROUPS] ;      //��Ҫ���ȵ���,ÿһλ����һ��.ÿһ���������
extern WORD Prn_GroupDots[GROUPS];        //������ȵ���ͳ��
extern BYTE Prn_HotMAX ;                 //��Ҫ���ȴ���
#endif

extern ULONG Prn_FeedCount;       //ͳ�Ƶ�������߶�����
extern WORD Prn_Delay;          //��ӡ����ͣʱ��
extern BYTE Prn_HotIndex;//index of hot of current
#if defined(CASE_FORHANZI)
extern ULONG Prn_HZTime;         // times for read hanzi
#endif

extern BYTE * pGraBuf;
extern unsigned int Graph_Offset;
extern unsigned int Graph_Width;
extern unsigned int Graph_PosX;
extern BYTE * pGraBuf;


extern CONST WORD DoubleByte[];

//#endif
/////////////////////////////////////////////////////////////////
extern void Create384Dots(void);
extern void CreatGraphicWithText(void);
extern void CreateGraphicDots(void);
extern void GetTaskFromPool(void);
extern void ClearAllOfPrintTask(void);
extern void Check_Print(void);
extern void Start_When_Ready(const char *);
extern PRNSTATUS Get_Printer_status(void);

extern int RSPrint(BYTE *buf, int count, WORD prnCMD);
extern BYTE TaskForReceipt(void);

void Reset_printer(void);

void Stop_Motor(void);
void Start_Motor(WORD prnCMD);
void Restart_Motor(void);
void Suspend_Motor(void);

#if ENCUTTER
void  Drive_CutMotor(WORD phase);
#endif

#define CWORD(a) (*(WORD*)&a)

#define CLONG(a) (*(ULONG*)&a)

/////////////////////////////////////////////////////////////////////////////
/* ��ӡ���¶ȼ��˿�:ADC1-10 */
#define ADC2_DR_ADDRESS    ((uint32_t)0x4001214C)


/* ��ӡ�����ݽӿ�:PCLK-PB3,PDATA-PB5, PLATCH-PB4  */
#define PRNData_SPI                           SPI3
#define PRNData_SPI_CLK                       RCC_APB1Periph_SPI3
#define PRNData_SPI_CLK_INIT                  RCC_APB1PeriphClockCmd
/* PDATA-PB5 */
#define PRNData_SPI_MOSI_PIN                  GPIO_Pin_5
#define PRNData_SPI_MOSI_GPIO_PORT            GPIOB
#define PRNData_SPI_MOSI_GPIO_CLK             RCC_AHB1Periph_GPIOB
#define PRNData_SPI_MOSI_SOURCE               GPIO_PinSource5
#define PRNData_SPI_MOSI_AF                   GPIO_AF_SPI3
/* PCLK-PB3 */
#define PRNData_SPI_SCK_PIN                   GPIO_Pin_3
#define PRNData_SPI_SCK_GPIO_PORT             GPIOB
#define PRNData_SPI_SCK_GPIO_CLK              RCC_AHB1Periph_GPIOB
#define PRNData_SPI_SCK_SOURCE                GPIO_PinSource3
#define PRNData_SPI_SCK_AF                    GPIO_AF_SPI3

/* PLATCH-PB4 */
#define PRNData_LATCH_PIN                     GPIO_Pin_4
#define PRNData_LATCH_GPIO_PORT               GPIOB
#define PRNData_LATCH_GPIO_CLK                RCC_AHB1Periph_GPIOB



/* Exported macro ------------------------------------------------------------*/
#if CASE_ER260F
#define PRNData_LATCH_LOW()       GPIO_ResetBits(PRNData_LATCH_GPIO_PORT, PRNData_LATCH_PIN)
#define PRNData_LATCH_HIGH()      GPIO_SetBits(PRNData_LATCH_GPIO_PORT, PRNData_LATCH_PIN)

#elif defined(CASE_ECR100F) || defined(CASE_ECR100S) || defined(CASE_MCR30) || defined(CASE_ECR99)

#define PRNData_LATCH_LOW()       GPIO_ResetBits(GPIOB, GPIO_Pin_4)
#define PRNData_LATCH_HIGH()      GPIO_SetBits(GPIOB, GPIO_Pin_4)

#define PRNData_PDATA_LOW()       GPIO_ResetBits(GPIOB, GPIO_Pin_5)
#define PRNData_PDATA_HIGH()      GPIO_SetBits(GPIOB, GPIO_Pin_5)

#define PRNData_PCLK_LOW()       	GPIO_ResetBits(GPIOB, GPIO_Pin_3)
#define PRNData_PCLK_HIGH()      	GPIO_SetBits(GPIOB, GPIO_Pin_3)

#endif

/* Exported functions ------------------------------------------------------- */


#if DEBUGONPC

void pcStop_Motor();
void pcStart_Motor();

void    Set_Hot_Data(BYTE,BYTE);
    #define udelay(a)    {}
void    Drive_Motor(WORD);
void Set_Motor_Speed(ULONG);
void Start_Hot();
void Stop_Motor();
    #define Latch_Data()    {}
    #define disLatch_Data()    {}


#else//DEBUGONPC

#if (WORDorBYTE)
void    Set_Hot_DataW(WORD dot,BYTE pos);
#else
void    Set_Hot_Data(BYTE dot,BYTE pos);
#endif
// Drive printer motor by one step:GPIO1
void  Drive_Motor(WORD phase);
#if GROUPMODE==2
void  Set_Hot_Group(void);
#endif
// Set the speed of motor: RIT
void Set_Motor_Speed(ULONG speed);
// Set the hot time
void Start_Hot(void);
void Set_HotPIN(void);
//Stop print motor

// delay moment if needed
#define udelay(a)    {}

#endif//DEBUGONPC

extern PRNSTATUS Printer_Status;
extern BYTE  TestPrintGoingOn(void);

extern BYTE PowerFlags;		//��⵽�ĵ�Դ״̬
/*
    Bit0:=0,Ϊ����������;=1,Ϊ��ع���
    Bit1:=1,Ϊ��ع���ʱ,���ֱ���PWR_WARNING1(��ѹ�ε�)
    Bit2:=1,Ϊ��ع���ʱ,���ֱ���PWR_WARNING2(��ѹ����)

    Bit4:=1,Ŧ�۵�س��ֱ���PWR_WARNING1(��ѹ�ε�)
    Bit5:=1,Ŧ�۵�س��ֱ���PWR_WARNING2(��ѹ����)

*/
extern BYTE pwrGetStatus(BYTE GetStatus);

extern struct GRB_DEFINE GRB_Define;

void PrinAllOfHold(void);//ccr2018-03-01
void PrintSetHold(void);//ccr2018-03-01

void ResetPopOutofReceipt(void);//ccr2018-03-07
void SavePopOutOfReceipt(void);//ccr2018-03-07

BYTE  PrinterDetect(void);
void SetPrintDensity(BYTE pSet);

#endif /* __PRINT_H */

