#define FIRMKEY_C
#include "king.h"
#include "exthead.h"
#include "exth.h"
#include "ejournal.h"
#include "flowbill.h"	  //lyq2003
#include "fiscal.h"
#include "message.h"

#if (PC_EMUKEY==1)
    #include "FEcrTest.h"
#endif

BYTE  ProgType_Last=0;

BYTE HTTPPost_DailyZ(void);//testonly

CONST char Reserved[]=MessageE48;

#if (DD_FISPRINTER==0)

/***********************************************
 * ��ӡ����ϵͳ�˵�
 *
 * @author EutronSoftware (2016-12-20)
 **********************************************/
void PrintSetupMenu(void)
{
    int mIdx,sIdx,i,j,l,k;
    char sStr[PRTLEN+3];

    StoreEJEnd();//ccr070609pm

    strcpy(sStr,"SETUP MANUALS LIST");
    PrintLine('.');
    PrintStr_Center(sStr,true);
    PrintLine('=');

    for (mIdx=SETDEPT;mIdx<=SETUPMAX;mIdx++)
    {
        //��ӡ�ϻ��˵�����
        memset(sStr,' ',sizeof(sStr));
        if (mIdx>9) sStr[3]=mIdx/10+'0';
        sStr[4]=mIdx % 10+'0';
        sStr[5]='.';
        strncpy(sStr+6,Msg[mIdx].str,sizeof(sStr)-6);
        sStr[PRTLEN+3-1]=0;
        RJPrint(0,sStr+3);
        switch (mIdx)
        {
        case SETSYSFLAG:
            {
                Appl_ProgLine = 1;
                Appl_ProgStart = 2;      /* indicate program dump */
                Appl_EntryCounter = 0;

                for (i=1;i<=SYSUSED;i++)  //liuj 0601
                {
                    MemSet(SysBuf, PRTLEN, ' ');
                    SysBuf[2]='>';
                    if (i>9) SysBuf[3]=i/10+'0';
                    SysBuf[4]=i % 10+'0';
                    SysBuf[5]='.';
                    memset(ProgLineMes,' ',sizeof(ProgLineMes));
#if (DISP2LINES)
                    memset(ProgLine1Mes,' ',sizeof(ProgLine1Mes));
#endif
                    Appl_BitNumber=0;
                    ProgSysFlag();

#if (!DISP2LINES)
                    memcpy(SysBuf+6, ProgLineMes, PRTLEN-6);
#else
                    l=strlen(ProgLine1Mes)-1;
                    if (l>=sizeof(ProgLine1Mes)) l=sizeof(ProgLine1Mes)-1;
                    for (;l>=0;l--)
                    {
                        if (ProgLine1Mes[l]!=' ')
                            break;
                    }
                    ProgLine1Mes[++l]=0;

                    for (j=0;j<strlen(ProgLine1Mes);j++)
                    {
                        if (ProgLine1Mes[j]!=' ')
                            break;
                    }
                    k=strlen(&ProgLine1Mes[j]);

                    {
                        l=strlen(ProgLineMes)-1;
                        if (l>=sizeof(ProgLineMes)) l=sizeof(ProgLineMes)-1;

                        for (;l>=0;l--)
                        {
                            if (ProgLineMes[l]!=' ')
                                break;
                        }
                        ProgLineMes[++l]=0;
                        CopyFrStr(SysBuf+6, ProgLineMes);
                        if ((l+k)<PRTLEN-6)
                        {
                            l=PRTLEN-6-k;
                        }
                    }
                    memcpy(SysBuf + l+6, ProgLine1Mes+j, k);
#endif
                    SysBuf[PRTLEN]=0;
                    PrintStr(SysBuf);
                    Appl_ProgLine++;
                }
                Appl_ProgLine = 0;
                Appl_ProgStart = 0;      /* indicate program dump */
                Appl_MaxEntry=6;
            }
            break;
        case SETAUXFUNCS:
            {
                for (i=1;i<=AUX_FUNCITEMS;i++)
                {
                    memset(sStr,' ',sizeof(sStr));
                    sStr[2]='>';
                    if (i>9) sStr[3]=i/10+'0';
                    sStr[4]=i % 10+'0';
                    sStr[5]='.';
                    strncpy(sStr+6,Msg[i+AUX_FUNC1ST-1].str,sizeof(sStr)-6);
                    sStr[PRTLEN]=0;
                    RJPrint(0,sStr);
                }
            }
            break;

    #if defined(CASE_GPRS)
        case SETGPRSFUNC:
            {
                for (i=1;i<=gprsMAINITEMS;i++)
                {
                    memset(sStr,' ',sizeof(sStr));
                    sStr[2]='>';
                    if (i>9) sStr[3]=i/10+'0';
                    sStr[4]=i % 10+'0';
                    sStr[5]='.';
                    strncpy(sStr+6,Msg[i+GPRSFUNC1ST-1].str,sizeof(sStr)-6);
                    sStr[PRTLEN]=0;
                    RJPrint(0,sStr);
                }
            }
            break;
    #endif
        }
    }


    strcpy(sStr,"X FUNCTIONS");
    PrintLine('.');
    PrintStr_Center(sStr,true);
    PrintLine('=');

    for (mIdx=1;mIdx<ITEMS_X+1;mIdx++)
    {
        //��ӡ�ϻ��˵�����
        memset(sStr,' ',sizeof(sStr));
        sprintf(SysBuf,"  %02d:%s",mIdx,Msg[mIdx+XREPORT1ST-1].str);
        SysBuf[PRTLEN]=0;
        RJPrint(0,SysBuf);
    }

    strcpy(sStr,"Z FUNCTIONS");
    PrintLine('.');
    PrintStr_Center(sStr,true);
    PrintLine('=');

    for (mIdx=1;mIdx<ITEMS_Z+1;mIdx++)
    {
        //��ӡ�ϻ��˵�����
        memset(sStr,' ',sizeof(sStr));
        sprintf(SysBuf,"  %02d:%s",mIdx,Msg[mIdx+ZREPORT1ST-1].str);
        SysBuf[PRTLEN]=0;
        RJPrint(0,SysBuf);
    }

#if (0)
    PrintLine('.');
    PrintStr_Center(COMMANDSFORSETUP,true);
    PrintLine('=');
    for (mIdx=0;mIdx<AUX_FUNCITEMS;mIdx++)
    {
        //��ӡ�ϻ��˵�����
        sprintf(SysBuf,"  %3d-%s",TblAUX_Funcs[mIdx],Msg[AUX_FUNC1ST+mIdx].str);
        SysBuf[PRTLEN]=0;
        RJPrint(0,SysBuf);
    }
#endif

#if (defined(CASE_ER220)||defined(CASE_ER100)||defined(CASE_ECR100F)||defined(CASE_MCR30))
    l=5;//����
    j=7;//����
#elif (defined(CASE_ER260) || defined(CASE_ER260F))
    l=4;//����
    j=8;//����
#else
    l=0;//����
    j=0;//����
#error "===KEYBOARD ERROR==="
#endif
    if (l)
    {
        PrintLine('.');
        PrintStr_Center(ASCIIONKEYBOARD,true);
        memset(SysBuf,'-',PRTLEN);
        for (i=0;i<j;i++)  SysBuf[2*(i+1)]=i+'1';
        SysBuf[0]='+';SysBuf[2*j+2]='+';SysBuf[2*j+3]=0;
        RJPrint(0,SysBuf);
        for (mIdx=0;mIdx<l*j;mIdx+=j)
        {
            memset(SysBuf,' ',PRTLEN);
            for (i=0;i<j;i++)
            {
                if (ASCIIKEY[mIdx+i])
                    SysBuf[2*(i+1)]=ASCIIKEY[mIdx+i];
            }
            SysBuf[0]='|';SysBuf[2*j+2]='|';SysBuf[2*j+3]=0;
            RJPrint(0,SysBuf);
        }
        memset(SysBuf,'-',PRTLEN); SysBuf[0]='+';SysBuf[2*j+2]='+';SysBuf[2*j+3]=0;
        RJPrint(0,SysBuf);
        PrintLine('.');
        PrintStr_Center(SPECIALONKEYBOARD,true);
        memset(SysBuf,'-',PRTLEN);
        for (i=0;i<j;i++)  SysBuf[2*(i+1)]=i+'1';
        SysBuf[0]='+';SysBuf[2*j+2]='+';SysBuf[2*j+3]=0;
        RJPrint(0,SysBuf);
        for (mIdx=0;mIdx<l*j;mIdx+=j)
        {
            memset(SysBuf,' ',PRTLEN);
            for (i=0;i<j;i++)
            {
                if (NUMASC_KEYBOARD[mIdx+i])
                    SysBuf[2*(i+1)]=NUMASC_KEYBOARD[mIdx+i];
            }
            SysBuf[0]='|';SysBuf[2*j+2]='|';SysBuf[2*j+3]=0;
            RJPrint(0,SysBuf);
        }
        memset(SysBuf,'-',PRTLEN);SysBuf[0]='+';SysBuf[2*j+2]='+';SysBuf[2*j+3]=0;
        RJPrint(0,SysBuf);

    }
    RFeed(3);
}

#endif

/**** ��ȡ���ܼ���ApplVar.AP.FirmKey�е���� ************
  ����0xff:���ǹ��ܼ�
   ******************************************************/
BYTE GetFirmkeyID(BYTE keyno)
{
    int i;
    for (i = 0; i < FIRMKEYS; i++)
    {
        if (keyno == ApplVar.AP.FirmKeys[i])
        {
            return i;
        }
    }
   return 0xff;
}
//����ĳЩ���ܼ����ڵİ���ת��Ϊ���ܼ���  //
#if (0)
BYTE ChangeFuncKey(BYTE keyIn)
{
    switch (keyIn)
    {
    case 9:             //modelock
        if (ApplVar.AP.KeyTable[9]==ApplVar.AP.KeyTable[8] || ApplVar.AP.KeyTable[9]==0)
            return fLOCK;
        else
            return keyIn;
    case 48:
        if (ApplVar.AP.KeyTable[48]==ApplVar.AP.KeyTable[40] || ApplVar.AP.KeyTable[48]==0)
            return fCLEAR;      //clear
        else
            return keyIn;
    case 47:
        if (ApplVar.AP.KeyTable[47]==ApplVar.AP.KeyTable[46] || ApplVar.AP.KeyTable[47]==0)
            return fPRGTYPE;        //select
        else
            return keyIn;
    case 55:
        if (ApplVar.AP.KeyTable[55]==ApplVar.AP.KeyTable[54] || ApplVar.AP.KeyTable[55]==0)
            return fPRGENTER;       //Enter
        else
            return keyIn;
    default:
        return keyIn;
    }
}
#else
#define  ChangeFuncKey(keyIn) (keyIn)
#endif


#if DD_FISPRINTER==0

/**********************************************************************************/

/*****************************************************************************
  ��SETģʽ��,��ѡ��ȷ������Ҫ���õ��ļ���,����DisplayOption
  Appl_ProgType: ָ����ǰ���õ��ļ�(����,��Ʒ,˰��...)
  Appl_ProgLine: =1,�״ν����ļ�������
            >1ʱ(Appl_ProgLine-1)ָʾ��ǰ���õ���Ŀ���,
  Appl_ProgNumber:ָ����ǰ�ļ��еļ�¼��;=-1,���м�¼�������,���¿�ʼ
  Appl_ProgStart:=0,Ϊ��δȷ�������ĸ��ļ�,��ʱ��ѡ������Զ�����ѡ���ļ�
            =1,�Ѿ�ȷ������ĳ���ļ�;��ʱ��λ������,���ܰ�ѡ���
            =2,Ϊö�ٴ�ӡ�ļ�����
  Appl_BitNumber: ���ڿ���λ������.=0:��ʾλ״̬;=2:�ı�λΪYes;=3:�ı�λΪNo
*******************************************************************************/
short DisplayOption(BYTE repeat)
{
    short   RandomL;
    WORD    listItem;//ccr2016-01-18

    RESETBIT(ApplVar.ArrowsAlfa,INPUTPWD+INPUTVALUE);
    SetDateFlg = 0;
    do
    {

        memset(ProgLineMes,' ',sizeof(ProgLineMes));

#if (DISP2LINES)
        memset(ProgLine1Mes,' ',sizeof(ProgLine1Mes));
#endif

        //  if add a new setup,update this line if needed;
        if (Appl_ProgLine == 1 && repeat)
        {//Ϊ��Ҫ���õ��ļ���׼��(Ԥ����)
            switch (Appl_ProgType)
            {
            //case SETSYSFLAG:
            case SETDATE:
            case SETTIME:
            case SETNETWORK:
#if defined(CASE_GPRS)
            case SETGPRSFUNC:
#endif
#if defined(CASE_ETHERNET)
            case SETETHERNETFUNC:
#endif
            case SETAUXFUNCS:
            case SETPORT1:
            case SETPORT2:
            case SETPORT3:
#if (DD_CHIPC==1)
            case SETCHARGIC:    //ccr chipcard
            case SETCLEARIC:    //ccr chipcard
            case SETINITIC:     //ccr chipcard
            case SETCHIPPOINT:
            case SETIC:         //ccr chipcard
#endif
                SETMyFlags(EXITMUST);//ccr2017-12-13
                break;//can't input any data for these setup
            case SETGRAP:
                if (Appl_ProgNumber>=GRASETMAX)
                    Appl_ProgNumber = 0;
                CopyFrStr(ProgLineMes,GrapType[Appl_ProgNumber]);
                SETMyFlags(EXITMUST);//ccr2017-12-13
                break;
            case SETPERIPHERALS://ccr2017-08-04>��SETPORT1,SETPORT2,SETKPN���ൽSETPERIPHERALS��>>>
                SETMyFlags(EXITMUST);//ccr2017-12-13
                switch (listItem=ListItems(SETPERIPHERALS,0,Msg[SETPERIPHERALS].str,false,true))
                {
                case It_EXIT:    //�˳�����
                case 0:         //��Items
                    ProgType_Last=Appl_ProgType-1;//����ֱ��ѡ�����һ�ν��������
                    Appl_ProgType = 0;//�޴����ʱ,���˲��� Appl_ProgType��ָ������
                    Appl_ProgStart=0;
                    Appl_ProgLine = 0;
                    ENTER;//ccr2018-01-18
//                    EXIT;
                    return true;//break;
                default://�������³����ʱ,ֱ�ӽ�������

                    memset(ProgLineMes,' ',sizeof(ProgLineMes));
                    Appl_ProgType=SETPORT1+listItem-1;
                    Appl_ProgLine=1;
                    Appl_ProgNumber=1;
                    Appl_BitNumber = 0;
                    Appl_EntryCounter = 0;
                    ApplVar.ErrorNumber=0;
                    Appl_ProgStart = 1;
                    break;
                }//ccr2017-08-04  <<<<<<<<<<<<<<<<<<<<<<<
            default:
                CLRMyFlags(EXITMUST);//ccr2017-12-13
                if (Appl_ProgNumber<0)
                    Appl_ProgNumber = 0;
/* ccr2017-05-08>>>>>>>>>>
                if (Appl_EntryCounter)
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                    Appl_ProgType = 0;
                    MemSet(ModeHead, sizeof(ModeHead), ' ');
                    strcpy(ModeHead,DText[DTEXT_SET]);//PROGRAM
                    return 0;
                }
 ccr2017-05-08<<<<<<<<<<<<<<<< */
                //��ʾ��¼��
                if (Appl_ProgStart == 2)
                {
                    CopyFrStr(ProgLineMes, Msg[Appl_ProgType].str);
                    ProgLineMes[ DISLEN - 2 - WORDtoASC(ProgLineMes + DISLEN - 1, Appl_ProgNumber + 1)] = '#';//ccr20131120
                }
                else if (Appl_EntryCounter>0)
                {
                    if (Appl_ProgType==SETPLU && ApplVar.AP.Plu.RandomSize)//ccr20131120
                    {
                        ApplVar.PluNumber = 1;

                        if (Appl_EntryCounter <= (ApplVar.AP.Plu.RandomSize * 2))
                        {
                            //ApplVar.Entry.Sign=0;
                            //StrToBCDValue(ApplVar.Entry.Value, &AtEntryBuffer(1), BCDLEN);
                            ApplVar.PluNumber = GetPluNumber(1, ApplVar.Entry.Value);
                            if (!ApplVar.PluNumber)       /* not found then add ? */
                            {
                                if (!CheckRandomPlu(0, 0))       /* add */
                                {
                                    EXIT;
                                    return true;
                                    //ApplVar.PluNumber=1;
                                }
                                else
                                    ApplVar.PluNumber = GetPluNumber(0,ApplVar.Entry.Value);
                            }
                        }
                        Appl_ProgNumber = ApplVar.PluNumber-1;
                        Appl_BitNumber = 0;
                        Appl_EntryCounter = 0;
                        ApplVar.ErrorNumber=0;
                        Appl_ProgLine=2;
                    }
                    else
                    {
                        CopyFrStr(ProgLineMes, Msg[Appl_ProgType].str);
                        ProgLineMes[ DISLEN - 2 - WORDtoASC(ProgLineMes + DISLEN - 1, Appl_ProgNumber + 1)] = '#';//ccr20131120
                    }
                }
                else
                {//�Բ˵���ʽѡ����Ҫ�����ļ��µļ�¼
                    //ccr2017-12-21>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                    //��˰�ʽ����޸�ʱ�������Ƚ���ǰ��˰�ʴ�FM���룬������ͨ�õĸ�ʽ��ʾ�����£�
                    //A=xx.xx%,B=xx.xx%, C=xx.xx%, D=xx.xx% ��E=0%.
                    if (ProgType_Last==SETHEAD-1 && Appl_ProgType!=SETHEAD)
                    {
                        Fiscal_AddHeaderChg(true);
                    }
                    else if (ProgType_Last==SETTAX-1 && Appl_ProgType!=SETTAX)
                    {
                        Fiscal_AddTaxRateChg(false);
                    }
#if defined(CASE_GREECE) //!!! GREECE_ONLY !!!
                    else if (ProgType_Last!=SETTAX-1 && Appl_ProgType==SETTAX)
                    {//��ʾ��ǰ˰��
                        sprintf(SysBuf,"A=%2x.%02x%%B=%2x.%02x%%",ApplVar.CurrentTaxRate[0][1],ApplVar.CurrentTaxRate[0][0],
                                                            ApplVar.CurrentTaxRate[1][1],ApplVar.CurrentTaxRate[1][0]);
                        PutsO(SysBuf);
                        sprintf(SysBuf,"C=%2x.%02x%%D=%2x.%02x%%",ApplVar.CurrentTaxRate[2][1],ApplVar.CurrentTaxRate[2][0],
                                                            ApplVar.CurrentTaxRate[3][1],ApplVar.CurrentTaxRate[3][0]);
                        Puts1(SysBuf);
                        while (!KbHit() || (ProgType_Last=Getch())!=DOWNKey && ProgType_Last!=ENTERKey){}
                        PutsO(SysBuf);
                        sprintf(SysBuf,"E=%2x.%02x%%",ApplVar.CurrentTaxRate[4][1],ApplVar.CurrentTaxRate[4][0]);
                        Puts1(SysBuf);
                        while (!KbHit() || (ProgType_Last=Getch())!=ENTERKey && ProgType_Last!=CLEARKey){}
                        if (ProgType_Last==CLEARKey)
                        {
                            ProgType_Last=Appl_ProgType-1;
                            Appl_ProgStart=0;//ccr2017-12-05
                            EXIT;
                            return true;//break;
                        }
                    }
#endif
                    ProgType_Last=Appl_ProgType-1;
                    //ccr2017-12-21<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                    switch (listItem=ListItems(Appl_ProgType,0,Msg[Appl_ProgType].str,false,true))
                    {
                    case It_EXIT:    //�˳�����
                        Appl_ProgStart=0;//ccr2017-12-05
                        if (Appl_ProgType==SETKP)//ccr2018-01-18 >>>>>>>>>
                        {//��SETKP�˳���,�ص�SETPERIPHERALS
                            Appl_ProgType=SETPERIPHERALS;
                            ProgType_Last=SETPERIPHERALS-1;
                        }//ccr2018-01-18 <<<<<<<<
                        EXIT;
                        return true;//break;
                    case 0:         //��Items
                        CopyFrStr(ProgLineMes, Msg[Appl_ProgType].str);
                        ProgLineMes[ DISLEN - 2 - WORDtoASC(ProgLineMes + DISLEN - 1, Appl_ProgNumber + 1)] = '#';//ccr20131120
                        break;
                    case It_PLU_MG:    //���ӵ�Ʒ
                        if (!GetInputByListItems()) //ccr2017-05-09��ListItems�����л�ȡ���ⰴ��
                        {
                            EXIT;
                            return true;
                        }
                        else
                        {
                            KeyFrHost=0xff;
                            ApplVar.PluNumber = 0;
                            //GetLongEntry(); /* make word from entry to Appl_NumberEntry */

                            if (Appl_EntryCounter <= (ApplVar.AP.Plu.RandomSize * 2))
                            {
                                ApplVar.Entry.Sign=0;
                                StrToBCDValue(ApplVar.Entry.Value, &AtEntryBuffer(1), BCDLEN);
                                ApplVar.PluNumber = GetPluNumber(1, ApplVar.Entry.Value);
                                if (!ApplVar.PluNumber)       /* not found then add ? */
                                {
                                    if (!CheckRandomPlu(0, 0))       /* add */
                                    {
                                        EXIT;
                                        return true;
                                        //ApplVar.PluNumber=1;
                                    }
                                    else
                                        ApplVar.PluNumber = GetPluNumber(0,ApplVar.Entry.Value);
                                }
                                listItem = ApplVar.PluNumber;
                            }
                            else
                                listItem = 1;
                            //break;
                        }
                    default://�������³����ʱ,ֱ�ӽ�������
                        memset(ProgLineMes,' ',sizeof(ProgLineMes));
                        if (Appl_ProgType==SETSYSFLAG)
                        {
                            Appl_ProgLine=listItem-1+2;
                            Appl_ProgNumber=1;
                        }
                        else
                        {
                            Appl_ProgLine=2;
                            Appl_ProgNumber=listItem-1;
                        }
                        Appl_BitNumber = 0;
                        Appl_EntryCounter = 0;
                        ApplVar.ErrorNumber=0;
                        Appl_ProgStart = 1;
                        break;
                    }
                }
#if (DISP2LINES)
//ccr2018-01-18                strcpy(ProgLine1Mes,ENTERMESS);//ccr20131120
#endif
                break;
            }
        }

        switch (Appl_ProgType)
        {
        case SETPLU://1:	/* plu */
            ProgPlu();
            break;
        case SETPLUSTOCK:   //ccr2017-09-15 plu stock
            ProgPluStock();
            break;
        case SETDEPT://2:	/* dept */
            ProgDept();
            break;
        case SETGROUP://3:	/* ApplVar.Group */
            ProgGroup();
            break;
        case SETTEND://4:	/* tend */
            ProgTend();
            break;
        case SETPORA://5:	/* pora */
            ProgPoRa();
            break;
        case SETCORR://6:	/* correc */
            ProgCorrec();
            break;
        case SETDISC://7:	/* disc */
            ProgDisc();
            break;
        case SETCURR://8:	/* ApplVar.Curr */
            ProgCurr();
            break;
        case SETDRAWER://9:	/* drawer */
            ProgDraw();
            break;
#if (DD_FISPRINTER==0 && DD_DISABLEPBF==0)
        case SETPBF://10:	 /* pb functions */
            ProgPbF();
            break;
        case SETPBINF://27:
            ProgPbInfo();
            break;
#endif
        case SETTAX://11:	 /* tax */
#if defined(FISCAL)
            if (ApplVar.ZReport != 1)   /* z report taken ? */
            {
                Appl_ProgStart = 0;
                Appl_ProgLine = 0;//ccr2014 ���Ա���Ҫ���˳���,���ǻ�ص���������.
                ApplVar.ErrorNumber=ERROR_ID(CWXXI75);
                CopyFrStr(ProgLineMes+1, Msg[Appl_ProgType].str); // liuj 0808
                ProgLineMes[0]='>';
                return 0;//ccr2014 break;
            }
            if (ApplVar.FTrain)    //cc 20071026
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                break;
            }
#endif
            ProgTax();
            break;
        case SETCLERK://12:	 /* clerk */
            ProgClerk();
            break;
        case SETZONES://13:	 /* zones */
            ProgZone();
            break;
        case SETMODIF://14:	 /* modifiers */
            ProgModi();
            break;
        case SETHEAD://15:	/* program header */
#if(defined(FISCAL))	//cc 20071026
            if (ApplVar.ZReport != 1)   /* z report taken ? */
            {
                Appl_ProgStart = 0;
                Appl_ProgLine = 0;//ccr2014 ���Ա���Ҫ���˳���,���ǻ�ص���������.
                ApplVar.ErrorNumber=ERROR_ID(CWXXI75);
                CopyFrStr(ProgLineMes+1, Msg[Appl_ProgType].str); // liuj 0808
                ProgLineMes[0]='>';
                return 0;//ccr2014 break;
            }
            if (ApplVar.FTrain)
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                break;
            }
#endif
            ProgHeader();
            break;
        case SETTRAIL://16:
            ProgTrailer();
            break;
#if (DD_SETSLIP)
        case SETSHEAD://17:	    /* slip header */
            ProgSlipHead();
            break;
#endif
#if (DD_SETREPORT)
        case SETREPORT://18:
            ProgReport();
            break;
        case SETREPTYPE://23:	/* report types */
#endif
        case SETFIXCAP://19:	/* fixed captions */
        case SETERRMSG://20:	/* system & error message */
        case SETWEEKCAP://21:	/* day of week captions */
        case SETMONTHCAP://22:	/* month captions */
            ProgSysMes();
            break;
        case SETSYSFLAG://24:	 /* system flags */
            ProgSysFlag();
            break;
        case SETKEYB://25:	/* keyboard code and manager */
            Appl_MaxEntry = 6;
            memset(ProgLineMes,' ',sizeof(ProgLineMes));
#if(DD_ZIP==1)
            //memset(ProgLine1Mes,' ',sizeof(ProgLine1Mes));
            strcpy(ProgLine1Mes,EXITMESS);//ccr2014-10-31
#endif
            CopyFrStr(ProgLineMes + 1, Msg[SETKEYB].str);
            if (Appl_ProgLine < 3)
            {
#if(DD_ZIP==1)
                CopyFrStr(ProgLineMes + 1, Prompt.LineCap[Line_KEYCODE]);
#else
                CopyFrStr(ProgLineMes + 6, Prompt.LineCap[Line_KEYCODE]);
#endif
                if (Appl_ProgLine == 1)
                {
                    Appl_ProgLine++;
                    break;
                }
            }
            else
            {
                Appl_ProgType = 0;
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                strcpy(ModeHead,DText[DTEXT_SET]);//PROGRAM
/*ccr080829
#if (DISP2LINES)
                        CopyFrStr(ProgLineMes + 1, Prompt.LineCap[Line_MANAGE]);
#else
                        CopyFrStr(ProgLineMes + 6, Prompt.LineCap[Line_MANAGE]);
#endif
                        if (Appl_ProgLine == 3)
                        {
                            Appl_ProgLine++;
                            break;
                        }
*/
            }
            if (ApplVar.Key.Code > 2 && ApplVar.Key.Code < 0x0100)
                return 0;
            if (Appl_ProgLine == 2)
            {
                if ((Appl_NumberEntry == '.' || Appl_NumberEntry < 3 || Appl_NumberEntry > 299) &&
                    Appl_NumberEntry != CLEAR && Appl_NumberEntry != MODELOCK)
                {
                    //ccr2014-03-10>>>>>>>>
                    if (FEEDKey == ApplVar.KeyNo)
                        FEEDKey = 0xff;
                    else if (CLEARKey == ApplVar.KeyNo)
                        CLEARKey = 0xff;
                    else if (LOCKKey == ApplVar.KeyNo)
                        LOCKKey = 0xff;
                    //<<<<<<<<<<<<<
                    ApplVar.AP.KeyTable[ApplVar.KeyNo] = Appl_NumberEntry;
                    switch (Appl_NumberEntry)
                    {
                    case JPF:
                        FEEDKey = ApplVar.KeyNo;
                        break;
                    }
                    SETMyFlags(CONFIGECR);
                }
            }
/*ccr080829			else if (Appl_ProgLine == 4 && !Appl_EntryCounter)
                    {
                        if (ApplVar.KeyNo == EXITKey)
                            Appl_ProgLine = 0;
                        else
                            ApplVar.AP.Manager[ApplVar.KeyNo / 8] ^= (0x01 << (ApplVar.KeyNo % 8));
                    }*/
            else
            {
                Appl_ProgType = 0;
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                strcpy(ModeHead,DText[DTEXT_SET]);//PROGRAM
            }
            DeptPluKeysCount();
            break;
        case SETKEYMASK://26:	/* keyswitch disable */
            if (GetOpt(7, ApplVar.AP.Config.KeyMask, sizeof(ApplVar.AP.Config.KeyMask) * 8))
                break;
#if (salNumber)
        case SETSALER://28:
            ProgSalPer();
            break;
#endif
        case SETDATE:
#if defined(FISCAL)
            if (ApplVar.ZReport != 1)   /* z report taken ? */
            {
                Appl_ProgStart = 0;
                Appl_ProgLine = 0;
                ApplVar.ErrorNumber=ERROR_ID(CWXXI75);
                CopyFrStr(ProgLineMes+1, Msg[Appl_ProgType].str); // liuj 0808
                ProgLineMes[0]='>';
                return 0;//ccr2014 break;
            }
#endif
            ProgDate();
            break;
        case SETTIME:
#if defined(FISCAL)
            if (ApplVar.ZReport != 1)   /* z report taken ? */
            {
                Appl_ProgStart = 0;
                Appl_ProgLine = 0;
                ApplVar.ErrorNumber=ERROR_ID(CWXXI75);
                CopyFrStr(ProgLineMes+1, Msg[Appl_ProgType].str); // liuj 0808
                ProgLineMes[0]='>';
                return 0;//ccr2014 break;
            }
#endif

            ProgTime();
            break;
#if offNumber
        case SETOFF:
            ProgOFF();
            break;
#endif
        case SETPORT1:
            ProgPort(0);
            break;
        case SETPORT2:
            ProgPort(1);
            break;
        case SETPORT3:
            strcpy(ProgLineMes,Reserved);
            break;

        case SETNETWORK:
#if (defined(CASE_ETHERNET)||defined(CASE_GPRS))
            ProgNetWork();    //ccr chipcard 2004-06-28
#else
            strcpy(ProgLineMes,Reserved);
#endif
            break;
#if defined(CASE_GPRS)
        case SETGPRSFUNC:
            ProgGPRSFuncs();
            break;
#endif
#if defined(CASE_ETHERNET)
        case SETETHERNETFUNC:
            ProgNetFunctions();//ccr2017-09-20 ProgEthernetFuncs();
            break;
#endif
        case SETAUXFUNCS:  //ccr2017-05-10
            ProgAuxFunctions();
            break;
        case SETGRAP:
            ProgPrnGraph();
            break;
#if (DD_CHIPC)
        case SETIC:
            ProgIC();    //ccr chipcard 2004-06-28
            break;
#endif
#if (DD_PROMOTION)
        case SETPROM:
            ProgPromotion();
            break;
#endif
//ccr070725				case SETAGREE:
//ccr070725					ProgAgree();
//ccr070725					break;
        case SETKP:
            ProgKPrn();
            break;
#if (DD_SETSLIP)
        case SETSP:
            ProgSlip();
            break;
#endif
#if (DD_CHIPC==1)
        case SETBLOCKIC:
            ProgICBlock();
            break;  //ccr chipcard 2004-07-01
        case SETCHARGIC:
            ProgChargeChip();
            break;
        case SETCLEARIC:
            ProgClearChip();
            break;
        case SETINITIC:
            ProgInitialChip();
            break;
        case SETCHIPPOINT:
            ProgPoints();
            break;
#endif
        default:
            Appl_ProgType = 0;
            strcpy(ModeHead,DText[DTEXT_SET]);//PROGRAM
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            break;
        }
        Save_ConfigVar(false);

        //���Appl_ProgLine=0,��ʾ�Զ�ѭ�����õ�ǰ�ļ�������
        if (Appl_ProgLine || !Appl_ProgType //ccr2017-12-05
            || Appl_ProgType == SETSYSFLAG
            || Appl_ProgType == SETNETWORK//ccr2015-10-12
#if defined(CASE_GPRS)
            || Appl_ProgType == SETGPRSFUNC //ccr2016-12-23
#endif
#if defined(CASE_ETHERNET)
            || Appl_ProgType == SETETHERNETFUNC//ccr2017-02-16
#endif
            || Appl_ProgType ==  SETAUXFUNCS
#if (DD_CHIPC)
            || Appl_ProgType >= SETCLEARIC//ccr chipcard
#endif
            || Appl_ProgType == SETKEYB
            || Appl_ProgType == SETKEYMASK)
            break;

        if (Appl_ProgStart == 2)
        {//ö�ٴ�ӡ����
            Appl_ProgNumber++;
        }
#if 0 //ccr2017-05-10>>>>>>>>
        else if (Appl_ProgType == SETDEPT  && Appl_ProgNumber >=0 /*|| Appl_ProgType == SETTAX || Appl_ProgType == SETHEAD*/)
        {
#if defined(FISCAL)
            RFeed(1);
            DumpDept();
#endif
            //PrintRegiInfo();
            //FiscalTrailer();

        }
#endif //ccr2017-05-10<<<<<<<<
        if (repeat) //ccr2017-05-10
            Appl_ProgLine = 1;//�������õ�ǰ�ļ�
    } while (repeat);//end of do()

//    if (Appl_ProgStart == 2)
//    ProgLineMes[sizeof(ProgLineMes) - 1] = 0;
//    else
        ProgLineMes[DISLEN]=0;
#if (DISPLINE2)
    ProgLine1Mes[DISLEN]=0;
#endif
    return true;
}


//CheckFirmKey return true(1) If the input from keyboard processed by CheckFirmKey
//else return false(0);
//ֻ����SET/X/Z���µİ�������,����״̬�²�����CheckFirmKey
WORD CheckFirmKey()
{
    int  i,xz;
    WORD listItem,cpCentralLock;
    BYTE keyno,cpNumber;

    keyno = ChangeFuncKey(ApplVar.KeyNo);

    if (keyno==CLEARKey)    /* firm key clear key */
    {
        //ccr2017-07-25>>>ϣ����CLEAR�����˳�>>>>
        if (Appl_EntryCounter || ApplVar.ErrorNumber || ApplVar.CentralLock==RG || ApplVar.CentralLock==MG
            || (ApplVar.CentralLock==SET && Appl_ProgStart && Appl_EntryCounter))
        {
            ApplVar.Key.Code = CLEAR;
            if (ApplVar.CentralLock==X || ApplVar.CentralLock==Z)
            {
              ApplVar.ReportNumber=0;
              ENTER;
            }
            return false;
        }
        else if (ApplVar.CentralLock==X || ApplVar.CentralLock==Z)
        {
            MODE;
            return true;
        }
        else
        {//ccr2017-07-25ϣ����CLEAR�����˳�
            if (MyFlags(EXITMUST))//ccr2017-12-13
            {
                CLRMyFlags(EXITMUST);//ccr2017-12-13
                //���ô����,���ص�MODE���˵�,Appl_ProgLine=0;
                Appl_ProgStart=0;
            }
            keyno=EXITKey;
        }
        //ccr2017-07-25<<<<<<<<<<<<<<<<<<<<
    }

    if (ApplVar.ErrorNumber)
        return TRUE;
    else if (Appl_EntryCounter && Appl_ProgType == SETKEYB && Appl_ProgLine == 2)
        i = ID_ENTER;    /* simulate enter key */
    else if (Appl_ProgType == SETKEYB && Appl_ProgLine == 4)
    {
        i = ID_ENTER;
        Appl_ProgLine--;
    } else
        i = GetFirmkeyID(keyno);

    if (ApplVar.FuncOnEnter!=0 && i!=ID_CANCEL)      //lyq added 2003\10\30		   start
    {
        return false;
    }                                      //lyq added 2003\10\30		   end
    if ((ApplVar.FRegi || ApplVar.FInv) && i < sizeof(ApplVar.AP.FirmKeys))
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI14);
        return 1;
    }
    if (Appl_EntryCounter)
    {
        StrToBCDValue(ApplVar.Entry.Value, &AtEntryBuffer(1), BCDLEN);//&EntryBuffer[ENTRYSIZE - 2]
        GetLongEntry();
    }
//ccr2017-07-05    else if (Appl_NumberEntry<0)//special use for fCANCEL
//ccr2017-07-05        Appl_NumberEntry = abs(Appl_NumberEntry);
    else
        Appl_NumberEntry = 0;
    //ccr2017-05-11>>>>��ID_DOWN��ת��>>>>>>>>>>>
#if defined(CASE_EURO) //!!! GREECE_ONLY !!!//ccr2017-12-04>>>>>>>>>>>>> ʹ�����¼�����Select
    if (ApplVar.CentralLock == SET && Appl_ProgType>0 && Appl_ProgStart && (i==ID_DOWN || i==ID_UP))
    {
        if (Appl_ProgType==SETGRAP && Appl_ProgLine==1)
        {//������ͼƬʱ,��ѡ���ѡ��ͼƬ
            if (i==ID_DOWN)
            {
                Appl_ProgNumber++;
                if (Appl_ProgNumber>GRASETMAX )
                    Appl_ProgNumber = 0;
            }
            else if (Appl_ProgNumber>0)
                Appl_ProgNumber--;
            else
                return true;
            DisplayOption(true);
            PutsO(ProgLineMes);
#if (DISP2LINES)
            Puts1(ProgLine1Mes);
#endif
            return true;
        }
        else if (Appl_ProgLine>0 && Appl_BitNumber)
        {//�ڴ��������ļ���ĳ����Ŀ״̬ʱ,�����ѡ���,�����������
            /* change option on/off */
            Appl_EntryCounter = 1;   /* set invert by setting Appl_EntryCounter */

            if (i==ID_DOWN)
                Appl_BitNumber++;
            else if (Appl_BitNumber>1)
                Appl_BitNumber--;

            if (!DisplayOption(true))
                return 0;
            if (!ApplVar.ErrorNumber)
            {
                PutsO(ProgLineMes);
#if (DISP2LINES)
                Puts1(ProgLine1Mes);
#endif
            }
            return true;
        }
        else if (i==ID_DOWN)
            i=ID_ENTER;
    }
#else//ccr2017-12-04<<<<<<<<<<<<<<<<<<<<<<<<
    if (i==ID_DOWN)
    {
        if (ApplVar.CentralLock == SET)
        {
            if (Appl_ProgStart!=0)
                i=ID_ENTER;
//ccr2017-09-11 ��ֹSELECTѡ��˵�����            else
//ccr2017-09-11 ��ֹSELECTѡ��˵�����                i=ID_SELECT;
        }
//ccr2017-09-11 ��ֹSELECTѡ��˵�����        else if(ApplVar.CentralLock == X || ApplVar.CentralLock == Z)
//ccr2017-09-11 ��ֹSELECTѡ��˵�����        {
//ccr2017-09-11 ��ֹSELECTѡ��˵�����            i=ID_SELECT;
//ccr2017-09-11 ��ֹSELECTѡ��˵�����        }
    }
#endif
    //ccr2017-05-11<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    //ccr2017-11-03>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if ((i==ID_ENTER)&&(ApplVar.CentralLock == X || ApplVar.CentralLock == Z)&&(Appl_EntryCounter==0 && ApplVar.ReportNumber==0))
    {//���л���X/Z����ģʽ��,ֱ�Ӱ�ȷ�ϼ�,����Ϊ��ID_DOWN,�����˴���ʱ,��ȷ�ϻ�ֱ�Ӵ�ӡ��һ������!!!!!
        i=ID_DOWN;
    }//ccr2017-11-03<<<<<<<<<<<<<<<<<<<<<<<<<
    switch (i)//(ApplVar.AP.FirmKeys[i])
    {
    case ID_SYSREP:         // system report trigger
#if defined(FISCAL)
        if (ApplVar.CentralLock == SET)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            return 1;
        }
//liuj 0529
        if (ApplVar.FiscalFlags!= FISCALOK
            && ApplVar.FiscalFlags != TESTFM //liuj 0728  test card can do everything except sale
            && ApplVar.FiscalFlags != FMLESS
            && ApplVar.FiscalFlags != EJLESS)
        {
            if (ApplVar.FiscalFlags == FMISNEW)
                ApplVar.ErrorNumber=ERROR_ID(CWXXI94);
            else
                CheckFisError();
            return 1;
        }

#endif

        ApplVar.FReport = ApplVar.CentralLock;
        GetSystemReport(0);
        ApplVar.FReport = 0;
        break;
    case ID_UP:     /* ���ص���һ��������Ŀ */
        //1.����SET��,������δ�����ļ�����()
        if (ApplVar.CentralLock == SET)
        {
            if (Appl_ProgType==SETGRAP && Appl_ProgLine==1)
            {//������ͼƬʱ,��ѡ���ѡ��ͼƬ
                if (Appl_ProgNumber>0)
                {
                    Appl_ProgNumber--;
                    DisplayOption(true);
                    PutsO(ProgLineMes);
#if (DISP2LINES)
                    Puts1(ProgLine1Mes);
#endif
                }
                return 1;
            }
            if (Appl_ProgType>0 && Appl_ProgLine>0 && Appl_ProgStart>0)// && Appl_BitNumber)
            {//�ڴ��������ļ���ĳ����Ŀ״̬ʱ,
                if (Appl_ProgLine>2)
                {
                    Appl_ProgLine--;
                    ClearEntry();
                    keyno = Appl_ProgLine;//��DisplayOption����ǿ������Appl_ProgLine�����
                    Appl_BitNumber=0;
                    Appl_ProgStart = 1;
                    if (!DisplayOption(true))
                        return 0;
                    if (Appl_ProgLine>keyno)
                    {//��DisplayOption����ǿ���޸�Appl_ProgLine�����
                        Appl_ProgLine=keyno;
                    }
                    if (!ApplVar.ErrorNumber)
                    {
                        PutsO(ProgLineMes);
        #if (DISP2LINES)
                        Puts1(ProgLine1Mes);
        #endif
                    }
                }
                return 1;
            }
            if (Appl_ProgType>1 && !Appl_ProgStart)
            {//ѡ��Ҫ���õ��ļ�
                Appl_ProgType--;
                memset(ProgLineMes,' ',DISLEN+1);
                CopyFrStr(ProgLineMes, Msg[Appl_ProgType].str);
                Appl_MaxEntry = 6;

                //ccr2017-07-26>>>>�ڵ�һ����ʾ�ļ����,�ڶ�����ʾ����>>>>
                PutsPre(0,ProgLineMes,'>');
#if (DISP2LINES)
                memset(ProgLine1Mes,' ',DISLEN);
//ccr2017-09-11 ���ڵڶ�����ʾ                CopyFrStr(ProgLine1Mes,DText[DTEXT_SET]);
//ccr2017-09-11 ���ڵڶ�����ʾ                WORDtoASC(ProgLine1Mes+DISLEN-1,Appl_ProgType);
//ccr2017-11-29                CopyFrStr(ProgLine1Mes, Msg[Appl_ProgType+1].str);//ccr2017-09-11 ���ڵڶ�����ʾ
                Puts1(ProgLine1Mes);// (ENTERMESS);//ccr20131120
#endif
                //ccr2017-07-26<<<<<<<<<<<

                Appl_ProgNumber = 0;
                Appl_ProgLine = 0;//
                Appl_BitNumber = 0;
            }
            break;
        }
        else if ((ApplVar.CentralLock==X || ApplVar.CentralLock==Z) && ApplVar.ReportNumber>1)
        {
            ApplVar.ReportNumber-=2;
        }
        else
            break;
    case ID_SELECT:     //ccr2017-09-11 ��ֹSELECTѡ��˵�����>>>>
#if defined(CASE_EURO) //ccr2017-09-11
        if ((i==ID_SELECT)&&(ApplVar.CentralLock==X || ApplVar.CentralLock==Z || (ApplVar.CentralLock==SET && Appl_ProgStart==0)))
            return 1;
    case ID_DOWN:       //ccr2017-09-11 ��ֹSELECTѡ��˵����ܸ���ID_DOWN<<<<<
#endif
        //ccr2017-05-31>>>>>>>����X/Z�����˵�>>>>>>>>>>>>>>>>>>>>>>>
        if (ApplVar.CentralLock==X || ApplVar.CentralLock==Z)
        {// use fPRGTYPE key to select a ApplVar.Report file;
            if (ApplVar.CentralLock==X)
            {
                i=XREPORT1ST;
                listItem=ITEMS_X;
                xz=DTEXT_X;
            }
            else
            {
                xz=DTEXT_Z;
                i=ZREPORT1ST;
                listItem=ITEMS_Z;
            }
            ApplVar.ReportNumber++;
            if (ApplVar.ReportNumber>listItem)
                ApplVar.ReportNumber = 1;

            if (Appl_EntryCounter)
            {
                if (Appl_NumberEntry==0 || Appl_NumberEntry>listItem)
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                    break;
                }
            }
            else
                Appl_NumberEntry = ApplVar.ReportNumber;

//ccr2017-09-15 �����һ�ΰ�DOWNʱ���¹�������            ApplVar.ReportNumber = Appl_NumberEntry;
            memset(SysBuf,' ',DISLEN);

            //ccr2017-07-26>>>>�ڵ�һ����ʾ�ļ����,�ڶ�����ʾ����>>>>
#if(DISP2LINES)
            memset(ProgLine1Mes,' ',DISLEN);
//ccr2017-09-11���ڵڶ�����ʾ            CopyFrStr(ProgLine1Mes,DText[xz]);
//ccr2017-09-11���ڵڶ�����ʾ            WORDtoASC(ProgLine1Mes+DISLEN-1,ApplVar.ReportNumber);
//ccr2017-11-29            if (ApplVar.ReportNumber<listItem)  //ccr2017-09-12�ڶ�����ʾ��һ��
//ccr2017-11-29                CopyFrStr(ProgLine1Mes,Msg[i+ApplVar.ReportNumber].str);
            Puts1(ProgLine1Mes);
#endif
            CopyFrStr(SysBuf,Msg[i+ApplVar.ReportNumber-1].str);//ccr2017-11-29
            //ccr2014 WORDtoASC(SysBuf+DISLEN - 1,Appl_NumberEntry);
            PutsPre(0,SysBuf,'>');
			//ccr2017-07-26<<<<<<<<<<<<<<<<<<<<<<
            ClearEntry();
            return 1;
        }
        else if (Appl_ProgType==SETGRAP && Appl_ProgLine==1)
        {//������ͼƬʱ,��ѡ���ѡ��ͼƬ
            Appl_ProgNumber++;
            if (Appl_ProgNumber>GRASETMAX )
                Appl_ProgNumber = 0;
            DisplayOption(true);
            PutsO(ProgLineMes);
#if (DISP2LINES)
            Puts1(ProgLine1Mes);
#endif
            return 1;
        }
        else if (Appl_ProgType>0 && Appl_ProgLine>0 && Appl_ProgStart>0)// && Appl_BitNumber)
        {//�ڴ��������ļ���ĳ����Ŀ״̬ʱ,�����ѡ���,�����������
            /* change option on/off */
            if (Appl_BitNumber)     /* ֻ�����λ������,���ܹ���ѡ���,invert option ? */
                Appl_EntryCounter = 1;   /* set invert by setting Appl_EntryCounter */
            else
            {//���򱨴�
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                break;
            }
            Appl_BitNumber++;
            Appl_ProgStart = 1;
            if (!DisplayOption(true))
                return 0;
            if (!ApplVar.ErrorNumber)
            {
                PutsO(ProgLineMes);
#if (DISP2LINES)
                Puts1(ProgLine1Mes);
#endif
            }
            break;
        }
        else if (Appl_NumberEntry > 102 && Appl_NumberEntry < 108)  /* Check ApplVar.Plu File */
        {
            if (Appl_NumberEntry == 107 && ApplVar.CentralLock != SET)
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);  /* repair only in Z or SET */
            else
                CheckPluFile(Appl_NumberEntry);
            break;
        }
        else if (Appl_NumberEntry)
        {//ѡ��Ҫ���õ��ļ�
            Appl_ProgType = Appl_NumberEntry+1;//ccr2017-09-15 �����һ�ΰ�DOWNʱ���¹�������
            Appl_ProgStart = 0;
         }
        else if (!Appl_ProgType || !Appl_ProgStart)// �Զ�������ʽѡ��Ҫ���õ��ļ�
            (Appl_ProgType >= SETUPMAX || !Appl_ProgType)?(Appl_ProgType = 1):(Appl_ProgType++);

        //ccr2017-05-09>>>>>�����������뵥Ʒ����ĳ���>>>>>>>
        if (Appl_ProgType==SETPLU && ApplVar.AP.Plu.RandomSize)
            Appl_MaxEntry=ApplVar.AP.Plu.RandomSize*2;
        else
            Appl_MaxEntry=6;
        //ccr2017-05-09<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        strcpy(ProgLineMes,Msg[Appl_ProgType].str);

        //ccr2017-07-26>>>>�ڵ�һ����ʾ�ļ����,�ڶ�����ʾ����>>>>
        PutsPre(0,ProgLineMes,'>');
#if (DISP2LINES)
        memset(ProgLine1Mes,' ',DISLEN);
//ccr2017-09-11���ڵڶ�����ʾ        CopyFrStr(ProgLine1Mes,DText[DTEXT_SET]);
//ccr2017-09-11���ڵڶ�����ʾ        WORDtoASC(ProgLine1Mes+DISLEN-1,Appl_ProgType);
//ccr2017-11-29        if (Appl_ProgType<SETUPMAX) //ccr2017-09-11�ڵڶ�����ʾ��һ��������
//ccr2017-11-29            strcpy(ProgLine1Mes,Msg[Appl_ProgType+1].str);
        Puts1(ProgLine1Mes);// (ENTERMESS);//ccr20131120
#endif
        //ccr2017-07-26<<<<<<<<<<<

        Appl_ProgStart = 0;
        Appl_ProgNumber = 0;
        Appl_ProgLine = 0;//
        Appl_BitNumber = 0;
        break;
    case ID_ENTER:     /* ID_ENTER enter key */
        if (ApplVar.CentralLock == X || ApplVar.CentralLock == Z)
        {/* select report for X/Z by the input */

            if (ApplVar.CentralLock==X)
            {
                xz=XREPORT1ST;
                listItem=ITEMS_X;
            }
            else
            {
                xz=ZREPORT1ST;
                listItem=ITEMS_Z;
            }

            if (Appl_EntryCounter==0 && (ApplVar.ReportNumber==0 || ApplVar.ReportNumber>listItem))
            {
                Appl_NumberEntry = 1;
                Appl_EntryCounter = 1;
            }
            if (Appl_EntryCounter)
            {

                if (Appl_NumberEntry==0 || Appl_NumberEntry>listItem)
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                    break;
                }
                ApplVar.ReportNumber = Appl_NumberEntry;
#if(DISP2LINES)
//                CopyFrStr(SysBuf,ModeHead);
//ccr2017-12-12                PutsO(Msg[xz+ApplVar.ReportNumber-1].str);
//ccr2017-12-12                if (Appl_NumberEntry<=listItem)
//ccr2017-12-12                    Puts1(Msg[xz+ApplVar.ReportNumber].str);
#else
//ccr2017-12-12                PutsO(Msg[xz+ApplVar.ReportNumber-1].str);
#endif
               //ccr2014 WORDtoASC(SysBuf+DISLEN - 1,Appl_NumberEntry);
				//<<<<<<<<<<<<<<<<<<<<<<
            }
            //ccr2017-05-31���¿���X/Z�µĹ��ܲ˵�>>>>>>>>>>
            {
                if (ApplVar.FiscalFlags!= FISCALOK
                    &&  ApplVar.FiscalFlags != TESTFM //liuj 0728  test card can do everything except sale
                    && ApplVar.FiscalFlags !=FMLESS
                    && ApplVar.FiscalFlags != EJLESS)
                {
                    if (ApplVar.FiscalFlags == FMISNEW)
                        ApplVar.ErrorNumber=ERROR_ID(CWXXI94);
                    else
                        CheckFisError();
                    return 1;
                }

                cpNumber=ApplVar.ReportNumber;
                cpCentralLock=ApplVar.CentralLock;
                ApplVar.ReportNumber--;
                if (ApplVar.CentralLock == Z)
                    ApplVar.ReportNumber+=ITEMS_X;
                ApplVar.ReportNumber=TblXZ_Funcs[ApplVar.ReportNumber];
                if (ApplVar.ReportNumber<100)
                {//ģ���ϵ�XZ�����Ĵ�������
                    ApplVar.ReportNumber++;
                    ApplVar.RepComputer = 0;
                    if (ApplVar.CentralLock != Z || ApplVar.ReportNumber!=1)
                    {//��˰��Z����1,ȫ��ΪX��ӡ��ʽ:��ӡ����0
                        ApplVar.CentralLock = X;
                    }
                    ApplVar.FReport = ApplVar.CentralLock;

                    if (ApplVar.FReport == Z && ApplVar.ReportNumber == 1/*&& ApplVar.FiscalFlags == FISCALOK*/)//ccr070609pm
                        Print_FiscalReport(false);//��ӡZ����
                    else
                        GetReport(ApplVar.ReportNumber);

                    ApplVar.FReport = 0;
                }
                else
                {   //����X/Z�µķǴ�ӡ��������
                    switch (ApplVar.ReportNumber)
                    {
                    case CMD_xALLDAILY      :// "ALL DAILY"
                        for (i=0;i<=xCATEGORY-XREPORT1ST;i++)
                        {
                            ApplVar.ReportNumber=TblXZ_Funcs[i]+1;
                            ApplVar.FReport = ApplVar.CentralLock;
                            GetReport(ApplVar.ReportNumber);
                            ApplVar.FReport = 0;
                        }
                        break;
                    case CMD_xGENERALPARAM	:// "GENERAL PARAMETERS"
                        do//ccr2017-12-12>>>>>>>>>>>>
                        {
                            switch (listItem=ListItems(xGENERALPARAM,0,Msg[xGENERALPARAM].str,false,true))
                            {
                            case (xLISTPLU-xLISTPLU+1):                       //PLU LIST
                                PrintAllOfPLU();
                                break;
                            case (xLISTDEPARTMENT-xLISTPLU+1):                //DEPARTMENT LIST
                                PrintAllOfDepart();
                                break;
                            case (xLISTCLERK-xLISTPLU+1):                     //CLERK LIST
                                PrintAllOfClerk();
                                break;
                            case It_EXIT:
                                listItem=It_EXIT ;
                            default:
                                break;
                            }
                        } while (listItem!=It_EXIT); //ccr2017-12-12<<<<<<<<<<<
                        break;
                    case CMD_zCOPYLASTZ  	://"COPY OF LAST Z"
                        CopyPrintLastZ();
                        break;
                    case CMD_zZERODEPARTMENT://  "ZERO DEPARTMENT"
                    case CMD_zZEROPLUSALES  :// "ZERO PLU SALES"
                    case CMD_zZEROCLERKS    ://  "ZERO CLERKS"
#if (salNumber)
                    case CMD_zZEROWAITERS   ://  "ZERO WAITERS"
#endif
                        ApplVar.ReportNumber=ApplVar.ReportNumber-CMD_zZERODEPARTMENT+IDX_Z_FROM;
                        ApplVar.ReportNumber=TblXZ_Funcs[ApplVar.ReportNumber]+1;
                        ApplVar.CentralLock = Z;
                        SETMyFlags(CLOSEPRINT);//�رմ�ӡ��
                        ApplVar.FReport = Z;
                        GetReport(ApplVar.ReportNumber);
                        CLRMyFlags(CLOSEPRINT);
                        ApplVar.FReport = 0;
                        PutsM((char*)MsgREPORTCLEARED);
                        break;
                    case CMD_zZEROALLSALES  :// "ZERO ALL SALES"
                        for (i=IDX_Z_FROM;i<IDX_Z_FROM+(CMD_zZEROWAITERS-CMD_zZERODEPARTMENT+1);i++)
                        {
                            ApplVar.ReportNumber=TblXZ_Funcs[i]+1;
                            ApplVar.CentralLock = Z;
                            SETMyFlags(CLOSEPRINT);//�رմ�ӡ��
                            ApplVar.FReport = Z;
                            GetReport(ApplVar.ReportNumber);
                            CLRMyFlags(CLOSEPRINT);
                            ApplVar.FReport = 0;
                        }
                        PutsM((char*)MsgREPORTCLEARED);
                        break;
                    case CMD_zFMREADZ_Z:// "FM READ Z-Z"
                        PrintFMZByZ_Z();
                        break;
                    case CMD_zFMREADDATE:// "FM READ DATE"
                        PrintFMZByDate(FISCLEARLOG);
                        break;
#if defined(CMD_zFMREADTAXRATE)
                    case CMD_zFMREADTAXRATE:  // "READ TAX RATE "
                        PrintFMZByDate(FISTAXLOG);
                        break;
                    case CMD_zFMREADHEAD:     // "READ HEAD "
                        PrintFMZByDate(FISHEADCHGLOG);
                        break;
                    case CMD_zFMREADSETDATE:     //ccr2017-08-08 // "READ DATE CHANGED"
                        PrintFMZByDate(FISDATECHGLOG);
                        break;
#endif
#if defined(CMD_zHTTPPOSTSFILE)
                    case CMD_zHTTPPOSTSFILE:    //ccr2017-10-23 "SEND S-FILES OF Z"
                        HTTPPost_SFiles();
                        break;
#endif
                    }
                }
                PutsPre(0,(char*)Msg[xz+cpNumber-1].str,'>');//ccr2017-12-12
                ApplVar.ReportNumber=cpNumber;
                ApplVar.CentralLock=cpCentralLock;
            }
            break;
            //ccr2017-05-31<<<<<<<<<<<<<<<<<<
        }
        else if (ApplVar.CentralLock == SET && Appl_ProgType)//ccr chipcard
        {//Ϊ����״̬ ,ѡ���µ������ļ�
            if (Appl_ProgType <= SETKEYMASK)//SETCLEARIC)//ccr chipcard
            {
                MemSet(ModeHead, sizeof(ModeHead), ' ');
#if((DISP2LINES) || DD_LCD_1601)
                CopyFrStr(ModeHead,Msg[Appl_ProgType].str);
                ModeHead[tCAPWIDTH] = 0;
#else
                CopyFrStr(ModeHead,Msg[Appl_ProgType].str, 4);
                ModeHead[4] = 0;
#endif
                if (Appl_ProgType==SETTAX)
                    CopyTaxRate();
            }

            if (Appl_ProgLine==1 && Appl_EntryCounter)// && Appl_ProgStart>0)
            {//ccr2017-05-09�˶γ���ֻ������������/ʱ������ʱ�Żᱻִ��>>>>>>>>>>>>>>
                /* program number key,select spacified PLU/DEPT/.... */
                if (!Appl_ProgStart)
                {
                    CheckMultiply();
                    break;
                }
                ApplVar.Entry.Sign = 0;

                if (Appl_ProgType == SETPLU && ApplVar.AP.Plu.RandomSize)
                {//�������˵�Ʒ����ʱ,����������µ�Ʒ����ɾ���ɵ�Ʒ
                    //ccr2017-05-10�˶γ��򲻻ᱻִ��>>>>>>>>>>>>>>
                    ApplVar.PluNumber = 0;
                    if (Appl_EntryCounter <= (ApplVar.AP.Plu.RandomSize * 2))
                    {
                        ApplVar.PluNumber = GetPluNumber(1, ApplVar.Entry.Value);
                        if (!ApplVar.PluNumber)       /* not found then add ? */
                        {
                            if (!CheckRandomPlu(0, 0))       /* add */
                            {
                                PutsPre(0,ModeHead,'>');// liuj 0806
                                break;
                            }
                            ApplVar.PluNumber = GetPluNumber(0,ApplVar.Entry.Value);
                        }
                        else if (ApplVar.CentralLock != X)  /* ask for delete ? */
                            CheckRandomPlu(1, 0);   /* delete? */
                        Appl_NumberEntry = ApplVar.PluNumber;
                    }
                    else
                        Appl_NumberEntry = 0;
                    //ccr2017-05-10<<<<<<<<<<<<<<<<<<<<
                }

                if (Appl_ProgType==SETDATE || Appl_ProgType==SETTIME)//ccr2015-10-12  || Appl_ProgType==SETNETWORK)
                {

                    Appl_ProgLine = 2;//set date or time
                    DisplayOption(true);
                    ClearEntry();
//						ClearLine2();
                    strcpy(ProgLineMes+1,ModeHead);
                    ProgLineMes[0]='>';
                    return 1;
                }
                if (Appl_NumberEntry)
                    Appl_ProgNumber = Appl_NumberEntry - 1;
                else
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                    break;
                }
                //�����˼�¼��
                Appl_ProgLine = 0;
                Appl_BitNumber = 0;
                Appl_EntryCounter = 0;
                ApplVar.ErrorNumber=0;
                ApplVar.KeyNo = ENTERKey;//fPRENTER;
                CheckFirmKey();//=======================!!!!!!!!!!!!!
                return 1;
            //ccr2017-05-09<<<<<<<<<<<<<<<<<<<<<<<<<
            }
            if ((Appl_ProgType==SETDATE || Appl_ProgType==SETTIME)//ccr2015-10-12 || Appl_ProgType==SETNETWORK)
                && !Appl_EntryCounter && SetDateFlg>0)
            {
                SetDateFlg = 0;
                Appl_EntryCounter = 0;
                ApplVar.ErrorNumber=0;
                Appl_ProgLine = 0;
                Appl_ProgStart = 0;
                Appl_BitNumber = 0;
                ApplVar.KeyNo = ENTERKey;//fPRTYPE;
                CheckFirmKey();//=======================!!!!!!!!!!!!!
                return true;
            }
        }// end of "if (ApplVar.CentralLock==SET && Appl_ProgType && Appl_EntryCounter)"

        if (!Appl_EntryCounter || Appl_BitNumber)//ccr2017-12-25
        {
            if (!Appl_ProgType)
            {
                //ccr2017-12-05ѡ��Department/PLU/....
                SetItemDefault(SETPROGRAM,ProgType_Last);//ccr2017-12-15
                listItem=ListItems(SETPROGRAM,0,ModeHead,false,true);
                if (listItem==It_EXIT)// || listItem==It_PLU_MG)
                {//ccr2017-12-05>>>>>���ص�ģʽѡ��
                    KeyFrHost=LOCKKey;
                    return true;
                }
                else
                {
                    VirtualInputWORD(ENTERKey,listItem);
                    return true;
                }
            }
            else if (!BIT(ApplVar.ArrowsAlfa,SETCONFIRM))//ccr040809
            {
                Appl_ProgLine++;
                Appl_BitNumber = 0;
                //ccr2017-05-09>>>>>�����������뵥Ʒ����ĳ���>>>>>>>
                if (Appl_ProgType==SETPLU && ApplVar.AP.Plu.RandomSize)
                    Appl_MaxEntry=ApplVar.AP.Plu.RandomSize*2;
                else
                    Appl_MaxEntry=6;
                //ccr2017-05-09<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
            }
            else
                break;
        }
        //ccr20170508>>>>>>>Ϊ��Ʒʱ,�������ӵ�Ʒ����>>>>>
        else if (Appl_ProgType==SETPLU && Appl_ProgLine == 0)
        {
            Appl_ProgLine = 1;
        }//ccr20170508<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        else if (Appl_BitNumber || !Appl_ProgType)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            break;
        }
        Appl_ProgStart = 1;
        if (!DisplayOption(true))
            return 0;
        if (!ApplVar.ErrorNumber)
        {
            PutsO(ProgLineMes);

#if (DISP2LINES)
            Puts1(ProgLine1Mes);
#endif

        }
        break;
#ifdef ID_DUMP
    case ID_DUMP:   /* dump program key */
        ProgramDump();
        break;
#endif
    case ID_CANCEL://  Appl_ProgType>0
        RESETBIT(ApplVar.ArrowsAlfa,INPUTPWD+INPUTVALUE+SETCONFIRM);//ccr040809
        SetInputMode(0);

        //ccr chipcard>>>>>>>>>>>>>>>>>>>>>>>>>>

        if ((ApplVar.CentralLock & SETUPMG) == SETUPMG)
        {//cancel the verify of password mode,return to REGIS mode directly
            ApplVar.CentralLock &=( ~SETUPMG);
#if	(DD_CHIPC==1)
            IC.ICState &= IC_NOTREMOVED;
#endif
            ClearEntry();
            Appl_MaxEntry = ENTRYSIZE-2;
            PutsO(ModeHead);
            ClearLine2(); //
            Appl_ProgType = Appl_ProgLine = 0;
            return ApplVar.CentralLock;
        }//<<<<<<<<<<<<
        //ccr chipcard<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        Save_Config(false);
        if (Appl_ProgLine==0 && Appl_ProgStart==0)
        {//return to SET mode
            Appl_ProgType = 0;
#if defined(CASE_EURO) //!!! GREECE_ONLY !!!
            KeyFrHost=LOCKKey;
            return ApplVar.CentralLock;
#else
            if (ApplVar.CentralLock==X || ApplVar.CentralLock==Z)
            {
                PutsPre(0,ModeHead,'>');
                Appl_MaxEntry = 6;
                break;
            }
            else
            {
                ApplVar.FuncOnEnter = 0;           //lyq added 2003/10/30
                ApplVar.CentralLock = SET;
                strcpy(ModeHead,DText[DTEXT_SET]);
                PutsPre(0,ModeHead,'>');
                Appl_MaxEntry = 6;
                break;
            }
#endif
        }
        else
        {//�˳��ļ���������,return to last set mode
#if 0 //ccr2017-05-10>>>>>>>>
#if defined(FISCAL) //&& CASE_FATFS_EJ == 1 //liuj 0530
            if (Appl_ProgType == SETDEPT  && Appl_ProgNumber >=0 /*|| Appl_ProgType == SETTAX || Appl_ProgType == SETHEAD*/)
            {
                RFeed(1);
                DumpDept();
			}
#endif
#endif //ccr2017-05-10<<<<<<<<<

            ApplVar.ErrorNumber=0;
            Appl_EntryCounter = 0;
            Appl_ProgLine = 0;
            //ccr2018-01-18 >>>>when we enter this menu we can't go back with CL key   ��c���˳�������peripherals������DEPARTMENT
            if (Appl_ProgType == SETPORT1 || Appl_ProgType == SETPORT2 || Appl_ProgType == SETKP)
            {
                if (Appl_ProgStart)
                {
                    ProgType_Last=SETPERIPHERALS -1;//����ֱ��ѡ�����һ�ν��������
                    Appl_ProgType = 0;//�޴����ʱ,���˲��� Appl_ProgType��ָ������
                }
            }
            else//ccr2018-01-18 <<<<<<<<<<<<<<
            {
                //ccr2017-12-05>>>>>>>>
                if (!Appl_ProgStart || Appl_ProgType==SETKEYB)
                {//����ǴӲ���/��Ʒ�������˳�,Ӧ�ûص�����/�б�ѡ��
                    ProgType_Last=Appl_ProgType-1;//����ֱ��ѡ�����һ�ν��������
                    Appl_ProgType = 0;//�޴����ʱ,���˲��� Appl_ProgType��ָ������
                }
            }
            Appl_ProgStart=0;
            ENTER;//ccr2017-12-05
            return true;
#if (0)//ccr2017-12-05>>>>>>>>>>>>
#if defined(CASE_EURO)     //ccr2017-09-11 ��ֹSELECTѡ��˵�����
            ApplVar.KeyNo = CLEARKey;//fPRGTYPE;
#else
            Appl_ProgType--;
            ApplVar.KeyNo = SELECTKey;//fPRGTYPE;
#endif
            CheckFirmKey();
            return true;
#endif//ccr2017-12-05<<<<<<<<<<<<<<
        }
    default:
        return 0;
    }
    ClearEntry();
#if (DISP2LINES)
    if (i == ID_CANCEL)
        ClearLine2(); //
#endif
    return true;
}


void DispForPwd(CONSTCHAR *mess)
{
    memset(SysBuf,'-',DISLEN+5);

#if ((DISP2LINES) )
    PutsO(mess);
    Puts1(SysBuf);
#else
    CopyFrStr(SysBuf,mess);
    PutsO(SysBuf);
#endif
}
//chang the work mode if Press MODELOCK key
//CheckMode return true(1) or simulated ApplVar.KeyNo If the input from keyboard processed by CheckMode
//else return false(0);


BYTE CheckMode()
{
    BYTE keyno;
    short   i,j;
    UnLong sAddr,sVal;
    BYTE sYear,sMonth,sDay;
    BYTE setprint;

    keyno=ChangeFuncKey(ApplVar.KeyNo);
    if (ApplVar.KeyNo == FEEDKey)
    {
        if (Appl_EntryCounter==0)
        {
            JFeed();
            return true;
        }
        else//���Ѿ�����������ʱ.��������ֽ,��ֽ����Ϊɾ��������
            return false;
    }

    if (ApplVar.ErrorNumber)
        return FALSE;
    //ccr2017-05-09>>>>>ͨ���˵�ѡ����ģʽ>>>>>>>>>>>>>
    if (ApplVar.KeyNo == LOCKKey && !ApplVar.FRegi)
    {
        //ccr2017-12-21>>>>>>>>>>>>

         //ccr2018-01-16 Ԥ��Ʊͷ>>>>>>>>>>>
         if (ApplVar.CentralLock==SET)
         {
            if (Appl_ProgType==SETHEAD)
            {
                PrintHeader();
                RFeed(PREHEADER+2);
                return true;
            }
            else if (Appl_ProgType)
                return true;
        }//ccr2018-01-16 Ԥ��Ʊͷ<<<<<<
        ProgType_Last=0;
        if (ApplVar.CentralLock==SET)
        {
            Fiscal_AddTaxRateChg(false);
            Fiscal_AddHeaderChg(true);
        }//ccr2017-12-21<<<<<<<<<<<<<
        CLRMyFlags(EXITMUST);//ccr2017-12-13
        if (Appl_EntryCounter)
        {//ͨ����������+LOCK����˵�
            StrToBCDValue(ApplVar.Entry.Value, &EntryBuffer[ENTRYSIZE - 2], BCDLEN);
            GetLongEntry();
        }
        else
        {//�Ե�ǰģʽ����˵�
            switch (ApplVar.CentralLock)
            {
            case RG:Appl_NumberEntry=1;break;
            case X:Appl_NumberEntry=2;break;
            case Z:Appl_NumberEntry=3;break;
            case SET:Appl_NumberEntry=4;break;
#if !defined(CASE_GREECE)//ccr2017-12-14ȥ��������
            case MG:Appl_NumberEntry=5;break;
#endif
            }
        }
        //ccr2017-12-05>>>>>>>>>>>>>>>
        if (Appl_NumberEntry>=1 && Appl_NumberEntry<=ITEMS_MODE)
            SetItemDefault(SETECRMODE,Appl_NumberEntry-1);
        i = ListItems(SETECRMODE,false,"ECR MODE",false,true);
        ClearEntry();
        Appl_EntryCounter=1;
        if (i>=1 && i<=ITEMS_MODE)
        {
            AtEntryBuffer(1)=i+'0';
            AtEntryBuffer(0) = 0;
            ENTER;//ccr2017-12-04
        }
        else
        {//Ĭ�Ͻ���REGISTģʽ
            Appl_MaxEntry = ENTRYSIZE-2;
            AtEntryBuffer(1)='1';
            AtEntryBuffer(0) = 0;
        }
        Appl_ProgLine=0;
        Appl_ProgType=0;
        Appl_ProgStart=0;
        //ccr2017-12-05<<<<<<<<<<<<<<<<
    }
    //ccr2017-05-09<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    if (MyFlags(CANCELSAL) && keyno != CLEARKey && keyno != ENTERKey)
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI25);
        return TRUE;
    }

    if (ApplVar.Key.Code == CORREC+4 && ApplVar.FRegi)
    {//��Ϊȡ������ʱ,����һ��ȷ��
        SETMyFlags(CANCELSAL);
        PutsO(DMes[ItemDMes24]);//confirm
        return TRUE;
    }

    i = GetFirmkeyID(keyno);

    if (i>=sizeof(ApplVar.AP.FirmKeys))//�������⹦�ܼ�֮��
        return FALSE;

    if (ApplVar.FuncOnEnter)
    {//���Ѿ��������⹦�ܲ���ʱ
        if (i==ID_CANCEL)
        {
            SetInputMode(0);
            ApplVar.FuncOnEnter = 0;
            ApplVar.Key.Code = 0;
            LogDefine.idx = 0;
            ClearEntry();
            Appl_MaxEntry=6;
            PutsPre(0,ModeHead,((ApplVar.CentralLock==RG)||(ApplVar.CentralLock==MG))?(0):('>'));
            ClearLine2(); //
            return TRUE;
        }
        else if (i==ID_CLEAR)
        {
            ApplVar.Key.Code=0;
            ClearEntry();
#if (DISP2LINES)
            Puts1(Msg[SPACE].str);
#else
            PutsO(EntryBuffer + ENTRYSIZE - DISLEN - 1);
#endif
            return TRUE;
        }
        else if (i!=ID_ENTER && i!=ID_SHIFTKEY)
        {
            ApplVar.Key.Code=0;
            return TRUE;
        }
    }

    switch (i)
    {
/*
    case ID_CANCEL:
        if (ApplVar.CentralLock != RG && !Appl_ProgType)
        {

            keyno = RG;
            ApplVar.CentralLock = RG;
            ModeHead[0]=0;
            ClearEntry();
            PutsO(DText[DTEXT_REG]);
            return keyno;

        }
        else
            return 0;
*/
    case ID_SHIFTKEY:  /* �ı�������뷨(a->A->9 */
        if ((ApplVar.CentralLock == SET || ApplVar.CentralLock == (SETUPMG|RG) || ApplVar.CentralLock == (SETUPMG|MG)))
        {
            if (BIT(ApplVar.ArrowsAlfa,INPUTVALUE))
            {
                SetInputMode(ID_SHIFTKEY);
                return TRUE;
            }
        }
        return FALSE;
    case ID_CLEAR:
/*		if (BIT(ApplVar.ArrowsAlfa,SETCONFIRM))//ccr040809
        {//don't confirm SETUP request.
            RESETBIT(ApplVar.ArrowsAlfa,SETCONFIRM);
            ApplVar.KeyNo = fCANCEL;
            return FALSE;
        }*/
        if (MyFlags(CANCELSAL))
        {
            CLRMyFlags(CANCELSAL);
            ApplVar.Key.Code = 0;
            ClearEntry();
            PutsO(EntryBuffer+ENTRYSIZE-DISLEN-1);
            ClearLine2();
            return TRUE;
        }
        return FALSE;
    case ID_RJFEED:
//			RFeed(1);
        return TRUE;
#if !defined(FISCAL)//ccr070609pm
    case ID_OCPRINTER:
        if (BIT(DOT,BIT5) && !Appl_EntryCounter)
        {
#if PC_EMUKEY
            if (FisTestTask.PrnOFF)   //    ccr080519 added for control the printing of pb message
            {
                FisTestTask.PrnOFF = 0;
                PutsO(MessageE49);
            }
            else
            {
                FisTestTask.PrnOFF = 1;
                PutsO(MessageE50);
            }

#else
            if (!MyFlags(CLOSEPRINT))
            {
                PutsO(MessageE50);
                SETMyFlags(CLOSEPRINT);
            }
            else
            {
                PutsO(MessageE49);
                CLRMyFlags(CLOSEPRINT);
            }
#endif
            return TRUE;
        }
        else
            return FALSE;
#endif
    case ID_ENTER://������������
        if (Appl_ProgType==0)
        {
            if (MyFlags(CANCELSAL))
            {
                ApplVar.Key.Code = CORREC+4;
                ApplVar.KeyNo=GetKeyNoByCode(ApplVar.Key.Code);//ccr2017-09-22
                ProcessKey();
                CLRMyFlags(CANCELSAL);
                ApplVar.Key.Code = 0;
                return TRUE;
            }
            if (ApplVar.CentralLock==SET)
            {//Can chang password for a mode if in SET mode
                if (Appl_EntryCounter)
                {
                    StrToBCDValue(ApplVar.Entry.Value, &EntryBuffer[ENTRYSIZE - 2], BCDLEN);
                    GetLongEntry();
                }
                else
                {
                    ApplVar.Entry = ZERO;
                    Appl_NumberEntry = 0;
                }

                switch (Appl_NumberEntry)
                {//SET�µ���������
    #if defined(CASE_ETHERNET)
                case CMD_INPUTMAC://����MAC��ַ
                    ClearEntry();
                    ClearLine2();
                    ProgMAC();
                    strcpy(ModeHead,DText[DTEXT_SET]);
                    PutsPre(0,ModeHead,'>');
                    return TRUE;
    #endif

                case CMD_HARDTEST:
                    SystemTestMenu();
//ccr2017-12-05                    strcpy(ModeHead,DText[DTEXT_SET]);
//ccr2017-12-05                    PutsPre(0,ModeHead,'>');
                    ENTER;//ccr2017-12-05
                    return TRUE;
                case CMD_INITFISCAL://FUNC800,˰�س�ʼ��
                    CheckFiscal(false);
                    if (ApplVar.FiscalFlags == FMISNEW)  /* new card */
                    {
    /*ccr2014-PANAMA-TRAIN
                        if (MyFlags(ZREPORT))   //z report taken ?
                        {
                            ApplVar.ErrorNumber=ERROR_ID(CWXXI75);
                            ApplVar.FuncOnEnter = 0; //liuj 0528
                            return TRUE;
                        }
    */
                        Initial_Fiscal();
                    }
                    else
                        ApplVar.ErrorNumber=ERROR_ID(CWXXI79);     /* already initialied */

                    //���ϴ����ʱ,��������ʾ��ʼ��EJ EXIT;//ccr2017-12-05

                    return TRUE;
    #if(defined(CASE_FATFS_EJ))
                case CMD_INITEJ:
                    Initial_EJ();//ccr091125
                    //���ϴ����ʱ,�������EJ��ʼ����� EXIT;//ccr2017-12-05
                    MODE;//ǿ�ƽ���MODE��ʽѡ��˵�
                    return TRUE;
    #endif

                default:
                    if (Appl_EntryCounter)
                    {//ccr2017-05-08>>>>>>>>
                        if ((Appl_NumberEntry>0 && Appl_NumberEntry<=SETUPMAX))
                        {//��ȷ�Ϻ�,ֱ�ӽ�������
                            Appl_ProgType = Appl_NumberEntry;
                            Appl_ProgStart = 0;
                            ClearEntry();
                            return false;
                        }
                        else
                            ApplVar.ErrorNumber=ERROR_ID(CWXXI32);     //illegle input
                        //ccr2017-05-08<<<<<<<<<<
                    }
                    else
                        PutsPre(0,ModeHead,'>');
                    return false;
                }
            }
        }
        return FALSE;
    case ID_LOCK:       //change mode

        ApplVar.FuncOnEnter = 0;
        setprint =0;//liuj 0606
#if defined(FISCAL)
        Fiscal_AddTaxRateChg(false);
        Fiscal_AddHeaderChg(true);
#endif

        if (ApplVar.CentralLock == SET && Appl_ProgLine>0)
        {// ������ʱ���������ʱ����ֹģʽ�л�  //
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            return 0;
        }

        if (Appl_EntryCounter)
        {
            StrToBCDValue(ApplVar.Entry.Value, &EntryBuffer[ENTRYSIZE - 2], BCDLEN);
            GetLongEntry();
        }
        else
            Appl_NumberEntry = 0;
        //ccr2017-02-23>>>>���л���Ӫҵ��ʱ,���������������еĴ���
        if (ApplVar.FRegi && Appl_NumberEntry!=1)// || (ApplVar.PB.Block || ApplVar.FProforma))//ccr091127
        {//on the saling mode,can't chang the mode
            ApplVar.ErrorNumber=ERROR_ID(CWXXI14);
            return 0;
        }
        if (ApplVar.CentralLock==MG && ApplVar.FInv)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI47);
            return 0;
        }

        {//select new mode first

            if (MyFlags(REBOOTMUST))//�޸�������ĵ�ǰֵ
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI118);//ccr2017-09-26��Ҫ���������տ��
                CLRMyFlags(REBOOTMUST);
            }

#if defined(FISCAL)	//liuj 0529
            if (ApplVar.FiscalFlags != FISCALOK && ApplVar.FiscalFlags != FMLESS && ApplVar.FiscalFlags != EJLESS)  // liuj 0728
            {
                CheckFisError();    //liuj 0611
                Appl_NumberEntry = 4;
            }

#elif defined(CASE_FATFS_EJ)
            if (ApplVar.FiscalFlags == MUSTINITEJ)  // liuj 0728
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI97);
                Appl_NumberEntry = 4;
            }
#endif

            PwdInput[0]=0;

            switch (Appl_NumberEntry)
            {
            case 1://Regist����ģʽ
                if (ApplVar.CentralLock == RG)//ccr070608
                    setprint = 1;

                keyno = RG;
                ApplVar.CentralLock = RG;

                strcpy(ModeHead,DText[DTEXT_REG]);
                if (ApplVar.AP.KeyTable[MAXKEYB-1]==0xffff)     //lyq added 2003\11\1 start
                {//������ʽ�£�ʹ��Сд��ĸ��ʾӪҵģʽ
                    for (i=strlen(ModeHead)-1;i>0;i--)
                        ModeHead[i] |= 0x20;
                }                                      //lyq added 2003\11\1 end
                ApplVar.FReceipt=0;//ccr2018-01-19
                SetInputMode(0);
                PutsO(ModeHead);

                Appl_MaxEntry = ENTRYSIZE-2;
                if (BIT(CLERKFIX, BIT0))    /* clerk compulsory or secret, no key */
                    ApplVar.ClerkNumber = 0;
#if (salNumber)
                if (BIT(KEYTONE, BIT6))
                    ApplVar.SalPerNumber = 0;
#endif
                Save_ConfigVar(false);

                break;
#if !defined(CASE_GREECE)//ccr2017-12-14ȥ��������
            case 5:
                keyno=CheckPassword(MG);
                if (keyno==0xff || keyno==false)
                {
                    SetInputMode(0);
                    EXIT;
                    return true;
                }
                ApplVar.FReceipt=0;//ccr2018-01-19
                SetInputMode(0);
                keyno = MG;
                strcpy(ModeHead,DText[DTEXT_MG]);
                PutsPre(0,ModeHead,'>');
                ApplVar.CentralLock = MG;
                if (BIT(CLERKFIX, BIT0))    /* clerk compulsory or secret, no key */
                    ApplVar.ClerkNumber = 0;
#if (salNumber)
                if (BIT(KEYTONE, BIT6))
                    ApplVar.SalPerNumber = 0;
#endif
                Appl_MaxEntry = ENTRYSIZE-2;
                ENTER;
                break;
#endif
            case 2:
                keyno=CheckPassword(X);
                if (keyno==0xff || keyno==false)
                {
                    SetInputMode(0);
                    EXIT;
                    return true;
                }
                keyno = X;
                ApplVar.CentralLock = X;
                SetInputMode(0);

                ApplVar.ReportNumber = 0;
                strcpy(ModeHead,DText[DTEXT_X]);//ccr20131120
                PutsPre(0,ModeHead,'>');
                Appl_MaxEntry = 6;
#if (DISP2LINES)
                strcpy(ProgLineMes,ModeHead);
#endif
                ENTER;
                break;
            case 3:
#if defined(FISCAL)    //ccr091127>>>>>>>>>>>>>>>
#if (0)
                for (i=1; i <= ApplVar.AP.Pb.NumberOfPb; i++)
                {
                    PbTotal(i, 0);
                    if (ApplVar.PB.Block)
                    {// �й������̨ʱ,ǿ�ƴ�ӡZ��������������й������̨������   //

                        memset(SysBuf,' ',DISLEN);
                        WORDtoASCZero(SysBuf+4, i);
                        SysBuf[1]='T';
                        strcpy(SysBuf+6,SERVING);
                        PutsO(SysBuf+1);

                        while (1)
                        {
                            if (!KbHit())
                                continue;
                            i =Getch();
                            if (i==CLEARKey)
                            {
                                PutsO(ModeHead);
                                ApplVar.ErrorNumber=ERROR_ID(CWXXI14);
                                return 0;
                            }
                            if (i==ENTERKey)
                            {
                                ApplVar.ZReport = 1;// ���ι���ǿ�ƴ�ӡZ���� //
                                break;
                            }
                        }
                    }
                }
#endif
                RESETBIT(ApplVar.Fiscal_PrintFlag,BIT2);    //cc 20070524
#endif     //<<<<<<<<<<<<<<<<<<<<<
                keyno=CheckPassword(Z);
                if (keyno==0xff || keyno==false)
                {
                    SetInputMode(0);
                    EXIT;
                    return true;
                }
                SetInputMode(0);

                keyno = Z;
                ApplVar.CentralLock = Z;

                ApplVar.ReportNumber = 0;
                strcpy(ModeHead,(char*)DText[DTEXT_Z]);
                PutsPre(0,ModeHead,'>');
                Appl_MaxEntry = 6;
#if (DISP2LINES)
                strcpy(ProgLineMes,ModeHead);
#endif
                ENTER;
                break;
            case 4:
#if defined (CASE_GREECE)//ccr2018-03-21 ϣ��Ҫ�����SETʱ,�����ӡZ����
                if (ApplVar.ZReport != 1)   /* z report taken ? */
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI75);
                    return 0;
                }
#endif
//					if (ApplVar.AP.KeyTable[MAXKEYB-1]==0xffff)
                for (i=1; i <= ApplVar.AP.Pb.NumberOfPb; i++)
                {
                    PbTotal(i, 0);
                    if (ApplVar.PB.Block)
                    {// �й������̨ʱ,��ֹ����SET   //
                        ApplVar.ErrorNumber=ERROR_ID(CWXXI14);
                        return 0;
                    }
                }

#if DD_CHIPC
                RESETBIT(IC.ICState,IC_INSERT);//ccr040809
#endif
                keyno=CheckPassword(SET);
                if (keyno==0xff || keyno==false)
                {
                    SetInputMode(0);
                    EXIT;
                    return true;
                }
                keyno = SET;
                ApplVar.CentralLock = SET;
                SetInputMode('9');

                strcpy(ModeHead,DText[DTEXT_SET]);
                PutsPre(0,ModeHead,'>');
                Appl_MaxEntry = 6;
                ENTER;
                break;
            default:
                if (Appl_EntryCounter)
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI32);     //illegle input
                return 0;
            }

            ClearEntry();
#if (DISP2LINES)//ccr20131120>>>>>>>>>
            if (ApplVar.CentralLock==RG || ApplVar.CentralLock==MG)
                Puts1(EntryBuffer + ENTRYSIZE - DISLEN - 1);
            else
            {
                memset(SysBuf,' ',DISLEN);SysBuf[DISLEN]=0;
                Puts1(SysBuf);//ccr2017-09-11���ڵڶ�����ʾPuts1(SELECTMESS);
            }
#endif//<<<<<<<<<<<<<<<<
            //�л�����ģʽ������ڶ���
            return keyno;
        }
    default:
        return 0;
    }
}
#endif

//Suspend ECR if user press MODELOCK,Resume ECR until user press MODELOCK
void SuspendECR()
{
#if (!defined(DEBUGBYPC) && DD_FISPRINTER==0)

    BYTE keyno,Befl;

    Bios_1(BiosCmd_BuzzS);

    LCDClose();

    PutsO_Only(MessageE59);

    do
    {
        Bios_1(BiosCmd_AutoClickOff);
        while (!KbHit()) FM_EJ_Exist();
        keyno = Getch();
#if (0)//!defined(DEBUGBYPC)
        /*������״̬��,������˳���,��ر�GPIOA,����ʹ��JLINK���س���*/
        if (keyno==Default.FirmKeys[ID_CANCEL])
        {
            Save_ApplRam();
            PutsO_Only("FOR JLINK ONLY!");//
            GPIO_DeInit(GPIOA);
            while(1){};
        }
#endif
    } while (keyno != LOCKKey);

    if (!BIT(KEYTONE,BIT0))
        Bios_1(BiosCmd_AutoClickOn);

    PutsO_Saved();
    Bios_1(BiosCmd_BuzzS);
    LCDOpen();

#endif
}

//////////////////////////////////////////////////////////////////////////

