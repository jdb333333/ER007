/***********************************************************************************************
 * @author �³���-�Ŵ� (2017-04-01)
 *  ���SD����FatFSϵͳ��װ���ļ���������,���Թ������SD���ļ�ϵͳ
 *  �ڲ����ļ�����֮ǰ,��������ʹ��ff_SelectSDiskָ��ѡ���ĸ�SD��
 *  ���в��������е��ļ����ƻ��ļ������Ʋ�����const char[] ����
***********************************************************************************************/

#ifdef CASE_FATFS_EJ

#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
#include "include.h"

//#include "bsp.h"
#include "monitor.h"
#include "stm32f2xx.h"
#include "typedef.h"
#include "ff.h"			/* FatFS�ļ�ϵͳģ��*/

//////////////////////////////////////////////////////////////////////////////////////////////

SD_CardInfo SDCardInfo;//ccr2017-06-20

TSDISK fsSDisk[_VOLUMES-FS_SD]={{0}};
TSDISK *fsSDiskP=&fsSDisk[_FS_SD];

char lFileName[_MAX_LFN + 1];//��ų��ļ���

// FRESULT ö���������Ӧ���ַ���
const char *FRESULT_STR[] = {
	"FR_OK",					/* (0) Succeeded */
	"FR_DISK_ERR",				/* (1) A hard error occured in the low level disk I/O layer */
	"FR_INT_ERR",				/* (2) Assertion failed */
	"FR_NOT_READY",				/* (3) The physical drive cannot work */
	"FR_NO_FILE",				/* (4) Could not find the file */
	"FR_NO_PATH",				/* (5) Could not find the path */
	"FR_INVALID_NAME",			/* (6) The path name format is invalid */
	"FR_DENIED",				/* (7) Acces denied due to prohibited access or directory full */
	"FR_EXIST",					/* (8) Acces denied due to prohibited access */
	"FR_INVALID_OBJECT",		/* (9) The file/directory object is invalid */
	"FR_WRITE_PROTECTED",		/* (10) The physical drive is write protected */
	"FR_INVALID_DRIVE",			/* (11) The logical drive number is invalid */
	"FR_NOT_ENABLED",			/* (12) The volume has no work area */
	"FR_NO_FILESYSTEM",			/* (13) There is no valid FAT volume */
	"FR_MKFS_ABORTED",			/* (14) The f_mkfs() aborted due to any parameter error */
	"FR_TIMEOUT",				/* (15) Could not get a grant to access the volume within defined period */
	"FR_LOCKED",				/* (16) The operation is rejected according to the file shareing policy */
	"FR_NOT_ENOUGH_CORE",		/* (17) LFN working buffer could not be allocated */
	"FR_TOO_MANY_OPEN_FILES",	/* (18) Number of open files > _FS_SHARE */
	"FR_INVALID_PARAMETER"		/* (19) Given parameter is invalid */
};
//////////////////////////////////////////////////////////////////////////////////////////////

void print_FatFS(FATFS *fatfs,char prn_space_only);
/**********************************************************************************************************
*	�� �� ��: ff_ListFolder
*	����˵��: ��ʾSD��ָ��Ŀ¼�µ��ļ��л��ļ�(�Ǳ���)
*	��    �Σ���
*	�� �� ֵ: ��
********************************************************************************************************/
void ff_ListFolder(char *path)
{
    /* ������ʹ�õľֲ�����ռ�ý϶࣬���޸������ļ�����֤��ջ�ռ乻�� */
    FRESULT result;
    DIR DirInf;
    FILINFO FileInf;
    uint32_t cnt;

    /* �����ļ�ϵͳ */
    result = ff_MountSDisk(FS_MOUNT);   /* Mount a logical drive */
    if (result != FR_OK)
    {
        print_FResult(path,result);
        return ;
    }

#if defined(TWO_SDCARDS)
    path[0]=fsSDiskP->FS_Myself+'0';
#endif
    cnt=strlen(path)-1;
    if (cnt>0 && path[cnt]=='/') path[cnt]=0;

    /* �򿪸��ļ��� */
    DirInf.fs = fsSDiskP->FatFS;
    result = f_opendir(&DirInf, path); /* ���������������ӵ�ǰĿ¼��ʼ */
    if (result != FR_OK)
    {
//        if (result!=FR_OK)
        {
            if (ApplVar.FS_Current==FS_SD)
                ApplVar.ErrorNumber=ERROR_ID(CWXXI122);
            else
                ApplVar.ErrorNumber=ERROR_ID(CWXXI123);
        }
        print_FResult(path,result);
        return ;
    }

    /* ��ȡ��ǰ�ļ����µ��ļ���Ŀ¼ */
    FileInf.lfname = lFileName;
    FileInf.lfsize = sizeof(lFileName);

    xputs("Attribute|File Size |   Date Time    |Long Name,\r\n");
    for (cnt = 0; ;cnt++)
    {
        result = f_readdir(&DirInf,&FileInf);       /* ��ȡĿ¼��������Զ����� */
        if (result != FR_OK || FileInf.fname[0] == 0)
        {
            break;
        }

        if (FileInf.fname[0] == '.')
        {
            continue;
        }

        /* �ж����ļ�������Ŀ¼ */
        if (FileInf.fattrib & AM_DIR)
        {
            xprintf("  [DIR]  |", FileInf.fattrib);
        } else
        {
            xprintf("  [---]  |", FileInf.fattrib);
        }

        /* ��ӡ�ļ���С, ���4G */
        xprintf("%10d|%4u/%02u/%02u %02u:%02u|", FileInf.fsize,
                                                (FileInf.fdate >> 9) + 1980, FileInf.fdate >> 5 & 15, FileInf.fdate & 31,
                                                FileInf.ftime >> 11, FileInf.ftime >> 5 & 63);
        //xprintf("%12s|", FileInf.fname);	//[> ���ļ��� <]
        if (FileInf.lfname[0]=='\0')
            xprintf("%s\n", (char *)FileInf.fname);	//[> ���ļ��� <]
        else
            xprintf("%s\n", (char *)FileInf.lfname);	//[> ���ļ��� <]
    }

//    print_FatFS(fsSDiskP->FatFS,true);//ccr2017-04-21 testonly

    /* ж���ļ�ϵͳ */
    ff_MountSDisk(FS_RELEASE);
}


/***********************************************************************************************************
 * ��SD���ϴ򿪻򴴽�һ�����ļ�,�ļ��������ݴ���fsSDiskP->File,
 * �ڵ���ff_OpenFileǰ,�������ff_MountSDisk
 * ����Ҫ�򿪵��ļ����ڵ��ļ��в�����ʱ,�ȴ����ļ���
 * �ļ��������д��ķ�ʽ��,���ļ���д��λ���Ƶ�ĩβ
 *
 * @author EutronSoftware (2017-04-11)
 *
 * @param filename �������������ļ��к��ļ�����(1:....)
 *                    filename������Ϊconst����
 *                    filenameָ�����ļ��в�����ʱ�����Զ�����
 * @param mode ���ļ��д򿪷�ʽ(FA_CREATE_NEW,FA_WRITE...)
 * @param pCreate ��=true,�ļ��в�����ʱ����;=false,�������ļ���
 *
 * @return FRESULT
 **********************************************************************************************************/
FRESULT ff_OpenFile(char *filename,BYTE mode)
{
    FRESULT result;
    int i,fnlen=strlen(filename);

#if defined(TWO_SDCARDS)
    filename[0]=fsSDiskP->FS_Myself+'0';
#endif
    XPRINTF(("OpenC file:%s\n",filename));
    if (fnlen<3 || filename[fnlen-1]=='.' || filename[fnlen-1]==':' || filename[fnlen-1]=='/')
    {
        print_FResult(filename,FR_INVALID_NAME);
        return FR_INVALID_NAME;
    }

    //�ļ��в�����ʱ����
    for (i=fnlen-1;i>3;i--)
    {
        if (filename[i]=='/')
            break;
    }
    if (i>3)
    {//�ȴ����ļ���
        filename[i]=0;
        ff_CreateFolders(filename);
        filename[i]='/';
        /* �����ļ�ϵͳ */
        result = ff_MountSDisk(FS_MOUNT);           /* Mount a logical drive */
        if (result != FR_OK)
        {
            print_FResult(filename,result);
            return result;
        }
    }
    /* ���ļ� */
    if ((result=f_open(&fsSDiskP->File, filename, mode))==FR_OK &&  (mode & (FA_CREATE_NEW+FA_CREATE_ALWAYS+FA_WRITE))==FA_WRITE)
        f_lseek(&fsSDiskP->File, fsSDiskP->File.fsize);//��λ�´����ļ�ʱ,����дλ������ĩβ
    if (result!=FR_OK)
    {
        if (ApplVar.FS_Current==FS_SD)
            ApplVar.ErrorNumber=ERROR_ID(CWXXI114);
        else
            ApplVar.ErrorNumber=ERROR_ID(CWXXI115);
        if (result==FR_NO_FILE || result==FR_NO_PATH)//ccr2017-11-17
            ApplVar.ErrorNumber += (ERROR_ID(CWXXI122)-ERROR_ID(CWXXI114));
        print_FResult(filename,result);
    }
    return result;
}
/***********************************************************************************************************
 * ��SD���ϴ��ļ�,Ȼ�����ļ���д�����ݺ�ر��ļ����ļ�������ʱ���Զ�����
 * ff_OpenFileWrite�ٶ���Ҫ�򿪵��ļ����ڵ��ļ��ж�����
 * �ļ��������д��ķ�ʽ��,���ļ���д��λ���Ƶ�ĩβ
 * (д����������ʱ��Լ��ff_WriteFile��25��)
 *
 * @author EutronSoftware (2017-04-11)
 *
 * @param filename �������������ļ��к��ļ�����(1:....)
 *                    filename������Ϊconst����
 *                    filenameָ�����ļ��в�����ʱ�����Զ�����
 * @param data :��Ҫд�������
 * @param length :��Ҫд������ݳ���
 *
 * @return FRESULT
 **********************************************************************************************************/
FRESULT ff_OpenFileWrite(char *filename,BYTE *data,int length)
{
    FRESULT result=FR_OK;
	DWORD bw;

    int i,fnlen=strlen(filename);

#if defined(TWO_SDCARDS)
    filename[0]=fsSDiskP->FS_Myself+'0';
#endif
    if (length)
    {
       XPRINTF(("OpenC & Write:%s\n",filename));

        if (fnlen<3 || filename[fnlen-1]=='.' || filename[fnlen-1]==':' || filename[fnlen-1]=='/')
        {
            print_FResult(filename,FR_INVALID_NAME);
            return FR_INVALID_NAME;
        }
        /* �����ļ�ϵͳ */
        result = ff_MountSDisk(FS_MOUNT);           /* Mount a logical drive */
        if (result != FR_OK)
        {
            print_FResult(filename,result);
            return result;
        }

        /* ���ļ�, ���ļ���д������ */
        if ((result=f_open(&fsSDiskP->File, filename, FA_OPEN_ALWAYS | FA_WRITE))==FR_OK)
        {
            f_lseek(&fsSDiskP->File, fsSDiskP->File.fsize);
            if ((result=f_write(&fsSDiskP->File, data, length, &bw))!=FR_OK)
                print_FResult(filename,result);
            ff_CloseFile();
        }
        if (result!=FR_OK)
        {
            if (ApplVar.FS_Current==FS_SD)
                ApplVar.ErrorNumber=ERROR_ID(CWXXI114);
            else
                ApplVar.ErrorNumber=ERROR_ID(CWXXI115);
            if (result==FR_NO_FILE || result==FR_NO_PATH)//ccr2017-11-17
                ApplVar.ErrorNumber += (ERROR_ID(CWXXI122)-ERROR_ID(CWXXI114));
            print_FResult(filename,result);
        }
        ff_MountSDisk(FS_RELEASE);
    }
    return result;
}

/***********************************************************************************************************
 * ��SD���Ͽ��ٴ��ļ�(������Ҫ�򿪵��ļ�����)
 * �ļ��������ݴ���fsSDiskP->File,�ڵ���ff_OpenFileQǰ,�������ff_MountSDisk
 * ff_OpenFileQ�ٶ���Ҫ�򿪵��ļ��������ڵ��ļ��ж�����ʱ
 * �ļ��������д��ķ�ʽ��,���ļ���д��λ���Ƶ�ĩβ
 *
 * @author EutronSoftware (2017-04-11)
 *
 * @param filename �������������ļ��к��ļ�����(1:....)
 *                   filenameָ�����ļ��в�����ʱ�����Զ�����
 * @param mode ���ļ��д򿪷�ʽ(FA_CREATE_NEW,FA_WRITE...)
 * @return FRESULT
 **********************************************************************************************************/
FRESULT ff_OpenFileQ(char *filename,BYTE mode)
{
    FRESULT result;

    int i,fnlen=strlen(filename);

#if defined(TWO_SDCARDS)
    filename[0]=fsSDiskP->FS_Myself+'0';
#endif
    if (fnlen<3 || filename[fnlen-1]=='.' || filename[fnlen-1]==':' || filename[fnlen-1]=='/')
    {
        print_FResult(filename,FR_INVALID_NAME);
        return FR_INVALID_NAME;
    }
    /* ���ļ� */
    XPRINTF(("OpenQ File:%s\n",filename));

    if ((result=f_open(&fsSDiskP->File, filename, mode))==FR_OK &&  (mode & (FA_CREATE_NEW+FA_CREATE_ALWAYS+FA_READ+FA_WRITE))==FA_WRITE)
        f_lseek(&fsSDiskP->File, fsSDiskP->File.fsize);//��Ϊ�´����ļ�ʱ,����дλ������ĩβ
    if (result!=FR_OK)
    {
        if (ApplVar.FS_Current==FS_SD)
            ApplVar.ErrorNumber=ERROR_ID(CWXXI114);
        else
            ApplVar.ErrorNumber=ERROR_ID(CWXXI115);
        if (result==FR_NO_FILE || result==FR_NO_PATH)//ccr2017-11-17
            ApplVar.ErrorNumber += (ERROR_ID(CWXXI122)-ERROR_ID(CWXXI114));
        print_FResult(filename,result);
    }

    return result;
}
/**********************************************************************************************************
*	�� �� ��: ReadFileData
*	����˵��: ��ȡ�ļ����ݣ�����ӡ������
*	��    �Σ�filename:��Ҫ��ȡ���ݵ��ļ�����
*	�� �� ֵ: ��
**********************************************************************************************************/
void ReadFileData(char *filename)
{

    FRESULT result;
    int32_t bw;
    int i;

    /* �����ļ�ϵͳ */
    result = ff_MountSDisk(FS_MOUNT);           /* Mount a logical drive */
    if (result != FR_OK)
    {
        print_FResult(filename,result);
        return;
    }

    /* ���ļ� */
    result = ff_OpenFileQ(filename, FA_OPEN_EXISTING | FA_READ);
    if (result !=  FR_OK)
    {
        print_FResult(filename,result);
        ff_MountSDisk(FS_RELEASE);
        return;
    }

    /* ��ȡ�ļ� */

    while (!ff_EofFile())
    {
        bw = ff_ReadFile(SDRW_Buffer, sizeof(SDRW_Buffer),FS_BINARY);
        if (bw>=0)
        {
            for (i=0;i<bw;i++)
            {
                xputc(SDRW_Buffer[i]);
            }
        }
        else
        {
            print_FResult(filename,result);
            break;
        }
    }

    /* �ر��ļ�*/
    ff_CloseFile();

    /* ж���ļ�ϵͳ */
    ff_MountSDisk(FS_RELEASE);
}



/**********************************************************************************************************
*	�� �� ��: ff_DeleteFolderFile
*	����˵��: ɾ��SD����ָ���ļ��л��ļ�
*	��    �Σ���
*	�� �� ֵ: ��
**********************************************************************************************************/
FRESULT ff_DeleteFolderFile(char *filename)
{
    /* ������ʹ�õľֲ�����ռ�ý϶࣬���޸������ļ�����֤��ջ�ռ乻�� */
    FRESULT result;

    /* �����ļ�ϵͳ */
    result = ff_MountSDisk(FS_MOUNT);           /* Mount a logical drive */
    if (result != FR_OK)
    {
        print_FResult(filename,result);
        return result;
    }
#if defined(TWO_SDCARDS)
    filename[0]=ApplVar.FS_Current+'0';
#endif
    /* ɾ��Ŀ¼/Dir1 [��Ϊ������Ŀ¼�ǿգ�������Ŀ¼)���������ɾ����ʧ��]*/
    result = f_unlink(filename);
#ifdef XPRINTOUT
    if (result == FR_OK)
    {
        XPRINTF(("(%s) Deleted\r\n",filename));
    } else if (result==FR_NO_FILE || result==FR_NO_PATH)//ccr2017-11-17
    {
        XPRINTF(("(%s) not found\r\n", filename));
    } else
    {
        XPRINTF(("Error= %s when delete %s\r\n", FRESULT_STR[result],filename));
    }
#endif
    /* ж���ļ�ϵͳ */
    ff_MountSDisk(FS_RELEASE);
    return result;
}

/********************************************************************************************
 *	�� �� ��: ff_CreateFolders, ��SD����Ŀ¼�����༶�ļ���
 *
 * @author EutronSoftware (2017-04-05)
 *
 * @param folders :��Ҫ�������ļ���,��ʽ:
 *                '1:/folder1/folder2/folder3' ���ַ���<_MAX_PATH
 *                ����Ϊ'1:/f'
 *                ���δ���:folder1,folder2,folder3
 * @return FRESULT
 *********************************************************************************************/
FRESULT ff_CreateFolders(char *folders)
{
    FRESULT result;
    DIR DirInf;

    char sFolders[_MAX_PATH+1];
    int folderIDX,folderLEN;

#if defined(TWO_SDCARDS)
    folders[0]=ApplVar.FS_Current+'0';
#endif
    for (folderLEN=strlen(folders);folderLEN>1 && sFolders[folderLEN-1]==' ';)
    {//ɾ���ļ�����ĩβ�Ŀո�
        folderLEN--;
        sFolders[folderLEN]=0;
    }

    if (folderLEN<4 || folderLEN>_MAX_PATH)
    {
        XPRINTF(("Folder name error:'%s'.\n", folders));
        return FR_INVALID_PARAMETER;
    }

    /* �����ļ�ϵͳ */
    result = ff_MountSDisk(FS_MOUNT);           /* Mount a logical drive */
    if (result != FR_OK)
    {
        print_FResult(folders,FR_INVALID_PARAMETER);
        return FR_INVALID_PARAMETER;
    }
    strcpy(sFolders,folders);
    if (sFolders[folderLEN-1]=='/')
        sFolders[--folderLEN]=0;   //ɾ�����Ҷ˵�'/'

#if 1
    //���·�ʽ�ȼ���ļ����Ƿ����,Ȼ���ٴ���,����Ч�ʸ�
    for (folderIDX=folderLEN;folderIDX>1 && (result = f_opendir(&DirInf,sFolders))==FR_NO_PATH;)
    {
        for (folderIDX--;folderIDX>1;folderIDX--)
        {
            if (sFolders[folderIDX]=='/')
            {
                sFolders[folderIDX]=0;
                break;
            }
        }
    }

    if (result==FR_OK && folderIDX<folderLEN || result==FR_NO_PATH)
    {
        for (;folderIDX<folderLEN;folderIDX++)
        {
            if (sFolders[folderIDX]==0)
            {
                sFolders[folderIDX]='/';
                /* ����Ŀ¼ */
                result = f_mkdir(sFolders);
                if (result == FR_OK)
                {
                    fsSDiskP->SpaceFree -= FOLDERSIZE;
                    XPRINTF(("Make folder:%s\n",sFolders));
                } else if (result == FR_EXIST)
                {
                    XPRINTF(("'%s' Exist!\n", sFolders));
                } else
                {
                    XPRINTF(("Make folder '%s' Failer.\n", sFolders));
                    if (ApplVar.FS_Current==FS_SD)
                        ApplVar.ErrorNumber=ERROR_ID(CWXXI84);
                    else
                        ApplVar.ErrorNumber=ERROR_ID(CWXXI96);
                    break;
                }
            }
        }
    }
//    else
//     xputs(FRESULT_STR[result]);

#else
    //���´�����ʽÿ���ļ��в������Ƿ���ڶ�����һ��,����Ч�ʵ�
    for (folderIDX=4;folderIDX<=folderLEN;folderIDX++)
    {
        if (sFolders[folderIDX]=='/' || sFolders[folderIDX]==0)
        {
            sFolders[folderIDX]=0;
            /* ����Ŀ¼ */
#ifdef XPRINTOUT
            xprintf("mkdir %s >>>>\n",sFolders);
#endif
            result = f_mkdir(sFolders);
            if (result == FR_OK)
            {
#ifdef XPRINTOUT
                xprintf("mkdir %s Ok\n",sFolders);
#endif
            } else if (result == FR_EXIST)
            {
#ifdef XPRINTOUT
                xprintf("%s Ŀ¼�Ѿ�����\n", sFolders);
#endif
            } else
            {
                if (ApplVar.FS_Current==FS_SD)
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI84);
                else
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI96);
#ifdef XPRINTOUT
                xprintf("mkdir %s ʧ�� \n", sFolders);
#endif
                break;
            }
            sFolders[folderIDX]='/';
        }
    }
#endif
    /* ж���ļ�ϵͳ */
    ff_MountSDisk(FS_RELEASE);
    return result;

}
/**********************************************************************************************
 * ɨ��ָ���ļ����µ��ļ�(�еݹ����,��Ҫ�㹻��ջ)
 * ����ǰ��ʼ��:folder->Files=folder->Folders=folder->FilesSpace=0;
 * @author EutronSoftware (2017-04-05)
 *
 * @param path :�ļ���,��ʽΪ:'1:/folder1/folder2'
 *              path����Ϊ��������,������const����
 *              path�Ĵ�СӦ���㹻�����ļ��к��ļ�����
 *
 * @param folder :���ͳ���ļ���Ŀ���ļ�����Ŀ
 *
 * @return FRESULT
 *********************************************************************************************/
FRESULT ff_ScanFiles (char* path,TSDISK *folder)
{
    FRESULT res;
    FILINFO fno;
    DIR dir;
    int i;

    char *fn;

#if defined(TWO_SDCARDS)
    path[0]=ApplVar.FS_Current+'0';
#endif
#if _USE_LFN
    fno.lfname = lFileName;
    fno.lfsize = sizeof(lFileName);
#endif

    i=strlen(path);
    if (path[i-1]=='/') i--;
    if (i<2 || i>_MAX_PATH)
    {
        xprintf("Folder name error:(%s)\n", path);

        return FR_INVALID_PARAMETER;
    }

    res = f_opendir(&dir, path);
    if (res == FR_OK)
    {
        i = strlen(path);
        for (;;)
        {
            res = f_readdir(&dir, &fno);
            if (res != FR_OK || fno.fname[0] == 0) break;
            if (fno.fname[0] == '.') continue;
#if _USE_LFN
            fn = *fno.lfname ? fno.lfname : fno.fname;
#else
            fn = fno.fname;
#endif
            if (fno.fattrib & AM_DIR)
            {
                folder->Folders++;
                path[i]='/';path[i+1]=0;strcat(path,fn);//ȡ��sprintf(&path[i], "/%s", fn);
                xprintf("[DIR]>%s\n", path);
                res = ff_ScanFiles(path,folder);
                if (res != FR_OK) break;
                path[i] = 0;
            } else
            {
                folder->Files++;
                folder->FilesSpace+=fno.fsize;
                xprintf("     >%s/%s\t%10d\n", path, fn, fno.fsize);

            }
        }
        //xprintf("....>>>%s\n", path);
    }

    return res;
}


/**********************************************************************************************
 * ɾ��Ŀ¼��:ɾ��ָ���ļ����µĸ������ļ��к��ļ�(�еݹ����,��Ҫ�㹻��ջ)
 * ����ff_DeleteTreeǰ,�����ȵ���ff_MountSDisk
 * @author EutronSoftware (2017-04-05)
 *
 * @param path :�ļ���,��ʽΪ:'1:/folder1/folder2'
 *              path����Ϊ��������,������const����
 *              path�Ĵ�СӦ���㹻���������ļ��к��ļ�����
 *
 * @return FRESULT
 *********************************************************************************************/
FRESULT ff_DeleteTree(char* path)
{
    FRESULT res;
    FILINFO fno;
    DIR dir;
    int i;

    char *fn;
#if _USE_LFN
    fno.lfname = lFileName;
    fno.lfsize = sizeof(lFileName);
#endif
#if defined(TWO_SDCARDS)
    path[0]=ApplVar.FS_Current+'0';
#endif
    i=strlen(path);
    if (path[i-1]=='/') i--;
    if (i<2 || i>_MAX_PATH)
    {
        XPRINTF(("Folder Name Error:(%s)\n", path));
        return FR_INVALID_PARAMETER;
    }

    res = f_opendir(&dir, path);
    if (res == FR_OK)
    {
        i = strlen(path);
        for (;;)
        {
            res = f_readdir(&dir, &fno);
            if (res != FR_OK || fno.fname[0] == 0) break;
            if (fno.fname[0] == '.') continue;
#if _USE_LFN
            fn = *fno.lfname ? fno.lfname : fno.fname;
#else
            fn = fno.fname;
#endif
            path[i]='/';path[i+1]=0;strcat(path,fn);//ȡ��sprintf(&path[i], "/%s", fn);
            if (fno.fattrib & AM_DIR)
            {
                res = ff_DeleteTree(path);
                if (res != FR_OK) break;
                path[i] = 0;
            } else
            {
                XPRINTF(("Delete File>>>%s\n", path));
                if ((res = f_unlink(path))==FR_OK)
                    fsSDiskP->SpaceFree += (fno.fsize/1024);
                path[i] = 0;
            }
        }
        XPRINTF(("Delete Folder>%s\n", path));
        if ((res = f_unlink(path))==FR_OK)
            fsSDiskP->SpaceFree += FOLDERSIZE;
    }
    else
    {//����Ϊ�ļ�,ɾ����,���˳���

        XPRINTF(("Delete File>>>%s\n", path));
        res = f_unlink(path);
    }
    return res;
}
/**********************************************************************************************
 * ִ��f_mount,���ڲ�fatFS����fsSDiskP->FatFs,
 *
 * @author EutronSoftware (2017-04-12)
 *
 * @param mount :<_VOLUMES,��mount��ֵ��ApplVar.FS_Current��,ִ��f_mount(*,&fatFS);
 *              =FS_MOUNT,ʹ��ApplVar.FS_Currentִ��f_mount(*,&fatFS);
 *              =FS_RELEASE,ִ��f_mount(*,null);
 *
 * @return FRESULT
 *********************************************************************************************/
FRESULT ff_MountSDisk(BYTE mount)
{
    static FATFS fatFS[_VOLUMES];

    switch (mount)
    {
    default:
        return FR_DISK_ERR;
    case FS_SD:
#if defined(TWO_SDCARDS)
    case FS_SD_2ND:
        ff_SelectSDisk(mount);
    case FS_MOUNT:
#else
    case FS_MOUNT:
        ff_SelectSDisk(FS_SD);
#endif
        if (fsSDiskP==NULL)
        {
            ff_SelectSDisk(ApplVar.FS_Current);
        }
        fsSDiskP->FatFS = &fatFS[ApplVar.FS_Current];
        return f_mount(ApplVar.FS_Current,&fatFS[ApplVar.FS_Current]);
    case FS_RELEASE:
        if (fsSDiskP==NULL)
        {
            ff_SelectSDisk(ApplVar.FS_Current);
        }
        fsSDiskP->FatFS = NULL;
        return f_mount(ApplVar.FS_Current,NULL);
    }

}
/***********************************************************************************************
 * ִ��f_mount����㵱ǰSD���Ŀռ�(��λ:KB),��˴˺���������f_mount֮�����
 *
 * @author EutronSoftware (2017-04-12)
 *
 * @return DWORD :����ʣ��ռ�
 **********************************************************************************************/
DWORD ff_SDiskSpace()
{
    DWORD free_clust;
    char driver[5];

#if 1 //ouhs test 

		ApplVar.EJSpaceSize[_FS_SD]=4000000;
		ApplVar.EJSpaceFree[_FS_SD]=3000000;

		ApplVar.EJSpaceSize[_FS_SD_2ND]=4000000;
		ApplVar.EJSpaceFree[_FS_SD_2ND]=3000000;

		return 3000000;
#endif
	
    if (fsSDiskP==NULL)
        ff_SelectSDisk(ApplVar.FS_Current);

    if (fsSDiskP->FatFS)
    {
        sprintf(driver,"%d:/",fsSDiskP->FS_Myself);
        free_clust=fsSDiskP->FatFS->free_clust;
        if ((free_clust && free_clust<=fsSDiskP->FatFS->n_fatent) || f_getfree(driver, &free_clust, &fsSDiskP->FatFS)==FR_OK)
        {
            /* Get total sectors and free sectors */
            fsSDiskP->SpaceTotal = (fsSDiskP->FatFS->n_fatent - 2) * fsSDiskP->FatFS->csize / 2;
            /* Free space in unit of KB (assuming 512B/sector) */
            fsSDiskP->SpaceFree = free_clust * fsSDiskP->FatFS->csize / 2;
        }
#if defined(TWO_SDCARDS)
        else if (ApplVar.FS_Current==FS_SD_2ND)
            ApplVar.ErrorNumber=ERROR_ID(CWXXI96);
#endif
        else
            ApplVar.ErrorNumber=ERROR_ID(CWXXI84);
    }
    else
    {
        fsSDiskP->SpaceTotal = 0;
        fsSDiskP->SpaceFree = 0;
    }
#if defined(TWO_SDCARDS)
    if (fsSDiskP->FS_Myself==FS_SD_2ND)
    {//Ϊ���ⲿSD��(�ɰγ�SD��)
        ApplVar.EJSpaceSize[_FS_SD_2ND]=fsSDiskP->SpaceTotal;
        ApplVar.EJSpaceFree[_FS_SD_2ND]=fsSDiskP->SpaceFree;
    }
    else
#endif
    {
        ApplVar.EJSpaceSize[_FS_SD]=fsSDiskP->SpaceTotal;
        ApplVar.EJSpaceFree[_FS_SD]=fsSDiskP->SpaceFree;
    }
    return fsSDiskP->SpaceFree;
}

/***********************************************************************************************
 * ��򿪵��ļ���д������,����ff_WriteFileǰ,�����ȵ���ff_MountSDisk
 *
 * @author EutronSoftware (2017-04-12)
 *
 * @param data :��Ҫд�������
 * @param length :��Ҫд������ݳ���
 *
 * @return int :����ʵ��д������ݳ���
 **********************************************************************************************/
int ff_WriteFile(BYTE *data,int length)
{
    DWORD bw;
    FRESULT result;

    if (length && fsSDiskP->File.fs)//�ļ�������
    {
        if ((result=f_write(&fsSDiskP->File, data, length, &bw))==FR_OK)
        {
            return bw;
        }
        else
        {
            if (ApplVar.FS_Current==FS_SD)
                ApplVar.ErrorNumber=ERROR_ID(CWXXI114);
            else
                ApplVar.ErrorNumber=ERROR_ID(CWXXI115);
            print_FResult("ff_WriteFile",result);
        }
    }

    return 0;
}

/***********************************************************************************************
 * �رմ򿪵��ļ�
 *
 * @author EutronSoftware (2017-04-12)
 **********************************************************************************************/
void ff_CloseFile()
{
    if (fsSDiskP->File.fs)//�ļ�������
    {
        f_close(&fsSDiskP->File);
    }
}

/************************************************************************************************
 * �Ӵ򿪵��ļ��ж�ȡ����,����ff_ReadFileǰ,�����ȵ���ff_MountSDisk
 *
 * @author EutronSoftware (2017-04-12)
 *
 * @param data :�����洢��ȡ������
 * @param length :��Ҫ��ȡ�����ݳ���
 * @param mode :=FS_BINARY,��ȡ������;=FS_TEXT,��f_gets��ʽ��ȡ����
 *
 * @return int :>=0,���ض�ȡ�����ݳ���;=-1,����
 ***********************************************************************************************/
int ff_ReadFile(BYTE *data,int length,BYTE mode)
{
    DWORD bw;
    FRESULT result;

    if (fsSDiskP->File.fs)//�ļ�������
    {
        switch (mode)
        {
        case FS_BINARY:
            if ((result = f_read(&fsSDiskP->File, data, length, &bw))==FR_OK)
                return bw;
            else
            {
                if (ApplVar.FS_Current==FS_SD)
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI114);
                else
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI115);
                print_FResult("ff_ReadFile",result);
            }
            break;
        case FS_TEXT:
            if (f_gets(data,length,&fsSDiskP->File))
            {
                return strlen(data);
            }
            break;
        }
    }
    return -1;

}
/***********************************************************************************************
 * �ж��Ƿ��ļ�ĩβ
 *
 * @author EutronSoftware (2017-04-12)
 * @return int :true,���ļ�ĩβ;
 ***********************************************************************************************/
int ff_EofFile()
{
    if (fsSDiskP->File.fs)//�ļ�������
    {
        return f_eof(&fsSDiskP->File);
    }
    return true;
}

/***********************************************************************************************
 * ѡ��SD��(FS_USB,FS_SD)
 *
 * @author EutronSoftware (2017-04-12)
 *
 * @param sd_Disk:FS_USB,FS_SD
 **********************************************************************************************/
void ff_SelectSDisk(BYTE sd_Disk)
{
    if (sd_Disk<_VOLUMES)
    {
        ApplVar.FS_Current=sd_Disk;
        fsSDiskP=&fsSDisk[ApplVar.FS_Current-FS_SD];
        fsSDiskP->FS_Myself=ApplVar.FS_Current;//
    }
}
/***********************************************************************************************
 * ���ļ�����������,���ļ������ھ��ļ����ļ�����,���ò����ĸ�ʽ:
 * ("1:/folder1/fileFrom.txt","fileTo.txt")
 * @author EutronSoftware (2017-04-14)
 *
 * @param fileFr:�ļ�������,����·��
 * @param fileTo:������,���ɰ���·��
 *
 * @return FRESULT
 **********************************************************************************************/
FRESULT ff_RenameFile(char *fileFr,char *fileTo)
{
    int i,j;
    char sNewFN[_MAX_PATH];
    FRESULT result;

#if defined(TWO_SDCARDS)
    fileFr[0]=ApplVar.FS_Current+'0';
#endif
    strcpy(sNewFN,fileFr);
    i = strlen(sNewFN);

    for (j=i-1;j>0;j--)
    {
        if (sNewFN[j]=='/')
        {
            sNewFN[++j]=0;
            j++;
            break;
        }
    }
    if  (j+strlen(fileTo)<_MAX_PATH || fileTo[1]!=':')
    {
        if (j)
            strcat(sNewFN,fileTo);
        else
            strcpy(sNewFN,fileTo);

        j=(sNewFN[1]==':')?2:0;
        ff_MountSDisk(FS_MOUNT);
        result =f_rename(fileFr,sNewFN+j);
        ff_MountSDisk(FS_RELEASE);
        if (result!=FR_OK)
        {
            if (ApplVar.FS_Current==FS_SD)
                ApplVar.ErrorNumber=ERROR_ID(CWXXI114);
            else
                ApplVar.ErrorNumber=ERROR_ID(CWXXI115);
            if (result==FR_NO_FILE || result==FR_NO_PATH)//ccr2017-11-17
                ApplVar.ErrorNumber += (ERROR_ID(CWXXI122)-ERROR_ID(CWXXI114));
            print_FResult(sNewFN,result);
        }
        return result;
    }
    else
        return FR_INVALID_NAME;
}

/********************************************************************************************
 *	�� �� ��: ff_OpenFolder, ���SD����Ŀ¼�µ��ļ����Ƿ����(�����Զ�����)
 *
 * @author EutronSoftware (2017-04-05)
 *
 * @param folders :��Ҫ�����ļ���,��ʽ:
 *                '1:/folder1/folder2/folder3' ���ַ���<_MAX_PATH
 *                ����Ϊ'1:/f'
 * @return FRESULT
 *********************************************************************************************/
FRESULT ff_OpenFolder(char *folders)
{
    FRESULT result;
    DIR DirInf;

    char sFolders[_MAX_PATH+1];
    int folderIDX,folderLEN;

#if defined(TWO_SDCARDS)
    folders[0]=ApplVar.FS_Current+'0';
#endif
    folderLEN=strlen(folders);
    if (folderLEN<4 || folderLEN>_MAX_PATH)
    {

        XPRINTF(("Folder name error:'%s'.\n", folders));
        return FR_INVALID_PARAMETER;
    }

    /* �����ļ�ϵͳ */
    result = ff_MountSDisk(FS_MOUNT);           /* Mount a logical drive */
    if (result != FR_OK)
    {
        print_FResult(folders,FR_INVALID_PARAMETER);
        return FR_INVALID_PARAMETER;
    }
    strcpy(sFolders,folders);
    if (sFolders[folderLEN-1]=='/')
        sFolders[--folderLEN]=0;   //ɾ�����Ҷ˵�'/'


    //���·�ʽ�ȼ���ļ����Ƿ����,Ȼ���ٴ���,����Ч�ʸ�
    result =f_opendir(&DirInf,sFolders);
//ccr2017-11-16(���뱨��)    if (result!=FR_OK)
//ccr2017-11-16    {
//ccr2017-11-16        if (ApplVar.FS_Current==FS_SD)
//ccr2017-11-16            ApplVar.ErrorNumber=ERROR_ID(CWXXI122);
//ccr2017-11-16        else
//ccr2017-11-16            ApplVar.ErrorNumber=ERROR_ID(CWXXI123);
//ccr2017-11-16        print_FResult(filename,result);
//ccr2017-11-16    }

    /* ж���ļ�ϵͳ */
    ff_MountSDisk(FS_RELEASE);
    return result;
}

/***********************************************************************************************************
 * ��ȡ���ļ����ļ�����
 *
 * @author EutronSoftware (2017-10-25)
 *
 * @return int
 **********************************************************************************************************/
int ff_FileSize()
{
    return fsSDiskP->File.fsize;
}

/////////////////////////////////////////////////////////////////////////////////////////////////
char ConsoleLine[256];
/**********************************************************************************************
 * ��ʾSD�ļ����ܲ������
 *
 * @author EutronSoftware (2017-04-11)
 *
 * @param result
 *********************************************************************************************/
#if (XPRINTOUT)
void print_FResult(char *filename,FRESULT result)
{
   if (filename)
   {
       xputs(filename);xputc('>');
   }
   if (result>=0)
      xputs(FRESULT_STR[result]);
   xputc('\n');
}
#endif

/***********************************************************************************************
 * ��ʾ��ǰ����ʱ��,С������������Ϊ�����ʱ��
 *
 * @author EutronSoftware (2017-04-14)
 *
 * @param t :=0,�������ʱ����0
 *           =1,��ʾ�����ʱʱ��
 **********************************************************************************************/
void DisplayTime(BYTE t)
{
    static DWORD sDelayFr=0;
    DWORD delay=0;
    RTCTime rtc;

    RTC_GetDateTime(&rtc);
    if (t==0)
    {
        delay=0;
        sDelayFr=GetSystemTimer();
    }
    else
    {
        delay=GetSystemTimer()-sDelayFr;
        sDelayFr=0;
    }

    XPRINTF(("%u/%u/%u %02u:%02u:%02u.%lu\n", rtc.year, rtc.mon, rtc.mday, rtc.hour, rtc.min, rtc.sec,delay));

}
/**********************************************************************************************
 * ���f_mountִ�к�fatfs��ֵ,��˴˺���������f_mount֮�����
 *
 * @author EutronSoftware (2017-04-11)
 *
 * @param fatfs :FAT����
 * @param prn_space_only :ֻ��ʾ���̿ռ�����
 *********************************************************************************************/
void print_FatFS(FATFS *fatfs,char prn_space_only)
{
    if (!prn_space_only)
    {

        xprintf("******Result after f_mount******\n");
        xprintf("fatfs->fs_type = %u\n", fatfs->fs_type);
        xprintf("fatfs->drv = %u\n", fatfs->drv);
        xprintf("fatfs->csize = %u\n", fatfs->csize);
        xprintf("fatfs->n_fats = %u\n", fatfs->n_fats);
        xprintf("fatfs->wflag = %u\n", fatfs->wflag);
        xprintf("fatfs->id = %u\n", fatfs->id);
        xprintf("fatfs->n_rootdir = %u\n", fatfs->n_rootdir);
#if _MAX_SS != 512
        xprintf("fatfs->ssize = %u\n", fatfs->ssize);
#endif
        xprintf("fatfs->last_clust = %lu\n", fatfs->last_clust);
        xprintf("fatfs->free_clust = %lu\n", fatfs->free_clust);
        xprintf("fatfs->fsi_sector = %lu\n", fatfs->fsi_sector);
        xprintf("fatfs->n_fatent = %lu\n", fatfs->n_fatent);
        xprintf("fatfs->fsize = %lu\n", fatfs->fsize);
        xprintf("fatfs->fatbase = %lu\n", fatfs->fatbase);
        xprintf("fatfs->dirbase = %lu\n", fatfs->dirbase);
        xprintf("fatfs->database = %lu\n", fatfs->database);
        xprintf("fatfs->winsect = %lu\n", fatfs->winsect);
        xprintf("fatfs->win[%d]:\n", _MAX_SS);
    }
    /* Get total sectors and free sectors */
    ff_SDiskSpace();
    if (ApplVar.ErrorNumber)
        xprintf("\nSD CARD ERROR = %d\n",ApplVar.ErrorNumber);// fsSDiskP->SpaceTotal,fsSDiskP->SpaceFree);
    else
    /* Print free space in unit of KB (assuming 512B/sector) */
       xprintf("\n%lu KB total drive space.\n%lu KB available.\n",ApplVar.EJSpaceSize[ApplVar.FS_Current-1],
                                                                  ApplVar.EJSpaceFree[ApplVar.FS_Current-1]);// fsSDiskP->SpaceTotal,fsSDiskP->SpaceFree);

}

/*
*********************************************************************************************************
*	�� �� ��: DispMenu
*	����˵��: ��ʾ������ʾ�˵�
*	��    �Σ���
*	�� �� ֵ: ��
*********************************************************************************************************
*/
void DispSDiskMenu(void)
{
    FRESULT res;

    xputs("\n------------------------------------------------\n");
    xputs("Command list:\n");
    //xputs("f - ��ʽ��SD��\n");
    xputs("vI:/folder1/folder2 - Display files on folder2\n");
    xputs("sI:/folder1/folder2/folder3 - Display trees of the folder3\n");
    xputs("rI:/folder1/folder2/Data.dat - Read data from file Data.dat\n");
    xputs("f[E/I]S/F -S:Get size of SD\n");
    xputs("           E:Select SD-E\n");
    xputs("           I:Select SD-I\n");
    xputs("           F:About FAT\n");
#if (CC_DEBUG)
    xputs("d1:/folder1/folder2/folder3 - �����ļ���\n");
    xputs("c1:/folder1/folder2/file - ��folder2�´����ļ�file\n");
    xputs("w1:/folder1/folder2/file data - ���ļ�file��д������\n");
    xputs("W1:/folder1/folder2/file a/s/..- ��cache��ʽ���ļ�file��д��һ������\n");
    xputs("        a/s/\n");
    xputs("Wr/e/f -  r:Reset Cache,e:end of Cache, f:Flush cache\n");

    xputs("n1:/folder1/folder2/file 1:/folder1/folder2/file1 - �ļ�����\n");
    xputs("m1:/folder1/folder2/file - ɾ��ָ���ļ��л��ļ�file\n");
    xputs("M1:/folder1/folder2/file - ɾ��Ŀ¼�����ļ�file\n");
    xputs("k10 - ɾ��ָ������ǰ��Z����\n");
#endif
    xputs("z1 5 - ��ȡ1��5��Z��������;�޲���ʱ,����FM����\n");
    xputs("pA string - ��ӡ�ַ���'A string'\n");
    xputs("Q - �˳�\n");
    xputs("------------------------------------------------\n");
}
/**********************************************************************************************************
*	�� �� ��: FatFSFunctionsDemo
*	����˵��: FatFS�ļ�ϵͳ��ʾ������,ͨ������'EJ'�������
*	��    �Σ���
*	�� �� ֵ: ��
**********************************************************************************************************/
extern void Check_FiscalData();

void FatFSFunctionsDemo(void)
{

    long p1,p2,p3,p4;
    char *ptr,ch;
    int i,j,l;
    FRESULT result;

    ff_SelectSDisk(FS_SD);

    DispSDiskMenu();/* ��ӡ�����б����û�����ͨ�����ڲ���ָ�� */

    while (1)
    {
        xputc('\n');xputc('>');
        ptr = ConsoleLine;
        ConsoleLine[0]=0;
        i = get_line(ptr, sizeof(ConsoleLine));

        if (i)  /* �Ӵ��ڶ���һ���ַ�(��������ʽ),i=��������ݳ��� */
        {
            xputc('\n');

            ch=*ptr++;i--;
            for (j=0;j<i;j++)
            {//�߳�����Ͳ���֮��Ŀո�
                if (*ptr==' ')
                {
                    ptr++;
                    i--;
                }
            }
            for (j=0;j<i;j++)
            {//���ҵڶ����������ݵĿ�ʼλ��
                if (ptr[j]==' ')
                {
                    ptr[j++]=0;
                    break;
                }
            }
            //ptrָ�������ĵ�һ������,ptr+jָ��ڶ�������
            switch (ch)
            {
            case 'Q':
                EmptyComm(COMPUTER_1);
                ff_SelectSDisk(FS_SD);
                return;
            case 'p':
                RJPrint(0,ptr);
                break;
            case 'z'://��ȡ1��5��Z������
                p1=p2=0;
                if (i)
                {
                   xatoi(&ptr, &p1);
                   if (j)
                   {
                      ptr++;//skip \0
                      xatoi(&ptr, &p2);
                   }
                }

#if (CC_DEBUG)
                if (p1==0 && p2==0)
                {
                   xputs("[Check FM DATA]\n");
                   Check_FiscalData();
                }
                else
#endif
                {
                   xprintf("[Read Z-Report from %d to %d]\n",p1,p2);
                   LogDefine.RecNumFr=p1;
                   LogDefine.RecNumTo=p2;
                   Read_FiscalData(PRINTFMZ_Z + BIT6,FISCLEARLOG);
                }
                break;
#if (CC_DEBUG)
            case 'k'://ɾ��ָ������ǰ��Z����
                xatoi(&ptr, &p1);
                xprintf("[Delete Z-Report befor %d days]\n",p1);
                DeleteSDBefor60Days(p1);
                break;
            case 'n'://n1:/folder1/folder2/fileOLD fileNEW�ļ�����
                ptr[0]=ApplVar.FS_Current+'0';//ccr2017-06-15
                xprintf("[Rename file from %s to %s]\n",ptr,ptr+j);
                if (strlen(ptr)>7 && ptr[1]==':')
                {
                    if (j<i)
                        print_FResult(ptr+j, ff_RenameFile(ptr,ptr+j));
                    else
                        xputs("Error on file name!");
                }
                break;
            case 'r': //rI:/folder1/folder2/Data.dat ���ļ�����ʾ�ļ��е�����
                ptr[0]=ApplVar.FS_Current+'0';//ccr2017-06-15
                if (strlen(ptr)>4 && ptr[1]==':')
                    ReadFileData(ptr);
                break;
            case 'd'://d1:/folder1/folder2/folder3 - �����ļ���
                ptr[0]=ApplVar.FS_Current+'0';//ccr2017-06-15
                xprintf("[Create Folder:%s]\n",ptr);
                DisplayTime(0);
                if (strlen(ptr)>4)
                    ff_CreateFolders(ptr);
                DisplayTime(1);
                break;
            case 'M'://M1:/folder1/folder2/file - ɾ��Ŀ¼�����ļ�file
                if (ff_MountSDisk(FS_MOUNT)==FR_OK)
                {
                    ff_SDiskSpace();
                    xprintf("Size of SD-%d:%lu Free:%lu\n",ApplVar.FS_Current,fsSDisk[ApplVar.FS_Current-FS_SD].SpaceTotal,fsSDisk[ApplVar.FS_Current-FS_SD].SpaceFree);

                    ptr[0]=ApplVar.FS_Current+'0';//ccr2017-06-15
                    if (!ptr[1])
                    {
                        ptr[1]=':';  ptr[2]='/';ptr[3]=0;
                    }
                    xprintf("[Delete TREE:%s]\n",ptr);
                    ff_DeleteTree(ptr);
                    ff_SDiskSpace();
                    xprintf("Size of SD-%d:%lu Free:%lu\n",ApplVar.FS_Current,fsSDisk[ApplVar.FS_Current-FS_SD].SpaceTotal,fsSDisk[ApplVar.FS_Current-FS_SD].SpaceFree);
                }
                ff_MountSDisk(FS_RELEASE);
                break;
            case 'c'://c1:/folder1/folder2/file - ��folder2�´����ļ�file
                ptr[0]=ApplVar.FS_Current+'0';//ccr2017-06-15
                xprintf("[OpenFile:%s]\n",ptr);
                if (strlen(ptr)>4 && ptr[1]==':')
                {
                    if  ((result=ff_MountSDisk(FS_MOUNT))==FR_OK)
                    {
                        if ((result=ff_OpenFileQ(ptr,FA_OPEN_ALWAYS | FA_WRITE))==FR_OK)  /* ����һ�����ļ� */
                        {
                            p1=0;
                            DisplayTime(0);
                            if (j<i && j>1)
                            {
                                ptr[i++]='\n';
                                ptr[j]='c';
                                for (l=0;l<100;l++)
                                {
                                    if (ff_WriteFile(ptr+j,i-j)!=i-j)
                                    {
                                        xputs("Error when Write!\r\n");
                                        break;
                                    }
                                    p1+=(i-j);
                                }
                            }
                            else
                            {
                                xputs("Wait data for write,[0d] for end\r\n");
                                while (true)
                                {
                                    i = get_line(ConsoleLine, sizeof(ConsoleLine));
                                    if (i)
                                    {
                                        /* дһ������ */
                                        ConsoleLine[i++]='\n';
                                        if (ff_WriteFile(ConsoleLine,i)!=i)
                                        {
                                            xputs("Error when Write!\r\n");
                                            break;
                                        }
                                        p1+=i;
                                    }
                                    else
                                    {
                                        xputs("Write Finished!\r\n");
                                        break;
                                    }
                                }
                            }
                            DisplayTime(1);
                            fsSDiskP->SpaceFree-=(p1/1024);
                            /* �ر��ļ�*/
                            f_close(&fsSDiskP->File);
                        }
                        else
                        {
                            xputs("Create file ERROR:\r\n");
                            print_FResult(ptr,result);
                        }
                        /* ж���ļ�ϵͳ */
                        ff_MountSDisk(FS_RELEASE);
                    }
                    else
                        print_FResult("ff_MountSDisk",result);
                }
                break;
            case 'w'://w1:/folder1/folder2/file data - ���ļ�file��д������
                if (j<i && j>1 && strlen(ptr)>6 && ptr[1]==':')
                {
                    ptr[0]=ApplVar.FS_Current+'0';//ccr2017-06-15
                    ptr[i++]='\n';
                    ptr[j]='w';
                    xprintf("[Open File and Write 100 lines:%s]\n",ptr+j);

                    DisplayTime(0);
                    for (l=0;l<100;l++)
                    {
                        (ff_OpenFileWrite(ptr,ptr+j,i-j));
                    }
                    DisplayTime(1);
                }
                break;
            case 'W'://w1:/folder1/folder2/file - ���ļ�file��д������
                ch=*ptr;
                if (ch=='r')
                    SDCacheReset('R');
                else if (ch=='e')
                    SDCachePushEnd();
                else if (ch=='f')
                {
                    DisplayTime(0);
                    SDCacheFlushData(true);
                    DisplayTime(1);
                }
                else if (j<i && j>1 && strlen(ptr)>6 && ptr[1]==':')
                {
                    CheckTime(true);
                    if (!ApplVar.SDCache.Type)
                        SDCacheReset('R');
                    ptr[0]=ApplVar.FS_Current+'0';//ccr2017-06-15
                    ch=ptr[j];
                    SDCachePushFileName(ch,ptr);
                    xprintf("[Write 50 lines to:%s]\n",ptr);

                    DisplayTime(0);
                    for (l=0;l<50;l++)
                    {
                        sprintf(ptr,"%d>Data of wrtie to file\n",l);
                        SDCachePushData(TimeAsci,8);xputs(TimeAsci);
                        SDCachePushData(ptr,strlen(ptr));xputs(ptr);
                    }
                    DisplayTime(1);
                }
                break;
            case 'm'://m1:/folder1/folder2/file - ɾ��ָ���ļ��л��ļ�file
                xprintf("[Delete Folder or File:%s]",ptr);
                if (ptr[1]==':' && (strlen(ptr)>4))
                {
                    ptr[0]=ApplVar.FS_Current+'0';//ccr2017-06-15
                    ff_DeleteFolderFile(ptr);    /* ɾ��Ŀ¼���ļ� */
                }
                break;
#endif
            case 's'://sI:/folder1/folder2/folder3 - Display trees of the folder3
                if (ff_MountSDisk(FS_MOUNT)==FR_OK)
                {
                    ptr[0]=ApplVar.FS_Current+'0';//ccr2017-06-15
                    if (!ptr[1])
                    {
                        ptr[1]=':';  ptr[2]='/';ptr[3]=0;
                    }
                    xprintf("[Scan Folder:%s]\n",ptr);
                    if (ptr[1]==':')//(strlen(ptr)>4)
                    {
                        fsSDiskP->Files=fsSDiskP->Folders=fsSDiskP->FilesSpace=0;
                        ff_ScanFiles(ptr,fsSDiskP);
                        xprintf("Folders:%d\t  Files:%d\t FilesSpace:%lu\n",fsSDiskP->Folders,fsSDiskP->Files,fsSDiskP->FilesSpace);
                    }
                }
                ff_MountSDisk(FS_RELEASE);
                break;
            case 'f'://fS/E/I/F - S:Get size of SD E:Select SD-E  I:Select SD-I  F:About FAT
                ch=0;
                if  (*ptr=='E' || *ptr==0)
                {
                    ff_SelectSDisk(FS_SD);
                    xprintf("[Select SD-External(%d)]",ApplVar.FS_Current);
                    ptr++;
                    ch=FS_SD;
                }
#if defined(TWO_SDCARDS)
                else if  (*ptr=='I')
                {
                    ff_SelectSDisk(FS_SD_2ND);
                    xprintf("[Select SD-Internal(%d)]",ApplVar.FS_Current);
                    ptr++;
                    ch=FS_SD_2ND;
                }
#endif
                if  (*ptr=='S')
                {
                    ApplVar.ErrorNumber=0;
                    xputs("[Get size of SD-I & SD-E]");
                    DisplayTime(0);
                    GetMMCSize(ch);
                    if (!ApplVar.ErrorNumber)
                    {
#if defined(TWO_SDCARDS)
                       if (ch==0 || ch==FS_SD_2ND)
                          xprintf("Size of SD-I:%lu Free:%lu\n",fsSDisk[_FS_SD_2ND].SpaceTotal,fsSDisk[_FS_SD_2ND].SpaceFree);
#endif
                       if (ch==0 || ch==FS_SD)
                          xprintf("Size of SD-E:%lu Free:%lu\n",fsSDisk[_FS_SD].SpaceTotal,fsSDisk[_FS_SD].SpaceFree);
                    }
                    else
                        xprintf("Error:%d-%s\n",ApplVar.ErrorNumber,Msg[ApplVar.ErrorNumber+CWXXI01-1].str);
                    DisplayTime(1);
                }
                else if  (*ptr=='F')
                {
#if defined(TWO_SDCARDS)
                   if (ch==0 || ch==FS_SD_2ND)
                   {
                       result = ff_MountSDisk(FS_SD_2ND);   /* Mount a logical drive */
                       if (result==FR_OK)
                            print_FatFS(fsSDiskP->FatFS,false);
                       else
                           print_FResult("ff_MountSDisk",result);
                       result = ff_MountSDisk(FS_RELEASE);   /* Mount a logical drive */
                   }
#endif
                   if (ch==0 || ch==FS_SD)
                   {
                        result = ff_MountSDisk(FS_SD);   /* Mount a logical drive */
                      	if (result==FR_OK)
                               print_FatFS(fsSDiskP->FatFS,false);
                      	else
                      		print_FResult("ff_MountSDisk",result);
                      	result = ff_MountSDisk(FS_RELEASE);   /* Mount a logical drive */
                   }
                    /*
                    if ((result=ff_MountSDisk(FS_MOUNT))==FR_OK)
                    {
                        xprintf("[Format Current:%d]\n",ApplVar.FS_Current);
                        DisplayTime(0);
                        if ((result=f_mkfs(ApplVar.FS_Current,0,_MAX_SS))!=FR_OK)
                            print_FResult(filename,result);
                        DisplayTime(1);
                        PutsLine0("Exit From Format!");
                    } else
                        print_FResult(filename,result);

                    ff_MountSDisk(FS_RELEASE);
                 */
                }
                break;
            case 'v'://vI:/folder1/folder2 - Display files on folder2
                xprintf("[List of current Folder:%d]\n",ApplVar.FS_Current);
                ptr[0]=ApplVar.FS_Current+'0';//ccr2017-06-15
                if (!ptr[1])
                {
                     ptr[1]=':';  ptr[2]='/';ptr[3]=0;
                }
                ff_ListFolder(ptr);      /* ��ʾSD����Ŀ¼�µ��ļ��� */
                break;
            case '?':
            default:
                DispSDiskMenu();
                break;
            }
        }
    }
}


#endif