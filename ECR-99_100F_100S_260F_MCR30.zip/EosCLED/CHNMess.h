//---------------------------------------------------------------------------
#ifndef CHNMESS
#define CHNMESS

#include "bios_dir.h"

#define MSG(id)     Msg[id].str

#define  SETUPMG  0xf000  //Ϊ����ģʽִ��һЩSETUP����.

//for Msg[]>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
typedef enum {
        SPACE,//0
//----------------setup index definitions------------------------
        SETDEPT,//1     /* 1 dept ���뱣��Ϊ1 */
        SETPLU,       	  /* 2 plu */
        SETPLUSTOCK,   	  /* 2 plu */
        SETTAX,       	   /* 3 tax */
        SETHEAD,       	 /* 4 program header */
        SETDISC,       	//(SETHEAD+1)  /* 5 disc */
        SETSYSFLAG,         /* 7 system flags */
        SETGROUP,       	/* 15 Group */
        SETKEYB,       /* 26 keyboard code and manager */
        SETDATE,       /* 12  */
        SETTIME,       /* 13  */
        SETGRAP,       	 	// 14
        SETPERIPHERALS, //ccr2017-08-04
#if (DD_CHIPC)
        SETIC,       	 	// 17
#endif
#if (DD_PROMOTION)
        SETPROM,       	 	// 18
#endif
#if (DD_FISPRINTER==0 && DD_DISABLEPBF==0)
        SETPBF,       /* 19 pb functions */
        SETPBINF,        	/* 23 keyswitch disable */
#endif
        SETCLERK,       	/* 21 clerk */
#if (DD_SETREPORT)
        SETREPTYPE,       	/* 27 report types */
        SETREPORT,        	// 28
#endif
#if offNumber
        SETOFF,       	 	// 29
#endif
        SETTRAIL,        	// 32
#if (DD_SETSLIP)
        SETSP,       	 	// 33
        SETSHEAD,        	/* 34 slip header */
#endif
#if (DD_CHIPC)
        SETBLOCKIC,       	/* 35 icblock*/  	//ccr chipcard 2004-07-01
#endif
        SETNETWORK,       	 	/* 36 ����ip��ַ */
#if defined(CASE_GPRS)
        SETGPRSFUNC,       	/* 37 GPRS����*/
#endif
#if defined(CASE_ETHERNET)
        SETETHERNETFUNC,        /* 38 ����ͨ�Ź���*/
#endif

        SETAUXFUNCS,       	//39//ccr2017-05-10 ��������
        SETUPITEM1ST=SETDEPT,
        SETUPMAX=SETAUXFUNCS,

//ccr2017-05-12>>�����������Ϊ�������,�������ù���,���ǲ������ò˵��г���,���Msg[]���޶�Ӧ����Ϣ>>>>>>>>
        //ccr2017-07-24>>ϣ����Ҫȡ��������>>>>>>>
        SETSALER,        /* 6 keyswitch disable */
        SETCURR,       	 /* 8 Curr */
        SETPORT3,        	// 11
        SETTEND,       /* 16 tend */
        SETMODIF,       	/* 22 modifiers */
        SETCORR,       /* 24 correc */
        SETZONES,       	/* 25 zones */
        SETPORA,       /* 30 pora */
        SETDRAWER,       	/* 31 drawer */
        //ccr2017-07-24<<<<<<<<<<<<<<<<<<<<<<<<<<<
        SETFIXCAP,       	/* fixed captions */
        SETERRMSG,       	/* system & error message */
        SETWEEKCAP,       	/* day of week captions */
        SETMONTHCAP,       	/* month captions */
        SETKEYMASK,       	//ccr2017-05-19 ����Ϊ���һ��������Ŀ /* keyswitch disable */
//ccr chipcard>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#if (DD_CHIPC)
        MGSETUPIC,
        SETCLEARIC=MGSETUPIC,
        SETINITIC,
        SETCHARGIC,
        SETCHIPPOINT,
#endif
        SETECRMODE,       //ѡ���տ��ģʽ�˵�
        SETPROGRAM,       	//ѡ���տ�������ļ��˵�
//ccr2017-05-12<<<<<<<<<<<<<<<<<<<<end of setup index definitions---------------------
        CWXXI01 =(SETUPMAX+1),                    	//="��Ч����!"
        CWXXI02,         	//="��Ч����!"
        CWXXI03,         	//="��Чʱ��!"
        CWXXI04,         	//="��ֹ����!"
        CWXXI05,         	//="PLU����Ϊ��!"
        CWXXI06,         	//="PLU�ļ����!"
        CWXXI07,         	//="��̨��ռ��!"
        CWXXI08,         	//="��̨�Ѵ�!"
        CWXXI09,         	//="��̨�Ų���!"
        CWXXI10,         	//="��������̨��"
        CWXXI11,         	//="��̨û�п�̨"
        CWXXI12,         	//="��̨�������"
        CWXXI13,         	//="��ֹ�޸�ʱ��"
        CWXXI14,         	//="����������!"
        CWXXI15,         	//="���ۻ�������"
        CWXXI16,         	//="��Ʒû���۳�"
        CWXXI17,         	//="���ڽ�����!"
        CWXXI18,         	//="�������ݳ���"
        CWXXI19,         	//="���ڸ���!"
        CWXXI20,         	//="�������!"
        CWXXI21,         	//="û��ȷ�Ͻ���"
        CWXXI22,         	//="��ֹȡ������"
        CWXXI23,         	//="�޲���!"
        CWXXI24,         	//="�޴��տ�Ա!"
        CWXXI25,         	//="�տ�Ա�ı�"
        CWXXI26,         	//="�޴��౨��!"
        CWXXI27,         	//="������ӡ�ж�"
        CWXXI28,         	//="�����ھ�����"
        CWXXI29,         	//="���ܷ���ʱ��"
        CWXXI30,         	//="�����������"
        CWXXI31,         	//="ת�뵽"
        CWXXI32,         	//="δ��Ȩ!"
        CWXXI33,         	//="��ָ���տ�Ա"
        CWXXI34,         	//="��ָ��ӪҵԱ"
        CWXXI35,         	//="��ֹPLU��ۣ�"
        CWXXI36,         	//="���벻��!"
        CWXXI37,         	//="������ӡ����"
        CWXXI38,         	//="Ʊ�ݴ�ӡ����"
        CWXXI39,         	//="��ӡѹ��̧��"
        CWXXI40,         	//="��ӡֽ����!"
        CWXXI41,         	//="��ӡ�¶�̫��"
        CWXXI42,         	//="����δ����!"
        CWXXI43,         	//="����������"
        CWXXI44,         	//="��ֹ���ָ���"
        CWXXI45,         	//="�����޴˹���"
        CWXXI46,         	//="δ��С�Ƽ�!"
        CWXXI47,         	//="���ڹ������"
        CWXXI48,         	//="������ˮ��"
        CWXXI49,         	//="MODEMͨѶ��!"
        CWXXI50,        	//="����������!"
        CWXXI51,        	//="POS�����!"
        CWXXI52,        	//="�����ݴ�!"
        CWXXI53,        	//="Ϊ���ڿ�!"
        CWXXI54,        	//="Ϊ��ʧ��!"
        CWXXI55,        	//="�ͻ�����!"
        CWXXI56,        	//="Ϊ�¿�!"
        CWXXI57,        	//="���ǹ��￨!"
        CWXXI58,        	//="д������!"
        CWXXI59,        	//="���Ų���!"
        CWXXI60,        	//="�����ۿۿ�!"
        CWXXI61,        	//="�����ֽ�!"
        CWXXI62,        	//="�������ʿ�!"
        CWXXI63,        	//="����IC��!"
        CWXXI64,        	//="�忨����!"
        CWXXI65,        	//="�������!"
        CWXXI66,        	//="IC��ֵ����!"
        CWXXI67,        	//="IC��ʼ������"
        CWXXI68,        	//="��ֹ��ʼ��!"
        CWXXI69,        	//="IC����!"
        CWXXI70,        	//="IC�������!"
        CWXXI71,        	//="IP��ַ��"
        CWXXI72,           	//="��Ƶ������!"
        CWXXI73,           	//="����ʧ��!"
        CWXXI74,           	//="NO FISCAL MEMORY"
        CWXXI75,           	//="PRINT Z-REPORT"
        CWXXI76,           	//="WRITE FM ERROR"
        CWXXI77,           	//=FM����//
        CWXXI78,           	//="FM ERROR"
        CWXXI79,           	//="FISCALIZED"
        CWXXI80,           	//="Train Mode"
        CWXXI81,       	          	//="INITIALIZE FM"
        CWXXI82,       	          	//=FM�е������д�//
        CWXXI83,       	          	//="NO EJ"
        CWXXI84,       	          	//=EJ ��д����//
        CWXXI85,       	          	//=EJ������//
        CWXXI86,       	          	//="FM IS FULL"
        CWXXI87,       	          	//=EJ����//
        CWXXI88,       	          	//="EJ IS FULL"
        CWXXI89,       	          	//="MUST FORMAT SD"
        CWXXI90,       	          	//="New EJ"
        CWXXI91,       	          	//=���200�μӵ��ʼ��//
        CWXXI92,       	          	//="CHECKSUM ERROR"
        CWXXI93,       	          	//=FM ���տ����ƥ��//
        CWXXI94,       	          	//="NEW FM"

        CWXXI95,       	          	//="O.Battery Low!"
        CWXXI96,       	          	//="INNER EJ ERROR"
        CWXXI97,       	          	//="INITIALIZE EJ"
        CWXXI98,       	          	//=EJ���տ����ƥ��//
        CWXXI99,       	          	//="STOCK DISABLED"
        CWXXI100, 	//="INVALID TAX"
        CWXXI101,	//TAX<0

        CWXXI102,       	//GPRS����
        CWXXI103,       	//�������ݳ���
        CWXXI104,       	//�������ݳ���
        CWXXI105,       	//�޷����ӷ�����
        CWXXI106,       	//�޷�����IP��ַ
        CWXXI107,       	//��SIM��
        CWXXI108,       	//GPRSδ����
        CWXXI109,       	//����δ���
        CWXXI110,       	//����ͨѶʧ��
        //ccr2017-06-16>>>����������SD��������Ϣ>>>
        CWXXI111,           //INNER SD ����//
        CWXXI112,           //������EJ
        CWXXI113,           //�����ʼ��
        //ccr2017-06-16<<<<<<<<<<<<<<<<<<<<<<<<<
        CWXXI114,           //"File-E Not Found'
        CWXXI115,           //"File-I Not Found'
        CWXXI116,           //"NOT ACTIVED" //ccr2017-08-02
        CWXXI117,           //"OP-Times overflow" //ccr2017-08-08
        CWXXI118,           //"MUST RESTART ECR" //ccr2017-09-26

        CWXXI119,           //"URL/DNS NULL" //ccr2017-10-30
        CWXXI120,           //"FAILER ON DNS" //ccr2017-10-30
        CWXXI121,           //"ECR IP NULL" //ccr2017-10-30
        CWXXI122,           //"NO FILE/FOLDER-E"
        CWXXI123,           //"NO FILE/FOLDER-I"
        CWXXI124,           //"CACHE FULL"
        CWXXI125,           //"RATA DUPLICATION"
        CWXXI126,          // "PRINT DISCONNECT"   //ccr2018-04-02

//ccr2017-08-04>>>
        SETPORT1,        	// 9
        SETPORT2,        	// 10
        SETKP,       	 	// 20 ccr070725
        SETPERIPHERAL_ITEMS=(SETKP-SETPORT1+1),
//ccr2017-08-04<<<
        KAHAO=(SETKP+1),
        KLXING,
        KNJE,
        KYJIN,
        XFZE,
        CHZHZE,
        SHYCSHU,
        JGLBIE,
        PINMA,
        BHJBIE,
        ZDJZHANG,
        ZHKRQI,
        KYXQI,
        KHMCHEN,
        CHSHHICKA,
        ICKCHZHI,
        QCHICKA,
        GUASHIIC,
        ZHEKOUCA,
        XIANJINKA,
        SHEZHANGKA,
        XFJIDIAN,
        ZHKLVF,
        ICKTKUAN,
        ICKDJDIANG,
        ICKSDIAN,
        ZHUOTAI,
        RECNUMFR,
        RECNUMTO,
        EJCSHUA,
        EJBHAO,
        EJBBIAO,
        GRANDTOTAL,
#if (defined(FISCAL) || DD_FISPRINTER==1)
//cc 2006-09-19 for Fiscal>>>>>>>>>>>>>>>>>>
        ITEMTAXA,
        TAXTOTAL,
        TOTALZCOUNTER,
        NETSALE,
        RECNUMBER,
        MSGECRxFM     ,   //FM�γ�����
        MSGECRxEJ     ,   //SD���γ�����ͳ��
        MSGECRCMOSERR ,   //CMOS����(���ݴ�)����ͳ��
        MSGECRxPRINTER,   //��ӡ���Ͽ�����ͳ��
        CHANGEHEAD,
        CHANGEDATETIME,
        TAXACHG,
        TAXFROM,
        TAXTO,
        PRNFISCAL,
        PRNTOTAL,
        CLEARTOTAL,
        MACRESET,
        CHANGETAX,
//hf 20060919 for fiscal >>>
        SHKZBB,
        TAXCODE,
        RIFCODE,
        MIANSHUI,
        SHUIMUA,
        KHMINGCH,
        JIQIHAO,
        RIQI,
        SHIJIAN,
        XSHZHJI,
        THUOZHJI,
        ZHKOUZHJI,
        XIAOSHOUA,
        NETAFTERTAX, //"NET AFTER TAX"	//"˰�����۶�"		//
        AMTWITHTAX, //		"AMOUNT WITH "	    //"��˰���۶�"
        THXIAOSHOU,
        ZHKOUXSH,
        THZJSHUI,
        ZHKZJSHUI,
        EJXINXI,
//hf end <<<<<<<<<<<<<<<<<<<
        EJSHJIAN,
        NONFISCAL,
        SHKCSHUA,
        DATEFROM,
        DATETO,
        TIMEFROM,
        TIMETO,
        ZHJIFPHAO,
        ZHJITHHAO,
        ZHJIFSHHAO,
        FAPIAOHAO,
        DAILYRECEIPTS,
        THUOHAO,
        FEISHUIHAO,
        SHKBBHAO,
        QZHJSHU,
        REPLEFT,
        SIZEFM,
#endif
        SIZEEJ,
        VALUEINIC,
        LOWBAT,
        CLEARIC,
        CHARGEIC,
        ADPOINTS,
        INITIC,
        WAITEICCARD,
        ICCARDOK,
//ChipCard<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        ePOSTAC,
        WAITEPOS,
        ePOSCARNO,
        eCARREMAIN,
        TMHYHAO,
        BARREPORT,
        XFJE,
        ZONGJI,
        WAITING,
        INITWAITING,

        RECEIPTFROM,      	// "��ʼ�վݺ�",	//
        RECEIPTTO,         	// "�����վݺ�",	//

        ZNumFORRECEIPT,     //MessageRecZNum,//	"#Z OF RECEIPT"   //"�վݺ�����Z������"
        RECEIPTNUMBER,      //MessageRecNum,//	"RECEIPT NUMBER"   //"��ѯ���վݺ�"

        SUM_EXC_VAT,       	//����˰���۽��
        VAT_AMOUNT,       //˰��
//ccr2017-05-09>>ѡ���տ��ģʽ�˵���>>>>>>>>>>>>>>>>>
        REG_MODE,       //MessMODEReg
        X_MODE,       	//MessMODEX
        Z_MODE,       	//MessMODEZ
        SET_MODE,       //MessMODESET
#if !defined(CASE_GREECE)//ccr2017-12-14ȥ��������
        MG_MODE,       	//MessMODEMAN
#else
        MG_MODE=SET_MODE,       	//MessMODEMAN
#endif
        REGMODE1ST=REG_MODE,
        ITEMS_MODE=(MG_MODE-REG_MODE+1),
//ccr2017-05-09<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

//>>>>>>>>����X��������>>>>>>>>>
        XREPORT1ST=(MG_MODE+1),
        xDAILYJOURNAL=XREPORT1ST    ,// "DAILY JOURNAL"
        xDEPARTMENTDAILY ,         // "DEPARTMENT DAILY"
        xPLUDAILY        ,         // "PLU DAILY"
        xCLERKSDAILY     ,         // "CLERKS DAILY"
#if (salNumber)
        xWAITERSDAILY    ,         // "WAITERS DAILY"
#endif
        xCATEGORY        ,         //"CATEGORY DAILY"
        xALLDAILY        ,         // "ALL DAILY"
        xGENERALPARAM	   ,    // "GENERAL PARAMETERS"
        ITEMS_X=(xGENERALPARAM-XREPORT1ST+1),

//>>>>>>����Z��������>>>>>>>>>>>
        ZREPORT1ST=(xGENERALPARAM+1),
        zPRINTZREPORT=ZREPORT1ST  ,// "PRINT Z REPORT"
#if defined(CMD_zHTTPPOSTSFILE)
        zHTTPPOSTSFILE ,                // "SEND S-FILES OF Z"
#endif
        zCOPYLASTZ  	 ,                  //"COPY OF LAST Z"
        zDEPTSALES	 ,                  //"DEPARTMENT SALES" <<< IDX_Z_FROM
        zPLUSALES      ,                //  "PLU SALES"
        zCLERKSSALES   ,                // "CLERKS  SALES"
#if (salNumber)
        zWAITERSSALES  ,                // "WAITERS  SALES"
#endif
        zZERODEPARTMENT,                //  "ZERO DEPARTMENT"
        zZEROPLUSALES  ,                // "ZERO PLU SALES"
        zZEROCLERKS    ,                //  "ZERO CLERKS"
#if (salNumber)
        zZEROWAITERS   ,                //  "ZERO WAITERS"
#endif
        zZEROALLSALES  ,                // "ZERO ALL SALES"
        zFMREADZ_Z     ,                // "FM READ Z-Z"
        zFMREADDATE    ,                // "FM READ DATE"
#if defined(CMD_zFMREADTAXRATE)
        zFMREADTAXRATE ,                // "READ TAX RATE "
        zFMREADHEAD    ,                // "READ HEAD "
        zFMREADSETDATE ,                // "READ DATE CHANGED"
        ITEMS_Z=(zFMREADSETDATE-ZREPORT1ST+1),
#else
        ITEMS_Z=(zFMREADDATE-ZREPORT1ST+1),
#endif
//>>>>>>X���µ�xGENERALPARAM���ܲ˵�>>>>>
        xLISTPLU=(ZREPORT1ST+ITEMS_Z),                       //PLU LIST
        xLISTDEPARTMENT,                //DEPARTMENT LIST
        xLISTCLERK,                     //CLERK LIST
        ITEMS_xPARAM=(xLISTCLERK-xLISTPLU+1),

        fmSYNOPSIS=(xLISTCLERK+1),      //"SYNOPSIS"      strSYNOPSIS    //��������
        fmANALYTICAL,                   //"ANALYTICAL"    strANALYTICAL  //��ϸ����
        ITEMS_fmPARAM=(fmANALYTICAL-fmSYNOPSIS+1),

        EJBYDATETIME=(fmANALYTICAL+1),  //strEJLOGBYDATE "EJ BY DATETIME"
        EJBYZNUMBER,                    //strEJLOGBYZ_Z "EJ BY Z NUMBER"
        ITEMS_EJRANGE=(EJBYZNUMBER-EJBYDATETIME+1),

        EJPrintReceipt=(EJBYZNUMBER+1),//strRECEIPTPRINT,"RECEIPT PRINT"
        EJPrintZRport,                  //strZREPORTPRINT,"Z REPORT PRINT"
        ITEMS_EJLOG=(EJPrintZRport-EJPrintReceipt+1),

#if (!defined(CASE_GPRS)) 	// ADD BY LQW 090827
        HZMESSMAX_GPRS=(EJPrintZRport+1),
#else
//ccr2014-11-11 NEWSETUP Step-4 �Ӳ˵���Ŀ��Ϣ���>>>>>>>>>>>>>>

        GPRSFUNC1ST=(EJPrintZRport+1),
        gprsSETMODE=GPRSFUNC1ST,
        gprsSendECRLog,
        gprsSendECRLogAll,
        gprsDownloadPLU,       //"���ص�Ʒ�ļ�"
        gprsDownloadDEPT,       	 	//"���ز����ļ�"
        gprsDownloadCLERK,       	//"�����տ�Ա"
        gprsDownloadHEAD,       	//"����Ʊͷ"
        gprsDownloadTRAIL,       	//"����Ʊβ"
        gprsDownloadALL,       //"����ȫ������"
        gprsRestart,       //  "��λGPRS"   	//gprsRestart	//ccr2016-08-26
        gprsSENDMESS,

        HZMESSMAX_GPRS,       	//(gprsRestart+1)	//<<<<<<<<

        gprsMAINITEMS=(HZMESSMAX_GPRS-GPRSFUNC1ST),       	//�Ӳ˵���Ŀ��,��Ҫ�޸�MENUGPRSFUNSMAX
#endif

#if (!defined(CASE_ETHERNET)) 	// ADD BY LQW 090827
        HZMESSMAX_ETH=(HZMESSMAX_GPRS),
#else
//ccr2014-11-11 NEWSETUP Step-4 �Ӳ˵���Ŀ��Ϣ���>>>>>>>>>>>>>>

        net_PINGMESS=(HZMESSMAX_GPRS),
        net_SETMODE,
        net_SendECRLog,
        net_SendECRLogAll,
        net_UpdatePLU,       	//"���ص�Ʒ�ļ�"
        net_UpdateDEPT,        	//"���ز����ļ�"
        net_UpdateCLERK,       //"�����տ�Ա"
        net_UpdateHEAD,       //"����Ʊͷ"
        net_UpdateTRAIL,       //"����Ʊβ"
        net_UpdateALL,       //"����ȫ������"
        net_Restart,       	//  "��λGPRS"   	//net_Restart	//ccr2016-08-26

        HZMESSMAX_ETH,       	//(net_Restart+1)	//<<<<<<<<

        ETHERNETFUNC1ST=net_PINGMESS,
        net_MAINITEMS=(net_Restart-net_PINGMESS+1),       	//�Ӳ˵���Ŀ��,��Ҫ�޸�MENUGPRSFUNSMAX
//     net_MAINITEMS,       	//(net_Restart-net_PINGMESS+1)       	//�Ӳ˵���Ŀ��,��Ҫ�޸�MENUGPRSFUNSMAX

#endif
//ccr2017-09-14>>>>>>>>>>>>>>>>>>>>>>>>>
#if(defined(CASE_ETHERNET)||defined(CASE_GPRS))
        MINISTRYSEND=HZMESSMAX_ETH  ,//   "MINISTRY SEND"
        //>>>>>For NET Functions
        SERVERURL,
        PERSONALCODE,
        GPRSSEND,
        //>>>>>For Net Work
        DHCP          ,//  "DHCP"
        PRIMARYDNS    ,//  "PRIMARY DNS"
        SECONDARYDNS  ,//  "SECONDARY DNS"
        PRINTSETTINGS ,//  "PRINT SETTINGS"
        MESSAGEMAX_NETWORK,
#else
        MESSAGEMAX_NETWORK=HZMESSMAX_ETH,
#endif
//ccr2017-09-14<<<<<<<<<<<<<<<<<<<<<<<<<
//ccr2017-05-10 SETAUXFUNCS>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

        AUX_PRINTPLU=(MESSAGEMAX_NETWORK),     	//CMD_PRINTPLU    ��ӡ��Ʒ��Ϣ
        AUX_EXPLOREEJ,        	            //CMD_EXPLOREEJ,  ��ѯEJ����
        AUX_PRINTFISCAL,        	        //CMD_PRINTFISCAL,��ӡ������˰����Ϣ
        AUX_PRINTEJ,       	                //CMD_PRINTEJ,    ��ӡEJ��Ϣ
        AUX_SETPWDX,       	                //CMD_SETPWDX,    ����X��������
        AUX_SETPWDZ,       	                //CMD_SETPWDZ,    ����Z��������
        AUX_SETPWDSET,        	            //CMD_SETPWDSET,  ����SET��������
        AUX_SETPWDMG,        	            //CMD_SETPWDMG,   ���þ���MG��������
        AUX_INITFISCAL,        	            //CMD_INITFISCAL, ˰�س�ʼ��
        AUX_INITEJ,       	                //CMD_INITEJ,     ��ʼ��EJ
        AUX_PRNGAPHIC,        	            //CMD_PRNGAPHIC,  ��ӡ�տ��ͼ��
        AUX_ECRCONFIG,                      //CMD_ECRCONFIG,  ��ӡ�տ������
        AUX_FUNC1ST=AUX_PRINTPLU,//!!!!!!!
        AUX_FUNCITEMS=(AUX_ECRCONFIG-AUX_PRINTPLU+1),//!!!!!!�Ӳ˵���Ŀ��

        /* SKJCSHI�µ�ϵͳ���Թ��� */
        SETTEST =AUX_ECRCONFIG+1,
        TEST_FUNC1ST=SETTEST,      //!!!!!!!
        SETTSTDISP =TEST_FUNC1ST,  //msg_SETTSTDISP  //"��ʾ����",
        SETTSTCUST ,               //msg_SETTSTCUST  //"����ʾ����",
        SETTSTPRT  ,               //msg_SETTSTPRT   //"��ӡ����",
        SETTSTCLK  ,               //msg_SETTSTCLK   //"ʱ�Ӳ���",
        SETTSTMEM  ,               //msg_SETTSTMEM	 //RAM����
        SETTSTBELL ,               //msg_SETTSTBELL  //"����������",
        SETTSTDRAW ,               //msg_SETTSTDRAW  //"Ǯ�����",
        SETTSTKBD  ,               //msg_SETTSTKBD   //"���̲���",
        SETTSTCOMM ,               //msg_SETTSTCOMM  //"���ڲ���",
#if defined(FOR_DEBUG)
        SETTSTERASEFM ,            //msg_SETTSTERASEFM    //"���FM",
        SETTSTFM ,                 //msg_SETTSTFM    //"����FM",
#endif                                   //
        SETTSTAUTO ,               //msg_SETTSTAUTO  //"�Զ�����",
        HZMESSMAX,       	       //<<<<<<<<<<<<<<<<<<<<<<<<
        TEST_FUNCITEMS=(SETTSTAUTO-TEST_FUNC1ST+1),//!!!!!!�Ӳ˵���Ŀ��
} SETUPTYPEDEF;
#define  TRAINMODE CWXXI80
//MSg[]<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

//index of LineCap>>>>>>>>>>>>>>>>>>>
typedef enum {
        Line_YES    	,//0  LineCap1,
        Line_NO    		,//1  LineCap2,
        Line_CAPTION    ,//2  LineCap3,
        Line_DEPART    	,//3  LineCap4,
        Line_GROUP    	,//4  LineCap5,
        Line_SYS_FLAG   ,//5  LineCap6,
        Line_PRINT    	,//6  LineCap7,
        Line_OPTION    	,//7  LineCap8,
        Line_EXTRAKP    ,//8  LineCap9,//KP EP = extra printer
        Line_TAXUSED    ,//9  LineCap10
        Line_LOC    	,//10 LineCap11
        Line_PRICE1    	,//11 LineCap12
        Line_PRICE2    	,//12 LineCap13
        Line_PRICE3    	,//13 LineCap14
        Line_PRICE4    	,//14 LineCap15
        Line_COST    	,//15 LineCap16
        Line_FIXED    	,//16 LineCap17
        Line_MAX     	,//17 LineCap18
        Line_FIXED1   	,//18 LineCap19
        Line_MAX1   	,//19 LineCap20
        Line_TAXRATE    ,//20 LineCap21
        Line_BUYRATE    ,//21 LineCap22
        Line_SELRATE    ,//22 LineCap23
        Line_START    	,//23 LineCap24
        Line_DRAWER    	,//24 LineCap25
        Line_OTD    	,//25 LineCap26 //��������С��
        Line_PRTTYPE    ,//26 LineCap27
        Line_PERIOD    	,//27 LineCap28
        Line_REPTYPE    ,//28 LineCap29
        Line_PREFIX    	,//29 LineCap30
        Line_LINK    	,//30 LineCap31
        Line_KEYCODE    ,//31 LineCap32
        Line_MANAGE    	,//32 LineCap33
        Line_TYPE    	,//33 LineCap34
        Line_DATEFR    	,//34 LineCap35  //MAX.Length<=7
        Line_DATETO    	,//35 LineCap36  //MAX.Length<=7
        Line_TIMEFR    	,//36 LineCap37
        Line_TIMETO    	,//37 LineCap38
        Line_WEEKDAY    ,//38 LineCap39
        Line_DISCOUNT   ,//39 LineCap40
        Line_PACKQTY    ,//40 LineCap41
        Line_UPRICE     ,//41 LineCap42
        Line_PPRICE     ,//42 LineCap43
        Line_PROTOCOL   ,//43 LineCap44
        Line_TELE     	,//44 LineCap45
        Line_PASSWORD   ,//45 LineCap46
        Line_FREQUENT   ,//46 LineCap47
        Line_MINIMUM    ,//47 LineCap48
        Line_PORT     	,//48 LineCap49
        Line_VALUE     	,//49 LineCap50
        Line_GRAPHIC    ,//50 LineCap51
        Line_SLIPTYPE   ,//51 LineCap52
        Line_BLANKLIN   ,//52 LineCap53  //???
        Line_LINEPAGE   ,//53 LineCap54
        Line_PRTINFO    ,//54 LineCap55
        Line_SECOND     ,//55 LineCap56
        Line_LEFTMAR    ,//56 LineCap57
        Line_POINT     	,//57 LineCap58
        Line_PRILEVEL   ,//58 LineCap59
        Line_CONFIRM    ,//59 LineCap60
        Line_FOREGIFT   ,//60 LineCap61
        Line_POSCODE    ,//61 LineCap62
        Line_USECASH    ,//62 LineCap63
        Line_DEADLINE   ,//63 LineCap64
        Line_PERSONALCODE,//64 LineCap65
        LINEITEMSMAX      ,//65
} LINEITEMS;
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

//------message index for TXT.Caption-----------------------------------------------------

#define ERROR_ID(err) (err-CWXXI01+1)


#if (defined(CASE_GPRS) || defined(CASE_ETHERNET))
typedef enum {
       G_xDATATYPE               ,//0                              //ccr"�������ʹ�"
       G_GPRSOK                  ,//(G_xDATATYPE+1)                //ccr"GPRS READY"
       G_GPRSNOTOK               ,//(G_GPRSOK+1)                   //ccr"GPRS ERROR"
       G_CONFIRM                 ,//(G_GPRSNOTOK+1)                //ccr"��ȷ��"
       G_SERVERIP_NULL           ,//(G_CONFIRM+1)                 //ccr"������IP��˿ڲ���:"
       G_X_IPPORT                ,//(G_SERVERIP_NULL+1)           //ccr"������IP��˿ڲ���:"
       G_WAITFOR                 ,//(G_X_IPPORT+1)                 //ccr�ȴ�GPRS
       G_SHUJUFASONGZHONG        ,//(G_WAITFOR+1)                      //"���ݷ�����.."
       G_SHUJUYIFACHU            ,//(G_SHUJUFASONGZHONG+1)         //"�����ѷ���.."
       G_FASONGCHENGGONG         ,//(G_SHUJUYIFACHU+1)      //"���ͳɹ�.."
       G_LIANJIESERVERSHIBAI     ,//(G_FASONGCHENGGONG+1)   //"���ӷ�����ʧ��"
       G_JIESHOUSHIBAI           ,//(G_LIANJIESERVERSHIBAI+1)      //"����ʧ��"
       G_FASONGSHIBAI            ,//(G_JIESHOUSHIBAI+1)       //"����ʧ��"
       G_SERVERIP	             ,//(G_FASONGSHIBAI+1)               //
       G_SERVERPORT              ,//(G_SERVERIP+1)                 //
       G_CONNECTING              ,//(G_SERVERPORT+1)          // "���ڽ�������.."
       G_TOCONNECTING            ,//(G_CONNECTING+1)               // "׼����������.."
       G_FUWEIMOKUAI             ,//(G_TOCONNECTING+1)            // "���ڸ�λģ��.."
       G_CHENGGONGTUICHU         ,//(G_FUWEIMOKUAI+1)              // "�������,���˳�.."
       G_GPRSMessMax             ,//(G_CHENGGONGTUICHU+1)
} NETWORKITEM;
extern CONST FSTRING GPRSMess[G_GPRSMessMax]; //ADD BY LQW. 090802
#endif


typedef enum {/*    Caption[50][15]     */
        ItemPrompt0    ,         //0 "TOTAL"         //Ӧ��
        ItemPrompt1    ,         //1 "SUBTOTAL"      //
        ItemPrompt2    ,         //2 "SPENDING"      //"�����ܶ� "
        ItemPrompt3    ,         //3 " NET AMOUNT"   //
        ItemPrompt4    ,         //4 " PRICE"        //
        ItemPrompt5    ,         //5 " TRANSACTIONS" //
        ItemPrompt6    ,         //6 " QUANTITIES"   //
        ItemPrompt7    ,         //7 " AMOUNT"       //
        ItemPrompt8    ,         //8 "RECEIVE"       //
        ItemPrompt9    ,         //9 "CHANGE"        //
        ItemPrompt10   ,         //10" "             //
        ItemPrompt11   ,         //11" "             //
        ItemPrompt12   ,         //12"-"             //
        ItemPrompt13   ,         //13"-"             //
        ItemPrompt14   ,         //14"STANDARD"      //
        ItemPrompt15   ,         //15"OPERATOR"      //
        ItemPrompt16   ,         //16" "             //
        ItemPrompt17   ,         //17" "             //
        ItemPrompt18   ,         //18"-"             //
        ItemPrompt19   ,         //19"REPORT"        //
        ItemPrompt20   ,         //20" REFUND"       //
        ItemPrompt21   ,         //21" DISCOUNT"     //
        ItemPrompt22   ,         //22" COST"         //
        ItemPrompt23   ,         //23"TABLE#"        //
        ItemPrompt24   ,         //24"CHEQUE#"       // used for Registe
        ItemPrompt25   ,         //25"OPTIONS:"      //
        ItemPrompt26   ,         //26"GROSS SALES"   //
        ItemPrompt27   ,         //27" TAX"          //
        ItemPrompt28   ,         //28" PAGE"         //
        ItemPrompt29   ,         //29"No.#:"         //
        ItemPrompt30   ,         //30"SERVICE"       //
        ItemPrompt31   ,         //31"PREV. BALANCE "//
        ItemPrompt32   ,         //32"Z COUNT"       //
        ItemPrompt33   ,         //33"CLEAR"         //
        ItemPrompt34   ,         //34"SYSTEM REPORT" //
        ItemPrompt35   ,         //35" GROSS PROFIT" //
        ItemPrompt36   ,         //36"STOCK UPDATE"  //
        ItemPrompt37   ,         //37"FORMER PB:"    //
        ItemPrompt38   ,         //38"CREDIT CARD#"  //
        ItemPrompt39   ,         //39"NEW TABLE:"    //
        ItemPrompt40   ,         //40"GUESTS"        //
        ItemPrompt41   ,         //41"EXCHANGE"      //
        ItemPrompt42   ,         //42"INSERT"        // Add random n
        ItemPrompt43   ,         //43"DELETE"        // delete rando
        ItemPrompt44   ,         //44"DISCOUNT 1"    //
        ItemPrompt45   ,         //45"DISCOUNT 2"    //
        ItemPrompt46   ,         //46"SALES"         //
        ItemPrompt47   ,         //47"MIX-MATCH"     //
        ItemPrompt48   ,         //48"STOCK"         //
        ItemPrompt49   ,         //49"OFFER"         //
        ItemPrompt50   ,         //50"OPTIONS"       // for options
        ItemPrompt51   ,         //51"USE KP "       // for KP option
        ItemPrompt52   ,         //52"FIXED DISCOUNT"// Options for D
        ItemPrompt53   ,         //53"FLOAT DISCOUNT"//
        ItemPrompt54   ,         //54"FIXED+FLOAT"   //
        ItemPrompt55   ,         //55"OPEN()"        // Options for PBFun
        ItemPrompt56   ,         //56"OP_ADD"        //
        ItemPrompt57   ,         //57"SERVICE"       //
        ItemPrompt58   ,         //58"CONFIRM"       //
        QUERENF=ItemPrompt58,
        ItemPrompt59   ,         //59"PRINT/OPEN"    //
        ItemPrompt60   ,         //50"PRINT BILL"    //
        ItemPrompt61   ,         //61"CANCEL"        //
        ItemPrompt62   ,         //62"SPLIT BILL"    //
        ItemPrompt63   ,         //63"TRANSFER"      //
        ItemPrompt64   ,         //64"MOVE TO"       //
        ItemPrompt65   ,         //65"COVER"         //
        ItemPrompt66   ,         //66"JOKERSLIP ?"   //
        ItemPrompt67   ,         //67"POINT ?"       //
        ItemPrompt68   ,         //68"DEC_ADD ?"     //
        ItemPrompt69   ,         //69"CHIP CARD ?"   //
        ItemPrompt70   ,         //70"DISCOUNT"      //
        ItemPrompt71   ,         //71"CASH"          //
        ItemPrompt72   ,         //72"CREDIT"        //
        ItemPrompt73   ,         //73"PRT CARD INFO."//
        ItemPrompt74   ,         //74"AUTO DISCOUNT "//
        ItemPrompt75   ,         //75"POINTS"        //
        ItemPrompt76   ,         //76"<CASH>KEY TEND"//
        ItemPrompt77   ,         //77"CHARGE/DISCHG?"//
        ItemPrompt78   ,         //78"EXPIRED DATE " //
#if((DISP2LINES)||DD_LCD_1601==1)
//Option for dept==
        ItemPrompt79   ,         //79 "��ֹ��۸�",      //JZHLJGE
        ItemPrompt80   ,         //80 "��ӡ�ָ���",      //DYFGXIAN
        ItemPrompt81   ,         //81 "��������:",        //DXXSHOU
        ItemPrompt82   ,         //82 "�ۿ��� 1:",     //ZHKXIANG1
        ItemPrompt83   ,         //83 "�ۿ��� 2:",     //ZHKXIANG2
        ItemPrompt84   ,        //84 "��ӡ�ܶ�:",        //KPDYZE
//Option for ApplVar.KP===
        ItemPrompt85   ,         //85 "����ͬ��ӡ",      //KPCXTDY
        ItemPrompt86   ,         //86 "�˲�ͬ��ӡ",      //KPCBTDY
        ItemPrompt87   ,         //87 "��Ǯ��:",        //DKQXIANGF
//Options for tend=
        ItemPrompt88   ,         //88 "������:",        //SHRJE
        ItemPrompt89   ,         //89 "��ֹ����:",        //JZHSHRU
        ItemPrompt90   ,         //90 "�������:",        //SHRHMA
        ItemPrompt91   ,         //91 "����ΪС��",      //ZHLXFEI
        ItemPrompt92   ,         //92 "��Ǯ��:",        //DKQXIANGP
//Options for ApplVar.PoRa=
        ItemPrompt93   ,         //93 "���ʽ��",      //FKFSHJIAN
        ItemPrompt94   ,         //94 "������:",        //CRJE
        ItemPrompt95   ,         //95 "���/����",        //RJCHJIN
        ItemPrompt96   ,         //96 "��ӡ�ۿ۶�",      //DYZHKE
//Option for ApplVar.Disc==
        ItemPrompt97   ,         //97 "ʹ���ۿ�1:",       //SHYZHK1
        ItemPrompt98   ,         //98 "ʹ���ۿ�2:",       //SHYZHK2
        ItemPrompt99   ,         //99   "����������",      //MCHJZHLIN
//Options for currency==
        ItemPrompt100,           //100  "��С����:",        //WXSHDIAN
//Options for ApplVar.Draw
        ItemPrompt101,           //101  "��Ǯ��:",        //DKQXIANGD
        ItemPrompt102,           //102  "Ӫҵ/��ֵ:",       //YYZZHI
//Options for ApplVar.Tax=
        ItemPrompt103,           //103  "��ӡ˰����",      //DYSHLXIANG
        ItemPrompt104,           //104  "��ӡ0˰��",        //DYLSHXXI
        ItemPrompt105,           //105  "ΪGST��˰",     //WGSTSHUI
        ItemPrompt106,           //106  "��ӡ˰��:",        //DYSHE
        ItemPrompt107,           //107  "ȡ������:",        //QXXZHI
//Options for clerk
        ItemPrompt108,           //108  "��������:",        //GGXZHI
        ItemPrompt109,           //109  "ȡ������:",        //QXJYIXZHI
        ItemPrompt110,           //110  "�˻�����:",        //THXZHI
        ItemPrompt111,           //111  "%�ۿ�����:",       //BFBZHKXZHI
        ItemPrompt112,           //112  "%�ӳ�����:",       //BFBJCHXZHI
        ItemPrompt113,           //113  "+-�������",       //JJJEXZHI
        ItemPrompt114,           //114  "��ѵģʽ:",        //PSHMSHI
#endif
        ItemPrompt115,           //115  "ACTIVE",        //ACTIVE
        ItemPrompt116,           //116  "PRINT LOGO",        //PRINTLOGO
        PROMPTITEMSMAX
}  PROMPTITEMS;


typedef enum {  //DMes[]
		 ItemDMes0,//   " CHANGE PRICE "		/* 0, Plu Price Change (PutsO)*/
		 ItemDMes1 ,//   " ADD STOCK"		/* 1, Inventory ++  (PutsO)*/
		 ItemDMes2 ,//   " REMOVE STOCK"		/* 2, Inventory --  (PutsO)*/
		 ItemDMes3 ,//   " KP_GROUP"		/* 3, Kitchen Printer Group  (PutsO)*/
		 ItemDMes4 ,//   " CORRECT"		/* 4, Correction (PutsO)*/
		 ItemDMes5 ,//   " REFUND"			/* 5, Refund (PutsO)*/
		 ItemDMes6 ,//   " CANCEL 1"		/* 6, Cancel 1 function (PutsO)*/
		 ItemDMes7 ,//   " CANCEL 2"		/* 7, Cancel 2 function (PutsO)*/
		 ItemDMes8 ,//   " RS232 ERROR"		/* 8, RS232 Test */
		 ItemDMes9 ,//   " RS232 OK"		/* 9, RS232 Test */
		 ItemDMes10,//   " RTC ERROR"		/* 10, RTC Test Error */
		 ItemDMes11,//   " CTC ERROR"		/* 11, CTC Test Error */
		 ItemDMes12,//   " FPROM ERROR"		/* 12, Fiscal Prom Error */
		 ItemDMes13,//   "INITIALIZATION"		/* 13, Clearing RAM (PutsO)*/
		 ItemDMes14,//   " INIT END"			/* 14, Initialising Application */
		 ItemDMes15,//   " SLIP PAPER"		/* 15, Change Slip Paper (PutsO)*/
		 ItemDMes16,//   " PASSWORD? "		/* 16, Secret Clerk Code */
		 ItemDMes17,//   " ERROR- "			/* 17, Error code        */
		 ItemDMes18,//   "PASSWORD ERROR"	/* 18, Error code   (PutsO)     */
		 ItemDMes19,//   " ACCEPTED"		/* 19, Error code   (PutsO)     */
		 ItemDMes20,//   "OPERATOR:"		/*20 �տ�Ա��  */
		 ItemDMes21,//   "S.PERSON: "		/* 21 ӪҵԱ:  */
		 ItemDMes22,//   "ECR#:"	/*22 �տ����  */  //ZWQ
		 ItemDMes23,//   "LOCATION:"		/*23 λ��  */ //ZWQ
		 ItemDMes24,//   "CONFIRM ?"		//24 (PutsO)
		 ItemDMes25,//   "COMPLETED"			//25		???
		 ItemDMes26,//   "VERSION:"		//26 "���а汾"	//
		 ItemDMes27,//   "POINTS"			//27 "�������ѵ�"	 //
		 ItemDMes28,//   "ADD PLU "			//28 "���ӵ�Ʒ:"	//
		 ItemDMes29,//   "DELETE PLU:"		//29"ɾ����Ʒ:"	//
		 ItemDMes30,//   "TEST STARTED>>"		//30"��ʼ���"	//
		 ItemDMes31,//   "TEST COMPLETED"		//31"������"	// ZWQ
		 ItemDMes32,//   "PRICE"			//32
		 ItemDMes33,//   "STOCK"		//33
         ITEMDMESSMAX
} ITEMDMESS;



typedef enum {
		   DTEXT_CURRENCY ,		//"CURRENCY"		/* 0, Foreign Currency */
		   DTEXT_TOTAL ,		//"TOTAL"		/* 1, Sales Total */
		   DTEXT_CHANGE ,		//"CHANGE"			/* 2, Change */
		   DTEXT_SUBTOTAL ,		//"SUBTOTAL"		/* 3, Subtotal */ //ZWQ
		   DTEXT_DISCOUNT ,		//"DISCOUNT"		/* 4, Discount */
		   DTEXT_PO ,		    //"P.O"			/* 5, Paid Out */	//ZWQ
		   DTEXT_RA ,		    //"R.A"		/* 6, Received On Account */ //ZWQ
		   DTEXT_DRAWER ,		//"DRAWER"		/* 7, Drawer */
		   DTEXT_TABLE ,		//"TABLE#"		/* 8, Table Number */
		   DTEXT_SRVICE ,		//"SERVICE"			/* 9, Service */
		   DTEXT_CHKPAID,		//"CHECKS PAID"		/* 10, Checks Paid */
		   DTEXT_CHKCANCEL,		//"CHECK CANCEL"		/* 11, cancel Checks Paid */
		   DTEXT_GUEST,		    //"GUEST"			/* 12, Covers */
		   DTEXT_OPERATOR,		//"OPERATOR"		/* 13, Clerk */
		   DTEXT_MODIFIER,		//"MODIFIER"		/* 14, Modifier */
		   DTEXT_HOLD,		    //"HOLD"			/* 15, Suspend/Recall tekst */
		   DTEXT_CANCEL,		//"CANCEL"			/* 16, Transaction void */
		   DTEXT_SALER,		    //"SALESPERSON"		/* 17, SalesPerson */
		   DTEXT_OFF,		    //"OFF"			// 18, LOCK mode
		   DTEXT_REG,		    //"REGIST"			// 19,Reg mode
		   DTEXT_X,		        //"X REPORT"			// 20,X report mode
		   DTEXT_Z,		        //"Z REPORT"		// 21,Z report mode
		   DTEXT_SET,		    //"PROGRAM"		// 22, SET mode
		   DTEXT_MG,		    //"MANAGEMENT"		// 23, Manager mode
		   DTEXT_PASSWORD,		//"PASSWORD"		// 24,Password for XMode
		   DTEXT_NEWPWD,		//"-NEW PASSWORD"		// 25,New password for xMode
		   DTEXT_CONFIRMPWD,		//"-CONFIRM PWD"		// 26,Confirm new password for XMode
		   DTEXT_PRICE,		    //"PRICE:"			/* 27	���� */
		   DTEXT_AMOUNT,		//"AMT.:"			/* 28  ��� */
		   DTEXT_RETALL,		//"RETAIL"		// 29		ZWQ
		   DTEXT_RESTAURANT,		//"RESTAURANT"		// 30
		   DTEXT_YEAR,		    //"-"					/* 1 �� */
		   DTEXT_MONTH,		    //"-"					/* 32 ��  */
		   DTEXT_DAY,		    //" "					/* 33 ��  */
		   DTEXT_TEST,		    //"TEST MODE"		// 34
		   DTEXT_RAM,		    //"RAM:"			//35
		   DTEXT_OBLI,		    //"OBLI."		/* 36  Subtotal */ //ZWQ
		   DTEXT_FINISHED,		//  "FINISHED"		/* 37, cash finished  */
} ITEMDTEXT;
//////////////////////////////////////////////////////////////

extern const char
    MsgSAVETOSDCARD[],	//=MSG_SAVETOSDCARD,//"SAVE TO SD?" //ccr2018-04-02
    MsgREMOVEMAC[],     //=MSG_REMOVEMAC,//"REMOVE MAC-JUMP"
    PWD4Technician[],   //=PWD4TECHNICIAN,
    MsgREPORTCLEARED[],//=MSG_REPORTCLEARED,//"REPORTS CLEARED"
    MsgCOPYRECEIPTEND[],//=COPYRECEIPTEND   ,//   "*****COPY RECEIPT-END*****"
    MsgCOPYRECEIPTSTART[],//=COPYRECEIPTSTART ,//   "*****COPY RECEIPT-START*****"
    MsgNOTARECEIPT[],//=NOTARECEIPT      ,//   "THIS IS NOT A RECEIPT"
    MsgZAFTERPOWERFAIL1[],//=ZAFTERPOWERFAIL1 ,//   "POWER FAILURE"
    MsgZAFTERPOWERFAIL2[],//=ZAFTERPOWERFAIL2 ,//   "UNSUCCESSFUL ISSUING OF Z"
    MsgCOPYOFLASTZ[],//=COPYOFLASTZ      ,//   "COPY OF THE LAST Z DAILY REPORT"
    MsgCOMMENTS[],//=MSG_COMMENTS,
    MsgAESKey[],//=msg_AESKey,//"AES KEY"
    MsgSendCurrentSFile[],//=msg_SendCurrentFile,//"Send S.File?"
    MsgSendSFiles[],//=msg_SendSFiles;//"Send All S.Files"
    MsgCUSTOMERCARD[],//SysFlag_CUSTOMERCARD "CUSTOMER RECEIPT CARD"
    MsgGPRSAPNNAME[],//GPRSAPNNAME;//       "APN"           //GPRSAPNNAME
    MsgGPRSUSERNAME[],//GPRSUSERNAME;//        "USER NAME"           //GPRSUSERNAME
    MsgCLIENTIP[],//    "CLIENT IP"
    MsgSERVERIP[],   // "SERVER IP"
    MsgGATEWAY[],    // "GATE WAY"
    MsgIPMASK[],     // "IP MASK"

#if defined(CASE_EURO)
    MsgSaveChanges[],//="SAVE CHANGES?"
#endif
    MsgBARCODE[],//=PLUBARCODE,   //"BAR-CODE"
    MsgNOFMDATA[],//=NOFMDATA,  //      "* NO FISCAL DATA  *"
    MsgRECEIPTSTART[],//=RECEPTSTART,
    MsgRECEIPTEND[],//=RECEPTEND,
    MsgTEMPRECEIPTSTART[],//Provisional receipts
    MsgTEMPRECEIPTEND[],//Provisional receipts
    MsgCOLLECTION[],    //COLLECTION
    MsgFATERROR[],
    MsgSPACEOVER[],       //"FILE OVERFLOW!"  // "�ļ��ռ�Խ��",
    MsgSRAMNOTFOUND[],
    MsgSizeOfEJ[],          //=MessageE53,
    MsgPRESSANYKEY[],
    MsgDELZBEFOR60[],//     "DEL Z BEFOR 60 ?"  //ccr2017-06-19
    MsgDELZBEFOR60ING[],//  "DEL Z BEFOR 60D>"  //ccr2017-06-19
    MsgZ60DELETED[],//   "Z DATA DELETED"
    MsgCONTINUEDEL[],//  "CONTINUE DEL Z ?"
    MsgEXPLOREZBEGIN[],   //"* EXPLORE Z REPORT-START *"
    MsgEXPLOREZEND[],   //"* EXPLORE Z REPORT-END *"

    MsgEXPLORERBEGIN[],   //"* EXPLORE RECEIPT-START *"
    MsgEXPLOREREND[],   //"* EXPLORE RECEIPT-END *"
    MsgLOGOOnHEAD[],    //LOGOOnHEAD,//LOGO ON HEAD
    MsgLOGOOnTRAIL[];   //LOGOOnTRAIL;//LOGO ON TRAIL

#endif
