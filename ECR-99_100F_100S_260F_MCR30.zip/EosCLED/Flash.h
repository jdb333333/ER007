/***c1191_08.h*Header File for c1191_08.c***************************************
Filename: c1191_08.h

Commands for the various functions
*******************************************************************************/
#define FLASH_READ_MANUFACTURER (-2)
#define FLASH_READ_DEVICE_CODE (-1)
/*******************************************************************************
Error Conditions and return values.
See end of C file for explanations and help
*******************************************************************************/
#define FLASH_BLOCK_PROTECTED (0x01)
#define FLASH_BLOCK_UNPROTECTED (0x00)
#define FLASH_BLOCK_NOT_ERASED (0xFF)
#define FLASH_SUCCESS (-1)
/*Description: This value indicates that the flash command has executed	correctly.*/
#define FLASH_POLL_FAIL (-2)
/*Description: The Program/Erase Controller algorithm has not managed to complete
the command operation successfully. This may be because the device is damaged
Solution: Try the command again. If it fails a second time then it is
likely that the device will need to be replaced.
*/
#define FLASH_TOO_MANY_BLOCKS (-3)
/*Description: The user has chosen to erase more blocks than the device has.
This may be because the array of blocks to erase contains the same block
more than once.
Solutions: Check that the program is trying to erase valid blocks. The device
will only have NUM_BLOCKS blocks (defined at the top of the file). Also check
that the same block has not been added twice or more to the array.
*/
#define FLASH_MPU_TOO_SLOW (-4)
/*Description: The MPU has not managed to write all of the selected blocks to the
		device before the timeout period expired. See BLOCK ERASE COMMAND
		section of the Data Sheet for details.
Solutions: If this occurs occasionally then it may be because an interrupt is
		occuring between writing the blocks to be erased. Search for "DSI!" in
		the code and disable interrupts during the time critical sections.
		If this error condition always occurs then it may be time for a faster
		microprocessor, a better optimising C compiler or, worse still, learn
		assembly. The immediate solution is to only erase one block at a time.
		Disable the test (by #define��ing out the code) and always call the function
		with one block at a time.
*/
#define FLASH_BLOCK_INVALID (-5)
/*Description: A request for an invalid block has been made. Valid blocks number
from 0 to NUM_BLOCKS-1.
Solution: Check that the block is in the valid range.
*/
#define FLASH_PROGRAM_FAIL (-6)
/*Description: The programmed value has not been programmed correctly.
Solutions: Make sure that the block containing the value was erased before
programming. Try erasing the block and re-programming the value. If it fails
again then the device may need to be changed.
*/
#define FLASH_OFFSET_OUT_OF_RANGE (-7)
/*Description: The address offset given is out of the range of the device.
Solution: Check that the address offset is in the valid range.
*/
#define FLASH_WRONG_TYPE (-8)
/*Description: The source code has been used to access the wrong type of flash.
Solutions: Use a different flash chip with the target hardware or contact
		STMicroelectronics for a different source code library.
*/
#define FLASH_ERASE_FAIL (-14)
/*Description: This indicates that the previous erasure of one block, many blocks
		or of the whole device has failed.
Solution: Investigate this failure further by attempting to erase each block
		individually. If erasing a single block still causes failure, then the Flash
		sadly needs replacing.
*/
#define FLASH_TOGGLE_FAIL (-15)
/*Description: The Program/Erase Controller algorithm has not managed to complete
			the command operation successfully. This may be because the device is damaged.
Solution: Try the command again. If it fails a second time then it is
			likely that the device will need to be replaced.
*/

