#define   INITAPPL_C  6
#include "king.h"
#include "exthead.h"
#include "exth.h"
#include "flowbill.h" //lyq2003
#include "fiscal.h"
#include "Ejournal.h"
#include "message.h"

extern BYTE KeyFrHost;       //    ApplVar.Key code from host computer.

#if defined(DEBUGBYPC)
#define __disable_irq() {}
#define __enable_irq() {}
#endif

/***************************************************************/
#if FLASH_AppRAM
void InitClearTotal(WORD recSize,WORD totalOff)
{
    //��ʹ��FLASH���洢�ļ�����ʱ,FLASH�еĳ�ʼֵΪ0xff,���Ա������Ϊ0
    if (recSize > totalOff)
    {
        WriteRam(PCBuffer,recSize - totalOff);
    }
}
#else
//��ʹ��SRAM���洢�ļ�����ʱ,SRAM�е�ֵ�Ѿ���0,��������InitClearTotal
#define InitClearTotal(recSize,totalOff) {}
#endif


//============================= For Cortex M3 ER-50 ================================


//���������ݺͱ�������ȫ��д���ڴ汣����
extern void UART_PutChar (BYTE c);
//��LCD����ʾ�����ݸ��Ʊ�����,
//ctrl=true,����������;ctrl=false,������ʾʱ���״̬ʱ��������
void Copy_LCD(BYTE ctrl)
{
#if !defined(DEBUGBYPC)
    if (ctrl || InActive < ACTIVE)//���Ǵ�����ʾʱ���״̬
    {
        Save_LCD(ApplVar.LCD_Operator,ApplVar.LCD_Customer);
    }
#endif
}


#if (!defined(ApplVarInSRAM) || defined(DEBUGBYPC))

/***********************************************************
 *����Ҫ�����ı���(�������ݺ���������)������籣����RAM��
 *
 * @author EutronSoftware (2014-08-07)
 *
 * @param enSave :ǿ�Ʊ�������
 ***********************************************************/
void Save_ConfigVar(bool enSave)
{
    int i;
    BYTE j;
    BYTE *applVar;

    if (MyFlags(CONFIGECR) || enSave)
    {
        applVar= (BYTE*)&ApplVar.SIZE_EXTRAM;
        CLRMyFlags(CONFIGECR);
        ApplVar.InitFlags[1] = 0;
        ApplVar.InitFlags[2]=Config_SIZE;//ccr2017-11-30
        ApplVar.InitFlags[3]=AppVAR_SIZE;//ccr2017-11-30
        for (i=0;i<Config_SIZE-sizeof(ApplVar.InitFlags);i++)
        {
            ApplVar.InitFlags[1] += *applVar;
            applVar++;
        }
        ApplVar.InitFlags[1] = ~ApplVar.InitFlags[1];
        ApplVar.InitFlags[1]++;
        ApplVar.InitFlags[0] = 0x55aa;
//......................................

        ApplVar.ApplFlag =0x5aa5;

        applVar= (BYTE*)&ApplVar.ApplFlag;

        ApplVar.ApplVarCRC = j = 0;
        for (i=0;i<AppVAR_SIZE;i++)
        {
            j += *applVar;
            applVar++;
        }
        ApplVar.ApplVarCRC = ~j;
        ApplVar.ApplVarCRC++;

        RamOffSet = RamOfApplVar;
        WriteRam((BYTE*)&ApplVar,sizeof(APPLICATION_SAVE));
    }
    else
	{
        Save_ApplRam();
	}
}

/*********************************************************
 *����������д���ڴ汣����
 *
 * @author EutronSoftware (2014-08-07)
 *
 * @param enSave :=true,ǿ�Ʊ�����������
 **********************************************************/
void Save_Config(bool enSave)
{
    int i;
    BYTE *applVar= (BYTE*)&ApplVar.SIZE_EXTRAM;

    if (MyFlags(CONFIGECR) || enSave)
    {
        CLRMyFlags(CONFIGECR);
        ApplVar.InitFlags[1] = 0;
        ApplVar.InitFlags[2]=Config_SIZE;//ccr2017-11-30
        ApplVar.InitFlags[3]=AppVAR_SIZE;//ccr2017-11-30

        for (i=0;i<Config_SIZE-sizeof(ApplVar.InitFlags);i++)
        {
            ApplVar.InitFlags[1] += *applVar;
            applVar++;
        }
        ApplVar.InitFlags[1] = ~ApplVar.InitFlags[1];
        ApplVar.InitFlags[1]++;

        RamOffSet = RamOfApplVar;
        ApplVar.InitFlags[0] = 0x55aa;

        WriteRam((BYTE*)&ApplVar,Config_SIZE);
    }

}
//////////////////////////////////////////////////////////////////////////////
//�ڹػ����ߵ���ʱ,����ҵ����صı������ݴ������ʧ�洢��
//��:�ܵ�ر�����RAM����FLASH��
//......................................................................

void Save_ApplRam()
{
    static WORD Saved1=00;

    int i;
    WORD j;

    BYTE *applVar= (BYTE*)&ApplVar.ApplFlag;


//    if (ApplRamSaved==0x5a)//�������ʱ�ظ�����
    {
        __disable_irq();    //��ֹ�жϣ����Ᵽ������е����ݱ仯
        j = 0;

        ApplVar.ApplFlag =0x5aa5;

        ApplVar.ApplVarCRC = 0;//����ApplVarCRCҲ����ͳ��,��˱�����0,

        for (i=0;i<AppVAR_SIZE;i++)
        {
            j += *applVar;
            applVar++;
        }
        ApplVar.ApplVarCRC = ~(j & 0xff);
        ApplVar.ApplVarCRC++;

        if (Saved1!=j)//�������ʱ�ظ�����
        {
            ApplRamSaved = ~ApplRamSaved;
            Saved1=j;
#if defined(DEBUGBYPC)
            RamOffSet = RamOfApplVar + Config_SIZE;
            WriteRam((BYTE*)&ApplVar.ApplFlag,AppVAR_SIZE);
#elif CASE_ER380
            SRAM_WriteBuffer((BYTE*)&ApplVar.ApplFlag,RamOfApplVar + Config_SIZE + SRAM1_ADDR,AppVAR_SIZE);
#else
            SRAM_WriteBuffer((BYTE*)&ApplVar.ApplFlag,RamOfApplVar + Config_SIZE,AppVAR_SIZE);
#endif
        }
        __enable_irq();

    }
}
#endif
//���ڴ汣������ȡ��������
BYTE Recall_Config(void)
{
#if (!defined(ApplVarInSRAM) || defined(DEBUGBYPC))
    WORD i,err;
    BYTE *applVar= (BYTE*)&ApplVar.SIZE_EXTRAM;

    __disable_irq();    //��ֹ�жϣ����Ᵽ������е����ݱ仯

    RamOffSet = RamOfApplVar;
    ReadRam((BYTE*)&ApplVar,Config_SIZE);

    err = 1;
    if (ApplVar.InitFlags[2]==Config_SIZE)
    {//ccr2017-11-30�¾ɰ汾�Ŀռ�һ��
        err = 0;
        for (i=0;i<Config_SIZE-sizeof(ApplVar.InitFlags);i++)
        {
            err += *applVar;
            applVar++;
        }

        err+=ApplVar.InitFlags[1];

        if (ApplVar.InitFlags[0] != 0x55aa)
            err=1;
    }
    __enable_irq();
    return (err==0);
#else
    return (ApplVar.InitFlags[0] == 0x55aa);
#endif
}

//---------------------------------------------------------------------
//�ٿ���ʱ,�ѱ�������ҵ����صı������ݻָ��������ռ���
//��Recall_ApplRam֮ǰ,��Recall_Config
//��:�ܵ�ر�����RAM����FLASH��
//return True:�ָ�������������false�������쳣
//......................................................................
BYTE Recall_ApplRam()
{
#if (!defined(ApplVarInSRAM) || defined(DEBUGBYPC))
    WORD i;
    BYTE err;
    BYTE *applVar= (BYTE*)&ApplVar.ApplFlag;

    __disable_irq();    //��ֹ�жϣ����Ᵽ������е����ݱ仯

    err = 0;
    if (ApplVar.InitFlags[3]!=AppVAR_SIZE)
    {
        memset((BYTE*)&ApplVar.ApplFlag,0,AppVAR_SIZE);
    }
    else
    {
        RamOffSet = RamOfApplVar + Config_SIZE;

        ReadRam((BYTE*)&ApplVar.ApplFlag,AppVAR_SIZE);

        for (i=0;i<AppVAR_SIZE;i++)
        {
            err += *applVar;
            applVar++;
        }

        if (err || ApplVar.ApplFlag != 0x5aa5)
        {
            err=1;
//            RJPrint(0,"Error when Recall Memory!");//testonly
           //memset((char*)ApplVar.ZCount,0,AppVAR_SIZE);
        }
    }
    __enable_irq();

    return (err==0);
#else
    return (ApplVar.ApplFlag == 0x5aa5);
#endif
}
//////////////////////////////////////////////////////////////////////////

void InitPlu()
{
    BYTE i;

    memcpy(&ApplVar.Plu, &Def.Plu,sizeof(ApplVar.Plu));
#if defined(FOR_DEBUG)
    if (ApplVar.AP.Plu.RandomSize)
        ApplVar.AP.Plu.RNumber = ApplVar.AP.Plu.Number % 100;//ApplVar.AP.Plu.Number;	 set all used
#endif
    for (ApplVar.PluNumber = 0; ApplVar.PluNumber < ApplVar.AP.Plu.Number; ApplVar.PluNumber++)
    {
        ApplVar.Plu.Dept = (ApplVar.PluNumber % ApplVar.AP.Dept.Number);
        ApplVar.Plu.OFFIndex = 1;
        if (ApplVar.AP.Plu.CapSize)
            WORDtoASC(&ApplVar.Plu.Name[7], ApplVar.PluNumber + 1);
        if (ApplVar.AP.Plu.RandomSize)
            WORDtoBCD(ApplVar.Plu.Random, ApplVar.PluNumber + 1);
        if (ApplVar.AP.Plu.PriceSize)
        {
            for (i = 0; i < ApplVar.AP.Plu.Level; i++)
                WORDtoBCD(ApplVar.Plu.Price[i], 12354);
        }
        if (ApplVar.AP.Plu.Cost)
            WORDtoBCD(ApplVar.Plu.Cost, 12000);
       ApplVar.Plu.Inventory.Value[3]=0x10;

        WritePlu();
        InitClearTotal(ApplVar.AP.Plu.RecordSize, ApplVar.AP.Plu.TotalOffSet);
    }
}


void InitDept()
{
    short i;
    char sName[25];

    strcpy(ApplVar.Dept.Name,"DEPT");
    memcpy(&ApplVar.Dept, &Def.Dept,sizeof(ApplVar.Dept));
    for (ApplVar.DeptNumber = 0; ApplVar.DeptNumber < ApplVar.AP.Dept.Number; ApplVar.DeptNumber++)
    {
        ApplVar.Dept.Group = ApplVar.DeptNumber & 0x07;
        if (ApplVar.AP.Dept.RandomSize)
            WORDtoBCD(ApplVar.Dept.Random, ApplVar.DeptNumber + 1);
        if (ApplVar.AP.Dept.PriceSize)
            WORDtoBCD(ApplVar.Dept.Price, 0);
        for (i=0;i<ApplVar.AP.Dept.PriMaxSize;i++)
            ApplVar.Dept.PriceMax[i] = 0x99;

        if (ApplVar.AP.Dept.CapSize)
        {
            WORDtoASCL(&ApplVar.Dept.Name[3], ApplVar.DeptNumber + 1);
        }
        i=(ApplVar.DeptNumber % ApplVar.AP.Tax.Number);
        ApplVar.Dept.Tax = 1<<i;
        WriteDept();
        InitClearTotal(ApplVar.AP.Dept.RecordSize, ApplVar.AP.Dept.TotalOffSet);
    }
}


void InitGroup()
{
    memcpy(&ApplVar.Group,&Def.Group,sizeof(ApplVar.Group));
    //GetOpt(30, &ApplVar.Group.Family, 99);
    for (ApplVar.GroupNumber = 0; ApplVar.GroupNumber < ApplVar.AP.Group.Number; ApplVar.GroupNumber++)
    {
        if (ApplVar.AP.Group.CapSize)
            WORDtoASC(&ApplVar.Group.Name[7], ApplVar.GroupNumber + 1);
        WriteGroup();
        InitClearTotal(ApplVar.AP.Group.RecordSize, ApplVar.AP.Group.TotalOffSet);

    }
}


void InitTender()
{
    for (ApplVar.TendNumber = 0; ApplVar.TendNumber < ApplVar.AP.Tend.Number; ApplVar.TendNumber++)
    {
        memcpy(&ApplVar.Tend,(CONSTCHAR *)&Def.Tend+ApplVar.TendNumber*sizeof(ApplVar.Tend),sizeof(ApplVar.Tend));    /* copy default */
        WriteTender();
        InitClearTotal(ApplVar.AP.Tend.RecordSize, ApplVar.AP.Tend.TotalOffSet);
    }
}


void InitDrawer()
{
    for (ApplVar.DrawNumber = 0; ApplVar.DrawNumber < ApplVar.AP.Draw.Number; ApplVar.DrawNumber++)
    {
        memcpy(&ApplVar.Draw, (CONSTCHAR *)&Def.Draw+ApplVar.DrawNumber*sizeof(ApplVar.Draw),sizeof(ApplVar.Draw));
        WriteDrawer();
        InitClearTotal(ApplVar.AP.Draw.RecordSize, ApplVar.AP.Draw.TotalOffSet);
    }
}



void InitCorrec()
{
    for (ApplVar.CorrecNumber = 0; ApplVar.CorrecNumber < ApplVar.AP.Correc.Number; ApplVar.CorrecNumber++)
    {
        memcpy(&ApplVar.Correc, (CONSTCHAR *)&Def.Correc+ApplVar.CorrecNumber*sizeof(ApplVar.Correc),sizeof(ApplVar.Correc));
        WriteCorrec();
        InitClearTotal(ApplVar.AP.Correc.RecordSize, ApplVar.AP.Correc.TotalOffSet);
    }
}


void InitCurr()
{
    for (ApplVar.CurrNumber = 0; ApplVar.CurrNumber < ApplVar.AP.Curr.Number; ApplVar.CurrNumber++)
    {
        memcpy(&ApplVar.Curr, (CONSTCHAR *)&Def.Curr+ApplVar.CurrNumber*sizeof(ApplVar.Curr),sizeof(ApplVar.Curr));
        WriteCurr();
        InitClearTotal(ApplVar.AP.Curr.RecordSize, ApplVar.AP.Curr.TotalOffSet);
    }
}


void InitDisc()
{
    for (ApplVar.DiscNumber = 0; ApplVar.DiscNumber < ApplVar.AP.Disc.Number; ApplVar.DiscNumber++)
    {
        memcpy(&ApplVar.Disc,(CONSTCHAR *)&Def.Disc+ApplVar.DiscNumber*sizeof(ApplVar.Disc),sizeof(ApplVar.Disc));
        WriteDisc();
        InitClearTotal(ApplVar.AP.Disc.RecordSize, ApplVar.AP.Disc.TotalOffSet);
    }
}

void InitPoRa()
{
    for (ApplVar.PoRaNumber = 0; ApplVar.PoRaNumber < ApplVar.AP.PoRa.Number; ApplVar.PoRaNumber++)
    {
        memcpy(&ApplVar.PoRa,(CONSTCHAR *)&Def.PoRa+ApplVar.PoRaNumber*sizeof(ApplVar.PoRa),sizeof(ApplVar.PoRa));
        WritePoRa();
        InitClearTotal(ApplVar.AP.PoRa.RecordSize, ApplVar.AP.PoRa.TotalOffSet);
    }
}


void InitTax()
{
    for (ApplVar.TaxNumber = 0; ApplVar.TaxNumber < ApplVar.AP.Tax.Number; ApplVar.TaxNumber++)
    {
        memcpy(&ApplVar.Tax,(CONSTCHAR *)&Def.Tax+ApplVar.TaxNumber*sizeof(ApplVar.Tax),sizeof(ApplVar.Tax));
        WriteTax();
        InitClearTotal(ApplVar.AP.Tax.RecordSize, ApplVar.AP.Tax.TotalOffSet);
    }
}


void InitPbF()
{
    for (ApplVar.PbFNumber = 0; ApplVar.PbFNumber < ApplVar.AP.Pb.Number; ApplVar.PbFNumber++)
    {
        memcpy(&ApplVar.PbF ,(CONSTCHAR *)&Def.PbF+ApplVar.PbFNumber*sizeof(ApplVar.PbF),sizeof(ApplVar.PbF));
        WritePbF();
        InitClearTotal(ApplVar.AP.Pb.RecordSize, ApplVar.AP.Pb.TotalOffSet);
    }
    if ((ApplVar.AP.Pb.Random & 0x0f) || ApplVar.AP.Pb.Text)
    {
        MemSet(ApplVar.PB.Text, sizeof(ApplVar.PB.Text), ' ');
        CopyFrStr(ApplVar.PB.Text, Prompt.Caption[ItemPrompt23]);
        for (ApplVar.PbNumber = 1; ApplVar.PbNumber <= ApplVar.AP.Pb.NumberOfPb; ApplVar.PbNumber++)
        {
            if (ApplVar.AP.Pb.Random & 0x0f)
                WORDtoBCD(ApplVar.PB.Random, ApplVar.PbNumber);
            if (ApplVar.AP.Pb.Text)
                WORDtoASC(&ApplVar.PB.Text[6], ApplVar.PbNumber);
            PbTotal(ApplVar.PbNumber, 1);   /* write info */

#if FLASH_AppRAM
            GetPbtOffSet(ApplVar.PbNumber);
            RamOffSet += ApplVar.AP.Pb.TotalOffSet;
            InitClearTotal(ApplVar.AP.Pb.PBTRecordSize, ApplVar.AP.Pb.PBTTotalOffset);
#endif

        }
        ApplVar.PbNumber = 0;
    }
}



void InitClerk()
{
	int l,i;
    memcpy(&ApplVar.Clerk,&Def.Clerk,sizeof(ApplVar.Clerk));
	l = strlen(ApplVar.Clerk.Name);
    for (ApplVar.ClerkNumber = 1; ApplVar.ClerkNumber <= ApplVar.AP.Clerk.Number; ApplVar.ClerkNumber++)
    {
#if (0)//ccr2017-06-01 defined(CASE_EURO)
        memset(ApplVar.Clerk.Name,0,sizeof(ApplVar.Clerk.Name));
        WORDtoASCL(ApplVar.Clerk.Name, ApplVar.ClerkNumber);
#else
        if (l<sizeof(ApplVar.Clerk.Name)-3)
            WORDtoASCL(ApplVar.Clerk.Name+l, ApplVar.ClerkNumber);
#endif
        WriteClerk();
    }
}



void InitSalPer()
{
	int l;
    memcpy(&ApplVar.SalPer,&Def.SalPer,sizeof(ApplVar.SalPer));
	l = strlen(ApplVar.SalPer.Name);
    for (ApplVar.SalPerNumber = 1; ApplVar.SalPerNumber <= ApplVar.AP.SalPer.Number; ApplVar.SalPerNumber++)
    {
        if (l<sizeof(ApplVar.SalPer.Name)-3)
            WORDtoASCL(ApplVar.SalPer.Name+l, ApplVar.SalPerNumber);
        WriteSalPer();
    }
}


void InitModifier()
{
    memcpy(&ApplVar.Modi,&Def.Modi,sizeof(ApplVar.Modi));
    for (ApplVar.ModiNumber = 0; ApplVar.ModiNumber < ApplVar.AP.Modi.Number; ApplVar.ModiNumber++)
    {
        WORDtoASC(&ApplVar.Modi.Name[7], ApplVar.ModiNumber + 1);
        WriteModi();
    }
}


void InitOFFPrice()
{
#if offNumber
    memcpy(&ApplVar.OFFPrice, &Def.OFFPrice,sizeof(ApplVar.OFFPrice));
    for (ApplVar.OFFNumber = 0; ApplVar.OFFNumber < ApplVar.AP.OFFPrice.Number; ApplVar.OFFNumber++)
    {
        WriteOFFPrice();
    }
#endif
}

void InitPort()
{

    for (ApplVar.PortNumber = 0; ApplVar.PortNumber < ApplVar.AP.Port.Number; ApplVar.PortNumber++)
    {
        memcpy(&ApplVar.Port, &Def.Port,sizeof(ApplVar.Port));
        if (ApplVar.PortNumber == 1)//ccr2017-09-13
            ApplVar.Port.Type = PORT4BARCODE;
        WritePort();
    }
}


void InitAgree()
{
    memcpy(&ApplVar.Agree, &Def.Agree,sizeof(ApplVar.Agree));
    for (ApplVar.AgreeNumber = 0; ApplVar.AgreeNumber < ApplVar.AP.Agree.Number; ApplVar.AgreeNumber++)
    {
        WriteAgree();
    }
}


void InitGraph()
{
    short i;
    for (i = 0; i<GRAFESTMAX+2;i++)
        memcpy(&ApplVar.Graph[i], &Def.Graph,sizeof(Def.Graph));
}

void ClearApplMemory()
{
    MemSet(ApplVar.ZCount, (BYTE *)&ApplVar.ApplVarCRC + sizeof(ApplVar.ApplVarCRC) - (BYTE *)ApplVar.ZCount, 0) ;//ccr091027
}

//����sizeof(APPLICATION_SAVE),������StartAddress
//toActual:=true,ת��Ϊʵ�ʵ�ַ,StartAddress[AddrEndP]=sizeof(APPLICATION_SAVE);
//     =false,ת��Ϊ��Ե�ַ,StartAddress[AddrEndP]=0
//return:=true,��ַδԽ��;=false,��ַԽ��
BYTE ResetStartAddress(BYTE toActual)
{
    int i;
    switch (toActual)
    {
        case true:
            if (ApplVar.AP.StartAddress[0]==0)
            {
                for (i=0;i<AddrMAX;i++)
                {
                    ApplVar.AP.StartAddress[i]+=RamOfTotal;
                }
            }
            if (ApplVar.AP.StartAddress[AddrEndP]>=ApplVar.SIZE_EXTRAM)
                return false;
            else
                return true;
        case false:
            if (ApplVar.AP.StartAddress[0]>=RamOfTotal)
            {
                for (i=0;i<AddrMAX;i++)
                {
                    ApplVar.AP.StartAddress[i]-=(RamOfTotal);
                }
            }
            if (ApplVar.AP.StartAddress[AddrEndP]>=ApplVar.SIZE_EXTRAM-RamOfTotal)
                return false;
            else
                return true;
        default:
           break;
    }
    return true;
}
/**************************************************************/
void InitApplication()
{
    UnLong  sAddr,sCmp;
    bool    sSetDate=false; //ccr2018-03-30,=falseʱ,��Ҫ�����������¼��FM��
    bool    ApplRamOK;//ccr2018-03-30,=falseʱ,��Ҫ��CMOS Error��¼��FM��
    bool    sRePrint=false;//�Ƿ���Ҫ��ӡ�ػ�ǰΪ��ӡ��ϵ�����
    bool    sEcrUsed;//�����Ƿ�ʹ�ù������ұ�������������Ƿ�����
    BYTE    sFMPullOut;
    WORD    ReceiptNum[3];
	char 	*cpFr,*cpTo;


    KeyFrHost=0xff;
//    PutsO("Startup ECR>>>>");//ccr2017-06-14 testonly

#if (!defined(ApplVarInSRAM) || defined(DEBUGBYPC))
    sEcrUsed = Recall_Config() && Recall_ApplRam();//ccr2018-01-30//�ָ���������
#else
    sEcrUsed=(ApplVar.ApplFlag==0x5aa5) && (ApplVar.InitFlags[0]==0x55aa);
#endif

#if !defined(DEBUGBYPC)
    //ccr2018-01-31>>>>>>>>>>>>>>>>>>>
    if (sEcrUsed && (sRePrint=TaskForReceipt())==false)//����ӡ�Ĳ����������վ� (sRePrint)
    //if (sEcrUsed && (BIT(ApplVar.Fiscal_PrintFlag,(BIT0 | BIT7))!=(BIT0 | BIT7)))//ccr2018-03-08 �Ƿ��ӡ�վ�ʱ��ֽ
        ApplVar.PoolPopOut=ApplVar.PoolPushIn;
    //ccr2018-01-31<<<<<<<<<<<<<<<<<<<
#endif
    ClearVirtualInput();

    ApplRamOK=(ApplVar.ApplFlag==0x5aa5) && (ApplVar.InitFlags[0]==0x55aa);//ccr2018-01-19 when we reset the machine it must not lose anything

    if (ApplRamOK)
    {
        ReceiptNum[FRECEIPTS]=ApplVar.FisNumber.ReceiptNum[FRECEIPTS];//ApplVar.SaleReceipts
        ReceiptNum[NRECEIPTS]=ApplVar.FisNumber.ReceiptNum[NRECEIPTS];
        ReceiptNum[TRECEIPTS]=ApplVar.FisNumber.ReceiptNum[TRECEIPTS];

//#if (sizeof(SDRW_Buffer)<sizeof(WORD)*ZSIZE+sizeof(DWORD)+sizeof(BYTE)+sizeof(SHA1Context)+SHA1HashSize)
//#error "SDRW_Buffer ERROR!"
//#endif
//ccr2017-04-25 !!!!!ʹ��SDRW_Buffer���ָ�����,���붨���㹻��Ŀռ�,�����ݻָ�ǰ,SDRW_Buffer��������������; !!!!!!!!!
		cpFr=(char*)&ApplVar.ZCount;
		cpTo=(char*)&ApplVar.SHA1_Error;
        memcpy(SDRW_Buffer,ApplVar.ZCount,cpTo-cpFr);
    }
    else
    {
        cpFr=NULL;//Ϊ�»���,�ڴ�����Ϊ��
    }

//sEcrUsed    if (sEcrUsed)//����������ȷʱ
//sEcrUsed        sEcrUsed = (ApplVar.AP.StartAddress[0]==Default.StartAddress[0]);//�ж��ļ���ַ�ռ��Ƿ��쳣

    sFMPullOut=ApplVar.FMPullOut[NOFM_FLAG];

#if defined(CASE_GREECE)
    if (MACSwitch && !CheckPWD((char*)PWD4Technician))
    {
        PutsO(Msg[CWXXI36].str);
        do {
            MACSwitch=Bios_TestMAC();
        }while (MACSwitch);
    }
    //ccr2018-01-19 when we insert the jumper and turn on the machine it should ask for the technician password
    // and after we insert the password it will display to change time and date >>>>>>>
    if (MACSwitch)
    {//�ӵ��ʼ��ʱ,�����������ں�ʱ��
        sSetDate=true;
        GetTimeDate(&Now);              //* read timer
        do {
            ApplVar.ErrorNumber = 0;
            Initial_DateTime(0);//��ʾ��������
            if (GetStrFromKBD('9',(char*)Msg[RIQI].str,NULL,8,0,NO)>0)
            {
                Initial_DateTime(1);
                if (GetStrFromKBD('9',(char*)Msg[SHIJIAN].str,NULL,6,0,NO)>0)
                    Initial_DateTime(2);
            }
        } while (ApplVar.ErrorNumber);
    }
    while (Bios_TestMAC())
    {
        PutsM((char*)MsgREMOVEMAC);
    }
#endif
    //ccr2018-01-19<<<<<<<<<<<<<<<<<<
    if (MyFlags(NEWFIRMWARE) && !sEcrUsed)//Ϊ�����³���ʱ,�ұ���������쳣
			MACSwitch=1;
    if (MACSwitch || !ApplRamOK)//ccr2014-07-31 �ָ���������
    {//Ϊ�»�����ӵ��ʼ��
        if(!ApplRamOK)//ccr2018-01-19 when we reset the machine it must not lose anything>>>>>>
        {//������������ļ�,ʹ��Ĭ�����ݳ�ʼ������
            sEcrUsed=0;//ccr2018-01-29
            ClearApplMemory();

            memcpy(&ApplVar.TXT, &DefaultText, sizeof(struct APPTEXT));
            memcpy(&ApplVar.AP, &Default, sizeof(struct APPLICATION));

            GetTimeDate(&Now);              //* read timer
            if (Now.year<=0x2009)
            {//Ϊ�»���,���û��������ں�ʱ��
                do
                {
                    ApplVar.ErrorNumber = 0;
                    Initial_DateTime(0);//��ʾ��������
                    if (GetStrFromKBD('9',(char*)Msg[RIQI].str,NULL,8,0,NO)>0)
                    {
                        sSetDate=true;
                        Initial_DateTime(1);
                        if (GetStrFromKBD('9',(char*)Msg[SHIJIAN].str,NULL,6,0,NO)>0)
                            Initial_DateTime(2);
                    }
                } while (ApplVar.ErrorNumber);
            }

            ClsXRam();
            InitSysFlag();

    #if DD_FISPRINTER == 0
            MaskKeyBoard(1);
    #endif

            sAddr = ApplVar.SIZE_EXTRAM;
            if (sAddr && (sAddr > ApplVar.AP.StartAddress[AddrEndP] - SIZE_FLOWRAM))
            {//���¼����ڴ��п����ɵĵ�Ʒ��Ŀ
                sAddr -= ApplVar.AP.StartAddress[AddrEndP] - SIZE_FLOWRAM;

                sAddr /= pluRecordSize;
                sCmp = sAddr;
                sAddr *= pluRecordSize;
                ApplVar.AP.Plu.Number += sCmp;

                for (sCmp = AddrPLU+1;sCmp<AddrMAX;sCmp++)
                    ApplVar.AP.StartAddress[sCmp] += sAddr;
            }
            else
            {
                PutsO("RAM OUT,HALT!");
                while (1);
            }


            PutsO(Msg[INITWAITING].str);

            COMPUTER = BALANCE = 0;//Lyq modify 2003\10\27
            BARCODE &= 0xf8;

            PutsO(MSG_INITPORT);InitPort();SetPortForAppl();

            memset(PCBuffer,0,sizeof(PCBuffer));

    #if FLASH_AppRAM
            RamOffSet = ApplVar.AP.StartAddress[AddrTotl];

            InitClearTotal(ApplVar.AP.StartAddress[AddrGroup]-ApplVar.AP.StartAddress[AddrTotl],0);
    #endif

    #if(CASE_RAMBILL)
            PutsO(MSG_INITJOURNAL);Init_Flow();
    #endif
            PutsO(MSG_INITTENDER);    InitTender();
            PutsO(MSG_INITPORA);    InitPoRa();
            PutsO(MSG_INITDRAWER);    InitDrawer();
            PutsO(MSG_INITPLU);    InitPlu();
            PutsO(MSG_INITDEPT);    InitDept();
            PutsO(MSG_INITGROUP);    InitGroup();
            PutsO(MSG_INITCORREC);    InitCorrec();
            PutsO(MSG_INITCURR);    InitCurr();
            PutsO(MSG_INITDISCOUNT);      InitDisc();
            PutsO(MSG_INITTAX);     InitTax();
            if (ApplVar.AP.Pb.NumberOfPb)
            {
                PutsO(MSG_INITPBF);     InitPbF();
            }
            PutsO(MSG_INITOPERATOR);      InitClerk();
            PutsO(MSG_INITSALPER);      InitSalPer();
            PutsO(MSG_INITMODIFIER);   InitModifier();
            PutsO(MSG_INITOFFPRICE);   InitOFFPrice();
            PutsO(MSG_INITAGREE);       InitAgree();
            PutsO(MSG_INITGRAPHIC);      InitGraph();

#if (1)
            ApplVar.AP.NetWork=Default.NetWork;
#else
            ApplVar.AP.NetWork.IPAddress[0]=0;//192;
            ApplVar.AP.NetWork.IPAddress[1]=0;//168;
            ApplVar.AP.NetWork.IPAddress[2]=0;// 1;
            ApplVar.AP.NetWork.IPAddress[3]=0;//5;
#if defined(CASE_GPRS)
            ApplVar.AP.NetWork.APN[0]=0;//ccr2015-03-11
            ApplVar.AP.NetWork.UserName[0]=0;//ccr2015-03-11
            ApplVar.AP.NetWork.Password[0]=0;//ccr2015-03-11
#endif
#endif
            GetMMCSize(0);//ccr2017-06-22��ȡSD���ռ�
        }//sEcrUsed
        else//ccr2018-03-27>>>>>Ϊ�̽���MAC
        {
           memset(&ApplVar.FiscalBuff.Fis_ClearRecord,0xff,FISRECORDLEN);
           if (!Bios_FM_CheckPresence() || !Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,FISDATAADDR,FISRECORDLEN) || CLONG(ApplVar.FiscalBuff.Fis_ClearRecord.FDate)==0xFFFFffff)
           {
              ClearApplMemory();
              ApplVar.ZReport = 1;//
           }
           if (ApplVar.ZReport == 1 && !ApplVar.FRegi)//MACSwitch=1
           {//������ʱ,�����������
               //ClsXRam();
               ApplVar.PoolPopOut=ApplVar.PoolPushIn=0;
               sEcrUsed=0;//ccr2018-01-29
               ClearAllReport();
               ApplVar.CentralLock = RG;   //ccr Set REG mode for the default mode
               ApplVar.FRegi = ApplVar.FTend = ApplVar.FSub = ApplVar.FTrain = 0;
               ApplVar.MyFlags=0;//ccr2017-05-23
           }//ccr2018-01-19<<<<<<<
           else
               sEcrUsed=1;//ccr2018-01-29
        }//ccr2018-03-27<<<<<

        if (!sEcrUsed)
        {
            ApplVar.ClerkNumber = 0;
            ApplVar.SalPerNumber = 0;
            ApplVar.CentralLock = RG;   //ccr Set REG mode for the default mode
            ApplVar.ZCount[0]=ApplVar.ZCount[1] = 1;
            if (ApplVar.AP.Clerk.Number!=0)
            {
                ApplVar.ClerkNumber = 1;
                ReadClerk();
                SetTrainMode();

                //		ApplVar.Key.Code = CLERK;
                //		ApplVar.Entry = ONE;
                //		Appl_NumberEntry = 1;
                //		SelectClerk(0);
            }
            if (ApplVar.AP.SalPer.Number!=0)
            {
                ApplVar.SalPerNumber = 1;
                ReadSalPer();
            }
            ApplVar.ZReport = 1 ;// ccr090507 ��ʾ�����ӡZ���� //
            SETBIT(ARROWS, BIT0);    /* set  RON */
        }


        MACSwitch = 1;

        Save_ConfigVar(true);

#if (!defined(DEBUGBYPC)) && (FLASH_AppRAM==1)
        FlashErase = 1;//��ʾFLASH��д�г�ʼ������,flash�ǿ�
#endif

        if (!sRePrint)
        {
            RJPrint(0,Msg[INITWAITING].str);
            PrintVersion(); //cc 20070930
        }
    }
    else//<<<<if (MACSwitch || !sEcrUsed || !ApplRamOK)//ccr2014-07-31 �ָ���������
    {// MACSwitch = 0,sEcrUsed=true;//It's not the first time for use
        SetPortForAppl();
        CLRMyFlags(REBOOTMUST);//ccr2017-12-25
    }

#if defined(ApplVarInSRAM)
    ApplVar.ApplFlag =0x5aa5;
    ApplVar.InitFlags[0] = 0x55aa;
    ApplVar.InitFlags[1] = 0xAA55;
    ApplVar.InitFlags[2]=Config_SIZE;//ccr2017-11-30
    ApplVar.InitFlags[3]=AppVAR_SIZE;//ccr2017-11-30
#endif

    //������������״̬(���ָ��ػ�ǰ����ʾ)
    ApplVar.CentralLock = RG;
    Appl_MaxEntry = PRTLEN*2;
    strcpy(ModeHead,DText[DTEXT_REG]);

    SetInputMode(0);

    //;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

    ApplVar.ErrorNumber = 0;

    //ccr2017-04-24<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//    PutsO("Check Fiscal>>>>");//ccr2017-06-14 testonly
    ApplVar.FMPullOut[NOFM_FLAG] = sFMPullOut;
    CheckFiscal(!MACSwitch);

    //ccr2017-06-08 ����CurrentTaxRate���ܱ��ƻ�,����ڴ˴�����װ��CurrentTaxRate
    if (!MACSwitch)
    {
        for(ApplVar.TaxNumber=0;ApplVar.TaxNumber<ApplVar.AP.Tax.Number;ApplVar.TaxNumber++)
        {
            ReadTax();
            CWORD(ApplVar.CurrentTaxRate[ApplVar.TaxNumber][0]) = CWORD(ApplVar.Tax.Rate[0]);
        }
    }
    //ccr2017-06-08<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    //ccr2017-04-24�ӵ��ʼ��ʱ,�����������>>>>>>>>>>>

    if (cpFr!=NULL && MACSwitch==1)
    {
        ApplVar.FisNumber.ReceiptNum[FRECEIPTS]=ReceiptNum[FRECEIPTS];//ApplVar.SaleReceipts
        ApplVar.FisNumber.ReceiptNum[NRECEIPTS]=ReceiptNum[NRECEIPTS];
        ApplVar.FisNumber.ReceiptNum[TRECEIPTS]=ReceiptNum[TRECEIPTS];
#ifdef CASE_FATFS_EJ
        memcpy(ApplVar.ZCount,SDRW_Buffer,cpTo-cpFr);
#if defined(CASE_GREECE)//ccr2018-01-11Ҫǩ��,�����ļ�
        sprintf(ApplVar._s_txt,"%d:/GGPS/%s/%04d/_s.txt",
                            ApplVar.FS_Current,
                            ApplVar.ApprovalCode,
                            ApplVar.ZCount[FISCALZNUM]);
#endif
        //����0269170320/TLD66000003/1703200269/0001/_a.txt�ļ�
        sprintf(ApplVar._a_txt,"%d:/%04d%06d/%s/%06d%04d/%04d/_a.txt",
                                ApplVar.FS_Current,
                                ApplVar.ZCount[FISCALZNUM],
                                ApplVar.ZDate,
                                ApplVar.ApprovalCode,
                                ApplVar.ZDate,
                                ApplVar.ZCount[FISCALZNUM],
                                ApplVar.FisNumber.ReceiptNum[FRECEIPTS]);//ApplVar.SaleReceipts
        ff_SelectSDisk(ApplVar.FS_Current);    //��ǰ�ļ�ϵͳ
#endif
    }

#ifdef CASE_FATFS_EJ
//ccr2017-06-13    if (Bios(BiosCmd_SD_Init, SDRW_Buffer,0,0))
//ccr2017-06-15    PutsO("Get EJ Size>>>>");//ccr2017-06-14 testonly
//ccr2017-06-15 ��CheckEJ���м��    GetMMCSize(0);//��ʱ�ϳ�
#endif

    CheckFisError();

#if defined(CASE_GREECE)//ccr2018-03-30>>>>>>>>>>>>>>>>>>>>
    if (ApplVar.FiscalFlags <= MUSTINITEJ)
    {
       if (sSetDate)//��¼��������
          Fiscal_AddDatetimeChg(2);
       if (!ApplRamOK)//��¼CMOSError
          Fiscal_AddDisconnect(FISCMOSERRCOUNT);

    }
#endif//ccr2018-03-30<<<<<<<<<<<<<<<<<<<<

    if (!sRePrint && MACSwitch && (ApplVar.FiscalFlags == FISCALOK || ApplVar.FiscalFlags == FMMACFULL))
    {//Ϊ�ӵ縴λʱ,��ӡ˰����Ϣ

        StoreEJEnd();

        PrintLine('=');
        memset(SysBuf,' ',PRTLEN);
        SysBuf[0]='F';      SysBuf[1]='M';
        CopyFrStr(SysBuf+3, Msg[KAHAO].str);
        memcpy(SysBuf+15, (CONSTCHAR*)ApplVar.Fis_Header.FFisCode,strlen(ApplVar.Fis_Header.FFisCode) );
        SysBuf[PRTLEN] = 0;
        RJPrint(0, SysBuf);
        PrintFiscalAttribute();

#if (ENCUTTER==0)
        RFeed(3);
#endif

        MACSwitch = 0;//ccr20131107,��������EJ���
        ApplVar.FReceipt = 1;
        ReceiptIssue(BIT0+BIT2);       //ccr070609pm
        ApplVar.FReceipt = 0;//ccr2017-04-26 ����REGģʽ�²���ӡƱͷ
    }

#ifndef ReceiptMAX
    ReceiptMAX=(((ULONG)ApplVar.AP.Flag[57])<<24) +
                (((ULONG)ApplVar.AP.Flag[56])<<16) +
                (((ULONG)ApplVar.AP.Flag[55])<<8) + ApplVar.AP.Flag[54];
#endif

    ARROWS = 0x01;     //* Clear Arrows and receipt on
    MACSwitch = 0;
//	DENSITY = ApplVar.AP.Config.RDensity;
    if (BIT(KEYTONE,BIT0))
    {
        Bios_1(BiosCmd_AutoClickOff);
    }
    else
    {
        Bios_1(BiosCmd_AutoClickOn);
    }
    CHARSET &= 0x0f;
    CHARSET += ApplVar.AP.Config.Country * 0x10;     //* set char set
    ApplVar.AmtDecimal = NO_DECIMAL;
    Prefix1 = PREFIX_1;
    Prefix2 = PREFIX_2;
//* cortex m3
    if (!BIT(KEYTONE, BIT3))
    {
        ApplVar.PrintLayOut = 0x07;
        PrintMessage(44);     //* print init
    }
//*/

#if (defined(FISCAL) || defined(CASE_FATFS_EJ))
#if defined(FISCAL)
    if (ApplVar.FiscalFlags == FMISNEW || ApplVar.FiscalFlags == MUSTINITEJ || ApplVar.FiscalFlags == FMMACFULL)  // liuj 0611
#elif (defined(CASE_FATFS_EJ))
    if (ApplVar.FiscalFlags == MUSTINITEJ )  // liuj 0813
#endif
    {//Ϊ��˰�ؿ�,�Զ���������״̬,���տ������˰�س�ʼ��
        Appl_MaxEntry = 6;
        ApplVar.CentralLock= SET;
        ApplVar.FuncOnEnter = 0;
        strcpy(ModeHead,DText[DTEXT_SET]);//program mode
    }
#endif

#if DD_CHIPC
    memset(&IC,0,sizeof(struct ICStruct));//ccr chipcard

#if (CASE_MFRIC==1)
    if (ApplVar.MFRCardPort && BIT(ApplVar.ICCardSet.Options,IC_CHIPCARD))
    {
        Delay(ASECOND);//delay
        PutsO(Msg[WAITEICCARD].str);
        if ( mifs_config()!=0)//MI_OK
        {
            ApplVar.ErrorNumber=CWXXI72 - CWXXI01 + 1;
            ApplVar.MFRCardPort = 0;
        }
        else
            PutsO(Msg[ICCARDOK].str);
    }
#endif

#endif

    ClearEntry();
    CCDCounter = BalCounter = PCCounter = 0;
    DialTime = DialSkiped = 0;//flags
    Appl_ProgLine = Appl_ProgStart = Appl_ProgType = 0;               /* programming type status */

    PutsPre(0,ModeHead,((ApplVar.CentralLock==RG)||(ApplVar.CentralLock==MG))?(0):('>'));
    ClearLine2();

    DeptPluKeysCount();
#if (CASE_MFRIC==1)
    if (ApplVar.MFRCardPort)
    {
        Delay(ASECOND);//delay for
        if ( mifs_config()!=0)//MI_OK)
        {
            ApplVar.ErrorNumber=CWXXI72 - CWXXI01 + 1;
            CheckError(0);
            ApplVar.MFRCardPort = 0;
        }
    }
#endif

    ApplVar.FBalance = 0;       //cc 2006-06-29 for Balance
    ApplVar.PrintLayOut = 0x03;     /* R & J */

#if PC_EMUKEY==1
    KeyFrHost = 0xff;
#endif

    Bell(2);

    if (ApplVar.ZReport == 1)
    {
        CheckTime(0x80);
        ApplVar.FisNumber.LastZDate = EncordBCDDate(Now.year & 0xff, Now.month, Now.day);    //    liuj0831
    }

#if DD_FISPRINTER
    LogDefine.RecNumTo = 0;
    SelectCounter=0;
#endif

    CheckFisError();

#if defined(DEBUGBYPC)
    GetMMCSize(0);//�ָ�ʣ��ռ�Ϊԭʼֵ
    //��������,�������ڵ�������
    if (ApplVar.ZDate)
    {
        Now.year=0x2000+DECtoBCD(ApplVar.ZDate/10000);
        Now.month=DECtoBCD((ApplVar.ZDate/100)%100);
        Now.day=DECtoBCD(ApplVar.ZDate%100);
        Now.hour=0x12;Now.min=0x12;Now.sec=0x12;
        SetTimeDate(&Now);
    }
#else
    //ccr20131015>>>>>>
    pwrGetStatus(GET_VRTC_STATUS);
    if (BATTERYTooLow(PWR_BUT_WARNING2))
    {
#if defined(CASE_GREECE)//ccr2018-03-30>>>>>>>>>>>>>>>>>>>>
       if (ApplRamOK && (ApplVar.FiscalFlags <= MUSTINITEJ))//��¼CMOSError
          Fiscal_AddDisconnect(FISCMOSERRCOUNT);
#endif
        Bell(2);
#if (DISP2LINES)
        Puts1_Right(BUTTONBATLOW);
#else
        PutsO(BUTTONBATLOW);
#endif
    }

#if POWERCTRL
    pwrGetStatus(GET_VIN_STATUS);
    while (BATTERYTooLow(PWR_WARNING2 | PWR_BY_BAT))
    {
        Bell(1);
#if (DISP2LINES)
        Puts1_Right(CaptionCWXXI95);
#else
        PutsO(CaptionCWXXI95);
#endif
        Delay(500);
        pwrGetStatus(GET_VIN_STATUS);
    }
    if (BATTERYTooLow(PWR_BY_BAT | PWR_WARNING1))
        ApplVar.ErrorNumber = ERROR_ID(CWXXI95);
#endif
    //<<<<<<<<<<<<<<<

    if (sRePrint)//����ӡ���������վ� (sRePrint)
    {//��ӡ�ػ�ǰ���жϵ�δ��ӡ����
       if (BIT(ApplVar.Fiscal_PrintFlag,(BIT0 | BIT7))==(BIT0 | BIT7))
           ResetPopOutofReceipt();//ccr2018-03-07��ӡ������Ŀʱ,ȱֽ,���´�ӡ����
       else
#if defined(CASE_GREECE)//ccr2018-03-20 ɾ�� 'reprint when power on'
           Start_When_Ready(0);
#else
           Start_When_Ready(REPRN_PWON);
#endif
    }
#endif

    GetTimeDate(&Now);              //* read timer

#if (SDCACHESIZE)
    SDCacheFlushData(true);//���ػ�ǰδд���ļ�������д���ļ�
    if (!ApplVar.FiscalFlags)
        CheckEJSpace();
#endif
#if (0)//ccr2015-10-13
    //�ָ��ػ�ǰ����ʾ����
    if (!ApplVar.ErrorNumber && ApplVar.LCD_Operator[0])
    {
#if (DD_ZIP)
        PutsO(ApplVar.LCD_Operator);
        Puts1(ApplVar.LCD_Operator+DISLEN);
#elif (DD_ZIP_21)
        PutsO(ApplVar.LCD_Operator);
        Puts1(ApplVar.LCD_Operator+DISLEN);
        PutsC(ApplVar.LCD_Customer);
#else
        PutsO(ApplVar.LCD_Operator);
#endif
        ApplVar.LCD_Operator[0]=0;
    }
#endif
}


/****************************************************************
 * ����ʱ,���Ϊ�»���,���������ں�ʱ��
 *
 * @author EutronSoftware (2017-12-13)
 *
 * @param idx :=0,��ʾ��������;=1,��ʾ����ʱ��;=2,�������ں�ʱ��
 ***************************************************************/
void Initial_DateTime(BYTE idx)
{

    switch (idx)
    {
    case 0://��ʾ��������
        ClearEntry();
        ClearLine2();

        SetInputMode('0');
        Appl_MaxEntry = 8;

        DateForDisplay(0,DISLEN);

#if (DISP2LINES)
        strcpy(ProgLineMes,Msg[RIQI].str);
        PutsO(ProgLineMes);
        Puts1(SysBuf);
//								PutsC(SysBuf+4);
#else
        CopyFrStr(SysBuf,Msg[RIQI].str);
        PutsO(SysBuf);
#endif
        ClearEntry();
        break;
    case 1:
        if (Appl_EntryCounter)
        {
            NewTimeDate(0xf1);
            if (ApplVar.ErrorNumber)
            {
#if (DISP2LINES)
                Puts1(Msg[ApplVar.ErrorNumber].str);
#else
                PutsO(Msg[ApplVar.ErrorNumber].str);
#endif
            }
            else if (Now.year<0x2000) Now.year |= 0x2000;
        }

        memset(SysBuf,' ',DISLEN);
        HEXtoASC(SysBuf+DISLEN-8,(char*)(&Now.hour),1);SysBuf[DISLEN-6]=':';
        HEXtoASC(SysBuf+DISLEN-5,(char*)(&Now.min),1);SysBuf[DISLEN-3]=':';
        HEXtoASC(SysBuf+DISLEN-2,(char*)(&Now.sec),1);

        SysBuf[DISLEN] = 0;

#if(DISP2LINES)
        strcpy(ProgLineMes,Msg[SHIJIAN].str);
        PutsO(ProgLineMes);
        Puts1(SysBuf);
#else
        CopyFrStr(SysBuf,Msg[SHIJIAN].str);
        PutsO(SysBuf);
#endif

        ClearEntry();
        Appl_MaxEntry = 6;
        break;
    case 2:// input time
        if (Appl_EntryCounter)
        {
            NewTimeDate(0xf2);
            if (ApplVar.ErrorNumber)
            {
#if (DISP2LINES)
                Puts1(Msg[ApplVar.ErrorNumber].str);
#else
                PutsO(Msg[ApplVar.ErrorNumber].str);
#endif
                break;
            }
        }
        SetTimeDate(&Now);
        SetDateFlg = 0;

        ClearEntry();
        ClearLine2();
        break;
    }
}


