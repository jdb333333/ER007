#define CORREC_C 7
#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
#include "flowbill.h"
#define CANCELF 0


/****************************************************************/


void GetCorrecOffSet()
{
	RamOffSet = ApplVar.CorrecNumber * ApplVar.AP.Correc.RecordSize + ApplVar.AP.StartAddress[AddrCorr];
}

void AddCorrecTotal()
{
    GetCorrecOffSet();
	RamOffSet += ApplVar.AP.Correc.TotalOffSet;
    for (ApplVar.PointerType = 0; ApplVar.PointerType < REPDEFMAX; ApplVar.PointerType++)
    {
		ApplVar.Size = ApplVar.AP.Correc.Size[ApplVar.PointerType];
		AddPointerTotal();
    }
}

void WriteCorrec()
{
    if (ApplVar.CorrecNumber < ApplVar.AP.Correc.Number)
    {
		GetCorrecOffSet();
		WriteRam((BYTE *)&ApplVar.Correc, ApplVar.AP.Correc.TotalOffSet);	 /* write function options */
    }
}

void ReadCorrec()
{
    GetCorrecOffSet();
    ReadRam((BYTE *)&ApplVar.Correc, ApplVar.AP.Correc.TotalOffSet);	    /* write function options */
    ApplVar.Correc.Name[ApplVar.AP.Correc.CapSize]=0 ;
}

void TransactionVoid()
{
	BYTE savenumber;
	WORD saveclerk;
	short i;


//	if (!ApplVar.RGNumber || ApplVar.RGBuf[ApplVar.RGNumber - 1].Key.Code == SUSPEND /*|| ApplVar.FTend*/ || !ApplVar.FRegi)	/* items in buffer ? */
	if (!ApplVar.RGNumber || ApplVar.RGBuf[ApplVar.RGNumber - 1].Key.Code == SUSPEND || ApplVar.FTend || !ApplVar.FRegi)	//liuj modify 080602 /* items in buffer ? */
	{
        ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
		return;
	}


	if (ApplVar.FTend)//ccr 050111
		ApplVar.BufKp = 0;

	ApplVar.PrintLayOut = ApplVar.Correc.Print;
    if (CheckSlip())		/* slip compulsory */
	    return;
	if (ApplVar.FRegi)
	{
		if (ApplVar.FPb)							/* ApplVar.PB transaction ? */
		{
			ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
			return;
		}
		StoreInBuffer();
//ccr2018-01-05		ApplVar.PrintLayOut = 0;
		RegiEnd(false);//ccr2018-01-05
		ApplVar.SubTotal = ApplVar.SaleAmt;
	}
	else
		CalculateTax(1);						/* calculate only */
	ApplVar.FTrvoid = 1;
	ApplVar.SubTotal.Sign ^= 0x80;
    RESETBIT(ARROWS, BIT1); /* reset RG led */
#if(DD_ZIP==1)
	PutsO(DText[DTEXT_CANCEL]);
	Puts1(DispAmtStr(0, &ApplVar.SubTotal,DISLEN));
#elif(DD_ZIP_21==1)
	PutsO(DText[DTEXT_CANCEL]);
	Puts1(DispAmtStr(0, &ApplVar.SubTotal,DISLEN));
	if (SysBuf[sizeof(SysBuf)- DISLENC + 3]==' ')
		CopyFrStr(&SysBuf[sizeof(SysBuf)- DISLENC],CusDText[ItemDTextCAN]);
	PutsC(&SysBuf[sizeof(SysBuf)- DISLENC]);
#else
	PutsO((char*)DispAmtStr(DText[DTEXT_CANCEL], &ApplVar.SubTotal,DISLEN));
#endif

#if(CASE_RAMBILL)
	Collect_Data(TVOIDLOG) ;				 //    lyq2003
#endif
	savenumber = ApplVar.CorrecNumber;
	saveclerk = ApplVar.ClerkNumber;
	ProcessBuffer();
	ApplVar.CorrecNumber = savenumber;
	ReadCorrec();							/* read function */
	ApplVar.ClerkNumber = saveclerk;
	ReadClerk();
	if (ApplVar.ErrorNumber)
	{
		ApplVar.FTrvoid = 0;
		return;
	}
	ApplVar.PrintLayOut = ApplVar.Correc.Print;
	if (!ApplVar.FRegi)
	{
		for (i = 0;i < ApplVar.AP.Tax.Number;i++)
		{//ccr090108>>>>>>>>>
			ApplVar.TaxItem[0][i].Sign ^= 0x80;
			ApplVar.TaxItem[1][i].Sign ^= 0x80;
			ApplVar.TaxItem[2][i].Sign ^= 0x80;
		}//<<<<<<<<<<<<<<<<<
		ApplVar.SaleAmt.Sign ^= 0x80;
		if (ApplVar.FTrvoid != 2)
			CalculateTax(0);						/* calculate and add in report */
	}
#if !defined(CASE_GREECE)//ccr2018-03-20
	else
		PrintLine('-');
#endif
// lyq   ApplVar.SaleAmt = ZERO;					 //lyq modified for print the total of Fvoid 2003\11\3 start
    ApplVar.SaleQty = ZERO;
    MemSet(ApplVar.TaxItem, sizeof(ApplVar.TaxItem), 0);
	memcpy(&ApplVar.SaleAmt.Value,&ApplVar.SubTotal.Value,sizeof(BCD)-1);
	ApplVar.SaleAmt.Sign ^=0x80;
	PrintAmt(ApplVar.Correc.Name, &ApplVar.SaleAmt);//ccr &ApplVar.SubTotal);
#if defined(CASE_GREECE)//ccr2018-03-20
    PrintLine('-');
    PrintAmt(Prompt.Caption[ItemPrompt0], &ZERO);   //ApplVar.Total
#endif

#if defined(FISCAL) // liuj 0801
	if (!ApplVar.Dept.Tax)
		Add(&ApplVar.FExento, &ApplVar.Amt);	/* exento for fiscal report */

//	Add(&ApplVar.FTotal, &ApplVar.SubTotal);	//cc 20071018
#endif
	if (!ApplVar.FTrain)//ccr100330
	{
	Add(&ApplVar.FTotal, &ApplVar.SubTotal);	//    cc 20071018
	Add(&ApplVar.TotalMax, &ApplVar.SubTotal);	//    ccr080901
	}

   	ApplVar.SaleAmt = ZERO;							//lyq modified for print the total of Fvoid 2003\11\3 start
    RESETBIT(ARROWS, BIT1); /* reset RG led */
	ApplVar.FRegi = 0;
	ApplVar.FSale = 0;
	RegiEnd(true);
	ReceiptIssue(1);
	ApplVar.FTrvoid = 0;
	ApplVar.CopyReceipt = ApplVar.RGNumber = 0;    /* reset trans buffer */
	ApplVar.Amt = ApplVar.SubTotal;
	ApplVar.Qty = ONE;
	ApplVar.RetQty = ZERO;
	ApplVar.DiscAmt = ZERO;
	ApplVar.Cost = ZERO;
	AddCorrecTotal();
	ApplVar.BufCC = 1;
	AddCorrecTotal();			/* reset CC */
	ApplVar.BufCC= 0;
    CLRMyFlags(OPENRECEIPT);//ccr2017-05-23
    if (BIT(CLERKFIX, BIT0) && !ApplVar.ClerkLock)	  /* clerk compulsory, no key */
    {
		ApplVar.ClerkNumber = 0;
		ApplVar.FTrain = 0;
    }
#if (SDCACHESIZE)//ccr2018-02-23>>>>>
    SDCacheFlushData(true);//ccr2018-03-01
#endif//ccr2018-02-24<<<<<<<
}

void Correction()
{
    if (Appl_EntryCounter)
    {
		ApplVar.ErrorNumber=ERROR_ID(CWXXI04);
		return;
    }
    ApplVar.CorrecNumber = ApplVar.Key.Code - CORREC - 1;
    if (ApplVar.CorrecNumber < ApplVar.AP.Correc.Number)
		ReadCorrec();		/* read function */
    else
    {
		ApplVar.ErrorNumber=ERROR_ID(CWXXI42);
		return;
    }
    if (ApplVar.FPb)
		ApplVar.Correc.Print = ApplVar.PbF.Print;
    ApplVar.PrintLayOut = ApplVar.Correc.Print;
    switch(ApplVar.Correc.Options & 0x07) {
	case 0:     /* void */
		if (!BIT(ApplVar.Clerk.Options,BIT0) && !CheckPWD(ApplVar.AP.ModePwd.PwdMG))
		{
			ApplVar.ErrorNumber=ERROR_ID(CWXXI36);
			return;
		}

	    ApplVar.FVoid = 1;
	    StoreInBuffer();
	    if (ApplVar.FRegi && ApplVar.RepeatCount)
	    {
			ApplVar.RGRec.Key.Code = CORREC + 1 + ApplVar.CorrecNumber;
			if (ApplVar.FPlu)		/* Previous PLU */
				ProcessPlu();
			else
				ProcessDept();
	    }
	    else if (ApplVar.RGRec.Key.Code > DISC && ApplVar.RGRec.Key.Code < DISC + 100)
	    {
			ApplVar.RGRec.Key.Code = CORREC + 1 + ApplVar.CorrecNumber;
			Discount();
	    }
	    else if (ApplVar.RGRec.Key.Code > PORA && ApplVar.RGRec.Key.Code < PORA + 100)
	    {
			ApplVar.RGRec.Key.Code = CORREC + 1 + ApplVar.CorrecNumber;
			PaidOutRa();
	    }
	    else
	    {
			ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
			ApplVar.RGRec.Key.Code = 0;
	    }
	    return;
	case 1:     /* correction */
		if (!BIT(ApplVar.Clerk.Options,BIT1) && !CheckPWD(ApplVar.AP.ModePwd.PwdMG))
		{
			ApplVar.ErrorNumber=ERROR_ID(CWXXI36);
			return;
		}

	    if (!ApplVar.FRegi)
			ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
	    else
	    {
			PutsO(DMes[ItemDMes4]);
			ApplVar.FCorr = 1;
	    }
	    StoreInBuffer();
	    ApplVar.RGRec.Key.Code = 0;
	    break;
	case 2:     /* �˻� Refund */
		if (!BIT(ApplVar.Clerk.Options,BIT3) && !CheckPWD(ApplVar.AP.ModePwd.PwdMG))
		{
			ApplVar.ErrorNumber=ERROR_ID(CWXXI36);
			return;
		}
	    StoreInBuffer();
	    ApplVar.RGRec.Key.Code = 0;
	    if (ApplVar.FSplit)
			ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
	    else
	    {
			PutsO(DMes[ItemDMes5]);
			ApplVar.FRefund = 1;
	    }
	    break;
//#if !defined(FISCAL) ||(defined(FISCAL) && DD_FISPRINTER==1) //liuj 0731
	case 3:
		if (!BIT(ApplVar.Clerk.Options,BIT2) && !CheckPWD(ApplVar.AP.ModePwd.PwdMG))
		{
			ApplVar.ErrorNumber=ERROR_ID(CWXXI36);
			return;
		}
		TransactionVoid();
		break;
	case 4 :     /* cancel 1 */
	    if (ApplVar.FRegi)
			ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
	    else
	    {
			PutsO(DMes[ItemDMes6]);
			ApplVar.FCanc = 1;
			ApplVar.CancelNumber = ApplVar.Key.Code - CORREC - 1;
			ApplVar.CancPrint = ApplVar.Correc.Print | 0x04;    /* set double size */
	    }
	    break;
	case 5 :    /* cancel 2 */
	    if (ApplVar.FRegi)
			ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
	    else
	    {
			PutsO(DMes[ItemDMes7]);
			ApplVar.FCanc = 2;
			ApplVar.CancPrint = 0xfe;   /* not on journal */
	    }
	    break;
//#endif
	default:
	    ApplVar.ErrorNumber=ERROR_ID(CWXXI42);
	    break;
    }
}

