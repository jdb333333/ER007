#define DISCOUNT_C 7
#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
#include "flowbill.h"  //lyq2003
#define JIANGBO 0


/***************************************************************/


void GetDiscOffSet()
{
    RamOffSet = ApplVar.DiscNumber * ApplVar.AP.Disc.RecordSize + ApplVar.AP.StartAddress[AddrDisc];
}

void AddDiscTotal()
{
    GetDiscOffSet();
    RamOffSet += ApplVar.AP.Disc.TotalOffSet;
    for (ApplVar.PointerType = 0; ApplVar.PointerType < REPDEFMAX; ApplVar.PointerType++)
    {
        ApplVar.Size = ApplVar.AP.Disc.Size[ApplVar.PointerType];
        AddPointerTotal();
    }
}

void WriteDisc()
{
    if (ApplVar.DiscNumber < ApplVar.AP.Disc.Number)
    {
        GetDiscOffSet();
        WriteRam((BYTE *)&ApplVar.Disc, ApplVar.AP.Disc.TotalOffSet);      /* write function options */
    }
}

void ReadDisc()
{
    GetDiscOffSet();

    ReadRam((BYTE *)&ApplVar.Disc, ApplVar.AP.Disc.TotalOffSet);      /* write function options */
    ApplVar.Disc.Name[ApplVar.AP.Disc.CapSize]=0 ;
}

void PrintPercentage(BCD *perc)
{
    if (!BIT(ApplVar.Disc.Options, BIT2) && /* percentage ? */
        BIT(ApplVar.Disc.Options, BIT0 + BIT1))  /* and open, open/fixed */
    {
        MemSet(SysBuf, sizeof(SysBuf), ' ');
        perc->Sign = 0x02;
        FormatQty(SysBuf + 10, perc);
        SysBuf[12] = '%';
        SysBuf[13] = 0;
        PrintStr(SysBuf);
    }
}
//ccr091210 for SubDisc on ApplVar.PB>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
//sType 	= 0:�ٷֱ�С���ۿ�	//
//		= 1:С���ۿۺ�ȡ������	//
//		= 2:���С���ۿ�		//
//		= 4:С���ۿۼ�˰		//
//////////////////////////////////////////////////////////////
#if (0)
void CalculateSubDisc(short sType)
{
    BYTE i;
    BYTE SubDisc_Flag;/* BIT0:	PLU Sales	BIT1:	ApplVar.FRefund		BIT2:	ApplVar.FVoid*/

    BCD sAmt,saveAmt,saveDiscAmt,saveQty,sQty,sDiscVal,sTot;
    WORD savePlu,saveDept;

    saveAmt = ApplVar.Amt;
    saveDiscAmt = ApplVar.DiscAmt;
    saveQty = ApplVar.Qty;
    savePlu = ApplVar.PluNumber;
    saveDept = ApplVar.DeptNumber;

    SubDisc_Flag = 0;
    if (sType == 0)
    {
        sAmt = sDiscVal = ZERO;
        sDiscVal = ApplVar.Entry;
        Multiply(&sDiscVal,&THOUSAND100);

        if (!BIT(ApplVar.Disc.Options,BIT3))
            sDiscVal.Sign ^= 0x80;
        if (ApplVar.FVoid)
            sDiscVal.Sign ^= 0x80;
    }
//	else if(sType == 1)
//		sDiscVal.Sign ^= 0x80;
    else if (sType == 2)
    {
        sAmt = sDiscVal = ZERO;
        sDiscVal = ApplVar.Entry;
        for (i=0;i<ApplVar.RGNumber;i++)
        {
            if (ApplVar.RGBuf[i].Key.Code > DEPT)
            {
                sDiscVal.Sign = ApplVar.RGBuf[i].DiscAmt.Sign;      //cc 20070427
                if (ApplVar.RGBuf[i].Key.Code > PLU1)
                {
                    ApplVar.PluNumber = ApplVar.RGBuf[i].Key.Code - PLU1 - 1;
                    ReadPlu();
                    ApplVar.DeptNumber = ApplVar.PluDept;
                }
                else
                    ApplVar.DeptNumber = ApplVar.RGBuf[i].Key.Code - DEPT - 1;
                ReadDept();

                if (BIT(ApplVar.Disc.Options,BIT6) || BIT(ApplVar.Disc.Options,BIT7))
                {
                    if (!(BIT(ApplVar.Disc.Options,BIT6) && BIT(ApplVar.Dept.Options,BIT6)) &&
                        !(BIT(ApplVar.Disc.Options,BIT7) && BIT(ApplVar.Dept.Options,BIT7)))
                        continue;
                }
                sAmt = ApplVar.RGBuf[i].DiscAmt;
                if (BIT(SubDisc_Flag,BIT1))
                {
                    sAmt.Sign ^= 0x80;
                    RESETBIT(SubDisc_Flag,BIT1);
                }
                Add(&sTot,&sAmt);
            }
            else if (ApplVar.RGBuf[i].Key.Code == CORREC+3 || ApplVar.RGBuf[i].Key.Code == CORREC+2)
            {
//				SETBIT(SubDisc_Flag,BIT1);
                continue;
            }
        }

        Multiply(&sDiscVal,&MILLION10);
        Divide(&sDiscVal,&sTot);

        if (!BIT(ApplVar.Disc.Options, BIT3))    /* Positive or negative */
            sDiscVal.Sign ^= 0x80;
        if (ApplVar.FVoid)
            sDiscVal.Sign ^= 0x80;
    }

    for (i=0;i<ApplVar.RGNumber;i++)
    {
        if (ApplVar.RGBuf[i].Key.Code > DEPT)
        {
            RESETBIT(SubDisc_Flag,BIT0);
            if (ApplVar.RGBuf[i].Key.Code > PLU1)
            {
                SETBIT(SubDisc_Flag,BIT0);
                ApplVar.PluNumber = ApplVar.RGBuf[i].Key.Code - PLU1 - 1;
                ReadPlu();
                ApplVar.DeptNumber = ApplVar.PluDept;
            }
            else
                ApplVar.DeptNumber = ApplVar.RGBuf[i].Key.Code - DEPT - 1;
            ReadDept();

            if (sType == 4)
            {
                ApplVar.Amt = saveAmt;
                if (!BIT(ApplVar.Disc.Options,BIT6) && !BIT(ApplVar.Disc.Options,BIT7))
                    CalculateTax2();
                else
                {
                    if ((BIT(ApplVar.Disc.Options,BIT6) && BIT(ApplVar.Dept.Options,BIT6)) ||
                        (BIT(ApplVar.Disc.Options,BIT7) && BIT(ApplVar.Dept.Options,BIT7)))
                        CalculateTax2();
                }
            }

            else//if(sType != 4)
            {
                if (BIT(ApplVar.Disc.Options,BIT6) || BIT(ApplVar.Disc.Options,BIT7))
                {
                    if (!(BIT(ApplVar.Disc.Options,BIT6) && BIT(ApplVar.Dept.Options,BIT6)) &&
                        !(BIT(ApplVar.Disc.Options,BIT7) && BIT(ApplVar.Dept.Options,BIT7)))
                        continue;
                }
//				PrintAmt(Prompt.Caption[ItemPrompt16],&ApplVar.RGBuf[i].DiscAmt);
                if (sType == 1)
                {
                    ApplVar.DiscAmt = ApplVar.RGBuf[i].Amt;
                    if (BIT(SubDisc_Flag,BIT1))
                    {
                        sAmt.Sign ^= 0x80;
                        RESETBIT(SubDisc_Flag,BIT1);
                    }

                    Multiply(&ApplVar.DiscAmt, &ApplVar.RGBuf[i].Qty);  //20070118
                    Subtract(&ApplVar.DiscAmt, &ApplVar.RGBuf[i].DiscAmt);
                    ApplVar.Amt = ApplVar.DiscAmt;
                    ApplVar.Qty = ApplVar.RGBuf[i].Qty;
                    ApplVar.Qty.Sign ^= 0x80;
                }
                else
                {
                    sAmt = ApplVar.RGBuf[i].DiscAmt;

                    if (BIT(SubDisc_Flag,BIT1))
                    {
                        sAmt.Sign ^= 0x80;
                        RESETBIT(SubDisc_Flag,BIT1);
                    }

                    Multiply(&sAmt,&sDiscVal);
                    Divide(&sAmt,&MILLION10);
                    RoundBcd(&sAmt,0);
                    AmtRound(1,&sAmt);

                    ApplVar.DiscAmt = ApplVar.Amt = sAmt;
                    Add(&ApplVar.RGBuf[i].DiscAmt,&sAmt);
                }
            }
        }
        else if (ApplVar.RGBuf[i].Key.Code >= DISC1 && ApplVar.RGBuf[i].Key.Code <= DISC4 && sType == 1)
        {
            ApplVar.Amt = ApplVar.DiscAmt = ApplVar.RGBuf[i].Amt;
/*			sAmt = ApplVar.RGBuf[i].Amt;

            if(BIT(ApplVar.Disc.Options,BIT6) || BIT(ApplVar.Disc.Options,BIT7))		//cc 20070518
            {
                if(!(BIT(ApplVar.Disc.Options,BIT6) && BIT(ApplVar.Dept.Options,BIT6)) &&
                    !(BIT(ApplVar.Disc.Options,BIT7) && BIT(ApplVar.Dept.Options,BIT7)))
                    continue;
            }

            Multiply(&sAmt,&sDiscVal);
            Divide(&sAmt,&MILLION10);
            RoundBcd(&sAmt,0);
            AmtRound(1,&sAmt);

            ApplVar.DiscAmt = ApplVar.Amt = sAmt;
*/
        }
        else if (ApplVar.RGBuf[i].Key.Code >= DISC5 && ApplVar.RGBuf[i].Key.Code <= DISC8 && sType == 1)
            continue;   //break;
        else if (ApplVar.RGBuf[i].Key.Code == CORREC+2 && sType != 4)
        {
//			SETBIT(SubDisc_Flag,BIT1);
            continue;
        }
        else
            ApplVar.DiscAmt = ApplVar.Amt = ZERO;

        if (sType || ApplVar.FVoid)
            ApplVar.Qty = ZERO;

        if (sType != 4)
        {
            if (ApplVar.Dept.Group < ApplVar.AP.Group.Number)
                ApplVar.GroupNumber = ApplVar.Dept.Group;
            else
                ApplVar.GroupNumber = 0;

            AddGroupTotal();

            if (BIT(SubDisc_Flag,BIT0))
                AddPluTotal();
            AddDeptTotal();
        }
    }

    if (ApplVar.FVoid)
        sDiscVal = ZERO;
    ApplVar.Amt = saveAmt;
    ApplVar.DiscAmt = saveDiscAmt;
    ApplVar.Qty = saveQty;
    ApplVar.PluNumber = savePlu;
    ApplVar.DeptNumber = saveDept;
}
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#endif
void Discount()
{
    BCD d1, d2;//ccr090113,d3;
    BYTE i, sign;//ccr090113,firsttax;
    WORD    SKC;


    ApplVar.FCurr = 0;
    sign = 0;
    if (!ApplVar.FVoid)
    {
        ApplVar.DiscNumber = ApplVar.Key.Code - DISC - 1;
        if (ApplVar.DiscNumber < ApplVar.AP.Disc.Number)
            ReadDisc();           /* read function */
        else
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI42);
            return;
        }

        if ((!BIT(ApplVar.Clerk.Options,BIT6) && BIT(ApplVar.Disc.Options, BIT2) && !CheckPWD(ApplVar.AP.ModePwd.PwdMG)) ||
            (!BIT(ApplVar.Clerk.Options,BIT4) && !BIT(ApplVar.Disc.Options, BIT3) && !CheckPWD(ApplVar.AP.ModePwd.PwdMG)) ||
            (!BIT(ApplVar.Clerk.Options,BIT5) && BIT(ApplVar.Disc.Options, BIT3) && !CheckPWD(ApplVar.AP.ModePwd.PwdMG)))
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI36);
            return;
        }

        if (ApplVar.FSub)
        {
            ApplVar.RGRec.Group = 1;    //cc 2006-06-05 for SubDisc>>>>>>>>>>>>>>>
            ApplVar.FSub = 0;       /* ccr090107 reset subtotal  */
            if (BIT(KEYTONE, BIT5))
                RESETBIT(ApplVar.Disc.Options, BIT4);    /* reset item */
        }
        else
            ApplVar.RGRec.Group = 0;    //cc 2006-06-05 for SubDisc>>>>>>>>>>>>>>>
        if ((ApplVar.Disc.Options & (BIT2+BIT4)) != BIT2) /* ccr090107 not sub amt disc? */   //cc050906
        {

            if (!ApplVar.FRegi || ApplVar.FRefund || ApplVar.FCorr)
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                return;
            }

            if (ApplVar.FSplit)
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI29);
                return;
            }
        }
        if (ApplVar.FPb)
            ApplVar.Disc.Print = ApplVar.PbF.Print;

//cc 20071102>>>>>>>>>>>>>>>>
        if (!BIT(ApplVar.Disc.Options, BIT2))    /* amount or percentage ? */
            ApplVar.FDisc = 1;
//cc 20071102>>>>>>>>>>>>>>>>

        if (Appl_EntryCounter && BIT(ApplVar.Disc.Options, BIT0 + BIT1))     /* open or open/fixed? */
        {
            //ccr2017-07-27>>>>>>>>>С����ת��>>>>>>>>
            ApplVar.Qty1 = ZERO;
            memcpy(ApplVar.Qty1.Value, ApplVar.Disc.Max, sizeof(ApplVar.Disc.Max));
            if (CompareBCD(&ApplVar.Entry, &ApplVar.Qty1) > 0)
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI18);
                return;
            }

		    if (!BIT(ApplVar.Disc.Options, BIT2))   /* percentage ? */
				ChangePoint2(true);  //ccr2018-01-03  yes, It is percentage
			else
				ChangePoint();
            //ccr2017-07-27<<<<<<<<<<<<<<<<<<<
/*		    else if (ApplVar.DecimalPoint || AmtInputMask())
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                return;
            }*/

        }
        else if (!Appl_EntryCounter && !BIT(ApplVar.Disc.Options, BIT0))     /* fixed? */
        {
            ApplVar.Entry = ZERO;
            memcpy(ApplVar.Entry.Value, ApplVar.Disc.Fixed, sizeof(ApplVar.Disc.Fixed));
        }
#if DD_CHIPC
        else if (!BIT(IC.ICState,IC_DISCOUNT))//ccr chipcard
#else
        else
#endif
        {
            if (!CheckNotZero(&ApplVar.Entry))//Appl_EntryCounter)
                ApplVar.ErrorNumber=ERROR_ID(CWXXI43);//ccr2017-09-12 "0 NOT ALLOWED"
            else
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            return;
        }
        //ccr2017-09-12 "0 NOT ALLOWED">>>>
        if (!CheckNotZero(&ApplVar.Entry))//Appl_EntryCounter)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI43);
            return;
        }
        //ccr2017-09-12 <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        if (BIT(ApplVar.Disc.Options, BIT4))    /* item or subtotal */
        {
            if (ApplVar.RGRec.Key.Code < DEPT || !ApplVar.RepeatCount || ApplVar.FMixMatch)  /* no item */
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                return;
            }
            sign = ApplVar.Qty.Sign & 0x80; /* when negative then corr or refund used !!*/
        }
        else
        {
            if (!ApplVar.FRegi)
                ApplVar.Amt = ZERO;
            else if (!BIT(ApplVar.Disc.Options, BIT6 + BIT7))    /* items 1 */
            {
                ApplVar.Amt = ApplVar.SaleAmt;
                /* JB Add */
                if ((!BIT(PBINFO, BIT3) || ApplVar.FPb) && ApplVar.PbNumber && !ApplVar.FSplit)    /* fast ApplVar.PB ? */
                {
                    PbTotal(ApplVar.PbNumber, 0);       /* read total */
                    Add(&ApplVar.Amt, &ApplVar.PB.Amt);
                }

            }
            else
            {
                ApplVar.Amt = ZERO;
                if (BIT(ApplVar.Disc.Options, BIT6))    /* items 1 */
                {
                    d1 = ApplVar.DiscItem[0];
                    if (/* BIT(PBINFO, BIT3) && !ApplVar.FPb && */ ApplVar.PbNumber && !ApplVar.FSplit)    /* fast ApplVar.PB ? */
                        Add(&d1, &ApplVar.PB.Disc1);
                    Add(&ApplVar.Amt, &d1);
                }
                if (BIT(ApplVar.Disc.Options, BIT7))    /* items 2 */
                {
                    d2 = ApplVar.DiscItem[1];
                    if (/* BIT(PBINFO, BIT3) && !ApplVar.FPb && */ ApplVar.PbNumber && !ApplVar.FSplit)    /* fast ApplVar.PB ? */
                        Add(&d2, &ApplVar.PB.Disc2);
                    Add(&ApplVar.Amt, &d2);
                }
            }
        }
        if (BIT(ApplVar.Disc.Options, BIT2))    /* amount or percentage ? */
        {
            ApplVar.Amt = ApplVar.Entry;
            if (BIT(ApplVar.Disc.Options, BIT4))    /* item */
                ApplVar.Amt.Sign = sign;
        }
        else
        {    /* Percentage */
            ApplVar.Entry.Sign = 0x04;    /* 4 decimals */
            Multiply(&ApplVar.Amt, &ApplVar.Entry);
            RoundBcd(&ApplVar.Amt, 0);
            AmtRound(1, &ApplVar.Amt);
        }

        if (!BIT(ApplVar.Disc.Options, BIT3))    /* Positive or negative */
            ApplVar.Amt.Sign ^= 0x80;
    }
#if defined(FISCAL)
    else if (!BIT(ApplVar.Disc.Options, BIT4+BIT2))    /* subtotal% with void not allowed */
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
        return;
    }
#endif
    ApplVar.PrintLayOut = ApplVar.Disc.Print;
#if defined(FISCAL)
    if (!ApplVar.FRegi)
        ApplVar.FStatus = 1;        /* set fiscal receipt */
#endif
    if (ApplVar.FVoid || ApplVar.FCorr || ApplVar.FRefund)
    {
        ApplVar.Amt.Sign ^= 0x80;
        SKC = ApplVar.RGRec.Key.Code;
        if (ApplVar.DiscNumber == 2)
        {
            ApplVar.RGRec.Amt.Sign ^= 0x80;
            ApplVar.RGRec.Key.Code = DISC+3;
            StoreInBuffer();
            ApplVar.RGRec.Amt = ZERO;
        }
        if (ApplVar.DiscNumber == 3)
        {
            ApplVar.RGRec.Amt.Sign ^= 0x80;
            ApplVar.RGRec.Key.Code = DISC+4;
            StoreInBuffer();
            ApplVar.RGRec.Amt = ZERO;
        }
        ApplVar.RGRec.Key.Code = SKC;
    }
    if (ApplVar.FCanc && BIT(ApplVar.Disc.Options, BIT2))    /* amount ? */
        ApplVar.Amt.Sign ^= 0x80;


//#if defined(FISCAL)		//cc 20071018
    if (BIT(ApplVar.Disc.Options, BIT4) &&     /* subtotal or item */
        (ApplVar.Amt.Sign & 0x80) && CompareBCD(&ApplVar.Amt, &ApplVar.FTotal) == 1)
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
        return;
    }
//#endif


    if (RegiStart())
        return;  /* check if start of registration */

    if (BIT(ApplVar.Disc.Options, BIT4))    /* item then no consolidation */
        ApplVar.BufCmd = 0;
    StoreInBuffer();

    ApplVar.RGRec.Key.Code = ApplVar.Key.Code;
    if (BIT(ApplVar.Disc.Options, BIT2))    /* amount or percentage ? */
        ApplVar.RGRec.Qty = ZERO;
    else
        ApplVar.RGRec.Qty = ApplVar.Entry;
    ApplVar.RGRec.Amt = ApplVar.Amt;

    if (ApplVar.FCorr || (sign && (ApplVar.Correc.Options & 0x07) == 1)) /* correction ? */
    {
        ApplVar.BufCmd = 2;         /* only check if used */
        StoreInBuffer();    /* check if discount used */
        if (ApplVar.ErrorNumber)
        {
            ApplVar.RGRec.Key.Code = 0;
            return;
        }
    }
//ccr091223>>>>>>>>>>>
//	if (ApplVar.PbNumber && BCDWidth(&ApplVar.Amt)>ApplVar.AP.Pb.ArtAmt*2)
//	{
//		ApplVar.ErrorNumber = ERROR_ID(CWXXI65);
//		return;
//	}
//<<<<<<<<<<<<<<<<<<<<<
    if (StorePbBuffer())     /* store in ApplVar.PB buffer */
    {
        ApplVar.RGRec.Key.Code = 0;
        return;
    }
    if (ApplVar.FCorr || ApplVar.FRefund)
    {
        ApplVar.RGRec.Key.Code = CORREC + 1 + ApplVar.CorrecNumber;
        StoreInBuffer();      /* store correction or refund function */
        ApplVar.RGRec.Key.Code = ApplVar.Key.Code;
    }

    //��ʾ�ۿ۽��
#if(DD_ZIP==1)
    PutsO(DText[DTEXT_DISCOUNT]);
    Puts1(DispAmtStr(0, &ApplVar.Amt,DISLEN));
#elif(DD_ZIP_21==1)
    PutsO(DText[DTEXT_DISCOUNT]);
    Puts1(DispAmtStr(0, &ApplVar.Amt,DISLEN));
    if (SysBuf[sizeof(SysBuf)- DISLENC + 3]==' ')
        CopyFrStr(&SysBuf[sizeof(SysBuf)- DISLENC],CusDText[ItemDTextTOT]);
    PutsC(&SysBuf[sizeof(SysBuf)- DISLENC]);
#else
    PutsO(DispAmtStr(DText[DTEXT_DISCOUNT], &ApplVar.Amt,DISLEN));
#endif

    if (ApplVar.FVoid)
        ApplVar.TaxTemp = ApplVar.TaxTemp1;     /* restore temp tax shift */
#if (defined(CASE_GREECE))//ϣ���ڽ��ǰ����ӡŷԪ����
    Prefix1 = 0;
    Prefix2 = 0;
#endif
    if (ApplVar.FVoid || ApplVar.FCorr || ApplVar.FRefund) /* void */
    {
        ApplVar.PrintLayOut = ApplVar.Correc.Print;
        PrintStr(ApplVar.Correc.Name);
        ApplVar.PrintLayOut = ApplVar.Disc.Print;
    }
    else if ((ApplVar.Disc.Options & (BIT4 + BIT5)) == BIT5)
    {           /* subtotal  and print Subtotal ?*/
        PrintLine('-');
        if (!BIT(ApplVar.Disc.Options, BIT6 + BIT7))    /* items 1 */
            PrintAmt(Prompt.Caption[ItemPrompt1], &ApplVar.SaleAmt);
        else
        {
            if (BIT(ApplVar.Disc.Options, BIT6))    /* items 1 */
                PrintAmt(Prompt.Caption[ItemPrompt44], &d1);
            if (BIT(ApplVar.Disc.Options, BIT7))    /* items 2 */
                PrintAmt(Prompt.Caption[ItemPrompt45], &d2);
        }
    }

    MemSet(ProgLineMes, sizeof(ProgLineMes), ' ');
    i = strlen(ApplVar.Disc.Name);
    if (i>10)
        i = 10;
    strncpy(ProgLineMes,ApplVar.Disc.Name,i);
    ProgLineMes[i]=' ';

    if (!BIT(ApplVar.Disc.Options, BIT2) && /* percentage ? */
        BIT(ApplVar.Disc.Options, BIT0 + BIT1))  /* and open, open/fixed */
    {
        if (ApplVar.FVoid)
        {
            BcdDiv10(&ApplVar.Entry);
            BcdDiv10(&ApplVar.Entry);
        }
        ApplVar.Entry.Sign = 0x02;
#if (PRTLEN<25)
        FormatQty(ProgLineMes + 12, &ApplVar.Entry);     //lyq modified 2003\11\4
        ProgLineMes[13] = '%';
        i = 14;
#else
        FormatQty(ProgLineMes + 18, &ApplVar.Entry);     //lyq modified 2003\11\4
        ProgLineMes[19] = '%';
        i = 20;
#endif
    }
    ProgLineMes[i] = 0;

    PrintAmt(ProgLineMes, &ApplVar.Amt);//��ӡ�ۿ۽��

#if (defined(CASE_GREECE))//ϣ���ڽ��ǰ����ӡŷԪ����
    Prefix1 = PREFIX_1;
    Prefix2 = PREFIX_2;
#endif
    ApplVar.Qty = ZERO;
    if (BIT(ApplVar.Disc.Options, BIT4))    /* subtotal or item */
    {
        // discount for only one item
        ApplVar.BufCmd = 0;             /* don't consolidate item discounts */
        if (!BIT(KEYTONE, BIT4))    /* only add in function ? */
        {
            ApplVar.RetQty = ZERO;
            ApplVar.Cost = ZERO;
            ApplVar.DiscAmt = ApplVar.Amt;
            AddGroupTotal();
            AddDeptTotal();
            if (ApplVar.FPlu)   /* PLU ? */
                AddPluTotal();
            ApplVar.DiscAmt = ZERO;
        }
#if !defined(FISCAL)
        AddTaxItem(ApplVar.Dept.Tax & (ApplVar.Disc.Tax ^ 0xff),0); /*ccr090108 add to tax itemizers */
#else

#if (pbAmtDisc)//ccr091210>>>>>>>>>>
        if (ApplVar.PbNumber)
            if (!BIT(ApplVar.Disc.Options, BIT2))    /* percentage ? */
                ProcPbBufferDisc(1,0);// percentage discount
            else
                ProcPbBufferDisc(1,1);// net discount
        ApplVar.PBA.Disc.Sign= 0xff;//ccr091210 ????????????????????
#endif//<<<<<<<<<<<<<<<<

        AddTaxItem(ApplVar.Dept.Tax,ApplVar.Dept.Options);      /*ccr090108 add to tax itemizers */
//ccr090108>>>>>>>>>>>>>>>>>>>>>>>>>>>>>//??????????????????????????
        if (BIT(ApplVar.Dept.Options, BIT6))
            Add(&ApplVar.DiscItem[0], &ApplVar.Amt);
        if (BIT(ApplVar.Dept.Options, BIT7))
            Add(&ApplVar.DiscItem[1], &ApplVar.Amt);
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#endif

#if defined(FISCAL)
        if (!ApplVar.Dept.Tax)
            Add(&ApplVar.FExento, &ApplVar.Amt);    /* exento for fiscal report */
#endif
        if (!ApplVar.FTrain && !ApplVar.FSplit)    //    cc 20071018
        {
            Add(&ApplVar.FTotal,&ApplVar.Amt);/*    Total Sales for fiscal report     */
            Add(&ApplVar.TotalMax, &ApplVar.Amt);   //    ccr080901
        }
    }
    else
    {// discount after sub-total
//liuj 0625
        if (!BIT(KEYTONE, BIT4))    /* only add in function ? */
        {
            ApplVar.RetQty = ZERO;
            ApplVar.Cost = ZERO;
            ApplVar.DiscAmt = ApplVar.Amt;

            RamOffSet = ApplVar.AP.StartAddress[AddrTotl];
            for (ApplVar.PointerType = 0; ApplVar.PointerType < REPDEFMAX; ApplVar.PointerType++)     /* add total sales */
            {
                ApplVar.Size = ApplVar.AP.Sales.Size[ApplVar.PointerType];
                AddPointerTotal();
            }
            ApplVar.DiscAmt = ZERO;
        }
//liuj 0625
#if (!defined(FISCAL))// ccr090107
        if (ApplVar.Disc.Tax)           /* calculate discount into ApplVar.Tax itemizers */
#endif
            if (!BIT(ApplVar.Disc.Options, BIT2))    /* percentage ? */
            {
                // percentage discount after sub-total

#if (pbAmtDisc)//ccr091210>>>>>>>>>>
                if (ApplVar.PbNumber)
                    ProcPbBufferDisc(0,0);
#endif//<<<<<<<<<<<<<<<<<<<<<<<<<<<<


                ApplVar.Entry.Sign = 0x04;    /* 4 decimals */
                for (i = 0; i < ApplVar.AP.Tax.Number; i++)
                {
#if (!defined(FISCAL))// ccr090107
                    if (ApplVar.Disc.Tax & (0x01 << i))
#endif
                    {//ccr090108>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                        if (BIT(ApplVar.Disc.Options, BIT6))    /* items 1  PenGH  2008-11-26 15:10*/
                            d1 = ApplVar.TaxItem[1][i];
                        else if (BIT(ApplVar.Disc.Options, BIT7))    /* items 1  PenGH  2008-11-26 15:10*/
                            d1 = ApplVar.TaxItem[2][i];
                        else
                            d1 = ApplVar.TaxItem[0][i];

                        if (CheckNotZero(&d1))//ccr091208
                        {
                            Multiply(&d1, &ApplVar.Entry);
                            RoundBcd(&d1, 0);
                            AmtRound(1, &d1);
                            if (!BIT(ApplVar.Disc.Options, BIT3))    /* Positive or negative */
                                d1.Sign ^= 0x80;
                            if (ApplVar.FVoid)
                                d1.Sign ^= 0x80;
                            Add(&ApplVar.TaxItem[0][i], &d1);
                            if (BIT(ApplVar.Disc.Options, BIT6))    /* items 1  PenGH  2008-11-26 15:10*/
                            {
                                Add(&ApplVar.TaxItem[1][i], &d1);
                                Add(&ApplVar.DiscItem[0], &d1);//??????????????????????????
                            }
                            else if (BIT(ApplVar.Disc.Options, BIT7))    /* items 1  PenGH  2008-11-26 15:10*/
                            {
                                Add(&ApplVar.TaxItem[2][i], &d1);
                                Add(&ApplVar.DiscItem[1], &d1);//?????????????????????????
                            }
                        }
                    }
                    //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                }
            }
            else
            {//ccr091221>>>>>>>>>>>>>>>>>>>> net discount after sub-total

#if (pbAmtDisc)//ccr091210>>>>>>>>>>
                if (ApplVar.PbNumber)
                    ProcPbBufferDisc(0,1);
#endif//<<<<<<<<<<<<<<<<<<<<<<<<<<<<

                if (CheckNotZero(&ApplVar.SaleAmt))     /* active ? */
                {
                    d1 = ApplVar.Amt;
                    Multiply(&d1, &THOUSAND);
                    Divide(&d1, &ApplVar.SaleAmt);
                    RoundBcd(&d1, 0);

                    for (i = 0; i < ApplVar.AP.Tax.Number; i++)
                    {
#if (!defined(FISCAL))// ccr090107
                        if ((ApplVar.Disc.Tax & (0x01 << i)) && CheckNotZero(&ApplVar.TaxItem[0][i]))//ccr090108
#endif
                            if (CheckNotZero(&ApplVar.TaxItem[0][i]))//ccr090108
                            {
                                d2 = ApplVar.TaxItem[0][i];//ccr090108
                                Multiply(&d2, &d1);
                                Divide(&d2, &THOUSAND);
                                RoundBcd(&d2, 0);
                                d2.Sign &= 0xfc;
                                AmtRound(1, &d2);
                                Add(&ApplVar.TaxItem[0][i], &d2);  /*ccr090108 sign is already oke */
                            }


                        if (CheckNotZero(&ApplVar.TaxItem[1][i]))
                        {
                            d2 = ApplVar.TaxItem[1][i];//ccr090108
                            Multiply(&d2, &d1);
                            Divide(&d2, &THOUSAND);
                            RoundBcd(&d2, 0);
                            d2.Sign &= 0xfc;
                            AmtRound(1, &d2);
                            Add(&ApplVar.TaxItem[1][i], &d2);  /*ccr090108 sign is already oke */
                            Add(&ApplVar.DiscItem[0], &d2);//??????????????????????????
                        }

                        if (CheckNotZero(&ApplVar.TaxItem[2][i]))
                        {
                            d2 = ApplVar.TaxItem[2][i];//ccr090108
                            Multiply(&d2, &d1);
                            Divide(&d2, &THOUSAND);
                            RoundBcd(&d2, 0);
                            d2.Sign &= 0xfc;
                            AmtRound(1, &d2);
                            Add(&ApplVar.TaxItem[2][i], &d2);  /*ccr090108 sign is already oke */
                            Add(&ApplVar.DiscItem[1], &d2);//??????????????????????????
                        }
                    }
                }
            }//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//#if defined(FISCAL)		//cc 20071018
        if (!ApplVar.FTrain && !ApplVar.FSplit)
        {
            Add(&ApplVar.TotalMax, &ApplVar.Amt);   //    ccr080901
            Add(&ApplVar.FTotal, &ApplVar.Amt);    /*    ApplVar.Total Sales for fiscal report     */
        }
// #endif

        Add(&ApplVar.SaleAmt, &ApplVar.Amt);        /* also add to Sales ApplVar.Total */
    }
    if (sign)
    /* when sign 0x80 then Item refund or correction !!*/
    {
        ApplVar.Qty = ZERO;
        AddCorrecTotal();
    }
    ApplVar.Qty = ONE;
    ApplVar.Qty.Sign = sign;                /* Set sign incase Item Corr or Refund */
    if (ApplVar.FCanc)
        ApplVar.Qty.Sign ^= 0x80;
    if (ApplVar.FVoid || ApplVar.FCorr || ApplVar.FRefund)
    {
        ApplVar.Qty.Sign ^= 0x80;
        AddCorrecTotal();
    }
    if (ApplVar.FPlu == 0)
        memset(ApplVar.Plu.Random, 0, sizeof(ApplVar.Plu.Random));
#if(CASE_RAMBILL)
    if (ApplVar.FSub)                                   //    lyq2003
    {
        if (ApplVar.DiscNumber<2)
        {
            Collect_Data(SUBDISCADDLOG);
        }
        else
            Collect_Data(SUBDIRECTLOG);
    }
    else
    {
        if (ApplVar.DiscNumber<2)
        {
            Collect_Data(DISCADDLOG);
        }
        else
            Collect_Data(DIRECTLOG);
    }
#endif
#if DD_FISPRINTER == 1
    Add(&ApplVar.DiscountAmt,&ApplVar.Total.Amt);//ͳ�Ʊ����ܱ������ڵ��ۿ۽��
#endif
    AddDiscTotal();

    //lyq2004 added for don't print the message of void discount start
    if (ApplVar.FRegi && ApplVar.FVoid && (BIT(ApplVar.Disc.Options, BIT4)))
        ApplVar.RGNumber -=2;
    //lyq2004 added for don't print the message of void discount end

    ApplVar.FSale = 1;
    ApplVar.FVoid = 0;
    ApplVar.FCorr = 0;
    ApplVar.FSub = 0;       /* reset subtotal  */      //lyq2003
    ApplVar.FRefund = 0;
    ApplVar.RepeatCount = 0;
    ApplVar.FDisc = 0;          //cc 20071102
    if ((ApplVar.Disc.Options & (BIT2+BIT4)) != BIT2) /* not sub amt disc? */
        ApplVar.BufCmd = 0;     /* don't consolidate discounts */
}
