#define MODIFIER_C 2
#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"

/***************************************************************/

void GetModiOffSet()
{
	RamOffSet = (UnLong)ApplVar.ModiNumber * ApplVar.AP.Modi.CapSize + ApplVar.AP.StartAddress[AddrModi] ;
}

void WriteModi()
{
    if (ApplVar.ModiNumber < ApplVar.AP.Modi.Number)
    {
		GetModiOffSet();
		WriteRam(ApplVar.Modi.Name, ApplVar.AP.Modi.CapSize);
    }
}

void ReadModi()
{
    GetModiOffSet();
    ReadRam(ApplVar.Modi.Name, ApplVar.AP.Modi.CapSize);
    ApplVar.Modi.Name[ApplVar.AP.Modi.CapSize] = 0;
}


void GetModifier()
{
#if defined(CASE_EURO) //!!! GREECE_ONLY !!!
    short ml;
    char prompt[5];

    if (ApplVar.Key.Code == MODI && !Appl_EntryCounter)
    {
        if (ApplVar.CommentCou<COMMENTSMAX)
        {
           while (ApplVar.CommentCou<COMMENTSMAX)
           {
              prompt[0]=ApplVar.CommentCou+'1';prompt[1]=':';prompt[2]=0;
#if defined(CASE_GREECE)//ccr2018-03-21
              PutsO(prompt);
              prompt[0]=0;//ccr2018-03-21 Ŀ������prompt[0]�ͳ���󰴼�
#endif
               ml=GetStrFromKBD('*',prompt,NULL,PRTLEN,0,NO);
               if (ml>0)
               {
                   strcpy(ApplVar.CommentStr[ApplVar.CommentCou],&AtEntryBuffer(Appl_EntryCounter));
                   ApplVar.CommentCou++;
               }
               else
               {
#if defined(CASE_GREECE)//ccr2018-03-21
                  if (prompt[0])
                     KeyFrHost=prompt[0];
#endif
                  break;
               }
           }
        }
        else
            ApplVar.ErrorNumber=ERROR_ID(CWXXI04);
        return;
    }
#endif
    if (ApplVar.ModiCount > 3)
    {
		ApplVar.ErrorNumber=ERROR_ID(CWXXI46);
		return;
    }
    ApplVar.ModiNumber = 0;
    if (ApplVar.Key.Code == MODI && Appl_NumberEntry < 1000)
		ApplVar.ModiNumber = Appl_NumberEntry;
    else if (!Appl_EntryCounter)
    {
		ApplVar.ModiNumber = ApplVar.Key.Code - MODI;
		WORDtoBCD(ApplVar.Entry.Value, ApplVar.ModiNumber);
    }
    if (!ApplVar.ModiNumber || ApplVar.ModiNumber > ApplVar.AP.Modi.Number)
    {
		ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
		return;
    }
    if (BIT(KPPRICE, BIT5))     /* german system then enter first */
    {
		StoreInBuffer();
		ApplVar.RGRec.Key.Code = 0;
    }
    else if (ApplVar.RGRec.Key.Code < MODI || (ApplVar.RGRec.Key.Code > MODI + 999 && ApplVar.RGRec.Key.Code < DEPT))
    {
		ApplVar.ErrorNumber=ERROR_ID(CWXXI23);
		return;
    }
    ApplVar.ModiNumber--;
    ReadModi();
    PutsO(FormatQtyStr(DText[DTEXT_MODIFIER], &ApplVar.Entry, DISLEN));
    if (!BIT(KPPRICE, BIT5))     /* german system then enter first */
    {                       /* and print with department */
		if (!BIT(PLU_PRINT,BIT2)
			|| !ApplVar.AP.Plu.CapSize)     /* print depart name on receipt */
		{
			MemSet(SysBuf, sizeof(SysBuf), ' ');
		    strcpy(SysBuf + 2, ApplVar.Modi.Name);
			PrintStr(SysBuf);
		}
    }
    ApplVar.ModNum[ApplVar.ModiCount] = ApplVar.ModiNumber;
    ApplVar.ModiCount++;
    ApplVar.OldModiCount = 0;
}

