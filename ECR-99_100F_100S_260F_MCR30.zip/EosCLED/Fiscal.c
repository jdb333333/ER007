#define FISCAL_C
#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
#include "fiscal.h"
#include "EJournal.h"
#include "message.h"
#if (PC_EMUKEY==1)
    #include "FEcrTest.h"
#endif

#define PRN_SHCP	0	// ī����汾 //
#define SHCP_S		28
#define SHCP_H		29
#define SHCP_C		30
#define SHCP_P		31


#ifdef CASE_FATFS_EJ
extern void  CheckEJ(BYTE getSize);
#endif
void FiscalTrailer(void);
short Fiscal_RecallData(void);
short Fiscal_AddResetData(void);
short Fiscal_AddDisconnect(WORD disType);


//ccr2014-PANAMA>>>>
const FSTRING USERPROMPT[cUSERMAX]={
    MESG_FCName ,//'Name:'	//1-�˿�����
    MESG_FCRUC	,//'RUC:'	//2-�˿�RUC,
    MESG_FCDebit,//'RNo:'	//3-�����վݺ�
    MESG_FCAddr ,//'Addr:'	//4-�˿͵�ַ
    MESG_FVatNo //'FNo:'   //5-��������վݵĹ˿�˰����
};
//<<<<PANAMA

/***************************************************************/
#if defined(FISCAL)
WORD    sStartZ, sEndZ;

//ccr2014-07-29>>>>>>>>>>>>>>
/**
 * ����FM��EJ�Ƿ����,������ʱ,��������
 *
 * @author EutronSoftware (2014-07-29)
 *
 * @return NONE
 */
void FM_EJ_Exist(void)
{
    if (/* ApplVar.FiscalFlags == NOFM || */!Bios_FM_CheckPresence())
    {
        ApplVar.FMPullOut[NOFM_FLAG] = 0x69;//ccr071212
        ApplVar.FiscalFlags = NOFM;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI74);

        Save_Config(true);
        do
        {//ccr2014-07-29 block the ECR
            CheckError(0);
        }  while (1);//(!MMC_CheckPresence());
    }

#ifdef CASE_FATFS_EJ
    if (!MMC_CheckPresence())//ccr2014-07-29
//ccr2014-07-29             && (ApplVar.FiscalFlags==FISCALOK || ApplVar.FiscalFlags==FMISNEW || ApplVar.FiscalFlags==FM_X_EJ))//ֻ�е�����FISCALOKʱ,�ż��EJ�Ƿ����.
    {
        ApplVar.FiscalFlags = NOEJ;     // no EJ //
        ApplVar.ErrorNumber=ERROR_ID(CWXXI83);
        do
        {//ccr20140617 block the ECR
            CheckError(0);
        }  while (1);//(!MMC_CheckPresence());
    }
#endif
}

/***************************************************************************
 * ��ӡ˰�ظ��ּ�����
 *
 * @author EutronSoftware (2017-04-28)
 ***************************************************************************/
const WORD FXCOUNTMAX[FISxCOUNTMAX]={FxFMMAX,FxEJMAX,FCMOSERRMAX,FxPRINTERMAX};//ccr2018-03-28

void    PrintFiscalAttribute(void)
{//ccr071212
    int i;
//    RFeed(1);
    if (ApplVar.FReport == Z)//ccr2017-06-01
        PrintLine('-');

#if (0)//defined(CASE_GREECE)
     memset(SysBuf,' ',PRTLEN);
     CopyFrStr(SysBuf,Msg[TOTALZCOUNTER].str);
     if (ApplVar.FTrain)
         ULongtoASCZER0(SysBuf+PRTLEN-1,ApplVar.ZCount[TRAINZNUM],4);
     else
         ULongtoASCZER0(SysBuf+PRTLEN-1,ApplVar.ZCount[FISCALZNUM],4);
     RJPrint(0,SysBuf);

     GetReceiptTotalNumber(SysBuf);//ccr2017-08-02
     RJPrint(0,SysBuf);
#else
    if (ApplVar.FisNumber.TotalClearNum)
    {
       memset(SysBuf,' ',PRTLEN);
       CopyFrStr(SysBuf, MESG_Z_REMAIN);
       WORDtoASC(SysBuf+PRTLEN-1, FDAILYZMAX-ApplVar.FisNumber.TotalClearNum);
       SysBuf[PRTLEN] = 0;
       RJPrint(0, SysBuf);
    }
#endif

    for (i=0;i<FISxCOUNTMAX;i++)
    {
       if (ApplVar.FisNumber.TotalXUnit[i])
       {
          memset(SysBuf,' ',PRTLEN);
          CopyFrStr(SysBuf, Msg[MSGECRxFM+i].str);
//          WORDtoASC(SysBuf+PRTLEN-1, FXCOUNTMAX[i]);
          WORDtoASC(SysBuf+PRTLEN-1, ApplVar.FisNumber.TotalXUnit[i]);
//          SysBuf[PRTLEN-5]='/';
          SysBuf[PRTLEN]=0;
          RJPrint(0,SysBuf);
       }
    }

#if (0)//ccr2018-04-03>>>>>>>>>>
    if (ApplVar.FisNumber.TotalResetNum)
    {
       memset(SysBuf,' ',PRTLEN);
       CopyFrStr(SysBuf, Msg[MACRESET].str);
       WORDtoASC(SysBuf+PRTLEN-1, FRESETMAX);
       WORDtoASC(SysBuf+PRTLEN-7, ApplVar.FisNumber.TotalResetNum);
       SysBuf[PRTLEN-5]='/';    SysBuf[PRTLEN]=0;
       RJPrint(0,SysBuf);
    }
#endif//ccr2018-04-03<<<<<<<<<<<<

    if (ApplVar.FisNumber.TotalTaxChangeNum)
    {
       memset(SysBuf,' ',PRTLEN);
       CopyFrStr(SysBuf, Msg[CHANGETAX].str);
//       WORDtoASC(SysBuf+PRTLEN-1, FTAXCHGMAX);
       WORDtoASC(SysBuf+PRTLEN-1, ApplVar.FisNumber.TotalTaxChangeNum);
//       SysBuf[PRTLEN-5]='/';
       SysBuf[PRTLEN]=0;
       RJPrint(0,SysBuf);
    }

    //ccr2017-08-08>>>>>>>>>>>>>
    if (ApplVar.FisNumber.TotalDateChangeNum)
    {
       memset(SysBuf,' ',PRTLEN);
       CopyFrStr(SysBuf, Msg[CHANGEDATETIME].str);
//       WORDtoASC(SysBuf+PRTLEN-1, FDATECHGMAX);
       WORDtoASC(SysBuf+PRTLEN-1, ApplVar.FisNumber.TotalDateChangeNum);
//       SysBuf[PRTLEN-5]='/';
       SysBuf[PRTLEN]=0;
       RJPrint(0,SysBuf);
    }
    //ccr2017-08-08<<<<<<<<<<<<<<<<

    if (ApplVar.FisNumber.TotalHeadChangeNum)
    {
       memset(SysBuf,' ',PRTLEN);
       CopyFrStr(SysBuf, Msg[CHANGEHEAD].str);
//       WORDtoASC(SysBuf+PRTLEN-1, FHEADCHGMAX);
       WORDtoASC(SysBuf+PRTLEN-1, ApplVar.FisNumber.TotalHeadChangeNum);
//       SysBuf[PRTLEN-5]='/';
       SysBuf[PRTLEN]=0;
       RJPrint(0,SysBuf);
    }

    PrintLine('=');
}


void EncodeTimeFiscal(BYTE* pD0,char toTime[])
{
    toTime[0] = ((pD0[0] >> 4) & 0x0f) + '0';
    toTime[1] = (pD0[0] & 0x0f) + '0';
    toTime[2] = ':';
    toTime[3] = ((pD0[1] >> 4) & 0x0f) + '0';
    toTime[4] = (pD0[1] & 0x0f) + '0';
    toTime[5] = ':';
    toTime[6] = ((pD0[2] >> 4) & 0x0f) + '0';
    toTime[7] = (pD0[2] & 0x0f) + '0';
}
#endif
/**
 * ��ӡ��Ϣ:��StrMess׷����strType֮���ӡ
 * strType����,  StrMess����
 * @author EutronSoftware (2014-07-21)
 *
 * @param strType :��ӡ����������
 * @param StrMess :��Ҫ��ӡ����Ϣ
 * @param width :StrMess�Ŀ���,<PRTLEN
 */
void PrintMessagesBy(char *strType,char *StrMess,int width)
{
    char pBuf[PRTLEN+1];
    int  i=strlen(strType);

    if (width>PRTLEN) width = PRTLEN;
    if (i>PRTLEN) i = PRTLEN;

    memset(pBuf,' ',PRTLEN);
    memcpy(pBuf,strType,i);
    i = strlen(StrMess);
    if (i>width) i=width;
    memcpy(pBuf+PRTLEN-i,StrMess,i);
    pBuf[PRTLEN]=0;
    RJPrint(0,pBuf);//��ӡ�����˰����
}
//ccr091027>>>>>>>>>>>>>>>>>>>>>>>>>
/*******************************************************
 * ��ȡ��ǰ�վݺ�
 *
 * @author EutronSoftware (2018-02-06)
 *
 * @return WORD :�����տ����ǰ��ͬ״̬,���ض�Ӧ���վݺ�
 *******************************************************/
WORD ReceiptNumber()
{
    if ( ApplVar.FTrain )   //  PenGH 2008-11-27
    {
        return ApplVar.FisNumber.ReceiptNum[TRECEIPTS];
    }
    else if (!ApplVar.FStatus || ApplVar.FInv)
    {
        return ApplVar.FisNumber.ReceiptNum[NRECEIPTS];
    }
    else
    {
        return ApplVar.FisNumber.ReceiptNum[FRECEIPTS];
    }
}

/*******************************************************
 * �ָ���ǰ�վݺ�
 *
 * @author EutronSoftware (2018-03-21)
 *
 * @return WORD :�����տ����ǰ��ͬ״̬,���ض�Ӧ���վݺ�
 *******************************************************/
void ResetReceiptNumber(WORD num)
{
    if ( ApplVar.FTrain )   //  PenGH 2008-11-27
    {
        ApplVar.FisNumber.ReceiptNum[TRECEIPTS]=num;
    }
    else if (!ApplVar.FStatus || ApplVar.FInv)
    {
        ApplVar.FisNumber.ReceiptNum[NRECEIPTS]=num;
    }
    else
    {
        ApplVar.FisNumber.ReceiptNum[FRECEIPTS]=num;
    }
}


void AddReceiptNumber()
{
#if defined(FISCAL)
    ApplVar.SaleQty = ZERO;
//liuj 0531 PM
//	if(Bios_FM_Read(&ApplVar.Fis_Header, FISECRIDADDR, sizeof(ApplVar.Fis_Header)) && ApplVar.Fis_Header.FFlag != FMINITEDFLAG)
//		ApplVar.FStatus = 0;
    if ( ApplVar.FTrain  )
    {// ��ѵ�վݺ� //
        ApplVar.FisNumber.ReceiptNum[TRECEIPTS]++;
        if (ApplVar.CentralLock==RG || ApplVar.CentralLock==MG)//ccr2017-08-01
            ApplVar.FisNumber.TotalReceiptNum[TRECEIPTS]++;
    }
#if (DD_FISPRINTER==0)
    else if (!ApplVar.FStatus || ApplVar.FInv)
    {// ��˰�վݺ� //
        ApplVar.FisNumber.ReceiptNum[NRECEIPTS]++;
        if (ApplVar.CentralLock==RG || ApplVar.CentralLock==MG)//ccr2017-08-01
            ApplVar.FisNumber.TotalReceiptNum[NRECEIPTS]++;
    }
    else
    {// ��˰�վݺ� //
        ApplVar.FisNumber.ReceiptNum[FRECEIPTS]++;//ApplVar.SaleReceipts
        if (ApplVar.CentralLock==RG || ApplVar.CentralLock==MG)//ccr2017-08-01
            ApplVar.FisNumber.TotalReceiptNum[FRECEIPTS]++;
    }
#else
    else if (ApplVar.FStatus || BIT(ApplVar.Fiscal_Status,FISCALDOC))
    {
        ApplVar.FisNumber.ReceiptNum[FRECEIPTS]++;//ApplVar.SaleReceipts
        if (ApplVar.CentralLock==RG || ApplVar.CentralLock==MG)//ccr2017-08-01
            ApplVar.FisNumber.TotalReceiptNum[FRECEIPTS]++;
        i = 3;  // ��˰�վݺ� //
    }
    else
    {// ��˰�վݺ� //
        ApplVar.FisNumber.ReceiptNum[NRECEIPTS]++;
        if (ApplVar.CentralLock==RG || ApplVar.CentralLock==MG)//ccr2017-08-01
            ApplVar.FisNumber.TotalReceiptNum[NRECEIPTS]++;
    }
#endif
#else
    if (!ApplVar.FInv && ApplVar.FCanc != 2 && !ApplVar.FProforma)
    {
        if (ApplVar.FTrain)
            ApplVar.FisNumber.ReceiptNum[TRECEIPTS]++;
        else
            ApplVar.FisNumber.ReceiptNum[FRECEIPTS]++;//ApplVar.SaleReceipts
    }
#endif
}
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//Get the index of clerk and convert it into ascii string for print.
//to���ֽ�������>=PRTLEN
void GetReceiptNumber(char *to)
{
#if defined(FISCAL)
#if defined(CASE_EURO)//ccr2014-09-15>>>>>>>>>
    //��ӡZ������,Fiscal/None Fiscal�վݺŴ�1��ʼ
    if ( ApplVar.FTrain )   //  PenGH 2008-11-27
    {
        WORDtoASCZero(to+PRTLEN-1,ApplVar.FisNumber.ReceiptNum[TRECEIPTS]);
        CopyFrStr(to,MESG_TRAINRECNo);
    }
    else if (!ApplVar.FStatus || ApplVar.FInv)
    {
        WORDtoASCZero(to+PRTLEN-1,ApplVar.FisNumber.ReceiptNum[NRECEIPTS]);
        CopyFrStr(to,"NONE FISCAL No.");
    }
    else
    {
        WORDtoASCZero(to+PRTLEN-1,ApplVar.FisNumber.ReceiptNum[FRECEIPTS]);//ApplVar.SaleReceipts
        CopyFrStr(to,MESG_RECEIPTNo);
    }

#else//ccr2014-09-15-----------------------------------------------------------------------------

    if ( ApplVar.FTrain )   //  PenGH 2008-11-27
    {
        sprintf(to,"#%.8lu",ApplVar.FisNumber.TotalReceiptNum[TRECEIPTS]);/* ccr091027 is in fiscal training */
    }
    else if (!ApplVar.FStatus || ApplVar.FInv)
    {
        sprintf(to,"N%.8lu",ApplVar.FisNumber.TotalReceiptNum[NRECEIPTS]);/* ccr091027 is none fiscal  */
    }
    else
    {
        sprintf(to,"F%.8lu",ApplVar.FisNumber.TotalReceiptNum[FRECEIPTS]);/* ccr091027 is in  fiscal  */
    }

#endif//ccr2014-09-15<<<<<<<
    ApplVar.LastInvoiceDate = EncordBCDDate((WORD)(Now.year & 0x00ff), (WORD)Now.month, (WORD)Now.day);      //last invoice date		20070118
    ApplVar.LastInvoiceTime[0] = Now.hour;      //last invoice time		20070118
    ApplVar.LastInvoiceTime[1] = Now.min;
    ApplVar.LastInvoiceTime[2] = Now.sec;

#else
    {
        if ((CHARSET & 0xf0) == 0x10 || (SLIP != 4 && ((CHARSET & 0x0f) == 3 || (CHARSET & 0x0f) == 7)))  /* number sign not available */
            *to = 'N';
        else
            *to = '#';
//ccr091027>>>>>>>>
        if (ApplVar.FTrain)
            sprintf(to+1,"%.8lu",ApplVar.FisNumber.TotalReceiptNum[TRECEIPTS]);/* ccr091027 is train  */
        else
            sprintf(to+1,"%.8lu",ApplVar.FisNumber.TotalReceiptNum[FRECEIPTS]);/* ccr091027 is fiscal  */
/* ccr091027
        if (BIT(KPPRICE, BIT7))
            CWORD(to[1])=CWORD(sbuf[4]);
        else
        {
            CWORD(to[1])=CWORD(sbuf[1]);
            CWORD(to[3])=CWORD(sbuf[3]);
            to[5]=sbuf[5];
        }
*/
//<<<<<<<<<<<<<<<<<
    }
#endif
}

#if defined(FISCAL)
BYTE VerifyCRC(BYTE *Area,short pLen,short EnCode)
{
    BYTE sCRC;
    short i;

    sCRC = 0;
    for (i=0;i<pLen-2;i++)
        sCRC ^= Area[i];

    if (EnCode)
        return(sCRC + 1);
    else if ((sCRC+1) == Area[pLen-2])
        return 1;

    return 0;
}

/***************************************************************/
BYTE Read_FiscalRam(VOIDFAR *Dest, UnLong SrcAdr, WORD Num)
{
    if (ApplVar.FiscalFlags == NOFM)
        return 0;

    if (Bios_FM_Read(Dest,SrcAdr,Num))
        return 1;

    ApplVar.FiscalFlags = FMERROR;
#if DD_FISPRINTER

    SETBIT(ApplVar.Fiscal_Status, FM_ERR);

#endif
    return 0;
}

BYTE Write_FiscalRam(UnLong DestAdr, VOIDFAR *Src, WORD Num)
{
    if (ApplVar.FiscalFlags == NOFM)
        return 0;


    if (ApplVar.FTrain)
        return 0;

    if (DestAdr > FISDATAADDR)
    {
        if (DestAdr>= FISMEMERYSIZE - FISRECORDLEN)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI86);ApplVar.FiscalFlags = FMFULL;
#if DD_FISPRINTER
            SETBIT(ApplVar.Fiscal_Status, FM_FULL);
#endif
            return 1;
        }
        else if (DestAdr>=(FISMEMERYSIZE - FISMEMERYFULLSIZE_LESS))//ccr091104
        {
            ApplVar.FiscalFlags = FMFULL;ApplVar.ErrorNumber=ERROR_ID(CWXXI86);     // FM FULL

#if DD_FISPRINTER
            SETBIT(ApplVar.Fiscal_Status, FM_FULL);
#endif

        }
        else if (DestAdr>=(FISMEMERYSIZE - ( FISMEMERYFULLSIZE_LESS*10))
                 && DestAdr<(FISMEMERYSIZE - (FISMEMERYFULLSIZE_LESS*10)+Num))//ccr091104
        {
//			ApplVar.ErrorNumber=ERROR_ID(CWXXI77);		//ccr091104 low FM
            ApplVar.FiscalFlags = FMLESS;
#if DD_FISPRINTER
            SETBIT(ApplVar.Fiscal_Status, FM_100);
#endif

        }
    }

    if (Bios_FM_Write(DestAdr,Src,Num))
    {
        return 1;
    }
#if DD_FISPRINTER
    SETBIT(ApplVar.Fiscal_Status, FM_ERR);
#endif

    ApplVar.FiscalFlags = BADFM;
    ApplVar.ErrorNumber=ERROR_ID(CWXXI76);
    return 0;
}
#endif
//--------------------------------------------------------------
//20070313 VZLA format >>>>>>>>>>>>>>>>>>>>>>
void PrintReceiptNum()
{
    //print date time
    memset(SysBuf,' ', sizeof(SysBuf));
    DateTimeToStr(SysBuf,0);

    //AddReceiptNumber();	//

    if (((SLIPINFO & (BIT1+BIT2)) != BIT1+BIT2) ||
        (COMMA & (BIT3+BIT6+BIT7)) != (BIT3+BIT6+BIT7))  // print something //
    {
        SysBuf[PRTLEN] = 0;
        PrintStr(SysBuf);

        RESETBIT(ApplVar.PrintLayOut, BIT2);
        if (BIT(SLIPINFO, BIT3) && (ApplVar.Key.Code>PORA + 100 && ApplVar.Key.Code < TEND + 100))     // print on slip ? // // lyq added for slip  start 20040324 //
        {
            SlipMargin();
            PrintSlip(SysBuf);
            //CLRMyFlags( ENSLIPPB);	 //lyq added for slip 20040324
        }   // lyq added for slip end 20040324 //
    }
    RFeed(1);
}
/*********************************************************************
 * ��ӡ NON FISCAL ��ʾ��
 *
 * @author EutronSoftware (2018-01-09)
 *
 * @param inc :=1,һ��������Ʊ�ݵĿ�ʼλ�õ���,����˰Ʊ�ݼ�����+1;
 *             =0,һ��������Ʊ�ݵĽ���λ�õ���,��˰Ʊ�ݼ���������+1;
 ********************************************************************/
void Print_NonFiscal(BYTE inc)//ccr2018-01-09
{
    static BYTE noFlags=0;
//ccr2018-01-09    if (!ApplVar.FStatus || ApplVar.FTrain)
    if (noFlags!=inc)
    {
        ApplVar.FStatus=0;//ccr2018-01-09
        RFeed(1);
        if (inc)         //ccr2018-01-09
        {
            ApplVar.FisNumber.ReceiptNum[NRECEIPTS]++;//ccr2018-01-09
#if defined(CASE_GREECE)
            PrintStr_Center((char*)MsgNOTARECEIPT,true);
            PrintStr_Center((char*)MsgTEMPRECEIPTSTART,true);
#elif defined(CASE_ITALIA)
            PrintStr_Center((char *)Msg[NONFISCAL].str,true);
#endif
        }
        else
        {
            MemSet(SysBuf, sizeof(SysBuf), ' ');
            GetReceiptNumber(SysBuf);
            RJPrint(0,SysBuf);
#if defined(CASE_GREECE)
            PrintStr_Center(ApplVar.ApprovalCode,true);//ccr2018-03-13
            PrintStr_Center((char*)MsgTEMPRECEIPTEND,true);
#elif defined(CASE_ITALIA)
            PrintStr_Center((char *)Msg[NONFISCAL].str,true);
#endif

        }
        RFeed(1);
    }
    noFlags=inc;
}


#if defined(FISCAL)
//˰��Ҫ��:����ӡ�վ�ʱ�������ȱֽ,װֽ�����´�ӡ���վ�,�����վݵ�������
void PrintAgain()
{
    WORD saveclerk ;
    BYTE SaveRGNumber,saveCp, SaveSP,SavePrintLayOut,SaveContFlag;

    CLRBIT(ApplVar.Fiscal_PrintFlag,BIT7);
    if (BIT(ApplVar.Fiscal_PrintFlag,(BIT0 | BIT1)))
#if !defined(DEBUGBYPC)//ccr2018-03-07
    {
        ResetPopOutofReceipt();//ccr2018-03-07��ӡ������Ŀʱ,ȱֽ,���´�ӡ�վ�
    }
#else
    {
        if (!BIT(ApplVar.Fiscal_PrintFlag,BIT1))
        {
//			PCBuffer[0] = ApplVar.Fiscal_PrintFlag;
//			PrnBuffer(PCBuffer,1);
#if (0) //ccr2018-03-07>>>>>>>>>
           StoreInBuffer();
#ifdef CASE_FATFS_EJ
            memset(SysBuf,' ',PRTLEN);
#if (RIFMUST)//PANAMA
            strcpy(SysBuf, Msg[RIFCODE].str);
            strcat(SysBuf, ApplVar.Fis_Header.FRIFNumber);
            saveclerk =strlen(SysBuf);
            SysBuf[saveclerk]=' ';
#elif (DEVICEMUST)//PANAMA
            strcpy(SysBuf, DEVICECODE, strlen(DEVICECODE));
            strcat(SysBuf, ApplVar.Fis_Header.FDeviceCode);
            saveclerk =strlen(SysBuf);
            SysBuf[saveclerk]=' ';
#endif
            sprintf(SysBuf+PRTLEN-9,"E%.8lu",ApplVar.EJLogHeader.DocNumber_EJ);//ccr091103
            RJPrint(0, SysBuf);     //liuj 0528

#if (RIFMUST && DEVICEMUST)//PANAMA
            memset(SysBuf, ' ', sizeof(SysBuf));
            memcpy(SysBuf, DEVICECODE, strlen(DEVICECODE));
            strcpy(SysBuf+PRTLEN-strlen(ApplVar.Fis_Header.FDeviceCode), ApplVar.Fis_Header.FDeviceCode);
            SysBuf[PRTLEN] = 0;
            RJPrint(0, SysBuf);
#endif

#endif
            RFeed(10);
            PrintHeader();
#endif //ccr2018-03-07<<<<<<<<<<<<<<<<<<
        }

        SaveContFlag=BIT(ApplVar.ContFlag,(STOREEJ2_AZ));//ccr2018-03-07
        RESETBIT(ApplVar.ContFlag,(STOREEJ2_AZ));//ccr2018-03-07
        RFeed(1);
        saveCp = ApplVar.CopyReceipt+1;
        saveclerk = ApplVar.ClerkNumber ;
        SaveSP = SLIP;
        SLIP = 0;
        ApplVar.BufRec = 1;
        SaveRGNumber = ApplVar.RGNumber;

        ProcessBuffer();    /* second receipt */
        ApplVar.ContFlag |= SaveContFlag;//ccr2018-03-07
        ApplVar.RGNumber = SaveRGNumber;
        ApplVar.ClerkNumber = saveclerk ;
        ApplVar.CopyReceipt = saveCp;
        SLIP = SaveSP;

        ApplVar.Fiscal_PrintFlag = 0;
        ApplVar.OldClerk = ApplVar.ClerkNumber; //  /* force clerk not  print start transaction */

    }
#endif//ccr2018-03-07<<<<<<<<<<<<
}


//ccr070424>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
void AddBcdWithLong(BCD* addTo,long addFr)
{
    BCD sVal;

    if (addFr)//ccr070424
    {
        LongToBCD(&sVal, addFr);
        Add(addTo,&sVal);
    }
}
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
/**************************************************************************
 * ��ѹ���͵����ڰ�ϵͳ��ʽ����ת��Ϊ�ַ�������
 *
 * @author EutronSoftware (2017-05-02)
 *
 * @param pD0
 * @param toDate
 **************************************************************************/
void DecordDateFiscal(WORD pD0,char toDate[])
{
    WORD  sYear, sDay, sMonth;
    memset(toDate,' ',10);

    sYear = (pD0 >> 9) + 2000;
    sMonth = (pD0 >> 5) & 0x0f;
    sDay = pD0 & 0x1f;

    if (sMonth<1 || sMonth>12)
        sMonth = 1;
    if (sDay<1 || sDay>31)
        sDay=1;


    switch (TIME_DATE)
    {
    case 1:/*"Mon,MM-DD-YYYY" */
        WORDtoASC(toDate+9, sYear);
        WORDtoASC(toDate+1, sMonth);
        WORDtoASC(toDate+4, sDay);

        if (toDate[0]==' ')
            toDate[0]='0';
        if (toDate[3]==' ')
            toDate[3]='0';
        toDate[2]=toDate[5]=DATECHAR;
        toDate[10] = 0;
        break;
    case 2:/*"Mon,YYYY-MM-DD" */
        WORDtoASC(toDate+3, sYear);
        WORDtoASC(toDate+6, sMonth);
        WORDtoASC(toDate+9, sDay);

        if (toDate[5]==' ')
            toDate[5]='0';
        if (toDate[8]==' ')
            toDate[8]='0';
        toDate[4]=toDate[7]=DATECHAR;
        toDate[10] = 0;
        break;
    default:/*"Mon,DD-MM-YYYY" */
        WORDtoASC(toDate+9, sYear);
        WORDtoASC(toDate+4, sMonth);
        WORDtoASC(toDate+1, sDay);

        if (toDate[0]==' ')
            toDate[0]='0';
        if (toDate[3]==' ')
            toDate[3]='0';
        toDate[2]=toDate[5]=DATECHAR;
        toDate[10] = 0;
        break;
    }
}

//write produced date to fiscal card
void ProducedDate()
{
    short i;


//ccr070531>>>>>>>>>>>>>>>>>>>>>
    memset(&ApplVar.FiscalHead,0,sizeof(ApplVar.FiscalHead));
    memset(&ApplVar.FisNumber,0,sizeof(ApplVar.FisNumber));
    ApplVar.ZCount[FISCALZNUM]= ApplVar.ZCount[TRAINZNUM]=1;//ccr091027

    ApplVar.FisNumber.TotalClearNum = 1; // liuj 0526

    ApplVar.FiscalHead.MaxP = FISDATAADDR;
    ApplVar.FiscalHead.EJTblP =  FISEJADDR ;
    ApplVar.FiscalHead.ReadP = FISDATAADDR;
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    memset(&ApplVar.Fis_Header,0xff, sizeof(ApplVar.Fis_Header));
    memcpy(&ApplVar.Fis_Header.FFirst,FirmCode,16);
    GetTimeDate(&Now);
    ApplVar.Fis_Header.FPFirst[0] = (Now.year & 0xff);      /* YY */
    ApplVar.Fis_Header.FPFirst[1] = Now.month;              /* MM */
    ApplVar.Fis_Header.FPFirst[2] = Now.day;                /* DD */
    ApplVar.Fis_Header.FPFirst[3] = Now.hour;               /* HH */
    ApplVar.Fis_Header.FPFirst[4] = Now.min;                /* MM */
    ApplVar.Fis_Header.FPFirst[5] = Now.sec;                /* SS */


    if (!Bios_FM_Write(FISECRIDADDR,
                       &ApplVar.Fis_Header.FFirst,
                       sizeof(ApplVar.Fis_Header.FFirst) +
                       sizeof(ApplVar.Fis_Header.FPFirst)))
    {
        ApplVar.FiscalFlags = BADFM;    //20070302 FISINVALID;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI76);     /* write fiscal date error */
    }
    else
    {
        ApplVar.FiscalFlags = FMISNEW;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI94);
    }
}

//���˰�ػ���״̬(�Ƿ������˰�س�ʼ��
//ecrUsed��ʾ�տ���Ƿ�ʹ�ù���ʹ�ù����տ�������˰�ش洢���лָ�����
void CheckFiscal(bool ecrUsed)
{
    struct FIS_HEADER temphead;
    BYTE sFlag,sTp,sFiscalFlags=0;
		//ccr2018-04-04>>>>>>
    if (ApplVar.FiscalFlags == NOFM)
		{
			  sFiscalFlags= NOFM;
				if (!Bios_FM_CheckPresence()) 
					ApplVar.FiscalFlags = NOFM;
				else
				{
					ApplVar.FiscalFlags = FISCALOK;//�����տ��˰�س�ʼ���ɹ�
					ecrUsed=false;
				}	
		}			
		//ccr2018-04-04<<<<<<<	
    if (ApplVar.FiscalFlags == NOFM/* || !Bios_FM_CheckPresence()*/) //ccr2018-04-04
    {
        ApplVar.FMPullOut[NOFM_FLAG] = 0x69;//ccr071212
        ApplVar.FiscalFlags = NOFM;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI74);//ccr070719
        Save_Config(true);
        return;
    }
    else if (!ecrUsed)// It is reset by MAC
    {
        if (!Read_FiscalRam(&ApplVar.Fis_Header, FISECRIDADDR, sizeof(ApplVar.Fis_Header)))
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI76);     /* write fiscal date error */
            return;
        }
        memcpy(&temphead,&ApplVar.Fis_Header, sizeof(ApplVar.Fis_Header));
    }
    else if (!ApplVar.FRegi && ApplVar.ZReport == 2)     /* check if day changed when not in transaction */
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI75);       /* first take fiscal Z-ApplVar.Report */
        return;
    }

    if (!ecrUsed || Read_FiscalRam(&temphead,FISECRIDADDR,sizeof(temphead)))
    {
        memcpy(PCBuffer,FMSetCard, 16);     // liuj 0601
        if (CompareBCDValue(temphead.FFirst,(BYTE*)PCBuffer, 16) == 0)       // is test FM
        {
            if (!ecrUsed)  // init
                ApplVar.FiscalFlags = TESTFM;
            else
                ApplVar.FiscalFlags = FMERROR;
            return;
        }

/*
            if(temphead.FCRC != ApplVar.Fis_Header.FCRC && MACSwitch==FALSE)  // the code check sum is changed
            {
                ApplVar.FiscalFlags = CHECKSUMCHANGED;

                return ;
            }*/

        for (sTp=0,sFlag=0;sTp < 16;sTp++)
        {
            if (temphead.FFirst[sTp] == 0xff)
            {
                sFlag ++;
                continue;
            }
            else if (temphead.FFirst[sTp] != (BYTE)FirmCode[sTp])
            {
                ApplVar.FiscalFlags = BADFM;//˰�ش洢���쳣
                ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
                return ;
            }

        }

        if (sFlag == 16 )
        {//New FM card,Ϊ�»���,δ����˰�س�ʼ��
            ProducedDate();
            return;
        }
        if (temphead.FFlag == FMINITEDFLAG)      // the FM init success
        {
            if (!ecrUsed || //ccr070531
                strcmp(temphead.FFisCode,ApplVar.Fis_Header.FFisCode)==0
#if (DD_FISPRINTER || RIFMUST) // liuj 0806
                &&    strcmp(temphead.FRIFNumber,ApplVar.Fis_Header.FRIFNumber)==0
#endif
               )
            {
                //ccr2014-PANAMA>>>>
                for (sTp=sFlag=0;sTp < sizeof(ApplVar.Fis_Header.FFisCode);sTp++)
                {
                    if (ApplVar.Fis_Header.FFisCode[sTp] == 0xff)
                        sFlag++;
                }

                if (sFlag == sizeof(ApplVar.Fis_Header.FFisCode) )
                {//����δ����˰�س�ʼ��
                    ApplVar.FiscalFlags = FMISNEW;
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI94);
                    return;
                }
                if (sFlag)
                {
                    ApplVar.FiscalFlags = BADFM;//˰�ش洢���쳣
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
                    return;
                }

                //<<<<PANAMA
                sTp = ApplVar.FiscalFlags;//ccr091105
                ApplVar.FiscalFlags = FISCALOK;
                SetApprovCode();//ccr2017-05-04
                if (!ecrUsed || sFiscalFlags==NOFM)
                {//Fiscal initialize finished
                    //Ϊ�ӵ��ʼ��ʱ,�ָ�˰��ϵͳ
                    if (!Fiscal_RecallData())//ccr2018-04-02 || !Fiscal_AddResetData())//ccr070719
                    {//�ָ�ʧ��
#ifdef CASE_FATFS_EJ
                        if (ApplVar.FiscalFlags == FMFULL || ApplVar.FiscalFlags == FMMACFULL)
                        {//ccr091203>>>>>FMFULL��,���Բ�ѯEJ�ϵ�����
                            sFlag = ApplVar.FiscalFlags;
                            sTp = ApplVar.ErrorNumber;
                            ApplVar.ErrorNumber=0;//ccr091105
                            ApplVar.FiscalFlags = FISCALOK;
                            CheckEJ(true); //Ϊ�ӵ��ʼ��ʱ,���EJ
                            ApplVar.FiscalFlags = sFlag;
                            ApplVar.ErrorNumber = sTp;
                        }//<<<<<<<<<<<<<<<<<<<<<
#endif
                        return ;
                    }
										else
											sTp = ApplVar.FiscalFlags;//ccr2018-04-04
											
#ifdef CASE_FATFS_EJ
#if defined(CASE_GREECE)//ccr2018-01-08�����վݼ���SHA1ǩ��
                    RecallLastASED();
#endif
#else
//                    PutsO("Get Size of SD>>");//testonly
                    GetMMCSize(0);//ccr2017-06-19
#endif
                }

                if (ApplVar.FisNumber.TotalResetNum > FRESETMAX)
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI117);//����������������
                    ApplVar.FiscalFlags = FMMACFULL;
                    return ;
                }


                if (ApplVar.FisNumber.TotalXUnit[FISxFMCOUNT]>FxFMMAX)//ccr071212
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI117);//����������������
                    ApplVar.FiscalFlags = FMMACFULL;
                    return;
                }

                if (ApplVar.FMPullOut[NOFM_FLAG]==0x69)
                {
                    ApplVar.FMPullOut[NOFM_FLAG] = 0;
                    Fiscal_AddDisconnect(FISxFMCOUNT);
                }

                if (ApplVar.FiscalFlags == FISCALOK)
                {//ccr2014-08-07>>>>
                    Fiscal_AddTaxRateChg(true);//����ػ�ǰû�б������˰�ʺ���Ʊͷ
                    Fiscal_AddHeaderChg(false);
                }//<<<<<<<<<<<<<<<<<<<<<<

                if (ApplVar.FiscalHead.MaxP >= (FISMEMERYSIZE - FISMEMERYFULLSIZE_LESS))
                {
                    ApplVar.FiscalFlags = FMFULL;
                    return ;
                }
#ifdef CASE_FATFS_EJ
                else if (ApplVar.FisNumber.TotalEJNum >= FEJTBLMAX)
                {
                    ApplVar.FiscalFlags = EJFULL;
                    return ;
                }
                ApplVar.ErrorNumber=0;//ccr091105
//                PutsO("Check EJ>>>>>>>>");//ccr2017-06-14  testonly
                CheckEJ(false);  // Ϊ����ʱ,���EJ
				//ccr20140630!!!!>>>>
                if (ApplVar.FiscalFlags != FISCALOK && ApplVar.FiscalFlags != MUSTINITEJ)    //cc 20071012
                    return ;
                else//<<<<<<<<<<<
                    if (ApplVar.FiscalFlags != MUSTINITEJ && sTp==BADEJ)
                    ApplVar.FiscalFlags = sTp;
#endif
            }
            else        // not the FM for this ECR
            {
                ApplVar.FiscalFlags = FM_X_ECR;
                return ;
            }
        }
        else
        {
            if (temphead.FFlag == 0xff)
            {
                ApplVar.FiscalFlags = FMISNEW;          // the FM have not init
            }
            else
            {
                ApplVar.FiscalFlags = BADFM;
                ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
            }
            return ;
        }

    }
    return ;
}


/****************************************************************
 * ��ӡ��˰����
 *
 * @author EutronSoftware (2017-06-07)
 *
 * @param pSale:���۽��
 * @param pTax :��˰���
 * @param noTax :��Ҫ�ۼӵ���˰���
 ***************************************************************/
void Print_TAX_ALL(BCD pSale[8],BCD pTax[8],BCD* noTax)
{
#define PRNVAT  0   //�Ƿ��ӡ˰��,����ÿ��Z������˰�ʿ��ܲ�ͬ,��ӡ˰��û������

    int i,slen,k;
    BCD sVal;
    BCD sTotalSale, sTotalTax,sTotalxTax;//ccr070424
    char strNetValue[PRTLEN+1];

    sTotalTax = sTotalSale = ZERO;
    if (noTax)
        sTotalxTax = *noTax;
    else
        sTotalxTax = ZERO;

    strcpy(strNetValue,Msg[XIAOSHOUA].str);
    k=strlen(strNetValue);
    strNetValue[k++]=' ';

    for (i=0;i<ApplVar.AP.Tax.Number;i++)
    {
/*ccr20140725 һ����Ʒ�ж��ּ�˰ʱ����������>>>>>>>>>>>>>
        if (CheckNotZero(&ApplVar.FiscalTotal.FTaxSale[i]))
        {//TAX SALE
            Add(&sTotalSale, &ApplVar.FiscalTotal.FTaxSale[i]);//ccr070424
        }
<<<<<<<<<<<<<<<<<<<*/

        //�ȴ�ӡ�۳�˰���ľ����۶�
        memset(ProgLineMes,' ',PRTLEN);
        slen = strlen(Msg[XIAOSHOUA].str);
        memcpy(ProgLineMes,Msg[XIAOSHOUA].str,slen);
        ProgLineMes[slen+1] = 'A' + i;  //ProgLineMes[6] = 'A' + i;	//20070313
#if PRNVAT
        // ccr2017-06-07 ����ÿ��Z������˰�ʿ��ܲ�ͬ,�˴���ӡ˰��û������
        sVal=ZERO;
        CWORD(sVal.Value[0]) = CWORD(ApplVar.CurrentTaxRate[i][0]);
        sVal.Sign = 2;
        FormatQty(ProgLineMes+15,&sVal);//cr070424
        ProgLineMes[16] = '%';
#endif
        ProgLineMes[17] = 0;
        PrintAmt(ProgLineMes,&pSale[i]);//TAXABLE A  7.00%

//        if (CWORD(ApplVar.CurrentTaxRate[i][0]))//ccr2017-06-07 CheckNotZero(&ApplVar.FiscalTotal.FTaxAmt[i]))
        if (CheckNotZero(&pTax[i]))
        {//TAX AMT(Ӧ��˰���)

            strNetValue[k++]='A' + i;
            Add(&sTotalSale, &pSale[i]);//ccr070424

            Add(&sTotalTax, &pTax[i]);//ccr070424
            FormatAmtStr(Msg[ITEMTAXA].str,&pTax[i],PRTLEN); SysBuf[VAT_A_P]+=i;
#if PRNVAT
            // ccr2017-06-07 ����ÿ��Z������˰�ʿ��ܲ�ͬ,�˴���ӡ˰��û������
            sVal=ZERO;
            CWORD(sVal.Value[0]) = CWORD(ApplVar.CurrentTaxRate[i][0]);
            sVal.Sign = 2;
            FormatQty(SysBuf+15,&sVal);//cr070424
            SysBuf[16] = '%';

#endif
            RJPrint(0,SysBuf);//ccr070424
        }
        else //ccr2017-06-07>>>>>>>>>>
        {//ͳ����˰���۽��TAX-EXEMPT:���������˰���Ϊ0,�����������۽��,����Ϊ����˰���� ????
            Add(&sTotalxTax,&pSale[i]);
        }//ccr2017-06-07<<<<<<<<<<<<<<
    }

    PrintLine('.');
    //TOTAL NET SALE >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    if (CheckNotZero(&sTotalSale))
    {
        strNetValue[k]=0;
        PrintAmt(strNetValue,&sTotalSale);//SUM of NET Value for VAT
    }

    //TAX AMT TOTAL(Ӧ��˰�ܶ�)
    RJPrint(0,FormatAmtStr(Msg[TAXTOTAL].str,&sTotalTax,PRTLEN));

    //TAX-EXEMPT��˰���۽��
    if (CheckNotZero(&sTotalxTax))
        PrintAmt(Msg[MIANSHUI].str,&sTotalxTax); //ccr070424

}
/***********************************************************
 * ��ӡ��ѯ��Z������������
 * @author EutronSoftware (2014-07-25)
 ***********************************************************/
void Print_FiscalTotal()
{
    PrintStr_Center((char*)Msg[PRNTOTAL].str,true);
    //print Z counter
    memset(SysBuf, ' ', sizeof(SysBuf));
    CopyFrStr(SysBuf, Msg[CLEARTOTAL].str);
    ULongtoASCZER0(SysBuf+PRTLEN-1, ApplVar.FiscalTotal.FClearCount,6);
    SysBuf[PRTLEN] = 0;
    RJPrint(0, SysBuf);

    //TAX SALE
    Print_TAX_ALL(ApplVar.FiscalTotal.FTaxSale,ApplVar.FiscalTotal.FTaxAmt,&ApplVar.FiscalTotal.NoTaxSale);

    //Grand Total
    PrintLine('-');
    PrintStr_Center((char*)Msg[GRANDTOTAL].str,true);

    Print_TAX_ALL(ApplVar.FNetSum,ApplVar.FTaxSum,0);

    PrintLine('.');
    //��ӡ��˰�������ܼ�(�������ܼ�+Ӧ��˰�ܼ�)
#if (!defined(CASE_EURO))
    PrintAmt(Msg[GRANDTOTAL].str, &ApplVar.FTotal);  //liuj 0606
#endif

//��ӡƱ��ͳ������
    memset(SysBuf,' ',PRTLEN);
    CopyFrStr(SysBuf,Msg[FAPIAOHAO].str);
    ULongtoASCZER0(SysBuf+PRTLEN-1,ApplVar.FiscalTotal.FInvSum[FRECEIPTS],6);
    SysBuf[PRTLEN]=0;
    RJPrint(0, SysBuf);

#if 0
    //REFUND SALE	//20070118
    sLong = labs(ApplVar.FiscalTotal.ReturnAmt);
    ULongToBCDValue(sVal.Value,sLong);
    if (ApplVar.FiscalTotal.ReturnAmt < 0)
        SETBIT(sVal.Sign, BIT7);
    else
        RESETBIT(sVal.Sign, BIT7);
    PrintAmt(Msg[THUOZHJI].str,&sVal);

    //REFUND TAX	//20070118
    sLong = labs(ApplVar.FiscalTotal.ReturnTax);
    ULongToBCDValue(sVal.Value,sLong);
    if (ApplVar.FiscalTotal.ReturnTax < 0)
        SETBIT(sVal.Sign, BIT7);
    else
        RESETBIT(sVal.Sign, BIT7);
    PrintAmt(Msg[THZJSHUI].str,&sVal);

    RFeed(1);

//hf end <<<<<<<<<<<<<<<<<<<<<<<
#endif
    //20070313
    //memset(&sVal,0,sizeof(BCD));
    //WORDtoBCD(sVal.Value,ApplVar.FiscalTotal.FInvSum);
    //RJPrint(0,FormatQtyStr(Msg[RECNUMBER].str,&sVal,PRTLEN));
    //total invoice, refund, No Fiscal number
    PrintLine('.');
    PrintFiscalAttribute();//ccr071212

}
//�ӵ縴λʱ,��˰�ش洢���и�ԭ˰������
short Fiscal_RecallData()
{
    BYTE i,j,k;
    WORD sBegin;
    ULONG sMid,sAddr;

    memset(&ApplVar.FiscalHead,0,sizeof(ApplVar.FiscalHead));
    memset(&ApplVar.FisNumber,0,sizeof(ApplVar.FisNumber));
    ApplVar.FiscalHead.ReadP = FISDATAADDR;

//ccr070531>>>>>>>>>>>>>>>>>>>>>>
//	Bios_FM_Read(&ApplVar.Fis_Header, FISECRIDADDR, sizeof(ApplVar.Fis_Header)) ; // liuj modify for new FM but init

#ifdef CASE_FATFS_EJ
    for (sBegin=0;sBegin<FEJTBLMAX;sBegin++)
    {

        if (!Bios_FM_Read(SysBuf,FISEJADDR+sBegin*sizeof(ApplVar.Fis_EJTbl),sizeof(ApplVar.Fis_EJTbl)))
        {//ccr070719>>>>>>
            ApplVar.FiscalFlags = FMERROR;
            ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
            return 0;
        }//<<<<<<<<<<<<<<
        if (CWORD(SysBuf)==0xffff)
            break;
        memcpy(&ApplVar.Fis_EJTbl,SysBuf,sizeof(ApplVar.Fis_EJTbl));
    }

    ApplVar.FisNumber.TotalEJNum = sBegin;
    ApplVar.FiscalHead.EJTblP =  FISEJADDR + sBegin*sizeof(ApplVar.Fis_EJTbl);
#endif
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    if (!Bios_FM_Read(&ApplVar.FiscalBuff,FISDATAADDR,FISRECORDLEN))
    {//ccr070719>>>>>>>>>
        ApplVar.FiscalFlags = FMERROR;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
        return 0;
    }//<<<<<<<<<<<<<<<<<<<<<<<<
    if (CWORD(ApplVar.FiscalBuff)==0xffff)// û���κμ�¼//
    {
        ApplVar.FiscalHead.MaxP = FISDATAADDR;
        ApplVar.ZCount[FISCALZNUM]= ApplVar.ZCount[TRAINZNUM]=1;//ccr091027
        ApplVar.FisNumber.TotalClearNum = 1; // liuj 0526
        if (ApplVar.Fis_Header.FFlag == FMINITEDFLAG)
        {
            ApplVar.FisNumber.FiscalDate = EncordBCDDate(ApplVar.Fis_Header.FInitDate[0], ApplVar.Fis_Header.FInitDate[1], ApplVar.Fis_Header.FInitDate[2]);
            if (!ApplVar.FisNumber.LastZDate)    //have not print Z report, set fiscal date as LastZDate
                ApplVar.FisNumber.LastZDate =   ApplVar.FisNumber.FiscalDate;
        }
        return 0;
    }

    ApplVar.FTotal = ZERO;
    memset(&ApplVar.FTaxSum,0,sizeof(ApplVar.FTaxSum));//cr070615
    memset(&ApplVar.FNetSum,0,sizeof(ApplVar.FNetSum));//ccr2017-05-18


    memset(ApplVar.FisNumber.TotalReceiptNum,0, sizeof(ApplVar.FisNumber.TotalReceiptNum));//ccr091027
    ApplVar.SaleReceipts = 0; // liuj 0829
    sBegin = 0;

#if (DD_FISPRINTER)//ccr091104>>>>>>>
    SwitchLedON(100);
#else
    PutsO(Msg[WAITING].str);
#endif
    for (sMid=FISDATAADDR;sMid<FISMEMERYSIZE;sMid += FISRECORDLEN)
    {
        if (sMid+FISRECORDLEN>FISMEMERYSIZE)
        {//ccr20130314
            ApplVar.FiscalFlags = FMFULL;ApplVar.ErrorNumber=ERROR_ID(CWXXI86);
            return 0;
        }
        else if (!Bios_FM_Read(&ApplVar.FiscalBuff,sMid,FISRECORDLEN))
        {//ccr070719>>>>>>>>>
            ApplVar.FiscalFlags = FMERROR;ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
            return 0;
        }//<<<<<<<<<<<<<<<<<<<<<<<<

        ApplVar.FiscalHead.MaxP =sMid;
        if (CWORD(ApplVar.FiscalBuff)==0xffff)// û�м�¼//
            break;


        switch (ApplVar.FiscalBuff.Fis_ClearRecord.FunN)
        {
        case  FISCLEARLOG:
            ApplVar.FisNumber.TotalClearNum = ApplVar.FiscalBuff.Fis_ClearRecord.FCount;

            memcpy(ApplVar.FisNumber.TotalReceiptNum, ApplVar.FiscalBuff.Fis_ClearRecord.FInvSum, sizeof(ApplVar.FiscalBuff.Fis_ClearRecord.FInvSum));
            ApplVar.FisNumber.LastZDate = ApplVar.FiscalBuff.Fis_ClearRecord.FDate;
            memcpy(ApplVar.FisNumber.LastZTime, ApplVar.FiscalBuff.Fis_ClearRecord.FTime, sizeof(ApplVar.FisNumber.LastZTime));

            ApplVar.FiscalHead.ClearP = sMid;

            for (i=0;i<ApplVar.AP.Tax.Number;i++)//ccr070615
            {
                AddBcdWithLong(&ApplVar.FTaxSum[i], ApplVar.FiscalBuff.Fis_ClearRecord.FTaxAmt[i]);
                AddBcdWithLong(&ApplVar.FNetSum[i],ApplVar.FiscalBuff.Fis_ClearRecord.FTaxSale[i]);//ccr2017-05-18
            }

            break;
        case  FISRESETLOG:
            ApplVar.FisNumber.TotalResetNum = ApplVar.FiscalBuff.Fis_ReSet.FCount;
            ApplVar.FiscalHead.ReSetP= sMid;
            break;
        case  FISHEADCHGLOG:
            ApplVar.FisNumber.TotalHeadChangeNum = ApplVar.FiscalBuff.Fis_HeadPointer.FChgCount;
            ApplVar.FiscalHead.FisHeadChgP = sMid;
            break;
        case  FISTAXLOG:
            memcpy(ApplVar.CurrentTaxRate,ApplVar.FiscalBuff.Fis_TaxRate.FNTaxRate,sizeof(ApplVar.CurrentTaxRate));//ccr070615
            ApplVar.FisNumber.TotalTaxChangeNum = ApplVar.FiscalBuff.Fis_TaxRate.FChgCount;
            ApplVar.FiscalHead.TaxRateP = sMid;
            break;
        case FISDISCONNECTLOG://ccr071212
            ApplVar.FisNumber.TotalXUnit[ApplVar.FiscalBuff.Fis_UnitDisconnect.FXType] = ApplVar.FiscalBuff.Fis_UnitDisconnect.FXUnitCount[ApplVar.FiscalBuff.Fis_UnitDisconnect.FXType];
            ApplVar.FiscalHead.ECRxUnitP = sMid;
            break;
        case  FISDATECHGLOG://ccr2017-08-08
            ApplVar.FisNumber.TotalDateChangeNum = ApplVar.FiscalBuff.Fis_DateTime.FChgCount;
            ApplVar.FiscalHead.DateTimeP = sMid;
            break;
        }
    }

    for (i=0;i<ApplVar.AP.Tax.Number;i++)//ccr070615
    {
        Add(&ApplVar.FTotal,&ApplVar.FNetSum[i]);
        Add(&ApplVar.FTotal,&ApplVar.FTaxSum[i]);
    }

#if (DD_FISPRINTER)//ccr091104
    SwitchLedOFF();
#else
    PutsO(ModeHead);
#endif
    //�ظ�Ʊͷ����
    if (ApplVar.FiscalHead.FisHeadChgP)
    {
        //��ȡ����Ʊͷ���λ��
        if (!Bios_FM_Read(&ApplVar.FiscalBuff,ApplVar.FiscalHead.FisHeadChgP,FISRECORDLEN))
        {
            ApplVar.FiscalFlags = FMERROR;
            ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
            return 0;
        }
        //��ȡ����Ʊͷ����
        if (!Bios_FM_Read((BYTE *)&ApplVar.Fis_HeadChg,ApplVar.FiscalBuff.Fis_HeadPointer.FNewPointer,FHEADCHGLEN))
        {//ccr070719>>>>>>>>>
            ApplVar.FiscalFlags = FMERROR;
            ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
            return 0;
        }//<<<<<<<<<<<<<<<<<<<<<<<<
        if (VerifyCRC((BYTE *)&ApplVar.Fis_HeadChg,FHEADCHGLEN,0))
        {//������Ʊͷ���ݴ���ApplVar.TXT.Header
            memcpy(ApplVar.TXT.Header,ApplVar.Fis_HeadChg.FNewHead,sizeof(ApplVar.TXT.Header));
        }
    }

    //�������һ�����õ�˰��
    if (ApplVar.FiscalHead.TaxRateP)
    {
        for (ApplVar.TaxNumber=0;ApplVar.TaxNumber<ApplVar.AP.Tax.Number;ApplVar.TaxNumber++)
        {
            ReadTax();
            CWORD(ApplVar.Tax.Rate[0]) = CWORD(ApplVar.CurrentTaxRate[ApplVar.TaxNumber][0]);
            WriteTax();
        }
    }

    if (Bios_FM_Read(&ApplVar.Fis_Header, FISECRIDADDR, sizeof(ApplVar.Fis_Header)) && ApplVar.Fis_Header.FFlag == FMINITEDFLAG)
    {
        ApplVar.FisNumber.FiscalDate = EncordBCDDate(ApplVar.Fis_Header.FInitDate[0], ApplVar.Fis_Header.FInitDate[1], ApplVar.Fis_Header.FInitDate[2]);
        if (!ApplVar.FisNumber.LastZDate)    //have not print Z report, set fiscal date as LastZDate
            ApplVar.FisNumber.LastZDate =   ApplVar.FisNumber.FiscalDate;
        GetTimeDate(&Now);
        if (CompDateTime(&Now, ApplVar.FisNumber.LastZDate,ApplVar.FisNumber.LastZTime)<0)   //Now < LastZDate
        {
            Now.year = 0x2000 + ApplVar.Fis_Header.FInitDate[0];
            Now.month= ApplVar.Fis_Header.FInitDate[1];
            Now.day= ApplVar.Fis_Header.FInitDate[2];
            Now.dow = 8;
            Now.hour=ApplVar.FisNumber.LastZTime[0];
            Now.min=ApplVar.FisNumber.LastZTime[1];
            Now.sec=ApplVar.FisNumber.LastZTime[2];
            SetTimeDate(&Now);
            SetDateFlg = 0;
        }
    }

    if (ApplVar.FisNumber.TotalEJNum >= FEJTBLMAX)
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI117);//����������������
        ApplVar.FiscalFlags = EJFULL;
#if DD_FISPRINTER
        SETBIT(ApplVar.Fiscal_Status, EJ_100);
#endif

    }
    else if (ApplVar.FisNumber.TotalResetNum > FRESETMAX)
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI117);//����������������
        ApplVar.FiscalFlags = FMMACFULL;
    }
    else if (ApplVar.FiscalHead.MaxP >= (FISMEMERYSIZE - FISMEMERYFULLSIZE_LESS))
    {
        ApplVar.FiscalFlags = FMFULL;
#if DD_FISPRINTER
        SETBIT(ApplVar.Fiscal_Status, FM_100);
#endif
        return 0;//ccr091104
    }

    ApplVar.FisNumber.TotalClearNum ++;     // liuj 0526

    ApplVar.ZCount[FISCALZNUM] = ApplVar.FisNumber.TotalClearNum;
    return 1;
}

//-------------------------------------
//   13-12-2012 09:34:13        00001
//    TAX-EXEMPT                 0.00
//    TAXABLE A  7.00%          11.72
//    TAXABLE B 10.00%          21.42
//    TAXABLE C 15.00%          22.10
//    TAX SUM                    0.00
//    TAXABLE SUM               55.24
// # RECEIPTS                    1
//   --------------------------------
/***************************************************************************
 * ��ӡFM�е�˰������FiscalBuff:FISCLEARLOG/FISRESETLOG...
 *
 * @author EutronSoftware (2017-05-18)
 *
 * @param sType :FISCLEARLOG/FISRESETLOG...
 * @param pDate :=true,��ӡFISCLEARLOG������;
 *               =false,����ӡ����(Ϊ��ӡZ����ʱ����)
 ************************************************************************/
void Print_FiscalData(short sType,BYTE prnZDate)
{
    BCD sVal,sVal1;
    int i,j,k;
    BYTE saveTaxNumber;
    long  sLong;
    BYTE slen;  //20070313
    long sTotalSale, sTotalTax,sNoTaxSale;
    char strNetValue[PRTLEN+1];

#if (defined(CASE_GREECE))//ϣ���ڽ��ǰ����ӡŷԪ����
    Prefix1 = Prefix2 = 0;
#endif

    switch (sType)
    {
    case FISCLEARLOG:
        //Date & Time>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        if (prnZDate)
        {
            memset(ProgLineMes,' ',PRTLEN);
            DecordDateFiscal(ApplVar.FiscalBuff.Fis_ClearRecord.FDate,ProgLineMes);
            ProgLineMes[10] = ' ';

            //20070313
            EncodeTimeFiscal(ApplVar.FiscalBuff.Fis_ClearRecord.FTime, ProgLineMes+11);
            ProgLineMes[19] = ' ';

            ProgLineMes[PRTLEN-ULongtoASCZER0(ProgLineMes+PRTLEN-1, ApplVar.FiscalBuff.Fis_ClearRecord.FCount,4)-1]='#';
            ProgLineMes[PRTLEN] = 0;
            RJPrint(0, ProgLineMes);//13-12-2012 09:34:13        00001
        }


        //ITEMTAXA to ITEMTAXH>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        saveTaxNumber = ApplVar.TaxNumber;
        //"TAX SALE  "
        sTotalSale = sNoTaxSale = sTotalTax = 0;
        strcpy(strNetValue,Msg[XIAOSHOUA].str);
        k=strlen(strNetValue);
        strNetValue[k++]=' ';
        for (i=0;i<ApplVar.AP.Tax.Number;i++)
        {
            sVal1 = ZERO;
            sLong = (ApplVar.FiscalBuff.Fis_ClearRecord.FTaxSale[i]);

            //�ȴ�ӡ�۳�˰���ľ����۶�
#if !defined(CASE_EURO)
            if (sLong!=0)//ccr070424
#endif
            {
                LongToBCD(&sVal, sLong);

                CWORD(sVal1.Value[0]) = CWORD(ApplVar.CurrentTaxRate[i][0]);
                sVal1.Sign = 2;

                if (CWORD(sVal1.Value[0]))
                {
                    strNetValue[k++]='A' + i;
                    sTotalSale += sLong;
                }
                else
                    sNoTaxSale+=sLong;

#if defined(CASE_EURO)
                if (prnZDate)
#endif
                {
                    memset(ProgLineMes,' ',PRTLEN);
                    slen = strlen(Msg[XIAOSHOUA].str);
                    memcpy(ProgLineMes,Msg[XIAOSHOUA].str,slen);
                    ProgLineMes[++slen] = 'A' + i;  //ProgLineMes[6] = 'A' + i;	//20070313
#if (0)
                    ProgLineMes[++slen] = '(';                  slen+=5;
                    FormatQty(ProgLineMes+slen,&sVal1);//cr070424
                    ProgLineMes[++slen] = '%';
                    ProgLineMes[++slen] = ')';
#endif
                    ProgLineMes[++slen] = 0;

                    PrintAmt(ProgLineMes,&sVal);//TAXABLE A  7.00%
                }
            }

            //�ٴ�ӡӦ��˰���
            sVal1 =ZERO;
            sLong = (ApplVar.FiscalBuff.Fis_ClearRecord.FTaxAmt[i]);
            sTotalTax += sLong;
#if defined(CASE_EURO)
            if (prnZDate)
#else
            if (sLong!=0)//ccr070424
#endif
            {
                LongToBCD(&sVal,sLong);
                CWORD(sVal1.Value[0]) = CWORD(ApplVar.CurrentTaxRate[i][0]);
                sVal1.Sign = 2;

                memset(ProgLineMes,' ',PRTLEN);
                slen = strlen(Msg[ITEMTAXA].str);
                memcpy(ProgLineMes,Msg[ITEMTAXA].str,slen);ProgLineMes[VAT_A_P]+=i;
                ProgLineMes[++slen] = '(';                  slen+=5;
                FormatQty(ProgLineMes+slen,&sVal1);//cr070424
                ProgLineMes[++slen] = '%';
                ProgLineMes[++slen] = ')';
                ProgLineMes[++slen] = 0;
                PrintAmt(ProgLineMes,&sVal);
            }
        }
//ccr2017-08-02        PrintLine('.');
        //TOTAL NET SALE (�۳�˰������۶�ϼ�)
//ccr2017-08-02        if (sTotalSale)
        {
            strNetValue[k]=0;
            LongToBCD(&sVal,sTotalSale);
            PrintAmt(strNetValue,&sVal);//SUM of NET Value for VAT
        }

        //TAX TOTAL(Ӧ��˰���ϼ�)
        LongToBCD(&sVal,sTotalTax);
        PrintAmt(Msg[TAXTOTAL].str,&sVal);  //TAX SUM

        //TAX-EXEMPT(��˰���۽��)
        sNoTaxSale+=ApplVar.FiscalBuff.Fis_ClearRecord.NoTaxSale;
//ccr2017-08-02        if (sNoTaxSale)
        {
            LongToBCD(&sVal,sNoTaxSale);
            PrintAmt(Msg[MIANSHUI].str,&sVal);//TAX-EXEMPT
        }

        ApplVar.TaxNumber = saveTaxNumber;


//ccr091027>>>>
        sVal = ZERO;
        ULongToBCDValue(sVal.Value, ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice[FRECEIPTS]) ;
        RJPrint(0, FormatQtyStr(Msg[DAILYRECEIPTS].str, &sVal, PRTLEN)); // # RECEIPTS
//<<<<<<<<<<<<
#if 0
        //DISCOUNT SALE					//20070313
        sLong = (ApplVar.FiscalBuff.Fis_ClearRecord.DiscAmt);
        LongToBCD(&sVal,sLong);
        PrintAmt(Msg[ZHKOUZHJI].str,&sVal);

        //DISCOUNT TAX					//20070313
        sLong = (ApplVar.FiscalBuff.Fis_ClearRecord.DiscTax);
        LongToBCD(&sVal,sLong);
        PrintAmt(Msg[ZHKZJSHUI].str,&sVal);

        //REFUND SALE	//20070118
        LongToBCD(&sVal,ApplVar.FiscalBuff.Fis_ClearRecord.ReturnAmt);
        PrintAmt(Msg[THUOZHJI].str,&sVal);

        //REFUND TAX	//20070118
        LongToBCD(&sVal,ApplVar.FiscalBuff.Fis_ClearRecord.ReturnTax);
        PrintAmt(Msg[THZJSHUI].str,&sVal);
#endif
        //20070313	REC.NUMBER>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        //memset(&sVal,0,sizeof(BCD));
        //WORDtoBCD(sVal.Value,ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice);
        //PrintQty(Msg[RECNUMBER].str, &sVal);

        //invoice, refund, no fiscal number of the date
#if 0
        j = FAPIAOHAO;
        for (i = 0; i < 1;i++)
        {
            memset(SysBuf, ' ', sizeof(SysBuf));
            CopyFrStr(SysBuf, Msg[FAPIAOHAO].str);
            WORDtoASCZero(SysBuf+PRTLEN-1, ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice[i]);
            SysBuf[PRTLEN] = 0;
            RJPrint(0, SysBuf);
            j++;
        }

//liuj 0613
        for (i=0;i<ApplVar.AP.Tax.Number;i++)
        {
            if (CheckNotZero(&ApplVar.FTaxSum[i]))
            {
                FormatAmtStr(Msg[ITEMTAXA].str,&ApplVar.FTaxSum[i],PRTLEN);SysBuf[VAT_A_P]+=i;
                RJPrint(0,SysBuf);
            }
        }

        PrintAmt(Msg[GRANDTOTAL].str, &ApplVar.FTotal);  //liuj 0606
//liuj 0613
#endif
        break;
    case FISRESETLOG:
        memset(ProgLineMes,' ',PRTLEN);
        DecordDateFiscal(ApplVar.FiscalBuff.Fis_ReSet.FDate,ProgLineMes);
        ProgLineMes[10]=' ';//ccr071212
        strcpy(ProgLineMes+11,Msg[MACRESET].str);//ccr071212
        sVal = ZERO;
        WORDtoBCD(sVal.Value,ApplVar.FiscalBuff.Fis_ReSet.FCount);
        RJPrint(0,FormatQtyStr(ProgLineMes,&sVal,PRTLEN));
        break;

    case FISDISCONNECTLOG://ccr071212
        memset(ProgLineMes,' ',PRTLEN);
        DecordDateFiscal(ApplVar.FiscalBuff.Fis_UnitDisconnect.FDate,ProgLineMes);
        ProgLineMes[10]=' ';
        strcpy(ProgLineMes+11,Msg[MSGECRxFM+ApplVar.FiscalBuff.Fis_UnitDisconnect.FXType].str);
        sVal = ZERO;
        WORDtoBCD(sVal.Value,ApplVar.FiscalBuff.Fis_UnitDisconnect.FXUnitCount[ApplVar.FiscalBuff.Fis_UnitDisconnect.FXType]);
        RJPrint(0,FormatQtyStr(ProgLineMes,&sVal,PRTLEN));
        break;

    case FISHEADCHGLOG:
        memset(SysBuf,' ',PRTLEN);
        DecordDateFiscal(ApplVar.FiscalBuff.Fis_HeadPointer.FDate,SysBuf);
        SysBuf[10] = ' ';
        strcpy(SysBuf+12,Msg[CHANGEHEAD].str);

        RJPrint(0,SysBuf);
        for (i=0;i<HEADLINES;i++)
        {
            memcpy(SysBuf,ApplVar.Fis_HeadChg.FNewHead+i*(PRTLEN+1),PRTLEN);
            SysBuf[PRTLEN] = 0;
            RJPrint(0, SysBuf);
        }
        break;
    case FISTAXLOG:
        //Date & Time>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        memset(SysBuf,' ',PRTLEN);
        DecordDateFiscal(ApplVar.FiscalBuff.Fis_TaxRate.FDate,SysBuf);
        SysBuf[10] = ' ';
        strcpy(SysBuf+12,Msg[CHANGETAX].str);
        RJPrint(0,SysBuf);
        //TAX CHANGE>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        for (i=0;i<ApplVar.AP.Tax.Number;i++)
        {//ֻ��ӡ�б仯��˰��
            sVal=sVal1=ZERO;
            memset(SysBuf,' ',PRTLEN);

            CWORD(sVal.Value[0]) = CWORD(ApplVar.FiscalBuff.Fis_TaxRate.FNTaxRate[i][0]);

            CWORD(sVal1.Value[0]) = CWORD(ApplVar.FiscalBuff.Fis_TaxRate.FOTaxRate[i][0]);

            if (CompareBCD(&sVal,&sVal1) != 0)
            {//ֻ��ӡ�б仯��˰��
                strcpy(SysBuf,Msg[TAXACHG].str); SysBuf[VAT_A_P]+=i;
                RJPrint(1,SysBuf);
                memset(SysBuf,' ',PRTLEN);
#if PRTLEN<25 //liuj 0716
                sVal1.Sign = 2;
                FormatQty(SysBuf+6,&sVal1);//ccr070424
                SysBuf[7] = '%';
                CopyFrStr(SysBuf+8,Msg[TAXTO].str);
                sVal.Sign = 2;
                FormatQty(SysBuf+17,&sVal);;//ccr070424
                SysBuf[18] = '%';       SysBuf[PRTLEN] = 0;
                RJPrint(0,SysBuf);
#else
                CopyFrStr(SysBuf+2,Msg[TAXFROM].str);
                sVal1.Sign = 2;
                FormatQty(SysBuf+14,&sVal1);//ccr070424
                SysBuf[15] = '%';
                CopyFrStr(SysBuf+18,Msg[TAXTO].str);
                sVal.Sign = 2;
                FormatQty(SysBuf+27,&sVal);;//ccr070424
                SysBuf[28] = '%';       SysBuf[PRTLEN] = 0;
                RJPrint(0,SysBuf);
#endif
            }
            else//ccr2017-12-21>>>>>>
            {//δ���˰��
                CopyFrStr(SysBuf,Msg[ITEMTAXA].str);SysBuf[VAT_A_P]+=i;
                sVal1.Sign = 2;
                FormatQty(SysBuf+14,&sVal1);//ccr070424
                SysBuf[15] = '%';
                RJPrint(0,SysBuf);
            }//ccr2017-12-21<<<<<<<<
        }
        break;
    case FISDATECHGLOG://ccr2017-08-08
        memset(ProgLineMes,' ',PRTLEN);
        DecordDateFiscal(ApplVar.FiscalBuff.Fis_DateTime.FDate,ProgLineMes);
        ProgLineMes[10]=' ';
        strcpy(ProgLineMes+11,Msg[CHANGEDATETIME].str);
        sVal = ZERO;
        WORDtoBCD(sVal.Value,ApplVar.FiscalBuff.Fis_DateTime.FChgCount);
        RJPrint(0,FormatQtyStr(ProgLineMes,&sVal,PRTLEN));
        memset(ProgLineMes,' ',PRTLEN);
        CopyFrStr(ProgLineMes,Msg[TAXFROM].str);
        memcpy(ProgLineMes+PRTLEN-20,ApplVar.FiscalBuff.Fis_DateTime.FDateTimeOld,20);
        ProgLineMes[PRTLEN]=0;

        RJPrint(0,ProgLineMes);
        memset(ProgLineMes,' ',PRTLEN);
        CopyFrStr(ProgLineMes,Msg[TAXTO].str);
        memcpy(ProgLineMes+PRTLEN-20,ApplVar.FiscalBuff.Fis_DateTime.FDateTimeNew,20);
        ProgLineMes[PRTLEN]=0;
        RJPrint(0,ProgLineMes);

        break;
    }
    PrintLine('-');
}


//ccr20121212>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
// �������ڲ���z�������ݵĴ�ŵ�ַ //
// ZOnly:=true,ֻ��ѯZ���� //
// pDate:ѹ����ʽ������
// return -1:�޴����ڵ����ݣ������ҵ�һ����ӽ������ڵ�ַ //
//     0: �ҵ������ڵĵ�ַ //
//     1: ����������δ����ָ������ //
// RamOffset �ͳ���Ч��ַ //
short GetZAddrByDate(WORD pDate,bool ZOnly)
{
    ULONG sRamOffsetFr,sRamOffsetTo,sMid;

    struct 	FIS_CLEARRECORD sClearRecord;

    if (ApplVar.FiscalHead.ClearP<FISDATAADDR)
        return 1;

    RamOffSet =  FISDATAADDR;
    sRamOffsetFr = 1;
    sRamOffsetTo = (ApplVar.FiscalHead.ClearP-FISDATAADDR)/FISRECORDLEN+1;
    /*���ȼ���ṩ�����ڲ����Ƿ���˰�����ݼ�¼��Χ��*/
    if (!Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,FISDATAADDR,FISRECORDLEN))
    {
        ApplVar.FiscalFlags = FMERROR;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
        return 1;
    }

    if (pDate < ApplVar.FiscalBuff.Fis_ClearRecord.FDate)
        return -1;

    if (pDate == ApplVar.FiscalBuff.Fis_ClearRecord.FDate && !ZOnly)
        return 0;

    if (!Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,ApplVar.FiscalHead.ClearP,FISRECORDLEN))
    {
        ApplVar.FiscalFlags = FMERROR;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
        return 1;
    }

    if (pDate > ApplVar.FiscalBuff.Fis_ClearRecord.FDate)
        return 1;

    while (sRamOffsetFr <= sRamOffsetTo)
    {
        sMid = (sRamOffsetTo + sRamOffsetFr) / 2;
        RamOffSet = (sMid-1)*FISRECORDLEN+FISDATAADDR;

        if (!Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,RamOffSet,FISRECORDLEN))
            ApplVar.FiscalFlags = BADFM;

        if (ApplVar.FiscalBuff.Fis_ClearRecord.FDate == pDate)
        {//�ҵ�ƥ��ļ�¼
            sRamOffsetFr = RamOffSet;
            sRamOffsetTo = 0;// �ȼ�����Z�������� //
            while (RamOffSet>FISDATAADDR)
            {// ������ǰ�ҵ�һ��ƥ�����ڵ�����  //
                if (ApplVar.FiscalBuff.Fis_ClearRecord.FunN==FISCLEARLOG)
                    sRamOffsetTo = RamOffSet;// ��¼Z��������λ�� //
                RamOffSet-=FISRECORDLEN;//
                Bios_FM_Read(&sClearRecord,RamOffSet,FISRECORDLEN);
                if (sClearRecord.FDate != pDate)
                {
                    RamOffSet=sRamOffsetTo;//�ָ�Z����λ��
                    break;
                }
                memcpy(&ApplVar.FiscalBuff.Fis_ClearRecord,&sClearRecord,FISRECORDLEN);
            }
            if (ZOnly && (sRamOffsetTo==0))// û��Z����,���������� //
            {
                RamOffSet = sRamOffsetFr;
                while (RamOffSet<ApplVar.FiscalHead.ClearP)
                {// �ҵ�һ��ƥ�����ڵ�����  //
                    RamOffSet+=FISRECORDLEN;
                    Bios_FM_Read(&sClearRecord,RamOffSet,FISRECORDLEN);
                    if (sClearRecord.FDate != pDate)
                        break;

                    if (sClearRecord.FunN==FISCLEARLOG)
                    {
                        memcpy(&ApplVar.FiscalBuff.Fis_ClearRecord,&sClearRecord,FISRECORDLEN);
                        sRamOffsetTo = RamOffSet;// ��¼Z��������λ�� //
                        break;
                    }
                }
            }
            if (ZOnly)
                RamOffSet=sRamOffsetTo;
            if (RamOffSet)
                return 0;
            else
                return -1;// �޶�Ӧ���ڵ�Z��������  //
        }
        else if (pDate < ApplVar.FiscalBuff.Fis_ClearRecord.FDate)
        {
            sRamOffsetTo = sMid - 1;
        }
        else
            sRamOffsetFr = sMid + 1;
    }
//	RamOffSet = sRamOffsetFr*FISRECORDLEN+FISDATAADDR;
    return -1;
}
// ����Z��������z�������ݵĴ�ŵ�ַ(���������������˼������ݣ��˺���������) //
// return -1:�޴�Z#�����ݣ������ҵ�һ����ӽ������ڵ�ַ //
//     0: �ҵ���Z#�ĵ�ַ //
//     1: ����Z#��δ����ָ������ //
// RamOffset �ͳ���Ч��ַ //
    #if 0
short GetZAddrByNum(WORD pNum)
{
    WORD sRamOffsetFr,sRamOffsetTo,sMid;

    RamOffSet = FISDATAADDR;

    if (ApplVar.FiscalHead.ClearP<FISDATAADDR)
        return 1;

    sRamOffsetFr = 1;
    sRamOffsetTo = (ApplVar.FiscalHead.ClearP-FISDATAADDR)/FISRECORDLEN+1;

    if (!Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,FISDATAADDR,FISRECORDLEN))
    {
        ApplVar.FiscalFlags = FMERROR;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
        return 1;
    }

    if (pNum < ApplVar.FiscalBuff.Fis_ClearRecord.FCount)
        return -1;

    if (pNum == ApplVar.FiscalBuff.Fis_ClearRecord.FCount)
        return 0;

    if (!Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,ApplVar.FiscalHead.ClearP,FISRECORDLEN))
    {
        ApplVar.FiscalFlags = FMERROR;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
        return 1;
    }

    if (pNum > ApplVar.FiscalBuff.Fis_ClearRecord.FCount)
        return 1;

    while (sRamOffsetFr <= sRamOffsetTo)
    {
        sMid = (sRamOffsetTo + sRamOffsetFr) / 2;
        RamOffSet = (sMid-1)*FISRECORDLEN+FISDATAADDR;

        if (!Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,RamOffSet,FISRECORDLEN))
            ApplVar.FiscalFlags = BADFM;


        if (ApplVar.FiscalBuff.Fis_ClearRecord.FCount == pNum)
        {
            do
            {
                Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,RamOffSet-FISRECORDLEN,FISRECORDLEN);
                if (ApplVar.FiscalBuff.Fis_ClearRecord.FCount != pNum)
                    break;
                RamOffSet-=FISRECORDLEN;
            } while (1);
            return 0;
        }
        else if (pNum < ApplVar.FiscalBuff.Fis_ClearRecord.FCount)
            sRamOffsetTo = sMid - 1;
        else
            sRamOffsetFr = sMid + 1;
    }
//	RamOffSet = sRamOffsetFr*FISRECORDLEN+FISDATAADDR;
    return -1;
}
    #endif
//--------------------------------------------------------------
/****************************************************************************
 * ������ѯ��ӡ˰�����ݱ���
 *
 * @author EutronSoftware (2017-06-06)
 *
 * @param sType :BIT7=1ʱ,ͳ�ƻ���Z��������(ֻ���FISCLEARLOG)
 *               BIT6=1ʱ,�����ݷ��͵�����(ccr2018-03-23������)
 *               PRINTFMALL:��������ӡFM�е�ȫ������
 *               PRINTFMZ_Z:����������վݺŲ�ѯ��ӡFM����(ֻ���FISCLEARLOG)
 *               PRINTFMDATE:�������ڷ�Χ��ѯ��ӡFM����
 * @param FMType:��������(FISCLEARLOG,FISRESETLOG,...);=0ʱ,ָ����Χ�ڵ�ȫ������
 * @return short
 ****************************************************************************/
short Read_FiscalData(BYTE sType,BYTE FMType)
{
    int   i;
    BYTE    bCRC;
    BYTE    sActive,sTotal,sExit,sZOnly;
#if (CC_DEBUG)
    BYTE    sSend;
#endif
    UnLong  sAddr;
    WORD    sDate;
    BCD     sVal;
    BYTE    sSaveCurrent[8][2];

    sStartZ  = sEndZ = 0;

    if (ApplVar.FiscalHead.MaxP <= FISDATAADDR)
        return 0;

    sTotal = (BIT(sType,BIT7) && FMType==FISCLEARLOG);
#if (CC_DEBUG)
    sSend = (BIT(sType,BIT6) && FMType==FISCLEARLOG);//ccr2018-03-23
#endif
    RESETBIT(sType,BIT7+BIT6);
    memset((char *)&ApplVar.FiscalTotal,0,sizeof(ApplVar.FiscalTotal));//ccr070424

    //Print_NonFiscal();
    //PrintHeader();			//liuj 0610

    memcpy(sSaveCurrent,ApplVar.CurrentTaxRate, sizeof(ApplVar.CurrentTaxRate));// restore the current tax
    memset(&sVal,0,sizeof(BCD));


    Print_NonFiscal(1);

    PrintStr_Center((char *)Msg[PRNFISCAL].str,true);
    PrintLine('=');

    if (sType == PRINTFMZ_Z)
    {//���ݺ�������ѯ����(ֻ���FISCLEARLOG)
        sAddr = FISDATAADDR;
//		i = GetZAddrByNum(LogDefine.RecNumFr);
//		if (i>0)
//			return 0;
//		else
//			sAddr = RamOffSet;

        memset(SysBuf,' ',PRTLEN);
        sprintf(SysBuf,"%s  #%04d  TO  #%04d",Msg[RECEIPTFROM].str,LogDefine.RecNumFr,LogDefine.RecNumTo);
        RJPrint(0,SysBuf);
    }
    else if (sType == PRINTFMDATE)
    {
        memset(SysBuf,' ',PRTLEN);
        CopyFrStr(SysBuf,Msg[RIQI].str);
        DecordDateFiscal(LogDefine.DateFr,SysBuf+8);SysBuf[18]=' ';
        SysBuf[19]='T';SysBuf[20]='O';
        DecordDateFiscal(LogDefine.DateTo,SysBuf+22);
        SysBuf[PRTLEN]=0;
        RJPrint(0,SysBuf);
        i = GetZAddrByDate(LogDefine.DateFr,false);
        if (i>0)
        {
            PrintStr_Center((char*)MsgNOFMDATA,true);
            return 0;
        }
        else
            sAddr = RamOffSet;

    }
    else
        sAddr = FISDATAADDR;

    RFeed(1);
    sActive = sExit = false;

    PutsO(Msg[WAITING].str);
    while (sAddr < ApplVar.FiscalHead.MaxP && !KbHit() && !sExit)
    {
        if (KbHit() && Getch()==CLEARKey)//CLEAR any key for stop
            break;
        FM_EJ_Exist();
        if (sAddr+FISRECORDLEN>FISMEMERYSIZE)
        {//ccr20130314
            ApplVar.FiscalFlags = FMFULL;ApplVar.ErrorNumber=ERROR_ID(CWXXI86);
            return 0;
        }
        else  if (!Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,sAddr,FISRECORDLEN))
        {//ccr070719>>>>>>>>>
            ApplVar.FiscalFlags = FMERROR; ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
#if (CC_DEBUG)
            CheckError(0);
            sprintf(SysBuf,"\nFM-READ ERROR AT:%08x\n",sAddr);
            SendString(SysBuf,strlen(SysBuf));
            SendString((char*)&ApplVar.FiscalBuff.Fis_ClearRecord,FISRECORDLEN);
#endif
            return 0;
        }//<<<<<<<<<<<<<<<<<<<<<<<<
        bCRC = VerifyCRC((BYTE *)&ApplVar.FiscalBuff.Fis_ClearRecord,FISRECORDLEN,1);
        if (bCRC!= ApplVar.FiscalBuff.Fis_ClearRecord.FCRC )//(BYTE *)&ApplVar.FiscalBuff,FISRECORDLEN,1
        {//���ݳ�����.
            sTotal = false;
            ApplVar.ErrorNumber=ERROR_ID(CWXXI82);
#if (CC_DEBUG)
            CheckError(0);
            sprintf(SysBuf,"\nFM(%02x)-CRC(%02x) ERROR AT:%08x\n",(ApplVar.FiscalBuff.Fis_ClearRecord.FunN & 0xff), (bCRC & 0xff),sAddr);
            SendString(SysBuf,strlen(SysBuf));
            SendString((char*)&ApplVar.FiscalBuff.Fis_ClearRecord,FISRECORDLEN);
#endif
            if (ApplVar.FiscalBuff.Fis_ClearRecord.FDate==0xffff || ApplVar.FiscalBuff.Fis_ClearRecord.FDate==0)
               break;  //return 0;
        }

        sActive = false;//ccr100329
        switch (ApplVar.FiscalBuff.Fis_ClearRecord.FunN)
        {
        case FISCLEARLOG:
            if (sType == PRINTFMZ_Z)
            {
                if (ApplVar.FiscalBuff.Fis_ClearRecord.FCount > LogDefine.RecNumTo)
                    sExit = true;
                else
                    sActive= (ApplVar.FiscalBuff.Fis_ClearRecord.FCount >=  LogDefine.RecNumFr &&
                          ApplVar.FiscalBuff.Fis_ClearRecord.FCount <= LogDefine.RecNumTo);
            }
            //ccr2017-06-08>>>>�˴�Z������˰��>>>>>
            memcpy(ApplVar.CurrentTaxRate,ApplVar.FiscalBuff.Fis_ClearRecord.FTaxRate,  sizeof(ApplVar.FiscalBuff.Fis_ClearRecord.FTaxRate));

            sDate = ApplVar.FiscalBuff.Fis_ClearRecord.FDate;
            break;
        case FISRESETLOG:
            if (ApplVar.FiscalBuff.Fis_ReSet.FDate)//ccr2018-03-23�ƺ����Ż�����
              sDate = ApplVar.FiscalBuff.Fis_ReSet.FDate;
            break;
        case FISDISCONNECTLOG://ccr071212
            if (ApplVar.FiscalBuff.Fis_UnitDisconnect.FDate)//ccr2018-03-23�ƺ����Ż�����
               sDate = ApplVar.FiscalBuff.Fis_UnitDisconnect.FDate;
            break;
        case FISHEADCHGLOG:
            sDate = ApplVar.FiscalBuff.Fis_HeadPointer.FDate;
            if (!Bios_FM_Read((BYTE *)&ApplVar.Fis_HeadChg,ApplVar.FiscalBuff.Fis_HeadPointer.FNewPointer,FHEADCHGLEN))
            {
                ApplVar.FiscalFlags = FMERROR;
                ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
                return 0;
            }
            if (!VerifyCRC((BYTE *)&ApplVar.Fis_HeadChg,FHEADCHGLEN,0))
            {
                //sTotal = FALSE;
                ApplVar.ErrorNumber=ERROR_ID(CWXXI82);
                //return 0;
            }
            break;
        case FISTAXLOG:
            if (ApplVar.FiscalBuff.Fis_TaxRate.FDate)//ccr2018-03-23�ƺ����Ż�����
               sDate = ApplVar.FiscalBuff.Fis_TaxRate.FDate;
            memcpy(ApplVar.CurrentTaxRate,ApplVar.FiscalBuff.Fis_TaxRate.FNTaxRate,sizeof(ApplVar.CurrentTaxRate));//ccr060715
            break;
        case FISDATECHGLOG://ccr2017-08-08
            if (ApplVar.FiscalBuff.Fis_DateTime.FDate)//ccr2018-03-23�ƺ����Ż�����
               sDate = ApplVar.FiscalBuff.Fis_DateTime.FDate;
            break;
        }

#if (CC_DEBUG)//ccr2018-03-23
       if (sActive)
          SendString((char*)&ApplVar.FiscalBuff.Fis_ClearRecord,FISRECORDLEN);
#endif

        if (sType==PRINTFMDATE)
        {
            if (sDate > LogDefine.DateTo)//ccr091116
                sExit = true;
            else if (sDate >= LogDefine.DateFr && sDate <= LogDefine.DateTo)
            {
                sActive = !FMType || (ApplVar.FiscalBuff.Fis_ClearRecord.FunN==FMType);
            }
        }

        if (sActive || (sType==PRINTFMALL && (!FMType || (ApplVar.FiscalBuff.Fis_ClearRecord.FunN==FMType))))
        {
            if (!sTotal)
                Print_FiscalData(ApplVar.FiscalBuff.Fis_ClearRecord.FunN,true);
            //�Զ�ȡ�������ݽ���ͳ��
            switch (ApplVar.FiscalBuff.Fis_ClearRecord.FunN)
            {
            case FISCLEARLOG:
                ApplVar.FiscalTotal.FClearCount ++;
                //����Z��������
                for (i=0;i<ApplVar.AP.Tax.Number;i++)
                {
                    AddBcdWithLong(&ApplVar.FiscalTotal.FTaxAmt[i],ApplVar.FiscalBuff.Fis_ClearRecord.FTaxAmt[i]);//ccr070424
                    AddBcdWithLong(&ApplVar.FiscalTotal.FTaxSale[i], ApplVar.FiscalBuff.Fis_ClearRecord.FTaxSale[i]);//ccr070424
                }
                ApplVar.FiscalTotal.FInvSum[FRECEIPTS] += ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice[FRECEIPTS];
                ApplVar.FiscalTotal.FInvSum[NRECEIPTS] += ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice[NRECEIPTS];
                ApplVar.FiscalTotal.FInvSum[TRECEIPTS] += ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice[TRECEIPTS];
                AddBcdWithLong(&ApplVar.FiscalTotal.NoTaxSale, ApplVar.FiscalBuff.Fis_ClearRecord.NoTaxSale);//ccr070424
                ApplVar.FiscalTotal.DiscAmt+= ApplVar.FiscalBuff.Fis_ClearRecord.DiscAmt;       //20070313
                ApplVar.FiscalTotal.DiscTax+= ApplVar.FiscalBuff.Fis_ClearRecord.DiscTax;           //20070313
                ApplVar.FiscalTotal.ReturnAmt += ApplVar.FiscalBuff.Fis_ClearRecord.ReturnAmt;  //20070118
                ApplVar.FiscalTotal.ReturnTax += ApplVar.FiscalBuff.Fis_ClearRecord.ReturnTax;  //20070118


                //for printer
                if (!sStartZ)
                    sStartZ = ApplVar.FiscalBuff.Fis_ClearRecord.FCount;
                sEndZ = ApplVar.FiscalBuff.Fis_ClearRecord.FCount;
                break;
            case FISRESETLOG:
                ApplVar.FiscalTotal.FReSetCount ++;
                break;
            case FISTAXLOG:
                ApplVar.FiscalTotal.FTaxChgCount ++;
                break;
            case FISHEADCHGLOG:
                ApplVar.FiscalTotal.FHeadChgCount ++;
                break;
            case FISDATECHGLOG://ccr2017-08-08
                ApplVar.FiscalTotal.FDateChgCounter ++;
                break;
            }
        }
        sAddr += FISRECORDLEN;
    }

//-------------------liuj modify 070419 ------------------
    if (sTotal || FMType==FISCLEARLOG)
        Print_FiscalTotal();

    memcpy(ApplVar.CurrentTaxRate, sSaveCurrent,sizeof(ApplVar.CurrentTaxRate));// restore the current tax

    Print_NonFiscal(0);

    RFeed(PREHEADER+2);
    return sTotal;  //return 1;
}


#if 0

short Fiscal_AddClearData()
{
    short i,j,k;
    short sOld,sCount;
    WORD sY,sM,sD;
    BYTE sH;
    struct TimeDate sDate;

    if (ApplVar.FiscalHead.MaxP>=FISMEMERYSIZE)
        return 0;

    sOld = ApplVar.FiscalHead.ClearP;
    if (sOld == 0)
        memset(&ApplVar.FiscalBuff,0,sizeof(ApplVar.FiscalBuff.Fis_ClearRecord));
    else
        Bios_FM_Read(&ApplVar.FiscalBuff,sOld,sizeof(ApplVar.FiscalBuff.Fis_ClearRecord));

    SetFis_DateTime(false);
    ApplVar.FiscalBuff.Fis_ClearRecord.FCount++;
    ApplVar.FiscalBuff.Fis_ClearRecord.FTotal = 0;
    for (j=0;j<ApplVar.AP.Tax.Number;j++)
    {
        ApplVar.FiscalBuff.Fis_ClearRecord.FTaxAmt[j] = 30000+ApplVar.FiscalBuff.Fis_ClearRecord.FCount;
        ApplVar.FiscalBuff.Fis_ClearRecord.FTotal += ApplVar.FiscalBuff.Fis_ClearRecord.FTaxAmt[j];
    }

    ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice =300+ApplVar.FiscalBuff.Fis_ClearRecord.FCount;
    ApplVar.FiscalBuff.Fis_ClearRecord.FInvSum += ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice;
    ApplVar.FiscalBuff.Fis_ClearRecord.FEJID = 0;
    ApplVar.FiscalBuff.Fis_ClearRecord.FGross = 0;
    ApplVar.FiscalBuff.Fis_ClearRecord.FCRC = 0;
    ApplVar.FiscalBuff.Fis_ClearRecord.FunN = FISCLEARLOG;

    ApplVar.FisNumber.TotalClearNum++;
    ApplVar.FiscalHead.ClearP = ApplVar.FiscalHead.MaxP;
    ApplVar.FiscalHead.MaxP += sizeof(ApplVar.FiscalBuff.Fis_ClearRecord);
    ApplVar.FiscalBuff.Fis_ReSet.FCRC = VerifyCRC((BYTE *)&ApplVar.FiscalBuff.Fis_ReSet,FISRECORDLEN,1);
    Bios_FM_Write(ApplVar.FiscalHead.ClearP, &ApplVar.FiscalBuff, sizeof(ApplVar.FiscalBuff.Fis_ClearRecord));
    return 1;
}

#endif


/***********************************************************
 * ����д��˰�ش洢���ļ�¼��Ŀ�Ƿ��洦
 *
 * @author EutronSoftware (2018-03-30)
 *
 * @param currNum :��ǰ��¼��Ŀ
 * @param maxNum :���������ֵ
 *
 * @return short :=false,�д�(��¼�����FM��);=true,����д���¼
 *********************************************************/
short Fiscal_CheckNumber(WORD currNum,WORD maxNum)
{
   if (ApplVar.FiscalFlags > MUSTINITEJ)
      return false;

   if (ApplVar.FiscalHead.MaxP>=FISMEMERYSIZE)
   {
       ApplVar.FiscalFlags = FMFULL;ApplVar.ErrorNumber=ERROR_ID(CWXXI86);
       return false;
   }

   if (currNum > maxNum)//ccr091104>>>
   {
       ApplVar.ErrorNumber=ERROR_ID(CWXXI117);//����������������
       //ccr2017-08-08 ApplVar.ErrorNumber=ERROR_ID(CWXXI91);
       ApplVar.FiscalFlags = FMMACFULL;
       return false;
   }//<<<<<
   return true;
}
/**********************************************************
 * ����MAC��¼
 *
 * @author EutronSoftware (2018-03-29)
 *
 * @return short
 *********************************************************/
short Fiscal_AddResetData()
{
    struct TimeDate sDate;
    WORD sY,sM,sD;

    if (!Fiscal_CheckNumber(ApplVar.FisNumber.TotalResetNum,FRESETMAX))
       return false;

    SetFis_DateTime(true);
    ApplVar.FisNumber.TotalResetNum++;
    ApplVar.FiscalBuff.Fis_ReSet.FCount=ApplVar.FisNumber.TotalResetNum;
    sprintf(ApplVar.FiscalBuff.Fis_ReSet.FRelease,"RESET:%04d-%02-%02d,%02x:%02x:%02x",sDate.year,sM,sD,sDate.hour,sDate.min,sDate.sec);

    ApplVar.FiscalBuff.Fis_ReSet.FCRC = 0;
    ApplVar.FiscalBuff.Fis_ReSet.FunN = FISRESETLOG;

    ApplVar.FiscalHead.ReSetP = ApplVar.FiscalHead.MaxP;
    ApplVar.FiscalHead.MaxP += sizeof(ApplVar.FiscalBuff.Fis_ReSet);

    ApplVar.FiscalBuff.Fis_ReSet.FCRC = VerifyCRC((BYTE *)&ApplVar.FiscalBuff.Fis_ReSet,FISRECORDLEN,1);
    if (!Bios_FM_Write(ApplVar.FiscalHead.ReSetP, &ApplVar.FiscalBuff, FISRECORDLEN))
    {//ccr070719>>>>>>>>>
        ApplVar.FiscalFlags = BADFM;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI76);
        return 0;
    }//<<<<<<<<<<<<<<<<<<<<<<<<
    return 1;
}


// ��˰�ؿ��ο���¼��FM����  //
/******************************************************************************
 * ������Disconnect״̬д��FM,��¼����ͳһΪFISDISCONNECTLOG,�������¼������:
 * FISxFMCOUNT        0                    //FM�γ�����
 * FISxEJCOUNT       (FISxFMCOUNT     +1)  //SD���γ�����ͳ��
 * FISCMOSERRCOUNT   (FISxEJCOUNT     +1)  //CMOS����(���ݴ�)����ͳ��
 * FISxPRINTERCOUNT  (FISCMOSERRCOUNT +1)  //��ӡ���Ͽ�����ͳ��
 *
 * @author EutronSoftware (2018-03-30)
 *
 * @param disType :FISxFMCOUNT,FISxEJCOUNT,FISCMOSERRCOUNT,FISxPRINTERCOUNT
 *
 * @return short :=falseʱ,�����洦��FM����дFM����
 ****************************************************************************/
short Fiscal_AddDisconnect(WORD disType)
{//ccr071212

    if (!Fiscal_CheckNumber(ApplVar.FisNumber.TotalXUnit[disType] , FXCOUNTMAX[disType]))
       return false;

    SetFis_DateTime(true);
    ApplVar.FisNumber.TotalXUnit[disType]++;
    ApplVar.FiscalBuff.Fis_UnitDisconnect.FXType = disType;
    ApplVar.FiscalBuff.Fis_UnitDisconnect.FXUnitCount[disType]=ApplVar.FisNumber.TotalXUnit[disType];

    ApplVar.FiscalBuff.Fis_UnitDisconnect.FCRC = 0;
    ApplVar.FiscalBuff.Fis_UnitDisconnect.FunN = FISDISCONNECTLOG;

    ApplVar.FiscalHead.ECRxUnitP = ApplVar.FiscalHead.MaxP;
    ApplVar.FiscalHead.MaxP += sizeof(ApplVar.FiscalBuff.Fis_UnitDisconnect);

    ApplVar.FiscalBuff.Fis_UnitDisconnect.FCRC = VerifyCRC((BYTE *)&ApplVar.FiscalBuff.Fis_UnitDisconnect,FISRECORDLEN,1);
    if (!Bios_FM_Write(ApplVar.FiscalHead.ECRxUnitP, &ApplVar.FiscalBuff, FISRECORDLEN))
    {//ccr070719>>>>>>>>>
        ApplVar.FiscalFlags = BADFM;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI76);
        return 0;
    }//<<<<<<<<<<<<<<<<<<<<<<<<

    return 1;
}
//��Z������ӡ��Ϻ�,����FiscalReport_End������д��FM
//Ȼ���ٵ���GetReport���Z��������
void FiscalReport_End()
{
    UnLong sLastZ;
    int i;

//Write to FiscalRam-------------------------------
#if defined(CASE_GREECE)
//    memcpy(ApplVar.FiscalBuff.Fis_ClearRecord.FZASED, ApplVar.SHA1_Copy,SHA1HashSize);//ccr2018-03-28
#endif
    if (Write_FiscalRam( ApplVar.FiscalHead.MaxP,&ApplVar.FiscalBuff.Fis_ClearRecord,FISRECORDLEN))
    {
        RESETBIT(ApplVar.Fiscal_PrintFlag,BIT2);
        ApplVar.FiscalHead.ClearP = ApplVar.FiscalHead.MaxP;//ccr070615
        ApplVar.FiscalHead.MaxP += FISRECORDLEN;

        memset(ApplVar.FisNumber.ReceiptNum,0,sizeof(ApplVar.FisNumber.ReceiptNum));//ccr091027
        ApplVar.SaleReceipts = 0;//ccr091027

        ApplVar.ZReport = 1;        /* set fiscal report taken */
        if (ApplVar.FReport == Z)
        {
            if (ApplVar.FTrain)//ccr090507 ApplVar.Report.PointerType == 1 && ApplVar.FTrain)   /* training clerk ? */
            {//ccr090507>>>>>>>>>>>>>>>>>>>>
                ApplVar.ZCount[TRAINZNUM]++;//ccr090507
            }/* <<<<<<<<<not add with training clerk */
            else
            {
                ApplVar.FisNumber.TotalClearNum++;
                ApplVar.ZCount[FISCALZNUM] = ApplVar.FisNumber.TotalClearNum;//ccr091027 add to z -count
            }
        }

        //Clear Fiscal Z Report-------------------------------
        SETMyFlags( CLOSEPRINT);//set the flag to clear data only
        SETBIT(ApplVar.Fiscal_PrintFlag, BIT5);//set the flag to clear data only
        GetReport(ApplVar.ReportNumber);

#if defined(CASE_EURO) //!!! GREECE_ONLY !!!
        //ccr2017-06-23>>���X���ļ�������>>>>>>
#if (salNumber)
        for (i=xPLUDAILY-XREPORT1ST;i<=xWAITERSDAILY-XREPORT1ST;i++)
#else
        for (i=xPLUDAILY-XREPORT1ST;i<=xCLERKSDAILY-XREPORT1ST;i++)
#endif
        {
            ApplVar.ReportNumber=TblXZ_Funcs[i]+1;
            GetReport(ApplVar.ReportNumber);
        }
        ApplVar.FReport = 0;
        //ccr2017-06-23<<<<<<<<<<<<<<<<<<<<<<<<
#endif

        RESETBIT(ApplVar.Fiscal_PrintFlag, BIT5);
        CLRMyFlags( CLOSEPRINT);
        //Clear ApplVar.Report-------------------------------
        ApplVar.TotalMax = ApplVar.FExento = ZERO;     /* ccr090113 clear daily itemizers */
        ApplVar.FRetAmt = ApplVar.FRetTax = ZERO;
        ApplVar.FDiscAmt=ZERO;

//			 ApplVar.FTotal = ZERO;      /* ApplVar.FNetTotal is soft total and cleared at start of report */

        memset(&ApplVar.FTaxTotal,0,sizeof(ApplVar.FTaxTotal));
        memset(&ApplVar.FNetTotal,0,sizeof(ApplVar.FNetTotal));

        ApplVar.FTotal_Flags = 0;
        ApplVar.Fiscal_PrintFlag = 0;   //Reset ApplVar.Fiscal_PrintFlag--
#if DD_FISPRINTER
        MemSet(&ApplVar.DiscountAmt, sizeof(ApplVar.DiscountAmt), 0);
        MemSet(&ApplVar.RefundAmt, sizeof(ApplVar.RefundAmt), 0);

        RESETBIT(ApplVar.Fiscal_Status, OVERDATE);
#endif

        sLastZ = (FISMEMERYSIZE-ApplVar.FiscalHead.MaxP)/FISRECORDLEN;
        if (!sLastZ )        /* only less then 60  reports left ? */
            ApplVar.ErrorNumber=ERROR_ID(CWXXI86);       /* memory broken */
        else if (sLastZ <= FISRECORD_LESS)
            ApplVar.ErrorNumber=ERROR_ID(CWXXI77) ;

#if defined(CASE_GPRS)
        if (BIT(ApplVar.DaysMust,BIT7))//���Զ��������ݣ�����˰������
        {
            GPRSSendECR_FM();
        }
#endif
#if defined(CASE_ETHERNET)
        if (BIT(ApplVar.DaysMust,BIT7))//���Զ��������ݣ�����˰������
        {
            HTTPPost_SFiles();//ccr2017-10-23ETHERNETSendECR_FM();
        }
#endif
        RTC_AlarmSet();//ccr2017-12-18��λ24Сʱ����������
    }
    else
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI76);     // write fiscal date error //
        ApplVar.FiscalFlags = BADFM;
        ApplVar.ZReport = 2;        /* take Z ApplVar.Report */
    }
//Write to FiscalRam-------------------------------
}


/********************************************************************************
 * ��ӡ˰��Z���� ��Z�˵��µ�1�ű�����
 * �ڴ�ӡ˰��Z����ʾ,��Ҫʹ��ApplVar.FiscalBuff.Fis_ClearRecord�洢��˰����
 * @author EutronSoftware (2017-11-15)
 *
 * @param delOld :�Ƿ�ɾ�������Ӧ�÷ϳ���Z�����ļ�
 ********************************************************************************/
void Print_FiscalReport(BYTE delOld)
{
    RESETBIT(ApplVar.Fiscal_PrintFlag,BIT7);

    //�������´�����ʽ��Ϊ��ȷ����ӡһ��������Z�����ĵ�
    //���,�����ӡ���̵���ȱֽ,���Զ����´�ӡZ����
    do
    {
#ifdef CASE_FATFS_EJ
#if (SDCACHESIZE)//ccr2018-03-21
        if (ApplVar.SDCache.Type)
            ResetReceiptNumber(ApplVar.SDCache.ReceiptNo);
        SDCacheReset(0);//ccr2018-03-21
#else
        if (!BIT(ApplVar.Fiscal_PrintFlag,BIT7))  //ccr2018-01-24
#endif
        {
            if (!CreateFileZ_TXT())
            {
                CLRMyFlags(ZREPORT);
                ApplVar.ZReport = 1;        /* set fiscal report taken */
                ApplVar.FTotal_Flags = 0;
                return;
            }
        }
#endif

        if (BIT(ApplVar.Fiscal_PrintFlag,BIT7))  //liuj 0528
        {
            RJPrint(0, MessageE60);
        }

        RESETBIT(ApplVar.Fiscal_PrintFlag,BIT7+BIT5);
        SETBIT(ApplVar.Fiscal_PrintFlag,BIT2);//���ô�ӡ˰��Z����״̬��־
        ApplVar.ErrorNumber=0;
        //�п���ȱֽ�����´�ӡ,���ǿ���������²���
        ApplVar.FReport = Z;
        ApplVar.ReportNumber = 1;
        ApplVar.RepComputer = 0;
        //��GetReport�е���PrintFiscalTax���Z�������ݵ����ɺʹ�ӡ
        ApplVar.ZReport = 2;       //ccr2017-12-21 ���������ӡʧ��(�ϵ�),�´ο���ʱ,����ǿ�ƴ�ӡZ����
        GetReport(ApplVar.ReportNumber);
        while (TestPrintGoingOn()){ } //ccr2018-03-22�ȴ��������ݴ�ӡ���
    }while (BIT(ApplVar.Fiscal_PrintFlag,BIT7));

//ccr091228>>>>>>>>>>>>>>>>>>>>>
    if (ApplVar.FiscalFlags == BADEJ)
    {// ��ӡZ����ʱ,EJ������,��ʾ�Ƿ����  //
        RJPrint(0, BADEJBYZ);
        PutsO(PRINTZBADEJ);
        return;
    }
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    if (!ApplVar.FTrain) // ����ѵģʽ //
    {
        FiscalReport_End();//����Z��������
    }
    else
    {
        ApplVar.ZReport = 1;        /* set fiscal report taken */   //cc 20071026
        ApplVar.FTotal_Flags = 0;
    }
#if SDCACHESIZE//ccr2018-03-16
    SDCachePushEnd();
    //ccr2018-04-02>>>>>>>
    while (WaitForYesNo(MsgSAVETOSDCARD,0,1,true)=='N')
    {
       Fiscal_AddDisconnect(FISxEJCOUNT);
    }
    ClearLine2();
    //ccr2018-04-02<<<<<<<
    SDCacheFlushData(true);
#endif//ccr2018-03-16<<<<<
}

/*****************************************************
 * ��ӡ��ʷZ�ձ���������
 *
 * @author EutronSoftware (2017-05-18)
 ****************************************************/
void Print_ZDailySum()
{
    BCD sVal,sVal1;
    int i,j,k;
    BYTE saveTaxNumber;
    long  sLong;
    BYTE slen;  //20070313
    BCD sTotalSale, sTotalTax,sTaxESale;
    char strNetValue[PRTLEN+1];

#if (defined(CASE_GREECE))//ϣ���ڽ��ǰ����ӡŷԪ����
        Prefix1 = Prefix2 = 0;
#endif

        //PrintLine('=');//��Լֽ��
        PrintStr_Center(CUMULATIVE,true);//"   CUMULATIVE TOTALS"
        PrintLine('=');

        //ITEMTAXA to ITEMTAXH>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        saveTaxNumber = ApplVar.TaxNumber;
        //"TAX SALE  "
        sTotalSale = ZERO;
        sTotalTax = ZERO;
        sTaxESale = ZERO;
        strcpy(strNetValue,Msg[XIAOSHOUA].str);
        k=strlen(strNetValue);
        strNetValue[k++]=' ';
        for (i=0;i<ApplVar.AP.Tax.Number;i++)
        {
             sVal1 = ZERO;
             sVal = ApplVar.FNetSum[i];
             //��ӡNET AMOUNT
#if !defined(CASE_EURO)  //ccr2017-08-02
            if (CheckNotZero(&sVal))//ccr070424
#endif
            {
                memset(ProgLineMes,' ',PRTLEN);

                slen = strlen(Msg[XIAOSHOUA].str);
                memcpy(ProgLineMes,Msg[XIAOSHOUA].str,slen);

                CWORD(sVal1.Value[0]) = CWORD(ApplVar.CurrentTaxRate[i][0]);
                sVal1.Sign = 2;

                if (CWORD(sVal1.Value[0]))
                {
                    strNetValue[k++]='A' + i;
                    Add(&sTotalSale,&sVal);
                }
                else
                    Add(&sTaxESale,&sVal);

#if !defined(CASE_EURO)  //ccr2017-08-02
                ProgLineMes[++slen] = 'A' + i;  //ProgLineMes[6] = 'A' + i;	//20070313
#if !defined(CASE_EURO)  //ccr2017-08-02
                if (CheckNotZero(&sVal1))
#endif
                {
                    ProgLineMes[++slen] = '(';  //ProgLineMes[6] = 'A' + i;	//20070313
                    slen+=5;
                    FormatQty(ProgLineMes+slen,&sVal1);//cr070424
                    ProgLineMes[++slen] = '%';
                    ProgLineMes[++slen] = ')';
                    ProgLineMes[++slen] = 0;
                    PrintAmt(ProgLineMes,&sVal);//TAXABLE A  7.00%
                }
#endif
            }

            sVal1 =ZERO;
            sVal = ApplVar.FTaxSum[i];
            //��ӡTAX AMOUNT
#if !defined(CASE_EURO)  //ccr2017-08-02
            if (CheckNotZero(&sVal))//ccr070424
#endif
            {
                memset(ProgLineMes,' ',PRTLEN);
                Add(&sTotalTax,&sVal);

                CWORD(sVal1.Value[0]) = CWORD(ApplVar.CurrentTaxRate[i][0]);

                sVal1.Sign = 2;

                slen = strlen(Msg[ITEMTAXA].str);
                memcpy(ProgLineMes,Msg[ITEMTAXA].str,slen);ProgLineMes[VAT_A_P]+=i;
                ProgLineMes[slen]='(';slen+=5;
                FormatQty(ProgLineMes+slen,&sVal1);//ccr070424
                ProgLineMes[++slen] = '%';
                ProgLineMes[++slen] = ')';
                ProgLineMes[++slen] = 0;

                PrintAmt(ProgLineMes,&sVal);
            }
        }
#if !defined(CASE_EURO)  //ccr2017-08-02
        PrintLine('.');
        //TOTAL NET SALE >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        if (CheckNotZero(&sTotalSale))
#endif
        {
            strNetValue[k]=0;
            PrintAmt(strNetValue,&sTotalSale);//SUM of NET Value for VAT
        }

        //TAX-EXEMPT
#if !defined(CASE_EURO)  //ccr2017-08-02
        if (CheckNotZero(&sTaxESale))
#endif
        {
            PrintAmt(Msg[MIANSHUI].str,&sTaxESale);//TAX-EXEMPT
        }
        ApplVar.TaxNumber = saveTaxNumber;

       //TAX TOTAL>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        PrintAmt(Msg[TAXTOTAL].str,&sTotalTax);  //TAX SUM

//ccr2017-08-02        sVal = ZERO;
//ccr2017-08-02        ULongToBCDValue(sVal.Value, ApplVar.FisNumber.TotalReceiptNum[FRECEIPTS]);//ccr091027
//ccr2017-08-02        RJPrint(0, FormatQtyStr(Msg[MESG_RECEIPTSUMNo].str, &sVal, PRTLEN)); // liuj 0829
#if (1)//!defined(CASE_GREECE)
        GetReceiptTotalNumber(SysBuf);//ccr2017-08-02
        RJPrint(0,SysBuf);

        memset(SysBuf,' ',PRTLEN);
        CopyFrStr(SysBuf,Msg[TOTALZCOUNTER].str);
        if (ApplVar.FTrain)
            ULongtoASCZER0(SysBuf+PRTLEN-1,ApplVar.ZCount[TRAINZNUM],4);
        else
            ULongtoASCZER0(SysBuf+PRTLEN-1,ApplVar.ZCount[FISCALZNUM],4);
        RJPrint(0,SysBuf);
#endif

#if (!defined(CASE_EURO))
        PrintAmt(Msg[GRANDTOTAL].str, &ApplVar.FTotal);
#endif

//#if (defined(CASE_EURO))
//    Prefix1 = PREFIX_1;
//    Prefix2 = PREFIX_2;
//#endif

}
//
/************************************************************************
 * ��ӡ������۹�����Ŀ��Z�������ݺ�,��ӡ�ʹ洢Z�����Ļ�������
 * ���ձ�����˰�����ݴ��� ApplVar.FiscalBuff.Fis_ClearRecord ��
 * @author EutronSoftware (2018-03-28)
 ***********************************************************************/
void PrintFiscalTax()
{
    int i ;
    WORD sYear,sMonth,sDay;
    BCD bcdtemp;
	long	cpFTaxSale[8];	//Sale amount of each tax (NET value),���۽��
	long	cpFTaxAmt[8];		//Total Tax amount (��˰���)

    if (ApplVar.FReport == Z)
    {
//ccr2017-08-02        PrintStr_Center((char *)Msg[SHKZBB].str,true);//~Z ~R~E~P~O~R~T
//ccr2017-08-02        PrintLine('=');

        SetFis_DateTime(true);
        ApplVar.FiscalBuff.Fis_ClearRecord.FCount = ApplVar.FisNumber.TotalClearNum;//ccr091027


        //receipt number
        ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice[FRECEIPTS] = ApplVar.SaleReceipts;//ccr091027
        ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice[NRECEIPTS] = ApplVar.FisNumber.ReceiptNum[NRECEIPTS];
        ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice[TRECEIPTS] = ApplVar.FisNumber.ReceiptNum[TRECEIPTS];

        ApplVar.FiscalBuff.Fis_ClearRecord.FInvSum[FRECEIPTS] = ApplVar.FisNumber.TotalReceiptNum[FRECEIPTS];//ccr091027
        ApplVar.FiscalBuff.Fis_ClearRecord.FInvSum[NRECEIPTS] = ApplVar.FisNumber.TotalReceiptNum[NRECEIPTS];//ccr091027
        ApplVar.FiscalBuff.Fis_ClearRecord.FInvSum[TRECEIPTS] = ApplVar.FisNumber.TotalReceiptNum[TRECEIPTS];//ccr091027

        //ccr2017-05-02>>>>>>�����ӦZ�����ĵ�һ���վݿ�ʼ����>>>>>>>>>
        sYear=ApplVar.ZDate / 10000;
        sMonth=(ApplVar.ZDate / 100)%100;
        sDay=ApplVar.ZDate % 100;
        ApplVar.FiscalBuff.Fis_ClearRecord.FZDateFrom = EncordBCDDate(DECtoBCD(sYear),DECtoBCD(sMonth),DECtoBCD(sDay));//ccr2017-05-02 ApplVar.LastInvoiceDate;
        //ccr2017-05-02<<<<<<<<<<<<<<<
        memcpy(ApplVar.FiscalBuff.Fis_ClearRecord.FZTimeFrom, ApplVar.LastInvoiceTime, 3);

        //ccr2017-06-08>>>>����˴�Z������˰��>>>>>
        memcpy(ApplVar.FiscalBuff.Fis_ClearRecord.FTaxRate, ApplVar.CurrentTaxRate, sizeof(ApplVar.FiscalBuff.Fis_ClearRecord.FTaxRate));

#ifdef CASE_FATFS_EJ
        ApplVar.FiscalBuff.Fis_ClearRecord.FEJID = ApplVar.Fis_EJTbl.FEJID;
#else
        ApplVar.FiscalBuff.Fis_ClearRecord.FEJID = 1;       //20070118
#endif

        //Func Num = 0xa0
        ApplVar.FiscalBuff.Fis_ClearRecord.FunN = FISCLEARLOG;

        ApplVar.FiscalBuff.Fis_ClearRecord.NoTaxSale=BCDValueToULong(ApplVar.FExento.Value, BCDLEN);
        if (ApplVar.FExento.Sign & 0x80)
            ApplVar.FiscalBuff.Fis_ClearRecord.NoTaxSale = -ApplVar.FiscalBuff.Fis_ClearRecord.NoTaxSale;
#if defined(CASE_EURO)
        for(ApplVar.TaxNumber=0;ApplVar.TaxNumber<ApplVar.AP.Tax.Number;ApplVar.TaxNumber++)
		{
			ApplVar.FiscalBuff.Fis_ClearRecord.FTaxSale[ApplVar.TaxNumber]=BCDValueToULong(ApplVar.FTaxTotal[ApplVar.TaxNumber].Value, BCDLEN);
	        if(ApplVar.FTaxTotal[ApplVar.TaxNumber].Sign & 0x80) // liuj 0912 e
	               ApplVar.FiscalBuff.Fis_ClearRecord.FTaxSale[ApplVar.TaxNumber] =
                        -ApplVar.FiscalBuff.Fis_ClearRecord.FTaxSale[ApplVar.TaxNumber];
			ApplVar.FiscalBuff.Fis_ClearRecord.FTaxAmt[ApplVar.TaxNumber]=BCDValueToULong(ApplVar.FNetTotal[ApplVar.TaxNumber].Value, BCDLEN);
	        if(ApplVar.FNetTotal[ApplVar.TaxNumber].Sign & 0x80)// liuj 0912 e
	              ApplVar.FiscalBuff.Fis_ClearRecord.FTaxAmt[ApplVar.TaxNumber] =
                        -ApplVar.FiscalBuff.Fis_ClearRecord.FTaxAmt[ApplVar.TaxNumber];

            ReadTax();
            CWORD(ApplVar.CurrentTaxRate[ApplVar.TaxNumber][0]) = CWORD(ApplVar.Tax.Rate[0]);

		}

		ApplVar.FiscalBuff.Fis_ClearRecord.ReturnAmt=BCDValueToULong(ApplVar.FRetAmt.Value, BCDLEN);
		ApplVar.FiscalBuff.Fis_ClearRecord.ReturnTax=BCDValueToULong(ApplVar.FRetTax.Value, BCDLEN);
		memset(&ApplVar.FRetAmt,0,sizeof(ApplVar.FRetAmt));
		memset(&ApplVar.FRetTax,0,sizeof(ApplVar.FRetTax));

		ApplVar.FiscalBuff.Fis_ClearRecord.FCRC = VerifyCRC((BYTE *)&ApplVar.FiscalBuff.Fis_ClearRecord,FISRECORDLEN,1);

#endif

        Print_FiscalData(FISCLEARLOG,false);

        Print_ZDailySum();

    }

    ApplVar.FisNumber.LastZDate= ApplVar.FiscalBuff.Fis_ClearRecord.FDate;            //20070313
    memcpy(ApplVar.FisNumber.LastZTime, ApplVar.FiscalBuff.Fis_ClearRecord.FTime, sizeof(ApplVar.FisNumber.LastZTime));

    Bell(2);

    PrintFiscalAttribute();//ccr071212

}


void FiscalTrailer()
{
    BYTE i;
#if (defined(CASE_GREECE))
    //ccr2017-05-02 ��ӡƱβ˰��LOGO
    //memset(SysBuf,' ',PRTLEN);
    //CopyFrStr(SysBuf,APPRCODE);
    //strcpy(SysBuf+4, ApplVar.Fis_Header.FFisCode);
    PrintStr_Center(ApplVar.ApprovalCode,true);

#else//defined(CASE_EURO)

    memcpy(SysBuf, ApplVar.GrafTexts[0], sizeof(ApplVar.GrafTexts[0]));//����GrafTexts[0]��GrafTexts[1]
    SysBuf[PRTLEN+2]=ApplVar.GrafTexts[1][0];

    //copy serial number to graphic text
    memset(&ApplVar.GrafTexts[0][0], ' ', sizeof(ApplVar.GrafTexts[0]));

    ApplVar.GrafTexts[0][15] = 'D';
    ApplVar.GrafTexts[0][16] = 'S' ;
    strncpy(&ApplVar.GrafTexts[0][18], ApplVar.Fis_Header.FFisCode,MAX_FISCAL_CODE);

    ApplVar.GrafTexts[0][PRTLEN] = 0;
    ApplVar.GrafTexts[1][0]=0;

#if (PC_EMUKEY)
    if (!FisTestTask.PrnOFF)  //ccr080519 added for control the printing of pb message
#endif
      if (!MyFlags( CLOSEPRINT))//��ӡ˰��ͼ��(LOGO),����˰����
        Bios(BiosCmd_PrintGraph, (void*)(GRAPHICMAX), 1 , 0); //�ڵ�7���ַ�λ�ô�ӡ˰��Logo,����GrafTexts[0]������

    memcpy(ApplVar.GrafTexts[0], SysBuf, sizeof(ApplVar.GrafTexts[0]));//�ָ�GrafTexts[0]��GrafTexts[1]
    ApplVar.GrafTexts[1][0]=SysBuf[PRTLEN+2];

    RFeed(1);

#endif
}
//��Ʊͷ��ӡ˰����Ϣ
void FiscalHeader()
{
//* 20070313 VZLA format
#if (0)//(RIFMUST)// DD_FISPRINTER // liuj 0806

        memset(SysBuf, ' ', sizeof(SysBuf));
        memcpy(SysBuf, Msg[RIFCODE].str, strlen(Msg[RIFCODE].str));
        strcpy(SysBuf+PRTLEN-strlen(ApplVar.Fis_Header.FRIFNumber), ApplVar.Fis_Header.FRIFNumber);
        SysBuf[PRTLEN] = 0;
        RJPrint(0, SysBuf);
#endif
/*		memset(SysBuf, ' ', sizeof(SysBuf));
        CopyFrStr(SysBuf+(PRTLEN-strlen(ApplVar.Fis_Header.FRIFNumber))/2, (CONSTCHAR*)ApplVar.Fis_Header.FRIFNumber);
        SysBuf[PRTLEN] = 0;
        RJPrint(0, SysBuf);	*/
}


//write heading change info to fiscal card
//printIT:������Ƿ��ӡ
void Fiscal_AddHeaderChg(bool printIT)
{
    int i,j;
    ULONG HeadAdr,sLastZ;
    short sActive;
    BCD sVal;

#if DD_FISPRINTER == 0
    if (!Fiscal_CheckNumber(ApplVar.FisNumber.TotalHeadChangeNum , FHEADCHGMAX))
    {
       memcpy(ApplVar.TXT.Header,ApplVar.Fis_HeadChg.FNewHead,sizeof(ApplVar.TXT.Header));
       return;
    }

    if (ApplVar.FMPullOut[NEWHEAD_FLAG]!=0x69)//ccr070609pm
        return;
    else
        ApplVar.FMPullOut[NEWHEAD_FLAG]=0;
#endif

    sActive = memcmp(ApplVar.TXT.Header,ApplVar.Fis_HeadChg.FNewHead,sizeof(ApplVar.TXT.Header));

    if (!sActive)
        return;
    else
    {
        //ccr2018-01-17>>>Ϊ��ӡ��Ʊͷ�����Ʊͷ����>>>>
        memcpy(SDRW_Buffer,ApplVar.Fis_HeadChg.FNewHead,sizeof(ApplVar.Fis_HeadChg.FNewHead));
        //ccr2018-01-17>>>�ȴ�ӡ��Ʊͷ<<<<
        memset(ApplVar.Fis_HeadChg.FNewHead,0,sizeof(ApplVar.Fis_HeadChg.FNewHead));
        memcpy(ApplVar.Fis_HeadChg.FNewHead,ApplVar.TXT.Header,sizeof(ApplVar.TXT.Header));
    }
/*ccr070423/------------------liuj modify 070410 ----------------
    if( ApplVar.FisNumber.TotalHeadChangeNum>FHEADCHGMAX)
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI76);		// ccr070423 write fiscal date error
        return;
    }
//------------------liuj modify 070410 ----------------	*/
    //process head string
    //CRC
    ApplVar.Fis_HeadChg.FCRC = VerifyCRC((BYTE *)&ApplVar.Fis_HeadChg,FHEADCHGLEN,1);
    ApplVar.Fis_HeadChg.FunN = FISHEADLOG;

    HeadAdr = FISHEADCHGADDR+ApplVar.FisNumber.TotalHeadChangeNum*FHEADCHGLEN;
    //�����µ�Ʊͷ���ݴ���˰�ش洢��
    if (!Write_FiscalRam(HeadAdr,&ApplVar.Fis_HeadChg,FHEADCHGLEN))
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI76);     /* write fiscal date error */
    }
    if (ApplVar.ErrorNumber)
        return;

    //process head pointer
    SetFis_DateTime(true);

    //Count
    ApplVar.FiscalBuff.Fis_HeadPointer.FChgCount = ApplVar.FisNumber.TotalHeadChangeNum + 1; // liuj modify 080527

    //new pointer of heading
    HeadAdr = FISHEADCHGADDR+ApplVar.FisNumber.TotalHeadChangeNum*FHEADCHGLEN;
    ApplVar.FiscalBuff.Fis_HeadPointer.FNewPointer = HeadAdr;

    //old pointer of heading
    //ApplVar.FiscalBuff.Fis_HeadPointer.FOldPointer = 0;

    //CRC
    ApplVar.FiscalBuff.Fis_HeadPointer.FCRC = VerifyCRC((BYTE *)&ApplVar.FiscalBuff.Fis_HeadPointer,FISRECORDLEN,1);

    ApplVar.FiscalBuff.Fis_HeadPointer.FunN = FISHEADCHGLOG;

    if (Write_FiscalRam( ApplVar.FiscalHead.MaxP,&ApplVar.FiscalBuff.Fis_HeadPointer,sizeof(ApplVar.FiscalBuff.Fis_HeadPointer)))
    {
        ApplVar.FiscalHead.FisHeadChgP = ApplVar.FiscalHead.MaxP;//ccr070615
        ApplVar.FiscalHead.MaxP += FISRECORDLEN;

        ApplVar.FisNumber.TotalHeadChangeNum++;

        sLastZ = (FISMEMERYSIZE-ApplVar.FiscalHead.MaxP)/FISRECORDLEN;
        if (!sLastZ )        /* only less then 60  reports left ? */
            ApplVar.ErrorNumber=ERROR_ID(CWXXI86);       /* memory broken */
        else if (sLastZ <= FISRECORD_LESS)
            ApplVar.ErrorNumber=ERROR_ID(CWXXI77) ;

    }
    else
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI76);     /* write fiscal date error */
        return;
    }

    Save_ConfigVar(true);

    if (printIT)
    {
#if DD_FISPRINTER == 0
        Print_NonFiscal(1);

        PrintLine('=');
        PrintStr_Center(MSG_HEADEROLD,true);
        PrintLine('-');
        //ccr2018-01-17 ��ӡ��Ʊͷ
        if (SDRW_Buffer[0])
        {
            i=0;
            for (j = 0; j < HEADLINES; j++)
            {
                if (SDRW_Buffer[i])
                {
                    PrintStr_Center(SDRW_Buffer+i,DBLHIPRN & BIT3);
                    i+=(PRTLEN+1);
                }
                else
                    break;
            }
        }

        RFeed(1);
        PrintStr_Center(MSG_HEADERNEW,true);
        PrintLine('-');
        if (ApplVar.TXT.Header[0][0])
        {
            for (j = 0; j < HEADLINES; j++)
            {
                if (ApplVar.TXT.Header[j][0])
                {
                    PrintStr_Center(ApplVar.TXT.Header[j],DBLHIPRN & BIT3);
                }
                else
                    break;
            }
        }
        PrintLine('-');
        RFeed(1);
        memset(SysBuf,' ',PRTLEN);
        CopyFrStr(SysBuf,Msg[CHANGEHEAD].str);
        WORDtoASC(SysBuf+PRTLEN-5, ApplVar.FisNumber.TotalHeadChangeNum);
        SysBuf[PRTLEN-4]='/';
        WORDtoASC(SysBuf+PRTLEN-1,FHEADCHGMAX);
        SysBuf[PRTLEN]=0;
        RJPrint(0,SysBuf);

    //	FiscalTrailer();//ccr070610??????????????????
        PrintLine('=');
        Print_NonFiscal(0);
        RFeed(PREHEADER+2);
        CLRMyFlags(PRNTRAI);  //liuj 0610
#endif
    //liuj 0610
    }

}


/*********************************************************
 * write tax change info to fiscal card
 *
 * @author EutronSoftware (2017-12-21)
 *
 * @param sSaveFM :=true, Save TAX to FM but not print
 **********************************************************/
void Fiscal_AddTaxRateChg(BYTE sSaveFM)
{
    UnLong sLastZ;
    BCD sVal;

#if DD_FISPRINTER == 0
    if ((ApplVar.FMPullOut[NEWTAX_FLAG] & 0xf0)!= 0x60)//˰���Ƿ����޸�?
        return;
    else
        ApplVar.FMPullOut[NEWTAX_FLAG]=0;

    if (!Fiscal_CheckNumber(ApplVar.FisNumber.TotalTaxChangeNum , FTAXCHGMAX))
       return;
#endif
    memset(&ApplVar.FiscalBuff.Fis_TaxRate,0,sizeof(ApplVar.FiscalBuff.Fis_TaxRate));
    for (ApplVar.TaxNumber=0;ApplVar.TaxNumber<ApplVar.AP.Tax.Number;ApplVar.TaxNumber++)
    {//������˰�ʽ��бȽ�,�ж��Ƿ����޸�
        ReadTax();
        CopyOfTax[ApplVar.TaxNumber]=CWORD(ApplVar.Tax.Rate[0]);
        CWORD(ApplVar.FiscalBuff.Fis_TaxRate.FNTaxRate[ApplVar.TaxNumber][0]) = CWORD(ApplVar.Tax.Rate[0]);
        if (CWORD(ApplVar.CurrentTaxRate[ApplVar.TaxNumber][0]) != CWORD(ApplVar.Tax.Rate[0]))
        {
            ApplVar.FMPullOut[NEWTAX_FLAG]=0x69;//˰�����޸�
        }
    }

    if (ApplVar.FMPullOut[NEWTAX_FLAG]==0x69 || sSaveFM)
    {
        ApplVar.FMPullOut[NEWTAX_FLAG]=0;

        memcpy(ApplVar.FiscalBuff.Fis_TaxRate.FOTaxRate,ApplVar.CurrentTaxRate,sizeof(ApplVar.FiscalBuff.Fis_TaxRate.FOTaxRate));//ccr070615
        //Date
        SetFis_DateTime(false);

        //change count
        ApplVar.FiscalBuff.Fis_TaxRate.FChgCount = ApplVar.FisNumber.TotalTaxChangeNum + 1;

        //CRC
        ApplVar.FiscalBuff.Fis_TaxRate.FCRC = VerifyCRC((BYTE *)&ApplVar.FiscalBuff.Fis_TaxRate,FISRECORDLEN,1);

        //Func Num = 0xa3
        ApplVar.FiscalBuff.Fis_TaxRate.FunN = FISTAXLOG;

        if (Write_FiscalRam(ApplVar.FiscalHead.MaxP,&ApplVar.FiscalBuff.Fis_TaxRate,FISRECORDLEN))
        {
            memcpy(ApplVar.CurrentTaxRate, ApplVar.FiscalBuff.Fis_TaxRate.FNTaxRate,sizeof(ApplVar.FiscalBuff.Fis_TaxRate.FOTaxRate));//ccr070615
            ApplVar.FiscalHead.TaxRateP = ApplVar.FiscalHead.MaxP;//ccr070615

            ApplVar.FiscalHead.MaxP += FISRECORDLEN;

            ApplVar.FisNumber.TotalTaxChangeNum++;
    //ccr070615		memset(&ApplVar.FiscalBuff.Fis_TaxRate,0,sizeof(ApplVar.FiscalBuff.Fis_TaxRate));
            sLastZ = (FISMEMERYSIZE-ApplVar.FiscalHead.MaxP)/FISRECORDLEN;
            if (!sLastZ )        /* only less then 60  reports left ? */
                ApplVar.ErrorNumber=ERROR_ID(CWXXI86);       /* memory broken */
            else if (sLastZ <= FISRECORD_LESS)
                ApplVar.ErrorNumber=ERROR_ID(CWXXI77) ;

        }
        else
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI76);     /* write fiscal date error */
            return;//ccr070610
        }

        if (!sSaveFM)
        {

            Print_NonFiscal(1);
            PrintLine('-');
            Print_FiscalData(FISTAXLOG,false);//ccr2017-12-20
#if (1)//ccr2017-12-20>>>>>>>>>>>>>
            PrintStr_ULong(VATCHANGES,ApplVar.FisNumber.TotalTaxChangeNum,0);
            //ccr2018-03-20 PrintLine('-');
            PrintStr_ULong(VATCHANGESCAN,FTAXCHGMAX-ApplVar.FisNumber.TotalTaxChangeNum,0);
#else
            sVal = ZERO;//ccr071212
            WORDtoBCD(sVal.Value,ApplVar.FisNumber.TotalTaxChangeNum);
            FormatQtyStr(Msg[CHANGETAX].str,&sVal,PRTLEN-5);
            SysBuf[PRTLEN-5]=' ';   SysBuf[PRTLEN-4]='/';
            WORDtoASC(SysBuf+PRTLEN-1,FTAXCHGMAX);
            SysBuf[PRTLEN]=0;
            RJPrint(0,SysBuf);
#endif//ccr2017-12-20<<<<<<<<<<<<<<<<<
            PrintLine('=');
            Print_NonFiscal(0);
            RFeed(PREHEADER+2);
        }
    }
}
////////////////////////////////////////////////////////
#if DD_FISPRINTER == 0
//ccr2014-PANAMA>>>>
/* return:length of input */
BYTE GetUserOpt(BYTE type, char *opt,BYTE  size)
{
	int	sLp,sP;
	BYTE  sByte,sLen=0;

	MemSet(ProgLineMes, sizeof(ProgLineMes), ' ');
#if (DISP2LINES)
	MemSet(ProgLine1Mes,sizeof(ProgLine1Mes),' ');
#endif

    if (size)
    {
        if (Appl_EntryCounter)
        {
            GetCaption(opt, size);
            if (Appl_EntryCounter<size)
                opt[Appl_EntryCounter]=0;
            SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
        }

        if (Appl_ProgStart == 2)
            sP = 0;
        else
        {
            sP = strlen(USERPROMPT[type].str);//lCAPWIDTH;
            CopyFrStr(ProgLineMes, USERPROMPT[type].str);
        }
        for (sLp=0;sLp<Appl_EntryCounter;sLp++)
        {
            sByte =opt[sLp];

#if (DISP2LINES)
            ProgLine1Mes[sLp] = sByte;
#else
            ProgLineMes[sP++] = sByte;
#endif
            if (sByte==0)
                break;
            if (sByte!=' ')
                sLen = sLp+1;
        }
        if (Appl_EntryCounter==0)
        {//��ʾ��ǰ���뷽��
            if (BIT(ApplVar.ArrowsAlfa, NUMRIC09))//��ǰ��ʽΪ�������뷽ʽ
                ProgLineMes[DISLEN-1]='9';
            else if (BIT(ApplVar.ArrowsAlfa, UPPERASCII))//��ǰ��ʽΪA
                ProgLineMes[DISLEN-1]='A';
            else//��ǰ��ʽΪa
                ProgLineMes[DISLEN-1]='a';
        }
        if (Appl_ProgStart == 2)
            return sLen;
    }
    Appl_ProgLine++;
    return sLen;
}
/*
#define cFCNameID   0	//1-�˿�����
#define cFCRUCID	1	//2-�˿�RUC,
#define cFCDebitID  2	//3-�����վݺ�
#define cFCAddrID   3	//4-�˿͵�ַ
#define cFVatNoID   4   //5-��������վݵĹ˿�˰����
*/
void ProgUserInfo(int type)
{
    char sInput;
    int sSize;

    switch (type)
    {
    case cFCNameID:
        sSize=sizeof(ApplVar.UserInfo.FCName)-1;
        memset(ApplVar.UserInfo.FCName,0,sizeof(ApplVar.UserInfo.FCName));
        sInput=('*');
        break;
    case cFCAddrID:
        sSize=sizeof(ApplVar.UserInfo.FCAddr)-1;
        memset(ApplVar.UserInfo.FCAddr,0,sizeof(ApplVar.UserInfo.FCAddr));
        sInput=('*');
        break;
    case cFCRUCID:
        sSize=sizeof(ApplVar.UserInfo.FCRUC)-1;
        memset(ApplVar.UserInfo.FCRUC,0,sizeof(ApplVar.UserInfo.FCRUC));
        sInput=('*');
        break;
    case cFVatNoID:
        sSize=sizeof(ApplVar.UserInfo.FVatNo)-1;
        memset(ApplVar.UserInfo.FVatNo,0,sizeof(ApplVar.UserInfo.FVatNo));
        sInput=('9');
        break;
    case cFCDebitID:
        sSize=sizeof(ApplVar.UserInfo.FCDebit)-1;
        memset(ApplVar.UserInfo.FCDebit,0,sizeof(ApplVar.UserInfo.FCDebit));
        sInput=('9');
        break;
    default:
        return;
    }
    if (GetStrFromKBD(sInput,(char*)USERPROMPT[type].str,NULL,sSize,0,NO)>0)
    {
        ApplVar.UserInfo.InputType |= 1<<type;//����������
        switch (type)
        {
        case cFCNameID:
            memcpy(ApplVar.UserInfo.FCName,&AtEntryBuffer(Appl_EntryCounter),Appl_EntryCounter);
            break;
        case cFCAddrID:
            memcpy(ApplVar.UserInfo.FCAddr,&AtEntryBuffer(Appl_EntryCounter),Appl_EntryCounter);
            break;
        case cFCRUCID:
            memcpy(ApplVar.UserInfo.FCRUC,&AtEntryBuffer(Appl_EntryCounter),Appl_EntryCounter);
            break;
        case cFVatNoID:
            memcpy(ApplVar.UserInfo.FVatNo,&AtEntryBuffer(Appl_EntryCounter),Appl_EntryCounter);
            break;
        case cFCDebitID:
            memcpy(ApplVar.UserInfo.FCDebit,&AtEntryBuffer(Appl_EntryCounter),Appl_EntryCounter);
            break;
        default:
            return;
        }
    }
    SetInputMode(0);
    ClearEntry();
    PutsPre(0,ModeHead,((ApplVar.CentralLock==RG)||(ApplVar.CentralLock==MG))?(0):('>'));
}
/*ccr2014-PANAMA>>>>��ӡ����Ĺ˿���Ϣ
#define cFCName   BIT0	//1-�˿�����
#define cFCRUC	  BIT1	//2-�˿�RUC,
#define cFCDebit  BIT3	//3-�����վݺ�
#define cFCAddr   BIT4	//4-�˿͵�ַ
#define cFVatNo   BIT5   //5-��������վݵĹ˿�˰����
*/
void   PrintUserInput()
{
    int i;
    if (ApplVar.UserInfo.InputType)//������ʱ,�Ŵ�ӡ
    {
        RJPrint(0,MESG_CUSTOMER);
        if (BIT(ApplVar.UserInfo.InputType,cFCName))
        {//��ӡ�����û�RUC������
            memset(SysBuf,0,PRTLEN);

            i = strlen(USERPROMPT[cFCNameID].str);
            CopyFrStr(SysBuf,USERPROMPT[cFCNameID].str);
            strncpy(SysBuf+i, ApplVar.UserInfo.FCName,PRTLEN-i);
            SysBuf[PRTLEN] = 0;
            RJPrint(0,SysBuf);
            //RESETBIT(ApplVar.UserInfo.InputType,cFCName);
        }
        if (BIT(ApplVar.UserInfo.InputType,cFCRUC))
        {//��ӡ�����û�RUC������
            memset(SysBuf,0,PRTLEN);

            i = strlen(USERPROMPT[cFCRUCID].str);
            CopyFrStr(SysBuf,USERPROMPT[cFCRUCID].str);
            strncpy(SysBuf+i, ApplVar.UserInfo.FCRUC,PRTLEN-i);
            SysBuf[PRTLEN] = 0;
            RJPrint(0,SysBuf);
            //RESETBIT(ApplVar.UserInfo.InputType,cFCRUC);
        }
        if (BIT(ApplVar.UserInfo.InputType,cFCDebit))
        {//��ӡ�����û�RUC������
            memset(SysBuf,0,PRTLEN);

            i = strlen(USERPROMPT[cFCDebitID].str);
            CopyFrStr(SysBuf,USERPROMPT[cFCDebitID].str);
            strncpy(SysBuf+i, ApplVar.UserInfo.FCDebit,PRTLEN-i);
            SysBuf[PRTLEN] = 0;
            RJPrint(0,SysBuf);
            //RESETBIT(ApplVar.UserInfo.InputType,cFCDebit);
        }
        if (BIT(ApplVar.UserInfo.InputType,cFCAddr))
        {//��ӡ�����û�RUC������
            memset(SysBuf,0,PRTLEN);

            i = strlen(USERPROMPT[cFCAddrID].str);
            CopyFrStr(SysBuf,USERPROMPT[cFCAddrID].str);
            strncpy(SysBuf+i, ApplVar.UserInfo.FCAddr,PRTLEN-i);
            SysBuf[PRTLEN] = 0;
            RJPrint(0,SysBuf);
            //RESETBIT(ApplVar.UserInfo.InputType,cFCAddr);
        }
        if (BIT(ApplVar.UserInfo.InputType,cFVatNo))
        {//��ӡ�����û�RUC������
            memset(SysBuf,0,PRTLEN);

            i = strlen(USERPROMPT[cFVatNoID].str);
            CopyFrStr(SysBuf,USERPROMPT[cFVatNoID].str);
            strncpy(SysBuf+i, ApplVar.UserInfo.FVatNo,PRTLEN-i);
            SysBuf[PRTLEN] = 0;
            RJPrint(0,SysBuf);
            //RESETBIT(ApplVar.UserInfo.InputType,cFVatNo);
        }
        PrintLine('-');
    }
}
//<<<<PANAMA
/*---------------------------------------------------------------------
˰�س�ʼ��:����˰������,��LogDefine.idxֻ�ǵ�ǰ�����ĸ�����
RETURN:=true,��ʼ���ɹ�;=false,��ʼ��ʧ��
---------------------------------------------------------------------*/
BYTE Initial_Fiscal()
{
    UnLong sAddr;
    int   i;
    short inputLen;

    ApplVar.FuncOnEnter == FUNC800;
    ApplVar.ErrorNumber = 0;
    memset((char *)&LogDefine,0,sizeof(LogDefine));
    memset((char *)&ApplVar.Fis_Header,0,sizeof(ApplVar.Fis_Header));
    memset((char *)&ApplVar.FisNumber,0,sizeof(ApplVar.FisNumber));

    inputLen=GetStrFromKBD('9',(char*)Msg[TAXCODE].str,NULL,MAX_FISCAL_CODE,0,NO);
    if (inputLen!=MAX_FISCAL_CODE)
    {//����Ϊ8λ����
        memset(ApplVar.Fis_Header.FFisCode, 0, sizeof(ApplVar.Fis_Header.FFisCode));
        if (inputLen>0)
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
        ClearEntry();
        return false;
    }
    memset(ApplVar.Fis_Header.FFisCode, ' ', sizeof(ApplVar.Fis_Header.FFisCode));
    memcpy(ApplVar.Fis_Header.FFisCode, &AtEntryBuffer(MAX_FISCAL_CODE),MAX_FISCAL_CODE);
    memset(ApplVar.Fis_Header.FRelease,' ',sizeof(ApplVar.Fis_Header.FRelease));
    memcpy(ApplVar.Fis_Header.FRelease,Release,strlen(Release));
#if (RIFMUST)//>>>>>>>��ʾ����˰��ʶ����RIF
    if ((inputlen=GetStrFromKBD('9',(char*)Msg[RIFCODE].str,NULL,RIFMAX,0,NO))!=RIFMAX)
    {//����Ϊ8λ����
        if (inputLen>0)
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
        ClearEntry();
        return false;
    }

    memcpy(ApplVar.Fis_Header.FRIFNumber,&AtEntryBuffer(RIFMAX), RIFMAX);//����ʱ,��ǰ�油'0' //
#endif
    //��������
    DateForDisplay(0,DISLEN);
    inputLen=GetStrFromKBD('9',(char*)Msg[RIQI].str,SysBuf,8,0,NO);
    if (inputLen>0 && EXCEPTBIT(inputLen,NEWSTRING)!=8)
    {//����Ϊ8λ����
        ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
        ClearEntry();
        return false;
    }
    if (BIT(inputLen,BIT14))
    {
        NewTimeDate(0x11);//��EntryBuff�л����������ڴ���Now
        if (ApplVar.ErrorNumber)
        {
            ClearEntry();
            return false;
        }
    }
    ApplVar.Fis_Header.FInitDate[2] = Now.day;          // DD //
    ApplVar.Fis_Header.FInitDate[1] = Now.month;        // MM //
    ApplVar.Fis_Header.FInitDate[0] = (Now.year & 0xff);    // YY //
    //����ʱ��
    sAddr = (((UnLong)Now.hour)<<16) +  //YY
            ((UnLong)Now.min<<8) +      //MM
            ((UnLong)Now.sec);      //DD
    memset(SysBuf,' ',DISLEN);
    HEXtoASC(SysBuf+DISLEN-6,(char*)(&sAddr),3);
    SysBuf[DISLEN] = 0;
    inputLen=GetStrFromKBD('9',(char*)Msg[SHIJIAN].str,SysBuf,6,0,NO);
    if (inputLen>0 && EXCEPTBIT(inputLen,NEWSTRING)!=6)
    {//����Ϊ8λ����
        ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
        ClearEntry();
        return false;
    }
        if (BIT(inputLen,BIT14))
        {
            SetDateFlg = 2;
            NewTimeDate(0x12);//��EntryBuff�л�������ʱ�����Now
            SetDateFlg = 0;
            if (ApplVar.ErrorNumber)
            {
                ClearEntry();
                return false;
            }
            ApplVar.Fis_Header.FInitDate[3] = ApplVar.Entry.Value[2];   /* HH */
            ApplVar.Fis_Header.FInitDate[4] = ApplVar.Entry.Value[1];   /* MM */
            ApplVar.Fis_Header.FInitDate[5] = ApplVar.Entry.Value[0];   /* SS */
        }
        else
        {
            ApplVar.Fis_Header.FInitDate[3] = Now.hour; /* HH */
            ApplVar.Fis_Header.FInitDate[4] = Now.min;  /* MM */
            ApplVar.Fis_Header.FInitDate[5] = Now.sec;  /* SS */
        }
        SetDateFlg = 2;
        Now.year = 0x2000+ApplVar.Fis_Header.FInitDate[0];
        Now.month= ApplVar.Fis_Header.FInitDate[1];
        Now.day= ApplVar.Fis_Header.FInitDate[2];

        SetTimeDate(&Now);
        SetDateFlg = 0;

        ApplVar.FisNumber.FiscalDate = EncordBCDDate(ApplVar.Fis_Header.FInitDate[0],
                                                        ApplVar.Fis_Header.FInitDate[1],
                                                        ApplVar.Fis_Header.FInitDate[2]);//ccr070531
        ApplVar.LastInvoiceDate = ApplVar.FisNumber.LastZDate = ApplVar.FisNumber.FiscalDate;//ccr070531
        memcpy(ApplVar.LastInvoiceTime,ApplVar.Fis_Header.FInitDate+3,3);
        LogDefine.idx++;

        ClearEntry();
        ClearLine2();

        Appl_MaxEntry = 6;
#ifdef CASE_FATFS_EJ
        ApplVar.ContFlag = 0;
#endif

        //��ӡ���������Ϣ,ȷ�����������Ϣ
        PrintMessagesBy((char*)Msg[TAXCODE].str,(char*)ApplVar.Fis_Header.FFisCode,MAX_FISCAL_CODE);

#if (RIFMUST)//>>>>>>>��ʾ����˰��ʶ����RIF
        PrintMessagesBy((char*)Msg[RIFCODE].str,(char*)ApplVar.Fis_Header.FRIFNumber,RIFMAX);
#endif
        memset(SysBuf,' ',sizeof(SysBuf));
        DateTimeToStr(SysBuf,3);
        SysBuf[22] = 0;
        PrintMessagesBy((char*)Msg[RIQI].str,SysBuf,22);

        RFeed(5);

        PutsO(DMes[ItemDMes24]);//confirm

        while (1)
        {
           SetLoop();
           FM_EJ_Exist();
           if (KbHit())
           {
               i = Getch();
               if (i==FEEDKey)
               {
                   RFeed(1);
               }
               else if (i == ENTERKey && !ApplVar.FTrain)
               {//ȷ�ϳ�ʼ������
                   break;
               }
               else
               {//ȡ��˰�س�ʼ��,��ѵģʽʱ,��������˰�س�ʼ����Ϣ,���ǲ�����˰�س�ʼ��
                   ApplVar.FuncOnEnter = 0;
                   memset(ApplVar.Fis_Header.FFisCode, 0, sizeof(ApplVar.Fis_Header.FFisCode));
                   ApplVar.FiscalFlags = FMISNEW;
                   CheckFisError();
                   ResetLoop();
                   return false;
               }
           }
        }
        ResetLoop();


//								memset(sVal1.Value,0,sizeof(BCD));
        ApplVar.Fis_Header.FFlag = FMINITEDFLAG;

        if (!ApplVar.FTrain)    /* not in trainning mode */
        {

            if (!Write_FiscalRam(FISECRIDADDR + sizeof(ApplVar.Fis_Header.FFirst) +
                                sizeof(ApplVar.Fis_Header.FPFirst),
                                ApplVar.Fis_Header.FRelease,
                                sizeof(ApplVar.Fis_Header) - sizeof(ApplVar.Fis_Header.FFirst) - sizeof(ApplVar.Fis_Header.FPFirst)))//ccr070531
            {
                ApplVar.FiscalFlags = FMERROR;  //20070302 FISINVALID;

                memset(ApplVar.Fis_Header.FFisCode, 0, sizeof(ApplVar.Fis_Header.FFisCode));
#if (RIFMUST)
                memset(ApplVar.Fis_Header.FRIFNumber, 0, sizeof(ApplVar.Fis_Header.FRIFNumber));
#endif
                ApplVar.FuncOnEnter = 0; // liuj 0605
                CheckFisError();
                return false;
            }

//FLASH_ApplRAM					ClearAllReport();		/* Clear ApplVar.Report. */
            ApplVar.FiscalFlags = FISCALOK;
            ApplVar.FMPullOut[NOFM_FLAG] = 0;
            ApplVar.ZReport = 1 ;// ccr090507 ��ʾ�����ӡZ���� //
            //init ApplVar.FiscalHead
            memset(&ApplVar.FiscalHead, 0, sizeof(ApplVar.FiscalHead));
            ApplVar.FiscalHead.MaxP = FISDATAADDR;
            ApplVar.FiscalHead.EJTblP = FISEJADDR;

            ApplVar.ZCount[FISCALZNUM]= ApplVar.ZCount[TRAINZNUM]=1;//ccr091027
            ApplVar.FisNumber.TotalClearNum = 1; //ccr070531 !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!liuj 0526
#if defined(CASE_GREECE)//ccr2018-01-08�����վݼ���SHA1ǩ��
            memset(ApplVar.ASEDLastD,0,SHA1HashSize);
            memset(ApplVar.ASEDLastC,0,SHA1HashSize);
#endif
        }

        Bell(2);
        ApplVar.FStatus = 1;
        //ccr2017-04-25AddReceiptNumber();
        SetApprovCode();//ccr2017-05-04

        ApplVar.PrintLayOut = 0x03;
        PrintLine('=');
        RJPrint(0,Msg[SHKCSHUA].str);
        memset(SysBuf, ' ', sizeof(SysBuf));
        CopyFrStr(SysBuf, Msg[TAXCODE].str);
        strcpy(SysBuf+PRTLEN-strlen(ApplVar.Fis_Header.FFisCode), ApplVar.Fis_Header.FFisCode);
        SysBuf[PRTLEN] = 0;
        RJPrint(0, SysBuf);
#if (RIFMUST)
//liuj 0531 PM
        memset(SysBuf, ' ', sizeof(SysBuf));
        CopyFrStr(SysBuf, Msg[RIFCODE].str);
        strcpy(SysBuf+PRTLEN-strlen(ApplVar.Fis_Header.FRIFNumber), ApplVar.Fis_Header.FRIFNumber);
        SysBuf[PRTLEN] = 0;
        RJPrint(0, SysBuf);
//liuj 0531 PM
#endif

        /*if(!ApplVar.FTrain)	// not in trainning mode //
        {
            memset(ApplVar.Fis_Header.FFisCode, 0, sizeof(ApplVar.Fis_Header.FFisCode));
        }*/

        PrintRegiInfo(false);
        PrintLine('=');
        RFeed(1);

        Appl_ProgLine = 0;
        ApplVar.FExento = ZERO;     /*    clear daily itemizers     */
        ApplVar.FTotal = ZERO;      /*    ApplVar.FNetTotal is soft total and cleared at start of report     */
        ApplVar.TotalMax = ZERO;


        memset(&ApplVar.FTaxSum,0,sizeof(ApplVar.FTaxSum));//    ccr070615

        MemSet(ApplVar.CurrentTaxRate,0,sizeof(ApplVar.CurrentTaxRate));
        ApplVar.FMPullOut[NEWTAX_FLAG]=0x69;
        Fiscal_AddTaxRateChg(true);
#if (NAMEMUST || ADDRESSMUST)
        ApplVar.FMPullOut[NEWHEAD_FLAG]=0x69;
        Fiscal_AddHeaderChg(false);//Ʊͷ���ݴ���FM
#endif
        ClearAllReport();//ccr2018-01-24
        ApplVar.FuncOnEnter = 0;
#ifdef CASE_FATFS_EJ
        CheckEJ(true);//Ϊ˰�س�ʼ����,���EJ��;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI97); //liuj 0531 PM
#endif
        SetInputMode(0);
        ApplVar.FStatus = 0;
        ApplVar.FuncOnEnter = 0;
        PutsO(Msg[SHKCSHUA].str);
        return true;
}
#endif
#endif

void CheckFisError()
{
    if (!Bios_FM_CheckPresence())
        ApplVar.FiscalFlags = NOFM;
    else if (ApplVar.FiscalFlags==FISCALOK)
        return;
    if (!ApplVar.ErrorNumber)
    {
        switch (ApplVar.FiscalFlags)
        {
        case MUSTFORMATSD:		// 3: MUST FORMAT SD
            ApplVar.ErrorNumber=ERROR_ID(CWXXI89);
            break;
        case NOFM:      //  4: no Card //
            ApplVar.ErrorNumber =  ERROR_ID(CWXXI74);
            break;
        case BADFM:     //  5: invalid Card //
            ApplVar.ErrorNumber =  ERROR_ID(CWXXI76);
            break;
        case FMFULL:        //  6: fm  full
            ApplVar.ErrorNumber =  ERROR_ID(CWXXI86);
            break;
        case FMMACFULL:     //  7: mac > 200
            ApplVar.ErrorNumber =  ERROR_ID(CWXXI91);
            break;
        case FMERROR:   //  8: data error
            ApplVar.ErrorNumber =  ERROR_ID(CWXXI78);
            break;
        case CHECKSUMCHANGED:
            ApplVar.ErrorNumber = ERROR_ID(CWXXI92);//ERROR_ID(CWXXI92)
            break;
        case FM_X_ECR:
            ApplVar.ErrorNumber = ERROR_ID(CWXXI93);//ERROR_ID(CWXXI93)
            break;
        case FM_X_EJ:
            ApplVar.ErrorNumber = ERROR_ID(CWXXI98);//ERROR_ID(CWXXI98)
            break;
        //     case MUSTINITFM:
        case FMISNEW:
            ApplVar.ErrorNumber = ERROR_ID(CWXXI94);//ERROR_ID(CWXXI94)
            break;
        case BADEJ:
            ApplVar.ErrorNumber = ERROR_ID(CWXXI84);
            break;
        case EJFULL :
            ApplVar.ErrorNumber = ERROR_ID(CWXXI88) ;
            break;
        case MUSTINITEJ :
            ApplVar.ErrorNumber = ERROR_ID(CWXXI97);//ERROR_ID(CWXXI97)
            break;
        case NOEJ:
            ApplVar.ErrorNumber = ERROR_ID(CWXXI83);
            break;
        case EJLESS:
            ApplVar.ErrorNumber = ERROR_ID(CWXXI87);
            ApplVar.FiscalFlags = FISCALOK;
            break;
        case FMLESS://ccr091104
            ApplVar.ErrorNumber = ERROR_ID(CWXXI77);
            ApplVar.FiscalFlags = FISCALOK;
            break;
        default:
            //ApplVar.ErrorNumber |= ApplVar.FiscalFlags;//ERROR_ID(CWXXI99)
            break;
        }
    }
}
//ccr20131106>>>>>>>>>>>>>>>>>>>>>>>>>>
//------�����տ���Ƿ���˰������״̬-----------
//���տ��˰�س�ʼ��֮��,�տ���ʹ���˰������״̬
BYTE CheckInFiscalMode()
{
    return  (ApplVar.FiscalFlags == FISCALOK ||     //�տ��˰������״̬
             ApplVar.FiscalFlags == FMLESS ||       //�տ����˰�ش洢������
             ApplVar.FiscalFlags == FMMACFULL ||    //�տ���ļӵ��ʼ��������
             ApplVar.FiscalFlags == FMFULL ||       //�տ����˰�ش洢����
             ApplVar.FiscalFlags == EJFULL ||       //�տ����EJ��
             ApplVar.FiscalFlags == EJLESS);        //�տ����EJ����
}
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
void ProcessFiscalCmd(void)
{
}
//ccr2017-05-04>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
//Get the index of clerk and convert it into ascii string for print.
//to���ֽ�������>=PRTLEN
void GetReceiptTotalNumber(char *to)
{
#if defined(CASE_EURO)//ccr2014-09-15>>>>>>>>>
    //��ӡZ������,Fiscal/None Fiscal�վݺŴ�1��ʼ
    memset(to,' ',PRTLEN);
    if ( ApplVar.FTrain )
    {
        CopyFrStr(to,MESG_TRAINRECNoT);
        ULongtoASC(to+PRTLEN-1,ApplVar.FisNumber.TotalReceiptNum[TRECEIPTS]);
    }
    else if (!ApplVar.FStatus || ApplVar.FInv)
    {
        CopyFrStr(to,MESG_NONEFISRECEIPT);
        ULongtoASC(to+PRTLEN-1,ApplVar.FisNumber.TotalReceiptNum[NRECEIPTS]);
    }
    else
    {
        CopyFrStr(to,MESG_RECEIPTSUMNo);
        ULongtoASC(to+PRTLEN-1,ApplVar.FisNumber.TotalReceiptNum[FRECEIPTS]);
    }
    to[PRTLEN]=0;
#endif//ccr2014-09-15<<<<<<<
}
/**
 * ����Approv code + ˰����,�11���ַ�
 *
 * @author EutronSoftware (2017-05-04)
 */
void SetApprovCode()
{
    int l;

    strcpy(ApplVar.ApprovalCode,APPRCODE);
    l=strlen(ApplVar.Fis_Header.FFisCode);
    if (l>8) l=8;
    memcpy(ApplVar.ApprovalCode+3,ApplVar.Fis_Header.FFisCode,l);
    ApplVar.ApprovalCode[11]=0;
}

/***************************************************************************
 * ����Z���뷶Χ��ȡ��ӡZ��������
 *
 * @author EutronSoftware (2017-06-06)
 ***************************************************************************/
void PrintFMZByZ_Z()
{
    ULONG pMax;
    BYTE sTotal;


    switch(ListItems(zFMREADZ_Z,0,Msg[zFMREADZ_Z].str,false,true))
    {
    case (fmSYNOPSIS-fmSYNOPSIS+1):       //������˰��������
        sTotal=BIT7+PRINTFMZ_Z;
        break;
    case (fmANALYTICAL-fmSYNOPSIS+1):    //������˰��ϸ����
        sTotal=PRINTFMZ_Z;
        break;
//    case It_EXIT:
    default:
        EXIT;
        return;
    }

    pMax = ApplVar.ZCount[FISCALZNUM];
    if (pMax >0 )
    {
        pMax--;//ccr2018-01-05
        if (InputFromTo(RECEIPTFROM,pMax)!=EXITKey)
        {
#if (defined(CASE_GREECE))//ϣ���ڽ��ǰ����ӡŷԪ����
            Prefix1 = Prefix2 = 0;
#endif
            Read_FiscalData(sTotal,FISCLEARLOG);
#if (defined(CASE_GREECE))//ϣ���ڽ��ǰ����ӡŷԪ����
            Prefix1 = PREFIX_1;
            Prefix2 = PREFIX_2;
#endif
        }
        else
            EXIT;
    }
}

/***************************************************************************
 * ����Z���ڷ�Χ��ȡ��ӡZ��������
 *
 * @author EutronSoftware (2017-06-06)
 *
 * @param zType:FM�е���������(FISCLEARLOG,FISRESETLOG...
 ***************************************************************************/
void PrintFMZByDate(BYTE zType)
{
    ULONG pMax;
    BYTE sTotal;

    if (zType==FISCLEARLOG)
    {
        switch(ListItems(zFMREADZ_Z,0,Msg[zFMREADDATE].str,false,true))
        {
        case (fmSYNOPSIS-fmSYNOPSIS+1):       //������˰��������
            sTotal=BIT7+PRINTFMDATE;
            break;
        case (fmANALYTICAL-fmSYNOPSIS+1):    //������˰��ϸ����
            sTotal=PRINTFMDATE;
            break;
//        case It_EXIT:
        default:
            EXIT;
            return;
        }
    }
    else
        sTotal=PRINTFMDATE;

    pMax = BCDtoDEC(Now.year>>8)*1000000 + DateToYYMMDD();
    if (InputFromTo(DATEFROM,pMax)!=EXITKey)
    {
#if (defined(CASE_GREECE))//ϣ���ڽ��ǰ����ӡŷԪ����
        Prefix1 = Prefix2 = 0;
#endif

        Read_FiscalData(sTotal,zType);

#if (defined(CASE_GREECE))//ϣ���ڽ��ǰ����ӡŷԪ����
        Prefix1 = PREFIX_1;
        Prefix2 = PREFIX_2;
#endif
    }
    else
        EXIT;

}

/**
 * �����ÿ����ƴ�ӡ���һ��Z����,ֱ�Ӵ�Z�����ļ��и��ƴ�ӡ����
 *
 * @author EutronSoftware (2017-06-12)
 */
void CopyPrintLastZ()
{
     WORD sYear;
     int bw;
     BYTE sMonth,sDay;
    char sFileName[_MAX_PATH];

    if (ApplVar.FiscalHead.ClearP)
    {//��Z������Ҫ��ӡ.�����µ�Z�й��ļ��к��ļ�
        if (!Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,ApplVar.FiscalHead.ClearP,FISRECORDLEN))
        {
            ApplVar.FiscalFlags = FMERROR; ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
            return ;
        }
        //����0269170320/TLD66000003/1703200269/0001/_z.txt�ļ�
#if defined(TWO_SDCARDS)
        ff_MountSDisk(FS_SD_2ND);
#else
        ff_MountSDisk(FS_SD);
#endif
        sFileName[0]=ApplVar.FS_Current+'0';sFileName[1]=':';
        DecordDate(ApplVar.FiscalBuff.Fis_ClearRecord.FZDateFrom,&sYear,&sMonth,&sDay);
        sYear &= 0xff;

        sprintf(sFileName+2,"/%04d%02x%02x%02x/%s/%02x%02x%02x%04d/%04d/_z.txt",
                                ApplVar.FiscalBuff.Fis_ClearRecord.FCount,
                                sYear,sMonth,sDay,
                                ApplVar.ApprovalCode,
                                sYear,sMonth,sDay,
                                ApplVar.FiscalBuff.Fis_ClearRecord.FCount,
                                ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice[FRECEIPTS]+1);
        if (ff_OpenFileQ(sFileName,FA_READ | FA_TEXT)==FR_OK)
        {
#if defined(CASE_ITALIA)
            Print_NonFiscal(1);
#endif
            RJPrint(0,MSG_COPYZSTART);
            while (!ff_EofFile())
            {
                bw=ff_ReadFile(SDRW_Buffer, 50,FS_TEXT);
                if (bw>0)
                {
                    (bw>PRTLEN)?(bw=PRTLEN):(SDRW_Buffer[bw]==0x0a?(bw--):(bw=bw));
                    SDRW_Buffer[bw]=0;

                    RJPrint(0,SDRW_Buffer);
                }
            }
            ff_CloseFile();
            RJPrint(0,MSG_COPYZEND);
#if defined(CASE_ITALIA)
            Print_NonFiscal(0);
#endif
            RFeed(PREHEADER+2);//��ֽ��˺ֽλ��
        }
        ff_MountSDisk(FS_RELEASE);

    }
}

/*******************************************************************************
 * �����ÿ���ɾ��60��ǰ�ĸ�������,60��ʵ��Ϊ������,�������һ��Z��������������
 * ��Ҫɾ�������ļ���:
 * 1.GGPS\TLD66000003\0269(=ZNUMBER)
 * 2.0269170320(0269��Ӧ������)
 * @author EutronSoftware (2017-06-12)
 ******************************************************************************/
//#define DAYSBEFOR   60
void DeleteSDBefor60Days(int DAYSBEFOR)
{
#if defined(TWO_SDCARDS)
     WORD sYear,sDate;
     BYTE sMonth,sDay;
     ULONG sFMOffset;
     BYTE sYesToAll=false;
     char sFileName[_MAX_PATH];
#if !defined(DEBUGBYPC)
     DIR DirInf;
#endif

     if  (ApplVar.FisNumber.TotalClearNum<DAYSBEFOR || ApplVar.FiscalHead.ClearP<DAYSBEFOR*FISRECORDLEN+FISDATAADDR)
         return;//û�г���DAYSBEFOR��ļ�¼

    sYear=ApplVar.ZDate/10000;    sMonth=(ApplVar.ZDate/100)%100;    sDay=ApplVar.ZDate%100;
    if (sMonth<=2)
    {
        sMonth=sMonth+12-2;
        sYear--;
    }
    else
        sMonth-=2;
    sDate=EncordDECDDate(sYear,sMonth,sDay);
    ff_MountSDisk(FS_SD_2ND);
    sFMOffset= ApplVar.FiscalHead.ClearP-DAYSBEFOR*FISRECORDLEN;//ֱ��ָ��DAYSBEFOR��ǰ�ļ�¼
    for (;sFMOffset>=FISDATAADDR;sFMOffset-=FISRECORDLEN)
    {
        if (!Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,sFMOffset,FISRECORDLEN))
        {
            ApplVar.FiscalFlags = FMERROR; ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
            break ;
        }
        if (ApplVar.FiscalBuff.Fis_ClearRecord.FunN==FISCLEARLOG && ApplVar.FiscalBuff.Fis_ClearRecord.FZDateFrom<=sDate)
        {//Z���ݷ�����������

            sFileName[0]=ApplVar.FS_Current+'0';sFileName[1]=':';
            DecordDate(ApplVar.FiscalBuff.Fis_ClearRecord.FZDateFrom,&sYear,&sMonth,&sDay);
            sYear&=0xff;
            //ɾ��1.GGPS\TLD66000003\0269
#if defined(CASE_GREECE)//ccr2018-01-11Ҫǩ��,�����ļ�
            sprintf(sFileName+2,"/GGPS/%s/%04d",ApplVar.ApprovalCode,ApplVar.FiscalBuff.Fis_ClearRecord.FCount);
#else
            sprintf(sFileName+2,"/%04d%02x%02x%02x",ApplVar.FiscalBuff.Fis_ClearRecord.FCount,sYear,sMonth,sDay);
#endif

#if !defined(DEBUGBYPC)
            if (f_opendir(&DirInf,sFileName)!=FR_NO_PATH)
#else
            if (f_opendir(sFileName)!=FR_NO_PATH)
#endif
            {
                ff_DeleteTree(sFileName);
#if defined(CASE_GREECE)//ccr2018-01-08
                //ɾ��2.0269170320
                sprintf(sFileName+2,"/%04d%02x%02x%02x",ApplVar.FiscalBuff.Fis_ClearRecord.FCount,sYear,sMonth,sDay);
                ff_DeleteTree(sFileName);
#endif
            }
            else if (!sYesToAll)//û�д��ļ���,˵���Ѿ���ɾ����,������ǰ����
            {
                PutsO((char*)MsgZ60DELETED);
                if (WaitForYesNo(MsgCONTINUEDEL,0,1,0)=='Y')
                {
                    sYesToAll=true;
                    PutsO((char*)MsgDELZBEFOR60ING);
                    PutsM(Msg[WAITING].str);//��ʾ�ȴ�
                }
                else
                    break;
            }
        }
    }
    ff_SDiskSpace();
    ff_MountSDisk(FS_RELEASE);
#endif
}
/***************************************************************************************
 * ��������ʱ���޸�����
 *
 * @author EutronSoftware (2017-08-08)
 *
 * @param sSaveFM :=0,���������;=1,���������ں����FM;=2,ͬʱ�����¾����ں����FM
 ***************************************************************************************/
void Fiscal_AddDatetimeChg(BYTE sSaveFM)
{

    UnLong sLastZ;

    if (!Fiscal_CheckNumber(ApplVar.FisNumber.TotalDateChangeNum , FDATECHGMAX))
       return;

    //if (ApplVar.FiscalFlags == FISCALOK)
    {
        if (sSaveFM==0 || sSaveFM==2)
        {
            //Date
            SetFis_DateTime(true);
            DateTimeToStr(ApplVar.FiscalBuff.Fis_DateTime.FDateTimeOld,3);//ccr2017-08-07
        }
        if (sSaveFM)
        {
            DateTimeToStr(ApplVar.FiscalBuff.Fis_DateTime.FDateTimeNew,3);//ccr2017-08-07

            //change count
            ApplVar.FiscalBuff.Fis_DateTime.FChgCount = ApplVar.FisNumber.TotalDateChangeNum + 1;

            //CRC
            ApplVar.FiscalBuff.Fis_DateTime.FCRC = VerifyCRC((BYTE *)&ApplVar.FiscalBuff.Fis_DateTime,FISRECORDLEN,1);

            //Func Num = 0xa3
            ApplVar.FiscalBuff.Fis_DateTime.FunN = FISDATECHGLOG;

            if (Write_FiscalRam(ApplVar.FiscalHead.MaxP,&ApplVar.FiscalBuff.Fis_DateTime,FISRECORDLEN))
            {
                ApplVar.FiscalHead.DateTimeP = ApplVar.FiscalHead.MaxP;//ccr070615

                ApplVar.FiscalHead.MaxP += FISRECORDLEN;

                ApplVar.FisNumber.TotalDateChangeNum++;

                sLastZ = (FISMEMERYSIZE-ApplVar.FiscalHead.MaxP)/FISRECORDLEN;
                if (!sLastZ )        /* only less then 60  reports left ? */
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI86);       /* memory broken */
                else if (sLastZ <= FISRECORD_LESS)
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI77) ;
            }
            else
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI76);     /* write fiscal date error */
                return;//ccr070610
            }
        }
    }
}

/***********************************************
 * ����24Сʱ�����ӡZ������־ZReport=2
 *
 * @author EutronSoftware (2017-12-18)
 **********************************************/
void SetZReportMust()
{
    if ((ApplVar.FiscalFlags == FISCALOK || ApplVar.FiscalFlags == FMLESS || ApplVar.FiscalFlags == EJLESS)
        && ApplVar.ZReport != 1)// ZReport=0,�������µ�Z��������; =1,�Ѵ�ӡZ����; =2,3,�����ӡZ���� //
    {
            ApplVar.ZReport = 3;//2;    /* �����,���ñ����ӡZ������־ */
            //ccr2017-12-27 ApplVar.ErrorNumber=ERROR_ID(CWXXI75);       /* first take fiscal Z-ApplVar.Report */
    }
}

/****************************************************************************
 *  ���ú���:Ϊ˰�ؼ�¼�����������ں�ʱ��
 *
 * @author EutronSoftware (2018-03-29)
 *
 * @param zeroFisBuff :=true,��FiscalBuff��0;=false,����0
 *****************************************************************************/
void SetFis_DateTime(BYTE zeroFisBuff)
{
     if (zeroFisBuff)
         memset(&ApplVar.FiscalBuff.Fis_ClearRecord,0,FISRECORDLEN);//ccr2017-02-23
     GetTimeDate(&Now);
     ApplVar.FiscalBuff.Fis_ClearRecord.FDate = EncordBCDDate(Now.year & 0x00ff,Now.month,Now.day);
     //time
     ApplVar.FiscalBuff.Fis_ClearRecord.FTime[0] = Now.hour;
     ApplVar.FiscalBuff.Fis_ClearRecord.FTime[1] = Now.min;
     ApplVar.FiscalBuff.Fis_ClearRecord.FTime[2] = Now.sec;
}


#if (CC_DEBUG) //ccr2018-03-26>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
/*************************************************************
 * ���FM�д洢�����ݵ���ȷ��
 *
 * @author EutronSoftware (2018-03-26)
 *
 * @return short
 ************************************************************/
void Check_FiscalData()
{
    int   i;
    BYTE    bCRC;
    BYTE    sActive,sTotal,sExit,sZOnly;
    BYTE    sSend;
    UnLong  sAddr;
    WORD    sDate;
    WORD    sYear;
    BYTE    sMonth,sDay;

    sStartZ  = sEndZ = 0;

    if (ApplVar.FiscalHead.MaxP <= FISDATAADDR)
        return ;

    sAddr = FISDATAADDR;
    PutsO(Msg[WAITING].str);
    while (sAddr < ApplVar.FiscalHead.MaxP && !KbHit() && !sExit)
    {
        if (KbHit() && Getch()==CLEARKey)//CLEAR any key for stop
            break;
        if (sAddr+FISRECORDLEN>FISMEMERYSIZE)
        {//ccr20130314
            ApplVar.ErrorNumber=ERROR_ID(CWXXI86);
            CheckError(0);
            return ;
        }
        else  if (!Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,sAddr,FISRECORDLEN))
        {//ccr070719>>>>>>>>>
            ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
            CheckError(0);
            sprintf(SysBuf,"\nFM-READ ERROR AT:%08x\n",sAddr);
            SendString(SysBuf,strlen(SysBuf));
            SendString((char*)&ApplVar.FiscalBuff.Fis_ClearRecord,FISRECORDLEN);
            return ;
        }//<<<<<<<<<<<<<<<<<<<<<<<<
        bCRC = VerifyCRC((BYTE *)&ApplVar.FiscalBuff.Fis_ClearRecord,FISRECORDLEN,1);
        if (bCRC!= ApplVar.FiscalBuff.Fis_ClearRecord.FCRC )//(BYTE *)&ApplVar.FiscalBuff,FISRECORDLEN,1
        {//���ݳ�����.
            sTotal = false;
            ApplVar.ErrorNumber=ERROR_ID(CWXXI82);
            CheckError(0);
            sprintf(SysBuf,"\nFM(%02x)-CRC(%02x) ERROR AT:%08x",(ApplVar.FiscalBuff.Fis_ClearRecord.FunN & 0xff), (bCRC & 0xff),sAddr);
            SendString(SysBuf,strlen(SysBuf));
            switch (ApplVar.FiscalBuff.Fis_ClearRecord.FunN)
            {
            case FISCLEARLOG:
               SendString("-Z DATA\n",-1);break;
            case FISRESETLOG:
               SendString("-MAC RESET\n",-1);break;
            case FISDISCONNECTLOG://ccr071212
               SendString("-PULL FM\n",-1);break;
            case FISHEADCHGLOG:
               SendString("-NEW HEAD\n",-1);break;
            case FISTAXLOG:
               SendString("-NEW TAX\n",-1);break;
            case FISDATECHGLOG://ccr2017-08-08
               SendString("-NEW DATE\n",-1);break;
            default:
               SendString("-OUT\n",-1);break;
            }
            SendString((char*)&ApplVar.FiscalBuff.Fis_ClearRecord,FISRECORDLEN);
            if (ApplVar.FiscalBuff.Fis_ClearRecord.FDate==0xffff || ApplVar.FiscalBuff.Fis_ClearRecord.FDate==0)
               break;  //return 0;
        }

        sActive = true;//ccr100329
        sDate = ApplVar.FiscalBuff.Fis_ClearRecord.FDate;
        switch (ApplVar.FiscalBuff.Fis_ClearRecord.FunN)
        {
        case FISCLEARLOG:
           SendString("FM-Z DATA",-1);break;
        case FISRESETLOG:
           SendString("FM-MAC RESET",-1);break;
        case FISHEADCHGLOG:
           SendString("FM-NEW HEAD",-1);break;
        case FISTAXLOG:
           SendString("FM-NEW TAX",-1);break;
        case FISDISCONNECTLOG://ccr071212
           SendString("FM-PULL OUT",-1);break;
        case FISDATECHGLOG://ccr2017-08-08
           SendString("FM-NEW DATE",-1);break;
        default:
           SendString("FM-OUT OF RANGE\n",-1);
           sActive = false;//ccr100329
           break;
        }
        if (sActive)
        {
           DecordDate(sDate,&sYear,&sMonth,&sDay);
           sprintf(SysBuf," %04x-%02x-%02x %02x:%02x:%02x\n",sYear,sMonth,sDay,
                                                             ApplVar.FiscalBuff.Fis_ClearRecord.FTime[0],
                                                             ApplVar.FiscalBuff.Fis_ClearRecord.FTime[1],
                                                             ApplVar.FiscalBuff.Fis_ClearRecord.FTime[2]);
           SendString(SysBuf,-1);
        }
        else
        {
           sprintf(SysBuf," AT %08x\n",sAddr);
           SendString(SysBuf,-1);
           break;
        }
        sAddr+=FISRECORDLEN;
    }
}
#endif//ccr2018-03-26<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

