#include "King.h"
#include "Exth.h"
#include "Exthead.h"
#include "string.h"

#if(defined(CASE_ETHERNET))
#include "EthernetApp.h"

///////////////////////////////////////////////////////////////////////////////
#if !defined(DEBUGBYPC)
#define DEBUGETHERNET    //ccr2015-08-21�������ݷ�����ȷ��
#endif

#include "message.h"

#if defined(DEBUGETHERNET)
#define ETHERNETECHO_SEND(a) UARTSend(LOGIC_COM1,a)//��ETHERNET�ķ������ݴӴ���1����
#define ETHERNETECHO_RECEIVED(a) UARTSend(LOGIC_COM2,a)//��ETHERNET��ͨ�յ����ݴӴ���1����
#else
#define ETHERNETECHO_SEND(a) {}//��ETHERNET�ķ������ݴӴ���1����
#define ETHERNETECHO_RECEIVED(a) {}//��ETHERNET���յ����ݴӴ���1����
#endif

#define MAXLOGPACKAGE      //ccr2015-08-25����ˮ�������������ʽ����
#define ETHERNETWAITACK     //ccr2015-08-25����������ʱ,�ȴ����ݷ������
///////////////////////////////////////////////////////////////////////////////

unsigned long ETHERNET_Wait=0;//ccr2015-03-11��һ�γ���ETHERNETͨѶ��ʱ��

int PackageReceived=0;

BYTE ETHERNET_Ready=0;//������ʾETHERNETģ���״̬

#if defined(ACK_MUST)
BYTE ETHERNET_WaitACK=0;
#endif


//---------------------------------------------------------------------------
#define WAITFORTYPE 0//�ȴ���������:'F'-Ϊ��ˮ,'U'Ϊ����
#define WAITFORSIZE 1
#define WAITFORDATA 2


/**
 *  @author EutronSoftware (2014-12-06)
 * ���յ��������н���һ��ECR�ļ�����,�����������EcrRecordָ���Ĵ洢��
 *  data��¼��ʽ:[Type]+[size]+[data],  sizeΪdata���ֽ���
 *
 * @param command:��Ҫ����������('U'...);=0ʱ,��ʼ��
 *        data:�յ�������,data[0]Ϊ����,data[1]Ϊsize,data[2..3]Ϊ��������(������)
 *        size:�����յ������ݳ���
 *
 * @return
 *         WORD:=0xffffʱ,����������;=0ʱ,���ݽ���;����ֵ:Ϊ�յ������ݶ�Ӧ�Ĺ�����
 *         EcrRecord[0]+EcrRecord[1]:��Ź�����
 *         EcrRecord+2:Ϊ��Ӧ�����������
 */
#define EcrRecord PCBuffer

WORD ETHERNETDecodeECRRecord(BYTE command,BYTE data,BYTE *size)
{
    //Variable for ETHERNETGetECRARecord
    static BYTE ETHERNET_Command;//�յ�����������;'F','U','D'....
    static BYTE ETHERNET_SizeMust;//������ȡ��������Ŀ
    static int ETHERNET_BytesReceived;//��¼�Ѿ��յ���������Ŀ
    static BYTE ETHERNET_WaitFor=WAITFORTYPE;//=0,��ʾ�ȴ���������;=1��ʾ�ȴ������ֽ�;=2��ʾ�ȴ�����

    int i;

    if (command==0)
    {//initial
        ETHERNET_WaitFor=WAITFORTYPE;
        ETHERNET_BytesReceived=0;
    }
    else
    {
        switch (ETHERNET_WaitFor)
        {
        case WAITFORTYPE://�ȴ���������
           if (data=='U')//Ϊ������ˮ�������ļ�����
           {
               ETHERNET_Command = 'U';
               ETHERNET_WaitFor = WAITFORSIZE;
               ETHERNET_BytesReceived = 0;
           }
           break;
       case WAITFORSIZE://�ȴ����ݳ���,�256�ֽ�
           //if (data<=sizeof(union ECRFILEREC))
           {//Ϊ�ļ�����
                ETHERNET_SizeMust = data;
                ETHERNET_BytesReceived = 0;
                ETHERNET_WaitFor = WAITFORDATA;
           }
           //else//���ļ�����
           //  ETHERNET_WaitFor = WAITFORTYPE;
           break;
       case WAITFORDATA://�ȴ���ȡ����
           EcrRecord[ETHERNET_BytesReceived++]=data;
           if (ETHERNET_BytesReceived==ETHERNET_SizeMust)
           {//��ȡ��һ�����������ݰ�
               PackageReceived++;
               ETHERNET_WaitFor = WAITFORTYPE;

               if (ETHERNET_Command=='U')
               {//������ȡ���
                   if (CWORD(EcrRecord[0])==0)
                       return 0;
                   else// if (CWORD(EcrRecord[0])>CLERK && CWORD(EcrRecord[0])<PLU3 || CWORD(EcrRecord[0])>=RHEAD1 && CWORD(EcrRecord[0])<=RTRAIL2)
                   {
                       if (size)
                           *size = ETHERNET_SizeMust;
                       return CWORD(EcrRecord[0]);
                   }
               }
               else
                   return 0xffff;//������һ��������
           }
           break;
       }
       return 0xffff;//������һ��������
    }
}

//------------------------------------------------------------
#define WAITFOR_IPDATA  0
#define WAITFOR_LENGTH  1
#define WAITFOR_QUOTES  2
#define WAITFOR_DATA    3
#define ENDOF_READ      4
/**
 * �Ӵ��ڶ�ȡETHERNET���ص����� %IPDATA,xx,"12345678",[0d][0a]
 *
 * @author EutronSoftware (2014-12-08)
 *
 * @param pBuff :��ȡ�����ݴ����;=0ʱ,��ʼ��ETHERNETRead_IPDATA
 * @param size :��ͼ��ȡ���ֽ���Ŀ
 *
 * @return short :��ȡ���ֽ���Ŀ;=0ʱ,��ʱ;=-1ʱ,�������ݴ�
 */
short ETHERNETRead_IPDATA(char *pBuff,short size,ULONG sWaitFor)
{

    short dataLength,ch;
    char getIPDATA[16];

    short Read_MAX;//ETHERNETģ���յ���������Ŀ

    BYTE sByte,Read_CR;
    BYTE sBit=0;
    BYTE Read_WaitFor=0xff;// =0 ��������ͷ "%IPDATA", =1 �������ݳ���; =2,3 �������� //

    if (pBuff!=0 && size!=0)
    {
        dataLength= 0;
        SetTimerDelay0(sWaitFor);
        while (GetTimerDelay0())
        {
            ch = ReadComm(ETHERNETPORT);
            if (ch!=-1)
            {
                ETHERNETECHO_RECEIVED(ch);//testonly
                switch (Read_WaitFor)
                {
                case WAITFOR_IPDATA:
                    getIPDATA[dataLength++]=ch;
                    if (ch==':')
                    {
                        getIPDATA[dataLength]=0;
                        if (strcmp(getIPDATA,"%IPDATA:")==0)//	change by lqw %IPDATA->%IPDATA:
                        {
                            sBit = 0;
                            Read_WaitFor = WAITFOR_LENGTH;
                            dataLength= Read_MAX = 0;
                        }
                        else
                            return -1;// ���ص����ݳ��� //
                    }
                    else if (dataLength>8)
                        return -1;// ���ص����ݳ��� //
                    break;
                case WAITFOR_LENGTH:
                    if (ch==',')
                        Read_WaitFor = WAITFOR_QUOTES;
                    else if (ch>='0' && ch<='9')
                        Read_MAX = Read_MAX*10 + (ch & 0x0f);// ��ȡ���ݳ��� //
                    break;
                case WAITFOR_QUOTES:
                    if (ch=='"')
                    {
                        dataLength = 0;
                        Read_WaitFor = WAITFOR_DATA;
                        sBit = 0;
                    }
                    break;
                case WAITFOR_DATA:
                    if (ch=='"')
                        Read_WaitFor = ENDOF_READ;
                    else
                    {
                        if (sBit)
                        {
                            if (dataLength<size)
                                pBuff[dataLength++] = (sByte<<4)+ASC_2_HEX(ch);
                            //if (dataLength>=Read_MAX) return dataLength;// �����д� //
                        }
                        else
                            sByte = ASC_2_HEX(ch);

                        sBit ^= 1;
                    }
                    break;
                case ENDOF_READ://ccr2016-10-25>>>>>>>>>>
                    //�ȴ��س�+����
                    if (ch=='\r')
                        Read_CR = '\r';
                    else //if (ch=='\n')
                        return dataLength;
                    break;
                default:
                    if (ch=='%')
                    {//�Ѿ���ȡ%IPDATA���ȫ������
                        Read_WaitFor=WAITFOR_IPDATA;// =0 ��������ͷ "%IPDATA", =1 �������ݳ���; =2,3 �������� //
                        dataLength= 0;
                        getIPDATA[dataLength++]=ch;
                    }
                    break;
                }
                SetTimerDelay0(sWaitFor);
            }
        }
        return dataLength;
    }
    else
        return 0;
}

/**
 * ͨ��ETHERNET��AT%IPSEND������TCP/IP��ʽ��buffer�е����ݷ��ͳ�ȥ
 * �ڵ���ETHERNETSendECRData֮ǰ,Ҫ��StartGprs����TCP/IP
 * ����ETHERNETSendECRData֮��,��EndGprs�ر�TCP/IP
 *
 * @author EutronSoftware (2014-11-28)
 *
 * @param buffer
 * @param len :Bytes in buffer must be send
 *
 * @return int :0=false,else return length
 */
int ETHERNETSendECRData(BYTE *buffer,int len)
{
#define WAITSEND    RETRYTIMES*20

    char readETHERNET[32];
    int i,l,reTry,mul;

    if (len)
    {//������ʱ�ŷ���
        EmptyComm(ETHERNETPORT);
        ETHERNETSendAString(ATIPSEND,strlen(ATIPSEND));//"AT%IPSEND=",���ݷ�������
        ETHERNETSendByte('"');//���ݿ鿪ʼ

        for (i=0;i<len;i++)
            ETHERNETSendHEX(buffer[i]);//��������

        ETHERNETSendByte('"');//���ݿ����
        ETHERNETSendByte('\r');//�������

#if !defined(ETHERNETWAITACK)
        reTry=0;
        do {
#endif
            if (!ETHERNETSkipReceived(SECONDS(120))) //skip '\r\n'
                return false;

            if ((i=ETHERNETReadAString(readETHERNET,sizeof(readETHERNET),SECONDS(180)))<=0) // read "%IPSEND 1,13"
                return false;
            readETHERNET[7]=0;

            if (!ETHERNETHand(readETHERNET,"%IPSEND"))
                return false;// û���յ� "%IPSEND"

            l=0;mul=1;
            i--;
            for (;i>0 && readETHERNET[i]!=',';i--)
            {//��ȡETHERNETģ�鷢������ʣ��ռ�����
                if (readETHERNET[i]>='0' && readETHERNET[i]<='9')
                {
                    l += ((readETHERNET[i] & 0x0f)*mul);
                    mul *= 10;
                }
            }
#if !defined(ETHERNETWAITACK)
            if (reTry>0)//��ʾִ�е���"AT%IPSEND?"��ѯ
            {
                if(!ETHERNETSkipReceived(SECONDS(120)))	// SKIP one blank line.. add by lqw..090825
                    return FALSE;	// FOR GTM900B ,it will be opened..
            }
#endif
            if (ETHERNETReadAString(readETHERNET,sizeof(readETHERNET),SECONDS(180))<=0// read "OK"
                 || (CWORD(readETHERNET[0])!=RET_OK))
                    return false;//û���յ� "OK"
#if defined(ETHERNETWAITACK)
            if (l<=1 && !ETHERNETCheckACK(0))//ccr2015-08-25
                return false;
#else
            if (l<=1)//��������
            {//��ѯ������
                Delay(300);
                strcpy(readETHERNET,ATIPSEND);
                readETHERNET[9]='?';
                readETHERNET[10]='\r';
                ETHERNETSendAString(readETHERNET,11);//"AT%IPSEND?"��ѯ
                mDrawETHERNET(0,1,0);//ccr2015-08-24�����Ͻ���˸��ʾ��ʾ
            }
            reTry++;
        } while (l<=1 && reTry<WAITSEND);
        if (reTry>=WAITSEND)
        {
            return false;
        }
        else
#endif
            return len;
    }
    else
    {
        return true;
    }
}

/**
 * ������ˮ���ͷ�ʽ
 *
 * @author EutronSoftware (2014-12-01)
 */
void ETHERNET_SetSendMode()
{
    BYTE y;
    short si;
    WORD saveNumber;

    // ���÷��������վݵķ��Ͳ���
    //mClearScreen();
    y = WaitForYesNo(SENDLOGAUTO,0,0,TESTBIT(ApplVar.DaysMust,BIT7));
    if (y!=0)
    {
        if (y=='Y')
            SETBIT(ApplVar.DaysMust,BIT7);//Ϊ�Զ�������ˮ�������ʺ�����������ˮ
        else
            RESETBIT(ApplVar.DaysMust,BIT7);//���Զ�������ˮ����Ҫ�ֹ�����������ˮ����
#if defined(CASE_INDONESIA)
        y = 1;
        if (!TESTBIT(ApplVar.DaysMust,BIT7))
        {//���Զ�������ˮ״̬�£���ָ���ļ�������ڣ����뷢����ˮ����
            DisplayDecXY(ApplVar.DaysMust,DAYSFORLOG,y);
            si = GetStrFromKBD('9',NULL,NULL,2,0,NO);
            if (si<0)
            {
                ClearEntry();
                return;
            }
            else if (si>0)
            {
                ApplVar.DaysMust = ((EntryBuffer[ENTRYSIZE-3] & 0x0f)*10 + (EntryBuffer[ENTRYSIZE-2] & 0x0f)) & 0x7f;
            }
            y++;
        }
#endif
#if defined(ACK_MUST)
        y = WaitForYesNo(ACKMUSTNEED,0,1,ETHERNET_ACK_MUST);
        if (y=='Y')
            SETBIT(APPLCTRL,BIT2);      //ETHERNET�������ͨ��ʱ,��Ҫ����ACKӦ��
        else if (y=='N')
            RESETBIT(APPLCTRL,BIT2);    //ETHERNET�������ͨ��ʱ,��Ҫ����ACKӦ��
        SETBIT(ApplVar.MyFlags,CONFIGECR);
#endif
    }
    ClearEntry();
}

/**
 * ����һ�����ض������ݵķ�ʽ�ӷ�������������,�ٶȿ�,��������
 * �ӷ�����������codePLU1ָ�����տ���ļ�����
 * countPLUΪ��Ҫ���صļ�¼��
 * @author EutronSoftware (2014-12-06)
 *
 * @param typeName :������������
 * @param codePLU1 :�����������ʹ���(PLU1,DEPT,CLERK...),
 * @param countPLU :��¼��,ʵ�ʿ����ص���Ŀ����<countPLU
 *
 * ����codePLU1=0xffff,countPLU=0:����ȫ������
 *
 */

void ETHERNETDownloadEcrPLUData(const char *typeName,WORD codePLU1,WORD countPLU,ULONG sWaitFor)
{

    WORD received=0;//ͳ���յ���¼��Ŀ
    WORD ECRFunc,FuncNum;
    WORD cECRFunc0=0,cECRFunc1=0xffff;//����������ʾ
    BYTE decodeLen;

    short chReceived;//ͳ���Ѿ��յ����ֽ�����
    short ch;
    char getIPDATA[18];

    WORD Read_MAX;//ETHERNETģ���յ���������Ŀ
    BYTE sByte;
    BYTE sBit=0;
    BYTE Read_WaitFor=0xff;// =0 ��������ͷ "%IPDATA", =1 �������ݳ���; =2,3 �������� //


    if (TESTBIT(ETHERNET_Ready,ETHERNET_OK_BIT) && GetSystemTimer()>ETHERNET_Wait)
    {
        if (countPLU>0 || codePLU1==0xffff)//ccr2016-08-23
        {
            if (ETHERNETStartGprs())
            {
                memset(SysBuf,' ',SCREENWD);
                CopyFrStr(SysBuf,typeName);
                if (codePLU1!=0xffff)
                    WORDtoASC(SysBuf+SCREENWD-1,countPLU);
                SysBuf[SCREENWD]=0;
                DispStrXY(SysBuf,0,1);
                {
                    getIPDATA[0]='D';//������������
                    getIPDATA[1]=6;//size
                    CWORD(getIPDATA[2])=codePLU1+1;//ccr2016-08-18codePLU1=0xffffʱ,��ӽ��=0,����ȫ������
                    CWORD(getIPDATA[4])=codePLU1+countPLU;//Ĭ�������տ�������ɵĵ�Ʒ����
                    getIPDATA[6]=REGISTER;//�տ�����
                    getIPDATA[7]=LOCATION;//�տ���̵���
                    memcpy(&getIPDATA[8],ApplVar.AP.NetWork.ECR_ID,sizeof(ApplVar.AP.NetWork.ECR_ID));
                    if (ETHERNETSendECRData(getIPDATA,6+2+sizeof(ApplVar.AP.NetWork.ECR_ID)))//������������.
                    {

                        ETHERNETDecodeECRRecord(0,0,0);//initial ETHERNETGetECRARecord

                        ECRFunc= 0xffff;
                        chReceived=0;
                        SetTimerDelay0(sWaitFor);
                        while (GetTimerDelay0() && ECRFunc)
                        {
                            if(KbHit() && (Getch() == EXITKey))//ccr2016-08-26
                                    break;
                            ch = ReadComm(ETHERNETPORT);//��ȡ�ӷ��������ص�����
                            if (ch!=-1)//������
                            {
                                ETHERNETECHO_RECEIVED(ch);//testonly
                                switch (Read_WaitFor)
                                {
                                case WAITFOR_IPDATA:
                                    getIPDATA[chReceived++]=ch;
                                    if (ch==':')
                                    {
                                        getIPDATA[chReceived]=0;
                                        if (strcmp(getIPDATA,"%IPDATA:")==0)//	change by lqw %IPDATA->%IPDATA:
                                        {
                                            sBit = 0;
                                            Read_WaitFor = WAITFOR_LENGTH;
                                            chReceived= Read_MAX = 0;
                                        }
                                        else
                                        {
                                            DispStrXY(ETHERNETMess[G_xDATATYPE].str,0,1);//���ݴ�
                                            ECRFunc = 0;// ���ص����ݳ��� //
                                        }
                                    }
                                    else if (chReceived>8)
                                    {
                                        DispStrXY(ETHERNETMess[G_xDATATYPE].str,0,1);//���ݴ�
                                        ECRFunc = 0;// ���ص����ݳ��� //
                                    }
                                    break;
                                case WAITFOR_LENGTH:
                                    if (ch==',')
                                        Read_WaitFor = WAITFOR_QUOTES;
                                    else if (ch>='0' && ch<='9')
                                        Read_MAX = Read_MAX*10 + (ch & 0x0f);// ��ȡ���ݳ��� //
                                    break;
                                case WAITFOR_QUOTES:
                                    if (ch=='"')
                                    {//���ݿ�ʼ
                                        Read_WaitFor = WAITFOR_DATA;
                                        sBit = 0;
#if defined(ACK_MUST)
                                        ETHERNET_WaitACK=0;
#endif
                                    }
                                    break;
                                case WAITFOR_DATA:
                                    if (ch=='"')//���ݽ���
                                        Read_WaitFor = ENDOF_READ;
                                    else
                                    {
                                        if (sBit)
                                        {//�յ�һ���������ֽ�
                                            chReceived++;
                                            //if (chReceived>=Read_MAX)  return ;// �����д� //

                                            ECRFunc = ETHERNETDecodeECRRecord('U',(sByte<<4)+ASC_2_HEX(ch),&decodeLen);
                                            //�洢���ص�����>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                                            if (ECRFunc!=0xffff && ECRFunc!=0)//if (ECRFunc==0) //�վ���ȡ���
                                            {//���յ�������д���տ���ļ���

                                                if (ETHERNET_ProcessRecord('U',EcrRecord,decodeLen))
                                                {
                                                    received++;
                                                    memset(SysBuf,' ',SCREENWD);
                                                    if (ECRFunc==ADDPLU)
                                                        SysBuf[0]='+';
                                                    else if(ECRFunc==DELPLU)
                                                        SysBuf[0]='-';
                                                    if (SysBuf[0]!=' ')
                                                    {
                                                        SysBuf[1]='P';SysBuf[2]='L';SysBuf[3]='U';
                                                        if (cECRFunc0 && cECRFunc0!=ECRFunc)
                                                        {
                                                            cECRFunc0=ECRFunc;
                                                        }
                                                    }
                                                    else if (codePLU1==0xffff)
                                                    {
                                                        cECRFunc0=ECRFuncCodeToTypeName(ECRFunc,SysBuf);
                                                        if (cECRFunc0!=cECRFunc1)
                                                        {//Ϊ�µĹ�������

                                                            received=1;
                                                            cECRFunc1=cECRFunc0;
                                                        }
                                                        if (cECRFunc0)//�й�������
                                                            SysBuf[strlen(SysBuf)]=' ';
                                                        else
                                                            WORDtoASCL(SysBuf,ECRFunc);
                                                    }
                                                    WORDtoASC(SysBuf+SCREENWD-1,received);
                                                    SysBuf[SCREENWD]=0;
                                                    DispStrXY(SysBuf,0,1);//��ʾ���յ���������Ŀ
                                                }
                                                else
                                                {
                                                    DispStrXY(ETHERNETMess[G_xDATATYPE].str,0,1);//���ݴ�
                                                }
                                            }//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                                        }
                                        else
                                            sByte = ASC_2_HEX(ch);

                                        sBit ^= 1;
                                    }
                                    break;
                                case ENDOF_READ://ccr2016-10-25>>>>>>>>>>
                                    //�ȴ��س�+����
                                    //DispStrXY("END.",0,5);//testonly
#if defined(ACK_MUST)
                                    if (ETHERNET_ACK_MUST && ETHERNET_WaitACK)
                                    {
                                        //����ACKӦ��
                                        sByte=ACK;
                                        if ( (!ETHERNETSendECRData(&sByte,1)//��Ҫ�����ؽ���Ӧ��
#if defined(ETHERNETWAITACK)
                            //ccr2016-08-11    || !ETHERNETCheckACK(0)//�ȴ�������Ӧ��
#endif
                                            ))
                                        {//����ʧ��ʱ
                                            //DispStrXY("Send ACK error",0,1);//testonly
                                        }
                                        ETHERNET_WaitACK=false;
                                    }
#endif
                                    if (ch=='\r')
                                        break;
                                    else// if (ch=='\n')
                                    {//�Ѿ���ȡ%IPDATA���ȫ������
                                        Read_WaitFor=0xff;
                                    }
                                    //ccr2016-10-25<<<<<<<<
                                default:
                                    if (ch=='%')//ccr2016-10-25 || ch=='\r' || ch=='\n')
                                    {//�Ѿ���ȡ%IPDATA���ȫ������
                                        Read_WaitFor=WAITFOR_IPDATA;// =0 ��������ͷ "%IPDATA", =1 �������ݳ���; =2,3 �������� //
                                        chReceived= Read_MAX = 0;
                                        //ccr2016-10-25if (ch=='%')
                                            getIPDATA[chReceived++]=ch;
                                    }
                                    break;
                                }
                                SetTimerDelay0(sWaitFor);

                            }
                        }//While
                        if (!GetTimerDelay0())
                        {
                            DispStrXY(ETHERNETMess[G_JIESHOUSHIBAI].str,0,1);//��ʱ��
                        }
                    }
                    else
                    {
                        DispStrXY(ETHERNETMess[G_FASONGSHIBAI].str,0,1);
                    }
                }
                CloseETHERNET();
            }
        }
	}
	else
	{
		//mClearScreen();
        PutsO(ETHERNETMess[G_WAITFOR].str);//RG-DISPLAY
	}
	PRESS_ANY_KEY(1);

}

/**
 * //"���ص�Ʒ�ļ�"
 *
 * @author EutronSoftware (2014-12-06)
 */
void ETHERNET_DownloadPLU()
{
    ETHERNETDownloadEcrPLUData(Msg[net_UpdatePLU].str,PLU1,ApplVar.AP.Plu.Number,SECONDS(30));
}
/**
 * //"���ز����ļ�"
 *
 * @author EutronSoftware (2014-12-06)
 */
void ETHERNET_DownloadDEPT()
{
    ETHERNETDownloadEcrPLUData(Msg[net_UpdateDEPT].str,DEPT,ApplVar.AP.Dept.Number,SECONDS(30));
}
/**
 * //"�����տ�Ա"
 *
 * @author EutronSoftware (2014-12-06)
 */
void ETHERNET_DownloadCLERK()
{
    ETHERNETDownloadEcrPLUData(Msg[net_UpdateCLERK].str,CLERK,ApplVar.AP.Clerk.Number,SECONDS(30));
}
/**
 * //"����Ʊͷ"
 *
 * @author EutronSoftware (2014-12-06)
 */
void ETHERNET_DownloadHEAD()
{
    //Ϊӭ��ETHERNETDownloadEcrPLUData�е�CWORD(getIPDATA[2])=codePLU1+1
    //����ʹ��RHEAD1-1��Ϊ����Ʊͷ����
    ETHERNETDownloadEcrPLUData(Msg[net_UpdateHEAD].str,RHEAD1-1,2,SECONDS(30));
}
/**
 * //"����Ʊβ"
 *
 * @author EutronSoftware (2014-12-06)
 */
void ETHERNET_DownloadPTRAIL()
{
    //Ϊӭ��ETHERNETDownloadEcrPLUData�е�CWORD(getIPDATA[2])=codePLU1+1
    //����ʹ��RTRAIL1-1��Ϊ����Ʊβ����
    ETHERNETDownloadEcrPLUData(Msg[net_UpdateTRAIL].str,RTRAIL1-1,2,SECONDS(30));
}

/**
 * //"���ز�����"
 *
 * @author EutronSoftware (2014-12-06)
 */
void ETHERNET_DownloadALL()
{
    //Ϊӭ��ETHERNETDownloadEcrPLUData�е�CWORD(getIPDATA[2])=codePLU1+1
    //����ʹ��RTRAIL1-1��Ϊ����Ʊβ����
    //����0xfff,0:����ȫ������
    ETHERNETDownloadEcrPLUData(Msg[net_UpdateALL].str,0xffff,0,SECONDS(30));
}

/** ccr2015-08-03>>>>>>>>>>>>>>>>>>>>>
 * ͨ��AT%IPSEND �����տ��heartbeat��Ϣ
 * @author EutronSoftware (2015-08-02)
 *  @param force: =0x00���տ������ʱ����Heart-Beat;
 *                =0x01��������Heart-Beat;
 *                =0xff���÷���Heart-Beat���ӳ�ʱ��
 */
void ETHERNETSendECR_HeartBeat(BYTE force)
{
    BYTE HeartBuffer[15];
    static ULONG IDLE_HB;//=GetSystemTimer()+SECONDS(ACTIVE*60);//�ȴ�5����;

    if (force==0xff)
    {//=0xff���÷���Heart-Beat���ӳ�ʱ��
        IDLE_HB=GetSystemTimer()+SECONDS(ACTIVE*60);//�ȴ�5����;
    }
    else if (TESTBIT(ETHERNET_Ready,ETHERNET_OK_BIT) //ETHERNETģ����������
             && TESTBIT(DBLHIPRN,BIT5) //��������Heart-Beat
             && (force || (ACTIVE && GetSystemTimer()>IDLE_HB)))
    {
        if (ETHERNETStartGprs())
        {
            //�����տ�����������ΪHeartBeat��Ϣ
            HeartBuffer[0]='H';
            HeartBuffer[1]=sizeof(ApplVar.AP.NetWork.ECR_ID)+1;
            HeartBuffer[2]=NETIDLOG;
            memcpy(&HeartBuffer[3],ApplVar.AP.NetWork.ECR_ID,sizeof(ApplVar.AP.NetWork.ECR_ID));

            ETHERNETSendECRData(HeartBuffer,sizeof(ApplVar.AP.NetWork.ECR_ID)+3);//����HeartBeat����
            CloseETHERNET();

            IDLE_HB = GetSystemTimer()+SECONDS(ACTIVE*60);//��һ�η���Heart-Beat��ʱ����;
        }
    }
}//<<<<<<<<<<<<<<<<<<<<<<

/**
 * ETHERNET_ProcessRecord ccr2016-08-19
 * �����յ���¼����,
 *
 * @author EutronSoftware (2015-01-27)
 *
 * @param cmd :'U','D','F'
 * @param data :[func]+[data]
 *     data[0]+data[1]:��Ź�����
 *     data+2:Ϊ��Ӧ�����������
 * @param psize :size of data(=data[0]+1)
 *
 * @return BYTE :=true,�յ�һ������;=false,�յ�һ�����������.
 */

BYTE ETHERNET_ProcessRecord(char cmd,BYTE *srvData,BYTE psize)
{
//ccr2016-08-19    static UnLong logFirst=0;

//ccr2016-08-19    char sBuffer[sizeof(union FLOWREC)+5];

    WORD start, end, sMax, id, save, type;
    short size;
    UnLong sAddr;
    char *record;
    BYTE sPC,sBAR,sBAL,sEcrNo,sLocate,sEXTMem;
    BYTE err_state=true;
    char cmdReturn=0;//����ֵ��Ϊ0ʱ,��Ҫ����������Ӧ��.

     mDrawETHERNET(0,1,1);//ccr2015-01-29 testonly

    type = *((WORD *)(srvData));   // type: get the DataType..

    id = 0;
    if (type > CLERK)
        save = ApplVar.ClerkNumber;
    else if (type > SALPER)
        save = ApplVar.SalPerNumber;
    switch (cmd)       /* determine record type */
    {
    case cmdUPDATE://Update the ECR file
//ccr2016-08-19    case cmdDOWNLOAD: //Send ECR file to host
        {
            size = 0;
            record = 0;
            switch (type)
            {
            case PROMO:
                size = sizeof(ApplVar.AP.Promotion);
                record = (char *)&ApplVar.AP.Promotion;
                break;
            case SALPER:
                size = sizeof(ApplVar.AP.SalPer);
                record = (char *)&ApplVar.AP.SalPer;
                break;
            case OPTIONS:
                size = sizeof(ApplVar.AP.Options);
                record = (char *)&ApplVar.AP.Options;
                break;
            case PROGID :  /* program ID data */
                size = sizeof(Release);
                record = (char *)Release;
                break;
            case SYSFLG :  /* system Flags */
                size = sizeof(ApplVar.AP.Flag);
                record = (char *)ApplVar.AP.Flag;
                break;
            case START :  /* start addresses */
                size = sizeof(ApplVar.AP.StartAddress) ;
                record = (char *)ApplVar.AP.StartAddress;
                break;
            case RCONFIG : /* config */
                size = sizeof(ApplVar.AP.Config);
                record = (char *)&ApplVar.AP.Config;
                break;
            case RDAY : /* DAY table */
                size = sizeof(ApplVar.AP.Day);
                record = (char *)&ApplVar.AP.Day;
                break;
            case RMONTH : /* ApplVar.Month table */
                size = sizeof(ApplVar.AP.Month);
                record = (char *)&ApplVar.AP.Month;
                break;
            case RZONE : /* zone table */
                size = sizeof(ApplVar.AP.Zone);
                record = (char *)&ApplVar.AP.Zone;
                break;
            case RTOTAL : /* ApplVar.Total sales */
                size = sizeof(ApplVar.AP.Sales);
                record = (char *)&ApplVar.AP.Sales;
                break;
            case KEY0 :
                size = 64;     /* 64 bytes is 32 keys */
                record = (char *)ApplVar.AP.KeyTable;
                break;
            case KEY32 :
                size = 64;     /* 64 bytes is 32 keys */
                record = (char *)&ApplVar.AP.KeyTable[32];
                break;
    //		case KEY64 :
    //		    size = 64;     /* 64 bytes is 32 keys */
    //			record = (char *)&ApplVar.AP.KeyTable[64];
    //		    break;
    //		case KEY96 :
    //		    size = 64;     /* 64 bytes is 32 keys */
    //			record = (char *)&ApplVar.AP.KeyTable[96];
    //		    break;
            case RREP1 :        /* user report 1,2 & 3 */
                size =  3 * sizeof(struct FIXEDREPORT);
                record = (char *)&ApplVar.AP.ReportList[0];
                break;
            case RREP2 :        /* user report 4,5 & 6 */
                size =  3 * sizeof(struct FIXEDREPORT);
                record = (char *)&ApplVar.AP.ReportList[3];
                break;
            case RREP3 :        /* user report 7,8 & 9 */
                size = 3 * sizeof(struct FIXEDREPORT);
                record = (char *)&ApplVar.AP.ReportList[6];
                break;
#if (salNumber)
			case RREP4 :        /* user report 7,8 & 9 */
				size = 3 * sizeof(struct FIXEDREPORT);
				record = (char *)&ApplVar.AP.ReportList[9];
				break;
			case RREP5 :        /* user report 7,8 & 9 */
				size = 1 * sizeof(struct FIXEDREPORT);
				record = (char *)&ApplVar.AP.ReportList[12];
				break;
#else
            case RREP4 :        /* user report 7,8 & 9 */
                size = 1 * sizeof(struct FIXEDREPORT);
                record = (char *)&ApplVar.AP.ReportList[9];
                break;
#endif

            case REPCAP1 :        /* report types 0 - 6 */
                size = 7 * REPWIDTH;
                record = (char *)ApplVar.TXT.ReportType;
                break;
            case REPCAP2 :        /* report types 7 - 13 */
                size = 7 * REPWIDTH;
                record = (char *)ApplVar.TXT.ReportType[7];
                break;
            case REPCAP3 :        /* messages 14 - 15 */
                size = 2 * REPWIDTH;
                record = (char *)ApplVar.TXT.ReportType[14];
                break;
            case RHEAD1 :       /* receipt header 0 - 4 */
                size = 5 * (PRTLEN+1);
                record = (char *)ApplVar.TXT.Header;
                break;
            case RHEAD2 :       /* receipt header 5 - 7 */
                size = (HEADLINES-5) * (PRTLEN+1);
                record = (char *)ApplVar.TXT.Header[5];
                break;
            case RTRAIL1 :       /* receipt trailer 0 - 4 */
                size = 5 * (PRTLEN+1);
                record = (char *)ApplVar.TXT.Trailer;
                break;
            case RTRAIL2 :       /* receipt trailer 5 - 5 */
                size = 1 * (PRTLEN+1);
                record = (char *)ApplVar.TXT.Trailer[5];
                break;
            case RSLIPH1 :       /* slip header 0 - 2 */
                size = 3 * SHEADWIDTH;
                record = (char *)ApplVar.TXT.SlipHeader;
                break;
            case RSLIPH2 :       /* receipt header 3 - 5 */
                size = 3 * SHEADWIDTH;
                record = (char *)ApplVar.TXT.SlipHeader[3];
                break;

            case FIRM :
                size = sizeof(ApplVar.AP.FirmKeys);
                record = (char *)ApplVar.AP.FirmKeys;
                break;
            case MNGR :
                size = sizeof(ApplVar.AP.Manager);
                record = (char *)ApplVar.AP.Manager;
                break;
            case CORREC :
                size = sizeof(ApplVar.AP.Correc);
                record = (char *)&ApplVar.AP.Correc;
                break;
            case CURR :
                size = sizeof(ApplVar.AP.Curr);
                record = (char *)&ApplVar.AP.Curr;
                break;
            case DISC :
                size = sizeof(ApplVar.AP.Disc);
                record = (char *)&ApplVar.AP.Disc;
                break;
            case DRAW :
                size = sizeof(ApplVar.AP.Draw);
                record = (char *)&ApplVar.AP.Draw;
                break;
            case PBF :
                size = sizeof(ApplVar.AP.Pb);
                record = (char *)&ApplVar.AP.Pb;
                break;
            case PORA :
                size = sizeof(ApplVar.AP.PoRa);
                record = (char *)&ApplVar.AP.PoRa;
                break;
            case TEND :
                size = sizeof(ApplVar.AP.Tend);
                record = (char *)&ApplVar.AP.Tend;
                break;
            case MODI :
                size = sizeof(ApplVar.AP.Modi);
                record = (char *)&ApplVar.AP.Modi;
                break;
            case TAX :
                size = sizeof(ApplVar.AP.Tax);
                record = (char *)&ApplVar.AP.Tax;
                break;
            case CLERK :
                size = sizeof(ApplVar.AP.Clerk);
                record = (char *)&ApplVar.AP.Clerk;
                break;
            case GROUP :
                size = sizeof(ApplVar.AP.Group);
                record = (char *)&ApplVar.AP.Group;
                break;
            case DEPT :
                size = sizeof(ApplVar.AP.Dept);
                record = (char *)&ApplVar.AP.Dept;
                break;
            case PLU1 :
                size = sizeof(ApplVar.AP.Plu);
                record = (char *)&ApplVar.AP.Plu;
                break;
            case OFFER:
                size = sizeof(ApplVar.AP.OFFPrice);
                record = (char *)&ApplVar.AP.OFFPrice;
                break;
            case AGREE :
                size = sizeof(ApplVar.AP.Agree);
                record = (char *)&ApplVar.AP.Agree;
                break;
            case BLOCKIC:       //ccr chipcard
                size = sizeof(ApplVar.AP.ICBlock);
                record = (char *)&ApplVar.AP.ICBlock;
                break;
            case CHIPCARDSET:   //ccr chipcard
                size = sizeof(ApplVar.ICCardSet);
                record = (char *)&ApplVar.ICCardSet;
                break;
            case REMOTESETTIME :
                if (TESTBIT(ApplVar.MyFlags,ZREPORT))   /* z report taken ? */
                {
                    CheckError(ERROR_ID(CWXXI13));
                    type = 0xffff;
                } else
                {
                    ApplVar.ErrorNumber=0;
                    memcpy(&EntryBuffer[ENTRYSIZE - 9],&srvData[-1+3],8);
                    Appl_EntryCounter = 8;
                    NewTimeDate(1);
                    memcpy(&EntryBuffer[ENTRYSIZE - 7],&srvData[-1+11],6);
                    Appl_EntryCounter = 6;
                    NewTimeDate(2);
                    if (ApplVar.ErrorNumber)
                    {
                        CheckError(0);
                        type = 0xffff;
                    }
                    ClearEntry();
                    InActive |= ACTIVE+1;     /* Inactive longer then allowed */
                    CheckTime(false);
                }
                cmdReturn = cmdANSWER;//ccr2016-08-19return tcp_AnswerToHost(tpcb,cmdANSWER,type);
#if defined(ACK_MUST)
                ETHERNET_WaitACK = true;
#endif
                return (cmdReturn);//ccr2016-10-27
            default :
                break;
            }//switch(type)
            if (size)
            {//�����տ������������,��Ʊͷ/Ʊβ/����/ϵͳ������
#if defined(ACK_MUST)
                ETHERNET_WaitACK = true;
#endif
                if (cmd == cmdUPDATE)   /* update */
                {
                    sEcrNo = REGISTER;
                    sLocate = LOCATION;
                    sPC = COMPUTER;
                    sBAR = BARCODE;
                    sBAL = BALANCE;
                    sEXTMem = EXTRAMN;
                    if (type == CHIPCARDSET)
                        sAddr = ApplVar.ICCardSet.PosCode;
                    memcpy(record, &srvData[-1+3], size);//�����ݴ����տ�������ļ���
                    if (type == CHIPCARDSET)
                        ApplVar.ICCardSet.PosCode = sAddr;
                    if (type == SYSFLG)
                    {
                        InitSysFlag();
                        COMPUTER = sPC;
                        BARCODE = sBAR;
                        BALANCE = sBAL;
                        REGISTER = sEcrNo;
                        LOCATION = sLocate;
                        EXTRAMN =  sEXTMem;
                    } else if (type == START)
                    {//���µ�ַ����,�յ��ĵ�ַ����Ϊ��Ե�ַ!!!!
                        ClsXRam();
                        if (ResetStartAddress(true)==false)
                        {
                            Bell(2);
                            PutsO((char*)MsgSPACEOVER);
                            RJPrint(0,MsgSPACEOVER);


                            //���¼����ڴ��п����ɵĵ�Ʒ��Ŀ
                            sAddr = ApplVar.AP.StartAddress[AddrEndP] - ApplVar.SIZE_EXTRAM;

                            sAddr /= pluRecordSize;
                            sAddr++;//Ϊ��Ҫ���ٵĵ�Ʒ��Ŀ
                            sMax = sAddr;
                            sAddr *= pluRecordSize;//�����ٵĵ�Ʒ��ռ�õĿռ�
                            if (sMax<ApplVar.AP.Plu.Number)
                            {
                                ApplVar.AP.Plu.Number -= sMax;
                                if (ApplVar.AP.Plu.RNumber>ApplVar.AP.Plu.Number)
                                    ApplVar.AP.Plu.RNumber = ApplVar.AP.Plu.Number;
                            } else
                            {
                                RJPrint(0,(char*)MsgFATERROR);//"!!!! FAT(PLU) ERROR !!!!"
                                ApplVar.AP.Plu.Number = ApplVar.AP.Plu.RNumber = 0;
                            }

                            for (sMax = AddrPLU+1;sMax<AddrMAX;sMax++)
                                ApplVar.AP.StartAddress[sMax] -= sAddr;


                        }
                        ApplVar.MyFlags = 0;
                        //Save_ApplRam();
                    } else if (type == KEY0 || type == KEY32)
                    {
                        DeptPluKeysCount();

                        FEEDKey = 0xff;
                        CLEARKey = 0xff;
                        LOCKKey = 0xff;

                        for (id=0;id<MAXKEYB;id++)
                        {
                            switch (ApplVar.AP.KeyTable[id])
                            {
                            case JPF:
                            case RPF:
                                FEEDKey = id;
                                break;
                            case CLEAR:
                                CLEARKey = id;
                                break;
                            case MODELOCK:
                                LOCKKey = id;
                                break;
                            }
                        }
                    }
                    cmdReturn = cmdANSWER;//ccr2016-08-19return tcp_AnswerToHost(tpcb,cmdANSWER,type);//Ӧ��host,�������
                }
                //Ϊ'D'����,���������ݷ��͸�����
                if (type == START)//ת��Ϊ��Ե�ַ���͸�����
                    ResetStartAddress(false);
                cmdReturn = cmdANSWER;//ccr2016-08-19err_state = tcp_RecordToHost(tpcb,cmdUPDATE,type,record,size);/* send record */
                if (type == START)//�ָ�Ϊ���Ե�ַ
                {
                    ResetStartAddress(true);
#if(CASE_RAMBILL)
                    Init_Flow();
#endif
                }
                Save_Config(true);//ccr2014-10-30
            } else
            {
                if (type == ADDPLU || type == DELPLU || type == UPDPLU)
                {
                    if (cmd != cmdUPDATE)
                    {
//ccr2016-08-23                        cmdReturn = cmdANSWER;
                        break;
                    }
                    if (ApplVar.AP.Plu.RandomSize && ApplVar.AP.Plu.Number)
                    {
                        ApplVar.Key.Code = 0;   /* suppress repeat */
                        memcpy(&ApplVar.Plu, &srvData[-1+3], sizeof(ApplVar.Plu));
                        ApplVar.PluNumber = GetPluNumber(1, ApplVar.Plu.Random);        /* fill ApplVar.PluNumber with number */
                        switch (type)
                        {
                        case DELPLU:
                            if (ApplVar.PluNumber)
                            {
                                CheckRandomPlu(1, 1);       /* delete plu */
                                SETBIT(ApplVar.MyFlags,CONFIGECR);
                            }
                            break;
                        case ADDPLU:
                            if (!ApplVar.PluNumber)  /* Not Found then move and Add */
                            {
                                CheckRandomPlu(0, 1);//ccr2014-12-10
                                //ccr2014-12-10if (CheckRandomPlu(0, 1))
                                //ccr2014-12-10	ApplVar.PluNumber = GetPluNumber(0, ApplVar.Plu.Random);        /* fill ApplVar.PluNumber with number */
                                SETBIT(ApplVar.MyFlags,CONFIGECR);
                                break;//ccr2014-12-10
                            }
                        case UPDPLU:
                            if (ApplVar.PluNumber)
                            {
                                ApplVar.PluNumber--;
                                WritePlu();
                                SETBIT(ApplVar.MyFlags,CONFIGECR);
                            }
                        default:
                            break;
                        }
                        cmdReturn = cmdDOWNLOAD;//ccr2016-08-19err_state = tcp_AnswerToHost(tpcb,cmdANSWER,type);//Ӧ������,�������ݴ������,����������һ��
                    }
                    break;
                } else if (type > PBTOT)
                {
                    if (cmd == cmdUPDATE)   /* update */
                    {
                        PbTotal(type - PBTOT, 0);
                        if (!(PBINFO & 0x04) && !(PBPRINT & 0x80))       /* open numbers ? */
                            memcpy(ApplVar.PB.Random, &srvData[-1+3], 7);
                        memcpy(ApplVar.PB.Text, &srvData[-1+10], sizeof(ApplVar.PB.Text));
                        PbTotal(type - PBTOT, 3);
                        cmdReturn = cmdDOWNLOAD;//ccr2016-08-19err_state = tcp_AnswerToHost(tpcb,cmdDOWNLOAD,type+1);//Ӧ������,�������ݴ������,����������һ��
                        break;
                    }
                    id = PBTOT + 1;
                    if ((ApplVar.AP.Pb.Random & 0x0f) || ApplVar.AP.Pb.Text)
                        sMax = ApplVar.AP.Pb.NumberOfPb;
                    else
                        sMax = 0;                /* Not active */
                    size = sizeof(ApplVar.PB.Random) + sizeof(ApplVar.PB.Text);
                    record = (char *)ApplVar.PB.Random;
                } else if (type > BLOCKIC)    /* Chipcard for block ? ccr chipcard */
                {
                    if (cmd == cmdUPDATE)   /* update */
                    {
                        ApplVar.ICBlockNumber = type - BLOCKIC - 1;
                        if (ApplVar.ICBlockNumber < ApplVar.AP.ICBlock.Number)
                        {
                            memcpy(&ApplVar.ICBlock, &srvData[-1+3], sizeof(ApplVar.ICBlock));
                            WriteICBlock();
                            cmdReturn = cmdDOWNLOAD; //Ӧ������,�������ݴ������,����������һ��
                        } else
                            cmdReturn = cmdANSWER;
                        break;
                    }
                    id = BLOCKIC + 1;
                    sMax = ApplVar.AP.ICBlock.Number;
                    size = sizeof(ApplVar.ICBlock);
                    record = (char *)&ApplVar.ICBlock;

                } else if (type > PLU1)   /* plu */
                {
                    if (cmd == cmdUPDATE)   /* update */
                    {
                        ApplVar.PluNumber = type - PLU1 - 1;
                        if (ApplVar.PluNumber < ApplVar.AP.Plu.Number)
                        {
                            memcpy(&ApplVar.Plu, &srvData[-1+3], sizeof(ApplVar.Plu));
                            WritePlu();
                            if (ApplVar.PluNumber==0)//ccr2015-02-26
                                ApplVar.AP.Plu.RNumber=0;//ccr2015-02-26
                            if (ApplVar.AP.Plu.RandomSize &&    /* set PLU's used */
                                (ApplVar.PluNumber >= ApplVar.AP.Plu.RNumber))
                            {
                                ApplVar.AP.Plu.RNumber = (ApplVar.PluNumber + 1);
                            }
                            cmdReturn = cmdDOWNLOAD; //Ӧ������,�������ݴ������,����������һ��
                        } else
                            cmdReturn = cmdANSWER;
                        break;
                    }
                    id = PLU1 + 1;
                    if (ApplVar.AP.Plu.RandomSize)    /* set PLU's used */
                        sMax = ApplVar.AP.Plu.RNumber;
                    else
                        sMax = ApplVar.AP.Plu.Number;
                    size = sizeof(ApplVar.Plu);
                    record = (char *)&ApplVar.Plu;
                } else if (type > DEPT)   /* dept */
                {
                    if (cmd == cmdUPDATE)   /* update */
                    {
                        ApplVar.DeptNumber = type - DEPT - 1;
                        if (ApplVar.DeptNumber<ApplVar.AP.Dept.Number)
                        {
                            memcpy(&ApplVar.Dept, &srvData[-1+3], sizeof(ApplVar.Dept));
                            WriteDept();
                            cmdReturn = cmdDOWNLOAD; //Ӧ������,�������ݴ������,����������һ��
                        } else
                            cmdReturn = cmdANSWER;
                        break;
                    }
                    id = DEPT + 1;
                    sMax = ApplVar.AP.Dept.Number;
                    size = sizeof(ApplVar.Dept);
                    record = (char *)&ApplVar.Dept;
                } else if (type > GROUP)   /* group */
                {
                    if (cmd == cmdUPDATE)   /* update */
                    {
                        ApplVar.GroupNumber = type - GROUP - 1;
                        if (ApplVar.GroupNumber<ApplVar.AP.Group.Number)
                        {
                            memcpy(&ApplVar.Group, &srvData[-1+3], sizeof(ApplVar.Group));
                            WriteGroup();
                            cmdReturn = cmdDOWNLOAD; //Ӧ������,�������ݴ������,����������һ��
                        } else
                            cmdReturn = cmdANSWER;
                        break;
                    }
                    id = GROUP + 1;
                    sMax = ApplVar.AP.Group.Number;
                    size = sizeof(ApplVar.Group);
                    record = (char *)&ApplVar.Group;
                } else if (type > OFFER)   /* OFFER */
                {
                    if (cmd == cmdUPDATE)   /* update */
                    {
                        ApplVar.OFFNumber = type - OFFER -1;
                        if (ApplVar.OFFNumber<ApplVar.AP.OFFPrice.Number)
                        {
                            memcpy(&ApplVar.OFFPrice, &srvData[-1+3], sizeof(ApplVar.OFFPrice));
                            WriteOFFPrice();
                            cmdReturn = cmdDOWNLOAD; //Ӧ������,�������ݴ������,����������һ��
                        } else
                            cmdReturn = cmdANSWER;
                        break;
                    }
                    id = OFFER+1;
                    sMax = ApplVar.AP.OFFPrice.Number;
                    size = sizeof(ApplVar.OFFPrice);
                    record = (char *)&ApplVar.OFFPrice;
                } else if (type > CLERK)   /* clerk */
                {
                    if (cmd == cmdUPDATE)   /* update */
                    {
                        if (ApplVar.ClerkNumber<=ApplVar.AP.Clerk.Number)
                        {
                            ApplVar.ClerkNumber = type - CLERK;
                            memcpy(&ApplVar.Clerk, &srvData[-1+3], sizeof(ApplVar.Clerk));
                            WriteClerk();
                            cmdReturn = cmdDOWNLOAD; //Ӧ������,�������ݴ������,����������һ��
                        } else
                            cmdReturn = cmdANSWER;
                        break;
                    }
                    id = CLERK;
                    sMax = ApplVar.AP.Clerk.Number + 1;
                    size = sizeof(ApplVar.Clerk);
                    record = (char *)&ApplVar.Clerk;
                } else if (type > TAX)    /* modifier */
                {
                    if (cmd == cmdUPDATE)   /* update */
                    {
                        ApplVar.TaxNumber = type - TAX - 1;
                        if (ApplVar.TaxNumber<ApplVar.AP.Tax.Number)
                        {
                            memcpy(&ApplVar.Tax, &srvData[-1+3], sizeof(ApplVar.Tax));
                            WriteTax();
                            cmdReturn = cmdDOWNLOAD; //Ӧ������,�������ݴ������,����������һ��
                        } else
                            cmdReturn = cmdANSWER;
                        break;
                    }
                    id = TAX + 1;
                    sMax = ApplVar.AP.Tax.Number;
                    size = sizeof(ApplVar.Tax);
                    record = (char *)&ApplVar.Tax;
                } else if (type > SALPER)    /* sales person */
                {
                    if (cmd == cmdUPDATE)   /* update */
                    {
                        ApplVar.SalPerNumber = type - SALPER;
                        if (ApplVar.SalPerNumber<=ApplVar.AP.SalPer.Number)
                        {
                            memcpy(&ApplVar.SalPer, &srvData[-1+3], sizeof(ApplVar.SalPer));
                            WriteSalPer();
                            cmdReturn = cmdDOWNLOAD; //Ӧ������,�������ݴ������,����������һ��
                        } else
                            cmdReturn = cmdANSWER;
                        break;
                    }
                    id = SALPER;
                    sMax = ApplVar.AP.SalPer.Number+1;
                    size = sizeof(ApplVar.SalPer);
                    record = (char *)&ApplVar.SalPer;
                } else if (type > MODI)    /* modifier */
                {
                    if (cmd == cmdUPDATE)   /* update */
                    {
                        ApplVar.ModiNumber = type - MODI - 1;
                        if (ApplVar.ModiNumber<ApplVar.AP.Modi.Number)
                        {
                            memcpy(&ApplVar.Modi, &srvData[-1+3], sizeof(ApplVar.Modi));
                            WriteModi();
                            cmdReturn = cmdDOWNLOAD; //Ӧ������,�������ݴ������,����������һ��
                        } else
                            cmdReturn = cmdANSWER;
                        break;
                    }
                    id = MODI + 1;
                    sMax = ApplVar.AP.Modi.Number;
                    size = sizeof(ApplVar.Modi);
                    record = (char *)&ApplVar.Modi;
                } else
                {
                    id = (type / 100) * 100 + 1;
                    if (type > TEND)
                    {
                        if (cmd == cmdUPDATE)   /* update */
                        {
                            ApplVar.TendNumber = type - TEND - 1;
                            if (ApplVar.TendNumber<ApplVar.AP.Tend.Number)
                            {
                                memcpy(&ApplVar.Tend, &srvData[-1+3], sizeof(ApplVar.Tend));
                                WriteTender();
                                cmdReturn = cmdDOWNLOAD; //Ӧ������,�������ݴ������,����������һ��
                            } else
                                cmdReturn = cmdANSWER;
                            break;
                        }
                        sMax = ApplVar.AP.Tend.Number;
                        size = sizeof(ApplVar.Tend);
                        record = (char *)&ApplVar.Tend;
                    } else if (type > PORA)
                    {
                        if (cmd == cmdUPDATE)   /* update */
                        {
                            ApplVar.PoRaNumber = type - PORA - 1;
                            if (ApplVar.PoRaNumber<ApplVar.AP.PoRa.Number)
                            {
                                memcpy(&ApplVar.PoRa, &srvData[-1+3], sizeof(ApplVar.PoRa));
                                WritePoRa();
                                cmdReturn = cmdDOWNLOAD; //Ӧ������,�������ݴ������,����������һ��
                            } else
                                cmdReturn = cmdANSWER;
                            break;
                        }
                        sMax = ApplVar.AP.PoRa.Number;
                        size = sizeof(ApplVar.PoRa);
                        record = (char *)&ApplVar.PoRa;
                    } else if (type > PBF)
                    {
                        if (cmd == cmdUPDATE)   /* update */
                        {
                            ApplVar.PbFNumber = type - PBF - 1;
                            if (ApplVar.PbFNumber<ApplVar.AP.Pb.Number)
                            {
                                memcpy(&ApplVar.PbF, &srvData[-1+3], sizeof(ApplVar.PbF));
                                WritePbF();
                                cmdReturn = cmdDOWNLOAD; //Ӧ������,�������ݴ������,����������һ��
                            } else
                                cmdReturn = cmdANSWER;
                            break;
                        }
                        sMax = ApplVar.AP.Pb.Number;
                        size = sizeof(ApplVar.PbF);
                        record = (char *)&ApplVar.PbF;
                    } else if (type > DRAW)
                    {
                        if (cmd == cmdUPDATE)   /* update */
                        {
                            ApplVar.DrawNumber = type - DRAW - 1;
                            if (ApplVar.DrawNumber<ApplVar.AP.Draw.Number)
                            {
                                memcpy(&ApplVar.Draw, &srvData[-1+3], sizeof(ApplVar.Draw));
                                WriteDrawer();
                                cmdReturn = cmdDOWNLOAD; //Ӧ������,�������ݴ������,����������һ��
                            } else
                                cmdReturn = cmdANSWER;
                            break;
                        }
                        sMax = ApplVar.AP.Draw.Number;
                        size = sizeof(ApplVar.Draw);
                        record = (char *)&ApplVar.Draw;
                    } else if (type > DISC)
                    {
                        if (cmd == cmdUPDATE)   /* update */
                        {
                            ApplVar.DiscNumber = type - DISC - 1;
                            if (ApplVar.DiscNumber<ApplVar.AP.Disc.Number)
                            {
                                memcpy(&ApplVar.Disc, &srvData[-1+3], sizeof(ApplVar.Disc));
                                WriteDisc();
                                cmdReturn = cmdDOWNLOAD; //Ӧ������,�������ݴ������,����������һ��
                            } else
                                cmdReturn = cmdANSWER;
                            break;
                        }
                        sMax = ApplVar.AP.Disc.Number;
                        size = sizeof(ApplVar.Disc);
                        record = (char *)&ApplVar.Disc;
                    } else if (type > CURR)
                    {
                        if (cmd == cmdUPDATE)   /* update */
                        {
                            ApplVar.CurrNumber = type - CURR - 1;
                            if (ApplVar.CurrNumber<ApplVar.AP.Curr.Number)
                            {
                                memcpy(&ApplVar.Curr, &srvData[-1+3], sizeof(ApplVar.Curr));
                                WriteCurr();
                                cmdReturn = cmdDOWNLOAD; //Ӧ������,�������ݴ������,����������һ��
                            } else
                                cmdReturn = cmdANSWER;
                            break;
                        }
                        sMax = ApplVar.AP.Curr.Number;
                        size = sizeof(ApplVar.Curr);
                        record = (char *)&ApplVar.Curr;
                    } else if (type > CORREC)
                    {
                        if (cmd == cmdUPDATE)   /* update */
                        {
                            ApplVar.CorrecNumber = type - CORREC - 1;
                            if (ApplVar.CorrecNumber<ApplVar.AP.Correc.Number)
                            {
                                memcpy(&ApplVar.Correc, &srvData[-1+3], sizeof(ApplVar.Correc));
                                WriteCorrec();
                                cmdReturn = cmdDOWNLOAD; //Ӧ������,�������ݴ������,����������һ��
                            } else
                                cmdReturn = cmdANSWER;
                            break;
                        }
                        sMax = ApplVar.AP.Correc.Number;
                        size = sizeof(ApplVar.Correc);
                        record = (char *)&ApplVar.Correc;
                    } else
                    {
                        cmdReturn = cmdANSWER;
                        break;
                    }
                }
#if (0)//ccr2016-08-19 ���ṩ�ϴ��ļ����ݵĹ���
                start = type - id;
                if (start < sMax)
                {//��ָ���ļ���һ����¼���ݷ��͸�����
                    MemSet(record, size, 0);    /* clear memory */
                    memset(sBuffer,' ',INPUTWIDTH);
                    if (type > PBTOT)
                    {
#if (DD_FISPRINTER==0 && DD_DISABLEPBF==0)
                        CopyFrStr(sBuffer,Msg[SETPBINF].str);
#endif
                        PbTotal(start + 1, 0);  /* read */
                    } else if (type > BLOCKIC)//ccr chipcard
                    {
                        CopyFrStr(sBuffer,Msg[GUASHIIC].str);
                        ApplVar.ICBlockNumber = start;
                        ReadICBlock();
                    } else if (type > PLU1)
                    {
                        CopyFrStr(sBuffer,Msg[SETPLU].str);
                        ApplVar.PluNumber= start;
                        ReadPlu();
                    } else if (type > DEPT)
                    {
                        CopyFrStr(sBuffer,Msg[SETDEPT].str);
                        ApplVar.DeptNumber = start;
                        ReadDept();
                    } else if (type > GROUP)
                    {
                        CopyFrStr(sBuffer,Msg[SETGROUP].str);
                        ApplVar.GroupNumber = start;
                        ReadGroup();
                    } else if (type > OFFER)
                    {
#if offNumber
                        CopyFrStr(sBuffer,Msg[SETOFF].str);
#endif
                        ApplVar.OFFNumber = start;
                        ReadOFFPrice();
                    } else if (type > CLERK)
                    {
                        CopyFrStr(sBuffer,Msg[SETCLERK].str);
                        ApplVar.ClerkNumber = start;
                        ReadClerk();
                    } else if (type > TAX)    /* tax */
                    {
                        CopyFrStr(sBuffer,Msg[SETTAX].str);
                        ApplVar.TaxNumber = start;
                        ReadTax();
                    } else if (type > SALPER)    /* salesperson */
                    {
                        CopyFrStr(sBuffer,Msg[SETSALER].str);
                        ApplVar.SalPerNumber = start;
                        ReadSalPer();
                    } else if (type > MODI)    /* modifier */
                    {
                        CopyFrStr(sBuffer,Msg[SETMODIF].str);
                        ApplVar.ModiNumber = start;
                        ReadModi();
                    } else if (type > TEND)    /* tender */
                    {
                        CopyFrStr(sBuffer,Msg[SETTEND].str);
                        ApplVar.TendNumber = start;
                        ReadTender();
                    } else if (type > PORA)    /* pora */
                    {
                        CopyFrStr(sBuffer,Msg[SETPORA].str);
                        ApplVar.PoRaNumber = start;
                        ReadPoRa();
                    } else if (type > PBF)    /* pb */
                    {
#if (DD_FISPRINTER==0 && DD_DISABLEPBF==0)
                        CopyFrStr(sBuffer,Msg[SETPBF].str);
#endif
                        ApplVar.PbFNumber = start;
                        ReadPbF();
                    } else if (type > DRAW)    /* drawer */
                    {
                        CopyFrStr(sBuffer,Msg[SETDRAWER].str);
                        ApplVar.DrawNumber = start;
                        ReadDrawer();
                    } else if (type > DISC)    /* discount */
                    {
                        CopyFrStr(sBuffer,Msg[SETDISC].str);
                        ApplVar.DiscNumber = start;
                        ReadDisc();
                    } else if (type > CURR)    /* currency */
                    {
                        CopyFrStr(sBuffer,Msg[SETCURR].str);
                        ApplVar.CurrNumber = start;
                        ReadCurr();
                    } else                  /* correction */
                    {
                        CopyFrStr(sBuffer,Msg[SETCORR].str);
                        ApplVar.CorrecNumber = start;
                        ReadCorrec();
                    }
                    WORDtoASC(sBuffer+INPUTWIDTH-1,start);
                    DispSt2(sBuffer);

                    err_state = tcp_RecordToHost(tpcb,cmdUPDATE,type,record, size);//���ͼ�¼����
                } else
                    cmdReturn = cmdANSWER;//������Ҫ������
#endif
            }
        }
        break;
    case cmdCLEAR:           /* clear memory ? */
        if (type == 0x524c) /* command "C  LR" */
        {
            id = ApplVar.CentralLock;
            start = ApplVar.ClerkNumber;
            end = ApplVar.ClerkLock;
            sMax = ApplVar.SalPerNumber;
//				ClearApplMemory();
            ClearAllReport();
            ApplVar.CentralLock = id;
            ApplVar.ClerkNumber = start;
            ApplVar.ClerkLock = end;
            ApplVar.SalPerNumber = sMax;
        }
        cmdReturn = cmdANSWER;
        ARROWS = 0x01;
        break;
#if (0)//ccr2016-08-19 ���ṩ��ȡ��ˮ�Ĺ���
        case cmdINIT:           /* init */
            if (type == 0x544e) /* command "INT" */
            {
                InitApplication(true);//ǿ�ƽ��г�ʼ��
            }
            cmdReturn = cmdANSWER;//Ӧ������,���ݴ������
            ARROWS = 0x01;
            break;
    case cmdFLOWDATA:
        if(ApplVar.FRegi || ApplVar.FlowHeader.ReadP==ApplVar.FlowHeader.NextNP)
        {//������״̬��,��ֹ��ȡ��ˮ����
            cmdReturn = cmdANSWER;
        }
        else
        {//�����տ��������ˮ,���ݷ��͸�ʽ:'F'+[size]+[type1]+[type2]+[data]; [type1]+[type2]Ϊ��ˮ˳���
            if (logFirst!=0)
                ApplVar.FlowHeader.ReadP = logFirst;

            if (type==0)
            {
                logFirst = ApplVar.FlowHeader.ReadP;
                sBuffer[0] = ECRNOLOG;
                sBuffer[1] = REGISTER;
                sBuffer[2] = LOCATION;
                return tcp_RecordToHost(tpcb,cmdFLOWDATA,type,sBuffer, 3);//���ͼ�¼����
            }
            sAddr = ApplVar.FlowHeader.ReadP;
            size = Read_Flow(sBuffer);
            logFirst = ApplVar.FlowHeader.ReadP;
            if (size <= 0)
            {
                if (size==-1)
                {
                    ApplVar.ErrorNumber = (ERROR_ID(CWXXI48));
                }

                cmdReturn = cmdANSWER;
            } else
            {
                ApplVar.FlowHeader.ReadP = sAddr;//�������յ�host��Ӧ���,ȷ��host�յ�������,������FlowHeader.ReadP
                err_state = tcp_RecordToHost(tpcb,cmdFLOWDATA,type,sBuffer, size);//���ͼ�¼����
                if (err_state!=ERR_OK)
                {//����ʧ��,�ָ���ˮָ��
                    ApplVar.ErrorNumber = (ERROR_ID(CWXXI103));
                    cmdReturn = cmdANSWER;
                } else
                    return err_state;
            }
        }
        break;
    case cmdPASSWORD://ccr2015-02-04 Catesir for PWD>>>>>>>>>>>>>>>>
        switch (type)
        {
        case 0:
            memcpy(&ApplVar.AP.ModePwd.PwdX,&srvData[-1+3],MAXPWD);//MAXPWD-1
            break;
        case 1:
            memcpy(&ApplVar.AP.ModePwd.PwdZ,&srvData[-1+3],MAXPWD);
            break;
        case 2:
            memcpy(&ApplVar.AP.ModePwd.PwdSET,&srvData[-1+3],MAXPWD);
            break;
        case 3:
            memcpy(&ApplVar.AP.ModePwd.PwdMG,&srvData[-1+3],MAXPWD);
            break;
        }
        cmdReturn = cmdANSWER;
        break;
#endif
    default :
//ccr2016-08-23        cmdReturn = cmdANSWER;
        break;
    }

    if (cmdReturn)
    {//�����host����Ӧ��

#if (0)//ccr2016-10-25>>>>>
#if defined(ACK_MUST)
        if (ETHERNET_ACK_MUST)
        {
            //����ACKӦ��
            sEcrNo=ACK;
            if ( cmdReturn==cmdDOWNLOAD && //��Ҫ�����ؽ���Ӧ��
                 (!ETHERNETSendECRData(&sEcrNo,1)
#if defined(ETHERNETWAITACK)
//ccr2016-08-11    || !ETHERNETCheckACK(0)//�ȴ�������Ӧ��
#endif
                ))
            {//����ʧ��ʱ
            }
        }
#endif
#else
#if defined(ACK_MUST)
            ETHERNET_WaitACK = ETHERNET_ACK_MUST;
#endif
#endif//ccr2016-10-25<<<<<

    }

    if (type > CLERK && type<OFFER)
    {
        ApplVar.ClerkNumber = save;

        if (save)
        {
            ReadClerk();
        }

    } else if (type > SALPER  && type<TAX)
    {
        ApplVar.SalPerNumber = save;
        ReadSalPer();
    }
    if (!TESTBIT(ApplVar.Clerk.Options, BIT7))
    {
        ApplVar.FTrain = 1 ;
        SETBIT(ARROWS, BIT2) ;
    } else
    {
        ApplVar.FTrain = 0 ;
        RESETBIT(ARROWS, BIT2) ;
    }
    return (cmdReturn);
}

/**
 * ��FiscalMemory�е�����(FISCALRECORD)���͸�������
 * ����˰�����ݵ�������Ϊ'T'
 * @author EutronSoftware (2016-12-26)
 *
 */
void ETHERNETSendECR_FM()
{
    short i,size;
    ULONG sendCount=0;//���ͼ�����
    ULONG logReadCopyNext=0;//��һ������Ҫ��ȡ����ˮ����
    ULONG logReadCopyLast=0;//��ǰ��ȡ����ˮ����
    BYTE OK_Send;
#if defined(MAXLOGPACKAGE)
    ULONG logSize;//����ָ��������͵���־���ݰ���С
    int  sendFlag;//���ͼ�����
#endif

    if (ApplVar.FiscalHead.ReadP==ApplVar.FiscalHead.MaxP)
        return;
    if (TESTBIT(ETHERNET_Ready,ETHERNET_OK_BIT) && GetSystemTimer()>ETHERNET_Wait)//ccr2015-03-11
    {
        ////mClearScreen();
        //DispStrXY(ETHERNETMess[G_CONNECTING].str,0,0);
        if (ETHERNETStartGprs())
        {
            if (ApplVar.CentralLock==SET)
                DispStrXY(ETHERNETMess[G_SHUJUFASONGZHONG].str,0,1);
            else
                PutsO(ETHERNETMess[G_SHUJUFASONGZHONG].str);//RG-DISPLAY

            SetFis_DateTime(true);

            ApplVar.FiscalBuff.Fis_Register.FLocation=LOCATION;
            ApplVar.FiscalBuff.Fis_Register.FRegister=REGISTER;

            ApplVar.FiscalBuff.Fis_Register.FCRC = 0;
            ApplVar.FiscalBuff.Fis_Register.FunN = FISREGISTER;

            size = FRECORDLEN;//�����ͳ�˰�����ݵ��տ�������־
            PCBuffer[0]='T';
            PCBuffer[1]=size & 0xff;
            memcpy(PCBuffer+2,(BYTE *)&ApplVar.FiscalBuff.Fis_Register,FRECORDLEN);
#if defined(MAXLOGPACKAGE)
            logSize = size+2;//ccr2015-08-26
#endif

#if defined(MAXLOGPACKAGE)
#if (PCBUFMAX<1024)
#error "PCBUFMAX<1024"
#endif
            //����PCBuffer,һ�η��Ͳ�����1024�ֽڵ���ˮ����
            while (size>0)// && ApplVar.FiscalHead.ReadP<ApplVar.FiscalHead.MaxP)
            {//�ڴ�ѭ����,���ȫ����ˮ���ݵķ���
                sendFlag = 0;//������ʾÿ������е���ˮ����
                if (logReadCopyNext!=0)
                    ApplVar.FiscalHead.ReadP = logReadCopyNext;//ccr2015-08-24ָ����һ��Ҫ��ȡ�ͷ��͵���ˮ
                logReadCopyLast = ApplVar.FiscalHead.ReadP;//ccr2015-08-24���浱ǰ��ȡ����ˮ���ݵ�ַ
                logReadCopyNext = logReadCopyLast;//ccr2016-04-18
                while (size>0)
                {//�ڴ�ѭ����,���һ������ͷ���
                    if (ApplVar.FiscalHead.ReadP<ApplVar.FiscalHead.MaxP)
                    {
                        size = Bios_FM_Read(&ApplVar.FiscalBuff.FiscalData,ApplVar.FiscalHead.ReadP,FRECORDLEN);
                        if (!size)
                             size=-1;//��ʾ�����ݳ���
                        else if (CWORD(ApplVar.FiscalBuff.FiscalData[0])==0xffff)
                             size=0;//��ʾ���ݶ���
                    }
                    else
                        size = 0;//��ʾ��Fiscal����

                    if (size>0 && (FRECORDLEN+logSize)<=1020)
                    {
                        //�����ݴ���PCBuffer,��ɴ��
                        PCBuffer[logSize++]='T';
                        PCBuffer[logSize++]=FRECORDLEN;
                        memcpy(PCBuffer+logSize,(BYTE *)&ApplVar.FiscalBuff.FiscalData,FRECORDLEN);
                        logSize+=FRECORDLEN;
                        sendFlag++;
                        ApplVar.FiscalHead.ReadP+=FRECORDLEN;//ָ����һ����¼
                    }
                    else if (size>=0)// (FRECORDLEN+logSize)>1020)
                    {
                        if (sendFlag)
                        {//��Ҫ���͵�����,�����ݷ��ͳ�ȥ
                            memset(SysBuf,' ',SCREENWD);
                            OK_Send = ULongtoASC(SysBuf+SCREENWD-1,sendFlag);
                            SysBuf[SCREENWD]=0;
                            if (ApplVar.CentralLock==SET)
                                DispStrXY(SysBuf,0,1);//��ʾ�ѷ���������Ŀ
                            else
                            {
                                SysBuf[0] = OK_Send;
                                DispStrXY(SysBuf+1,1,1);
                            }

                            logReadCopyLast = logReadCopyNext;
                            logReadCopyNext = ApplVar.FiscalHead.ReadP;
                            ApplVar.FiscalHead.ReadP = logReadCopyLast;//���ͳ���ʱ,�´δӴ����·���
                            if (
                                 !ETHERNETSendECRData(PCBuffer,logSize)//������ˮ����
#if defined(ETHERNETWAITACK)
                                 || !ETHERNETCheckACK(ACK)//�ȴ�������Ӧ��
#endif
                                )
                            {//����ʧ��ʱ
                                OK_Send = false;
                                size = 0;//��������.
                            }
                            else
                            {//���ͳɹ�
                                ApplVar.FiscalHead.ReadP = logReadCopyNext;//���ͳɹ�,�´δӴ˷���
                                if (sendCount==0) sendCount=1;//���տ��NETID����ˮ
                                sendCount+=sendFlag;
                                OK_Send = true;
                            }
                            logSize = 0;
                        }
                        break;
                    }
                }
            }

            memset(SysBuf,' ',SCREENWD);
            SysBuf[0] = ULongtoASC(SysBuf+SCREENWD-1,sendCount);
            SysBuf[SCREENWD]=0;
            if (OK_Send)
                i = G_FASONGCHENGGONG;
            else
                i = G_FASONGSHIBAI;
            if (ApplVar.CentralLock==SET)
            {
                SysBuf[0]=' ';
                //DispStrXY(SysBuf,0,2);//��ʾ�ѷ���������Ŀ
                DispStrXY(ETHERNETMess[i].str,0,1);
            }
            else
            {
                PutsO(ETHERNETMess[i].str);//RG-DISPLAY
                //DispStrXY(SysBuf+1,1,1);
            }
#else//����������ˮ���ݷ�ʽ>>>>>>>>>>>>
            do
            {
                //����������ˮ����
                if (!ETHERNETSendECRData(PCBuffer,size+2))//������ˮ����
                {
                    OK_Send = false;
                    break;
                }
                sendCount++;

                if (logReadCopyNext!=0)
                    ApplVar.FiscalHead.ReadP = logReadCopyNext;//ccr2015-08-24ָ����һ��Ҫ��ȡ�ͷ��͵���ˮ

                logReadCopyLast = ApplVar.FiscalHead.ReadP;//ccr2015-08-24���浱ǰ��ȡ����ˮ���ݵ�ַ
                size=Read_Flow(PCBuffer+2);//��ȡ��ˮ����
                logReadCopyNext = ApplVar.FiscalHead.ReadP;//ccr2015-08-24������һ����Ҫ��ȡ����ˮ����
                if (size>0)
                {
                    memset(SysBuf,' ',SCREENWD);
                    OK_Send = ULongtoASC(SysBuf+SCREENWD-1,sendCount);
                    SysBuf[SCREENWD]=0;
                    if (ApplVar.CentralLock==SET)
                        DispStrXY(SysBuf,0,1);//��ʾ�ѷ���������Ŀ
                    else
                    {
                        SysBuf[0] = OK_Send;
                        DispStrXY(SysBuf+1,1,1);
                    }

                    ApplVar.FiscalHead.ReadP = logReadCopyLast;//ccr2015-08-24�ָ�����ȡ����ˮ���ݵ�ַ,�Է����������ȳ���
                    PCBuffer[0]='T';
                    PCBuffer[1]=size;
                }
                OK_Send = true;

            } while (size>0);
#if defined(ETHERNETWAITACK)
            if (sendCount>0)//��ʾ�ڷ�������ˮ
                 ETHERNETCheckACK(ACK);//�ȴ�������Ӧ��
#endif
#endif//defined(MAXLOGPACKAGE)

            if (!OK_Send)//����ʧ��
            {
                if (ApplVar.CentralLock==SET || ApplVar.CentralLock==X)
                    DispStrXY(ETHERNETMess[G_FASONGSHIBAI].str,0,1);
                else
                {
                    CheckError(ERROR_ID(CWXXI103));
                    //PutsO(ETHERNETMess[G_FASONGSHIBAI].str);
                }
            }
            else if (size==0)//��ˮ���ݷ������
            {
#if defined(CASE_INDONESIA)
                ApplVar.LastDaysLog = GetDaysFrom1900(Now.year,Now.month,Now.day);
#endif
#if !defined(MAXLOGPACKAGE)
                if (ApplVar.CentralLock==SET)
                    DispStrXY(ETHERNETMess[G_FASONGCHENGGONG].str,0,1);
                else
                {
                    //PutsO(ETHERNETMess[G_FASONGCHENGGONG].str);//RG-DISPLAY
                    DispStrXY(SysBuf+1,1,1);
                }
#endif
            }
            else if (size==-1)//��ˮ���ݹ��ܺų���
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI48);
            }
            CloseETHERNET();
        }
    }
    else
    {
        if (ApplVar.CentralLock!=SET)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI108);
        }
        PutsO(ETHERNETMess[G_WAITFOR].str);//RG-DISPLAY
    }
    if (ApplVar.CentralLock==SET || ApplVar.CentralLock==X)
        PRESS_ANY_KEY(1);
}

/**
 * ����ȫ��˰������
 *
 * @author EutronSoftware (2014-12-01)
 */
void ETHERNETSendECR_FM_All()
{
    //mClearScreen();
    //DispStrXY(MESS_LOGREPET,0,0);
    if (WaitForYesNo(Prompt.Caption[QUERENF],0,1,0)=='Y')
    {
        ApplVar.FiscalHead.ReadP = FISDATAADDR;
        ETHERNETSendECR_FM();
    }
}

#endif
