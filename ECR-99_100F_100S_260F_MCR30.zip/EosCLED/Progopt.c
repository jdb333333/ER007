#define PROGOPT_C
#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
#include "message.h"

/****************************************************************/
//���ֽ�opt��Ϊ1��λתΪλ���,����str��
//��:10010100=>853
void OptionToStr(BYTE opt,char *str)
{
    short i;
    int j=0;

    for (i = 0; i < 8; i++)
    {
        if (opt & (0x01 << i))
            str[j++] = 0x31+i;
        //else
        //			str[i] = ' ';
    }

}

#if (ASCIIINPUT==1 || COMPOSEIN==0)
// Ϊ���aA9��ϼ������뷽ʽת������
// ��������İ������sKeyNo,��ȡ��Ӧ��ASCII
//����:0-û�ж�Ӧ��ASCII
//  >0-�Żض�Ӧ���ַ�
char GetComposeASC(char sKeyNo)
{
    char newASC;

    if (BIT(ApplVar.ArrowsAlfa,NUMRIC09))       //liuj 0627
    {
        newASC = NUMASC_KEYBOARD[sKeyNo];

        if (BIT(ApplVar.ArrowsAlfa,UPPERASCII) &&
            (((newASC<'0' || newASC>'9') && newASC!='.')))
        {//�ڴ��������뷽ʽ��,�����˷�����
            return 0;
        }
    } else
    {
        newASC = ASCIIKEY[sKeyNo];
        if ((newASC>='a' && sKeyNo<='z') && BIT(ApplVar.ArrowsAlfa,UPPERASCII))
            newASC &=(~0x20);
    }                               //liuj 0627

    return newASC;
}
#elif  (COMPOSEIN==1)
// Ϊ�������������ĸ��ʽת������
// ��������İ�����Ӧ�����ֻ�ȡ��Ӧ��ASCII
//����:0-û�ж�Ӧ��ASCII
//  0xff-�Ѿ���ϵ�������
//  ����-�ж�Ӧ��ASCII,�������ְ���
char GetComposeASC(WORD keyCode)
{
    int sLp;
    char sP = keyCode & 0xff;

    if (keyCode=='.')
    {
        RESETBIT(ApplVar.ArrowsAlfa,COMPASCII);
        return sP;
    } else if (keyCode>='0' && keyCode<='9' )
    {
        if (BIT(ApplVar.ArrowsAlfa,INPUTVALUE))
        {
            if (Appl_EntryCounter==0)
            {
                SETBIT(ApplVar.ArrowsAlfa,COMPASCII);//��һ��������Ҫ�������
                return sP;
            } else if (BIT(ApplVar.ArrowsAlfa,COMPASCII))
            {
                if (!BIT(ApplVar.ArrowsAlfa, NUMRIC09))
                {//Ϊ��ĸ���뷽ʽ
                    for (sLp=0;sLp<NUMASC;sLp++)
                    {
                        if (EntryBuffer[ENTRYSIZE - 2] == CodeASC[sLp][0] && sP==CodeASC[sLp][1])
                        {//����������ֶ�Ӧ����ĸ
                            *num2 = CodeASC[sLp][2];
                            if (!BIT(ApplVar.ArrowsAlfa, UPPERASCII) && sP>='A' && sP<='Z')//ccr070616
                                sP |= 0x20;
                            EntryBuffer[ENTRYSIZE - 2] = sP;
                            RESETBIT(ApplVar.ArrowsAlfa,COMPASCII);
                            return 0xff;
                        }
                    }
                }
            }
        }
        return sP;
    } else
        return 0;//������Ϊ�Ƿ�����,�˳�
}
#endif


#if (DD_FISPRINTER==0)
//Get HANZ code from input
//����ʵ�ʳ���
int GetCaption(char *cap,BYTE size)
{
    int   sLp=Appl_EntryCounter;

    if (Appl_EntryCounter > size)
    {//�����볤�ȴ���sizeʱ,ֻcopyǰsize���ַ�
        sLp = size;
        ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
//		return;
    }
    MemSet(cap, size, 0);
    memcpy(cap,EntryBuffer + ENTRYSIZE - Appl_EntryCounter - 1,sLp);
    if (cap[0]==' ' && cap[1]==0)
    {//���ֻ������һ���ո�,����Ϊ���ַ���
        cap[0] = 0;
        sLp = 0;
    }
    return sLp;
}

//Get byte value from input
void GetByte(BYTE *to,BYTE min,BYTE max)
{
    StrToBCDValue(ApplVar.Entry.Value, &EntryBuffer[ENTRYSIZE - 2], BCDLEN);
    GetLongEntry();

    if (Appl_NumberEntry < min || Appl_NumberEntry > max)
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
        return;
    }
    *to = Appl_NumberEntry;
}

//Get hex data from input(BCD)
void GetHexBytes(BYTE *to,BYTE max)
{

    BYTE smax;

    smax = max * 2;
    MemSet(to, max,0);
    if (ApplVar.DecimalPoint)
        smax ++;
    if (Appl_EntryCounter > smax)
        ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
    else
        StrToBCDValue(to, &EntryBuffer[ENTRYSIZE - 2], max);
}

//type =1,2,3,4
void SetPortType(BYTE type,void *val)
{
    *(BYTE *)val = type +'0';
    CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[Line_TYPE]);
#if (DISP2LINES)
    memcpy(ProgLine1Mes+ DISLEN - (PORTTYPELEN-1),PortType[type-1],(PORTTYPELEN-1));
#else
    memcpy(ProgLineMes+ DISLEN - (PORTTYPELEN-1),PortType[type-1],(PORTTYPELEN-1));
#endif
}


void InvertBit(BYTE type,void *flag)
{
    BYTE *f, bit;

    bit = (0x01 << ((Appl_BitNumber - 2) & 0x07));
    f = (BYTE *) flag;
    f += ((Appl_BitNumber - 2) / 8);
    if (Appl_EntryCounter)
    {
#if defined(FISCAL)
        if (type != 3 || Appl_BitNumber > 3)    /* Print Always on R & J */
#endif

            *f ^= bit;
    }
    CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[type + 3]);
#if (DISP2LINES)
    WORDtoASC(ProgLineMes + 13, Appl_BitNumber - 1);
    if (*f & bit)
        CopyFrStr(ProgLine1Mes + 8, Prompt.LineCap[Line_YES]);//copy YES
    else
        CopyFrStr(ProgLine1Mes + 8, Prompt.LineCap[Line_NO]);//copy No
#else
    WORDtoASC(ProgLineMes + 5, Appl_BitNumber - 1);
    if (*f & bit)
        CopyFrStr(ProgLineMes + 8, Prompt.LineCap[Line_YES]);
    else
        CopyFrStr(ProgLineMes + 8, Prompt.LineCap[Line_NO]);
#endif
}

//Chang the Binary data to string "11010011"
void Btoa(BYTE type,void *flag)
{
    short i;

    for (i = 0; i < 8; i++)
    {
#if (DISP2LINES)
        if (*((BYTE *)flag) & (0x01 << i))
            ProgLineMes[13 + i] = '1';
        else
            ProgLineMes[13 + i] = '0';
#else
        if (*((BYTE *)flag) & (0x01 << i))
            ProgLineMes[5 + i] = '1';
        else
            ProgLineMes[5 + i] = '0';
#endif
    }
}

//convert "11001001" to byte data
void strToBin(BYTE type,BYTE *byte)
{
    short i;
    BYTE sByte;

    *byte = 0;
    for (i=0;i<Appl_EntryCounter;i++)
    {
        sByte =EntryBuffer[ENTRYSIZE - 2 - i];
        if (sByte==0x30)
            continue;
        else if (sByte>0x30 && sByte <= 0x38)
            (*byte) |= (1<<(sByte - 0x31));
        else
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            break;
        }
    }
}

/* return 1 if option exist else return 0 */
BYTE GetOpt(BYTE type,void *opt,BYTE  size)
{
    short   sLp,sP;
    BYTE sByte;

    MemSet(ProgLineMes, sizeof(ProgLineMes), ' ');
#if (DISP2LINES)
    MemSet(ProgLine1Mes,sizeof(ProgLine1Mes),' ');
#endif

    switch (type)
    {
    case 0:     /* name */
#if defined(FISCAL)
    case 50:
#endif
        if (size)
        {
            if (Appl_EntryCounter)
            {
                GetCaption((char *) opt, size);
                SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
            }

            if (Appl_ProgStart == 2)
                sP = 0;
            else
            {
                sP = strlen(Prompt.LineCap[Line_CAPTION]);//lCAPWIDTH;
                CopyFrStr(ProgLineMes, Prompt.LineCap[Line_CAPTION]);

#if (!(DISP2LINES))
                ProgLineMes[sP++] = ':';
#endif
            }
            for (sLp=0;sLp<size;sLp++)
            {
                sByte =((char *)opt)[sLp];

#if (DISP2LINES)
                ProgLine1Mes[sLp] = sByte;
#else
                ProgLineMes[sP++] = sByte;
#endif
            }
            if (Appl_ProgStart == 2)
                return 1;
            break;
        }
        Appl_ProgLine++;
        return 0;
    case 1:     /* dept number (plu) */
        if (Appl_EntryCounter)
        {
            StrToBCDValue(ApplVar.Entry.Value, &EntryBuffer[ENTRYSIZE - 2], BCDLEN);
            GetLongEntry();
            if (!Appl_NumberEntry || Appl_NumberEntry > ApplVar.AP.Dept.Number)
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            else
            {
                Appl_NumberEntry--;
                *((WORD *) opt) = Appl_NumberEntry;
                SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
            }
        }
        CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[Line_DEPART]);
#if (DISP2LINES)
        WORDtoASC(ProgLine1Mes + DISLEN-1, *((WORD *) opt) + 1);
#else
        WORDtoASC(ProgLineMes + DISLEN-1, *((WORD *) opt) + 1);
#endif
        break;
    case 32:
        if (Appl_EntryCounter)
        {
            StrToBCDValue(ApplVar.Entry.Value, &EntryBuffer[ENTRYSIZE - 2], BCDLEN);
            GetLongEntry();
            if (!ApplVar.AP.Plu.RandomSize && Appl_NumberEntry > ApplVar.AP.Plu.Number)
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            else
            {
                *((WORD *) opt) = Appl_NumberEntry;
                SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
            }
        }
        CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[Line_LINK]);
#if (DISP2LINES)
        WORDtoASC(ProgLine1Mes + DISLEN-1, *((WORD *) opt));
#else
        WORDtoASC(ProgLineMes + DISLEN-1, *((WORD *) opt));
#endif
        break;
    case 33:    /* ApplVar.OFFPrice index,added by ccr */
        if (Appl_EntryCounter)
        {
            StrToBCDValue(ApplVar.Entry.Value, &EntryBuffer[ENTRYSIZE - 2], BCDLEN);
            GetLongEntry();
            if (Appl_NumberEntry > ApplVar.AP.OFFPrice.Number)
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            else
            {
                *((WORD *) opt) = Appl_NumberEntry;
                SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
            }
        }
#if offNumber
        CopyFrStr(ProgLineMes+SETUPMARIN, Msg[SETOFF].str);
#endif
#if (DISP2LINES)
        WORDtoASC(ProgLine1Mes + DISLEN-1, *((WORD *) opt));
#else
        WORDtoASC(ProgLineMes + DISLEN-1, *((WORD *) opt));
#endif
        break;
    case 2:     /* dept group number */
        if (Appl_EntryCounter)
        {
            GetByte((BYTE *)opt, 1, size);
            *(BYTE *)opt = *(BYTE *)opt - 1;
            SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
        }
        CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[Line_GROUP]);
#if (DISP2LINES)
        WORDtoASC(ProgLine1Mes + DISLEN-1, *((BYTE *) opt) + 1);
#else
        WORDtoASC(ProgLineMes + DISLEN-1, *((BYTE *) opt) + 1);
#endif
        break;
    case 3:     /* print */
    case 4:     /* options */
    case 5:     /* kp */
    case 6:     /* tax */
    case 7:     /* disable key switch */

        if (!size)
        {
            Appl_ProgLine++;
            return 0;
        }
        if (!Appl_BitNumber)
            Appl_BitNumber = 2;
        if (Appl_BitNumber > size + 1)
        {
            Appl_BitNumber = 0;
            Appl_ProgLine++;
            return 0;
        }
        if (Appl_ProgStart == 2)
        {
            CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[type - 3 + Line_PRINT]);
            Btoa(type, (BYTE *) opt);       /*    print bit map     */
            return 1;
        } else
        {
            InvertBit(type, (BYTE *) opt); /* type 1 is print */
            SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
        }
        break;
    case 8:     /* price1 */
    case 9:     /* price2 */
    case 10:    /* price3 */
    case 11:    /* price4 */
    case 12:    /* costprice */
    case 13:    /* fixed amt */
    case 14:    /* max amount */
    case 15:    /* fixed perc */
    case 16:    /* max perc */
    case 17:    /* ApplVar.Tax Rate */
    case 18:    /* buyrate */
    case 19:    /* sell rate */
    case 31:    /* Random ApplVar.PB Number */
    case 47:    //ccr2017-09-14 ADD STOCK
    case 48:    //ccr2017-09-14 REMOVE STOCK
        if (Appl_EntryCounter)
        {
            if (ApplVar.DecimalPoint)
                ApplVar.DecimalPoint--;
            GetHexBytes((BYTE *) opt, size);
            SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
        }
        if (type == 31)
        {
            ProgLineMes[1] = 'N';
            ProgLineMes[2] = ':';
            HEXtoASC(ProgLineMes + 3, (BYTE *) opt, size);
            if (Appl_ProgStart == 2) /* dump ? */
                return 1;
            else
                break;
        }
        else if (type==47)//ccr2017-09-14 ADD STOCK
            CopyFrStr(ProgLineMes+SETUPMARIN, DMes[ItemDMes1]);
        else if (type==48)//ccr2017-09-14 REMOVE STOCK
            CopyFrStr(ProgLineMes+SETUPMARIN, DMes[ItemDMes2]);
        else
            CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[type - 8 + Line_PRICE1]);
        ApplVar.Entry = ZERO;
        memcpy(ApplVar.Entry.Value, opt, size);


        if (type < 15) /*    amount     */
        {
            if (Appl_EntryCounter)
            {
                ChangePoint();
                memcpy(opt,ApplVar.Entry.Value, size);
            }
#if (DISP2LINES)
            strncpy(ProgLine1Mes, DispAmtStr(ProgLine1Mes, &ApplVar.Entry,DISLEN),DISLEN);
#else
            strncpy(ProgLineMes, DispAmtStr(ProgLineMes, &ApplVar.Entry,DISLEN),DISLEN);
#endif
        } else
        {
            if (type < 18)
            {
                if (Appl_EntryCounter)
                {
                    ChangePoint2(false);//ccr2017-07-27
                    //ccr2017-12-21>>>>>>>
                    if (type==17 && BCDWidth(&ApplVar.Entry)>4)//˰���������
                    {
                        ApplVar.ErrorNumber=ERROR_ID(CWXXI01);//�����������
                        Appl_EntryCounter = 0;
                    }
                    else//ccr2017-12-21<<<<<<
                        memcpy(opt,ApplVar.Entry.Value, size);
                }
                ApplVar.Entry.Sign = 2; // perc
            } else
            {
                if (Appl_EntryCounter)
                {
                    switch (ApplVar.DecimalPoint)
                    {
                    case 0:
                        BcdMul10(&ApplVar.Entry);
                    case 1:
                        BcdMul10(&ApplVar.Entry);
                    case 2:
                        BcdMul10(&ApplVar.Entry);
                    default:
                        break;
                    }
                    memcpy(opt,ApplVar.Entry.Value, size);
                }
                ApplVar.Entry.Sign = 3;
            }
#if (DISP2LINES)
            strncpy(ProgLine1Mes, DispQtyStr(ProgLine1Mes, &ApplVar.Entry,DISLEN), DISLEN);
#else
            strncpy(ProgLineMes, DispQtyStr(ProgLineMes, &ApplVar.Entry,DISLEN), DISLEN);
#endif
        }
        break;
    case 20:    /*    start time zone     */
        CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[Line_START]);//    state

        if (Appl_EntryCounter)
        {
            GetHexBytes(SysBuf, 2);
            if (!ApplVar.ErrorNumber &&
                SysBuf[0] < 0x59 && SysBuf[1] < 0x24)
            {
                *((BYTE *) opt) = SysBuf[0];
                *(((BYTE *) opt) + 1) = SysBuf[1];
                SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
            } else
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI03);
                break;
            }
        }
        ApplVar.Entry = ZERO;
        memcpy(ApplVar.Entry.Value, opt, size);
        ApplVar.Entry.Sign = 2;
#if (DISP2LINES)
        strncpy(ProgLine1Mes, DispQtyStr(ProgLine1Mes, &ApplVar.Entry,DISLEN), sizeof(ProgLine1Mes));
#else
        strncpy(ProgLineMes, DispQtyStr(ProgLineMes, &ApplVar.Entry,DISLEN), sizeof(ProgLineMes));
#endif
        break;
    case 21:     /*    drawer 1     */
    case 22:     /*    drawer 2     */
    case 23:     /*    tip     */
    case 24:     /*    period     */
    case 25:    /*    pointer     */
    case 26:    /*    amount prefix1     */
    case 27:     /*    amount prefix2     */
    case 28:    /*    link     */
    case 30:    /*    max entry     */
        if (!size)
            break;
        if (Appl_EntryCounter)
        {
            GetByte((BYTE *) opt, 0, size);
            SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
        }
        if (type == 30)     /*    max entry ?     */
            CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[Line_MAX]);//    MAX
        else if (type > 25)
        {
            if (type < 28)
            {
                CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[Line_PREFIX]);//    pre
#if (DISP2LINES)
                WORDtoASC(ProgLineMes + 8, type - 25);
#else
                WORDtoASC(ProgLineMes + 6, type - 25);
#endif
            } else
            {
                CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[Line_LINK]);//    Lin
                WORDtoASC(ProgLineMes + 6, Appl_ProgLine - 6);
                if (type==28)                             // lyq added 2003\10\27
                {
                    WORDtoASC(ProgLineMes + 6, Appl_ProgLine - 5); // lyq added 2003\10\27
                }
            }
        } else
            CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[type - 21 + Line_DRAWER]);

#if (DISP2LINES)
        WORDtoASC(ProgLine1Mes + DISLEN -1, *((BYTE *) opt));
#else
        WORDtoASC(ProgLineMes + DISLEN -1, *((BYTE *) opt));
#endif
        if ((type < 24 || type > 25) && !*((BYTE *) opt))   /* copy off if zero */
        {
#if (DISP2LINES)
            CopyFrStr(ProgLine1Mes + DISLEN -3, Prompt.LineCap[Line_NO]);
#else
            CopyFrStr(ProgLineMes + DISLEN -3, Prompt.LineCap[Line_NO]);
#endif
        }
        break;
    case 34:    //    OFF type
        CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[Line_TYPE]);

        if (Appl_EntryCounter)
        {
            StrToBCDValue(ApplVar.Entry.Value, &EntryBuffer[ENTRYSIZE - 2], BCDLEN);
            GetLongEntry();
            if (Appl_NumberEntry > size)
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                break;
            } else
            {
                *((BYTE *)opt) = Appl_NumberEntry;
                SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
            }
        }
#if (DISP2LINES)
        WORDtoASC(ProgLine1Mes + DISLEN-1, *((BYTE *)opt));
#else
        WORDtoASC(ProgLineMes + DISLEN-1, *((BYTE *)opt));
#endif
        break;
    case 35:    //    DateFrom
    case 36:    //    DateTo
        CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[type-35+Line_DATEFR]);

        if (Appl_EntryCounter)
        {   //ccr100329>>>>>>>>>>>>>>
            if (size==4)
                NewTimeDate(0x11);
            if (!ApplVar.ErrorNumber)
            {
                if (size==4)
                {
                    *((WORD *) opt) = ((WORD)Now.month<<8) | Now.day;
                    *((WORD *)((char *)opt+2)) = Now.year;
                } else
                    *((WORD *) opt) = ((WORD)ApplVar.Entry.Value[1]<<8) | ApplVar.Entry.Value[0];
                SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
                //<<<<<<<<<<<<<
            } else
                break;
        }
#if (DISP2LINES)
        HEXtoASC(ProgLine1Mes + DISLEN - size * 2 - 1,(char *)opt,size);
#else
        HEXtoASC(ProgLineMes + DISLEN - size * 2 - 1,(char *)opt,size);
#endif
        break;
    case 37:    //    TimeFrom
    case 38:    //    TimeTo
        CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[type-37+Line_TIMEFR]);

        if (Appl_EntryCounter)
        {
            NewTimeDate(0x12);//������ʱ��,ֻ��ȡ
            if (!ApplVar.ErrorNumber)
            {
                *((WORD *) opt) = ((WORD)Now.hour<<8) | Now.min;
                SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
            } else
                break;
        }
#if (DISP2LINES)
        HEXtoASC(ProgLine1Mes + DISLEN-5, (char *)opt,2);
#else
        HEXtoASC(ProgLineMes + DISLEN-5, (char *)opt,2);
#endif
        break;
    case 39:    //WeekDay
        if (Appl_EntryCounter)
        {
            strToBin(type,(BYTE *)opt);
            SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
        }
        CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[Line_WEEKDAY]);

#if (DISP2LINES)
        ProgLine1Mes[0] = '0';
        sP = 0;
#else
        ProgLineMes[DISLEN-7] = '0';
        sP = DISLEN-7;
#endif
        for (sLp = 0; sLp < 7; sLp++)
        {
            if (*((BYTE *)opt) & (0x01 << sLp))
            {
#if (DISP2LINES)
                ProgLine1Mes[sP] = sLp+0x31;
#else
                ProgLineMes[sP] = sLp+0x31;
#endif
                sP++;
            }
        }
        break;
    case 41:        //OFF NumItems
        if (!size)
            break;
        if (Appl_EntryCounter)
        {
            GetByte((BYTE *)opt, 0, size);
            SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
        }
        CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[Line_PACKQTY]);//    MAX
#if (DISP2LINES)
        WORDtoASC(ProgLine1Mes + DISLEN -1, *((BYTE *)opt));
#else
        WORDtoASC(ProgLineMes + DISLEN -1, *((BYTE *)opt));
#endif
        break;
    case 40:        //OFF Discount
    case 42:
    case 43:
        if (Appl_EntryCounter)
        {
            if (ApplVar.DecimalPoint)
                ApplVar.DecimalPoint--;
            GetHexBytes((BYTE *) opt, size);
            SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
        }
        CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[type-40+Line_DISCOUNT]);
        ApplVar.Entry = ZERO;
        memcpy(ApplVar.Entry.Value, opt, size);

        if (Appl_EntryCounter)
        {
            ChangePoint();
            memcpy(opt,ApplVar.Entry.Value, size);
        }

#if (DISP2LINES)
        strncpy(ProgLine1Mes, DispAmtStr(ProgLine1Mes, &ApplVar.Entry,DISLEN),sizeof(ProgLine1Mes));
#else
        strncpy(ProgLineMes, DispAmtStr(ProgLineMes, &ApplVar.Entry,DISLEN),sizeof(ProgLineMes));
#endif
        break;
    case 44:    /* Select ApplVar.Port type */
        if (!size)
        {
            Appl_ProgLine++;
            return 0;
        }
//	    		if (!Appl_BitNumber)//ccr 050302
//				Appl_BitNumber = (*(BYTE*)opt)-'0';
        if (Appl_BitNumber > size )
            Appl_BitNumber = 1;
        SetPortType(Appl_BitNumber,(BYTE *) opt);
        SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
        break;
    case 45:    /* Select Protocl type */
        if (!size)
        {
            Appl_ProgLine++;
            return 0;
        }
        CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[Line_PROTOCOL]);

        if (Appl_EntryCounter)
        {
            if (Appl_EntryCounter != size)
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI03);
                break;
            } else
            {
                sP = ENTRYSIZE-Appl_EntryCounter-1;
                if (EntryBuffer[sP]>='1' && EntryBuffer[sP++]<='8' && //speed
                    EntryBuffer[sP]>='0' && EntryBuffer[sP++]<='2' && //check type
                    EntryBuffer[sP]>='1' && EntryBuffer[sP++]<='2' && //stop bit
                    EntryBuffer[sP]>='7' && EntryBuffer[sP++]<='8')   //data length
                {
                    *((BYTE *)opt)=EnCodeProto(EntryBuffer+ENTRYSIZE-Appl_EntryCounter-1);
                    SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
                } else
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI03);
                    break;
                }
            }
        }
#if (DISP2LINES)
        DeCodeProto(*((BYTE*)opt), ProgLine1Mes+DISLEN - size);
#else
        DeCodeProto(*((BYTE*)opt), ProgLineMes+DISLEN - size);
#endif
        break;
//ccr070723>>>>>>>>>>>>>>
    case 46://Set Tax for depart or discount
        CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[Line_TAXUSED]);

        if (Appl_EntryCounter)
        {
            sByte = *((BYTE*)opt);
            strToBin(type,(BYTE *)opt);
            SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
            if (*((BYTE*)opt) > (BYTE)(~(0xff<<size)))
            {
                *((BYTE*)opt) = sByte;
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                break;
            }
            //			*((BYTE*)opt) &= (~(0xff<<size));

        }
        sP = DISLEN-1;//ccr20131120

#if (DISP2LINES)
        ProgLine1Mes[sP] = '0';//ccr20131120
#else
        ProgLineMes[sP] = '0';
#endif
        for (sLp = 0; sLp < size; sLp++)
        {
            if (*((BYTE *)opt) & (0x01 << sLp))
            {
#if (DISP2LINES)
                ProgLine1Mes[sP] = sLp+0x31;
#else
                ProgLineMes[sP] = sLp+0x31;
#endif
                sP--;
            }
        }
        break;
//<<<<<<<<<<<<<<<<<<
    default:
        break;
    }

    ProgLineMes[DISLEN] = 0;

#if (DISP2LINES)
    ProgLine1Mes[DISLEN] = 0;
#endif

    return 1;
}

//��������������Ʊͷ,���ֻ������һ���ո�,����Ϊ��Ʊͷ
void GetHeader(int idx,int size)
{
    int sP,sLp;

    if (Appl_EntryCounter)
    {
        sLp=GetCaption(ApplVar.TXT.Header[idx], size);
        SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
        ApplVar.TXT.Header[idx][sLp]=0;

        if (sLp==0)//���ֻ������һ���ո�,����Ϊ��Ʊͷ
            memset(ApplVar.TXT.Header[idx],0, size+1);
    }
    switch (idx)
    {
    case 0://Panama-Name
        sP = strlen(FISCALNAME);//lCAPWIDTH;
        CopyFrStr(ProgLineMes, FISCALNAME);

        for (sLp=0;sLp<DISLEN;sLp++)
        {
#if (DISP2LINES)
            ProgLine1Mes[sLp] = ApplVar.TXT.Header[idx][sLp];
#else
            ProgLineMes[sP++] = ApplVar.TXT.Header[idx][sLp];
            if (sP>=DISLEN) break;
#endif
        }
        break;
    case 1://Panama-Address,ռ��1,2����
        sP = strlen(FISCALADDR);//lCAPWIDTH;
        CopyFrStr(ProgLineMes, FISCALADDR);

        for (sLp=0;sLp<DISLEN;sLp++)
        {
#if (DISP2LINES)
            ProgLine1Mes[sLp] = ApplVar.TXT.Header[idx][sLp];
#else
            ProgLineMes[sP++] = ApplVar.TXT.Header[idx][sLp];
            if (sP>=DISLEN) break;
#endif
        }

        if (Appl_EntryCounter)
        {//��������ĵ�ַ�Զ��������
            for (sLp=(PRTLEN+1)*2-1;sLp>PRTLEN;sLp--)
            {
                ApplVar.TXT.Header[1][sLp]=ApplVar.TXT.Header[1][sLp-1];
            }
            ApplVar.TXT.Header[1][PRTLEN]=0;//׷�ӽ�����־
            ApplVar.TXT.Header[2][PRTLEN]=0;//׷�ӽ�����־
        }
        break;
    default://case 2,3,4,5,6,7,8
        if (idx>=3 && idx<=(HEADLINES-1))//
        {
            sP = strlen(Prompt.LineCap[Line_CAPTION]);//lCAPWIDTH;
            CopyFrStr(ProgLineMes, Prompt.LineCap[Line_CAPTION]);
            ProgLineMes[sP++] = (idx-3)+'1';
            ProgLineMes[sP++] = ':';

            for (sLp=0;sLp<DISLEN;sLp++)
            {
#if (DISP2LINES)
                ProgLine1Mes[sLp] = ApplVar.TXT.Header[idx][sLp];
#else
                ProgLineMes[sP++] = ApplVar.TXT.Header[idx][sLp];
                if (sP>=DISLEN) break;
#endif
            }
        }
        break;
    }
}

//�˺���ר������������Ʊͷ,Ʊβ,��ζ�ȴ������ļ�������
//ֻ��һ���ո�ʱ,��Ϊû������
//setType:��������
//recMax:��¼��
//capSize:������󳤶�
void ProgCaptions(int setType,int recMax,int capSize)
{
    int sP,sLp,idx;
    char *cap;

    if (Appl_ProgNumber >= recMax)
    {
        SetInputMode('9');
        Appl_ProgNumber = -1;
        Appl_ProgLine = 0;
        return;
    }

    if (Appl_ProgLine<=2)//ccr2017-05-08
    {
        Appl_ProgLine = Appl_ProgNumber+2;
        Appl_ProgNumber = 0;
    }

    if (Appl_ProgLine>=2 && Appl_ProgLine<=recMax+1)
    {
        SetInputMode('a');

        Appl_MaxEntry = capSize;
        idx = Appl_ProgLine-2;

        switch (setType)
        {
        case SETMODIF:
            ApplVar.ModiNumber = idx;
            ReadModi();
            cap = ApplVar.Modi.Name;
            break;
        case SETTRAIL:
            cap = ApplVar.TXT.Trailer[idx];
            break;
#if (DD_SETSLIP)
        case SETSHEAD:
            cap = ApplVar.TXT.SlipHeader[idx];
            break;
#endif
        case SETHEAD:
            if( ApplVar.FisNumber.TotalHeadChangeNum>=FHEADCHGMAX)
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI117);//����������������
                Appl_EntryCounter = 0;
            }
            cap = ApplVar.TXT.Header[idx];
            break;
        }

        if (Appl_EntryCounter)
        {
            sLp=GetCaption(cap, capSize);
            SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
            cap[sLp]=0;

            if (sLp==1 && cap[0]==' ')//ֻ��һ���ո�ʱ,��Ϊû������
                memset(cap,0, capSize);
            if (setType==SETMODIF)
                WriteModi();
            else if (setType==SETHEAD)
                ApplVar.FMPullOut[NEWHEAD_FLAG]=0x69;
        }

        sP = strlen(Msg[setType].str);//lCAPWIDTH;
        memcpy(ProgLineMes, Msg[setType].str,sP++);
        sP += WORDtoASCL(ProgLineMes+sP,idx+1);
        ProgLineMes[sP++]=':';

        for (sLp=0;sLp<DISLEN;sLp++)
        {
#if (DISP2LINES)
            ProgLine1Mes[sLp] = *cap;
#else
            ProgLineMes[sP++] = *cap;
            if (sP>=DISLEN) break;
#endif
            cap++;
        }
    } else
    {
        SetInputMode('9');
        Appl_ProgLine = 0;
        Appl_ProgNumber = 0;
        Appl_MaxEntry = capSize;
    }
}


//Speed:'1'-1200,'2'-2400,'3'-4800,'4'-9600,'5'-19200,'6'-38400,'7'-57600,'8'-115200
//���ȱ���С��SETINPUTWD
CONST char PortRate[PORTRATENUM][7]={
    "  1200",
    "  2400",
    "  4800",
    "  9600",
    " 19200",
    " 38400",
    " 57600",
    "115200"
};


/***************************************************************
 * ��ȡ���ڵ�ͨѶ����
 *
 * @author EutronSoftware (2017-08-04)
 *
 * @param val
 *****************************************************************/
void GetPortRate(BYTE *val)
{
    if (Appl_BitNumber > PORTRATENUM )
        Appl_BitNumber = 1;

    *val = EnCodeRate(Appl_BitNumber);
#if ((DISP2LINES) )
    //memset(ProgLine1Mes, ' ', DISLEN);
    memcpy(ProgLine1Mes+ DISLEN + 1 - sizeof(PortRate[0]),PortRate[Appl_BitNumber-1],sizeof(PortRate[0]));
#else
    //MemSet(ProgLineMes, sizeof(ProgLineMes), ' ');
    memcpy(ProgLineMes+ DISLEN + 1 - sizeof(PortRate[0]),PortRate[Appl_BitNumber-1],sizeof(PortRate[0]));
#endif
}


#endif//(DD_FISPRINTER==0)
