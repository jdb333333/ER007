#ifndef __KING_H__
#define __KING_H__

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "debug.h"
#include "bios_dir.h"

#if defined(DEBUGBYPC)

#pragma option -a1

#define CONSTCHAR  char
#define CONSTBYTE  BYTE

#define VOIDFAR void
#define CONST

#else

#include "include.h"

#pragma pack(1)

#define CONSTCHAR  const char
#define CONSTBYTE  const BYTE
//#define BOOL     BYTE
#define bool     BYTE
#define VOIDFAR void
#define CONST   const
#endif

#if defined(CASE_EURO)
#define AMTMUL100		0 // ����Ľ���Ƿ��Է�Ϊ��λ,=0ʱ,���Զ�����С������Ľ��/100  //
#elif defined(CASE_MALTA)
#define AMTMUL100		1 // ����Ľ���Ƿ��Է�Ϊ��λ,=0ʱ,���Զ�����С������Ľ��/100  //
#endif

#define ffMemCopy(a,b,c) memcpy(a,b,c)
#define ffStrCopy(a,b) strcpy(a,b)
#define CopyFrStr(a,b) memcpy(a,b,strlen(b))


#define WORDFAR  WORD


#if defined(CASE_GPRS)
#define KEYDESMAX	    46  //ccr2016-08-23
#else
#define KEYDESMAX	    39 //ccr2016-09-13
#endif

#include "types.h"		//    definizione di tipi ausiliari
#include "bios.h"		//    bios
#include "print.h"

#include "SysTick.h"

#include "Menu.h"   //ccr2016-12-22

#ifndef BIT0
#define BIT0	0x01
#define BIT1	0x02
#define BIT2	0x04
#define BIT3	0x08
#define BIT4	0x10
#define BIT5	0x20
#define BIT6	0x40
#define BIT7	0x80

#define BIT8	0x0100
#define BIT9	0x0200
#define BIT10	0x0400
#define BIT11	0x0800
#define BIT12	0x1000
#define BIT13	0x2000
#define BIT14	0x4000
#define BIT15	0x8000

#define BIT16	0x010000l
#define BIT17	0x020000l
#define BIT18	0x040000l
#define BIT19	0x080000l
#define BIT20	0x100000l
#define BIT21	0x200000l
#define BIT22	0x400000l
#define BIT23	0x800000l

#define BIT24	0x01000000l
#define BIT25	0x02000000l
#define BIT26	0x04000000l
#define BIT27	0x08000000l
#define BIT28	0x10000000l
#define BIT29	0x20000000l
#define BIT30	0x40000000l
#define BIT31	0x80000000l
#endif
//.......................................................................
#define BIT(w,i)	    (w & (i))
#define TESTBIT(w,i)	    (w & (i))
#define SETBIT(w,i)	        (w |= (i))
#define RESETBIT(w,i)	    (w &= ~(i))
#define CLRBIT(w,i)	    (w &= ~(i))
#define INVERTBIT(w,i)	    (w ^= (i))
#define EXCEPTBIT(w,i)	    (w & (~(i)))
//..........................................................................

#define PARTNER  0		/*    if set then test EPROM for PARTNER     */
#define NETTEST 0		/*    if set then no computer network     */
#define CUBA1	0		/*    If set then new option for SICO CUBA     */
#define COST	0		/*    if set then costprice system for Dansk     */
#define PLUTEST 0		/*    if set then test new Random Plu Routines     */

/*    DON'T FORGET TO SET THE CORRECT SWITCHES IN THE ASSEMBLER SOURCES    */

#define BSF	0		/*    if set then eprom for BSF     */
#define PLOGO	0		/*    if PLOGO is 1 then check for graphic logo     */
#define HIGHSPEED   (input(0x19) & 0x20)    /*    if set then high speed installed     */
#define PTEST	1	/*    if set then printer controller with command for     */
/*    1 DOT line also system flag KISCTR is checked     */


#define BONUS	0		/*    bonus system     */
#define PBAFTER 0		/*    pb transactions are added to reports when finalized     */
#define PBTIME	0		/*    store time on PB for Moretti     */
#define BOTTLE	1		/*    bottle link     */
#define TTLPOS	0		/*    programmable position of total on slip for Moretti     */
#define PLUENQ	0		/*    plu enquiry function     */
#define PRCREP	0		/*    print reports by computer also on journal     */
#define INVCOM	0		/*    change inventory by computer     */
#define PLUREQ	0		/*    plu request     */
#define CCARD	0		/*    credit card interface for Moretti     */
#define NOBUGS	1		/*    all bugs solved     */
#define KWS	0		/*    changes for KWS (PB)     */
#define INDO	0		/*    Indonesian fiscal version (also set FISCAL to 1)     */

#define NEWPORT 0	/*    if set then extra serial port for Moretti     */
#define LCDLEN	16		/*    Length of LCD Display     */
#define JAPAN	0	/*    if set the Japanese standard app texts     */
/*    and special controller used also make    */
/*    eprom with XJ1219 application     */
#define DANKORT 0      /*    if set then dankort interface active     */
#define EFT	0		/*    if set EFT active for Holland     */
#define EFTD	0		/*    if set EFT active for Germany, also set EFT     */
#define REMOTE	0      /*    if set invoice printing for argentina     */
/*    Also GST is calculated on NET Sales Amount !!    */
/*    Special Validation lay-out     */
/*    Total not double heigth/width     */

#define CUBA	0		/*    if set then special Eprom for CUBA, SICO with secret code
and special print on SPRINT only used for LAUNDRY system      */
#define CHINA	1	/*    chinese printing      */
/*    If CHINA is set to 2 it is compiled for Europe     */
/*    This means graphic print on slip only when Slip     */
/*    is set to CTM 290, Reset GRAPHIC     */
/*    DON'T forget XTGEN/XTMOD/XTDRIVER/XTC/MAKEPROM !!!!     */
/*    For CHINA = 1 also skip LOGO, BONUS, VALIDATION     */
/*    SUSPEND     */
#define SLOVAK	0	/*    if set the program for Slovakia Fiscal Prom 32K !!     */
/*    if set to 2 then version without Fiscal Eprom     */
/*    Always set FISCAL to 1     */
#define GRILLO	0		/*    Note that SUPER must also be 1 !!     */
/*    used for header print      */
/*    if 1 then 24 character print     */
/*    if 2 then 11 character print     */
#define PRINTTYPE   0	    /*    define printer type used     */
/*    0 is thermal, 1 is dot matrix     */
#define CHAN	0      /*    if CHAN is 1 then PORT 1 is High Speed     */
/*    Channel     */
#define APPL	1     /*    1 -> Standard application     */
/*    2 -> GREEK (and Cyprus) application     */
/*    3 -> OPALE RIVA Germany appl     */
/*    4 -> Moretti Spanish appl (based on appl 1)     */
/*    5 -> Cyprus English appl (based on appl 2)     */
/*    6 -> Chinese Application base on appl 1 thermal     */
/*    7 -> Chinese Application base on appl 1 for     */
/*    Super Micro dot matrix     */
/*    8 -> Standard MALTA application     */
/*     also make special applic eproms !!     */
/*    9 -> Standard Frontiera Application     */
/*    10 -> Standard Spanish Frontiera Application     */
/*    11 -> Slovakian appl (based on appl 1)     */
/*    12 -> Application for Holland based on 1     */
/*    13 -> test application for new init routines     */
#define OPALE	0	/*    if 1 then compile for OPALE (RHS Germany)    */
/*    skip PB, KP, ReceiptIssue, Proforma & KPGroup     */
/*    note that SKIP must be set to S_PB     */
#define DEBET	0   /*    if set then debet card reader active     */
/*    if set to 1 then QUARTO     */
/*    if set to 2 then Standard (SCAS), IPC     */
#define CRT	0   /*    if set then KT + CRT version     */

#define MA   1		//must = 1
#define NEWCTR	1 /*    if set then NEW controller is used (SM Main board)     */
/*    MUST be SET also for SUPER, GRILLO, FRONT     */
#define SUPER 0
/* if SUPER is 1 and MA  == 1 then compile  for SUPER MICRO */
#define FRONT	0   /* if SUPER is 1 and FRONT is 1 then compile for FRONTIERA */
#define DITRON	0
/* if set then DITRON LANGUAGE active */
/* Don't set FISCAL because only serial */
/* number is written */


#define ARGENT	0   /* if set then Argentine fiscal logo */
#define CYPRUS	0   /* if set and GREEK is also set fiscal O.S. for Cyprus */
/* there are two versions APPL = 2 (Greek) APPL = 5 (English) */
#define GREEK	0   /* if set and FISCAL set then Greek fiscal O.S. */

#define EMPORIKI	0	/* If Set Then EPROM for EMPORIKI */
#define ROUNDTAXUP  0	/* if set round tax always UP, especially for GREECE */
/* not required any more */
#define MALTA	0   /* if set then fiscal O.S. for MALTA (no powerfail) */

#define FISCALERROR 100     /* fiscal error message start */
#define GRAPHIC 0   /* If set then print Graphic picture */
/* MUST be disabled for TECHNOEMPORIKI GREECE !!! */

/* if SKIP is set to 1 then the report, */
/* program, barcode and pbbuffer module */
/* are empty because of the size of the */
/* eprom emulator */
#define S_PB	0x01   /* Bit 0 then skip PB */
#define S_REP	0x02	/* bit 1 then skip report */
#define S_PROG	0x04	    /* if bit 2 then skip programming */
#define S_BAR	0x08	    /* if bit 3 then skip barcode */
#define S_COMP	0x10	    /* if bit 4 set then skip computer */
#define S_DISC	0x20	    /* if bit 5 set then skip discount */

/*
#define SKIP	(S_PB+S_REP+S_DISC)
*/

#define SKIP	0

/* Define default print Layout */
#define PLAYOUT 	0x03  //ccr2017-07-24 0x0b


#define BASEITEMS  98   //

#if COST == 1
#define TRANSITEMS	(BASEITEMS - 8)
#else
#if BONUS == 1
#define TRANSITEMS	(BASEITEMS - 7)
#else
#define TRANSITEMS	(BASEITEMS - 6)   //�������۵���Ŀ��Ŀ
#endif
#endif

#if GREEK == 0

#define ARROWS	ArrowsRight  /* if ARROWS is ArrowsRight then the left	     */
/* markers are used for #(Training), REGI, RON */
#else

#define ARROWS	ArrowsFlag  /* if ARROWS is defined ArrowsFlag then the left */
/* markers are used for SUB, TTL, CHANGE */

#endif
//ccr2017-04-28>>>>>>>>>>>>>>>>>>>>>>>
#define FRECEIPTS	0		// ˰���վݼ��� //
#define TRECEIPTS	1		// ��ѵ�վݼ��� //
#define NRECEIPTS	2		// ��˰�վݼ��� //
#define RECNUMSIZE	3		// ��˰�վݼ��� //
/////////////////////////////////////////////////

#define FISCALZNUM	0	/* receipt number */
#define TRAINZNUM	1	/* training receipt number */
#define ZSIZE	    2
//ccr2017-04-28<<<<<<<<<<<<<<<</////////

#define SOH		0x01
#define STX		0x02
#define ETX		0x03
#define EOT		0x04
#define ENQ		0x05
#define ACK		0x06
#define BEL		0x07
#define LF		0x0A
#define VT		0x0B
#define FF		0x0C
#define CRET		0x0D
#define SO		0x0E
#define SI		0x0F
#define DLE		0x10
#define DC1		0x11
#define DC2		0x12
#define DC3		0x13
#define DC4		0x14
#define NAK		0x15
#define ETB		0x17
#define DEL		0x18
#define CAN		0x18
#define WAIT	0x1b
#define FS		0x1C
#define GS		0x1D

//lyq added for modify flash driver 2003\12\08 start
#define CCLIB_ADDR ((unsigned CONSTCHAR*)0x40000)


//===========================================
extern BYTE PrintAmt(CONSTCHAR *str, BCD *amt);
extern void SetPrintLayOut(BYTE playout);
extern void KpEnd(BYTE kp);
extern void PrintKp(BYTE cmd, char *str);
extern void PrintMessage(WORD number);
extern void ReadClerk(void);
extern void ReadPlu(void);
//===========================================
extern BYTE PortParameter[4];
/*
extern CONST BYTE DUserChar[8][9];
*/

extern void Reset_int(void);

//cc test 2005-12-29
//extern void CloseDisp3150x(void);
//cc test 2005-12-29


extern void DrawerOpen(void);
extern void BcdDiv10(BCD *A0);
extern void BcdMul10(BCD *A0);
extern void BcdDiv100(BCD *A0);
extern void BcdMul100(BCD *A0);
extern void ULongToBCDValue(BYTE *toA1, unsigned long R2R0);	    /* (void) make BCD from hex long */
extern WORD BCD4toWORD(WORD R2R0);
extern BYTE BCDtoDEC(BYTE frR0H);
extern void    Multiply(BCD *result, BCD *with);     /* (void) */
extern void RoundBcd(BCD *A0, WORD decimalR3);     /* (void) round BCD to fixed number of decimals */
extern void Add(BCD *result, BCD *with);	    /* (void) add two BCD numbers */
extern void    Subtract(BCD *result, BCD *with);     /* (void) */
extern void    FormatBCD(char *toA0, BCD *fromA1, WORD fmtR1);	    /* () make ascii from BCD */
extern short   Bell(short len);	    /* () sound (len = 0, 1, 2, 3)  buzzer */
extern void    WORDtoBCD(char *to, WORD R3);	    /* () make BCD from hex */
extern BYTE    WORDtoASC(char *to, WORD R3);	    /* () make ascii string from unsigned short with zero suppression*/
extern short WORDtoASCL(char *to, WORD num);
extern void    WORDtoASCZero(char *to, WORD R3);     /* () make asci string from unsigned short with leading zero's*/
extern void    HEXtoASC(char *to, char *from, short len);	    /* () convert hex to asci */
extern void    HEXtoASCL(char *too, BYTE *from, short len);
extern void    Divide(BCD *result, BCD *with);	    /* () */
extern short     CompareBCDValue(void *a, void *b, WORD length);	    /* () */
extern short     CompareBCD(BCD *a, BCD *b);   /* () */
extern void HEXtoASCx0(char *to, char *from, short len);     /* (char *to, void *from, short len) convert hex to asci */

/* make unsigned long from bcd number */
extern BYTE    CheckOnLine(BYTE port);
extern WORD    Check232(BYTE port);
extern short     CheckNotZero(BCD * bcd);
/* return 0 if zero else 1 */

extern short BCDWidth(BCD  *bcd);
extern void SetBCDPoint(BCD *bcd,BYTE point);

extern void    DrawerOpen(void);   /* (BYTE draw) number number from 0 to 3 */
extern BYTE     Getch(void);	    /* wait and read keynumber */
extern void    GetTimeDate(struct TimeDate *);  /* () get system time, date */

#if NEWPORT == 1
extern void InitLcd(BYTE cmd, BYTE *line1, BYTE *line2);	    /* () */
extern BYTE	DisplayType;
#endif
extern short     JFeed(void);	    /* (short line) feed number of lines on journal */

extern short     KbHit(void);	    /* check if key available */
extern short     KbTone(short cmd);	    /* () keytone on,off */

extern void 	MaskKeyBoard(char pReset);
extern void     PutsLine0(CONST char *str);	    /* () put string on operator display */
extern void     PutsLine1(CONST char *str);

extern void     PutsO(CONST char *str);	    /* () put string on operator display */
extern void     PutsO_Only(CONST char *str);	    /* () put string on operator display */
extern void     PutsO_Saved(void);

#if defined(DEBUGBYPC)
extern void OutPrintEx(WORD Cmd, CONSTBYTE *Line, WORD DotLinesBlank) ;
#endif

extern void Puts1_At(BYTE ch,BYTE addr);//ccr20131120
extern void PutsO_At(BYTE ch,BYTE addr);//ccr20131120


#if(DD_ZIP==1)
  extern void Puts1(CONST char *str);
  extern void Puts1_Right(CONST char *str);//ccr20131120
  extern void PutsO_Right(char *str);
#elif(DD_ZIP_21==1)
  extern void Puts1(CONST char *str);
  extern void Puts1_Right(CONST char *str);//ccr20131120
  extern void PutsC(CONST char *str);
  extern void PutsO_Right(char *str);
#elif(DD_LCD_1601)
  extern void PutsC(CONST char *str);
  extern void PutsC_Only(CONST char *str);
  extern void PutsC_Saved(void);
#endif

//    extern void    ReadRam();	    /*    () read bytes from ram banks     */
extern short     RFeed(short line);	    /*    () feed number of lines on receipt     */
/*    Command 0 only returns status     */
//    extern short     RJPrint(short cmd, char *str);	    /*    () print string on printer     */

extern void SetRts(BYTE port, BYTE OnOff);	    /*    ()     */
extern void SetTimeDate(struct TimeDate *);  /*    () set system time     */

extern void	WaitOnLine(BYTE port);   /*    () set  to 1 if time out     */
//    extern void WriteRam();     /*    () write bytes to ram banks     */
extern WORD WriteSL(BYTE port, BYTE b);	    /*    () return 1 if time out     */


/*   *********************************************************************    */
/*   ********* Define MA  specific variables and functions ****************    */
/*   *********************************************************************    */

/* Central Lock Codes as used by the MA  register */
/* now also used for KT because KT translated to MA  */


#define     SET     71
#define     Z	    70
#define     OFF     66
#define     RG	    67
#define     X	    68
#define     MG	    69
#define     NOCLERK 72


//ccr2017-05-10>>>>>CheckMode���ܺ����¶�ӦSETģʽ�µ�����>>>>>>>>
//��SET��,�������������ȷ�ϼ�,ִ�������Ӧ�Ĺ���
//ccr2017-05-31>>>XZ���µĲ�������,����С��255 >>>>>>
#define CMD_xALLDAILY       101         // "ALL DAILY"
#define CMD_xGENERALPARAM	102         // "GENERAL PARAMETERS"
#define CMD_zCOPYLASTZ  	103         //"COPY OF LAST Z"
#define CMD_zZERODEPARTMENT 104         //  "ZERO DEPARTMENT"
#define CMD_zZEROPLUSALES   (CMD_zZERODEPARTMENT+1)         // "ZERO PLU SALES"
#define CMD_zZEROCLERKS     (CMD_zZEROPLUSALES+1)         //  "ZERO CLERKS"
#if (salNumber)
#define CMD_zZEROWAITERS    (CMD_zZEROCLERKS+1)         //  "ZERO WAITERS"
#else
#define CMD_zZEROWAITERS    (CMD_zZEROCLERKS)         //  "ZERO WAITERS"
#endif

#define CMD_zZEROALLSALES   108         // "ZERO ALL SALES"
#define CMD_zFMREADZ_Z      109         // "FM READ Z-Z"
#define CMD_zFMREADDATE     110         // "FM READ DATE"

#if defined(CMD_zFMREADTAXRATE)
#define CMD_zFMREADTAXRATE  111         // "READ TAX RATE "
#define CMD_zFMREADHEAD     112         // "READ HEAD "
#define CMD_zFMREADSETDATE  113         // "READ DATE CHANGED"
#endif

#if defined(FOR_DEBUG)//ccr2017-12-13
#define CMD_zHTTPPOSTSFILE  114         // "SEND S-FILES OF Z"
#endif
#if defined(CMD_zHTTPPOSTSFILE)//ccr2017-12-15
#define IDX_Z_FROM     ITEMS_X+3
#else
#define IDX_Z_FROM     ITEMS_X+2
#endif
//ccr2017-05-31<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#define CMD_INPUTMAC	14863		//����MAC��ַ

#define CMD_PRINTPLU	100			//��ӡ��Ʒ��Ϣ
#define CMD_EXPLOREEJ	200			//��ѯEJ����
#define CMD_PRINTFISCAL	810			//��ӡ������˰����Ϣ
#define CMD_PRINTEJ		901			//��ӡEJ��Ϣ
#define CMD_SETPWDX		601			//����X��������
#define CMD_SETPWDZ		602			//����Z��������
#define CMD_SETPWDSET	603			//����SET��������
#define CMD_SETPWDMG	604			//���þ���MG��������
#define CMD_INITFISCAL	800			//˰�س�ʼ��
#define CMD_INITEJ		900			//��ʼ��EJ
#define CMD_PRNGAPHIC	500			//��ӡ�տ��ͼ��
#define CMD_ECRCONFIG	310			//�տ����ӡ����
#define CMD_PRNRECEIPTS 311         //AUX_PRINTRECEIPTS, //��ӡ�վݲ���

//#define CMD_MARKET		605			//����Ϊ���м���
//#define CMD_RESTAURANT	606			//����Ϊ��������

#define CMD_HARDTEST	300			//�տ��Ӳ������
#define CMD_TESTSRAM	400			//�����ⲿRAM
#define CMD_CHIPCARD	600			//��ӡIC��Ա����Ϣ
#define CMD_ERASEFM		710			//����Fiscal Memory
#define CMD_TESTFM		711			//����Fiscal Memory
#define CMD_SD_CID		902			//��ȡSD����CID����
#define CMD_SD_CSD		903			//��ȡSD����CSD����
#define CMD_NETSEND_EJ  904			//ͨ����̫��������ˮ����
#define CMD_GPRSSEND_EJ 905			//ͨ��GPRSģ�鷢����ˮ����
//ccr2017-05-10<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


//ccr2017-09-13>>>PortType1..PortType7..>>>>>>>>>>>>>>>
#define PORT4BARCODE  	'1'      //����ǹ
#define PORT4SCALE		'2'     //���ӳ�
#define PORT4EXTLCD		'3'     //�ⲿ����
#define PORT4EXTKEYB	'4'     //�ⲿ����
#define PORT4KITCHEN	'5'     //��������ӡ��
#define PORT4HOSTPC		'6'     //��PC����
#define PORT4NONE		'7'

#define portTypeNum		(PORT4NONE-PORT4BARCODE+1)////ccr2017-09-13
#define portProNum		portTypeNum		// ccr epos

//ccr2017-09-13<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
// =====================================================================================

//#define RJPrint(a, s) printf(s) //testonly
#define RJPrint(a, s) OutPrint((BIT(ApplVar.PrintLayOut,BIT2)?CMDP_DR:CMDP_R)|CMDP_LFRJ, (CONSTCHAR *)(s))	//    Lancia stampa (standard)

#define TESTONLY(s) {UARTSend(0,s[0]); RSPrint(s,strlen(s),CMDP_RJ);}  //testonly

#define  NearEnd() Bios_1(BiosCmd_PrintCheck)	    /*    check nearend R & J     */
/*    0 = ok, 1 = J nearend, 2 = R nearend     */
/*    3 = R & J nearend     */
#define  PrintNoPaper() (Bios_1(BiosCmd_PrintCheck) & MK_NOPAPER)	    /*    check nearend R & J     */

#define MemSet(a,b,c) memset(a,c,b)

#if(DD_ZIP==1)
#define ClearLine2() PutsLine1(Msg[SPACE].str)
#elif(DD_ZIP_21==1)
#define ClearLine2() { PutsLine1(Msg[SPACE].str);\
                       if( (ApplVar.CentralLock==RG)||(ApplVar.CentralLock==MG)  )\
	                    {\
                          PutsC(EntryBuffer + ENTRYSIZE - DISLENC - 1);\
					    }\
					}
#else
#define ClearLine2() {}
#endif

//#define TESTONLY(a)	RJPrint(0,a)
#if !defined(DEBUGBYPC)

#define Delay(msec) msDelay(msec)

#ifndef MAC_ADDR
//ouhs #define MAC_ADDR ((__IO BYTE *)0x1FFF7800) //ccr2017-03-01MAC��ַ�Ĵ洢Ϊֹ
#endif
#else

#define Delay(msec) {}

extern BYTE MAC_ADDR[6];
#endif

#define DECtoBCD(p) ((((p)/10)<<4)+((p)%10))    //DEC to BCD
#define BCDtoDEC(p) (((p)>>4)*10+((p)&0x0f))   //BCD to DEC
#define TestBit(ch,BitNo) (ch & (1<< BitNo))
#define MemCopy(to,from ,len)  memcpy(to,from,len)
#define StrCopy(to,from) strcpy(to,from)
#define StrLen(str) strlen(str)

#define AppendCRLF(s,p)  {s[p++]='\r';s[p++]='\n';}

extern void    Density(WORD printer, WORD density);	    /*    ()     */
extern short     InitConfig(void *config, short len);   /*    () init controller     */

#include "appl.h"                               /* Kingtron library and I/O routines */

#endif
