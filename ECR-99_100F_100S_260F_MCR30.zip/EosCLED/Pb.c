#define PB_C 1
#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
#include "fiscal.h"
#include "flowbill.h"


/****************************************************************/

short StorePbInvoice(short check)
{
    char str[7];
    WORD used, invoice;
	UnLong offset;
    BCD temp;

    if (!BIT(ApplVar.AP.Pb.Random, BIT6) || ApplVar.FTrain)
			return 0;
	RamOffSet =  (ApplVar.AP.Pb.Random & 0x0f) + ApplVar.AP.Pb.Text + ApplVar.AP.Pb.AmtSize + 6 ;//????????????????????????
    if (BIT(PBINFO, BIT7))  /* Discount item stored ? */
		RamOffSet += ((ApplVar.AP.Pb.AmtSize + 1) << 1) ;
	RamOffSet = RamOffSet * ApplVar.AP.Pb.NumberOfPb + ApplVar.AP.StartAddress[AddrPBt] ;
    if (BIT(ApplVar.AP.Pb.Random, BIT7))     /* Pb Trailer ? */
		RamOffSet += 50*24 ;//???????????????????????????
	offset = RamOffSet ;     /* save start */
    ReadRam((BYTE *)&used, 2);      /* read entries used */
    if (check == 1)     /* check if full */
    {
		if (used < 200)
		    return 0;
		else        /* buffer full */
		{
		    ApplVar.ErrorNumber=ERROR_ID(CWXXI15);
		    return 1;
		}
    }
    if (check == 2)  /* print report */
    {
		temp = ZERO;
		while(used)     /* print report */
		{
		    MemSet(str, sizeof(str), ' ');
		    str[sizeof(str) - 1] = 0;
		    ReadRam((BYTE *)&invoice, 2);
		    WORDtoASC(str + 5, invoice);
		    if ((CHARSET & 0xf0) == 0x10 || (SLIP != 4 &&
		    	((CHARSET & 0x0f) == 3 || (CHARSET & 0x0f) == 7)))  /* number sign not available */
				str[0] = 'N';
		    else
				str[0] = '#';
		    ReadRam((BYTE *)temp.Value, 4);
		    if (BIT(temp.Value[3], BIT7))
		    {
				temp.Sign = 0x80;
				temp.Value[3] &= 0x0f;
		    }
		    else
				temp.Sign = 0;
		    PrintAmt(str, &temp);
		    used--;
		}
		PrintLine('-');
		if (ApplVar.FReport == Z)
		{
			RamOffSet = offset ;
		    WriteRam((BYTE *)&used, 2);
		}
		return 0;
    }
    used++;
	RamOffSet = offset;
    WriteRam((BYTE *)&used, 2);
    used--;
    used = (used<<2)+(used<<1);//*6;
	RamOffSet += used ;        /* calculate offset */
    temp = ApplVar.SubTotal;
    temp.Value[3] &= 0x0f;  /* digit 8 is sign used for sign */
    if (BIT(ApplVar.SubTotal.Sign, BIT7))   /* negative ? */
		temp.Value[3] |= 0x80;
    WriteRam((BYTE *)&ApplVar.PbInvoice, 2);        /* write ApplVar.Total */
    WriteRam((BYTE *)temp.Value, 4);
    ApplVar.PbInvoice++;
    if (ApplVar.PbInvoice > 9999)
		ApplVar.PbInvoice = 1;
    return 0;
}

void GetPbFOffSet()
{
	RamOffSet =  (UnLong)ApplVar.PbFNumber* ApplVar.AP.Pb.RecordSize + ApplVar.AP.StartAddress[AddrPBf] ;
}

void AddPbFTotal()
{

    GetPbFOffSet();
	RamOffSet += ApplVar.AP.Pb.TotalOffSet ;
    for (ApplVar.PointerType = 0; ApplVar.PointerType < REPDEFMAX; ApplVar.PointerType++)
    {
		ApplVar.Size = ApplVar.AP.Pb.Size[ApplVar.PointerType];
		AddPointerTotal();
    }
}

void WritePbF()
{
    if (ApplVar.PbFNumber < ApplVar.AP.Pb.Number)
    {
		GetPbFOffSet();

		WriteRam((BYTE *)&ApplVar.PbF, ApplVar.AP.Pb.TotalOffSet);      /* write function options */
/*      WriteRam(ApplVar.PbF.Name, ApplVar.AP.Pb.CapSize);*/
    }
}

void ReadPbF()
{
    GetPbFOffSet();

    ReadRam((BYTE *)&ApplVar.PbF,ApplVar.AP.Pb.TotalOffSet);      /* write function options */
/*        ReadRam(ApplVar.PbF.Name, ApplVar.AP.Pb.CapSize);*/
}

void GetPbtOffSet(short pbnum)  //ccr 2003-10-31
{
    if (pbnum<0)
        pbnum = (ApplVar.PbNumber-1);
	RamOffSet =  (UnLong)pbnum* ApplVar.AP.Pb.PBTRecordSize + ApplVar.AP.StartAddress[AddrPBt] ;
}

void AddPbtTotal()  //ccr 2003-10-31
{
    GetPbtOffSet(-1);
	RamOffSet += ApplVar.AP.Pb.PBTTotalOffset ;
    for (ApplVar.PointerType = 0; ApplVar.PointerType < REPDEFMAX; ApplVar.PointerType++)
    {
		ApplVar.Size = ApplVar.AP.Pb.PBTSize[ApplVar.PointerType];
		AddPointerTotal();
    }
}


/* cmd 0 = read ApplVar.PB total */
/* cmd 1 = write ApplVar.PB total */
/* cmd 2 = reset ApplVar.PB total */
/* cmd 3 = Write ApplVar.PB info (random + text) */
/* cmd 4 = Only get Offset */
/* cmd 5 = Only reset ApplVar.PB Extra Count for CUBA */

void PbTotal(WORD pbnum, BYTE cmd)
{
    WORD newblock;
	UnLong save;

    if (ApplVar.FProforma && cmd > 0  && cmd < 4) /* when proforma only read */
		return;
    pbnum--;
    GetPbtOffSet(pbnum);
	if (cmd == 4)   /* only get offset */
		return;
	if (cmd == 2 && ApplVar.AP.StartAddress[AddrTrack]>0)       /* reset track buffer ?*/
    {
		save = RamOffSet;
		ReadRam((BYTE *)&ApplVar.PB.Block, sizeof(ApplVar.PB.Block));   /* read start block */
		if (ApplVar.PB.Block)   /* used so link to free */
		{
		    newblock = ApplVar.PB.Block;    /* save start */
		    for(;;)
		    {
				ApplVar.PB.Block--;             /* minus 1 for offset calculation */
				RamOffSet = ApplVar.AP.StartAddress[AddrTrack] + (UnLong)ApplVar.PB.Block * ApplVar.AP.Pb.BlockSize ;
				ReadRam((BYTE *)&ApplVar.PB.Block, sizeof(ApplVar.PB.Block));   /* next block ? */
				if (!ApplVar.PB.Block)  /* end block reached */
				{
					RamOffSet -=  sizeof(ApplVar.PB.Block);
				    ApplVar.EmptyBlock++;
				    WriteRam((BYTE *)&ApplVar.EmptyBlock, sizeof(ApplVar.PB.Block));    /* link to other */
				    ApplVar.EmptyBlock = newblock - 1;  /* free pb block */
				    break;
				}
		    }
		}
		RamOffSet = save ;
    }
    if (!cmd || cmd == 2)   /* read or reset */
		MemSet(&ApplVar.PB, sizeof(ApplVar.PB), 0);
    if (!cmd) /* read */
		ReadRam((BYTE *)&ApplVar.PB.Block, sizeof(ApplVar.PB.Block));
    else if (cmd == 3)
		RamOffSet += sizeof(ApplVar.PB.Block);
    else
		WriteRam((BYTE *)&ApplVar.PB.Block, sizeof(ApplVar.PB.Block));
    if (ApplVar.AP.Pb.Random & 0x0f)
    {
		if (!cmd || cmd == 2)   /* read */
		    ReadRam((BYTE *)ApplVar.PB.Random, ApplVar.AP.Pb.Random & 0x0f);
		else if (cmd == 3)  /* write new random number */
		    WriteRam((BYTE *)ApplVar.PB.Random, ApplVar.AP.Pb.Random & 0x0f);
		else
			RamOffSet += ApplVar.AP.Pb.Random & 0x0f;
    }
    if (ApplVar.AP.Pb.Text)
    {
		if (!cmd || cmd == 2)   /* read */
		    ReadRam((BYTE *)ApplVar.PB.Text, ApplVar.AP.Pb.Text);
		else if (cmd == 3)  /* write new text */
		    WriteRam((BYTE *)ApplVar.PB.Text, ApplVar.AP.Pb.Text);
		else
			RamOffSet += ApplVar.AP.Pb.Text ;
    }

    if (!cmd) /* read */
    {
		ReadRam((BYTE *)&ApplVar.PB.Clerk, sizeof(ApplVar.PB.Clerk)
//						+ sizeof(ApplVar.PB.SalPer)  //ccr091125PB.SalPer?
						+ sizeof(ApplVar.PB.Lines)
						+ sizeof(ApplVar.PB.Covers));
		ReadRam((BYTE *)&ApplVar.PB.Amt, ApplVar.AP.Pb.AmtSize + 1);
		if (BIT(PBINFO, BIT7))      /* ApplVar.Disc Item stored ? */
		{
		    ReadRam((BYTE *)&ApplVar.PB.Disc1, ApplVar.AP.Pb.AmtSize + 1);
		    ReadRam((BYTE *)&ApplVar.PB.Disc2, ApplVar.AP.Pb.AmtSize + 1);
		}
    }
    else if (cmd == 3)  /* only write info */
    {
		RamOffSet += ( sizeof(ApplVar.PB.Clerk)
//						+ sizeof(ApplVar.PB.SalPer) //ccr091125PB.SalPer?
						+ sizeof(ApplVar.PB.Lines) + sizeof(ApplVar.PB.Covers) + ApplVar.AP.Pb.AmtSize + 1) ;
		if (BIT(PBINFO, BIT7))  /* Discount item stored ? */
			RamOffSet += ((ApplVar.AP.Pb.AmtSize + 1) << 1);
   	}
    else
    {
		WriteRam((BYTE *)&ApplVar.PB.Clerk,
						sizeof(ApplVar.PB.Clerk)
//						+ sizeof(ApplVar.PB.SalPer) //ccr091125PB.SalPer?
						+ sizeof(ApplVar.PB.Lines)+ sizeof(ApplVar.PB.Covers));
		WriteRam((BYTE *)&ApplVar.PB.Amt, ApplVar.AP.Pb.AmtSize + 1);
		if (BIT(PBINFO, BIT7))      /* ApplVar.Disc Item stored ? */
		{
		    WriteRam((BYTE *)&ApplVar.PB.Disc1, ApplVar.AP.Pb.AmtSize + 1);
		    WriteRam((BYTE *)&ApplVar.PB.Disc2, ApplVar.AP.Pb.AmtSize + 1);
		}
    }
}


/* return 1 incase of error slip etc */

void PrintPbHeader()
{
    BYTE saveprint;
    BCD temp;

    saveprint = ApplVar.PrintLayOut;
    if (BIT(ApplVar.PrintLayOut, BIT3)) /* print on slip */
    {
		if (ApplVar.SlipLines)      /* paper in slip ? */
		{
		    if (ApplVar.PB.Lines)
		    {
				SETMyFlags( ENSLIPPB);
				if(!BIT(DOT, BIT7) && SLIP == 2)
				   FeedSlip(ApplVar.PB.Lines*2 + SLIP_TOP-2);
				else
				   FeedSlip(ApplVar.PB.Lines + SLIP_TOP);
				ApplVar.SlipLines += ApplVar.PB.Lines;
				RESETBIT(ApplVar.PrintLayOut, BIT3); /* reset print on slip */
		    }
		}
    }
    SETBIT(ApplVar.PrintLayOut, BIT2);  /* double size */
    if ((ApplVar.PbF.Options & 0x0f) < 2)
    {
    	ApplVar.SlipDouble = 1;     /* double size on slip */		//20040326
    	PrintQty(Prompt.Caption[ItemPrompt23], &ApplVar.Entry);
    	ApplVar.PrintLayOut = saveprint;
    }
//	ApplVar.SlipPage = ApplVar.PB.Pages;  // 20040326
	RESETBIT(ApplVar.PrintLayOut, BIT3); /* reset print on slip */	 //20040326

    if (BIT(ApplVar.FNoPb, BIT2) && BIT(ApplVar.AP.Pb.Random, BIT6)) /* print Invoice number ? */
    {
		if (!ApplVar.PbInvoice)
		    ApplVar.PbInvoice = 1;
		temp = ZERO;
		WORDtoBCD(temp.Value, ApplVar.PbInvoice);

		PrintQty(Prompt.Message[25], &temp);
    }
	if ((ApplVar.PbF.Options & 0x0f) > 2)
		PrintQty(ApplVar.PbF.Name, &ApplVar.Entry);
	RESETBIT(ApplVar.PrintLayOut, BIT2);
	if (ApplVar.AP.Pb.Text)
		PrintStr(ApplVar.PB.Text);
	PrintLine('=');
//    ApplVar.PrintLayOut = saveprint;
    ApplVar.FPb = 1;
}


short GetPbNumber()
{
    WORD free, pbsave;

    if (ApplVar.AP.Pb.Random & 0x0f)  /* random pb# */
    {
		if (Appl_EntryCounter > ((ApplVar.AP.Pb.Random & 0x0f) * 2))
		{
		    ApplVar.ErrorNumber=ERROR_ID(CWXXI09);
		    return 0;
		}
		Appl_NumberEntry = 0;
		free = 0;
		pbsave = ApplVar.PbNumber;
		for (ApplVar.PbNumber = 1; ApplVar.PbNumber <= ApplVar.AP.Pb.NumberOfPb; ApplVar.PbNumber++)
		{
		   PbTotal(ApplVar.PbNumber, 0);   /* read new */
		   if (!ApplVar.PB.Block && ApplVar.PbNumber != pbsave)       /* free */
		   {
			if (!free)
			    free = ApplVar.PbNumber;    /* first free ApplVar.PB */
			if (BIT(PBINFO, BIT2) || BIT(PBPRINT, BIT7))  /* check number ? */
			    continue;
		   }
		   if (!CompareBCDValue(ApplVar.Entry.Value, ApplVar.PB.Random, ApplVar.AP.Pb.Random & 0x0f)) /* found */
		   {
		       Appl_NumberEntry = ApplVar.PbNumber;
		       break;
		   }
		}
		ApplVar.PbNumber = pbsave;
		if (!Appl_NumberEntry && free &&
					(BIT(PBINFO, BIT2) || BIT(PBPRINT, BIT7)))  /* check# ? */
		{
		    Appl_NumberEntry = free;
		    PbTotal(free, 4);   /* only get offset */
			RamOffSet += sizeof(ApplVar.PB.Block);
		    memcpy(ApplVar.PB.Random, ApplVar.Entry.Value, ApplVar.AP.Pb.Random & 0x0f);
		    WriteRam((BYTE *)ApplVar.PB.Random, ApplVar.AP.Pb.Random & 0x0f);  /* write new number */
		}
    }
   if (!Appl_NumberEntry || Appl_NumberEntry > ApplVar.AP.Pb.NumberOfPb)
    {
	ApplVar.ErrorNumber=ERROR_ID(CWXXI09);
	return 0;
    }
    return 1;
}

void ClearPb()
{
    if (!BIT(PBINFO,BIT3)) /* if split and new system */
    {
		PbTotal(ApplVar.PbNumber, 0);       /* read total */
		if (ApplVar.FSplit)
		{
		    ApplVar.Amt = ApplVar.SubTotal;
		    Subtract(&ApplVar.PB.Amt, &ApplVar.Amt);
		    Subtract(&ApplVar.PB.Disc1, &ApplVar.DiscItem[0]);
		    Subtract(&ApplVar.PB.Disc2, &ApplVar.DiscItem[1]);
		    PbTotal(ApplVar.PbNumber, 1);   /* write new total */
		    ApplVar.FSplit = 0; /* reset otherwise checkout not added */
		    ApplVar.BufKp = 0;      /* don't print on ApplVar.KP */
		}
		else
		{
		    ApplVar.Amt = ApplVar.PB.Amt;
		    Add(&ApplVar.SaleAmt, &ApplVar.PB.Amt);
		    Add(&ApplVar.SubTotal, &ApplVar.PB.Amt);
		    Add(&ApplVar.DiscItem[0], &ApplVar.PB.Disc1);
		    Add(&ApplVar.DiscItem[1], &ApplVar.PB.Disc2);
		    PbTotal(ApplVar.PbNumber, 2);       /* reset total */
		}
	}
    else
	{
		PbTotal(ApplVar.PbNumber, 2);       /* reset total */
	}
    ApplVar.FPb = 0;
}

void PrintNewBal()
{
	BCD amt;

    if (BIT(PBPRINT,BIT2))   /* print new balance */
    {
		ApplVar.PrintLayOut = ApplVar.PbF.Print & 0x0b;  /* set slip & R&J */
		amt = ApplVar.PB.Amt;
		AmtRound(0, &amt);              /* Sales Amount rounding */
		PrintAmt(Prompt.Caption[ItemPrompt30], &amt);
    }
}


void PbFunction()
{

#if(DD_FISPRINTER || DD_DISABLEPBF)
    return;
#else
    BYTE type;
    BYTE autochk;
    BYTE ENP = 1,SPFG;
    WORD tBlock;

    if (ApplVar.AP.Pb.NumberOfPb<2 || ApplVar.AP.Pb.Number<2)//ccr20130911
        return;//ccr2017-05-19��ֹ��������

    ApplVar.PbFNumber = ApplVar.Key.Code - PBF - 1;
    ApplVar.PrintLayOut = ApplVar.PbF.Print;    /* save previous print */
    if (ApplVar.PbFNumber < ApplVar.AP.Pb.Number)
		ReadPbF();           /* read function */
    else
    {
		ApplVar.ErrorNumber=ERROR_ID(CWXXI42);
		return;
    }
	ApplVar.PBOpenFlag.bit.Confirm	 = 0;
	autochk = 0;
    ApplVar.Qty = ZERO;
    type = ApplVar.PbF.Options & 0x0f;
    if ((ApplVar.FCorr || ApplVar.FRefund) && type != 10)
    {
		ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
		return;
    }
    if (type < 2 && !ApplVar.FPb && !ApplVar.FRegi)
    {
		if (!Appl_EntryCounter)
		{
			if (BIT(PBPRINT, BIT7) && (ApplVar.AP.Pb.Random & 0x0f))    /* Auto Check Number ? */
			{
				//if (!ApplVar.AutoCheck.l && ApplVar.AutoCheck.h)
				if (!(ApplVar.AutoCheck & 0xffff) && (ApplVar.AutoCheck & 0xffff0000))
					ApplVar.AutoCheck = 1 ;
                ApplVar.Entry = ZERO;//ccr20120101
				ULongToBCDValue(ApplVar.Entry.Value, ApplVar.AutoCheck);
				Appl_EntryCounter = 5;
				autochk = 1;
			}
			else if (BIT(ApplVar.PbF.Options, BIT5))
			{
				if (!BIT(ApplVar.FNoPb, BIT0) && BIT(KPPRICE, BIT4))
					PrintHeader();
			    SETBIT(ApplVar.FNoPb, BIT0);  /* set disable ApplVar.PB compulsion for 1 transaction */
				return;
			}
		}
    }
    if (!type && !Appl_EntryCounter)  /* OPEN without entry then service */
		type = 2;
    else if (ApplVar.TaxPerm)
    {
		ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
		return;
    }

#if defined(FISCAL)
	ApplVar.FStatus = 0; //ccr091201
#endif
    switch(type) {
	case 0:     /* open ApplVar.PB and feed if already open */
		ApplVar.PBOpenFlag.bit.Print = 0;
		ApplVar.PBOpenFlag.bit.FirstOpen = 0;
	case 1:
	case 4:     /* Print Pb */
	case 5:     /* print pb and release */
	case 7:     /* split bill */
	    if (!Appl_EntryCounter)
	    {
			ApplVar.ErrorNumber=ERROR_ID(CWXXI10);
			break;
	    }
	    else if (ApplVar.FPb)
	    {
			ApplVar.ErrorNumber=ERROR_ID(CWXXI08);
			break;
	    }
	    else if (ApplVar.FRegi)
	    {
			ApplVar.ErrorNumber=ERROR_ID(CWXXI14);
			break;
	    }
	    if(!GetPbNumber())
			break;
	    PbTotal(Appl_NumberEntry, 0);   /* read pb total */
	    if (type > 1)      /* print or split ? */
	    {
			if (!ApplVar.AP.StartAddress[AddrTrack])    /* no track buffer */
			{
			    ApplVar.ErrorNumber=ERROR_ID(CWXXI45);
			    return;
			}
			if (!ApplVar.PB.Block && !ApplVar.FProforma)  /* pb open ? */
			{
			    /* if proforma and print bill then also when not open */
			    ApplVar.ErrorNumber=ERROR_ID(CWXXI11);
			    return;
			}
			if (type != 7 && ApplVar.PB.Lines &&
			   (BIT(PBPRINT,BIT0) && ApplVar.CentralLock != MG))   /* already printed ? */
			{
			    ApplVar.ErrorNumber=ERROR_ID(CWXXI28);
			    return;
			}
//			ApplVar.PB.Lines = 0;   /* always print */
	    }

	    ApplVar.PrintLayOut = ApplVar.PbF.Print;
	    if (ApplVar.PB.Lines && BIT(PBPRINT,BIT1))   /*already printed then insert bill */
			ApplVar.PrintLayOut |= 0x10;     /* set slip compulsory */
	    if (BIT(CLERKFIX, BIT1) && ApplVar.PB.Block && ApplVar.PB.Clerk != ApplVar.ClerkNumber)
	    {
			ApplVar.ErrorNumber=ERROR_ID(CWXXI25);
			return;
	    }
	    if (type == 4 || type == 7)   /* print not SI or split */
	    {
			if (BIT(ApplVar.PbF.Options, BIT4))     /* Invoice# PBtrail ? */
			{
			    if (StorePbInvoice(1))
					return;     /* buffer full */
			    SETBIT(ApplVar.FNoPb, BIT2);
			}
	    }
	    ApplVar.FPb = 1;        /* indicate ApplVar.PB incase no receipt# increment */
	    if(!BIT(PBPRINT, BIT4) && !((type == 4  && ApplVar.PB.Block) || type == 5 || type == 7))// ccr 040727
        	SETMyFlags( CLOSEPRNONPB);//��̨��ӡ:????

        if (RegiInit())
	    {
			ApplVar.FPb = 0;
        	CLRMyFlags( CLOSEPRNONPB);// ccr 040727
			RESETBIT(ApplVar.FNoPb, BIT2);
			return;
	    }
	    ApplVar.FPb = 0;
	    if (type != 5)
	    {
			if (BIT(PBINFO, BIT1))      /* display amount ? */
			{
				ApplVar.Amt = ApplVar.PB.Amt;
				AmtRound(0, &ApplVar.Amt);              /*    total sales rounding     */
#if(DD_ZIP==1)//ccr091130>>>>>>>>>
				memset(SysBuf,' ',DISLEN);SysBuf[DISLEN]=0;
				CopyFrStr(SysBuf, DText[DTEXT_TABLE]);
				WORDtoASC(SysBuf+DISLEN-1,Appl_NumberEntry);
		    	PutsO(SysBuf);
		    	Puts1(DispAmtStr(0, &ApplVar.Amt,DISLEN));
#elif(DD_ZIP_21==1)
				memset(SysBuf,' ',DISLEN);SysBuf[DISLEN]=0;
				CopyFrStr(SysBuf, DText[DTEXT_TABLE]);
				WORDtoASC(SysBuf+DISLEN-1,Appl_NumberEntry);
		    	PutsO(SysBuf);
		    	Puts1(DispAmtStr(0, &ApplVar.Amt,DISLEN));
				if (SysBuf[sizeof(SysBuf)- DISLENC + 3]==' ')
					CopyFrStr(&SysBuf[sizeof(SysBuf)- DISLENC], CusDText[ItemDTextTOT]);
				PutsC(&SysBuf[sizeof(SysBuf)- DISLENC]);
#else
		    	PutsO(DispAmtStr(DText[DTEXT_TOTAL], &ApplVar.Amt,DISLEN));
#endif//<<<<<<<<<<<<<<<<<<
			}
			else
			{
#if(DD_ZIP==1)//ccr091130>>>>>>>>>
				memset(SysBuf,' ',DISLEN);SysBuf[DISLEN]=0;
				CopyFrStr(SysBuf, DText[DTEXT_TABLE]);
				WORDtoASC(SysBuf+DISLEN-1,Appl_NumberEntry);
		    	PutsO(SysBuf);
		    	Puts1(DispQtyStr(0, &ApplVar.Entry,DISLEN));
#elif(DD_ZIP_21==1)
				memset(SysBuf,' ',DISLEN);SysBuf[DISLEN]=0;
				CopyFrStr(SysBuf, DText[DTEXT_TABLE]);
				WORDtoASC(SysBuf+DISLEN-1,Appl_NumberEntry);
		    	PutsO(SysBuf);
		    	Puts1(DispQtyStr(0, &ApplVar.Entry,DISLEN));
				if (SysBuf[sizeof(SysBuf)- DISLENC + 3]==' ')
					CopyFrStr(&SysBuf[sizeof(SysBuf)- DISLENC], CusDText[ItemDTextTOT]);
				PutsC(&SysBuf[sizeof(SysBuf)- DISLENC]);
#else
		    	PutsO(DispQtyStr(DText[DTEXT_TOTAL], &ApplVar.Entry,DISLEN));
#endif//<<<<<<<<<<<<<<
			}
#if(CASE_RAMBILL)
			Collect_Data(PBOPENLOG);
#endif
	    }
	    else
			RESETBIT(ARROWS, BIT1);
	    if (BIT(KPPRICE, BIT4)
		    && type > 1
			&& BIT(ApplVar.PrintLayOut, BIT1)) /* print or split function ? */
			PrintHeader();

		if (type < 2 && ApplVar.FNFolio)                /* new folio key used ? */
		{
			ApplVar.PB.Lines = 0;
	   		PrintPbHeader();
			if (ApplVar.PB.Block)
				PrintAmt(Prompt.Caption[ItemPrompt30], &ApplVar.PB.Amt);     /* balance */
		}
		else
			PrintPbHeader();
	    if (ApplVar.FCanc == 1)
			PrintMessage(57);
	    StoreInBuffer();
	    ApplVar.PbNumber = Appl_NumberEntry;
	    ApplVar.Amt = ZERO;
	    if (type == 4 || type == 5 || type == 7)  /* print or split */
	    {
			if (BIT(ApplVar.PbF.Options, BIT7))
			    ApplVar.FNoTime = 1;    /* set don't print time */
	    }
	    if ((type == 4  && ApplVar.PB.Block) || type == 5)  /* print ? */
	    {   /* only print total with 4 (not SI) when bill available */

			SPFG = ApplVar.PrintLayOut;
			RESETBIT(ApplVar.PrintLayOut, BIT3);	  //20040326
			if (ApplVar.PB.Covers)
			{
			    WORDtoBCD(ApplVar.Amt.Value, ApplVar.PB.Covers);
			    PrintQty(Prompt.Caption[ItemPrompt40], &ApplVar.Amt);
	    		PrintLine('=');
			}
			if (type == 4)
			{
    			ApplVar.PBOpenFlag.bit.Print = 1;

				if ((FLAGPRNLOGO && ApplVar.Graph[0].PictNo && ApplVar.Graph[0].PictNo<=GRAPHICMAX) && !MyFlags( CLOSEPRNONPB+CLOSEPRINT))
				{//=1ʱ��Ϊ�û��Զ���ͼƬ
					Bios(BiosCmd_PrintGraph, (void*)(ApplVar.Graph[0].PictNo), 1 , 0); //Stampa msg ram
			    	PrintLine('=');
				}
#if (!defined(CASE_EURO))
			    PrintStr(Prompt.Title);
#endif
	    		PrintLine('-');

	    	}
			ProcessPbBuffer(0);     /* print buffer */ //@@@@@@@@@@@@@@
			ApplVar.PrintLayOut &= 0xdf;    /* reset two line */
			ApplVar.FSale = 1;
#if (defined(CASE_EURO))
			ApplVar.SubTotal = ApplVar.SaleAmt;
#endif
			RegiEnd(true);
			ApplVar.FSale = 0;
			if (!BIT(PBINFO, BIT3)) /* only without check-out system */
			{
			    SETBIT(ApplVar.PrintLayOut, BIT2);  /* double size */
			    ApplVar.SlipDouble = 1;
			}
			AmtRound(0, &ApplVar.SubTotal);         /* total sales rounding */
			if(type == 5)
				PrintAmt(Prompt.Caption[ItemPrompt0], &ApplVar.SubTotal);
			RESETBIT(ApplVar.PrintLayOut, BIT2);
			if (PVAT)       /* print VAT ? */
			    CalculateTax(3);
			if (type == 5)  /* single item */
			{
			    ApplVar.FRegi = 0;
			    ReceiptIssue(BIT(ApplVar.PbF.Options, BIT4) ? 1 : 0); /* print time date ? */
//			    if (ApplVar.SlipLines > 1)
//				ApplVar.PB.Lines = ApplVar.SlipLines - 1;	//040329
			    ApplVar.PB.Clerk = ApplVar.ClerkNumber;
			    PbTotal(ApplVar.PbNumber, 1);   /* write line count */
			    ApplVar.FPb = 0;
			    ApplVar.PbNumber = 0;
			    ApplVar.FNoPb = 0;
                CLRMyFlags(OPENRECEIPT);//ccr2017-05-23
			}
            else
			{
//ccr091210			    MemSet(ApplVar.TaxItem, sizeof(ApplVar.TaxItem), 0);     //@@@@@@@@@@@
			    ApplVar.SaleAmt = ZERO;
			}
	   		ApplVar.PrintLayOut = SPFG;	 //20040326
	    }
	    ApplVar.RGRec.Key.Code = ApplVar.Key.Code;
	    ApplVar.RGRec.Amt = ApplVar.Entry;
	    *((WORD *) ApplVar.RGRec.Qty.Value) = ApplVar.PbNumber;
	    if (type == 7)      /* split ?*/
	    {
			ApplVar.FSplit = 1;
			PrintMessage(38);
	    }
	    if (type < 2 && BIT(ApplVar.PbF.Options, BIT6)) /* NO tender allowed */
	    {
			if (!ApplVar.PB.Lines && !ApplVar.SlipLines)    /* bill not printed yet */
			    SETBIT(ApplVar.FNoPb, BIT1);
	    }
		if (autochk)
		{
			ApplVar.AutoCheck++;
		}

#if defined(FISCAL)
		if (type == 4)
        {
			ApplVar.PBOpenFlag.bit.FirstOpen = 1;
        }
#endif

	    break;
	case 2:     /* service */

#if (pbAmtDisc)
		ApplVar.LastKey=ApplVar.RGRec.Key.Code;//ccr091210 �������۵��������һ�����۵ĵ�Ʒ����Ĺ�����() //
#endif

	    RESETBIT(ApplVar.PrintLayOut, BIT3);//20040326
	    SysBuf[0] = ApplVar.PbF.Print;
	    ApplVar.PbF.Print = ApplVar.PrintLayOut;        /* print of open function */
	    ApplVar.PrintLayOut = SysBuf[0] & ApplVar.PbF.Print;    /* print of service */
	    if (Appl_EntryCounter)
			ApplVar.ErrorNumber=ERROR_ID(CWXXI04);
	    else if (!ApplVar.FPb)
			ApplVar.ErrorNumber=ERROR_ID(CWXXI10);
	    else if (ApplVar.FSplit)
			ApplVar.ErrorNumber=ERROR_ID(CWXXI21);
	    else
	    {
			ApplVar.SubTotal = ApplVar.SaleAmt;//ccr091210 CalculateTax(0);        /* add and report */  //@@@@@@@@@@@@@@@
			RESETBIT(ARROWS, BIT1);
#if(DD_ZIP==1)//ccr091130>>>>>>>>>
				memset(SysBuf,' ',DISLEN);SysBuf[DISLEN]=0;
				CopyFrStr(SysBuf, DText[DTEXT_SRVICE]);
				WORDtoASC(SysBuf+DISLEN-1,ApplVar.PbNumber);
		    	PutsO(SysBuf);
		    	Puts1(DispAmtStr(0, &ApplVar.SubTotal,DISLEN));
#elif(DD_ZIP_21==1)
				memset(SysBuf,' ',DISLEN);SysBuf[DISLEN]=0;
				CopyFrStr(SysBuf, DText[DTEXT_SRVICE]);
				WORDtoASC(SysBuf+DISLEN-1,ApplVar.PbNumber);
		    	PutsO(SysBuf);
		    	Puts1(DispAmtStr(0, &ApplVar.SubTotal,DISLEN));
				if (SysBuf[sizeof(SysBuf)- DISLENC + 3]==' ')
					CopyFrStr(&SysBuf[sizeof(SysBuf)- DISLENC], CusDText[ItemDTextTOT]);
				PutsC(&SysBuf[sizeof(SysBuf)- DISLENC]);
#else
			PutsO(DispAmtStr(DText[DTEXT_SRVICE], &ApplVar.SubTotal,DISLEN));
#endif//<<<<<<<<<<<<
			if (ApplVar.FRecIssue)
			{
			    NewReceipt();
			    RESETBIT(ApplVar.PrintLayOut, BIT1);
			}
			ApplVar.FRecIssue = 0;
			StoreInBuffer();
			RegiEnd(true);
			ApplVar.Amt = ApplVar.SubTotal;
			ApplVar.RGRec.Key.Code = 299;    /* subtotal */
			StoreInBuffer();
		    PrintAmt(ApplVar.PbF.Name, &ApplVar.Amt);
			ApplVar.RGRec.Key.Code = ApplVar.Key.Code;
			ApplVar.RGRec.Qty = ZERO;
			ApplVar.RGRec.Amt = ApplVar.Amt;
			StoreInBuffer();
			ApplVar.FRegi = 0;
			PbTotal(ApplVar.PbNumber, 0);   /* read current total */
			ApplVar.PB.Clerk = ApplVar.ClerkNumber;
//ccr091125PB.SalPer?			ApplVar.PB.SalPer =	ApplVar.SalPerNumber;
			Add(&ApplVar.PB.Amt, &ApplVar.Amt);     /* add total */
			Add(&ApplVar.PB.Disc1, &ApplVar.DiscItem[0]);     /* add discount total */
			Add(&ApplVar.PB.Disc2, &ApplVar.DiscItem[1]);     /* add discount total */
#if(CASE_RAMBILL)
			Collect_Data(PBCLOSELOG);
 #endif
			PrintNewBal();
			PrintSaleQty();
			ApplVar.FNoPb = 0;      /* reset Invoice number */
     		ReceiptIssue(BIT(ApplVar.PbF.Options, BIT4) ? 1 : 0); /* print time date ? */

			if (ApplVar.SlipLines > 1)      /*  */
			    ApplVar.PB.Lines = ApplVar.SlipLines - 1;
			else
			    ApplVar.PB.Lines = 0;
			if (!ApplVar.AP.StartAddress[AddrTrack] && ApplVar.FSale)   /* no track buffer and sale */
//			if (ApplVar.FSale)   /* no track buffer and sale */
			    ApplVar.PB.Block = 1;       /* then indicate used */
			PbTotal(ApplVar.PbNumber, 1);   /* write new total */
			AddPbFTotal();
					ApplVar.FSale = 0;
			ApplVar.BufCC = 1;                 /* set add Customer Count */
			ApplVar.BufKp = 1;
			ProcessBuffer();    /* reset Customer count and print kp*/
			if (BIT(PBPRINT,BIT6))//ccr040810
			{
				ApplVar.BufCC = 1;                 /* set add Customer Count */
				ApplVar.BufKp = 1;
				ProcessBuffer();    /* reset Customer count and print kp*/
			}
			ApplVar.FPb = 0;
			ApplVar.PbNumber = 0;
            CLRMyFlags(OPENRECEIPT);//ccr2017-05-23

	    }
	    CLRMyFlags( CLOSEPRNONPB);  // lyq added 20040224
		ApplVar.PBOpenFlag.bit.Print = 0;
		ApplVar.PBOpenFlag.bit.Confirm = 0;
	    break;
	case 3:     /*    check out     */
#if defined(FISCAL)
		if(! ApplVar.PBOpenFlag.bit.FirstOpen)
		{// ��̨�������,�����ȴ�ӡ��̨����ܽ���,Ŀ���Ǳ�֤��˰�վݵ������� //
			ApplVar.ErrorNumber=CWXXI01;
			break;
		}
#endif//

		if(!MyFlags( CLOSEPRNONPB))
			ENP = 1;
		else
		{
			ENP = 0;
			CLRMyFlags( CLOSEPRNONPB);	  //  |
		}		  						  //  |___>// lyq added 20040224
	case 6:
	    if (!BIT(PBINFO,BIT3))
			ApplVar.ErrorNumber=ERROR_ID(CWXXI42);        /* not allowed with new system */
	    else if (!ApplVar.PbNumber)
			ApplVar.ErrorNumber=ERROR_ID(CWXXI10);
	    else if (Appl_EntryCounter)
			ApplVar.ErrorNumber=ERROR_ID(CWXXI04);
	    else if (type == 3 && !ApplVar.FPb)
			ApplVar.ErrorNumber=ERROR_ID(CWXXI19);
	    else if (type == 6 && ApplVar.FPb)
			ApplVar.ErrorNumber=ERROR_ID(CWXXI22);
	    else
	    {
#if defined(FISCAL)//ccr091201>>>>>>
			if (type == 3)
			{
				ApplVar.PBOpenFlag.bit.Confirm = 1;
				ApplVar.FStatus = 1;
				AddReceiptNumber();//ccr2017-04-25?????
				ApplVar.SaleReceipts++;
			}
			else
			{
				if (!ApplVar.FTrain)
                {
					ApplVar.SaleReceipts--;
					ApplVar.FisNumber.ReceiptNum[FRECEIPTS]--;//ApplVar.SaleReceipts
            		ApplVar.FisNumber.TotalReceiptNum[FRECEIPTS]--;
                }
			}
#endif//<<<<<<<<<<<
			ApplVar.PrintLayOut &= ApplVar.PbF.Print;   /* and open ApplVar.PB print */
			PbTotal(ApplVar.PbNumber, 0);       /* read total */
			if (ApplVar.FSplit)
			{
			    RegiEnd(true);
				ApplVar.FSale = 0;
			    ApplVar.Amt = ApplVar.SubTotal;
//ccr100513 Split			    Subtract(&ApplVar.PB.Amt, &ApplVar.Amt);
			    Subtract(&ApplVar.PB.Amt, &ApplVar.SaleAmt);//ccr100513 Split
			    Subtract(&ApplVar.PB.Disc1, &ApplVar.DiscItem[0]);
			    Subtract(&ApplVar.PB.Disc2, &ApplVar.DiscItem[1]);
			    PbTotal(ApplVar.PbNumber, 1);   /* write new total */
			    ApplVar.FSplit = 0;
			    ApplVar.PbNumber = 0;
				AmtRound(0, &ApplVar.Amt);              /* Sales Amount rounding */
			    PrintAmt(Prompt.Caption[ItemPrompt0], &ApplVar.Amt);
//ccr100513 Split			    ApplVar.SaleAmt = ApplVar.Amt;
			    if (PVAT)
			    {
					CalculateTax(3);        /* print VAT */
					ApplVar.Amt = ApplVar.SaleAmt;          /* restore amount */
			    }
//ccr100511			    MemSet(ApplVar.TaxItem, sizeof(ApplVar.TaxItem), 0);
			    ApplVar.RGNumber = 2;
			}
			else
			{
			    StoreInBuffer();
			    ApplVar.Amt = ApplVar.PB.Amt;
			    AmtRound(0, &ApplVar.Amt);              /* Sales Amount rounding */
/* JB Modify */
/*                    ApplVar.DiscItem[0] = ApplVar.PB.Disc1;
		    ApplVar.DiscItem[1] = ApplVar.PB.Disc2;      */
			    if (type == 6)   /* cancel pay */
					ApplVar.Amt.Sign ^= 0x80;
			    Add(&ApplVar.SaleAmt, &ApplVar.Amt);
				ApplVar.Amt = ApplVar.SaleAmt;
			}
			if (type == 3)
			{

#if(DD_ZIP==1)//ccr091130>>>>>>>>>
				memset(SysBuf,' ',DISLEN);SysBuf[DISLEN]=0;
				CopyFrStr(SysBuf, DText[DTEXT_CHKPAID]);
				WORDtoASC(SysBuf+DISLEN-1,ApplVar.PbNumber);
		    	PutsO(SysBuf);
		    	Puts1(DispAmtStr(0, &ApplVar.Amt,DISLEN));
#elif(DD_ZIP_21==1)
				memset(SysBuf,' ',DISLEN);SysBuf[DISLEN]=0;
				CopyFrStr(SysBuf, DText[DTEXT_CHKPAID]);
				WORDtoASC(SysBuf+DISLEN-1,ApplVar.PbNumber);
		    	PutsO(SysBuf);

		    	Puts1(DispAmtStr(0, &ApplVar.Amt,DISLEN));
				if (SysBuf[sizeof(SysBuf)- DISLENC + 3]==' ')
					CopyFrStr(&SysBuf[sizeof(SysBuf)- DISLENC], CusDText[ItemDTextTOT]);
				PutsC(&SysBuf[sizeof(SysBuf)- DISLENC]);
#else
			    PutsO(DispAmtStr(DText[DTEXT_CHKPAID], &ApplVar.Amt,DISLEN));
#endif//<<<<<<<<<<<<
			    ApplVar.FPb = 0;
			}
			else
			{
#if(DD_ZIP==1)//ccr091130>>>>>>>>>

				memset(SysBuf,' ',DISLEN);SysBuf[DISLEN]=0;
				CopyFrStr(SysBuf, DText[DTEXT_CHKCANCEL]);
				WORDtoASC(SysBuf+DISLEN-1,ApplVar.PbNumber);
		    	PutsO(SysBuf);
		    	Puts1(DispAmtStr(0, &ApplVar.Amt,DISLEN));
#elif(DD_ZIP_21==1)
				memset(SysBuf,' ',DISLEN);SysBuf[DISLEN]=0;
				CopyFrStr(SysBuf, DText[DTEXT_CHKCANCEL]);
				WORDtoASC(SysBuf+DISLEN-1,ApplVar.PbNumber);
		    	PutsO(SysBuf);
		    	Puts1(DispAmtStr(0, &ApplVar.Amt,DISLEN));
				if (SysBuf[sizeof(SysBuf)- DISLENC + 3]==' ')
					CopyFrStr(&SysBuf[sizeof(SysBuf)- DISLENC], CusDText[ItemDTextTOT]);
				PutsC(&SysBuf[sizeof(SysBuf)- DISLENC]);

#else
			    PutsO(DispAmtStr(DText[DTEXT_CHKCANCEL], &ApplVar.Amt,DISLEN));
#endif//<<<<<<<<<<<<
			    ApplVar.FPb = 1;
			}
			if(type ==3 && ENP == 0)	 //lyq added 20040224 ,added enp varialbe
			{
				SETBIT(ApplVar.PrintLayOut, BIT2);
				ApplVar.Entry = ZERO;
				ULongToBCDValue(ApplVar.Entry.Value, ApplVar.PbNumber);
				PrintQty(Prompt.Caption[ItemPrompt23], &ApplVar.Entry);
				RESETBIT(ApplVar.PrintLayOut, BIT2);
				PrintLine('=');
			}
			ApplVar.RGRec.Amt = ApplVar.Amt;
			ApplVar.RGRec.Key.Code = ApplVar.Key.Code;
			SPFG = ApplVar.PrintLayOut;		   //
			RESETBIT(ApplVar.PrintLayOut, BIT3);//20040326
			PrintAmt(ApplVar.PbF.Name, &ApplVar.Amt);
			ApplVar.PrintLayOut = SPFG;		  //20040326
			if(type == 6)				 //lyq added 2003\11\1
				ApplVar.Amt.Sign ^= 0x80;
			AddPbFTotal();
			RESETBIT(ApplVar.FNoPb, BIT0+BIT1);      /* reset no tender */
	    }

	    break;
	case 8:     /* transfer table */
	case 11:	// combine table  //liuj 0716
	    if (!ApplVar.FPb)
	    {
			ApplVar.ErrorNumber=ERROR_ID(CWXXI10);
			break;
	    }
	    else if (ApplVar.FSplit)
	    {
			ApplVar.ErrorNumber=ERROR_ID(CWXXI29);
			break;
	    }
	    else if (!Appl_EntryCounter || ApplVar.FProforma)
	    {
			ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
			break;
	    }
	    else if (!GetPbNumber())
			break;
//liuj 0716 for combine
	  if (type == 11 )  /* pb open ? */
			{
				GetPbtOffSet(Appl_NumberEntry -1 );
				ReadRam((BYTE *)&tBlock, sizeof(ApplVar.PB.Block));   /* read start block */
			   if(!tBlock && !ApplVar.FProforma)
			   	{
			    /* if proforma and print bill then also when not open */
			  	  ApplVar.ErrorNumber=ERROR_ID(CWXXI11);
				    return;
			   	}
			}
//liuj 0716 for combine
	    if (Appl_NumberEntry == ApplVar.PbNumber)    /* transfer to same table */
	    {
			ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
			break;
	    }
	    PbTotal(Appl_NumberEntry, 0);   /* read new pb total */
	    if (ApplVar.PB.Block)  /* pb  open ? */
	    {
			if (BIT(ApplVar.PbF.Options, BIT4)) /* open allowed ? */
			{
			    ApplVar.ErrorNumber=ERROR_ID(CWXXI08);   /* already open */
			    break;
			}
			if (BIT(ApplVar.PbF.Options, BIT5) && ApplVar.ClerkNumber != ApplVar.PB.Clerk) /* other clerk allowed ? */
			{
			    ApplVar.ErrorNumber=ERROR_ID(CWXXI25);   /* wrong clerk */
			    break;
			}
			if (ApplVar.FSale && ApplVar.ClerkNumber != ApplVar.PB.Clerk)
			{
			    ApplVar.ErrorNumber=ERROR_ID(CWXXI14);   /* already in sale */
			    break;
			}
			PbTotal(ApplVar.PbNumber, 0);   /* read old */

			ProcessPbBuffer(Appl_NumberEntry);   /* transfer records */
			if (ApplVar.ErrorNumber)
			    break;
			PbTotal(ApplVar.PbNumber, 0);   /* read old */
			ApplVar.Amt = ApplVar.PB.Amt;
			ApplVar.DiscItem[0] = ApplVar.PB.Disc1;
			ApplVar.DiscItem[1] = ApplVar.PB.Disc2;
			type = ApplVar.PB.Covers;
			PbTotal(Appl_NumberEntry, 0);   /* read new */
			ApplVar.PB.Lines = 0;   /* reset printed */
			Add(&ApplVar.PB.Amt, &ApplVar.Amt);
			Add(&ApplVar.PB.Disc1, &ApplVar.DiscItem[0]);
			Add(&ApplVar.PB.Disc2, &ApplVar.DiscItem[1]);
/* JB Modify */
			ApplVar.DiscItem[0] = ZERO;
			ApplVar.DiscItem[1] = ZERO;

			ApplVar.PB.Covers += type;
	    }
	    else
	    {
			PbTotal(ApplVar.PbNumber, 0);   /* read old */
			ApplVar.PB.Clerk = ApplVar.ClerkNumber; /* current clerk */
	    }
#if(CASE_RAMBILL)
		Collect_Data(TRTABLELOG);
#endif
	    ApplVar.PrintLayOut &= ApplVar.PbF.Print;   /*    and open ApplVar.PB print     */

	    if (ApplVar.PB.Clerk != ApplVar.ClerkNumber)
			PrintStr(ApplVar.Clerk.Name);
	    PrintMessage(42);
	    PrintQty(Prompt.Caption[ItemPrompt23], &ApplVar.Entry);
	    PbTotal(Appl_NumberEntry, 1);    /* write new */
	    PbTotal(Appl_NumberEntry, 0);   /* read new for ApplVar.PB text */
	    if (ApplVar.AP.Pb.Text)
			PrintStr(ApplVar.PB.Text);
	    MemSet(&ApplVar.PB, sizeof(ApplVar.PB), 0);
	    PbTotal(ApplVar.PbNumber, 1);    /* reset old */
	    ApplVar.PbNumber = Appl_NumberEntry;
	    PbTotal(ApplVar.PbNumber, 0);   /* read new */
	    StoreInBuffer();
	    ApplVar.RGRec.Key.Code = ApplVar.Key.Code;
	    ApplVar.RGRec.Amt = ApplVar.Entry;
	    ApplVar.RGRec.Qty = ZERO;
	    if (ApplVar.PB.Clerk != ApplVar.ClerkNumber)
	    {
			ApplVar.Amt.Sign ^= 0x80;       /* invert sign */
			AddPbFTotal();
			Appl_NumberEntry = ApplVar.ClerkNumber;      /* save active clerk */
			ApplVar.ClerkNumber = ApplVar.PB.Clerk;
			ReadClerk();
			PrintStr(ApplVar.Clerk.Name);
			ApplVar.Amt.Sign ^= 0x80;       /* invert sign back */
			AddPbFTotal();          /* add in transfer total */
			ApplVar.ClerkNumber = Appl_NumberEntry;
			ReadClerk();
			SPFG = ApplVar.PrintLayOut;		   //
			RESETBIT(ApplVar.PrintLayOut, BIT3);//20040326
			PrintAmt(ApplVar.PbF.Name, &ApplVar.Amt);
			ApplVar.PrintLayOut = SPFG;		  //20040326
			StoreInBuffer();
			ApplVar.FRegi = 0;
			ReceiptIssue(1);

			ApplVar.BufCC = 1;
			ProcessBuffer();
			ApplVar.FPb = 0;
			ApplVar.PbNumber = 0;
            CLRMyFlags(OPENRECEIPT);//ccr2017-05-23

	    }
	    break;
	case 9:     /* transfer clerk when pb open only 1 pb else all */
	    if (!Appl_EntryCounter || Appl_EntryCounter > 3 || ApplVar.FProforma)
	    {
			ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
			break;
	    }
	    if (!Appl_NumberEntry || Appl_NumberEntry > ApplVar.AP.Clerk.Number)
	    {
			ApplVar.ErrorNumber=ERROR_ID(CWXXI24);
			break;
	    }
	    ApplVar.Amt = ZERO;
	    if (ApplVar.FPb)
	    {
			if (ApplVar.FSplit)
			{
			    ApplVar.ErrorNumber=ERROR_ID(CWXXI29);
			    break;
			}
			if (ApplVar.FSale)  /* already in transaction */
			{
			    ApplVar.ErrorNumber=ERROR_ID(CWXXI14);
			    break;
			}
			ApplVar.PrintLayOut &= ApplVar.PbF.Print;
			PbTotal(ApplVar.PbNumber, 0);   /* read new */
			ApplVar.PB.Clerk = Appl_NumberEntry;
			PbTotal(ApplVar.PbNumber, 1);   /* write back */
			ApplVar.Amt = ApplVar.PB.Amt;
	    }
	    else
	    {
			ApplVar.PrintLayOut = ApplVar.PbF.Print;
			ApplVar.FPb = 1;
			if (RegiStart())
			{
    	    	CLRMyFlags( CLOSEPRNONPB);// |
			    ApplVar.FPb = 0;
			    return;  /* check if start of registration */
			}
			for (ApplVar.PbNumber = 1; ApplVar.PbNumber <= ApplVar.AP.Pb.NumberOfPb; ApplVar.PbNumber++)
			{
			    PbTotal(ApplVar.PbNumber, 0);   /* read new */
			    if (ApplVar.PB.Clerk == ApplVar.ClerkNumber)
			    {
					ApplVar.PB.Clerk = Appl_NumberEntry;
					PbTotal(ApplVar.PbNumber, 1);   /* write back */
					Add(&ApplVar.Amt, &ApplVar.PB.Amt);
					if (ApplVar.AP.Pb.Random & 0x0f)
					    memcpy(ApplVar.Entry.Value, ApplVar.PB.Random, 7);
					else
					    WORDtoBCD(ApplVar.Entry.Value, ApplVar.PbNumber);
					PrintQty(Prompt.Caption[ItemPrompt23], &ApplVar.Entry);
					if (ApplVar.AP.Pb.Text)
					    PrintStr(ApplVar.PB.Text);
			    }
			}
			ApplVar.PB.Clerk = Appl_NumberEntry;
	    }
	    PrintMessage(42);
	    ApplVar.Amt.Sign ^= 0x80;       /* invert sign */
	    AddPbFTotal();
	    Appl_NumberEntry = ApplVar.ClerkNumber;      /* save active clerk */
	    ApplVar.ClerkNumber = ApplVar.PB.Clerk;
	    ReadClerk();
	    PrintStr(ApplVar.Clerk.Name);
	    ApplVar.Amt.Sign ^= 0x80;       /* invert sign back */
	    AddPbFTotal();          /* add in transfer total */
	    ApplVar.ClerkNumber = Appl_NumberEntry;
	    ReadClerk();
	    PrintAmt(ApplVar.PbF.Name, &ApplVar.Amt);
	    ApplVar.FRegi = 0;
	    ReceiptIssue(1);
	    ApplVar.BufCC = 1;
	    AddPbFTotal();
	    Appl_NumberEntry = ApplVar.ClerkNumber;      /* save active clerk */
	    ApplVar.ClerkNumber = ApplVar.PB.Clerk;
	    AddPbFTotal();          /* add in transfer total */
/* JB Modify */
	    ReadClerk();
/*            ApplVar.ClerkNumber = Appl_NumberEntry; */

	    ApplVar.FPb = 0;
	    ApplVar.BufCC = 0;
	    ApplVar.PbNumber = 0;
		ApplVar.CopyReceipt = ApplVar.RGNumber = 0;    /* reset trans buffer */
	    break;
	case 10:        /* covers */
	    if (!ApplVar.FPb)
	    {
			ApplVar.ErrorNumber=ERROR_ID(CWXXI10);
			break;
	    }
	    if (!Appl_EntryCounter)
	    {
			ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
			break;
	    }
	    if (ApplVar.FSplit || ApplVar.FCanc || ApplVar.FCorr || ApplVar.FRefund)
			ApplVar.Entry.Sign = 0x80;  /* negativ */
	    if (Appl_EntryCounter > 3 || Appl_NumberEntry > 100)
	    {
			ApplVar.ErrorNumber=ERROR_ID(CWXXI18);
			break;
	    }
	    PbTotal(ApplVar.PbNumber, 0);   /* read pb total */
	    if ((ApplVar.PB.Covers + Appl_NumberEntry) > 255)
	    {
			ApplVar.ErrorNumber=ERROR_ID(CWXXI20);
			break;
	    }
	    if (ApplVar.Entry.Sign & 0x80)
	    {
			if (Appl_NumberEntry > ApplVar.PB.Covers)
			{
			    ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
			    break;
			}
			ApplVar.PB.Covers -= Appl_NumberEntry;
	    }
	    else
			ApplVar.PB.Covers += Appl_NumberEntry;       /*    add covers     */
	    ApplVar.PrintLayOut &= ApplVar.PbF.Print;   /*    and open ApplVar.PB print     */
#if(DD_ZIP==1)//ccr091130>>>>>>>>>
		memset(SysBuf,' ',DISLEN);SysBuf[DISLEN]=0;
		CopyFrStr(SysBuf, DText[DTEXT_GUEST]);
		WORDtoASC(SysBuf+DISLEN-1,ApplVar.PbNumber);
    	PutsO(SysBuf);

    	Puts1(DispAmtStr(0, &ApplVar.Entry,DISLEN));
#elif(DD_ZIP_21==1)
		memset(SysBuf,' ',DISLEN);SysBuf[DISLEN]=0;
		CopyFrStr(SysBuf, DText[DTEXT_GUEST]);
		WORDtoASC(SysBuf+DISLEN-1,ApplVar.PbNumber);
    	PutsO(SysBuf);

    	Puts1(DispAmtStr(0, &ApplVar.Entry,DISLEN));
		if (SysBuf[sizeof(SysBuf)- DISLENC + 3]==' ')
			CopyFrStr(&SysBuf[sizeof(SysBuf)- DISLENC], CusDText[ItemDTextCOV]);
		PutsC(&SysBuf[sizeof(SysBuf)- DISLENC]);
#else
	    PutsO(DispQtyStr(DText[DTEXT_GUEST], &ApplVar.Entry,DISLEN));
#endif//<<<<<<<<<<<<
	    PrintQty(Prompt.Caption[ItemPrompt40], &ApplVar.Entry);
	    PbTotal(ApplVar.PbNumber, 1);   /* write new total */
	    StoreInBuffer();
	    ApplVar.RGRec.Key.Code = ApplVar.Key.Code;
	    ApplVar.RGRec.Amt = ApplVar.Entry;
	    ApplVar.RGRec.Qty = ZERO;
	    ApplVar.Amt = ApplVar.Entry;            /* add in report */
	    AddPbFTotal();
	    ApplVar.FRefund = 0;
	    ApplVar.FCorr = 0;
	    break;
	default:
	    ApplVar.ErrorNumber=ERROR_ID(CWXXI42);
	    break;
    }
    if (ApplVar.ErrorNumber)
    {
		if (ApplVar.RGRec.Key.Code == ApplVar.Key.Code)
		    ApplVar.RGRec.Key.Code = 0;
    }
#endif
}

