#include "king.h"
#include "Release.h"
#include "message.h"

/* comment of Release:
    Release[0..4]:  Type name
    Release[5]:		PRTLEN
    Release[6]:		C-CortexM3
    Release[7]:		E-SD card,P-Print
    Release[8]:		2-IC4442,8-IC4428,M-ICmifare,X-no IC
    Release[9]:		Keyboard type N-7x8,L-7x6,W-8x7,C-6x7
    Release[10]:	N-New MCU,O-Old type MCU,\0-Old verssion
*/


#ifdef CASE_FATFS_EJ
    #define EJ_2		'E'
#else
    #define EJ_2		'P'
#endif

#if (DD_CHIPC==1)
    #if (CASE_MFRIC==1)
        #define MYIC		'M'
    #elif (DD_4442IC==1)
        #define MYIC		'2'
    #else
        #define MYIC		'8'
    #endif
#else
    #define MYIC		'X'
#endif

#define PRNTYPE	'T'

#if defined(FISCAL)
//������˰�ش洢����ʾ����,������00-15�ֽ���
CONST char FMSetCard[17]={FMINITEDFLAG,0xFF,0x55,0xAA,'E','U',',T','R','O','N','T','E','S','T','F','M'};
//˰�ش洢����ʾ����,������00-15�ֽ���
CONST char FirmCode[17] ={FMINITEDFLAG,0xff,0x55,0xaa,0x00,0xff,0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80,0x20,0x20};

#endif


#if (DD_ZIP)
    #define DISPO    '2'
    #define DISPC    '2'
#elif(DD_ZIP_21)
    #define DISPO    '2'
    #define DISPC    '1'
#else
    #define DISPO    '1'
    #define DISPC    '1'
#endif

/* comment of Release:
    Release[0..4]:  Type name
    Release[5]:		PRTLEN
    Release[6]:		M-MMC card,P-Print
    Release[7]:		2-IC4442,8-IC4428,M-ICmifare,X-no IC
    Release[8]:		Lines of operator
    Release[9]:		Lines of Customer
    Release[10~18]:	verssion
    ע�����¸���:
    memcpy(ApplVar.Fis_Header.FRelease,Release,8);
    memcpy(ApplVar.Fis_Header.FRelease+8,Release+10,8);
*/

//Release�ĳ��Ȳ��ó���Fis_Header.FRelease�ĳ���

#ifdef CASE_EURO
CONST char Release[16] = {'F','E','C','R','1','0','0','1',DISPO,DISPC,'V','1','.','0','1',0};

#elif (CASE_PCR01)
CONST char Release[16] = {'P','C','R','1','-',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};

#elif(CASE_ER28S)
CONST char Release[16] = {'E','2','8','S','-',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};

#elif(CASE_ER28T)
CONST char Release[16] = {'E','2','8','T','-',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};

#elif(CASE_ER50)
CONST char Release[16] = {'E','R','5','0','-',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};

#elif(CASE_ER220)
CONST char Release[16] = {'E','2','2','0','-',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};

#elif (defined(CASE_ER100))
CONST char Release[16] = {'E','1','0','0','-',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};

#elif (defined(CASE_ECR100F))
CONST char Release[16] = {'E','1','0','0','F',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};

#elif (CASE_ER260)
CONST char Release[16] = {'E','2','6','0','-',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};

#elif (CASE_ER260F)
CONST char Release[16] = {'E','2','6','0','F',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};

#elif(CASE_WISE158)
CONST char Release[16] = {'W','1','5','8','-',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};

#elif (DD_FISPRINTER)
CONST char Release[16] = {'F','P','8','0','-',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};

#elif (CASE_MCR30)
CONST char Release[16] = {'M','C','R','3','0',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};
#else
CONST char Release[16] = {'M','3','1','5','-',PRTLEN+' ',EJ_2,MYIC,DISPO,DISPC,'0','1','.','0','1',0};
#endif


CONST WORD SORT[] = {17, 9, 5, 3, 2, 1} ;


//cc 2006-07-14 for EN>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

CONST struct APPTEXT DefaultText = {
    {       /* Header[8][37] */
        Header1,
        Header2,
        Header3,
        Header4,
        "",
        "",
        "",
    },

    {    /* ReportType[16][16] */
        ReportType0,    //"  GRAND TOTAL   "//"   ��  ��  ��   "
        ReportType1,    //"  GROUP         "//" ��  ��  ��  �� "//1
        ReportType2,    //"  DEPARTMENT    "//" ��  ��  ��  �� "//2
        ReportType3,    //"  PLU           "//" ��  Ʒ  ��  �� "      /* 3 Used with Plu Report */
        ReportType4,    //"  TENDER        "//" ��  ��  ��  Ϣ "//4
        ReportType5,    //"  PORA          "//" �� �� �� �� Ϣ "//5
        ReportType6,    //"  DRAWER        "//" Ǯ  ��  ��  Ϣ "//6
        ReportType7,    //"  CORRECTION    "//" ��  ��  ��  Ϣ "//7
        ReportType8,    //"  DISCOUNT      "//" ��  ��  ��  Ϣ "//8
        ReportType9,    //"  CURRENCY      "//" ��  ��  ��  Ϣ "//9
        ReportType10,   //"  TAX           "//" ��  ˰  ��  Ϣ "//10
        ReportType11,   //" PB FUNCTIONS   "//" ��  ��  ��  Ϣ "//11
        ReportType12,   //"PREVIOUS BALANCE"//" ��  ̨  ��  Ϣ "//12
        ReportType13,   //"  TABLES        "//" ��  ̨  ��  Ϣ "//13
        ReportType14,   //"  INVENTORY     "//" ��  Ʒ  ��  �� "//14
        ReportType15,   //"  PB INVOICES   "// �������ָʲô? ZWQ û����
        ReportType16,   //"  TENDER BUFFER "// �������ָʲô? ZWQ û����
    },
    {   /* SlipHeader[6][35] */
        "",
        "",
        "",
        "",
        "",
        "",
    },

    {       /* Trailer[6][24] */
        Trailer1,
//Ccr 	"     ~��  ~л  ~��  ~��     ",
        Trailer2,
//Ccr 	"          ~��  ~��         ",
        "",
        "",
        "",
        "",
    },

};


//cc 2006-07-14 for EN>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

CONST struct APPLICATION Default = {
    {   /* FirmKeys[FIRMKEYS],Can't exchange position of the list */
        fCLEAR      ,       // 0,firmkey clear. It must be the first byte!!!!!!.
        fOCPRINTER  ,       // 1,Set Time
        0xff,               //ccr2017-12-18 fDATE ȡ��ID_DATE����,ֱ��ʹ��DATETIME������  , // 2,Display Date
        fREPORT     ,       // 3,ReportList Trigger
        fPRGTYPE    ,       // 4 programming Type key
        fPRGNUM     ,       // 5 Programming number
        fPRGENTER   ,       // 6 programming Enter
        fPRGUP      ,       // 7 Programming UP
        fSYSREP     ,       // 8 system report trigger
        fHARDTEST   ,       // 9 Machine test key
        fDOWN       ,       //10 Dump Program key
        0xff        ,       ////ccr2017-12-15 fSHIFTDEPT 11 Alfa Shift 1 ����ʹ��ID_SHIFTDEPT����,ֱ��ʹ��SHIFT1
        fSHIFTKEY       ,       // 12 Alfa Shift 2
        fLOCK       ,       // 13 mode lock
        fCANCEL     ,       // 14 cancel/exit
        fRJFEED     ,       // 15 confirm OK
    },
    {   /* Manager[16] */
        0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    },
    {       /* Flag[SYSFLAGS] */
        FLAG00,		FLAG01,		FLAG02,		FLAG03,		FLAG04,		FLAG05,		FLAG06,		FLAG07,
        FLAG08,		FLAG09,		FLAG10,		FLAG11,		FLAG12,		FLAG13,		FLAG14,		FLAG15,
        FLAG16,		FLAG17,		FLAG18,		FLAG19,		FLAG20,		FLAG21,		FLAG22,		FLAG23,
        FLAG24,		FLAG25,		FLAG26,		FLAG27,		FLAG28,		FLAG29,		FLAG30,		FLAG31,
        FLAG32,		FLAG33,		FLAG34,		FLAG35,		FLAG36,		FLAG37,		FLAG38,		FLAG39,
        FLAG40,		FLAG41,		FLAG42,		FLAG43,		FLAG44,		FLAG45,		FLAG46,		FLAG47,
        FLAG48,		FLAG49,		FLAG50,		FLAG51,		FLAG52,		FLAG53,		FLAG54,		FLAG55,
        FLAG56,		FLAG57,		FLAG58,		FLAG59,		FLAG60,		FLAG61,		FLAG62,		FLAG63
    },

    //...................���ֲ�ͨ�����ļ�������....................................................
#if (defined(CASE_ER220)||defined(CASE_ER100)||defined(CASE_ECR100F))
#ifdef CASE_EURO

#if defined(CASE_EURO) //!!! GREECE_ONLY !!!
    {//  KeyTable[128]
        MODELOCK,   JPF,    CLEAR,  MULT,       0,          0,     SHIFT1,
#if (0)//PC_EMUKEY)
        xRECEIPT,   '7',    '8',    '9',        DEPT+4,     DISC_PERINC,DISC_NETDEC, //����������ҪDISC+4(�ֽ��ۿ�)
        xLASTONE,   '4',    '5',    '6',        DEPT+3,     DISC_PERDEC,SUB,
        PLU1,       '1',    '2',    '3',        DEPT+2,     TEND_COUPON,TEND_CASH,
#else
        xRECEIPT,   '7',    '8',    '9',        DEPT+4,     DEPT+8,     TEND_VISA,//����������ҪDISC+4(�ֽ��ۿ�)
        xLASTONE,   '4',    '5',    '6',        DEPT+3,     DEPT+7,     SUB,
        PLU1,       '1',    '2',    '3',        DEPT+2,     DEPT+6,     TEND_CASH,
#endif
        DISC_PERDEC,'0',    ZERO2,  '.',        DEPT+1,     DEPT+5,     0,
        //ccr2017-12-14>>>>Second layer>>>>>>
        CLERK,      0,      0,      0,          0,          0,          0,
        MODI,       0,      0,      0,          0,          0,          TEND,
        NPRICE,     0,      0,      0,          0,          0,          DATETIME,
        xREFUND,    0,      0,      0,          0,          0,          0,
        DISC_NETDEC
        //ccr2017-12-14<<<<<<<<<<<<<<<<<<
    },
#elif defined(FOR_FLASHRAM)//ccr2017-10-13 testonly
    {//  KeyTable[128]
        MODELOCK,   JPF,    CLEAR,  MULT,       PLU1,       DISC+2,
#if (PC_EMUKEY)
        CLERK,      '7',    '8',    '9',        NPRICE,     DISC+1, //����������ҪDISC+4(�ֽ��ۿ�)
        CORREC+2,   '4',    '5',    '6',        DEPT+3,     TEND_COUPON,
#else
        CLERK,      '7',    '8',    '9',        NPRICE,     DISC+1,
        CORREC+2,   '4',    '5',    '6',        DEPT+3,     TEND+5,
#endif
        CORREC+1,   '1',    '2',    '3',        DEPT+2,     SUB,
        CORREC+4,   '0',    ZERO2,  '.',        DEPT+1,     TEND_CASH,
        0,          0,      0,      0,          0,          0,
        0,          0,      0,      0,          0,          0,
        0,          0,      0,      0,          0,          0,
        0,          0,      0,      0,          0,          0,
        0,          0,      0,      0,          0,
    },
#elif (CASE_PCR01)
    {// KeyTable[128]
        JPF,        INPUTVATNO, CLERK,      CORREC+2,   CORREC+3,   DISC+2, //00-05
        MODELOCK,   0,          NPRICE,     CORREC+1,   CORREC+4,   DISC+4,     //07-11
        CLEAR,      MULT,       PLU1,       DEPT+5,     DEPT+8,     PORA+1,     //12-17
        '7',        '8',        '9',        DEPT+4,     DEPT+7,     PORA+2,     //18-23
        '4',        '5',        '6',        DEPT+3,     DEPT+6,     SUB,        //24-29
        '1',        '2',        '3',        DEPT+2,     0,          TEND+1,     //30-35
        '0',        ZERO2,      '.',        DEPT+1,     0,          0,      //36-41
        0,          0,          0,          0,          0,          0,          //42-47
        0,          0,          0,          0,          0,          0,          //48-53
        0,          0,          0,          0,          0,          0,          //54-59
        0,          0,          0,          0,                                  //60-63
    },
#elif (CASE_ER50)
    {//  KeyTable[128]
        JPF,        MODELOCK,   CORREC+3,   SHIFT1,     DISC+2,
        PLU1,       NPRICE,     CORREC+1,   DEPT+6,     DISC+1,
        CLEAR,      MULT,       CLERK,      DEPT+5,     PORA+1,
        '7',        '8',        '9',        DEPT+4,     PORA+2,
        '4',        '5',        '6',        DEPT+3  ,   SUB,
        '1',        '2',        '3',        DEPT+2,     TEND+1,
        '0',        ZERO2,      '.',        DEPT+1,     TEND+1,
        0,          0,          0,          0,          0,
        0,          0,          0,          0,          0,
        0,

    },

#elif (defined(CASE_MCR30))
    {//  KeyTable[128]
#if PC_EMUKEY
        MODELOCK,   JPF,    CLEAR,  MULT,       PLU1,       NPRICE,     DISC+2, //����������ҪNPRICE
#else
        MODELOCK,   JPF,    CLEAR,  MULT,       PLU1,       NPRICE,     DISC+2,
#endif
        CLERK,      '7',    '8',    '9',        DEPT+4,     DEPT+8,     PORA+1,
        CORREC+2,   '4',    '5',    '6',        DEPT+3,     DEPT+7,     PORA+2,
        CORREC+1,   '1',    '2',    '3',        DEPT+2,     DEPT+6,     SUB,
        CORREC+3,   '0',    ZERO2,  '.',        DEPT+1,     DEPT+5,     TEND+1,
        0,          0,      0,      0,          0,          0,          0,
        0,          0,      0,      0,          0,          0,          0,
        0,          0,      0,      0,          0,          0,          0,
        0,          0,      0,      0,          0,          0,          0,
        0,

    },
#else
    {//  KeyTable[128]
        MODELOCK,   JPF,    CLEAR,  MULT,       PLU1,       NPRICE,     xREFUND,
#if (PC_EMUKEY)
        CLERK,      '7',    '8',    '9',        DISC_PERDEC,DISC_PERINC,DISC_NETDEC, //����������ҪDISC+4(�ֽ��ۿ�)
        xBEFOR,     '4',    '5',    '6',        DEPT+3,     SALPER,     TEND_COUPON,
#else
        CLERK,      '7',    '8',    '9',        DISC_PERDEC,DISC_PERINC,DISC_NETDEC,
        xBEFOR,     '4',    '5',    '6',        DEPT+3,     DEPT+6,     TEND_VISA,
#endif
        xLASTONE,   '1',    '2',    '3',        DEPT+2,     DEPT+5,     SUB,
        xRECEIPT,   '0',    ZERO2,  '.',        DEPT+1,     DEPT+4,     TEND_CASH,
        0,          0,      0,      0,          0,          0,          0,
        0,          0,      0,      0,          0,          0,          0,
        0,          0,      0,      0,          0,          0,          0,
        0,          0,      0,      0,          0,          0,          0,
        0
    },
#endif
#elif (defined(CASE_MALTA))
    {//  KeyTable[128]
#if PC_EMUKEY
        MODELOCK,   JPF,    CLEAR,  MULT,       PLU1,       NPRICE,     DISC+2, //����������ҪNPRICE
#else
        MODELOCK,   JPF,    CLEAR,  MULT,       PLU1,       INPUTVATNO, DISC+2,
#endif
        CORREC+4,   '7',    '8',    '9',        DEPT+4,     DEPT+8,     DISC+4,
        CORREC+2,   '4',    '5',    '6',        DEPT+3,     DEPT+7,     TEND+3,
        CORREC+1,   '1',    '2',    '3',        DEPT+2,     DEPT+6,     SUB,
        ODRAW,      '0',    ZERO2,  '.',        DEPT+1,     DEPT+5,     TEND+1,
        0,          0,      0,      0,          0,          0,          0,
        0,          0,      0,      0,          0,          0,          0,
        0,          0,      0,      0,          0,          0,          0,
        0,          0,      0,      0,          0,          0,          0,
        0,

    },
#else
    {//  KeyTable[128]

        MODELOCK,   JPF,    CLEAR,  MULT,       PLU1,       NPRICE,     DISC+2, //����������ҪNPRICE
        CORREC+4,   '7',    '8',    '9',        DEPT+4,     DEPT+8,     DISC+4,
        CORREC+2,   '4',    '5',    '6',        DEPT+3,     DEPT+7,     TEND+3,
        CORREC+1,   '1',    '2',    '3',        DEPT+2,     DEPT+6,     SUB,
        ODRAW,      '0',    ZERO2,  '.',        DEPT+1,     DEPT+5,     TEND+1,
        0,          0,      0,      0,          0,          0,          0,
        0,          0,      0,      0,          0,          0,          0,
        0,          0,      0,      0,          0,          0,          0,
        0,          0,      0,      0,          0,          0,          0,
        0,
#if 0
        MODELOCK,   JPF,    CLEAR,  MULT,       PLU1,       NPRICE,     PORA+1,
        DEPT,       '7',    '8',    '9',        DISC+2,     DISC+1,     PORA+2,
        CORREC+2,   '4',    '5',    '6',        DEPT+3,     DEPT+6,     TEND+2,
        CORREC+1,   '1',    '2',    '3',        DEPT+2,     DEPT+5,     SUB,
        CORREC+4,   '0',    ZERO2,  '.',        DEPT+1,     DEPT+4,     TEND+1,
        0,          0,      0,      0,          0,          0,          0,
        0,          0,      0,      0,          0,          0,          0,
        0,          0,      0,      0,          0,          0,          0,
        0,          0,      0,      0,          0,          0,          0,
        0,
#endif
    },
#endif

#elif (defined(CASE_ER260F) || defined(CASE_ER260))
    {
        JPF,        MULT,   NPRICE, PLU1,   DEPT+9, DEPT+10,    DISC+2,     PORA+2,     //00-07
        MODELOCK,   '7',    '8',    '9',    DEPT+7, DEPT+8,     DISC+4,     PORA+1,     //08-15
        CLERK,      '4',    '5',    '6',    DEPT+5, DEPT+6,     CORREC+1,   CORREC+4,   //16-23
        DISC+1,     '1',    '2',    '3',    DEPT+3, DEPT+4,     CORREC+2,   SUB,        //24-31
        CLEAR,      '0',    ZERO2,  '.',    DEPT+1, DEPT+2,     TEND+4,     TEND+1,     //32-39
        0,          0,      0,      0,      0,      0,          0,          0,          //40-47
        0,          0,      0,      0,      0,      0,          0,          0,          //48-55
        0,          0,      0,      0,      0,      0,          0,          0,          //56-63
    },

#elif (defined(CASE_ER260))
    {
        JPF,        MULT,   NPRICE, PLU1,   DEPT+9, DEPT+10,    DISC+4,     DISC+2,     //00-07
        MODELOCK,   '7',    '8',    '9',    DEPT+7, DEPT+8,     DISC+1,     CLERK,      //08-15
        PORA+1,     '4',    '5',    '6',    DEPT+5, DEPT+6,     CORREC+3,   CORREC+1,   //16-23
        PORA+2,     '1',    '2',    '3',    DEPT+3, DEPT+4,     CORREC+2,   SUB,        //24-31
        CLEAR,      '0',    ZERO2,  '.',    DEPT+1, DEPT+2,     TEND+4,     TEND+1,     //32-39
        0,          0,      0,      0,      0,      0,          0,          0,          //40-47
        0,          0,      0,      0,      0,      0,          0,          0,          //48-55
        0,          0,      0,      0,      0,      0,          0,          0,          //56-63
    },
#elif (CASE_ER28S)
    {
        CLEAR,  MODELOCK,   MULT,       PLU1,       CLERK,      DISC+2,     //00-05
        '7',    '8',        '9',        DEPT+7,     DEPT+8,     CORREC+2,   //06-11
        '4',    '5',        '6',        DEPT+5,     DEPT+6,     CORREC+1,   //12-17
        '1',    '2',        '3',        DEPT+3,     DEPT+4,     SUB,        //18-23
        '0',    ZERO2,      '.',        DEPT+1,     DEPT+2,     TEND+1,     //24-29
        0,      0,          0,          0,          0,          0,          //30-35
        0,      0,          0,          0,          0,          0,          //36-41
        0,      0,          0,          0,          0,          0,          //42-47
        0,      0,          0,          0,          0,          0,          //48-53
        0,      0,          0,          0,          0,          0,          //54-59
        0,      0,          0,          0,                                  //60-63
    },

#elif (CASE_ER28T)
    {//  KeyTable[128]
        JPF,        MULT,   NPRICE, PLU1,   DEPT+9, DEPT+10,    DISC+4,     DISC+2,     //    00-07
        MODELOCK,   '7',    '8',    '9',    DEPT+7, DEPT+8,     DISC+1,     CLERK,      //    08-15
        PORA+1,     '4',    '5',    '6',    DEPT+5, DEPT+6,     CORREC+3,   CORREC+1,   //    16-23
        PORA+2,     '1',    '2',    '3',    DEPT+3, DEPT+4,     CORREC+2,   SUB,        //    24-31
        CLEAR,      '0',    ZERO2,  '.',    DEPT+1, DEPT+2,     TEND+4,     TEND+1,     //    32-39
        0,          0,      0,      0,      0,      0,          0,          0,          //    40-47
        0,          0,      0,      0,      0,      0,          0,          0,          //    48-55
        0,          0,      0,      0,      0,      0,          0,          0,          //    56-63
    },

//cc 20070312
#elif (CASE_WISE158)
    {
#if(defined(CASE_EURO))	//cc 20071102
        MODELOCK,   MULT,   INPUTVATNO, DISC+2, DISC+4,     CORREC+3,
#else
        MODELOCK,   MULT,   DISC+1, DISC+2, DISC+4,     CORREC+3,
#endif
        DEPT+4, DEPT+8,     DEPT+12,    DEPT+16,    DEPT+20,DEPT+24,    SHIFT1,     JPF,            PLU1,       '7',        '8',        '9',        CORREC+2,   CORREC+1,
        DEPT+3, DEPT+7,     DEPT+11,    DEPT+15,    DEPT+19,DEPT+23,    DEPT,       NPRICE,     PORA+2,     '4',        '5',        '6',        CORREC+4,   CURR,
#if (defined(FISCAL))
        DEPT+2, DEPT+6,     DEPT+10,    DEPT+14,    DEPT+18,DEPT+22,    USERINFO,   DATETIME,   PORA+1,     '1',        '2',        '3',        TEND+4,     SUB,
#else
        DEPT+2, DEPT+6,     DEPT+10,    DEPT+14,    DEPT+18,DEPT+22,    SALPER, DATETIME,   PORA+1,     '1',        '2',        '3',        TEND+4,     SUB,
#endif

        DEPT+1, DEPT+5,     DEPT+9,     DEPT+13,    DEPT+17,DEPT+21,    CLERK,      ODRAW,      CLEAR,      '0',        ZERO2,  '.',        TEND+1,     TEND+1,
        0,      0,
    },
#elif CASE_ER380
    {// KeyTable[128]

        JPF,        CLERK,      DATETIME,   LOOKPLU,    DEPT+7,     SHIFT1,     CORREC+3,   DISC+4,     //00-07
        MODELOCK,   0,          NPRICE,     PLU1,       DEPT+6,     DEPT+13,    DISC+2,     DISC+1,     //08-15
        CORREC+2,   CORREC+4,   CORREC+1,   MULT,       DEPT+5,     DEPT+12,    PORA+1,     PORA+2,     //16-23
        ODRAW,      '7',        '8',        '9',        DEPT+4,     DEPT+11,    TEND+2,     TEND+4,     //24-31
        SALPER,     '4',        '5',        '6',        DEPT+3,     DEPT+10,    TEND+2,     CURR,       //32-39
        CLEAR,      '1',        '2',        '3',        DEPT+2,     DEPT+9,     SUB,        0,          //40-47
        0,          '0',        ZERO2,      '.',        DEPT+1,     DEPT+8,     TEND+1,     0,          //48-55
        0,          0,          0,          0,          0,          0,          0,          0,          //56-63

    },
#endif

    {   /*    StartAddress[AddrMAX]     */
        (RamOfTotal),                      /*    Total Sales start address     */
        (RamOfGroup),                     /*    Group Start Address     */
        (RamOfDept),                      /*    Dept start address     */
        (RamOfPLU),                         /*    Plu start address     */
        (RamOfPort),                        /*    Port start address     */
        (RamOfTend),                      /*    tendering function start address     */
        (RamOfPoRa),                      /*    Po Ra functions     */
        (RamOfDrawer),                    /*    Drawer start     */
        (RamOfCorr),                      /*    correc start     */
        (RamOfDisc),                      /*    discount start     */
        (RamOfCurr),                      /*    Foreign currency start     */
        (RamOfTax),                         /*    Tax start     */
        (RamOfPBf),                         /*    PB-Function start     */
        (RamOfModi),                      /*    modifier start     */
        (RamOfClerk),                     /*    clerk start     */
        (RamOfOFF),                     /*    OFFPrice start    */
        (RamOfICBlock),                     /*      //    ccr chipcard 2004-07-01     */
        (RamOFSalPer),                      /*         */
        (RamOFAgree),                       /*         */
        (RamOfRPLU),                    /*    Random PLU's used (low word)     */
        (RamOfEndP),                      /*    PROGRAM END Address     */
        (RamOfPBt),                         /*    PB table start     */
        (RamOfTrack)                      /*    track buffer start     */
    },

    {   //    struct PASSWORD ModePwd
        {0,0,0,0,0,0,0,0,0,0,0,0,0},    //    PwdX[MAXPWD];
        {0,0,0,0,0,0,0,0,0,0,0,0,0},    //    PwdZ[MAXPWD];
        {0,0,0,0,0,0,0,0,0,0,0,0,0},    //    PwdSET[MAXPWD];
        {0,0,0,0,0,0,0,0,0,0,0,0,0}     //    PwdMG[MAXPWD];
    },

    {   /* struct CCONFIG Config */
        0,        /* country code (0 = Europe) */
        2,        /* display (2 = 9 digit numeric) */
        3,      /* lock (2 = Central Lock, 3 = central & clerk) */
        128,    /* Journal density */
        128,    /* Receipt density */
        2,        /* Keyboard (2 = MA  60 keys) */
        15,        /* Clear key */
        -1,        /* Key Click 0 = disabled -1 = enabled) */
        {
            0x88,   /* disabled key locations each bit one key */
            0xff,
            0xff,
            0xff,
            0xff,
            0xff,
            0xff,
            0xbf,
            0xff,
            0xff,
            0xff,
            0xff,
        }
    },

    {   /* struct CLERKTABLE Clerk */
        clrkNumber      ,
        clrkRecordSize  ,
        clrkCapSize
    },

    {/* struct SALPERTABLE SalPer  */
        salNumber       ,
        salRecordSize   ,
        salCapSize
    },

    //...................��������....................................................
    {       /* struct FIXEDREPORT ReportList[13] */
        {
            {ReportList1},//Ccr REPID_CLERKDAILY  {" �� �� Ա �� �� "},
            PLAYOUT,   /* print */
            0x00,   /* options */
            0x00,  /* number */
            0x00,   /* period */
            0x01,   /* pointer type */
            {REPORT_GRANDTOTAL+1,   //ccr2017-12-15 �˴���������"�տ�Ա�ձ�"�������ı���,��������������,�ɶ�Ӧ���ӱ�����������
                REPORT_DEPARTMENT+1,//ccr2017-12-15 ��Ϊ�����struct DEPTTABLE Dept��û�������տ�Ա��ͳ������,����"�տ�Ա�ձ�"���޲����ͳ��
                REPORT_PLU+1,
                REPORT_TENDER+1,
                REPORT_CORRECTION+1,
                REPORT_DISCOUNT+1,
                REPORT_CURRENCY+1,
                0,//ccr2017-12-15 REPORT_TAX+1,��ΪTAX��struct TAXTABLE Tax��û�������տ�Ա��ͳ������,����"�տ�Ա�ձ�"����TAX��ͳ��
                0, 0, 0, 0}  /* Report type link */
        },
        {
            {ReportList2},//Ccr REPID_CLERKPERIOD   {" �� �� Ա �� �� "},
            PLAYOUT,   /* print */
            0x00,   /* options=0,ָ���տ�Ա */
            0x00,  /* number */
            0x01,   /* period */
            0x01,   /* pointer type */
            {REPORT_GRANDTOTAL+1,
                REPORT_DEPARTMENT+1,
                REPORT_PLU+1,
                REPORT_TENDER+1,
                REPORT_CORRECTION+1,
                REPORT_DISCOUNT+1,
                REPORT_CURRENCY+1,
                0,//ccr2017-12-15 REPORT_TAX+1,
                0, 0, 0, 0}  /* Report type link */
        },
        {   /**********   ˰��Z������,������ӡREPID_DAILYREPORT������ ********/
            {ReportList3},//ccr REPID_DAILYREPORT   {" ��  ��  ��  �� "},
            PLAYOUT,   /* print */
#if defined(FISCAL)
            0x06,   /* options */
#else
            0x02,
#endif
            0x00,  /* number */
            0x00,   /* period=0,��ʾ��ӡ��ͳ������ */
            0x00,   /* pointer type */
            {REPORT_GRANDTOTAL+1,
                REPORT_DEPARTMENT+1,
                REPORT_GROUP+1,//ccr2017-05-23
                REPORT_TENDER+1,
                REPORT_CORRECTION+1,
                REPORT_DISCOUNT+1,
                REPORT_CURRENCY+1,
                REPORT_TAX+1,
                0, 0, 0, 0}  /* Report type link */
        },
        {
            {ReportList4},//ccr REPID_PERIODREPORT  {" ��  ��  ��  �� "},
            PLAYOUT,   /* print */
            0x02,   /* options=2,ȫ����¼ */
            0x00,  /* number */
            0x01,   /* period=1,��ʾ��ӡ��ͳ������ */
            0x00,   /* pointer type */
            {REPORT_GRANDTOTAL+1,
                REPORT_DEPARTMENT+1,
                REPORT_TENDER+1,
                REPORT_CORRECTION+1,
                REPORT_DISCOUNT+1,
                REPORT_CURRENCY+1,
                REPORT_TAX+1,
                0, 0, 0, 0, 0}  /* Report type link */
        },
        {
            {ReportList5},//ccr REPID_PLUDAILY {" ��  Ʒ  ��  �� "},
            PLAYOUT,   /* print */
            0x02,   /* options=2,ȫ����Ʒ */
            0x00,  /* number */
            0x00,   /* period=0,��ͳ������ */
            0x00,   /* pointer type */
            {REPORT_PLU+1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}  /* Report type link */
        },
        {
            {ReportList6},//ccr REPID_TABLEREPORT {" ��  ��  ��  �� "},
            PLAYOUT,   /* print */
            0x02,   /* options */
            0x00,  /* number */
            0x00,   /* period */
            0x00,   /* pointer type */
            {REPORT_BALANCE+1, REPORT_TABLES+1, REPORT_PBFUNC+1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}  /* Report type link */
        },
        {
            {ReportList7},//ccr REPID_TIMEZONE {" ʱ  ��  ��  �� "},
            PLAYOUT,   /* print */
            0x02,   /* options=2,Ϊȫ����¼ */
            0x00,  /* number */
            0x00,   /* period=0,Ϊ�ձ��� */
            0x02,   /* pointer type=2,Ϊʱ�α��� */
            {REPORT_GRANDTOTAL+1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}  /* Report type link */
        },
        {
            {ReportList8},//ccr REPID_ALLCLERKDAILY {"  ȫ�տ�Ա�ձ�  "},
            PLAYOUT,   /* print */
            0x02,   /* options=2,ȫ���տ�Ա */
            0x00,  /* number */
            0x00,   /* period=0,Ϊ�ձ��� */
            0x01,   /* pointer type=1,Ϊ�տ�Ա���� */
            {REPORT_GRANDTOTAL+1,
                REPORT_DEPARTMENT+1,
                REPORT_PLU+1,
                REPORT_TENDER+1,
                REPORT_CORRECTION+1,
                REPORT_DISCOUNT+1,
                REPORT_CURRENCY+1,
                0,//ccr2017-12-15 REPORT_TAX+1,
                0, 0, 0, 0}  /* Report type link */
        },
        {
            {ReportList9},//ccr REPID_ALLCLERKPERIOD {"  ȫ�տ�Ա�ܱ�  "},
            PLAYOUT,   /* print */
            0x02,   /* options=2;Ϊȫ���տ�Ա */
            0x00,  /* number */
            0x01,   /* period=1,Ϊ�ܱ��� */
            0x01,   /* pointer type=1,Ϊ�տ�Ա���� */
            {REPORT_GRANDTOTAL+1,
                REPORT_DEPARTMENT+1,
                REPORT_PLU+1,
                REPORT_TENDER+1,
                REPORT_CORRECTION+1,
                REPORT_DISCOUNT+1,
                REPORT_CURRENCY+1,
                0,//ccr2017-12-15 REPORT_TAX+1,
                0, 0, 0, 0}  /* Report type link */
        },
#if (1)//ccr2017-12-13 salNumber
        {
            {ReportList10},//ccr2017-05-26 REPID_SALERDAILY /*Ӫ ҵ Ա �� ��*/
            PLAYOUT,   /* print */
            0x00,   /* options */
            0x00,  /* number */
            0x00,   /* period */
            0x05,   /* pointer type */
            {REPORT_GRANDTOTAL+1,
                REPORT_DEPARTMENT+1,
                REPORT_PLU+1,
                REPORT_TENDER+1,
                REPORT_CORRECTION+1,
                REPORT_DISCOUNT+1,
                REPORT_CURRENCY+1,
                0,//ccr2017-12-15 REPORT_TAX+1,
                0, 0, 0, 0}  /* Report type link */
        },
        {
            {ReportList11},//Ccr REPID_SALERPERIOD Ӫ ҵ Ա �� ��
            PLAYOUT,   /* print */
            0x00,   /* options */
            0x00,  /* number */
            0x01,   /* period */
            0x05,   /* pointer type */
            {REPORT_GRANDTOTAL+1,
                REPORT_DEPARTMENT+1,
                REPORT_PLU+1,
                REPORT_TENDER+1,
                REPORT_CORRECTION+1,
                REPORT_DISCOUNT+1,
                REPORT_CURRENCY+1,
                0,//ccr2017-12-15 REPORT_TAX+1,
                0, 0, 0, 0}  /* Report type link */
        },
        {
            {ReportList12},//ccr REPID_ALLSALERDAILY {"  ȫӪҵԱ�ձ�  "},
            PLAYOUT,   /* print */
            0x02,   /* options */
            0x00,  /* number */
            0x00,   /* period */
            0x05,   /* pointer type */
            {REPORT_GRANDTOTAL+1,
                REPORT_DEPARTMENT+1,
                REPORT_PLU+1,
                REPORT_TENDER+1,
                REPORT_CORRECTION+1,
                REPORT_DISCOUNT+1,
                REPORT_CURRENCY+1,
                0,//ccr2017-12-15 REPORT_TAX+1,
                0, 0, 0, 0}  /* Report type link */
        },
        {
            {ReportList13},//ccr REPID_ALLSALERPERIOD {"  ȫӪҵԱ�ܱ�  "},
            PLAYOUT,   /* print */
            0x02,   /* options */
            0x00,  /* number */
            0x01,   /* period */
            0x05,   /* pointer type */
            {REPORT_GRANDTOTAL+1,
                REPORT_DEPARTMENT+1,
                REPORT_PLU+1,
                REPORT_TENDER+1,
                REPORT_CORRECTION+1,
                REPORT_DISCOUNT+1,
                REPORT_CURRENCY+1,
                0,//ccr2017-12-15 REPORT_TAX+1,
                0, 0, 0, 0}  /* Report type link */
        },
#endif
        //ccr2017-05-27 �����ӵı���>>>>>>>
        {
            {ReportList14},//ccr REPID_DEPTDAILY {" ��  ��  �� ��  �� "},
            PLAYOUT,   /* print */
            0x02,   /* options=2,ȫ������ */
            0x00,  /* number */
            0x00,   /* period=0,��ͳ������ */
            0x00,   /* pointer type */
            {REPORT_DEPARTMENT+1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}  /* Report type link */
        },
        {
            {ReportList15},//ccr REPID_DEPTPERIOD {" �� �� �� �� �� �� "},
            PLAYOUT,   /* print */
            0x02,   /* options=2,ȫ������ */
            0x00,  /* number */
            0x01,   /* period=1,��ͳ������ */
            0x00,   /* pointer type */
            {REPORT_DEPARTMENT+1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}  /* Report type link */
        },
        {
            {ReportList16},//ccr REPID_GROUPDAILY {" ��  ��  ��  ��  �� "},
            PLAYOUT,   /* print */
            0x02,   /* options=2,ȫ������ */
            0x00,  /* number */
            0x00,   /* period=0,��ͳ������ */
            0x00,   /* pointer type */
            {REPORT_GROUP+1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}  /* Report type link */
        },
        {
            {ReportList17},//ccr REPID_PLUPERIOD {" �� Ʒ �� �� �� �� "},
            PLAYOUT,   /* print */
            0x02,   /* options=2,ȫ������ */
            0x00,  /* number */
            0x01,   /* period=1,��ͳ������ */
            0x00,   /* pointer type */
            {REPORT_PLU+1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}  /* Report type link */
        },
        //ccr2017-05-27<<<<<<<<<<<<<<<<
    },

    //...................����������ͳ������....................................................
    {       /* struct TOTALSALES Sales,REPORT_GRANDTOTAL */
        totalRecordSize, //Size[0].Length*2+Size[1].Length*clerkNumber + Size[2].Length * zoneNumber
        {/*Periods,	Length,Cc,Qty,Amt,RetQty,Disc,Cost*/
            {0x03, 	(toCC+toQTY+toAMT+toRET+toDISC+toCOST+1), toCC, toQTY, toAMT, toRET, toDISC, toCOST},       /*ccr090812 for SubDisc standard Total lay-out */
		    {0x03, 	toAMT+1, 		0, 0, toAMT, 	0, 		0, 0},   /* Clerk Total lay-out */
#if (zoneNumber)
		    {0x01, 	(toCC+toAMT+1), toCC, 0, toAMT, 	0, 		0, 0},   /* Time zones Total lay-out */
#else
            {0x00, 	0, 0, 0, 0, 	0, 		0, 0},   /* Time zones Total lay-out */
#endif
		    {0x00, 	0, 		0, 0, 0, 	0, 		0, 0},   /* Day Total lay-out */
		    {0x00, 	0, 		0, 0, 0, 	0, 		0, 0},   /* Month Total lay-out */
#if (salNumber)
		    {0x03, 	toAMT+1, 		0, 0, toAMT, 	0, 		0, 0},   /* Saler Total lay-out */
#else
		    {0x00, 	0, 		0, 0, 0, 	0, 		0, 0},   /* Saler Total lay-out */
#endif
		}
    },

    {   /* struct CORRECTABLE Correc,REPORT_CORRECTION */
        corrNumber      ,          /* number of correction functions */
        corrRecordSize  ,
        corrTotalOffSet ,
        corrCapSize     ,
		{/*Periods,	Length,Cc,Qty,Amt,RetQty,Disc,Cost*/
		    {0x03, (crCC+crQTY+crAMT+crRET+crDISC+crCOST+1), crCC, crQTY, crAMT, crRET, crDISC, crCOST},   /* standard Total lay-out */
		    {0x03, (crCC+crQTY+crAMT+crRET+crDISC+crCOST+1), crCC, crQTY, crAMT, crRET, crDISC, crCOST},   /* clerk Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Time zones Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Day Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Month Total lay-out */
#if (salNumber)
		    {0x03, (crCC+crQTY+crAMT+crRET+crDISC+crCOST+1), crCC, crQTY, crAMT, crRET, crDISC, crCOST},   /* saler Total lay-out */
#else
		    {0x00, 	0, 		0, 0, 0, 	0, 		0, 0},   /* Saler Total lay-out */
#endif
		}
    },

    {   /* struct CURRTABLE Curr,REPORT_CURRENCY */
        currNumber      ,          /* number of foreign currencies */
        currRecordSize  ,
        currTotalOffSet ,
        currCapSize     ,
		{/*Periods,	Length,Cc,Qty,Amt,RetQty,Disc,Cost*/
		    {0x03, (cuCC+cuAMT+1), cuCC, 0, cuAMT, 0, 0, 0},   /* standard Total lay-out */
		    {0x03, cuAMT+1, 0, 0, cuAMT, 0, 0, 0},   /* clerk Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Time zones Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Day Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Month Total lay-out */
#if (salNumber)
		    {0x03, cuAMT+1, 0, 0, cuAMT, 0, 0, 0},   /* saler Total lay-out */
#else
		    {0x00, 	0, 		0, 0, 0, 	0, 		0, 0},   /* Saler Total lay-out */
#endif
		}
    },


    {   /* struct DEPTTABLE Dept,REPORT_DEPARTMENT */
        depNumber       ,        /* number of Dept */
        depRecordSize   ,         /* Record size */
        depTotalOffSet  ,         /* Total offset */
        depRandomSize   ,          /* Random Number Size */
        depCapSize      ,            /* Caption Length */
        depPriceSize    ,       /* max size is 4 */
        depPriMaxSize   ,       /* max size is 4 */
        {/*Periods,	Length,Cc,Qty,Amt,RetQty,Disc,Cost*/
            /*|����|����|���۶�|�˻�����|�ۿۻ���|COST���� */
		    {0x03, (dCC+dQTY+dAMT+dRET+dDISC+dCOST+1), dCC, dQTY, dAMT, dRET, dDISC, dCOST},   /* standard Total lay-out */
            {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    Clerk Total lay-out     */
            {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    Time zones Total lay-out     */
            {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    Day Total lay-out     */
            {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    Month Total lay-out     */
            {0x00, 0, 0, 0, 0, 0, 0, 0},   /*    saler Total lay-out     */
        }
    },
    {       /* struct DISCTABLE Disc ,REPORT_DISCOUNT */
        discNumber      ,          /* number of discount functions */
        discRecordSize  ,
        discTotalOffSet ,
        discCapSize     ,
		{/*Periods,	Length,Cc,Qty,Amt,RetQty,Disc,Cost*/
		    {0x03, (xCC+xQTY+xAMT+xRET+xDISC+xCOST+1), xCC, xQTY, xAMT, xRET, xDISC, xCOST},   /* standard Total lay-out */
		    {0x03, (xCC+xQTY+xAMT+xRET+xDISC+xCOST+1), xCC, xQTY, xAMT, xRET, xDISC, xCOST},   /* clerk Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Time zones Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},    /* Day Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Month Total lay-out */
#if (salNumber)
		    {0x03, (xCC+xQTY+xAMT+xRET+xDISC+xCOST+1), xCC, xQTY, xAMT, xRET, xDISC, xCOST},   /* saler Total lay-out */
#else
		    {0x00, 	0, 		0, 0, 0, 	0, 		0, 0},   /* Saler Total lay-out */
#endif
		}
    },
    {       /* struct DRAWERTABLE Draw,REPORT_DRAWER */
        drawNumber      ,          /* number of drawer Total */
        drawRecordSize  ,
        drawTotalOffSet ,          /* 1 byte for options, 1 for print */
        drawCapSize     ,
		{/*Periods,	Length,Cc,Qty,Amt,RetQty,Disc,Cost*///ccr2017-05-26 ɾ��ͳ��
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* standard Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* clerk Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Time zones Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Day Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Month Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* saler Total lay-out */
		}
    },

    {       /* struct GROUPTABLE Group,REPORT_GROUP */
        grpNumber,
        grpRecordSize,
        grpTotalOffSet,
        grpCapSize,
		{/*Periods,	Length,Cc,Qty,Amt,RetQty,Disc,Cost*/
		    {0x01, (gCC+gQTY+gAMT+gRET+gDISC+gCOST+1), gCC, gQTY, gAMT, gRET, gDISC, gCOST},   /* standard Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* clerk Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Time zones Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Day Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Month Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* saler Total lay-out */
		}
    },
    {   /* struct MODITABLE Modi */
        modiNumber  ,
        modiCapSize ,
    },

    {       /* struct PBTABLE Pb */
        pbNumber        ,          /* number of PB functions */
        pbRecordSize    ,            /* record size PB function */
        pbTotalOffSet   ,         /* total offset */
        pbCapSize       ,          /* caption length */

        pbNumberOfPb    ,        /* number of PB's */
        pbRandom        ,          /* Pb random */
        pbText          ,          /* Pb text */
        pbAmtSize       ,          /* PB amount size is 5 (table contains also block clerk and lines */
        pbArtAmt        ,          /* max art amount 999999 */
//#if pbAmtDisc
//		pbAmtDisc		,			//ccr091208
//#endif
        pbQty           ,          /* max qty 999999 */
        pbArtSize       ,          /* amt + qty + sign + keycode */
        pbNumberOfItems ,         /* number of items in block */
        pbNumberOfBlocks,         /* number of blocks */
        pbBlockSize     ,        /* block size maximum is 128 bytes */
        pbtRecordSize,          // Record size for PBTable report ccr 2003-10-31
        pbtTotalOffset,         //ccr 2003-10-31
        {/*Periods,	Length,Cc,Qty,Amt,RetQty,Disc,Cost*///REPORT_PBFUNC, For pb function//ccr2017-05-26 ɾ��ͳ��
            {0x00, 0, 0, 0, 0, 0, 0, 0},   /* standard Total lay-out */
            {0x00, 0, 0, 0, 0, 0, 0, 0},   /* clerk Total lay-out */
            {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Time zones Total lay-out */
            {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Day Total lay-out */
            {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Month Total lay-out */
            {0x00, 0, 0, 0, 0, 0, 0, 0},   /* saler Total lay-out */
		},
		{/*Periods,	Length,Cc,Qty,Amt,RetQty,Disc,Cost*///REPORT_TABLES,for pb table //ccr2017-05-26 ɾ��ͳ��
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* standard Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* clerk Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Time zones Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Day Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Month Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* saler Total lay-out */
		}
    },
    {       /*    struct PLUTABLE Plu,REPORT_PLU     */
        pluNumber       ,        /*    number of plus     */
        0,                      /*    number of RandomPLU     */
        pluRecordSize   ,         /*    Record size (+ Dept selection)    */
        pluTotalOffSet  ,         /*    Total offset     */
        pluRandomSize   ,          /*    Random Number Size     */
        pluCapSize      ,         /*    Caption Length     */
        pluLevel        ,          /*    Number of Price Levels     */
        pluPriceSize    ,          /*    Price size in bytes     */
        pluCost         ,          /*    if not zero then cost price     */
        pluInvSize      ,          /*    inventory size (sign + size)     */
        //struct  REPSIZE Size[REPDEFMAX]
        {/*Periods,	Length,Cc,Qty,Amt,RetQty,Disc,Cost*/ //ccr2017-05-26����PLU��ͳ��
		    {0x03, (pCC+pQTY+pAMT+pRET+pDISC+pCOST+1), pCC, pQTY, pAMT, pRET, pDISC, pCOST},       /* standard Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   		/* Clerk Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},    	/* Time zones Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   		/* Day Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},    	/* Month Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   		/* saler Total lay-out */
		}
    },
    {       /* struct PORATABLE PoRa,REPORT_PORA */
        poraNumber      ,          /* number of PO  & RA functions */
        poraRecordSize  ,
        poraTotalOffSet ,
        poraCapSize     ,
        {/*Periods,	Length,Cc,Qty,Amt,RetQty,Disc,Cost*///ccr2017-05-26 ɾ��ͳ��
            {0x00, 0, 0, 0, 0, 0, 0, 0},   /* standard Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* clerk Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Time zones Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Day Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Month Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* saler Total lay-out */
		}
    },
    {       /* struct TAXTABLE Tax,REPORT_TAX */
        taxNumber       ,              /* (3) number of tax itemizers max 8 */
        taxRecordSize   ,
        taxTotalOffSet  ,
        taxCapSize      ,
        {/*Periods,	Length,            Cc, Qty,  Amt,RetQty,Disc,Cost*/
            {0x03, (tQTY+tAMT+tCOST+1), 0, tQTY, tAMT, 0, 0, tCOST},   /* standard Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Clerks Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Time zones Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Day Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Month Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Saler Total lay-out */
		}
    },
    {       /* struct TENDTABLE Tend,REPORT_TENDER */
        tendNumber      ,          /* number of tendering functions */
        tendRecordSize  ,
        tendTotalOffSet ,
        tendCapSize     ,
        {/*Periods,	Length,Cc,Qty,Amt,RetQty,Disc,Cost*/
            {0x03, (cCC+cQTY+cAMT+cRET+cDISC+cCOST+1), cCC, cQTY, cAMT, cRET, cDISC, cCOST},   /* standard Total lay-out */
		    {0x03, cAMT+1, 0, 0, cAMT, 0, 0, 0},   /* clerk Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Time zones Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Day Total lay-out */
		    {0x00, 0, 0, 0, 0, 0, 0, 0},   /* Month Total lay-out */
#if (salNumber)
		    {0x03, cAMT+1, 0, 0, cAMT, 0, 0, 0},   /* Saler Total lay-out */
#else
		    {0x00, 	0, 		0, 0, 0, 	0, 		0, 0},   /* Saler Total lay-out */
#endif
		}
    },
    {       /* struct ZONETABLE Zone */
        zoneNumber,
        {/* zone start */
            0x0000,0x0200,0x0400,0x0600,0x0800,0x1000,0x1200,0x1400,0x1600,0x1800,0x2000,0x2200,
            0,0,0,0,0,0,0,0,0,0,0,0     /* notused */
        },
    },

    {   /* struct DAYTABLE Day */
        dayNumber
    },

    {       /* struct MONTHTABLE Month */
        monthNumber
    },

    {//struct OPTIONTABLE                      /* Option */
        0,0,0,0,0,0,0,0,"",0,
    },
    {// struct OFFTABLE OFFPrice
        offNumber,
        offRecordSize,
        offCapSize,
        offPriUSize,
    },
    {// struct PORTTABLE Port
        portNumber,
        portRecordSize,
        portCapSize,
    },

    {//struct PROMRECORD 	Promotion;
        1000,
        {0x00,0x00,0x01,0x00},
        {0x00,0x00,0x01,0x00},
        {0x00,0x00,0x01,0x00},
        2,
        Promotion1,//		"  ~��  ~ϲ  ~��  ~��",
    },

    {//strcut AGREETABLE Agree
        agreeNumber,
        agreeRecordSize,
        agreeTotalOffSet,
        agreeCapSize,
    },
    {   /* struct ICBLOCKTABLE ICBlock */  //ccr chipcard 2004-07-01
        icblockNumber   ,
        icblockSize ,
    },
    {/* struct TTAXSET      TaxSet */
        0x00000000
    },
    {//struct TNETWORK NetWork;
        DHCPFlag,      //Option
        {192,168,1,200},//    IPAddress[4];
        10248,//    ClientPort;
        {147,102,24,100},//    ServerIP[4];
        80,//    ServerPort;
        {192,168,1,1},//    GateWay[4];//ccr2017-02-15
        {255,255,255,0},//    IPMask[4];//ccr2017-02-15
        {222,246,129,80},//    PrimaryDNS[4];
        {59,51,78,210},//    SecondDNS[4];
        "http://wldcl.ece.ntua.gr/myweb/websend.php",             //    ServerURL
        "",//    APN[16];//ccr2015-03-10
        "",//    UserName[16];//ccr2015-03-10
        "",//    Password[16];//ccr2015-03-10
        {'8','0','0','1','2','3','4','5','6',0},//    ECR_ID[8];         //For example:unitID=0x123456789ABCDEF0, 8 bytes
        {0x14,0xAE,0x59,0x21,0xF8,0x65,0xC6,0xFC,0x00,0x3A,0x04,0x09,0xFF,0xA8,0x2D,0xE0,0x63,0xC1,0xC0,0x1F,0x66,0x6E,0xAB,0x3B,0xB9,0x2A,0xDB,0xAB,0x80,0x4C,0x96,0x34}   //SecurityCode[32]
        //{'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','1','2','3','4','5','6'}   //testonly SecurityCode[32]
    },
};


CONST struct DEFAULT Def = {
    {/* CORREC */
        { PLAYOUT, 0x00, Correc1},//Ccr 		"ȡ�� VOID"
        { PLAYOUT, 0x01, Correc2},//Ccr 		"���� CORRECT"
        { PLAYOUT, 0x02, Correc3},//Ccr 		"�˻� RETURN"
        { PLAYOUT, 0x03, Correc4},//ccr         "ȡ������CANCEL"
//		{ PLAYOUT, 0x04, "CANCEL 1"},
//		{ PLAYOUT, 0x05, "CANCEL 2"},
    },
    {/* CURRENCY */
        {0, 8, 0, 0, {0,0,0,0}, {0,0,0,0}, CURRENCY1},//Ccr 		{0, 0, 0, 0, {0,0,0,0}, {0,0,0,0}, "��Ԫ    "},
        {0, 0, 0, 0, {0,0,0,0}, {0,0,0,0}, CURRENCY2},//Ccr 		{0, 0, 0, 0, {0,0,0,0}, {0,0,0,0}, "��Ԫ    "},
        {0, 0, 0, 0, {0,0,0,0}, {0,0,0,0}, CURRENCY3},//Ccr 		{0, 0, 0, 0, {0,0,0,0}, {0,0,0,0}, "�۱�    "},
        {0, 0, 0, 0, {0,0,0,0}, {0,0,0,0}, CURRENCY4},//Ccr 		{0, 0, 0, 0, {0,0,0,0}, {0,0,0,0}, "���1   "},
        {0, 0, 0, 0, {0,0,0,0}, {0,0,0,0}, CURRENCY5},//Ccr 		{0, 0, 0, 0, {0,0,0,0}, {0,0,0,0}, "���2   "},
    },
    {       /* DISCOUNT */
        {PLAYOUT, 0x19, {0, 0, 0}, 0, {0x00,0x99,0x00,0x00}, DISCOUNT1},         /*  DISC 1 "+%�ӳ�" */
        {PLAYOUT, 0x11, {0, 0, 0}, 0, {0x00,0x99,0x00,0x00}, DISCOUNT2},         /*  DISC 2  "(-%)�ۿ�" */
        {PLAYOUT, 0x1d, {0, 0, 0}, 0, {0x00,0x99,0x99,0x99}, DISCOUNT3},         /*  DISC 3 "���ӳ�" */
        {PLAYOUT, 0x15, {0, 0, 0}, 0, {0x00,0x99,0x99,0x99}, DISCOUNT4},         /* DISC 4 "����ۿ�" */
//		{PLAYOUT, 0x00, {0, 0, 0}, 0, {0x00,0x99,0x99,0}, "\xB5\xA5\xCF\xEE\xBC\xD3\xB3\xC9"},          /* DISC 5 "����ӳ�" */
    },
    {       /* DRAWER */
        {PLAYOUT, 0, DRAWER1},// 		{PLAYOUT, 0, "�ֽ�    "},
        {PLAYOUT, 0, DRAWER2},// 		{PLAYOUT, 0, "֧Ʊ    "},
        {PLAYOUT, 0, DRAWER3},// 		{PLAYOUT, 0, "���ÿ�  "},
        {PLAYOUT, 0, DRAWER4},//	{PLAYOUT, 0, "����ȯ  "},
        {PLAYOUT, 0, DRAWER5},//		{PLAYOUT, 0, "����    "},
        {PLAYOUT, 0, DRAWER6},//		{PLAYOUT, 0, "IC��    "},
        {PLAYOUT, 0, DRAWER7},//		{PLAYOUT, 0, "С��    "},
        {PLAYOUT, 0, DRAWER8},
    },
    {       /*    PB FUNCTIONS     */
        {PLAYOUT, 0x00,PBFunction0},    //  ��̨����  PB-F 1  //
#if pbNumber==12
        {PLAYOUT, 0x01, PBFunction1},    //  ��̨���� PB-F 2 //
        {PLAYOUT, 0x02, PBFunction2},    //   �ݽ�  PB-F 3 //
        {PLAYOUT, 0x03, PBFunction3},    //  ȷ�Ͻ���  PB-F 4 //
        {PLAYOUT, 0x04, PBFunction4},    //  ��ӡ��̨PB-F 5 //
        {PLAYOUT, 0x05, PBFunction5},    //  ��ӡ�ʵ� PB-F 6 //
        {PLAYOUT, 0x06, PBFunction6},    //  ȡ��ȷ�� PB-F 7 //
        {PLAYOUT, 0x07, PBFunction7},    //  ���� PB-F 8 //
        {PLAYOUT, 0x08, PBFunction8},    //   ת�� PB-F 9 //
        {PLAYOUT, 0x09, PBFunction9},   //  ת����  PB-F 10 //
        {PLAYOUT, 0x0A, PBFunction10},  //   ���� PB-F 11 //
        {PLAYOUT, 0x0B, PBFunction11},  //  �ϲ� PB-F 12 //  liuj 0716
#endif
    },
    {       /*    PORA     */
        {PLAYOUT, 0x01, 1, 0, PORAType1},         /*    PORA 1     *///    Ccr 		{PLAYOUT, 0x01, 1, 0, "����    "},         /*    PORA 1     */
        {PLAYOUT, 0x09, 1, 0, PORAType2},         /*    PORA 2     *///    Ccr 		{PLAYOUT, 0x09, 1, 0, "���    "},         /*    PORA 2     */
        {PLAYOUT, 0x01, 1, 0,PORAType3},         /*    PORA 3     *///    ccr		{PLAYOUT, 0x09, 1, 0, "IC���˿�"},         /*    PORA 3     */
        {PLAYOUT, 0x09, 1, 0, PORAType4},         /*    PORA 4     *///    ccr 		{PLAYOUT, 0x01, 1, 0, "IC����ֵ"},         /*    PORA 4     */
        {PLAYOUT, 0x01, 1, 0, PORAType5},         /*    PORA 5     *///    ccr		{PLAYOUT, 0x09, 1, 0, "��ICѺ��"},         /*    PORA 5     */
        {PLAYOUT, 0x09, 1, 0, PORAType6},         /*    PORA 6     *///    ccr 		{PLAYOUT, 0x01, 1, 0, "��ICѺ��"},         /*    PORA 6     */
    },
    {       /*    TEND     */
#if defined(CASE_EURO)
        {PLAYOUT, 0x41, 1, 0, 0, TendType1},        //"�ֽ�    "
        {PLAYOUT, 0x4d, 2, 0, 0, TendType2},        //"֧Ʊ    "
        {PLAYOUT, 0x45, 3, 0, 0, TendType3},        //"���ÿ�  "
        {PLAYOUT, 0x51, 4, 7, 0, TendType4},        //"����ȯ  "
        {PLAYOUT, 0x45, 5, 0, 0, TendType5},        //"����"
        {PLAYOUT, 0x45, 6, 0, 0, TendType6},        //"ICCard"
#else
        {PLAYOUT, 0x01, 1, 0, 0,TendType1},         /*    TEND 1     *///    Ccr 		{PLAYOUT, 0x01, 1, 0, 0, "�ֽ�    "},         /*    TEND 1     */
        {PLAYOUT, 0x05, 2, 0, 0, TendType2},         /*    TEND 3     *///    Ccr 		{PLAYOUT, 0x05, 3, 7, 0, "���ÿ�  "},         /*    TEND 3     */
        {PLAYOUT, 0x05, 3, 0, 0, TendType3},          /*    TEND 5 ����    */// 		{PLAYOUT, 0x05, 5, 7, 0, "����"},         /*    TEND 5     */
        {PLAYOUT, 0x05, 4, 0, 0,TendType4},         /*    TEND 2     *///    Ccr 		{PLAYOUT, 0x05, 2, 7, 0, "֧Ʊ    "},         /*    TEND 2     */
        {PLAYOUT, 0x11, 5, 7, 0, TendType5},         /*    TEND 4     */// 		{PLAYOUT, 0x11, 4, 7, 0, "����ȯ  "},         /*    TEND 4     */
        {PLAYOUT, 0x05, 6, 0, 0, TendType6},         /*    TEND 6     */// 		{PLAYOUT, 0x05, 6, 7, 0, "ICCard"},         /*    TEND 6     */
#endif
    },
    {       /* TAX */
#if (defined(CASE_GREECE))
        {TAXType1, {0,0x06,0}, 0x01},
        {TAXType2, {0,0x13,0}, 0x01},
        {TAXType3, {0,0x24,0}, 0x01},
        {TAXType4, {0,0x35,0}, 0x01},
        {TAXType5, {0,0x00,0}, 0x01},
#else
        {TAXType1, {0,0x13,0}, 0x02},
        {TAXType2, {0,0x08,0}, 0x02},
        {TAXType3, {0,0x17,0}, 0x02},
        {TAXType4, {0,0x00,0}, 0x02},
#if taxNumber==8
        {TAXType5, {0,0x00,0}, 0x02},
        {TAXType6, {0,0x00,0}, 0x02},
        {TAXType7, {0,0x00,0}, 0x02},
        {TAXType8, {0,0x00,0}, 0x02}
#endif
#endif
    },
    {
        Modifier1,             /* Modifier *///Ccr 		"˵��    ",             /* Modifier */
    },
    {
        ClerkRec1, 0xff,{0,0,0},                /* Clerk */
//Ccr 		"�տ�Ա  ", 0x10                /* Clerk */
    },
    {
        99, GroupRec1,             /* Group GROUPRECORD */
//Ccr 		0x0000, "����    ",             /* Group */
    },
    { /* DEPTRECORD */
        {0,0,0,0,0,0,0},    //Random
        DeptRec1,   //name
       //Group         Options  Tax  Kp
        01,   PLAYOUT, 0xc2,    0,   0,
        {0,0,0,0,0},        //Price
        {0,0,0,0,0}         //PriceMax
//Ccr 		{0,0,0,0,0,0,0}, "����    ",0,PLAYOUT,0,0,0,0           /* Department */
    },
    {   /* PLU */
//Ccr 		{0,0,0,0,0,0,0}, "��Ʒ    ",0,
        {0,0,0,0,0,0,0},            //Random
        PLURec1,        //Name
        0,                          //OFFIndex
        1,                          //Dept
        0,                          /* High Dept Number */
        {                           //Price
            {0,0,0,0,0},
            {0,0,0,0,0},
            {0,0,0,0,0},
            {0,0,0,0,0}
        },
        {0,0,0,0,0},                //Cost
        0,                          /* PLU Link */
        {0,{0,0,0,0,0,0,0,0}}               //NotUsed
    },
    {
        SalesPersonRec1, 0x00                /* Salesperson */
//Ccr 		"ӪҵԱ  ", 0x00                /* Salesperson */
    },
    {// struct OFFRECORD OFFPrice
        OffRec1,
        0,                              //Type
        {0x01,0x01},                            //Date From
        {0x01,0x01},                            //Date to
        {0x01,0x01},                            //Time from
        {0x01,0x01},                            //Time to
        0,                              //Week day
        0,//{0,{0,0,0,0},{0,0,0,0}},			//discount
    },
    {// struct PORTRECORD Port
        PortRec1,
        PORT4HOSTPC,                                //Type,host
        //BARCODE,SCALE,EXTLCD,EXTKEYB,KITCHEN,HOSTPC,NONE
        {0x43,    0x43,   0x43,   0x43,  0x43,  0x47,0x43},
        "0",
    },
    {//struct GRAPFORPRN Graph
        0,{0,0,0,0},{0,0,0,0},
    },
    {//strcut AGREERECORD Agree
        AgreeRec1,
        TeleRec1,
        "10000000",
        0,
    },
    {//struct ICBLOCKRECORD ICBlock;
        0
    }
};

//cc 2006-07-14 for EN>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>



CONSTCHAR *DMes[] = {//lenDMes=15
/*    These are messages for the display they MUST start with a SPACE     */
    DMes1,    //ItemDMes0,//   " CHANGE PRICE "        /* 0, Plu Price Change (PutsO
    DMes2,    //ItemDMes1 ,//   " ADD STOCK"       /* 1, Inventory ++  (PutsO)*/
    DMes3,    //ItemDMes2 ,//   " REMOVE STOCK"        /* 2, Inventory --  (PutsO)*/
    DMes4,    //ItemDMes3 ,//   " KP_GROUP"        /* 3, Kitchen Printer Group  (Put
    DMes5,    //ItemDMes4 ,//   " CORRECT"     /* 4, Correction (PutsO)*/
    DMes6,    //ItemDMes5 ,//   " REFUND"          /* 5, Refund (PutsO)*/
    DMes7,    //ItemDMes6 ,//   " CANCEL 1"        /* 6, Cancel 1 function (PutsO)*/
    DMes8,    //ItemDMes7 ,//   " CANCEL 2"        /* 7, Cancel 2 function (PutsO)*/
    DMes9,    //ItemDMes8 ,//   " RS232 ERROR"     /* 8, RS232 Test */
    DMes10,   //ItemDMes9 ,//   " RS232 OK"        /* 9, RS232 Test */
    DMes11,   //ItemDMes10,//   " RTC ERROR"       /* 10, RTC Test Error */
    DMes12,   //ItemDMes11,//   " CTC ERROR"       /* 11, CTC Test Error */
    DMes13,   //ItemDMes12,//   " FPROM ERROR"     /* 12, Fiscal Prom Error */
    DMes14,   //ItemDMes13,//   "INITIALIZATION"       /* 13, Clearing RAM (PutsO)*/
    DMes15,   //ItemDMes14,//   " INIT END"            /* 14, Initialising Applicati
    DMes16,   //ItemDMes15,//   " SLIP PAPER"      /* 15, Change Slip Paper (PutsO)*
    DMes17,   //ItemDMes16,//   " PASSWORD? "      /* 16, Secret Clerk Code */
    DMes18,   //ItemDMes17,//   " ERROR- "         /* 17, Error code        */
    DMes19,   //ItemDMes18,//   "PASSWORD ERROR"   /* 18, Error code   (PutsO)     *
    DMes20,   //ItemDMes19,//   " ACCEPTED"        /* 19, Error code   (PutsO)     *
    DMes21,   //ItemDMes20,//   "OPERATOR:"        /*20 �տ�Ա��  */
    DMes22,   //ItemDMes21,//   "S.PERSON: "       /* 21 ӪҵԱ:  */
    DMes23,   //ItemDMes22,//   "ECR#:"    /*22 �տ����  */  //ZWQ
    DMes24,   //ItemDMes23,//   "LOCATION:"        /*23 λ��  */ //ZWQ
    DMes25,   //ItemDMes24,//   "CONFIRM ?"        //24 (PutsO)
    DMes26,   //ItemDMes25,//   "COMPLETED"            //25        ???
    DMes27,   //ItemDMes26,//   "VERSION:"     //26 "���а汾" //
    DMes28,   //ItemDMes27,//   "POINTS"           //27 "�������ѵ�"   //
    DMes29,   //ItemDMes28,//   "ADD PLU "         //28 "���ӵ�Ʒ:"    //
    DMes30,   //ItemDMes29,//   "DELETE PLU:"      //29"ɾ����Ʒ:" //
    DMes31,   //ItemDMes30,//   "TEST STARTED>>"       //30"��ʼ���"  //
    DMes32,   //ItemDMes31,//   "TEST COMPLETED"       //31"������"  // ZWQ
    DMes33,   //ItemDMes32,//   "PRICE"            //32
    DMes34,   //ItemDMes33,//   "STOCK"        //33
};


CONST char UPCOMM[][4]={
    UPCOMM1,            //    0
    UPCOMM2,            //    1
    UPCOMM3,            //    2
    UPCOMM4,            //    3
};


CONSTCHAR *DText[] = {//lenDText=15,end by \0, lenDText <  sizeof(ModeHead)
    DText1,   //DTEXT_CURRENCY ,   /* 0, Foreign Currency */
    DText2,   //DTEXT_TOTAL ,      /* 1, Sales Total */
    DText3,   //DTEXT_CHANGE ,         /* 2, Change */
    DText4,   //DTEXT_SUBTOTAL ,   /* 3, Subtotal */
    DText5,   //DTEXT_DISCOUNT ,   /* 4, Discount */
    DText6,   //DTEXT_PO ,             /* 5, Paid Out */
    DText7,   //DTEXT_RA ,         /* 6, Received On Account */
    DText8,   //DTEXT_DRAWER ,     /* 7, Drawer */
    DText9,   //DTEXT_TABLE ,      /* 8, Table Number */
    DText10,  //DTEXT_SRVICE ,             /* 9, Service */
    DText11,  //DTEXT_CHKPAID,         /* 10, Checks Paid */
    DText12,  //DTEXT_CHKCANCEL,       /* 11, Checks Paid */
    DText13,  //DTEXT_GUEST,               /* 12, Covers */
    DText14,  //DTEXT_OPERATOR,        /* 13, Clerk */
    DText15,  //DTEXT_MODIFIER,        /* 14, Modifier */
    DText16,  //DTEXT_HOLD,                /* 15, Suspend/Recall tekst */
    DText17,  //DTEXT_CANCEL,              /* 16, Transaction void */
    DText18,  //DTEXT_SALER,           /* 17, SalesPerson */
    DText19,  //DTEXT_OFF,                 // 18, LOCK mode
    DText20,  //DTEXT_REG,                 // 19,Reg mode
    DText21,  //DTEXT_X,                   // 20,X report mode
    DText22,  //DTEXT_Z,               // 21,Z report mode
    DText23,  //DTEXT_SET,             // 22, SET mode
    DText24,  //DTEXT_MG,              // 23, Manager mode
    DText25,  //DTEXT_PASSWORD,        // 24,Password for XMode
    DText26,  //DTEXT_NEWPWD,          // 25,New password for xMode
    DText27,  //DTEXT_CONFIRMPWD,      // 26,Confirm new password for XMode
    DText28,  //DTEXT_PRICE,               /* 27	���� */
    DText29,  //DTEXT_AMOUNT,              /* 28  ��� */
    DText30,  //DTEXT_RETALL,          // 29
    DText31,  //DTEXT_RESTAURANT,      // 30
    "-",      //DTEXT_YEAR,                    /* 31 �� */
    "-",      //DTEXT_MONTH,                   /* 32 ��  */
    " ",      //DTEXT_DAY,                     /* 33 ��  */
    DText35,  //DTEXT_TEST,            // 34
    DText36,  //DTEXT_RAM,                 //35
    DText37,  //DTEXT_OBLI,             //36 MUST
    DText38   //DTEXT_FINISHED,        //37 finished
};

#if(DD_ZIP_21==1)
CONSTCHAR CusDText[][4]={
    CusDText1,
    CusDText2,
    CusDText3,
    CusDText4,
    CusDText5,
    CusDText6,
    CusDText7,
};
#endif

#if COMPOSEIN
CONST char CodeASC[NUMASC][4]={
    "10 ",
    "14!",
    "30\"",
    "24#",
    "34$",
    "44%",
    "40&",
    "20'",
    "54(",
    "64)",
    "74*",
    "60+",
    "80,",
    "50-",
    "70.",
    "90/",
    "000",
    "011",
    "022",
    "033",
    "044",
    "055",
    "066",
    "077",
    "088",
    "099",
    "84:",
    "94;",
    "15<",
    "35=",
    "25>",
    "45?",
    "95@",
    "11A",
    "12B",
    "13C",
    "21D",
    "22E",
    "23F",
    "31G",
    "32H",
    "33I",
    "41J",
    "42K",
    "43L",
    "51M",
    "52N",
    "53O",
    "61P",
    "62Q",
    "63R",
    "71S",
    "72T",
    "73U",
    "81V",
    "82W",
    "83X",
    "91Y",
    "92Z",
    "68_",
    "99~",
};
#endif

//    Captions for XZ report ,
//��FIXEDREPORT.ReportList[]�еı��������������,����XZREPORT�б�
CONST struct XZREPORT XZTitle[XZNUM]={
    {REPID_DAILYREPORT+1,   XZTitle1},  // {3, "�����ձ���"},    ItemXZ_DAILYREPORT,
    {REPID_PERIODREPORT+1,  XZTitle2},  // {4, "�����±���"},    ItemXZ_PERIODREPORT,
    {REPID_PLUDAILY+1,      XZTitle3},   // {5, "��Ʒ�ձ���"},      ItemXZ_PLUDAILY,
    {REPID_TABLEREPORT+1,   XZTitle4},  // {6, "���ʱ���"},      ItemXZ_TABLEREPORT,
    {REPID_TIMEZONE+1,      XZTitle5},  // {7, "ʱ�α���"},      ItemXZ_TIMEZONE,
    {REPID_CLERKDAILY+1,    XZTitle6},  // {1, "�տ�Ա�ձ���"},  ItemXZ_CLERKDAILY,
    {REPID_CLERKPERIOD+1,   XZTitle7},  // {2, "�տ�Ա�±���"},  ItemXZ_CLERKPERIOD,
    {REPID_ALLCLERKDAILY+1, XZTitle8},  // {8, "ȫ�տ�Ա�ձ�"},  ItemXZ_ALLCLERKDAILY,
    {REPID_ALLCLERKPERIOD+1,XZTitle9},  // {9, "ȫ�տ�Ա�±�"},  ItemXZ_ALLCLERKPERIOD,
#if (1)//ccr2017-12-13 (salNumber)
    {REPID_SALERDAILY+1,    XZTitle10}, //{10,"ӪҵԱ�ձ���"},   ItemXZ_SALERDAILY,
    {REPID_SALERPERIOD+1,   XZTitle11}, //{11,"ӪҵԱ�±���"},   ItemXZ_SALERPERIOD,
    {REPID_ALLSALERDAILY+1, XZTitle12}, //{12,"ȫӪҵԱ�ձ���"}, ItemXZ_ALLSALERDAILY,
    {REPID_ALLSALERPERIOD+1,XZTitle13}, //{13,"ȫӪҵԱ�±���"}, ItemXZ_ALLSALERPERIOD,
#endif
    //ccr2017-05-27>>>>>>>>>>>>>
    {REPID_DEPTDAILY+1 ,    XZTitle14}, //{14,"�����ձ���"},     ItemXZ_DEPTDAILY ,
    {REPID_DEPTPERIOD+1,    XZTitle15}, //{15,"�������ڱ���"},   ItemXZ_DEPTPERIOD,
    {REPID_GROUPDAILY+1,    XZTitle16}, //{16,"�����ձ���"},     ItemXZ_GROUPDAILY,
    {REPID_PLUPERIOD+1,     XZTitle17}, //{17, "��Ʒ���ڱ���"},  ItemXZ_PLUPERIOD,
    //ccr2017-05-27<<<<<<<<<<
//		{14,XZTitle14},
};


CONST char PortType[portTypeNum][PORTTYPELEN]={
    PortType1,
    PortType2,
    PortType3,
    PortType4,
    PortType5,
    PortType6,
    PortType7
#if 0	//cc 20070930
    "         MF1_IC",  //ccr epos
    "           EPOS"   //ccr epos
#endif
};

//�̶�Ϊ[7]
CONST char KPType[KPTypeNum][7]={
    KPType1,
    KPType2,
    "EPS-42",   //EPSON��ӡ��,ʹ��A����, 42�ַ�����
    "EPSONA",   //EPSON��ӡ��,ʹ��A����, 30�ַ�����
    "EPSONB",   //EPSON��ӡ��,ʹ��B����, 42�ַ�����
    "EPS-48",   //EPSON��ӡ��,���е�, 48�ַ�����
    "CITIZN",   //�����Ǵ�ӡ��, 30�ַ�����
    " POS58",   //POS58��ӡ��,���е�,30�ַ�����
};

CONST char SPType[SPTypeNum][8]={     // Lyq added for slip 20040331 start
    SPType1,
    SPType2,
    SPType3,
    SPType4,
    SPType5,
};                                    // Lyq added for slip 20040331 end

// PB-F1   PB-F2    PB-F3  PB-F4    PB-F5    PB-F6    PB-F7    PB-F8 PB-F9 PB-F10  PB-F11
//��̨���� ��̨���� �ݽ�   ȷ�Ͻ��� ��ӡ��̨ ��ӡ�ʵ� ȡ��ȷ�� ����  ת��  ת����  ����
#if (CASE_PCR01)
CONST WORD  KeyTablePBF[MAXKEYB] ={// KeyTable[128]
    JPF,        INPUTVATNO, CLERK,      CORREC+2,   CORREC+3,   DISC+2, //00-05
    MODELOCK,   0,          NPRICE,     CORREC+1,   CORREC+4,   DISC+4,     //07-11
    CLEAR,      MULT,       PLU1,       DEPT+5,     PBF+4,      PBF+1,      //12-17
    '7',        '8',        '9',        DEPT+4,     PBF+7,      PBF+5,      // 2,		//18-23
    '4',        '5',        '6',        DEPT+3,     DEPT+6,     SUB,        //24-29
    '1',        '2',        '3',        DEPT+2,     0,          TEND+1,     //30-35
    '0',        ZERO2,      '.',        DEPT+1,     0,          0,          //36-41
    0,          0,          0,          0,          0,          0,          //42-47
    0,          0,          0,          0,          0,          0,          //48-53
    0,          0,          0,          0,          0,          0,          //54-59
    0,          0,          0,          0xffff,                                 //60-63
};

#elif (CASE_ER50)
CONST WORD  KeyTablePBF[MAXKEYB] =
{//  KeyTable[128]
    JPF,        MODELOCK,   CORREC+3,   SHIFT1,     DISC+2,
    PLU1,       NPRICE,     CORREC+1,   DEPT+6,     DISC+1,
    CLEAR,      MULT,       CLERK,      DEPT+5,     PORA+1,
    '7',        '8',        '9',        DEPT+4,     PORA+12,
    '4',        '5',        '6',        DEPT+3  ,   SUB,
    '1',        '2',        '3',        DEPT+2,     TEND+1,
    '0',        ZERO2,      '.',        DEPT+1,     TEND+1,
    0,          0,          0,          0,          0,
    0,          0,          0,          0,          0,
    0,

};

#elif (defined(CASE_ER220)||defined(CASE_ER100)||defined(CASE_ECR100F)||defined(CASE_MCR30))
CONST WORD  KeyTablePBF[MAXKEYB] =
    #ifdef CASE_EURO
{//  KeyTable[128]

    MODELOCK,   JPF,    CLEAR,  MULT,       PLU1,       NPRICE,     DISC+2,
    CLERK,      '7',    '8',    '9',        PBF+1,      PBF+7,      DISC+1,//��̨��ȡ��ȷ��
    CORREC+1,   '4',    '5',    '6',        PBF+4,      PBF+5,      TEND+3,//ȷ�ϡ���ӡ��̨
    CORREC+2,   '1',    '2',    '3',        DEPT+2,     DEPT+4,     SUB,
    CORREC+4,   '0',    ZERO2,  '.',        DEPT+1,     DEPT+3,     TEND+1,
    0,          0,      0,      0,          0,          0,          0,
    0,          0,      0,      0,          0,          0,          0,
    0,          0,      0,      0,          0,          0,          0,
    0,          0,      0,      0,          0,          0,          0,
    0,

};
    #elif (defined(CASE_MALTA))
{//  KeyTable[128]
    MODELOCK,   JPF,    CLEAR,  MULT,       PLU1,       INPUTVATNO, DISC+2,
    CORREC+4,   '7',    '8',    '9',        PBF+4,      PBF+1,      DISC+4,
    CORREC+2,   '4',    '5',    '6',        PBF+7,      PBF+5,      TEND+2,
    CORREC+1,   '1',    '2',    '3',        DEPT+2,     DEPT+4,     SUB,
    ODRAW,      '0',    ZERO2,  '.',        DEPT+1,     DEPT+3,     TEND+1,
    0,          0,      0,      0,          0,          0,          0,
    0,          0,      0,      0,          0,          0,          0,
    0,          0,      0,      0,          0,          0,          0,
    0,          0,      0,      0,          0,          0,          0,
    0,
};
    #else
{//  KeyTable[128]
    MODELOCK,   JPF,    CLEAR,  MULT,       PLU1,       NPRICE,     DISC+2,
    CORREC+4,   '7',    '8',    '9',        PBF+4,      PBF+1,      DISC+4,
    CORREC+2,   '4',    '5',    '6',        PBF+7,      PBF+5,      TEND+2,
    CORREC+1,   '1',    '2',    '3',        DEPT+2,     DEPT+4,     SUB,
    ODRAW,      '0',    ZERO2,  '.',        DEPT+1,     DEPT+3,     TEND+1,
    0,          0,      0,      0,          0,          0,          0,
    0,          0,      0,      0,          0,          0,          0,
    0,          0,      0,      0,          0,          0,          0,
    0,          0,      0,      0,          0,          0,          0,
    0,
};
    #endif

#elif (defined(CASE_ER260) || defined(CASE_ER260F))

CONST WORD  KeyTablePBF[MAXKEYB] ={// KeyTable[128]
    JPF,        MULT,   NPRICE, PLU1,   PBF+4,  PBF+1,      DISC+4,     DISC+2,     //00-07
    MODELOCK,   '7',    '8',    '9',    PBF+7,  PBF+5,      CORREC+3,   CORREC+2,   //08-15
    CLERK,      '4',    '5',    '6',    DEPT+5, DEPT+6,     PORA+1,     CORREC+1,   //16-23
    ODRAW,      '1',    '2',    '3',    DEPT+3, DEPT+4,     PORA+2,     SUB,        //24-31
    CLEAR,      '0',    ZERO2,  '.',    DEPT+1, DEPT+2,     TEND+4,     TEND+1,     //32-39
    0,          0,      0,      0,      0,      0,          0,          0,          //40-47
    0,          0,      0,      0,      0,      0,          0,          0,          //48-55
    0,          0,      0,      0,      0,      0,          0,          0,      //56-63
};

#elif (CASE_ER28S)
CONST WORD  KeyTablePBF[MAXKEYB] ={//  KeyTable[128]
    CLEAR,  MODELOCK,   MULT,       PLU1,       CLERK,      DISC+2,     //00-05
    '7',    '8',        '9',        DEPT+7,     DEPT+8,     CORREC+2,   //06-11
    '4',    '5',        '6',        DEPT+5,     DEPT+6,     CORREC+1,   //12-17
    '1',    '2',        '3',        DEPT+3,     DEPT+4,     SUB,        //18-23
    '0',    ZERO2,      '.',        DEPT+1,     DEPT+2,     TEND+1,     //24-29
    0,      0,          0,          0,          0,          0,          //30-35
    0,      0,          0,          0,          0,          0,          //36-41
    0,      0,          0,          0,          0,          0,          //42-47
    0,      0,          0,          0,          0,          0,          //48-53
    0,      0,          0,          0,          0,          0,          //54-59
    0,      0,          0,          0,                                  //60-63
};

#elif (CASE_ER28T)

CONST WORD  KeyTablePBF[MAXKEYB] ={//  KeyTable[128]
    JPF,    MULT,NPRICE,PLU1,DEPT+9,DEPT+10,DISC+4,DISC+2,      //    00-07
    MODELOCK,   '7','8','9',DEPT+7,DEPT+8,CORREC+3,CORREC+2,    //    08-15
    CLERK,'4','5','6',DEPT+5,DEPT+6,PORA+1,CORREC+1,    //    16-23
    ODRAW,'1','2','3',DEPT+3,DEPT+4,PORA+2,SUB, //    24-31
    CLEAR,'0',ZERO2,    '.',DEPT+1,DEPT+2,TEND+4,TEND+1,        //    32-39
    0,      0,  0,  0,  0,  0,          0,          0,          //    40-47
    0,     0,  0,  0,  0,  0,          0,          0,          //    48-55
    0,     0,  0,  0,  0,  0,          0,          0,          //    56-63
};

#elif (CASE_WISE158)

CONST WORD  KeyTablePBF[MAXKEYB] ={//  KeyTable[128]
#if (0)//!defined(FISCAL)
    PLU1,  NPRICE,MULT, DISC+1,DISC+2,    DISC+4,
    DEPT+4, DEPT+8, DEPT+12,SHIFT1,     JPF,       DATETIME,ODRAW,MODELOCK,     DEPT,   '7',     '8',       '9',      CORREC+3,CORREC+1,
    DEPT+3, DEPT+7, DEPT+11,DEPT+15,    PBF+1,PBF+9,         PBF+8,  PBF+11,        CLERK, '4',  '5',       '6',      CORREC+4,CORREC+2,
    DEPT+2, DEPT+6, DEPT+10,DEPT+14,    PBF+5,PBF+6,         PBF+10,MODI,           SALPER,'1',  '2',       '3',      TEND+4,     SUB,
    DEPT+1, DEPT+5, DEPT+9, DEPT+13,    PBF+4,PBF+7,         PORA+2,PORA+1,     CLEAR, '0',      ZERO2,'.',   TEND+1, TEND+1,
    0,      0xffff, //0 	//hf_20060519 discard restaruant switch
#else
/* liuj 0606
                                                                                        PLU1,	NPRICE,	MULT,	DISC+1,	DISC+2,		DISC+4,
        DEPT+4,	DEPT+8,	DEPT+12,	SHIFT1,		JPF,		DATETIME,	ODRAW,	MODELOCK,	DEPT,	'7',	 	'8',	    	'9',	  	CORREC+3,	CORREC+1,
        DEPT+3,	DEPT+7,	DEPT+11,	DEPT+15,	PBF+1,	PBF+9,		PBF+8,	PBF+11,		CLERK,	'4',	 	'5',	    	'6',	  	CORREC+4,	CORREC+2,
        DEPT+2,	DEPT+6,	DEPT+10,	DEPT+14,	PBF+5,	PBF+6,		PBF+10,	MODI,		SALPER,	'1',	 	'2',	    	'3',	  	TEND+4,		SUB,
        DEPT+1,	DEPT+5,	DEPT+9,		DEPT+13,	PBF+4,	PBF+7,		PORA+2,	PORA+1,		CLEAR,	'0', 	 	ZERO2,	'.',	  	TEND+1,		0,
        0,		0xffff,
*/
    MODELOCK,   MULT,   DISC+1, DISC+2, DISC+4,     CORREC+3,
    DEPT+4, DEPT+8,     DEPT+12,    DEPT+16,    PBF+1,PBF+7,    SHIFT1,     JPF,            PLU1,       '7',        '8',        '9',        CORREC+2,   CORREC+1,
    DEPT+3, DEPT+7,     DEPT+11,    DEPT+15,    PBF+4,PBF+8,    DEPT,       NPRICE,     PORA+2,     '4',        '5',        '6',        CORREC+4,   CURR,
    DEPT+2, DEPT+6,     DEPT+10,    DEPT+14,    PBF+5,PBF+9,    USERINFO,   PBF+11, PORA+1,     '1',        '2',        '3',        TEND+4,     SUB,
    DEPT+1, DEPT+5,     DEPT+9,     DEPT+13,    PBF+6,PBF+10,   CLERK,      PBF+12,     CLEAR,      '0',        ZERO2,  '.',        TEND+1,     TEND+1,
    0,      0,

#endif
};
//cc 20070312

#elif CASE_ER380
//lyq added for giada din keyboard 2003\10\23 end
CONST WORD  KeyTablePBF[MAXKEYB] ={// KeyTable[128]
    JPF,        CLERK,      DATETIME,   PBF+11,     PBF+1,      SHIFT1,     CORREC+3,   DISC+4,     //00-07
    MODELOCK,   0,          NPRICE,     PLU1,       MODI,       PBF+6,      DISC+2,     DISC+1,     //08-15
    CORREC+2,   CORREC+4,   CORREC+1,   MULT,       PBF+8,      PBF+9,      PBF+4,      PBF+7,      //16-23
    ODRAW,      '7',        '8',        '9',        PBF+5,      PBF+10,     TEND+2,     TEND+4,     //24-31
    SALPER,     '4',        '5',        '6',        DEPT+3,     DEPT+6,     TEND+2,     CURR,       //32-39
    CLEAR,      '1',        '2',        '3',        DEPT+2,     DEPT+5,     SUB,        0,          //40-47
    0,          '0',        ZERO2,      '.',        DEPT+1,     DEPT+4,     TEND+1,     0,          //48-55
    0,          0,          0,          0,          0,          0,          0,          0xffff,     //56-63
};
#endif

CONST struct SYSFLAGIDX SysFlagUsed[SYSUSED] ={
//  ��YN�Ŀ����������ʾ0ΪON,1ΪOFF;//
#if ((DISP2LINES) || DD_LCD_1601==1)
	{15,255,0,0,SysFlag_ECRNo},//(1)00-255"ECR_no"
//ccr2017-07-28	{14,255,0,0,SysFlag_SHOPNo},//(1)00-255"ECR_Location"
//ccr2017-07-28	{63,4,0,0,SysFlag_ROUND},//(2)10,1,2,3,4"Round_"
	{54,0,0,0,SysFlagAmtMax},//(1)00-255"MAX AMT 1 of receipt"
//ccr2017-12-20	{24,0,6,YN,SysFlag_CHGPRICE},//(3)2bit1"PLU_Free"
	{4,0,1,YN,SysFlag_BEEP},//(4)3bit0"beep"
	{9,0,1,0,SysFlag_CLERKMUST},//(5)4bit0"Obl_Oper"
//	{9,0,3,0,SysFlag_CLERKLOGIN},//(6)5bit0"DisX_Oper"
	{9,0,6,0,SysFlag_CLERKPWD},//(7)6bit0"Pass_Oper"
//ccr2017-07-28	{24,0,5,0,SysFlag_PRNSALER},//(8)7bit0"Saleper_Num"
#if PRNCLERK
	{9,0,4,0,SysFlag_CLERK},//(9)8bit0"Prin_Oper"
#endif
//	{1,0,4,YN,SysFlag_PRNRECNo},//(10)9bit3"Prin_Recn"
//ccr2017-07-28	{4,0,7,0,SysFlag_SALERMUST},//(12)11bit6"Obl_Saleper_"
//ccr2017-07-28	{24,0,1,0,SysFlag_PRNPLUNo},//(13)12bit0"ArtCode"
	{9,0,8,0,SysFlag_SUBTMUST},//(14)13bit0"Obl_Subt_"
	{5,0,1,0,SysFlag_PRNITEMS},//(15)14bit0"Art_no_"
//ccr2017-05-22	{24,0,7,YN,SysFlag_PRNALLONE},//(16)15bit7"TALLONS"
//ccr2017-05-22	{25,0,5,0,SysFlag_ALLONEHEAD},//(17)16bit0"TALLON HEADER AND TAILER"
//ccr2017-07-28	{60,0,8,0,SysFlag_SHIFTDEPT},//(18)17bit7"En_Shift"
	{21,99,0,0,SysFlag_IDLETIME},//(19)180..99"Time_IDLE"
	{62,0,1,0,SysFlag_COPYRECEIPT},//(20)190..15"Copy Receipt"
//ccr2017-12-20	{23,0,4,0,SysFlag_PREONAMT},//(21)20bit3"EANSpec_"
	{0,0,5,YN,SysFlag_AMTPOINT},//(22)21bit4"input Amt Point"//
#if  CUSTOMERCARD
//ccr2017-12-20	{2,0,8,0,SysFlag_SUMMERTIME},//daylighttime
	{5,0,2,0,MsgCUSTOMERCARD},////ccr2017-09-21CUSTOMER RECEIPT CARD(CASE_EURO)
#endif
//ccr2017-05-22	{19,0,5,0,SysFlag_PRNBALANCE},//(23)22bit4"select pbprint"//lyq2003
//ccr2017-07-28	{19,0,6,0,SysFlag_PRNSTOCK},//(24)23bit4"select invprint"//lyq2003
//ccr2017-05-22	{25,0,6,0,SysFlag_DISPRINT},//(25)24bit5"allow press operator key to close printer"//lyq2003
#if (DD_DISABLEPBF==0)
	{18,0,1,0,SysFlag_TABLEMUST},//(25)24"���뿪̨:"},
#endif
//ccr2017-05-22	{18,0,5,0,SysFlag_KEEPRECNo},//(26)25"�����վݺ�"},
//ccr2017-05-22	{19,0,7,0,SysFlag_COPYKPRN},//(27)26//ccr040810
//	{62,0,8,0,SysFlag_RESETRECNo},//(28)27"�վݺŸ�λ"//
//ccr2017-05-22	{22,0,1,0,SysFlag_CUTTER},//(29)28"ʹ���е�"//
//ccr2017-07-28	{3,2,0,0,SysFlag_DATETYPE},//(30)290-2"Date Type"
//ccr2017-07-28	{2,0,1,YN,SysFlag_TIMETYPE},//(31)30bit0"time format 12 or 24"
//ccr2017-07-28	-{26,0,4,YN,SysFlag_HEADCENTER},//31bit3"Ʊͷ���д�ӡ"
//ccr2017-07-28	-{26,0,5,YN,SysFlag_TRAILCENTER},//32bit4"Ʊβ���д�ӡ"
        {60,0,6,0,SysFlag_PRINTTAXAMT},//ccr2018-03-20�Ƿ��ڽ���ʱ��ӡ��˰��PRINTTAXAMT
#else
	{15,255,0,0,},//(1)00-255"ECR_no"
//ccr2017-07-28	{14,255,0,0,},//(1)00-255"LOC_no"
//ccr2017-07-28	{63,4,0,0,},//(2)10,1,2,3,4"Round_"
	{24,0,6,YN,},//(3)2bit1"PLU_Free"
	{4,0,1,YN,},//(4)3bit0"beep"
	{9,0,1,0,},//(5)4bit0"Obl_Oper"
//	{9,0,3,0,},//(6)5bit0"DisX_Oper"
	{9,0,6,0,},//(7)6bit0"Pass_Oper"
//ccr2017-07-28	{24,0,5,0,},//(8)7bit0"Saleper_Num"
#if PRNCLERK
	{9,0,4,0,},//(9)8bit0"Prin_Oper"
#endif
//	{1,0,4,yn,},//(10)9bit3"Prin_Recn"
//ccr2017-07-28	{4,0,7,0,},//(12)11bit6"Obl_Saleper_"
//ccr2017-07-28	{24,0,1,0,},//(13)12bit0"ArtCode"
	{9,0,8,0,},//(14)13bit0"Obl_Subt_"
	{5,0,1,0,},//(15)14bit0"Art_no_"
//ccr2017-05-22	{24,0,7,YN,},//(16)15bit7"TALLONS"
//ccr2017-05-22	{25,0,5,0,},//(17)16bit0"TALLON HEADER AND TAILER"
//ccr2017-07-28	{60,0,8,0,},//(18)17bit7"En_Shift"
	{21,99,0,0,},//(19)180..99"Time_IDLE"
	{62,15,0,0,},//(20)190..15"Copy Receipt"
	{23,0,4,0,},//(21)20bit3"EANSpec_"
	{1,0,1,YN,},//(22)21bit0"Amt Pointor COMMA"//
#if  CUSTOMERCARD
//	{2,0,8,0,},//daylight time
	{5,0,2,0,},////ccr2017-09-21CUSTOMER RECEIPT CARD(CASE_EURO)
#endif
//ccr2017-05-22	{19,0,5,0,},//(23)22bit4"select pbprint"//lyq2003
//ccr2017-07-28	{19,0,6,0,},//(24)23bit4"select invprint"//lyq2003
//ccr2017-05-22	{25,0,6,0,},//(25)24bit5"allow press operator key to close printer"//lyq2003
#if (DD_DISABLEPBF==0)
	{18,0,1,0,},//(25)24"���뿪̨:"},
#endif
//ccr2017-05-22	{18,0,5,0,},//(26)25"�����վݺ�"},
//ccr2017-05-22	{19,0,7,0,},//(27)26//ccr040810
//	{62,0,8,0,},//(28)27"�վݺŸ�λ"//
//ccr2017-05-22	{22,0,1,0,},//(29)28"ʹ���е�"//
//ccr2017-07-28	{3,2,0,0,},//(30)290-2"Date Type"
//ccr2017-07-28	{2,0,1,YN,},//(31)30bit0"time format 12 or 24"
//ccr2017-07-28	-{26,0,4,YN,},//31bit3"Ʊͷ���д�ӡ"
//ccr2017-07-28	-{26,0,5,YN,},//32bit4"Ʊβ���д�ӡ"
        {60,0,6,0},//ccr2018-03-20�Ƿ��ڽ���ʱ��ӡ��˰��PRINTTAXAMT

#endif

};


CONST char GrapType[GRASETMAX][tCAPWIDTH]={
    GrapType1,
    GrapType2,
    GrapType3,
    GrapType4,
};

CONST char GrapSet[4][tCAPWIDTH]={
    GrapSet1,
    GrapSet2,
    GrapSet3,
    GrapSet4,
};


//    cc 20070312 for EN>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

CONSTCHAR *ConfTab[] =
{
    ConfTab1,       //	"�ļ�����"��0
    ConfTab2,       //	"�ļ��ռ䣺" 1
    ConfTab3,       // "ͳ���ļ�"	2
    ConfTab4,       //��������Ϣ��	3
    ConfTab5,       //���������Ϣ��4
    ConfTab6,       // ��Ǯ����Ϣ�� 5
    ConfTab7,       // ��������Ϣ�� 6
    ConfTab8,       // �������Ϣ�� 7
    ConfTab9,       // ����˰��8
    ConfTab10,      //	"��̨����"��9
    ConfTab11,      //	"��������ļ���"					10
    ConfTab12,      //	��ǩ���ļ�:��11
    ConfTab13,      //	"��Ʒ�����ļ���"12
    ConfTab14,      // ��������Ϣ��13
    ConfTab15,      // ����̨��������14
    ConfTab16,      //	"��ˮ�ռ䣺"15
    ConfTab17,      // �����ڡ�	16
    ConfTab18,      //17 RAM size
    ConfTab19,      //18 GUASHIIC
    ConfTab20,      //19 size of FM
    ConfTab21,		//20"       FREE"         //19
    ConfTab22		//21" FREE OF FM"         //19
};

CONSTCHAR *ConfTi[2] =
{
    ConfTi1,
    ConfTi2
};
// #endif


//    cc 20070312 for EN>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>


//#if defined(FISCAL)
/*
CONST BYTE	ASCIIKEY[MAXKEYB]={
                                    0,	0,	0,	0,	0,	0,
    '@',	'~',	0,	0,	0,	0,	0,	0,	'P',	'7',	'8',	'9',	0,	0,
    'Q',	'W',	'E',	'R',	'T',	'Y',	'U',	'I',	'O',	'4',	'5',	'6',	0,	0,
    'A',	'S',	'D',	'F',	'G',	'H',	'J',	'K',	'L',	'1',	'2',	'3',	0,	0,
    'Z',	'X',	'C',	'V',	'B',	'N',	'M',	' ',	0,	'0',	0,	'.',	0,	0,
    0,	0,
};

CONST BYTE	NUMASC_KEYBOARD[MAXKEYB]={
                                                0,	0,	0,	0,	0,	0,
    '@',	'~',		'!',		0x22,	'#',	'$',	0,	0,	0,	'7',	'8',	'9',	0,	0,
    '%',	'&',		0x27,	'(',		')',	'*',	'+',	',',	0,	'4',	'5',	'6',	0,	0,
    '-',	'/',		':',		';',		'<',	'=',	'>',	'?',	0,	'1',	'2',	'3',	0,	0,
    '[',	0x5c,	']',		'^',		'_',	'{',	'|',	'}',	0,	'0',	0,	'.',	0,	0,
    0,	0,
};
*/
#if defined(FOR_FLASHRAM)//ccr2017-10-13 testonly
CONST BYTE  ASCIIKEY[MAXKEYB]=
{
    0,      0,      0,      0,      'a',    0,
    'c',    'd',    'e',    'f',    'g',    0,
    'i',    'j',    'k',    'l',    'm',    0,
    'o',    'p',    'q',    'r',    's',    0,
    'u',    'v',    'w',    'x',    'y',    0,
    0,      0,      0,      0,      0,      0,
    0,      0,      0,      0,      0,      0,
    0,      0,      0,      0,      0,      0,
    0,      0,      0,      0,      0,      0,
    0,      0,      0,      0,      0,      0,

};
CONST BYTE  NUMASC_KEYBOARD[MAXKEYB]=
{
    0,      0,      0,      0,      '/',     0,
    '(',    '7',    '8',    '9',    128,     0,
    ')',    '4',    '5',    '6',    '-',     0,
    '%',    '1',    '2',    '3',    '?',     0,
    '+',    '0',    ';',   '.',     ':',     0,
    0,      0,      0,      0,      0,       0,
    0,      0,      0,      0,      0,       0,
    0,      0,      0,      0,      0,       0,
    0,      0,      0,      0,      0,       0,
    0,      0,      0,      0,      0,       0,

};
#elif (CASE_PCR01)
CONST BYTE  ASCIIKEY[MAXKEYB]=
{
    0,      'a',    'b',    'c',    'd',    0,  //00-05
    0,      0,      'e',    'f',    'g',    0,  //06-11
    0,      0,      'h',    'i',    'j',    '~',    //12-17
    'k',    'l',    'm',    'n',    'o',    0,      //18-23
    'p',    'q',    'r',    's',    't',    0,      //24-29
    'u',    'v',    'w',    'x',    0,      0,      //30-35
    'y',    0,      '.',    'z',    0,      0,      //36-41

    0,  0,  0,  0,  0,  0,          //42-47
    0,  0,  0,  0,  0,  0,          //48-53
    0,  0,  0,  0,  0,  0,          //54-59
    0,  0,  0,  0,                          //60-63
};

CONST BYTE  NUMASC_KEYBOARD[MAXKEYB]=
{
    0,      '#',    '$',    '%',    '/',    0,  //00-05
    0,      0,      '(',    ')',    '-',    0,  //06-11
    0,      0,      '{',    '}',    '@',    '~',    //12-17
    '7',    '8',    '9',    '\'',   '?',    0,      //18-23
    '4',    '5',    '6',    ':',    ';',    0,      //24-29
    '1',    '2',    '3',    '[',    0,      0,      //30-35
    '0',    0,      '.',    ']',    0,      0,      //36-41

    0,  0,  0,  0,  0,  0,          //42-47
    0,  0,  0,  0,  0,  0,          //48-53
    0,  0,  0,  0,  0,  0,          //54-59
    0,  0,  0,  0,                          //60-63

};

#elif CASE_ER50
CONST BYTE  ASCIIKEY[MAXKEYB]=
{

    0,      0,      'x',    'y',    'z',
    's',    't',    'u',    'v',    'w',
    0,      0,      'q',    'r',    0,
    'm',    'n',    'o',    'p',    0,
    'i',    'j',    'k',    'l',    0,
    'e',    'f',    'g',    'h',    0,
    'a',    'b',    'c',    'd',    0,
    0,      0,      0,      0,      0,
    0,      0,      0,      0,      0,

};
CONST BYTE  NUMASC_KEYBOARD[MAXKEYB]=
{
    0,      0,      '~',    '/',    '@',
    '#',    '$',    '%',    '&',    '*',
    0,      0,      '-',    '+',    0,
    '7',    '8',    '9',    '(',    0,
    '4',    '5',    '6',    ')',    0,
    '1',    '2',    '3',    ';',    0,
    '0',    ',',    '.',    '"',    0,
    0,      0,      0,      0,      0,
    0,      0,      0,      0,      0,

};

#elif (defined(CASE_ER220)||defined(CASE_ER100)||defined(CASE_ECR100F)||defined(CASE_MCR30))
CONST BYTE  ASCIIKEY[MAXKEYB]=
{
    0,      0,      0,      0,      'a',    'b',    0,
    'c',    'd',    'e',    'f',    'g',    'h',    0,
    'i',    'j',    'k',    'l',    'm',    'n',    ' ',
    'o',    'p',    'q',    'r',    's',    't',    0,
    'u',    'v',    'w',    'x',    'y',    'z',    0,
    0,      0,      0,      0,      0,      0,      0,
    0,      0,      0,      0,      0,      0,      0,
    0,      0,      0,      0,      0,      0,      0,
    0,      0,      0,      0,      0,      0,      0,
    0,

};
CONST BYTE  NUMASC_KEYBOARD[MAXKEYB]=
{
    0,      0,      0,      0,      '/',     '&',   0,
    '(',    '7',    '8',    '9',    128,     '~',   0,
    ')',    '4',    '5',    '6',    '-',     '_',   ' ',
    '%',    '1',    '2',    '3',    '?',     '@',   0,
    '+',    '0',    ';',   '.',     ':',     0x27,  0,
    0,      0,      0,      0,      0,      0,      0,
    0,      0,      0,      0,      0,      0,      0,
    0,      0,      0,      0,      0,      0,      0,
    0,      0,      0,      0,      0,      0,      0,
    0,

};
#elif (defined(CASE_ER260) || defined(CASE_ER260F))
CONST BYTE  ASCIIKEY[MAXKEYB]=
{
    0,      0,      'a',    'b',    'c',    'd',        '~',    0,      //00-07
    0,      'e',    'f',    'g',    'h',    'i',        'j',    0,  //08-15
    'k',    'l',    'm',    'n',    'o',    'p',        'q',    0,  //16-23
    'r',    's',    't',    'u',    'v',    'w',        'x',    0,  //24-31
    0,      ',',    0,      '.',    '@',    'y',        'z',    0,      //32-39
    //
    0,      0,      0,      0,      0,      0,          0,      0,          //40-47
    0,      0,      0,      0,      0,      0,          0,      0,          //48-55
    0,      0,      0,      0,      0,      0,          0,      0,      //56-63

};
CONST BYTE  NUMASC_KEYBOARD[MAXKEYB]=
{
    0,      0,      '!',    ':',    '#',    '$',        '~',    0,      //00-07
    0,      '7',    '8',    '9',    '%',    '^',        '&',    0,  //08-15
    '*',    '4',    '5',    '6',    '[',    ']',        '/',    0,  //16-23
    '=',    '1',    '2',    '3',    '(',    ')',        '-',    0,      //24-31
    0,      '0',    0,      '.',    '@',    '"',        '\'',   0,      //32-39
    //
    0,      0,      0,      0,      0,      0,          0,      0,          //40-47
    0,      0,      0,      0,      0,      0,          0,      0,          //48-55
    0,      0,      0,      0,      0,      0,          0,      0,      //56-63

};

#elif CASE_WISE158
CONST BYTE  ASCIIKEY[MAXKEYB]={
    '`','*','-', 0, 0 ,0 ,
    '~','!','@','#','$','%','(',')','p','7','8','9','+',0 ,
    'q','w','e','r','t','y','u','i','o','4','5','6','-',0,
    'a','s','d','f','g','h','j','k','l','1','2','3','[',']',
    'z','x','c','v','b','n','m',',',8  ,'0',';','.','=',0,
};

CONST BYTE  NUMASC_KEYBOARD[MAXKEYB]={
    0,  0,  0,  0,  0,  0,
    '@',    '~',        '!',        0x22,   '#',    '$',    0,  0,  0,  '7',    '8',    '9',    0,  0,
    '%',    '&',        0x27,   '(',        ')',    '*',    '+',    ',',    0,  '4',    '5',    '6',    0,  0,
    '-',    '/',        ':',        ';',        '<',    '=',    '>',    '?',    0,  '1',    '2',    '3',    0,  0,
    '[',    0x5c,   ']',        '^',        '_',    '{',    '|',    '}',    0,  '0',    0,  '.',    0,  0,
    0,  0,
};
#elif CASE_ER380
CONST BYTE  ASCIIKEY[MAXKEYB] = {
    0,  'a','b','c','d','e','f','g',
    0,  0,  'h','i','j','k','l','m',
    'n','o','p',0,  'q','r',' ',0,
    '@','7','8','9','s','t',0,  0,
    '~','4','5','6','u','v',0,  0,
    0,  '1','2','3','w','x',0,  0,
    0,  '0',0,  '.','y','z',0,  0,
    0,  0,  0,  0,  0,  0,  0,  0,
};

CONST BYTE  NUMASC_KEYBOARD[MAXKEYB] = {
    0,  '/',0x22,'#','$',   '%',    '&',0x27,
    0,  0,  '(', ')','*',   '+',    ',','-',
    '/',':',';', 0,  '<',   '=',    '>','?',
    '@','7','8', '9','[',   0x5c,   0,  0,
    '~','4','5', '6',']',   '^',    0,  0,
    0,  '1','2', '3','_',   '{',    0,  0,
    0,  '0',0,   '.','|',   '}',    0,  0,
    0,  0,  0,   0,   0,    0,      0,  0,
};
#endif


CONST WORD TblAUX_Funcs[AUX_FUNCITEMS]={
    CMD_PRINTPLU    ,
    CMD_EXPLOREEJ   ,
    CMD_PRINTFISCAL ,
    CMD_PRINTEJ     ,
    CMD_SETPWDX     ,
    CMD_SETPWDZ     ,
    CMD_SETPWDSET   ,
    CMD_SETPWDMG    ,
    CMD_INITFISCAL  ,
    CMD_INITEJ      ,
    CMD_PRNGAPHIC   ,
    CMD_ECRCONFIG   ,
};
//ccr2017-05-31 XZ���µĹ����б�,��Ŀ����X+Z�Ĺ�����Ŀ��ͬ >>>>>>>>>>>>
CONST BYTE TblXZ_Funcs[ITEMS_X+ITEMS_Z]={
//>>>>>>>>����X��������>>>>>>>>>
        ItemXZ_DAILYREPORT  ,// "DAILY JOURNAL"
        ItemXZ_DEPTDAILY    ,         // "DEPARTMENT DAILY"
        ItemXZ_PLUDAILY     ,         // "PLU DAILY"
        ItemXZ_ALLCLERKDAILY,         // "CLERKS DAILY"
#if (salNumber)
        ItemXZ_ALLSALERDAILY,         // "WAITERS DAILY"
#endif
        ItemXZ_GROUPDAILY   ,         //"CATEGORY DAILY"
        CMD_xALLDAILY       ,         // "ALL DAILY"
        CMD_xGENERALPARAM	,    // "GENERAL PARAMETERS"
//>>>>>>����Z��������,������Ŀʱ,ע���޸�>>>ApplVar.ReportNumber-CMD_zZERODEPARTMENT+ITEMS_X+2
        ItemXZ_DAILYREPORT  ,// "PRINT Z REPORT"
#if defined(CMD_zHTTPPOSTSFILE)
        CMD_zHTTPPOSTSFILE ,                // "SEND S-FILES OF Z"
#endif
        CMD_zCOPYLASTZ  	,                  //"COPY OF LAST Z"
        ItemXZ_DEPTPERIOD	,                  //"DEPARTMENT SALES"
        ItemXZ_PLUPERIOD    ,                //  "PLU SALES"
        ItemXZ_ALLCLERKPERIOD,                // "CLERKS  SALES"
#if (salNumber)
        ItemXZ_ALLSALERPERIOD,                // "WAITERS  SALES"
#endif
        CMD_zZERODEPARTMENT ,                //  "ZERO DEPARTMENT"
        CMD_zZEROPLUSALES   ,                // "ZERO PLU SALES"
        CMD_zZEROCLERKS     ,                //  "ZERO CLERKS"
#if (salNumber)
        CMD_zZEROWAITERS    ,                //  "ZERO WAITERS"
#endif
        CMD_zZEROALLSALES   ,                // "ZERO ALL SALES"
        CMD_zFMREADZ_Z      ,                // "FM READ Z-Z"
        CMD_zFMREADDATE     ,                // "FM READ DATE"
#if defined(CMD_zFMREADTAXRATE)
        CMD_zFMREADTAXRATE ,                // "READ TAX RATE "
        CMD_zFMREADHEAD    ,                // "READ HEAD "
        CMD_zFMREADSETDATE ,                // "READ DATE CHANGED"
#endif
};

