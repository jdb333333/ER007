#define EXTM_C 1
#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
#include "message.h"


extern CONST WORD  KeyTablePBF[MAXKEYB];
//extern CONSTBYTE Graph_001[];		//Indirizzo del "disegno" (vedi file "graphics.a30")


#if defined(DEBUGBYPC)
extern void sysGetDateTime();
extern void sysSetDateTime();
#endif

//==============================================================

#if (PC_EMUKEY)

#include "FEcrTest.h"
#if defined(DEBUGBYPC)
#include "FEcrTest.cpp"
#else
#include "FEcrTest.c"
#endif
#endif


void EmptyComm(BYTE port);
void SendComm(BYTE port,BYTE byte);

//calculate the keys of DEPT&PLU on the current KeyTable
void DeptPluKeysCount()
{
	short i;

	ApplVar.DeptKeys = ApplVar.PluKeys = 0;
	for (i=0;i<MAXKEYB-1;i++)
	{
		if (ApplVar.AP.KeyTable[i]>=DEPT+1 && ApplVar.AP.KeyTable[i]<PLU1)
			ApplVar.DeptKeys++;
		else if (ApplVar.AP.KeyTable[i]>=PLU1+1 && ApplVar.AP.KeyTable[i]<PLU3)
			ApplVar.PluKeys++;
	}
}
//Test if BARCode reader is online or not?
BYTE CheckOnLine(BYTE port)
{
	return 1;
}

void PrintDotEpson(void)
{
	if (!MyFlags( CLOSEPRINT))
		RJPrint(0,MessageE47);
}

//if pBCD==0 return false else return true
//
short CheckNotZero(BCD *pBCD)
{
    short sLp;

    for (sLp=0;sLp<BCDLEN;sLp++)
        if (pBCD->Value[sLp] != 0)
            return 1;
    return 0;
}
//
void WaitOnLine(BYTE port)
{
	char rBuf[1];

	Bios_PortRead(port+1, rBuf, 0, 1000/5, NULL);//time out=1's
}



short RFeed(short line)
{
	short sLp;

#if !defined(DEBUGBYPC)
	if (!MyFlags( CLOSEPRINT))
		for (sLp=0;sLp<line;sLp++)
		{
#if (PC_EMUKEY)
			if (!FisTestTask.PrnOFF)
#endif
			Excute_CR();							//    Line Feed standard
		}
#endif
}

short JFeed()
{
#if !defined(DEBUGBYPC)
	if (!MyFlags( CLOSEPRINT))
#if (PC_EMUKEY)
    if (!FisTestTask.PrnOFF)
#endif
		Excute_CR();								//Line Feed standard
#endif
}


//
void SetRts(BYTE port, BYTE OnOff)
{
}

//==================================================================
//short RJPrint(short cmd, char *str)
//{
//	OutPrint(CMDP_R, str);
//}

//==================================================================
//port=0,1,2,3....
BYTE TestCom123(BYTE port)
{
    BYTE    tChar;

    EmptyComm(port);
    tChar=0x00;
    while (tChar<0x80)
    {
        SendComm(port,tChar);
        if (ReadComm(port)!=tChar)
            return 1;
        tChar++;
    }
    return 0;

}
/**
 *
 *
 * @author EutronSoftware (2014-04-09)
 *
 * @param port:0,1,2,3
 *
 * @return WORD
 */
WORD CheckComm(BYTE port)
{
	return Bios_PortRead(port+1, NULL, 0, 0, NULL);
}

/**
 *
 *
 * @author EutronSoftware (2014-04-09)
 *
 * @param port:0,1,2,3
 */
void EmptyComm(BYTE port)
{
	if (Bios_PortRead(port+1, NULL, 0, 0, NULL))
		Bios_PortRead(port+1, NULL, -1, 0, NULL);
	return;
}

/*  When CheckComm return SOH, system can read data from rs232 use readcomm.
    the first byte is the length of data-L, then are the Byte data-B;
    the last is verify byte-V;
    (L + B)=V

*/
//Read one byte from port
//in: port(0:a, 1:b)  out:(receive data)
// return -1 if no data
short ReadComm(BYTE port)
{
	char rBuf[1];
	WORD sSta;

	sSta = 0;
	if (!Bios_PortRead(port+1, rBuf, 1, ASECOND, &sSta))
         //|| (sSta & (1<<B_SIOF_OVERRUN | 1<<B_SIOF_FRAME | 1<<B_SIOF_PARITY | 1<<B_SIOF_ERRORS)))
		return -1;
	else
		return (rBuf[0] & 0xff);
}
/**
 *
 *
 * @author EutronSoftware (2014-04-09)
 *
 * @param port:0,1,2,....
 * @param byte
 */
void SendComm(BYTE port,BYTE byte)
{
	BYTE s485=port & 0x80;

	port &= 0x0f;

	if (s485)//485
	{
		Delay(DELAY485);
		ClrRTS(port);
	}
	Bios_PortWrite(port+1, &byte, 1, 1);
	if (s485)
	{
		Delay(DELAY485);
		SetRTS(port);
	}
}



//Speed:'1'-1200,'2'-2400,'3'-4800,'4'-9600,'5'-19200,'6'-38400,'7'-57600,'8'-115200
//Parity: '0'-NONE,'1' = EVEN,'2'-ODD
//StopBit: '1'= 1 stop bit;'2'-2 stop bit
//BitCar: '8' = 8 bit per carattere;'7'-7 bit per carattere
CONST ULONG Baud[]={1200,2400,4800,9600,19200,38400,57600,115200};
/**
 *
 *
 * @author EutronSoftware (2014-04-09)
 *
 * @param Com:0,1,2,3....
 */
void SetComm(BYTE Com)
{
    BYTE pSet = ApplVar.PortList[Com].Prot[ApplVar.PortList[Com].Type - 0x31];
#if !defined(DEBUGBYPC)

    UARTInit(Com+1,
             Baud[pSet & 0x07], //Speed:'1'-1200,'2'-2400,'3'-4800,'4'-9600,'5'-19200,'6'-38400,'7'-57600,'8'-115200
             ((pSet>>6)&1) + 7, //BitCar: '8' = 8 bit per carattere;'7'-7 bit per carattere
             ((pSet>>3)&0x03),  //Parity: '0'-NONE,'1' = EVEN,'2'-ODD
    		 ((pSet>>5)&1) + 1);//StopBit: '1'= 1 stop bit;'2'-2 stop bit

#endif
}

//==============================================================

//
BYTE TestRtc()
{
	BYTE sERR;

	Bios_1(BiosCmd_GetDate);
	Bios_1(BiosCmd_GetTime);

	sERR = 0;
	if (rtc_date.dd<1 || rtc_date.dd>0x31)
	{
		rtc_date.dd = 1;
		sERR = 1;
	}
	if (rtc_date.mm<1 || rtc_date.mm>0x12)
	{
		rtc_date.mm = 1;
		sERR = 1;
	}
	if (rtc_date.w>6)
	{
		rtc_date.w = 1;
		sERR = 1;
	}

	if (rtc_time.hh>0x23)
	{
		rtc_time.hh=1;
		sERR = 1;
	}
	if (rtc_time.mm>0x59)
	{
		rtc_time.mm = 1;
		sERR = 01;
	}
	if (rtc_time.ss>0x59)
	{
		rtc_time.ss = 1;
		sERR = 01;
	}

	if (sERR)
	{
//		rtc_date.yy = 0;
		Bios_1(BiosCmd_SetDate);
		Bios_1(BiosCmd_SetTime);
	}
	return (sERR);
}

void RTC_SetDateTime (const RTCTime *rtc);

void SetTimeDate(struct TimeDate *pTimeDate)
{
#if defined(DEBUGBYPC)
	rtc_date.dd = pTimeDate->day;
	rtc_date.mm = pTimeDate->month;
	rtc_date.yy = pTimeDate->year;

	rtc_time.hh = pTimeDate->hour;
	rtc_time.mm = pTimeDate->min;
	rtc_time.ss = pTimeDate->sec;
    sysSetDateTime();
#elif (1)//ccr2017-08-10  defined(CASE_EURO) //ccr2017-08-10 ��ʱ��>>>>>>>>>>>>
    RTCTime rtc_tmp;

	rtc_tmp.mday =BCDtoDEC(pTimeDate->day);
	rtc_tmp.mon = BCDtoDEC(pTimeDate->month);
	rtc_tmp.year = BCDtoDEC(pTimeDate->year & 0xff);
    rtc_tmp.wday = GetWeekDay(pTimeDate->year,pTimeDate->month,pTimeDate->day);
	rtc_tmp.hour = BCDtoDEC(pTimeDate->hour);
	rtc_tmp.min = BCDtoDEC(pTimeDate->min);
	rtc_tmp.sec = BCDtoDEC(pTimeDate->sec);

    RTC_SetDateTime(&rtc_tmp);
//    xprintf("SET>>>>%d-%d-%d.%d ERR:%d\n",rtc_tmp.year,rtc_tmp.mon,rtc_tmp.mday,rtc_tmp.wday,ApplVar.ErrorNumber);//testonly
    //ccr2017-08-10 ����������ȡһ��,������������ʱ,������ȡ�����õ����ڻ᲻�ɹ�. WHY?
    RTC_GetDateTime(&rtc_tmp);
//    xprintf("READ>>>%d-%d-%d.%d ERR:%d\n",rtc_tmp.year,rtc_tmp.mon,rtc_tmp.mday,rtc_tmp.wday,ApplVar.ErrorNumber);//testonly

#else//ccr2017-08-10<<<<<<<<<<<<<<<<<<<<<
    rtc_date.dd = pTimeDate->day;
    rtc_date.mm = pTimeDate->month;
    rtc_date.yy = pTimeDate->year & 0xff;
    rtc_date.w = GetWeekDay(pTimeDate->year,pTimeDate->month,pTimeDate->day);
	Bios_1(BiosCmd_SetDate);

    rtc_time.hh = pTimeDate->hour;
    rtc_time.mm = pTimeDate->min;
    rtc_time.ss = pTimeDate->sec;
	Bios_1(BiosCmd_SetTime);
#endif
}

//1-����һ,...,6-������,7-������
void GetTimeDate(struct TimeDate *pTimeDate)
{
#if defined(DEBUGBYPC)
	sysGetDateTime();
	rtc_date.w = 2;
#else
	Bios_1(BiosCmd_GetDate);
#endif
	pTimeDate->day	=	rtc_date.dd;
	pTimeDate->month=	rtc_date.mm;
	pTimeDate->year	= 	rtc_date.yy+0x2000;
	pTimeDate->dow	=   rtc_date.w;

	Bios_1(BiosCmd_GetTime);
	pTimeDate->hour=rtc_time.hh ;
	pTimeDate->min =rtc_time.mm ;
	pTimeDate->sec =rtc_time.ss;
}


/*****************************************************
 * ����ǰ����ת��Ϊ������YYMMDD,��170410
 *
 * @author EutronSoftware (2017-04-10)
 *
 * @return ULONG:��170410
 ****************************************************/
ULONG DateToYYMMDD()
{
    return (BCDtoDEC(Now.year & 0xff)*10000+BCDtoDEC(Now.month)*100+BCDtoDEC(Now.day));
}

/**
 * ��ǰ��ʱ��ת��Ϊ������HHMM
 *
 * @author EutronSoftware (2017-04-10)
 *
 * @return ULONG
 */
ULONG TimeToHHMM()
{
    return (BCDtoDEC(Now.hour)*100+BCDtoDEC(Now.min));//*100+BCDtoDEC(Now.sec);
}


WORD BCD4toWORD(WORD R2R0)
{
    WORD tmp=(R2R0>>8),tmp2=(R2R0 & 0xff);
    tmp = BCDtoDEC(tmp)*100;
    return(tmp + BCDtoDEC(tmp2));
}

short BCDWidth(BCD *bcd)
{
	register short i;

	i = BCDLEN-1;
	while (i>=0)
	{
		if (bcd->Value[i] !=0)
			break;
		i--;
	}
	i++;
	if (i>0)
	{
		if (bcd->Value[i-1]<0x0f)
			i = (i <<1) - 1;
		else
			i<<=1;
	}
	return i;
}

//
void SetBCDPoint(BCD *bcd,BYTE point)
{
	short	sLp;

	sLp = bcd->Sign & 0x07;
	if (sLp>point)
	{
		sLp -= point;
		while (sLp)
		{
			BcdDiv10(bcd);
			sLp--;
		}
	}
	else if (sLp<point)
	{
		sLp = point-sLp;
		while (sLp)
		{
			BcdMul10(bcd);
			sLp--;
		}
	}
	bcd->Sign &= 0xf8;
	bcd->Sign |= (point & 0x07);
}
//   012345678901234567890123456789012345
//  ��ȡ����ʱ���ַ����������ʽΪ 2003-08-09 12:12:12
// dt:=0,��ϵͳ���ÿ���
// =1,ֻת������
// =2,ֻת��ʱ��
// =3,ת�����ں�ʱ��
void DateTimeToStr(char *sBuf,BYTE dt)
{
	int poi=0;
    if (!BIT(SLIPINFO, BIT1) || !BIT(COMMA, BIT6) || BIT(dt,BIT0))        /* print date on slip */
    {

		CheckTime(TRUE | 0x80);
        //����ϵͳ���õĸ�ʽ�������
        memcpy(sBuf,DateAsci+4,10);
        poi = 10;
        sBuf[poi++]=' ';

	}
    if ((!BIT(SLIPINFO, BIT2)||!BIT(COMMA, BIT7) || BIT(dt,BIT1)))// && !ApplVar.FNoTime)        /* print time on slip */
   	{
		memcpy(sBuf + poi, TimeAsci, 8);
   	}
}

/*********************************************************
 * �Խ��ո�ʽ������ת��Ϊ�ַ���,���Ҷ������SysBuf[DISLEN]
 *
 * @author EutronSoftware (2017-07-05)
 *
 * @param flag :=0,��������֮���޼������
 *              =1,��������֮��Ӽ������
 ********************************************************/
void DateForDisplay(BYTE flag,BYTE width)
{
	memset(SysBuf,' ',width);

	CheckTime(true | 0x80);
	if (flag==1)
	{
        if (width<10) width=10;
		memcpy(SysBuf+width-10, DateAsci+4, 10);
	}
	else
	{
        if (width<8) width=8;
		switch (TIME_DATE)
		{
            default:
			case 0://day,DD-MM-YYYY//
			case 1://day,MM-DD-YYYY//
				CWORD(SysBuf[width-8])=CWORD(DateAsci[4]);
				CWORD(SysBuf[width-8+2])=CWORD(DateAsci[4+3]);
				CLONG(SysBuf[width-8+4])=CLONG(DateAsci[4+6]);
				break;
			case 2://day,YYYY-MM-DD//
                CLONG(SysBuf[width-8])=CLONG(DateAsci[4]);
				CWORD(SysBuf[width-8+4])=CWORD(DateAsci[4+5]);
				CWORD(SysBuf[width-8+6])=CWORD(DateAsci[4+8]);
				break;
		}

	}
	SysBuf[width] = 0;
}

/*//sYear--year(YY,BCD); sMonth--Month(MM,BCD);sDay-Day(DD,BCD)
bitNum:fedcba9876543210
result:0000000000000000
       |     ||  |+---+----ApplVar.Day(1..31)
	   |	 |+--+---------ApplVar.Month(1..12)
	   +-----+-------------Year(0..99)2000..2099
*/
WORD EncordBCDDate(WORD sYear,BYTE sMonth,BYTE sDay)
{
	return (((((sYear & 0xf0)>>4)*10 + (sYear & 0x0f))<<9) |
			((((sMonth & 0xf0)>>4)*10 + (sMonth & 0x0f))<<5) |
			((((sDay & 0xf0)>>4)*10 + (sDay & 0x0f))));
}

//sYear--year(YYYY,DEC); sMonth--Month(MM,DEC);sDay-Day(DD,DEC)
WORD EncordDECDDate(WORD sYear,BYTE sMonth,BYTE sDay)
{
	return ((sYear % 100)<<9) | (sMonth<<5) | sDay;
}

//sYear--year(20YY,BCD); sMonth--Month(MM,BCD);sDay-Day(DD,BCD)

void DecordDate(WORD sDate,WORD *sYear,BYTE *sMonth,BYTE *sDay)
{
	WORD s;
	s = sDate>>9;
	*sYear = 0x2000 + ((s/10)<<4) + s % 10;

	s = (sDate>>5) & 0x0f;
	*sMonth = ((s/10)<<4) + s % 10;

	s = sDate & 0x1f;
	*sDay = ((s/10)<<4) + s % 10;
}


//���������ת��Ϊ��С����ʽ���(��ȥ��Sign�е�С��λ��),
//û������С��ʱ,�������Ĭ��Ϊ��λС��
BYTE ChangePoint()//ccr2016-04-05
{
    if (INPUT_DECIMAL || ApplVar.DecimalPoint)
    {
        switch (NO_DECIMAL)//ccr2016-11-07>>>>>>>>>>>>>>>>
        {
        case 0://ϵͳΪ��λС��
            {
                switch (ApplVar.DecimalPoint)
                {
                case 0:BcdMul100(&ApplVar.Entry); break;//û������С����
                case 1:BcdMul10(&ApplVar.Entry);break;//������һλС��
                case 2:break;//��������λС��
                case 3:BcdDiv10(&ApplVar.Entry); break;//��������λС��
                default:return 0;
                }
            }
            break;
        case 1://ϵͳΪ��С��
            {
                switch (ApplVar.DecimalPoint)
                {
                case 0:break;//û������С����
                case 1:BcdDiv10(&ApplVar.Entry);break;//������һλС��
                case 3:BcdDiv10(&ApplVar.Entry); //��������λС��
                case 2:BcdDiv100(&ApplVar.Entry);break;//��������λС��
                default:return 0;
                }
            }
            break;
        case 2://ϵͳΪ��λС��
            {
                switch (ApplVar.DecimalPoint)
                {
                case 0:BcdMul10(&ApplVar.Entry); //û������С����
                case 1:BcdMul100(&ApplVar.Entry);break;//������һλС��
                case 2:BcdMul10(&ApplVar.Entry);break;//��������λС��
                case 3:break;//��������λС��
                default:return 0;
                }
            }
            break;
        case 3://ϵͳΪ1λС��
            {
                switch (ApplVar.DecimalPoint)
                {
                case 0:BcdMul10(&ApplVar.Entry); break;//û������С����
                case 1:break;//������һλС��
                case 2:BcdDiv10(&ApplVar.Entry);break;//��������λС��
                case 3:BcdDiv100(&ApplVar.Entry);break;//��������λС��
                default:return 0;
                }
            }
            break;
        default:return 0;
        }//ccr2016-11-07<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    }
    ApplVar.Entry.Sign &= 0xf8;
    ApplVar.DecimalPoint = 0;
    return 1;
}


/*******************************************************************
 * ���������ת��Ϊ��С����ʽ���(��ȥ��Sign�е�С��λ��),
 * û������С��ʱ,�������Ĭ��Ϊ��λС��
 *
 * @author EutronSoftware (2018-01-03)
 *
 * @param discPer :Ϊ%�ۿ�ת��С����,ʹ������12����Ϊ12.00����0.12
 *
 * @return BYTE
 ******************************************************************/
BYTE ChangePoint2(BYTE discPer)//ccr2018-01-03
{
    if (INPUT_DECIMAL || ApplVar.DecimalPoint)
    {
        switch (ApplVar.DecimalPoint)
        {
        case 0:BcdMul100(&ApplVar.Entry); break;//û������С����
        case 1:BcdMul10(&ApplVar.Entry);break;//������һλС��
        case 2:break;//��������λС��
        case 3:BcdDiv10(&ApplVar.Entry); break;//��������λС��
        default:return 0;
        }
    }
    else if (discPer)   //ccr2018-01-03
        BcdMul100(&ApplVar.Entry);//ccr2018-01-03
    ApplVar.Entry.Sign = 2;
    ApplVar.DecimalPoint = 0;
    return 1;
}


/**
 * ����ApplVar.Key.Code�����Ƿ���Ҫ����������ݽ���С��ת��
 *
 * @author EutronSoftware (2016-05-28)
 *
 * @return BYTE:=true,��Ҫת��;=false,������������ݽ���С��ת��
 */
BYTE TestChangePointMust()
{
    return ((ApplVar.Key.Code != MULT &&
             ApplVar.Key.Code!=CLERK &&
             ApplVar.Key.Code!=SALPER &&
             //ApplVar.Key.Code!=VIPLOGIN &&
             ApplVar.Key.Code != NUMBER &&
             ApplVar.Key.Code != NUMBER1 &&
             ApplVar.Key.Code != NUMBER2 &&
             (ApplVar.Key.Code < DISC || ApplVar.Key.Code > PORA) &&
             ApplVar.Key.Code < PLU1) ||
             (ApplVar.Key.Code == MULT && ApplVar.CentralLock==MG && ApplVar.FInv == 3));
}
/*************************************************
 * ���벢У������,�����������󳤶�ΪMAXPWD
 *
 * @author EutronSoftware (2017-12-11)
 *
 * @param pass
 *
 * @return BYTE :=true,�ɹ�;=false:ʧ��
 ************************************************/
BYTE CheckPWD(char *pass)
{
    BCD cpEntry;
    BYTE cpCounter;
    ULONG cpNumber;
    BYTE keyno;
    short  sLen;
#if (0)//ccr2017-12-11>>>>>>>>>>>>>>>>>
    short  sCounter;
	WORD kCode;
	char sPass[MAXPWD];
#endif
	sLen = strlen(pass);
	if (!sLen)
		return TRUE;
	if (sLen>=MAXPWD)
		sLen = MAXPWD-2;

#if (1)//ccr2017-12-11>>>>>>>>>>>>>>>>>
    cpEntry=ApplVar.Entry;
    cpCounter=Appl_EntryCounter;
    cpNumber=Appl_NumberEntry;

    sLen=GetStrFromKBD('*',(char*)DText[DTEXT_PASSWORD],NULL,MAXPWD-1,'*',NO);
    if (sLen<=0 || strcmp(&AtEntryBuffer(Appl_EntryCounter),pass))
    {
        //����У��ʧ��,��ʾ�������
        //PutsO(DMes[ItemDMes18]);
        //WAIT_INPUT(keyno);
        keyno=false;
    }
    else
        keyno=true;

    ApplVar.Entry=cpEntry;
    Appl_EntryCounter=cpCounter;
    Appl_NumberEntry=cpNumber;

    return keyno;
#else//ccr2017-12-11<<<<<<<<<<<<<<<<<<<

	memset(SysBuf+sizeof(SysBuf)-DISLEN-1,'_',DISLEN);
	sCounter = 0;
	SysBuf[sizeof(SysBuf)-1] = 0;
    sPass[0]=0;

	for (;;)
	{
#if (DISP2LINES)
		PutsO(DText[DTEXT_PASSWORD]);
		Puts1(SysBuf+sizeof(SysBuf)-DISLEN-1);
#elif (DD_LCD_1601==1)
		if (sCounter<DISLEN-8)
		{
			CopyFrStr(SysBuf+sizeof(SysBuf)-DISLEN-1,DText25);
		}
		PutsO(SysBuf+sizeof(SysBuf)-DISLEN-1);
#else
		if (sCounter<DISLEN-4)
		{
			SysBuf[sizeof(SysBuf)-DISLEN-1] = 'P';
			SysBuf[sizeof(SysBuf)-DISLEN] = 'w';
			SysBuf[sizeof(SysBuf)-DISLEN+1] = 'd';
		}
		PutsO(SysBuf+sizeof(SysBuf)-DISLEN-1);
#endif


		while (!KbHit()) FM_EJ_Exist();
		keyno = Getch();
		kCode = ApplVar.AP.KeyTable[keyno];
		if (keyno == CLEARKey)
		{

            if (sCounter==0)
                return false;
            else
            {
                memset(SysBuf+sizeof(SysBuf)-DISLEN-1,'_',DISLEN);
                sCounter = 0;
                SysBuf[sizeof(SysBuf)-1] = 0;
                continue;
            }
		}
		if (keyno == ENTERKey)
		{
/*			keyno = 0;
			for (i = k = 0;i<sCounter;i++)
			{
				if (sPass[i]!=0)
					keyno = 1;
				if (keyno)
					sPass[k++]= sPass[i];
			}
			sPass[k] = 0;
			if (k>sLen)
				sLen = k;*/
			return (!strncmp(pass,sPass,sLen));
		}
		if (keyno == EXITKey)
			return FALSE;
		if ((kCode>='0' && kCode<='9' || kCode>='a' && kCode<='z' || kCode>='A' && kCode<='Z')
            && sCounter<MAXPWD-1)
		{
			sPass[sCounter++] = kCode & 0xff;
            sPass[sCounter]=0;
			SysBuf[sizeof(SysBuf)-1-sCounter] = '*';
		}
	}
#endif
}
//============================================================================
// ��ʾ16��������pHex,pWidthΪpHex���ֽ���   //
void DisplayHex(char *pHex, short pWidth,BYTE y)
{
	char sDisp[30];

    memset(sDisp,' ',sizeof(sDisp));
	HEXtoASC(sDisp, pHex, pWidth);
	sDisp[pWidth*2] = 0;
#if (DISP2LINES)
    if (y==0)
        PutsO(sDisp);
    else
        Puts1(sDisp);
#else
    PutsO(sDisp);
#endif

}
// ============================================================================
//  ���ַ���pStrת��Ϊ16��������,pWidthΪpStr���ֽ���   //
WORD StrToHex(char *pStr,BYTE pWidth)
{
	WORD j=0;
	BYTE i,sByte;

		for (i=0;i<pWidth;i++)
		{
			sByte =  pStr[i];
			j<<=4;
			if (sByte>'9')
				j += ((sByte & 0x0f)-1+10);
			else
				j += ((sByte & 0x0f));
		}
		return j;
}

//============================================================================
//���ַ���pStrת��Ϊ������16��������,pWidthΪpStr���ֽ���   //
long HexStrToLong(char *pStr,BYTE pWidth)
{
	long j=0;
	BYTE i,sByte;

		for (i=0;i<pWidth;i++)
		{
			sByte =  pStr[i];
			j <<=4;
			if (sByte>'9')
				j += ((sByte & 0x0f)-1+10);
			else
				j += ((sByte & 0x0f));
		}
		return j;
}
//============================================================================
//���ַ���pStrת��Ϊ������16��������,pWidthΪpStr���ֽ���   //
long StrToLong(char *pStr,BYTE pWidth)
{
	long j=0;
	BYTE i,sByte;

		for (i=0;i<pWidth;i++)
		{
			sByte =  pStr[i];
			j *=10;
            j += ((sByte & 0x0f));
		}
		return j;
}


/**
 * ccr070608
 *
 * @author EutronSoftware (2014-07-29)
 * �����뻺����EntryBuffer��ȡsNum���ַ����������,���뵽sTo��,��\0���� //
 * @param sTo: input into sTo, sizeof(sTo)>=sNum+1;
 * @param sNum: Max length of input
 * @param alignRight: lign to right or not
 *
 * @return int: he length of input
 */
int GetInput(char *sTo,BYTE sNum,bool alignRight)
{
	short i,j;

		j =  ENTRYSIZE - Appl_EntryCounter - 1;
		if (Appl_EntryCounter<sNum && alignRight)
			i = sNum - Appl_EntryCounter;
		else
			i = 0;
		for (;i<sNum && j<ENTRYSIZE;i++,j++)
			sTo[i] = EntryBuffer[j];
		sTo[i] = 0;//appen then end with \0
		return i;
}

//============================================================================
BYTE TestDencity()
{
	return (DENSITY & 1);
}
// -----------------------------------------------------------------------------
/* make unsigned long from bcd number */
UnLong BCDValueToULong(BYTE *p, BYTE BcdBytes)
{
    UnLong  sTmp;
    int  sLp;

    sTmp=0;
    for (sLp=BcdBytes-1;sLp>=0;sLp--)
    {
        sTmp=(sTmp<<3)+(sTmp<<1)+(p[sLp] >> 4);//sTmp=sTmp*10+p1
        sTmp=(sTmp<<3)+(sTmp<<1)+(p[sLp] & 0x0f);//sTmp=sTmp*10+p2
    }
    return (sTmp);
}


//============================================================================
short InitPrinterChar(BYTE *dots, short number)
{
}
//============================================================================

/********************* Subroutines for BCD data *****************************/

BYTE   BCDValue1[BCDLEN*2+1];
BYTE   BCDValue2[BCDLEN*2+1];

BYTE    SaveBCDDec1,SaveBCDDec2,SaveBCDSign1;
BYTE    BCDSign1,BCDSign2,BCDDecimal1,BCDDecimal2;

BYTE   BcdLongFlag;
//**** BCD.Value/10=>BCD.Value **********
//size of BCD.Value must be 16 bytes
void  BCDValue_DIV_10(BYTE *res)
{
    int  i;
    BYTE tmp1,tmp2,tmp;

    tmp=0;
    res += 15;

    for (i=0;(i<16) && (*res==0);i++)
        res--;

    for (;i<16;i++)
    {
        tmp1=(*res &  0x0f ) << 4;
        tmp2=(*res &  0xf0)  >> 4;
        *res=tmp2+tmp;
        tmp=tmp1;
        res--;
    }
}

//*******BCD.Value * 10 =>BCD.Value *************
//size of BCD.Value must be 16 bytes
void  BCDValue_MUL_10( BYTE *res)
{
    int      i;
    BYTE tmp1,tmp2,tmp;

    tmp=0;
    for (i=0;i<16;i++)
    {
        tmp1=(*res &  0x0f)  << 4;
        tmp2=(*res &  0xf0)  >> 4;
        *res=tmp1+tmp;
        tmp=tmp2;
        res++;
    }
}
//*******BCD.Value * 100 =>BCD.Value *************
//size of BCD.Value must be 16 bytes
void  BCDValue_MUL_100( BYTE *res)
{
    int      i;
    BYTE tmp2,tmp;

    tmp=0;
    for (i=0;i<16;i++)
    {
        tmp2=*res;
        *res=tmp;
        tmp=tmp2;
        res++;
    }
}
//aadjust BCD.Value: max 3 decimal/
void  Correct_BCDValue1(void)
{
    while (BCDDecimal1>3)
    {//ֻ����3λС��
        BCDValue_DIV_10(BCDValue1);
        BCDDecimal1--;
    }

    while ( (BCDDecimal1 > 0)  &&  ((BCDValue1[0] & 0x0f)  == 0) )
    {//ȥ��С������ĩβ��0
        BCDDecimal1--;
        BCDValue_DIV_10(BCDValue1);
    }


    while ( BCDDecimal1 > 0    &&  ((BCDValue1[8] & 0x0f)  != 0) )
    {//�����С��,����BCD��ֵ����16λ(8 bytes),��ô����С��,ֻ����8λBCD��ֵ
        BCDDecimal1--;
        BCDValue_DIV_10(BCDValue1);
    }
    BCDDecimal1 &=0x07;
    SaveBCDSign1 += BCDDecimal1;
}

// aadjust UINT64: max 3 decimal/
void  Correct_UINT64(UINT64 *pUInt64,BYTE *dec)
{
    while (*dec>3)
    {//ֻ����3λС��
        *pUInt64/=10;
        *dec--;
    }

    while ( (*dec > 0)  &&  (*pUInt64%10 == 0) )
    {//ȥ��С������ĩβ��0
    }


    while ( *dec > 0  &&  (*pUInt64>0xffffffff) )
    {//�����С��,����BCD��ֵ����16λ(8 bytes),��ô����С��,ֻ����8λBCD��ֵ
        *pUInt64/=10;
        *dec--;
    }
}


void SubBCDValue12(void)
{//BCDValue1=BCDValue1-BCDValue2
    short      i;
    BYTE tmp1,tmp2,tmp3,tmp,cfg;

    tmp=0;
    cfg=0;

    for (i=0;i<16;i++)
    {
#if (1)//����ʮ�����������м�������
        tmp1=BCDtoDEC(BCDValue1[i]);
        tmp2=BCDtoDEC(BCDValue2[i]);
        tmp2 += cfg;
        if (tmp1>=tmp2)
        {
            tmp=tmp1-tmp2;
            cfg=0;
        }
        else
        {
            tmp=tmp1 + 100 - tmp2;
            cfg=1;
        }
        BCDValue1[i]=DECtoBCD(tmp);
#else//ֱ�Ӷ�BCD���ݽ��м�������
        tmp1=BCDValue1[i] & 0x0f;
        tmp2=BCDValue2[i] & 0x0f;
        tmp2 += cfg;
        if (tmp1>=tmp2)
        {
            tmp=tmp1-tmp2;
            cfg=0;
        }
        else
        {
            tmp=tmp1 + 10 - tmp2;
            cfg=1;
        }

        tmp1=(BCDValue1[i] & 0xf0) >> 4;
        tmp2=(BCDValue2[i] & 0xf0) >> 4;
        tmp2=tmp2+cfg;
        if (tmp1>=tmp2)
        {
            tmp3=tmp1-tmp2;
            cfg=0;
        }
        else
        {
            tmp3=tmp1 + 10 - tmp2;
            cfg=1;
        }

        tmp3 = tmp3 << 4;
        BCDValue1[i]=tmp  + tmp3;
#endif
    }
}


void AddBCDValue12(void)
{
    short      i;
    BYTE tmp1,tmp2,tmp3,tmp,cfg;

    tmp=0;
    cfg=0;

    for (i=0;i<16;i++)
    {
#if (1)//����ʮ�����������мӷ�����
        tmp1=BCDtoDEC(BCDValue1[i]);
        tmp2=BCDtoDEC(BCDValue2[i]);
        tmp=tmp1+tmp2+cfg;
        if (tmp>99)
        {//�н�λ
            tmp -=100;
            cfg = 1;
        }
        else
            cfg=0;

        BCDValue1[i]=DECtoBCD(tmp);
#else//ֱ�Ӷ�BCD���ݽ��мӷ�����
        tmp1=BCDValue1[i] & 0x0f;
        tmp2=BCDValue2[i] & 0x0f;
        tmp=tmp1+tmp2+cfg;
        if (tmp>9)
        {//�н�λ
            tmp -=10;
            cfg = 1;
        }
        else
            cfg=0;

        tmp1=(BCDValue1[i] & 0xf0) >> 4;
        tmp2=(BCDValue2[i] & 0xf0) >> 4;
        tmp3=tmp1+tmp2+cfg;

        if (tmp3>9)
        {
            tmp3 -=10;
            cfg = 1;
        }
        else
            cfg=0;

        tmp3 = tmp3 << 4;
        BCDValue1[i]=tmp  + tmp3;
#endif
    }
}

/****************************************************************
 * ���ַ�����ת��BCD����
 *
 * @author EutronSoftware (2014-12-18)
 *
 * @param to :BCD���ݴ洢��
 * @param from :�ַ���('0'-'9','A'-'F'),�Ӻ���ǰ��ʼת��
 *               "1234.56"=>{0x56,0x34,0x12}
 *                from--^  to-^
 * @param len :to��ָBCD�洢���ĳ���
 ***************************************************************/
void  StrToBCDValue(char *to, char *from, short len)        /* (void *to, char *from, short len) convert ascii to (BCD.Value)*/
{
    BYTE      t1,l;
    BYTE    flag;//������ʾ��Ч�����Ƿ�ȡ��(�Ƿ������˿ո�)
    short      j,k;
    BYTE      *too;

    too=(BYTE  *)to;

    flag=k=0;

    for (j=l=0;j<len*2+k;j++)
    {
        if (*from=='.')
        {//�޳������е�С����
            from -- ;
            k++;
            continue;
        }
        if (!flag)
        {//ȡ��Ч����
            t1=*from;
            from--;
        }
        if (flag || t1==' ')
        {//�����ո��,��Ч�����Ѿ�ת�����,BCD��ʣ���ֽ���0
            flag = 1;
            t1 = 0;
        }
        else
        {
            if (t1>='A')  t1 -= 7;
            t1 &= 0x0f;
        }
        if ((l & 1)==0)
            *too = t1;
        else
        {
            *too |= (t1<<4);
            too++;
        }
        l++;
    }
}

/****************************************************************
 * ���ַ�����ת��BCD����
 *
 * @author EutronSoftware (2014-12-18)
 *
 * @param to :  BCD���ݴ洢��
 * @param from :�ַ���('0'-'9','A'-'F'),�������ҿ�ʼת��
 *               "123456"=>{0x12,0x34,0x56}
 *          from--^      to-^
 * @param len :to��ָBCD�洢���ĳ���
 ***************************************************************/
BYTE  StrToBCDValueL(char *to, char *from, short len)        /* (void *to, char *from, short len) convert ascii to (BCD.Value)*/
{
    BYTE      t1,l;
    BYTE    flag;//������ʾ��Ч�����Ƿ�ȡ��(�Ƿ������˿ո�)
    short      j;
    BYTE      *too;

    too=(BYTE  *)to;

    flag=0;

    for (j=l=0;j<len*2;j++)
    {
        if (!flag)
        {//ȡ��Ч����
            t1=*from;
            from++;
            if (t1 && t1!=' ')
            {
                if (t1>='A' && t1<='F' || t1>='a' && t1<='f')
                    t1 -= 7;
                else if (t1<'0' || t1>'9')
                    return false;//��������ݲ���HEX����
            }
            else
                flag=1;//��Ч�����Ѿ�ת�����
            t1 &= 0x0f;
        }
        if (flag)
        {//�����ո��,��Ч�����Ѿ�ת�����,BCD��ʣ���ֽ���0
            t1 = 0;
        }

        if ((l & 1)==0)
            *too = t1;
        else
        {
            *too = ((*too)<<4) | t1;
            too++;
        }
        l++;
    }
    return true;
}

/********************liuj 1227*************************/

void FormatBCD( char*  to, BCD *bcd, WORD Format)
{
    short i;

    BYTE *q = to;
    BYTE *p = bcd->Value;

    WORD count;
    BYTE *WorkPtr = BCDValue1 + (2*BCDLEN)-1;
    BYTE index = 0;
    BYTE DecimalPartLen = 0;


    /* BCD To Asci*/
    for (i=0;i<BCDLEN;i++)
    {
        BCDValue1[2*(BCDLEN-1-i)+1] = ((*p)&0x0f)+'0';
        BCDValue1[2*(BCDLEN-1-i)] = ((*p)>>4)+'0';
        p++;
    }
    /* Prefix '0' ---->  ' '*/
    if (!TestBit(Format,9))
    {//������ͷ����0��Ϊ�ո�
        /* Get Integer Part Length*/
        if (TestBit(Format,10))
        {//ΪQTY
            count = 2*BCDLEN -1;//ȥ��С����
            count = count - ((bcd->Sign)&0x0F);//ȥ��С��λ��
        }
        else
        {//ΪAMT
            count = 2*BCDLEN -3;//ȥ��2λС��+С����
            if (TestBit(Format,15))
            {
                if (TestBit(Format,11))
                    count++;
                else
                    count--;
            }
            else
            {
                if (TestBit(Format,11))
                    count+=2;
            }
        }
        /*Integer Part Prefix '0' --> ' '*/
        for (i=0;(i<count)&&(BCDValue1[i]=='0');i++)
            BCDValue1[i]=' ';
    }

    count = 0;//ͳ��ת�������ЧBCD����
    /* Add Postfix Sign. Sign In bcd.Sign.7 */
    if (TestBit(Format,8) && TestBit(bcd->Sign,7))//ccr2014
    {//���ŷ������ݵĺ���
        *to = '-';
        count++;
        to--;
    }

    if (TestBit(Format,10)) /* QTY:Decimal Length In bcd.Sign 2..0 bits
                               And Don't Need Comma List Separator.
                               And decimal Dot Must be Dot*/
        DecimalPartLen = bcd->Sign&0x0f;
    else    /*Decimal Length depend on the Format.15 and Format.11
            .15   .11   Decimal Length    Need Comma List Separator.
             1     1   1                    Y
             1     0   3                    Y
             0     0   2                    Y
             0     1   0                    N
            */
    {
        DecimalPartLen = 2;
        if (TestBit(Format,15))
        {
            if (TestBit(Format,11))
                DecimalPartLen--; //Decimal Length=1
            else
                DecimalPartLen++;//Decimal Length=3
        }
        else if (TestBit(Format,11))
                DecimalPartLen = 0;//Decimal Length=0
    }

    do
    {
        if (*WorkPtr == ' ') break;
        /* Add decimal dot*/
        if ((index == DecimalPartLen)&&(DecimalPartLen>0))
        {
//ccr2014-09-19            if (TestBit(Format,10))//ΪQTY��ӡ
//ccr2014-09-19                *to = '.';
//ccr2014-09-19            else
            {
                *to = ',';
                /*FormatInfo.4 .<--->,*/
                if (TestBit(Format,12))
                {
                    if (*to == '.')
						*to = ',';
                    else
						*to = '.';
                }
            }
            to--;
            count++;
        }
        else   if (!TestBit(Format,13)&&(!TestBit(Format,10)))//Amt
        {
            /* Add Comma List Separator  (�����������ӷָ�����",")
                FormatInfo.5 sum print but not need list separator
                FormatInfo.2 quantity print            */
            /*Add Decimal Part List Separator*/
            if (index < DecimalPartLen)
            {
                if ((((DecimalPartLen-index)%3)==0)&&(index >0))
                {
                    /*FormatInfo.4 .<--->,*/
                    if (TestBit(Format,12))
                        *to = ',';
                    else
                        *to = '.';
                    to--;
                    count++;
                }
            }
            /*Add Integer Part List Separator*/
            else
            {
                if ((((index-DecimalPartLen)%3)==0)&&(index >0))
                {
                    /*FormatInfo.4 .<--->,*/
                    if (TestBit(Format,12))
                        *to = ',';
                    else
                        *to = '.';
                    to--;
                    count++;
                }
            }
        }
        /* Copy Digital*/
        *to = *WorkPtr;
        to--;
        count++;
        index++;

        WorkPtr--;
    }
    while (index != 2*BCDLEN);

    /*Add Prefix Sign. Sign In bcd.Sign.7*/
//ccr070424>>>>>>>>>>>>>>>>>>>>>>
    if (!TestBit(Format,8))
    {
        if (!TestBit(Format,7) && TestBit(bcd->Sign,7))//ccr2014
        {//���ż��ڻ��ҷ��ĺ���
            *to = '-';
            to--;
            count++;
        }
        if (!TestBit(Format,10) && !TestBit(Format,14))
        {
            if (Prefix2)
            {
                *to = Prefix2;
                to--;
                count++;
            }
            if (Prefix1)
            {
                *to = Prefix1;
                to--;
                count++;
            }
        }
        if (TestBit(Format,7) && TestBit(bcd->Sign,7))//ccr2014
        {//���ż��ڻ��ҷ���ǰ��
            *to = '-';
            to--;
            count++;
        }

    }
    else
    {//׷��ǰ׺
        if (!TestBit(Format,10) && !TestBit(Format,14))
        {
            if (Prefix2)
            {
                *to = Prefix2;
                to--;
                count++;
            }
            if (Prefix1)
            {
                *to = Prefix1;
                to--;
                count++;
            }
        }
    }
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    /*remove 0 of the tail after Decimal*/
    if ((DecimalPartLen > 0))
    {
        while (q!= to)
        {
            /* if decimal point equal '.' */
            if (TestBit(Format,12))//ccr2014-09-19||TestBit(Format,10))
            {
                if ((*(q-2)=='.')||(*(q-1)=='.'))
                    break;
                else
                    if ((*q > '0')&&(*q <= '9')) break;
                else
                    *q = ' ';
            }
            else
            /* if decimal point equal ',' */
            {
                if ((*(q-2)==',')||(*(q-1)==',')) break;
                else
                    if ((*q > '0')&&(*q <= '9')) break;
                else
                    *q = ' ';
            }
            q--;
        }
    }
    //return count;
}

BYTE Addc ( BYTE num1,BYTE num2,BYTE  addmod)
{

    if (addmod)
    {
        if (BcdLongFlag)
        {
            num2++;
            if (num2<BcdLongFlag) BcdLongFlag = 1;
            else BcdLongFlag = 0;
        }
        num1 += num2;
        if (num1<num2) BcdLongFlag = 1;
    }
    else
    {
        num1 += num2;
        if (num1<num2) BcdLongFlag = 1;
        else BcdLongFlag = 0;
    }

    return num1;
}


/*
    Subc: Sub Involving C Flag Function
    submode
    1        Sub Involving C Flag
    0        Sub Not Involving C Flag
*/
BYTE Subc(BYTE  num1,BYTE  num2,BYTE submode)
{
    BYTE temp;

    if (submode)
    {
        if (BcdLongFlag)
        {
            num2++;
            if (num2<BcdLongFlag) BcdLongFlag = 1;
            else BcdLongFlag = 0;
        }
        temp = num1 - num2;
        if (temp > num1) BcdLongFlag = 1;
    }
    else
    {
        temp = num1 - num2;
        if (temp > num1) BcdLongFlag = 1;
        else BcdLongFlag = 0;
    }

    return temp;
}
/*
    CompareLong
*/
BYTE CompareLong(BYTE *Comparer,BYTE *BeComparer,BYTE len)
{
    BYTE result = 1;
    BYTE i;

    for (i=0;i<len;i++)
    {
        if (*Comparer<*BeComparer)
            result = 0;
        else
            if (*Comparer>*BeComparer)
            result = 2;

        Comparer++;
        BeComparer++;
    }
    return result;
}



//*************�Ƚ�ָ�����ȵ�����BCD.Value���ݵĴ�С*******************
short  CompareBCDValue(void  *a,void  *b, WORD  length)
{
    BYTE   *tmp1,*tmp2;
    WORD  i;

    tmp1=(BYTE  *) a;
    tmp2=(BYTE  *) b;
    tmp1 += (length-1);
    tmp2 += (length-1);

    for (i=0;i<length;i++)
    {
        if (*tmp1 >  *tmp2) return 1;
        if ( *tmp1 < *tmp2) return -1;
        tmp1--;
        tmp2--;
    }
    return 0;
}

/********** compare two BCD numbers **********/
/* result   returnvalue    */
/* a = b    0		   */
/* a < b    -1		   */
/* a > b    1		   */

short     CompareBCD(BCD *a, BCD *b)   /* (BCD *a, BCD *b) */
{
    int   i;

    BCDDecimal1=a->Sign  &  0x0f;//С��λ��
    BCDDecimal2=b->Sign  &  0x0f;//С��λ��

    memset(BCDValue1,0,sizeof(BCDValue1));
    memset(BCDValue2,0,sizeof(BCDValue2));
    memcpy(BCDValue1,a->Value,BCDLEN);
    memcpy(BCDValue2,b->Value,BCDLEN);

    i = BCDLEN-1;
    while (BCDDecimal1>BCDDecimal2)
    {
        BCDValue_MUL_10(BCDValue2);
        BCDDecimal2++;
        i++;
    }
    while (BCDDecimal2>BCDDecimal1)
    {
        BCDValue_MUL_10(BCDValue1);
        BCDDecimal1++;
        i++;
    }
    for (;i>=0;i--)
    {
        if (BCDValue1[i]>BCDValue2[i])
            return 1;
        if (BCDValue1[i]<BCDValue2[i])
            return -1;
    }

    return 0;
}


void    Divide(BCD *result1, BCD *with1)      /* (BCD *result, BCD *with) */
{
    int      decmi,tmp;
    BYTE     *result,*with;
    BYTE     temp3[17],temp4[17],temp5[17];

    if (CheckNotZero(result1))
    {//result1��ΪZEROʱ,���г�������
        with=(BYTE *)with1;
        result=(BYTE *)result1;
        SaveBCDDec1=*(BYTE *)result;
        SaveBCDDec2=*(BYTE *)with;
        BCDSign1=SaveBCDDec1&0x80;
        BCDSign2=SaveBCDDec2&0x80;
        BCDDecimal1=SaveBCDDec1&0x07;
        BCDDecimal2=SaveBCDDec2&0x07;
        result++;
        with++;

        SaveBCDSign1=0;
        if (BCDSign1!=BCDSign2)
            SaveBCDSign1=0x80;

        memset(temp3,0,sizeof(temp3));
        memset(temp4,0,sizeof(temp4));
        memset(temp5,0,sizeof(temp5));

        memcpy(BCDValue1,result1->Value,BCDLEN);
        memcpy(BCDValue2,with1->Value,BCDLEN);

        decmi=BCDDecimal1-BCDDecimal2;
        BCDDecimal2=0;
        while ( CompareBCDValue(BCDValue1,BCDValue2,BCDLEN*2) > 0)
        {
            BCDValue_MUL_10(BCDValue2);
            decmi--;
        }
        while ( CompareBCDValue(BCDValue1,BCDValue2,BCDLEN*2) < 0)
        {
            BCDValue_MUL_10(BCDValue1);
            decmi++;
        }

        for (;;)
        {
            if (decmi>6)
                break;
            tmp=CompareBCDValue(BCDValue1,BCDValue2,BCDLEN*2);
            if (tmp == 0)
            {

                memcpy(BCDValue1,temp5,sizeof(BCDValue1));
                memset(BCDValue2,0,sizeof(BCDValue2));
                BCDValue2[0]=1;
                AddBCDValue12();
                memcpy(temp5,BCDValue1,sizeof(temp5));

                break;
            }
            else if (tmp<0)
            {
                BCDValue_MUL_10(BCDValue1);
                BCDValue_MUL_10(temp5);
                decmi++;
            }
            else
            {
                while (tmp>0)
                {
                    SubBCDValue12();
                    BCDDecimal2++;
                    tmp=CompareBCDValue(BCDValue1,BCDValue2,BCDLEN*2);
                }

                memcpy(temp3,BCDValue1,sizeof(temp3));
                memcpy(BCDValue1,temp5,sizeof(BCDValue1));
                memcpy(temp4,BCDValue2,sizeof(temp4));
                memset(BCDValue2,0,sizeof(BCDValue2));
                BCDValue2[0]=BCDDecimal2;
                BCDDecimal2=0;
                AddBCDValue12();
                memcpy(temp5,BCDValue1,sizeof(temp5));
                memcpy(BCDValue1,temp3,sizeof(BCDValue1));
                memcpy(BCDValue2,temp4,sizeof(BCDValue2));
            }
        }

        while (decmi<0)
        {
            BCDValue_MUL_10(temp5);
            decmi++;
        }

        memcpy(BCDValue1,temp5,sizeof(BCDValue1));

        BCDDecimal1=decmi;
        Correct_BCDValue1();

        result1->Sign=SaveBCDSign1;
        memcpy(result1->Value,BCDValue1,8);
    }
    else
    {
      result1->Sign=0;
    }
}

/**********************************************************************
 * �ɸ��ֽ�����ֽڲ����Ҷ��䷽ʽת��HEX����
 *
 * @author EutronSoftware (2017-02-28)
 *  from:0x00001234
 * @param to:sizeof(to)>=len*2
 *           "00001234"
 *          to^
 * @param from:HEX����
 * @param len:from�ֽ���
 *
 **********************************************************************/
void    HEXtoASC(char *to, char *from, short len)     /* (char *to, void *from, short len) convert hex to asci */
{
    int      i;
    BYTE      *too,*from1;
    char      t1;

    too=(BYTE   *) to;
    too=too + 2*len;
    too--;
    from1=(BYTE  *)from;
        for (i=0;i<len;i++,from1++)
        {
            t1=(*from1 &  0x0f)+'0';
            if (t1>=0x3a) t1 +=7;
            *too--=t1;

            t1=((*from1) >>  4)+'0';
            if (t1 >=0x3a) t1  += 7;
            *too-- = t1;
        }
}
/**********************************************************************
 * �ɸ��ֽ�����ֽڲ����Ҷ��䷽ʽת��HEX����,ȥ����λ0
 *
 * @author EutronSoftware (2017-02-28)
 *
 *  from:0x00001234
 * @param to:sizeof(to)>=len*2
 *           "1234"
 *             to^
 * @param from:HEX����
 * @param len:from�ֽ���
 *
 **********************************************************************/
void HEXtoASCx0(char *to, char *from, short len)     /* (char *to, void *from, short len) convert hex to asci */
{
    int      i;
    char      *too,*from1,go;
    char      t1;

    too= to-2*len+1;
    from1=from+len-1;
	go=0;
	for (i=0;i<len;i++,from1--)
	{
		if (!go && *from1)
			go=1;
		if (go)
		{
			t1=((*from1) >>  4)+'0';
			if (go==2 || t1!='0')
			{
				if (t1>=0x3a) t1 +=7;
				*too++=t1;
				go=2;
			}
			else
				too++;

			t1=(*from1 &  0x0f)+'0';
			if (t1 >=0x3a) t1  += 7;
			*too++ = t1;
		}
		else
			too+=2;
	}
}

/***********************************************************************
 * �ɵ��ֽ�����ֽڲ�������䷽ʽת��HEX����
 *
 * @author EutronSoftware (2017-02-28)
 *  from:0x00001234
 * @param to:sizeof(to)>=len*2
 *           "34120000"
 *          to^
 * @param to:sizeof(to)>=len*2
 * @param from:HEX����
 * @param len:from�ֽ���
 **********************************************************************/
void    HEXtoASCL(char *too, BYTE *from, short len)     /* (char *to, void *from, short len) convert hex to asci */
{
    int      i;
    char      t1;

    for (i=0;i<len;i++,from++)
    {
        t1=((*from) >>  4)+'0';
        if (t1 >=0x3a) t1  += 7;
        *too++ = t1;

        t1=(*from &  0x0f)+'0';
        if (t1>=0x3a) t1 +=7;
        *too++=t1;
    }
}


void    WORDtoBCD(char *to, WORD num1)       /* (void *to, WORD) make BCD from hex */
{
    to[0]=DECtoBCD(num1%100);num1/=100;
    to[1]=DECtoBCD(num1%100);num1/=100;
    to[2]=num1;
}
//���Ҷ��뷽ʽ��WORDתΪ�ַ���
// '1234'
//    to^
//������Ч����λ��
BYTE    WORDtoASC(char *to, WORD num1)        /* (void *to, WORD) make ascii string from WORD */
{
    short     i;

    for (i=0;i<5;i++)
    {
        *to--=(num1 % 10) + '0';
        num1/=10;
        if (num1==0)
            break;
    }
    return i+1;
}

/*************************************************
 * ���Ҷ��뷽ʽ��ULONGתΪ�ַ���,����ת���λ��
 * '1234'
 *   to^
 * @author EutronSoftware (2018-01-19)
 *
 * @param to
 * @param num1
 *
 * @return int :ת��������ݳ���
 *************************************************/
int  ULongtoASC(char *to, ULONG num1)        /* (void *to, WORD) make ascii string from WORD */
{
    int     i;

    for (i=0;i<10;i++)
    {
        *to--=(num1 % 10) + '0';
        num1/=10;
        if (num1==0)
            break;
    }
    return i+1;
}
/**************************************************
 * ���Ҷ��뷽ʽ��ULONGתΪ�ַ���,����ת���λ��
 *  '001234'
 *      to^
 *
 * @author EutronSoftware (2017-05-04)
 *
 * @param to
 * @param num1
 * @param width :ת����ַ����Ŀ���
 *
 * @return int
 ***************************************************/
int  ULongtoASCZER0(char *to, ULONG num1,int width)        /* (void *to, WORD) make ascii string from WORD */
{
    int     i;

    for (i=0;i<width || num1;i++)
    {
		if (num1)
		{
			*to--=(num1 % 10) + '0';
			num1/=10;
		}
		else
			*to-- = '0';
    }
    return i;
}


//��WORD����ת��Ϊ�ַ���,������뷽ʽ�洢��to��
// no leading zero's & space
// '1234'
//  ^to
//����:ת������ַ�������
short WORDtoASCL(char *to, WORD num)
{
    short i,j;
    char ch;

    if (num>9999)       i = 10000;
    else if (num>999)   i = 1000;
    else if (num>99)    i = 100;
    else if (num>9)     i = 10;
    else                i = 1;

	j = 0;

    for (;i;)
    {
        ch = (num / i);
        if (ch || j)
        {
            to[j] = ch+'0';
            j++;
        }
        num %= i;
        i /= 10;
    }
    if (j==0)
    {
        to[0]='0';
        j=1;
    }
    return j;
}
// '01234'
//    to^
void    WORDtoASCZero(char *to, WORD num1)     /* (void *to, WORD) make asci string from WORD with */
{
    short     i;

    for (i=0;i<5;i++)
    {
        *to--=(num1 % 10) + '0';
        num1/=10;
    }
}/* leading zero's */

void  ULongToBCDValue(BYTE  *to, unsigned long relong)
{
    short     i;

    for (i=0;relong;i++)
    {
        to[i]=DECtoBCD(relong%100);
        relong/=100;
    }
}

void  LongToBCD(BCD  *to, long relong)
{
    int     i;
    unsigned long slong=labs(relong);

    *to = ZERO;
    for (i=0;slong;i++)
    {
        to->Value[i]=DECtoBCD(slong%100);
        slong/=100;
    }
    if (relong < 0)
        SETBIT(to->Sign, BIT7);
}
/**
 * ��BCD��������shiftnumλ,Ҳ��BCD=BCD/(10^shiftnum)
 *
 * @author EutronSoftware (2015-03-27)
 *
 * @param result
 * @param shiftnum
 */
void LeftShiftBCD(BCD *result,BYTE shiftnum)
{
    BYTE validshiftnum;
    BYTE i,j,src,dest;
    validshiftnum = result->Sign&0x0F;//С��λ��
    validshiftnum = 2*BCDLEN - validshiftnum;//����λ��

    result->Sign &= 0xF0;
    if (shiftnum > validshiftnum)
    {//��Ҫ���Ƶ�λ����������λ��,�ƶ���Ľ��Ϊ0
        for (i=0;i<BCDLEN;i++)
            result->Value[i] = 0x0;
        return;
    }
    else
    {
        j = shiftnum/2;
        if (j>0)
        {
            for (i=j;i<BCDLEN;i++)
                result->Value[i-j] = result->Value[i];
            for (i=0;i<j;i++)
                result->Value[BCDLEN -1- i] = 0x0;
        }

        if (shiftnum & 1)//
        {
            for (i= 0;i<BCDLEN-1;i++)
            {
                src = result->Value[i];
                dest = result->Value[i+1];
                result->Value[i] = (src>>4) | (dest<<4);
            }
            result->Value[BCDLEN-1] >>= 4;
        }
    }
}


void    Add(BCD *result1, BCD *with1)       /* (BCD *result, BCD *with) add two BCD numbers */
{
    short       i;
    BYTE    tmp;

    BCDSign1=result1->Sign & 0x80;
    BCDSign2=with1->Sign & 0x80;
    BCDDecimal1=result1->Sign & 0x07;
    BCDDecimal2=with1->Sign & 0x07;


    memset(BCDValue1,0,sizeof(BCDValue1));
    memset(BCDValue2,0,sizeof(BCDValue2));

    memcpy(BCDValue1,result1->Value,BCDLEN);
    memcpy(BCDValue2,with1->Value,BCDLEN) ;

    if (BCDDecimal1>BCDDecimal2)
        while (BCDDecimal1>BCDDecimal2)
        {
            BCDDecimal2++;
            BCDValue_MUL_10(BCDValue2);
        }
    else if (BCDDecimal1<BCDDecimal2)
        while (BCDDecimal1<BCDDecimal2)
        {
            BCDDecimal1++;
            BCDValue_MUL_10(BCDValue1);
        }

    for (i=7;i>=0;i--)
    {
        if (BCDValue1[i]>BCDValue2[i])
            break;
        if (BCDValue1[i]<BCDValue2[i])
        {
            for (i=0;i<8;i++)
            {
                tmp=BCDValue1[i];
                BCDValue1[i]=BCDValue2[i];
                BCDValue2[i]=tmp;
            }
            tmp=BCDSign2;
            BCDSign2=BCDSign1;
            BCDSign1=tmp;
            break;
        }
    }
    if (BCDSign1==BCDSign2)
        AddBCDValue12();
    else
        SubBCDValue12();
    SaveBCDSign1=BCDSign1;
    Correct_BCDValue1();

    result1->Sign=SaveBCDSign1;
    memcpy(result1->Value,BCDValue1,BCDLEN);
}

void    Multiply(BCD *result1, BCD *with1)     /* (BCD *result, BCD *with) */
{
#if (0)
    //���ó����������г˷�����
    ULONG       multiFor,multiWith;
    UINT64      result;

    BCDSign1=result1->Sign & 0x80;
    BCDSign2=with1->Sign & 0x80;

    BCDDecimal1=(with1->Sign & 0x07) + (result1->Sign & 0x07);

    if (BCDSign1==BCDSign2)
        BCDSign1=0;//������ͬ,���Ϊ����
    else
        BCDSign1=0x80;//���Ų�ͬ,���Ϊ����

    multiFor=BCDValueToULong(result1->Value,BCDLEN);
    multiWith=BCDValueToULong(with1->Value,BCDLEN);
    result = multiFor * multiWith;
    Correct_UINT64(&result,&BCDDecimal1);
    multiFor = result;
    memset(result1->Value,0,BCDLEN);
    LongToBCD(result1,multiFor);
    result1->Sign =BCDSign1 |  BCDDecimal1;

#else //������λ�ӷ�ʵ��BCD�˷�����
    short       i,i1,len;

    BYTE      temp3[17],temp4[17],temp5[17],tmp;

    SaveBCDDec1=result1->Sign;
    SaveBCDDec2=with1->Sign;

    BCDSign1=SaveBCDDec1&0x80;
    BCDSign2=SaveBCDDec2&0x80;
    BCDDecimal1=SaveBCDDec1&0x07;
    BCDDecimal2=SaveBCDDec2&0x07;

    memset(BCDValue1,0,sizeof(BCDValue1));
    memset(BCDValue2,0,sizeof(BCDValue2));

    memcpy(BCDValue1,result1->Value,BCDLEN);
    memcpy(BCDValue2,with1->Value,BCDLEN);

    i1=7;
    //����С����
    if (BCDDecimal1>BCDDecimal2)
        while (BCDDecimal1>BCDDecimal2)
        {
            i1++;
            BCDDecimal2++;
            BCDValue_MUL_10(BCDValue2);
        }
    else if (BCDDecimal1<BCDDecimal2)
        while (BCDDecimal1<BCDDecimal2)
        {
            i1++;
            BCDDecimal1++;
            BCDValue_MUL_10(BCDValue1);
        }

    for (i=7;i>=0;i--)
    {
        if (BCDValue1[i]>BCDValue2[i])
            break;
        if (BCDValue1[i]<BCDValue2[i])
        {//�ý�С����������

            memcpy(temp3,BCDValue1,BCDLEN);//��������
            memcpy(BCDValue1,BCDValue2,BCDLEN);
            memcpy(BCDValue2,temp3,BCDLEN);
            tmp=BCDSign2;
            BCDSign2=BCDSign1;
            BCDSign1=tmp;
            break;
        }
    }

    if (BCDSign1==BCDSign2)
        BCDSign1=0;//������ͬ,���Ϊ����
    else
        BCDSign1=0x80;//���Ų�ͬ,���Ϊ����
    BCDDecimal1 *=2;

    memset(temp3,0,sizeof(temp3));
    memset(temp4,0,sizeof(temp4));
    memset(temp5,0,sizeof(temp5));

    memcpy(temp3,BCDValue1,sizeof(temp3));
    memcpy(temp4,BCDValue2,sizeof(temp4));
    memcpy(BCDValue2,BCDValue1,sizeof(BCDValue1));

    for (; i1>=0 && temp4[i1]!=0;i1--);//Ѱ�������Чλ
    //temp5���������м���
    for (;i1>=0;i1--)
    {
        //p*qn
        memset(BCDValue1,0,sizeof(BCDValue1));

        len=(temp4[i1] & 0xf0) >> 4;

        while (len>0)
        {
            AddBCDValue12();
            len--;
        }
        //r=r*10
        BCDValue_MUL_10(temp5);
        //r=r+p*qn
        memcpy(BCDValue2,temp5,sizeof(BCDValue2));
        AddBCDValue12();

        memcpy(temp5,BCDValue1,sizeof(temp5));
        memcpy(BCDValue2,temp3,sizeof(BCDValue2));
        memset(BCDValue1,0,sizeof(BCDValue1));
        len=(temp4[i1] & 0x0f)   ;

        while (len>0)
        {
            AddBCDValue12();
            len--;
        }

        //r=r*10
        BCDValue_MUL_10(temp5);
        //r=r+p*qn
        memcpy(BCDValue2,temp5,sizeof(BCDValue2));

        AddBCDValue12();

        memcpy(temp5,BCDValue1,sizeof(temp5));
        memcpy(BCDValue2,temp3,sizeof(BCDValue2));
    }
    memcpy(BCDValue1,temp5,sizeof(BCDValue1));

    SaveBCDSign1=BCDSign1;
    Correct_BCDValue1();
    result1->Sign=SaveBCDSign1;
    memcpy(result1->Value,BCDValue1,BCDLEN);
#endif
}

void  RoundBcd(BCD *result, WORD decimal)    /* (BCD *n, BYTE decimal) round BCD to fixed number of decimals */
{
    short decimalnum = 0;
    BYTE CFlag = 0,ch,ch1;
    int i,j;

    decimalnum = (result->Sign&0x0F) - decimal;
    if (decimalnum <= 0) return;

//	i = decimalnum/2;
    i=(decimalnum+1)/2-1;/*change by nick 2006.8.28*/
    if (!(decimalnum%2))/*change by nick 2006.8.9*/
        CFlag = (result->Value[i] >= 0x50);
    else
        CFlag = ((result->Value[i]&0x0F) >= 0x05);

    CFlag &= 1;//�����λ

    LeftShiftBCD(result,decimalnum);

    //�������봦��,CFlag=1ʱ��Ҫ��������
    for (i=0;(i<2*BCDLEN)&&CFlag;i++)
    {
        j = i/2;
        ch1=result->Value[j];
        if (i & 1)//(i%2)
            ch = ch1>>4;
        else
            ch = ch1&0x0F;

        ch += CFlag;
        if (ch>=10)
        {
            CFlag = 1;
            ch %= 10;
        }
        else
            CFlag = 0;

        if (i & 1)//(i%2)
        {
            ch1 &= 0x0F;
            ch1 |= ch<<4;
        }
        else
        {
            ch1 &= 0xF0;
            ch1 |= ch;
        }
        result->Value[j] = ch1;
    }
}

void    Subtract(BCD *result1, BCD *with1)     /* (BCD *result, BCD *with) */
{
    short       i;
    BYTE    tmp;

    SaveBCDDec1=result1->Sign;
    SaveBCDDec2=with1->Sign;
    BCDSign1=SaveBCDDec1&0x80;
    BCDSign2=SaveBCDDec2&0x80;
    BCDDecimal1=SaveBCDDec1&0x07;
    BCDDecimal2=SaveBCDDec2&0x07;

    memset(BCDValue1,0,sizeof(BCDValue1));
    memset(BCDValue2,0,sizeof(BCDValue2));

    memcpy(BCDValue1,result1->Value,BCDLEN);
    memcpy(BCDValue2,with1->Value,BCDLEN);

    if (BCDDecimal1>BCDDecimal2)
        while (BCDDecimal1>BCDDecimal2)
        {
            BCDDecimal2++;
            BCDValue_MUL_10(BCDValue2);
        }
    else if (BCDDecimal1<BCDDecimal2)
        while (BCDDecimal1<BCDDecimal2)
        {
            BCDDecimal1++;
            BCDValue_MUL_10(BCDValue1);
        }

    for (i=7;i>=0;i--)
    {
        if (BCDValue1[i]>BCDValue2[i])
            break;
        if (BCDValue1[i]<BCDValue2[i])
        {
            for (i=0;i<8;i++)
            {
                tmp=BCDValue1[i];
                BCDValue1[i]=BCDValue2[i];
                BCDValue2[i]=tmp;
            }
            tmp=BCDSign2;
            BCDSign2=BCDSign1^0x80;
            BCDSign1=tmp^0x80;
            break;
        }
    }

    if (BCDSign1==BCDSign2)
        SubBCDValue12();
    else
        AddBCDValue12();
    SaveBCDSign1=BCDSign1;
    Correct_BCDValue1();

    result1->Sign=SaveBCDSign1;
    memcpy(result1->Value,BCDValue1,BCDLEN);
}


void BcdMul100(BCD *A0)
{
    int i;

    for (i=BCDLEN-1;i>0;i--)
    {
        A0->Value[i]=A0->Value[i-1];
    }
    A0->Value[0]=0;
}

void BcdMul10(BCD *A0)
{
    memset(BCDValue1,0,sizeof(BCDValue1));
    memcpy(BCDValue1,A0->Value,BCDLEN);
    BCDValue_MUL_10(BCDValue1);
    memcpy(A0->Value,BCDValue1,BCDLEN);
}

void BcdDiv10(BCD *A0)
{
    memset(BCDValue1,0,sizeof(BCDValue1));
    memcpy(BCDValue1,A0->Value,8);
    BCDValue_DIV_10(BCDValue1);
    memcpy(A0->Value,BCDValue1,8);
}

/**
 * ����ʵ��BCD/100�Ĳ���
 *
 * @author EutronSoftware (2016-05-28)
 *
 * @param A0
 */
void BcdDiv100(BCD *A0)
{
    memcpy(A0->Value,A0->Value+1,BCDLEN-1);
    A0->Value[BCDLEN-1]=0;
}

//��ʾ��ǰ����ģʽ9aA
void DispInputMode()
{
	BYTE sDisp;

	sDisp = 0;

	if (BIT(ApplVar.ArrowsAlfa, NUMRIC09))//��ǰ��ʽΪ�������뷽ʽ
		sDisp='9';
	else if (BIT(ApplVar.ArrowsAlfa, UPPERASCII))//��ǰ��ʽΪA
		sDisp='A';
	else//��ǰ��ʽΪa
		sDisp='a';

#if (DISP2LINES)
		PutsO_At(sDisp,DISLEN-1);//ccr20131120
#else
        if (GetsO_At(DISLEN-1)==' ')
            PutsO_At(sDisp,DISLEN-1);//ccr20131120
        else // if (GetsO_At(0)==' ')
            PutsO_At(sDisp,0);//ccr20131120
#endif

}


/*********************************************************
 * �л����뷽��,�����������ʾ���뷽����ĸ'9'/'a'/'A'
 * ���õ�ǰ����ģʽ'9','a','A','0'
 * '9'-Ϊ����������ASCII�ַ����뷽ʽ
 * '0'-Ϊ�������뷽ʽ,��ֹ��������
 *
 * @author EutronSoftware (2017-12-12)
 *
 * @param mode
 *
 * @return char
 ***********************************************************/
char SetInputMode(char mode)
{
	BYTE sDisp;

	sDisp = 0;

	switch (mode)	{
    case ID_SHIFTKEY:
        if (BIT(ApplVar.ArrowsAlfa, UPPERASCII))//��ǰ��ʽΪA
        {//�ı�Ϊ�������뷽ʽ
            RESETBIT(ApplVar.ArrowsAlfa, UPPERASCII); //UPPERASCII = 0,NUMRIC09=1
            SETBIT(ApplVar.ArrowsAlfa, NUMRIC09);      //INput numric mode
            sDisp = '9';
        }
        else if (BIT(ApplVar.ArrowsAlfa, NUMRIC09))//��ǰ��ʽΪ9
        {//�ı�Ϊa��ʽ
            RESETBIT(ApplVar.ArrowsAlfa, NUMRIC09);    //UPPERASCII=0,NUMRIC09=0
            sDisp = 'a';
        }
        else//��ǰ��ʽΪa
        {//�ı�ΪA
            SETBIT(ApplVar.ArrowsAlfa, UPPERASCII);       //UPPERASCII=1,NUMRIC09=0
            sDisp = 'A';
        }
        break;
	case '0':
		{//�ı�Ϊ���������뷽ʽ(��������С����)
			SETBIT(ApplVar.ArrowsAlfa, (INPUTVALUE | UPPERASCII | NUMRIC09)); //UPPERASCII = 1,NUMRIC09=1,numric mode
			sDisp='0';
			break;
		}
	case '9':
		{//�ı�Ϊ�������뷽ʽ(ֻ������һ��С����),UPPERASCII = 0,NUMRIC09=1
			RESETBIT(ApplVar.ArrowsAlfa,(INPUTVALUE | UPPERASCII));
			SETBIT(ApplVar.ArrowsAlfa, NUMRIC09);      //INput numric mode
			sDisp='9';
			break;
		}
	case 'a':
		{//�ı�Ϊa��ʽ,UPPERASCII=0,NUMRIC09=0
			SETBIT(ApplVar.ArrowsAlfa,INPUTVALUE);
			RESETBIT(ApplVar.ArrowsAlfa, NUMRIC09+UPPERASCII);    //
			sDisp='a';
			break;
		}
	case 'A':
		{//�ı�ΪA,UPPERASCII=1,NUMRIC09=0
			SETBIT(ApplVar.ArrowsAlfa,(INPUTVALUE | UPPERASCII));
			RESETBIT(ApplVar.ArrowsAlfa, NUMRIC09);
			sDisp='A';
			break;
		}
	default:
		{//����ģʽ�µ����뷽ʽ
#if (defined(DEBUGBYPC))
//			sDisp[0]='~';
#endif
			RESETBIT(ApplVar.ArrowsAlfa,INPUTVALUE);
			SETBIT(ApplVar.ArrowsAlfa, (UPPERASCII | NUMRIC09)); //UPPERASCII = 1,NUMRIC09=1,numric mode
			break;
		}
	}
	if (sDisp)//     DispInputMode();
#if (DISP2LINES)
		PutsO_At(sDisp,DISLEN-1);//ccr20131120
#else
        if (GetsO_At(DISLEN-1)==' ')
            PutsO_At(sDisp,DISLEN-1);//ccr20131120
        else//  if (GetsO_At(0)==' ')
                PutsO_At(sDisp,0);//ccr20131120
#endif
    return  sDisp;
}
//��������ַ����뵽����洢��EntryBuffer��
//�ɹ�����,�������������ַ���
//����ʱ,�Ż�0;
BYTE AppendEntry(char chKey)
{
	if (!Appl_EntryCounter)   //ccr20131120
		memset(EntryBuffer, ' ',ENTRYSIZE - 1);//ccr20131120
    if (Appl_EntryCounter<ENTRYSIZE - 3)//ccr2017-02-28
    {
        if (!BIT(ApplVar.ArrowsAlfa,INPUTVALUE))//����ģʽ��
        {//Ϊ���ּ�
            if (chKey == '.')     //   С����  //
            {
                if (!ApplVar.DecimalPoint && !NO_DECIMAL)//ccr2015-04-20
                {
                    ApplVar.DecimalPoint = 1;
                    if (Appl_EntryCounter==0)
                    {//���������Ϊ".",�Զ���Ϊ"0."
                        AtEntryBuffer(2) = '0';
                        AtEntryBuffer(1) = '.';
                        AtEntryBuffer(0) = 0;
                        Appl_EntryCounter = 2;
                        return 2;
                    }
                }
                else
                {
    //				ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                    return false;
                }
            }
            else if (ApplVar.DecimalPoint && chKey>='0' && chKey<='9')//  Set ApplVar.AP.NetWork address
            {
                if (ApplVar.DecimalPoint > 3)    // С�����������4 //
                {
    //				ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                    return false;
                }
                ApplVar.DecimalPoint++;
            }
        }

        if (Appl_EntryCounter)   //   Shift entry ������ֵ������ջ�����  PenGH //
            memcpy(EntryBuffer, EntryBuffer + 1,ENTRYSIZE - 2);
        AtEntryBuffer(1) = chKey;
        AtEntryBuffer(0) = 0;
        Appl_EntryCounter++;
    }
	return Appl_EntryCounter;
}
//
/***************************************************************************************
 * ��EntryBufferɾ�����������ַ�
 *
 * @author EutronSoftware (2017-11-02)
 *
 * @param disp :��Ϊtrueʱ,���EntryBufferֻ��һ���ַ�,����ǿ������Ϊ'0'��'0.00'
 ***************************************************************************************/
void DeleteEntry(BYTE disp)
{
	int i,k;

	if (disp && Appl_EntryCounter==1)
	{
		ClearEntry();
	}
	else if (Appl_EntryCounter>0)
	{
		k = ENTRYSIZE - 2;
		for (i=0;i<(Appl_EntryCounter-1);i++,k--)
			EntryBuffer[k] = EntryBuffer[k-1];
		EntryBuffer[k] = ' ';
		Appl_EntryCounter --;
		if (ApplVar.DecimalPoint)
			ApplVar.DecimalPoint--;
	}
}
/*********************************************************************************************
 * �Ӽ�������һ�ַ���,��ȷ�ϼ�����,��������ݴ���EntryBuffer,���ȴ��� Appl_EntryCounter
 *
 * @author EutronSoftware (2017-05-05)
 *
 * @param type: Ϊ������ַ�����,'9'-����/'A'-�ַ�/'*'-*�����л����뷽��
 * @param prompt :������ʾ��Ϣ,ccr2018-03-21:prompt[0]=0ʱ,����prompt[0]�ͳ���󰴼�,ϣ��ר��
 * @param strDefault :����ΪNULLʱΪĬ�ϳ�ʼ����,��������ݽ�����strDefault��
 * @param maxLen :�������ݵ���󳤶�,strDefault����С�ռ������strDefault[maxLen+1]
 * @param pwd :='*',��������;=0:������
 * @param useDefault :=true,����Ĭ��ֵ,��������ݽ�����strDefault��;
 *                    =false,������Ĭ��ֵ,��ʱ��Ĭ��ֵ������ʾ
 *
 * @return short :=-1,ȡ������;����ֵΪ������ַ�������Appl_EntryCounter
 *                ��ʹ��strDefaultʱ,NEWSTRING=1��ʾ��������strDefault��ͬ����ֵ
 ***********************************************************************************************/
short GetStrFromKBD(BYTE type,char *prompt,char *strDefault,BYTE maxLen,char pwd,BYTE useDefault)
{
    static BYTE sInput=0;

    BYTE kCode,keyno;
#if defined(CASE_GREECE)//ccr2018-03-21
    BYTE    sKeyOut=false; //	prompt[0]=0ʱ,����prompt[0]�ͳ���󰴼�,ϣ��ר��
#endif
    short sNew=0;//sNew��ʾ�Ƿ�������������
    char pwdBuff[DISLEN+1];
    BYTE flagsCP=ApplVar.ArrowsAlfa;
    int dispFr;//��dispFrָ����λ�ÿ�ʼ��ʾ
    int lenDef;//strDefault�ĳ���


	SetLoop();

    while (KbHit()) Getch();
    if (type=='*')
    {
        if (!sInput) sInput='9';//�״ν���Ĭ��Ϊ��������,�������뱣����һ�ε����뷨
    }
    else
        sInput=type;

    memset(EntryBuffer,' ',ENTRYSIZE-1);
    if (strDefault && useDefault)
    {//��Ĭ���ַ������Ƶ����뻺����
        Appl_EntryCounter=strlen(strDefault);
        lenDef=Appl_EntryCounter;
        if (Appl_EntryCounter>maxLen)
            Appl_EntryCounter=maxLen;
        memcpy(&AtEntryBuffer(Appl_EntryCounter),strDefault,Appl_EntryCounter);
        if (Appl_EntryCounter>DISLEN)
            dispFr=Appl_EntryCounter;
        else
            dispFr=DISLEN;
    }
    else
    {
        Appl_EntryCounter=0;
        dispFr=DISLEN;
    }
	AtEntryBuffer(0) = 0;

    SETBIT(ApplVar.ArrowsAlfa,INPUTVALUE);
#if defined(CASE_GREECE)//ccr2018-03-21
    if (prompt)
    {
       if (prompt[0])//ccr2017-09-21�Ƶ�SetInputMode֮��,�����SetInputMode��ʾ�����뷨�ַ�
          PutsO(prompt);
       else
          sKeyOut=true;//	prompt[0]=0ʱ,����prompt[0]�ͳ���󰴼�,ϣ��ר��
    }
#else
    if (prompt)//ccr2017-09-21�Ƶ�SetInputMode֮��,�����SetInputMode��ʾ�����뷨�ַ�
        PutsO(prompt);
#endif

#if (DISP2LINES)
	if (strDefault==NULL || useDefault)
		Puts1(&AtEntryBuffer(dispFr));
	else //if (strDefault)
		Puts1(strDefault);//Ĭ�����ݽ�����ʾ
#endif
    SetInputMode(sInput);//�л����뷽��,�����������ʾ���뷽����ĸ'9'/'a'/'A'
    for (;;)
    {

        while (!KbHit())    FM_EJ_Exist();

        keyno = Getch();
        if (keyno == SHIFTKey && type=='*')  /* �ı���̵�λ(a->A->9 */
        {
           sInput = SetInputMode(ID_SHIFTKEY);
           continue;
        }
        else if (keyno == UPKey)  /* �����ƶ�һ����ʾλ�� */
        {
            if (dispFr<Appl_EntryCounter && Appl_EntryCounter>DISLEN)
                dispFr++;
            else
                continue;
        }
        else if (keyno == RIGHTKey)  /* �����ƶ�һ����ʾλ�� */
        {
            if (dispFr>DISLEN)
                dispFr--;
            else
                continue;
        }
        else if (keyno == DELETEKey)  /* ɾ�����һ���ַ� */
        {
            if (Appl_EntryCounter)
            {
                DeleteEntry(false);
                dispFr=DISLEN;
                SETBIT(sNew,NEWSTRING);
            }
            else
                continue;
        }
        else if (keyno == ENTERKey)   /* ȷ������ */
        {
            ApplVar.ArrowsAlfa = flagsCP;
            if (strDefault)
            {
                if (useDefault && sNew)
                {
                    if (strcmp(strDefault,&AtEntryBuffer(Appl_EntryCounter)))
                    {//������������ݸ��Ƶ�Ĭ�ϴ洢��
                        memset(strDefault,0,maxLen);
                        strcpy(strDefault,&AtEntryBuffer(Appl_EntryCounter));
                    }
                    else
                        sNew=0;
                }
                else
                    sNew=0;
                //else
                //{
                //    memset(strDefault,0,maxLen);
                //    memcpy(strDefault,&AtEntryBuffer(Appl_EntryCounter),Appl_EntryCounter);
                //    strDefault[Appl_EntryCounter]=0;
                //}
            }
            else
                sNew=0;
			ResetLoop();
#if defined(CASE_GREECE)//ccr2018-03-21
            if (sKeyOut)
               *prompt=keyno;
#endif
            return (Appl_EntryCounter | sNew);
        }
        else if (keyno == EXITKey)
        {
            ApplVar.ArrowsAlfa = flagsCP;
			ResetLoop();
#if defined(CASE_GREECE)//ccr2018-03-21
            if (sKeyOut)
               *prompt=keyno;
#endif
            return -1;
        }
        else if (keyno == CLEARKey)
        {
            if (!Appl_EntryCounter || (strDefault && useDefault && !strcmp(strDefault,&AtEntryBuffer(Appl_EntryCounter))))
			{//ccr2017-07-25ϣ����CLEAR�����˳�
				ApplVar.ArrowsAlfa = flagsCP;
				ResetLoop();
#if defined(CASE_GREECE)//ccr2018-03-21
                if (sKeyOut)
                   *prompt=keyno;
#endif
				return -1;
			}//ccr2017-07-25<<<<<<<<<<<<<<<<<<<<
            else
			{
                Appl_EntryCounter=0;
                SETBIT(sNew,NEWSTRING);
                memset(EntryBuffer,' ',ENTRYSIZE-1);
                //AtEntryBuffer(0) = 0;
                //ccr2017-05-05 ClearEntry();
                dispFr=DISLEN;
#if defined(CASE_GREECE)//ccr2018-03-21
                if (prompt && !sKeyOut)
#else
                if (prompt)
#endif
#if (DISP2LINES)
                {
                    PutsO(prompt);
                }
#else
                {
                    PutsO(prompt);
                    continue;
                }
#endif
            }
        }
        else if (Appl_EntryCounter<maxLen)//ccr2017-05-05
        {
            if (sInput=='9')//��������
            {
                kCode = NUMASC_KEYBOARD[keyno];
                if (kCode && (type=='*' || kCode>='0' && kCode<='9'))
                {
                    dispFr=DISLEN;
                    AppendEntry(kCode);
                    SETBIT(sNew,NEWSTRING);
                }
            }
            else if ((sInput | 0x20)=='a')//�����ַ�
            {
                kCode = ASCIIKEY[keyno];
                if (kCode && (type=='*' || kCode>='a' && kCode<='z' || kCode==' '))
                {
                    if (sInput=='A' && (kCode>='a' && kCode<='z'))
                        kCode &= ~0x20;

                     dispFr=DISLEN;
                     AppendEntry(kCode);
                     SETBIT(sNew,NEWSTRING);
                }
            }
        }
		if (pwd==0)
		{
			PutsM(&AtEntryBuffer(dispFr));
		}
		else
		{//Ϊ��������
			memset(pwdBuff,pwd,DISLEN);
			if (DISLEN>Appl_EntryCounter)
				memset(pwdBuff,' ',DISLEN-Appl_EntryCounter);
			pwdBuff[DISLEN]=0;
			PutsM(pwdBuff);
		}
    }//(for ())
}

//-----------------------------------------------------------------------
//���ַ�����ӡ���м�λ��
//BYTE isMidPrt   == true  ��ӡ���и�ʽ
void PrintStr_Center(char *str,BYTE alCenter)
{
    BYTE sLayOut=ApplVar.PrintLayOut;
    int j,k;
    char strBuff[PRTLEN+1];


    if (alCenter)
    {
        if (str[0]=='@')
        {
            str++;
            ApplVar.PrintLayOut = sLayOut & 0xe7;
        }
        k = strlen(str)-1;
        while (k>0 && str[k]==' ') k--;
        if (k>=0 && k<PRTLEN-1 ) //Middle print Trailer
        {
            for ( j = 0 ; j<=k && str[j]==' ';j++ ) {}//j=��һ���ǿ��ַ�
            for (; j<k && str[k] == ' ';k-- ) {} //k=���һ���ǿ��ַ�
            k -= j;//��Ч���ַ�������
            k++;
            memset(strBuff,' ',sizeof(strBuff)) ;
            memcpy( strBuff + (PRTLEN - k)/2 , str + j , k);
            strBuff[ PRTLEN  ] = '\0';
            PrintRJ(strBuff);
        }
        else
            PrintRJ(str);

        ApplVar.PrintLayOut=sLayOut;
    }
    else
        PrintRJ(str);
}
//-----------------------------------------------------------------------
//
/*********************************************************************************
 * ��ӡ���ַ���,����ַ������ȳ�����ӡ����,��ֶ��д�ӡ
 *
 * @author EutronSoftware (2017-11-06)
 *
 * @param str
 * @param alRight :=true,���Ҵ�ӡ;=false,�����ӡ
 ********************************************************************************/
void PrintLongString(char *str,BYTE alRight)
{
    char sBuf[PRTLEN+1];
    char *sPtr;
    int len;

    sPtr=str;
    len = strlen(str);
    sBuf[PRTLEN]=0;
    while (len>PRTLEN)
    {
        memcpy(sBuf,sPtr,PRTLEN);;sPtr+=PRTLEN;
        RJPrint(0,sBuf);
        len-=PRTLEN;
    }
    if (len)
    {
        memset(sBuf,' ',PRTLEN);
        if (alRight)
            strcpy(sBuf+(PRTLEN-len),sPtr);
        else
            strcpy(sBuf,sPtr);
        RJPrint(0,sBuf);
    }
}


//��__DATE__,__TIME__�л�ȡ���ں�ʱ��,��'\0'����
//01234567890      0123456789
//��Apr 16 2013ת��Ϊ16/04/2013,12:34:45��ʽ
//sizeof(sDate)>19
void DateFrom__DATE__TIME(char *sDate)
{
    int i,j;

	i = strlen(__DATE__)-1;
	//Year field
	sDate[9]=__DATE__[i--];sDate[8]=__DATE__[i--];sDate[7]=__DATE__[i--];sDate[6]=__DATE__[i--];
	sDate[5]=DATECHAR;
	j = 3;
	//��Ӣ����д�·�ת��Ϊ����
	switch (__DATE__[0])
	{
	case 'J':
		sDate[j++] = '0';
		if (__DATE__[1]=='a')
			sDate[j++]='1';
		else if (__DATE__[2]=='n')
			sDate[j++]='6';
		else if (__DATE__[2]=='l')
			sDate[j++]='7';
		break;
	case 'F':
		sDate[j++] = '0';
		sDate[j++]='2';
		break;
	case 'M':
		sDate[j++] = '0';
		switch(__DATE__[2])
		{
		case 'r':sDate[j++]='3';break;
		case 'y':sDate[j++]='5';break;
		}
		break;
	case 'A':
		sDate[j++] = '0';
		switch(__DATE__[1])
		{
		case 'p':sDate[j++]='4';break;
		case 'u':sDate[j++]='8';break;
		}
		break;
	case 'S':
		sDate[j++]='9';
		break;
	case 'O':
		sDate[j++]='1';sDate[j++]='0';
		break;
	case 'N':
		sDate[j++]='1';sDate[j++]='1';
		break;
	case 'D':
		sDate[j++]='1';sDate[j++]='2';
		break;
	}
	sDate[2]=DATECHAR;
	i-=2;//point to day
    j=0;
	if (__DATE__[i]!=' ')
		sDate[j++]=__DATE__[i];
    else
		sDate[j++]='0';

	i++;
	if (__DATE__[i]!=' ')
		sDate[j++]=__DATE__[i];
    else
		sDate[j++]='0';

    sDate[10]=',';
    strcpy(sDate+11,__TIME__);
}
//////////////////////////////////////////////////////////////////////////////

/***************************************************************************
  ��ʾ�����RGBuf�е�����,ÿ����ʾ����
  Appl_dispRGNumberָʾ��ǰҪ��ʾ�ļ�¼��
 UpDown=-1:��ʾǰһ��,��ǰһ����������ʱ,���´ӵ�һ����ʼ�����ʾ;
       =1��ʾ��һ��
 ����:true-�п���ʾ������
      false-�޿���ʾ������
  ***************************************************************************/

BYTE Display_RGBuf(int UpDown)
{
    int items=0,scanIDX;
    BCD sAmt;
    struct TRANSRECORD  RGRec;          /* temporary record */
    BYTE isTrue;/* ��ʾ�Ƿ�Ϊ��Ч��������Ŀ*/
    BYTE firstFound=false;  /* δ�ҵ���һ����С��Ŀ */

    if (ApplVar.FRegi)
    {
        if ((ApplVar.RGRec.Key.Code>DEPT && ApplVar.RGRec.Key.Code<PLU3
             || ApplVar.RGRec.Key.Code>DISC && ApplVar.RGRec.Key.Code<=DISC+discNumber)
            && Appl_DispRGBuf.RGCount == ApplVar.RGNumber
            && ApplVar.FRegi)
        {//���һ����ĿΪ��Ʒ���߲���ʱ
            Appl_DispRGBuf.RGCount = ApplVar.RGNumber+1;
            ApplVar.RGBuf[ApplVar.RGNumber] =  ApplVar.RGRec;
            Appl_DispRGBuf.FirstRGNum++;
            Appl_DispRGBuf.LastRGNum = Appl_DispRGBuf.FirstRGNum;
        }

        if (UpDown==1)
            scanIDX = Appl_DispRGBuf.LastRGNum;
        else
            scanIDX = Appl_DispRGBuf.FirstRGNum;


        /* ��RGBuf����ѡ������Ŀ,�����ѡSCREENLN-1�� */
        {
            isTrue = false;
            scanIDX+=UpDown;
            if (scanIDX>=0 && scanIDX<Appl_DispRGBuf.RGCount)
            {
                RGRec = ApplVar.RGBuf[scanIDX];

                //if ((RGRec.Key.Code>DEPT && RGRec.Key.Code<PLU3))//it must be the PLU or DEPT record
                {
                    if (CheckNotZero(&RGRec.Qty))//Must not be the cancel record
                    {
                        memset(ProgLineMes,' ',sizeof(ProgLineMes));
                        sAmt = RGRec.Amt;

                        if (RGRec.Key.Code>PLU1 && RGRec.Key.Code<PLU3)
                        {
                            ApplVar.PluNumber = RGRec.Key.Code - PLU1 - 1;
                            ReadPlu();

                            strcpy(ProgLineMes,ApplVar.Plu.Name);
                            sAmt.Value[BCDLEN-1]=0;/* ����۸񼶱��ʾ */
                            Multiply(&sAmt, &RGRec.Qty);
                            RoundBcd(&sAmt, 0);

                            isTrue=true;
                        }
                        else if (RGRec.Key.Code>DEPT && RGRec.Key.Code<DEPT+5000)
                        {
                            ApplVar.DeptNumber = RGRec.Key.Code - DEPT - 1;
                            ReadDept();

                            strcpy(ProgLineMes,ApplVar.Dept.Name);
                            Multiply(&sAmt, &RGRec.Qty);
                            RoundBcd(&sAmt, 0);
                            isTrue=true;
                        }
                        else if (RGRec.Key.Code>DISC && RGRec.Key.Code<DISC+5)
                        {
                            ApplVar.DiscNumber = RGRec.Key.Code - DISC - 1;
                            ReadDisc();
                            ApplVar.Disc.Name[ApplVar.AP.Disc.CapSize] = 0;
                            strcpy(ProgLineMes,ApplVar.Disc.Name);
                            isTrue=true;
                        }
                        //else
                        //{
                        //    WORDtoASCL(ProgLineMes,RGRec.Key.Code);
                        //    ProgLineMes[6]=0;
                        //}
                        if (isTrue)
                        {
                            if (!firstFound)
                            {
                                Appl_DispRGBuf.FirstRGNum = scanIDX;
                                firstFound=true;
                            }

                            Appl_DispRGBuf.LastRGNum = scanIDX;

#if(DD_ZIP==1)
                            PutsO(ProgLineMes);
                            Puts1(DispAmtStr(0, &sAmt, DISLEN));
#elif(DD_ZIP_21==1)    // PenGH  2008-06-03
                            PutsO(ProgLineMes);
                            Puts1(DispAmtStr(0, &sAmt, DISLEN));
                            PutsC(DispAmtStr(ProgLineMes, &sAmt, DISLEN));
#else
                            PutsO(DispAmtStr(ProgLineMes, &sAmt, DISLEN));
#endif
                            items++;
                            //RJPrint(0,FormatStrQtyPriAmt(ProgLineMes, 0, 0, &sAmt, SCREENWD));
                        }
                    }
                }
            }
        }
    }
    return (items>0);
}
//ccr2016-12-23>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
/** ccr2016-01-18
 * ��ȡfuncKey�������ڼ����е�λ��
 *
 * @author EutronSoftware (2016-01-18)
 *
 * @param funcKey:������
 *
 * @return BYTE:=0xff,û�з��ִ˹�����,
 *              ���򷵻�funcKey�ڼ����е�λ��(0~n)
 */
BYTE PosOfFuncKey(WORD funcKey)
{
    short i;

    for (i=0;i<MAXKEYB-1;i++)
    {
        if (ApplVar.AP.KeyTable[i]==funcKey)
            return i;
    }
    return 0xff;
}

/**
 * ��ָ��λ������Y��N,��ȷ�Ͻ���
 *
 * @author EutronSoftware (2014-12-12)
 *
 * @param pMessage:��ʾ��Ϣ
 * @param x ,y :��Ϣ��ʾλ��
 * @param pDefault :Ĭ��ֵ1-Yes;0-No
 *
 * @return BYTE :����'Y'��'N',����ʱ,��ʾ��CANCEL(�˳�)��
 */

#if DISP2LINES

BYTE WaitForYesNo(const char *pMessage,BYTE x,BYTE y,BYTE pDefault)
{//˫����ʾ
    BYTE Yes_No,key;
    char dispBuf[DISLEN+1];

    Yes_No = strlen(pMessage);
    if (Yes_No>DISLEN) Yes_No = DISLEN;
    memset(dispBuf,' ',sizeof(dispBuf));
    if (y==0)
        DispStrXY((char*)pMessage,0,0);
    else
        CopyFrStr(dispBuf,pMessage);
    Yes_No=pDefault?'Y':'N';
    dispBuf[DISLEN]=0;
    do
    {
        if (y==0)
        {
            if (Yes_No=='Y')
                strcpy(dispBuf+ DISLEN - 3,(char*)Prompt.LineCap[Line_YES]);
            else
                strcpy(dispBuf+ DISLEN - 3,(char*)Prompt.LineCap[Line_NO]);
        }
        else
        {
            dispBuf[DISLEN-1]=Yes_No;
        }
        DispStrXY(dispBuf ,0,1);

        WAIT_INPUT(key);
        if (key==EXITKey || key==CLEARKey)
        {
            Yes_No = 0;
            break;
        }
        else if (key==UPKey || key==DOWNKey)//ccr2017-12-05
            Yes_No ^= YN;
        else if (ASCIIKEY[key]=='y')
            Yes_No = 'Y';
        else if (ASCIIKEY[key]=='n')
            Yes_No = 'N';
    } while (key!=ENTERKey);
//ccr2016-08-18    ClsArea(x,y,SCREENWD-x);
    return Yes_No;
}

#else
BYTE WaitForYesNo(const char *pMessage,BYTE x,BYTE y,BYTE pDefault)
{//������ʾ
    char Yes_No,key;
    char dispBuf[DISLEN+1];

    Yes_No = strlen(pMessage);
    if (Yes_No>DISLEN) Yes_No = DISLEN;
    memset(dispBuf,' ',sizeof(dispBuf));
    memcpy(dispBuf,pMessage,Yes_No);
    Yes_No=pDefault?'Y':'N';
    dispBuf[DISLEN]=0;
    do
    {
        dispBuf[DISLEN-1]=Yes_No;
        DispStrXY(dispBuf ,0,y);
        WAIT_INPUT(key);
        if (key==EXITKey || key==CLEARKey)
        {
            Yes_No = 0;
            break;
        }
        else if (key==UPKey || key==DOWNKey)//ccr2017-12-05
            Yes_No ^= YN;
        else if (ASCIIKEY[key]=='y')
            Yes_No = 'Y';
        else if (ASCIIKEY[key]=='n')
            Yes_No = 'N';
    } while (key!=ENTERKey);
//ccr2016-08-18    ClsArea(x,y,SCREENWD-x);
    return Yes_No;
}
#endif
/**
 * ����WORD���ݵ�λ��
 *
 * @author EutronSoftware (2016-03-25)
 *
 * @param pDec
 *
 * @return BYTE
 */
BYTE WidthofWORD(WORD pDec)
{
    if (pDec>9999)      return 5;
    else if (pDec>999)  return 4;
    else if (pDec>99)   return 3;
    else if (pDec>9)    return 2;
    else                return 1;
}

/***********************************************
 * �����Ե�y�е�x���ַ�λ����ʾ�ַ���str
 *
 * @author EutronSoftware (2017-06-01)
 *
 * @param str
 * @param x
 * @param y
 ************************************************/
void DispStrXY(CONSTBYTE *str ,BYTE x,BYTE y)
{
    char dispBuf[DISLEN+1];

    if (str && x<DISLEN)
    {
        memset(dispBuf,' ',DISLEN);
        strncpy(dispBuf+x,str,DISLEN-x);
        dispBuf[DISLEN]=0;
#if (DISP2LINES)
        if (y>=1)
        {
            Puts1(dispBuf);
        }
        else
#endif
        {
            PutsO(dispBuf);
        }
    }
}

// ��y��λ����ʾ10��������pDec, strΪ����//
void DisplayDecXY(ULONG pDec,char *str,int y)
{
	char sDisp[DISLEN+1];
    int l;

    memset(sDisp,' ',sizeof(sDisp));

    if (str)
    {
        l = strlen(str);
        if (l>DISLEN) l = DISLEN;
        memcpy(sDisp,str,l);
    }

	ULongtoASC(sDisp+DISLEN-1,pDec);
	sDisp[DISLEN] = 0;
	DispStrXY(sDisp,0,y);
}


CONST TKEYDES EcrKeyDes[]={
#if (DD_FISPRINTER==0 && DD_DISABLEPBF==0)
		{PBF+1	  ,PBF+pbNumber     ,MsgKEYPBFUN  ,SETPBF},//"��̨����\0��̨����\0�ݽ�\0ȷ�Ͻ���\0��ӡ��̨\0��ӡ�ʵ�\0ȡ��ȷ��\0����\0ת��\0����ת��\0����"},
#else
		{PBF+1	  ,PBF+pbNumber     ,MsgKEYPBFUN  ,0},//"��̨����\0��̨����\0�ݽ�\0ȷ�Ͻ���\0��ӡ��̨\0��ӡ�ʵ�\0ȡ��ȷ��\0����\0ת��\0����ת��\0����"},
#endif
        {PORA	  ,PORA             ,MsgKEYPORA   ,0},//"�������"},
		{PORA+1	  ,PORA+poraNumber  ,MsgKEYPO_RA  ,SETPORA},//"����\0���"},
		{TEND+1	  ,TEND+tendNumber  ,MsgKEYTEND   ,SETTEND},//"�ֽ�\0֧Ʊ\0���ÿ�\0����ȯ\0��ͨ��\0IC��"},
        {WEIGHT   ,WEIGHT           ,MsgKEYWEIGHT ,0},//"����"},       //cc 20060713
		{CLERK	  ,CLERK	        ,MsgKEYCLERKN ,0},//"�տ�Ա#"},
		{MODELOCK ,MODELOCK	        ,MsgKEYLOCK   ,0},//"��ʽ��"},
		{SALPER	  ,SALPER	        ,MsgKEYSALPN  ,0},//"ӪҵԱ#"},
        {DEPT	  ,DEPT             ,MsgKEYDEPTNo ,0},//"����#"},
		{DEPT+1	  ,DEPT+199         ,MsgKEYDEPT   ,SETDEPT},//"*"},
		{PLU1	  ,PLU1	            ,MsgKEYPLUNo  ,0},//"PLU"},
        {PLU1+1	  ,PLU1+39990       ,MsgKEYPLUDIR ,SETPLU},//"*"},
        {MODI	  ,MODI	            ,MsgKEYMEMO   ,0},//"˵��"},
        {CORREC+1 ,CORREC+corrNumber,MsgKEYCORR   ,SETCORR},//"����\0ȡ��\0�˻�\0ȡ������"},
        {CURR+1	  ,CURR+currNumber  ,MsgKEYCURR   ,SETCURR},//"��Ԫ\0��Ԫ\0�۱�"},
        {DISC+1	  ,DISC+discNumber  ,MsgKEYDISC   ,SETDISC},//"+%�ӳ�\0-%�ۿ�\0���ӳ�\0����ۿ�"},
        {SUSPEND  ,SUSPEND          ,MsgKEYSUSPEND,0},
//     {MACROFUNC1,MACROFUNC20     ,MESSKEYMACRO ,SETKEYMACRO},
//     {FUNCLOOK1,FUNCLOOK1        ,MsgFUNCLOOK1,0},
//     {FUNCLOOK2,FUNCLOOK2        ,MsgFUNCLOOK2,0},
        {ODRAW    ,ODRAW	        ,MsgKEYDRAW   ,0},//"��Ǯ��"},
        {CLEAR	  ,CLEAR	        ,MsgKEYCLEAR  ,0},//"���"},
        {JPF	  ,JPF		        ,MsgKEYFEED   ,0},//"��ֽ"},
        {MULT	  ,MULT	            ,MsgKEYMULT   ,0},//"X"},
        {POINT    ,POINT            ,MsgKEYDOT    ,0},
        {POINT+1  ,POINT+1          ,MsgKEYZERO2  ,0},
        {POINT+2  ,POINT+11         ,MsgKEYNUMBER ,LISTNUMRIC},
        {SHIFT1	  ,SHIFT1	        ,MsgKEYSHIFT  ,0},//"SHIFT"},
        {DATETIME ,DATETIME	        ,MsgKEYDATE   ,0},//"����"},
        {SUB	  ,SUB		        ,MsgKEYSUBTOT ,0},//"С��"},
        {NPRICE	  ,NPRICE	        ,MsgKEYPRICE  ,0},//"�۸�\0�۸�1\0�۸�2\0�۸�3\0�۸�4"},
        {LEVEL    ,LEVEL            ,MsgKEYPRICEN ,0},//"�۸�#"},      //cc 20060713
        {LEVEL1   ,LEVEL1           ,MsgKEYPRICE1 ,0},//"�۸�#"},      //cc 20060713
        {LEVEL2   ,LEVEL2           ,MsgKEYPRICE2 ,0},//"�۸�#"},      //cc 20060713
        {LEVEL3   ,LEVEL3           ,MsgKEYPRICE3 ,0},//"�۸�#"},      //cc 20060713
        {LEVEL4   ,LEVEL4           ,MsgKEYPRICE4 ,0},//"�۸�#"},      //cc 20060713
        {MODELOCK ,MODELOCK	        ,MsgMODELOCK  ,0},//""},
//     {VIPLOGIN ,VIPLOGIN	        ,MsgVIPLOGIN  ,0},//""},
        {NUMBER2  ,NUMBER2          ,MsgINPUTNUM  ,0},//�������
//     {CUSTOMER ,CUSTOMER         ,MsgCUSTOMER ,0},//����˿���Ϣ ccr2016-09-13
#if defined(CASE_GPRS)
        {CLERK+1  ,CLERK+90         ,MsgKEYCLERK  ,0},//ccr2016-08-23>>>>>����ʾ���ص�������������
        {DRAW+1	  ,DRAW+7           ,MsgKEYDRAWFUN,0},//"������\0֧Ʊ\0���ÿ�\0����ȯ\0��ͨ��\0IC��\0С��"},
        {RHEAD1	  ,RHEAD2           ,MsgRHEADER   ,0},//Ʊͷ,
        {RTRAIL1  ,RTRAIL2          ,MsgRTRAILER  ,0},//Ʊβ,
        {KEY0     ,KEY32            ,MsgKEYBOARD  ,0},//����,//ccr2016-08-23<<<<<<<<<
        {SYSFLG   ,SYSFLG           ,MsgSYSFLAGS  ,0},//ϵͳ����
        {REMOTESETTIME,REMOTESETTIME,MsgDATETIME   ,0},//ϵͳ����
#endif
        {0        ,0                ,MsgKEYNULL   ,0}

//   {SALPER+1 ,SALPER+90        ,MsgKEYSALP   ,0},//"*"},          //cc 20060713
};
#if 0
/**
 * ���տ��������ת��Ϊ��Ӧ�Ĺ�������
 *
 * @author EutronSoftware (2016-02-25)
 *
 * @param fCode :������
 * @param fName :���ڴ洢��������
 */
void ECRFuncCodeToName(WORD fCode,char *fName)
{
    int sIdx;

    for (sIdx=0;EcrKeyDes[sIdx].IndexS &&  EcrKeyDes[sIdx].IndexE;sIdx++)
    {
        if (fCode>=EcrKeyDes[sIdx].IndexS && fCode<=EcrKeyDes[sIdx].IndexE)
        {
            if (EcrKeyDes[sIdx].IndexS==EcrKeyDes[sIdx].IndexE || EcrKeyDes[sIdx].SetupIDX==0)
            {//ֻ��һ����������
                strcpy(fName,EcrKeyDes[sIdx].KeyType);
            }
            else// if (KeyDes[sIdx].SetupIDX)
            {
                if (!ReadItemCaption(EcrKeyDes[sIdx].SetupIDX,fCode-EcrKeyDes[sIdx].IndexS,fName))
                {
                    strcpy(fName,EcrKeyDes[sIdx].KeyType);
                    sIdx=strlen(fName);
                    sIdx+=WORDtoASCL(fName+sIdx,fCode-EcrKeyDes[sIdx].IndexS+1);
                    fName[sIdx]=0;
                }
            }
            return;
        }
    }
    strcpy(fName,EcrKeyDes[sIdx].KeyType);//�޶�Ӧ����
}
#endif

/***************************************************************************************
 * ���տ��������ת��Ϊ��Ӧ�Ĺ���������
 *
 * @author EutronSoftware (2016-02-25)
 *
 * @param fCode :������
 * @param fName :���ڴ洢����������
 *
 * @return WORD
 *         :=0,�޶�Ӧ��������;>0,Ϊ�����������
 **************************************************************************************/
WORD ECRFuncCodeToTypeName(WORD fCode,char *fName)
{
    WORD sIdx;

    for (sIdx=0;EcrKeyDes[sIdx].IndexS &&  EcrKeyDes[sIdx].IndexE;sIdx++)
    {
        if (fCode>=EcrKeyDes[sIdx].IndexS && fCode<=EcrKeyDes[sIdx].IndexE)
        {
            strcpy(fName,EcrKeyDes[sIdx].KeyType);
            return sIdx+1;
        }
    }
    strcpy(fName,EcrKeyDes[sIdx].KeyType);//�޶�Ӧ����
    return 0;
}

/**************************************************************************************
 * ����ǰ���ں�ʱ���ӡ��һ����
 * (dd-mm-yyyy        TIME HH:MM)
 *
 * @author EutronSoftware (2017-05-04)
 **************************************************************************************/
void PrintDateTime()
{
    int l=strlen(Msg[SHIJIAN].str);

    memset(SysBuf,' ',PRTLEN);
    CheckTime(TRUE | 0x80);
    memcpy(SysBuf,DateAsci+4,10);//����ϵͳ���õĸ�ʽ�������
    memcpy(SysBuf+PRTLEN-5-l-1,Msg[SHIJIAN].str,l);
    memcpy(SysBuf+PRTLEN-5, TimeAsci, 5);
    SysBuf[PRTLEN]=0;
    RJPrint(0,SysBuf);
}


/*************************************************************************************
 * ����ULONG,����������Appl_NumberEntry�ͳ�, ����ǰ����Appl_NumberEntry��Ϊ�����ʼֵ
 * Entry���ͳ�BCD����,����С����ʾ
 * �������������д�(����vMax),�򱣳ֳ�ʼֵ,������ERROR_ID(CWXXI18)
 * ��ʹ��SysBuf��Ϊ������
 *
 * @author EutronSoftware (2016-02-29)
 *
 * @param str:�������ݱ���,���������������ʾ��ͬһ��
 * @param vMax:���ֵ
 * @param y:����������ʾλ��(�к�)
 * @param enAMT:Ϊ����Amount,��������С����,�̶���λС��
 * @param iniDisp:�Ƿ��ʼ����ʾ(����ʼֵ��ʾ��y��)
 *
 * @return BYTE :Ϊ�˳�������ʱ�İ���
 ************************************************************************************/
BYTE InputULong(char *str,ULONG vMax,BYTE y,BYTE enAMT,BYTE iniDisp)
{
    WORD keyCode;
	ULONG cpInput,l,cpEntry;
    BYTE keyNo;

    if (str)
        l=strlen(str);
    else
        l=0;
	cpEntry=Appl_NumberEntry;
    if (iniDisp && l)
    {
#if (0) //ccr2018-01-16 ��Ҫ��ʾ���ֵ
        if (vMax)
        {//��ʾ����������ֵ
            memset(SysBuf,' ',DISLEN);
            memcpy(SysBuf,str,l);
            keyCode=ULongtoASC(SysBuf+DISLEN-2,vMax);
            SysBuf[DISLEN-1]=']';
            //!!!!Ϊ��ȷ���������ݸ�λ��ʾ0,��:02072017>>>>>>
            if (keyCode==7)
            {
                SysBuf[DISLEN-keyCode-3]='0';
                keyCode++;
            }//!!!!<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
            SysBuf[DISLEN-keyCode-3]='[';
            SysBuf[DISLEN]=0;
            DispStrXY(SysBuf,0,y);
        }
        else
#endif
            DispStrXY(str,0,y);
    }
    ClearEntry();
    memset(SysBuf,' ',DISLEN);
    if (l) memcpy(SysBuf,str,l);
//ccr2018-01-16    if (enAMT)  RESETBIT(ApplVar.ArrowsAlfa,INPUTVALUE);//ccr2018-01-16
    while (true)
    {
        SetLoop();
        while (!KbHit()){CheckError(0);};
        keyNo=Getch();

        ResetLoop();
        if (keyNo==CLEARKey)//
        {
#if (DISP2LINES)
            if (ApplVar.ErrorNumber)
                Puts1(SPACE);
#endif
            ApplVar.ErrorNumber=0;
            //ccr2017-09-11>>>>>>>
            if (Appl_EntryCounter==0)
            {//������ʱ,�˳�
				Appl_NumberEntry=cpEntry;
                return EXITKey;
            }
            else //ccr2017-09-11<<<<<<<
            {//�����������������,��ظ�ΪĬ��ֵ
                ClearEntry();
				Appl_NumberEntry=cpEntry;
                DisplayDecXY(Appl_NumberEntry,str,y);
                memset(SysBuf,' ',DISLEN);
                SysBuf[DISLEN]=0;
                if (l)  memcpy(SysBuf,str,l);
            }
        }
        else if (keyNo==UPKey || keyNo==DOWNKey || keyNo==EXITKey || keyNo==ENTERKey)
        {
            if (Appl_EntryCounter==0)
				Appl_NumberEntry=cpEntry;
            ApplVar.ErrorNumber=0;
            return keyNo;
        }
        else if (ApplVar.ErrorNumber==0)
        {
            keyCode=ApplVar.AP.KeyTable[keyNo];
            if (keyCode>='0' && keyCode<='9')//ccr2018-01-16 || (keyCode=='.' && enAMT))
                AppendEntry(keyCode);
			else
				continue;
			//cpInput = Appl_NumberEntry;
            GetEntry();
            if (vMax && Appl_NumberEntry>vMax)
			{
				Appl_NumberEntry = cpInput;
                ApplVar.ErrorNumber=ERROR_ID(CWXXI18);
			}
            if (Appl_EntryCounter<DISLEN)
                memcpy(SysBuf+DISLEN-Appl_EntryCounter,&AtEntryBuffer(Appl_EntryCounter),Appl_EntryCounter);
            else
                memcpy(SysBuf+DISLEN,&AtEntryBuffer(DISLEN),DISLEN);
            DispStrXY(SysBuf,0,y);
        }
    }
}

/*******************************************************************************
 * ���뷶Χ����,��������ݴ���LogDefine(RecNumFr,RecNumTo),
 * �����������ڷ�Χ:RecNumFr,RecNumTo����yyyymmdd��ʽ�ĳ��������ڷ�Χ,
 * ��DateFr,DateTo����ѹ������(WORD����)
 * ��ʹ��SysBuf��Ϊ������
 *
 * @author EutronSoftware (2017-06-02)
 *
 * @param msgID :Msg[msgID].str,Msg[msgID+1].str
 * @param vMAX :�������ֵ
 *
 * @return BYTE :���ذ���
 ******************************************************************************/
BYTE InputFromTo(int msgID,ULONG vMAX)
{
    BYTE sKey;

    if (msgID==DATEFROM)
    {//Ϊ����yyyymmdd���ڸ�ʽ������
        vMAX = 0;
        DateForDisplay(0,DISLEN);
        CopyFrStr(SysBuf,Msg[DATEFROM].str);
        DispStrXY(SysBuf,0,0);
    }
    else if (msgID==TIMEFROM)
    {//����yymmddhhmm��ʽ������ʱ��
        memset(SysBuf,' ',DISLEN);
        CopyFrStr(SysBuf,Msg[TIMEFROM].str);
#if (0)//ccr2018-01-16 ��Ҫ��ʾ���ֵ
		if (vMAX)
			ULongtoASCZER0(SysBuf+DISLEN-1,vMAX,10);
		else
#endif
		{
            switch (TIME_DATE)
            {
                default:
                case 0://day,DD-MM-YYYY//
                    strcpy(SysBuf+DISLEN-10,"DDMMYYhhmm");
                    break;
                case 1://day,MM-DD-YYYY//
                    strcpy(SysBuf+DISLEN-10,"MMDDYYhhmm");
                    break;
                case 2://day,YYYY-MM-DD//
                    strcpy(SysBuf+DISLEN-10,"YYMMDDhhmm");
                    break;
            }
		}
		DispStrXY(SysBuf,0,0);
        vMAX = 0;
    }

    sKey = InputULong((char*)Msg[msgID].str,vMAX,0,false,(msgID!=DATEFROM && msgID!=TIMEFROM));
    if (sKey==EXITKey)
        return sKey;
    if (msgID==DATEFROM)
    {//Ϊ������������
        if (vMAX && Appl_NumberEntry>vMAX)
            LogDefine.RecNumFr=0;
        else
            LogDefine.RecNumFr=ULongDateFrInput();

        if (LogDefine.RecNumFr==0)//Ĭ��Ϊ��ǰ����
            LogDefine.RecNumFr = BCDtoDEC(Now.year>>8)*1000000 + DateToYYMMDD();
            //return EXITKey;
        LogDefine.DateFr=EncordDECDDate(LogDefine.RecNumFr/10000,(LogDefine.RecNumFr/100)%100,LogDefine.RecNumFr % 100);
    }
    else
        LogDefine.RecNumFr=Appl_NumberEntry;

    if (msgID==DATEFROM)
    {
        DateForDisplay(0,DISLEN);
        CopyFrStr(SysBuf,Msg[DATETO].str);
        DispStrXY(SysBuf,0,1);
    }
    else if (msgID==TIMEFROM)
    {//����yymmddhhmm��ʽ������ʱ��
        memset(SysBuf,' ',DISLEN);
        CopyFrStr(SysBuf,Msg[TIMETO].str);
        {
            switch (TIME_DATE)
            {
                default:
                case 0://day,DD-MM-YYYY//
                    strcpy(SysBuf+DISLEN-10,"DDMMYYhhmm");
                    break;
                case 1://day,MM-DD-YYYY//
                    strcpy(SysBuf+DISLEN-10,"MMDDYYhhmm");
                    break;
                case 2://day,YYYY-MM-DD//
                    strcpy(SysBuf+DISLEN-10,"YYMMDDhhmm");
                    break;
            }
        }
        DispStrXY(SysBuf,0,1);
    }
#if (1)//ccr2018-01-16>>>>
    else if (LogDefine.RecNumFr==0) //msgID==RECEIPTFROM
        LogDefine.RecNumFr=1;
#endif//ccr2018-01-16<<<<<

    sKey = InputULong((char*)Msg[msgID+1].str,vMAX,1,false,(msgID!=DATEFROM && msgID!=TIMEFROM));
    if (sKey==EXITKey)
        return sKey;

    if (msgID==DATEFROM)
    {//Ϊ������������
        if (vMAX && Appl_NumberEntry>vMAX)
            LogDefine.RecNumTo=0;
        else
            LogDefine.RecNumTo=ULongDateFrInput();
        if (LogDefine.RecNumTo==0)
            LogDefine.RecNumTo=BCDtoDEC(Now.year>>8)*1000000 + DateToYYMMDD();
            //return EXITKey;
        LogDefine.DateTo=EncordDECDDate(LogDefine.RecNumTo/10000,(LogDefine.RecNumTo/100)%100,LogDefine.RecNumTo % 100);
    }
    else
    {
        LogDefine.RecNumTo=Appl_NumberEntry;
        if (LogDefine.RecNumTo==0)
        {
           if (vMAX)
               LogDefine.RecNumTo=vMAX;
           else
               LogDefine.RecNumTo=LogDefine.RecNumFr;
        }
        else if (vMAX && LogDefine.RecNumTo>vMAX)
           LogDefine.RecNumTo=vMAX;
    }
//    if (LogDefine.RecNumTo<LogDefine.RecNumFr)
//        return EXITKey;
//    else
        return sKey;
}
/*********************************************************************
 * ��������ApplVar.Entry.Value�е�BCD��������
 * ����ϵͳ���ڸ�ʽת��ΪULONG��������yyyymmdd
 *
 * @author EutronSoftware (2017-06-02)
 *
 * @return ULONG:��������,��:20170723;=0ʱ,���ڴ�
 ********************************************************************/
ULONG ULongDateFrInput()
{
    BYTE sDay,sMonth,sYear,sYearH;

    switch (TIME_DATE)
    {
    case 1:     //MMDDYYYY//
        sDay=ApplVar.Entry.Value[2];sMonth =ApplVar.Entry.Value[3];
        sYear=ApplVar.Entry.Value[0]; sYearH=ApplVar.Entry.Value[1];
        break;
    case 2:     //YYYYMMDD//
        sDay=ApplVar.Entry.Value[0];sMonth =ApplVar.Entry.Value[1];
        sYear=ApplVar.Entry.Value[2]; sYearH=ApplVar.Entry.Value[3];
        break;
    default:         //DDMMYYYY//
        sDay=ApplVar.Entry.Value[3];sMonth =ApplVar.Entry.Value[2];
        sYear=ApplVar.Entry.Value[0]; sYearH=ApplVar.Entry.Value[1];
        break;
    }
    if (sMonth >0x12 || sDay > GetMonthMaxDay( sYear,sMonth))
        return 0;
    else
        return ((ULONG)BCDtoDEC(sYearH)*1000000+(ULONG)BCDtoDEC(sYear)*10000+BCDtoDEC(sMonth)*100+BCDtoDEC(sDay));
}
/******************************************************************************************
 * �ж��Ƿ�������ʱ��
 *
 * @author EutronSoftware (2017-08-07)
 *
 * @return BYTE :=true,������ʱ��;=false,��������ʱ��
 *****************************************************************************************/
BYTE SummerTimeEnabled()
{
    return (SUMMERTIME!=0);
}
/**
 * ���ݹ�����,�Ӽ��̱��м�����������
 *
 * @author EutronSoftware (2017-09-22)
 *
 * @param funcCode
 *
 * @return BYTE :=0xff,�޴˰���
 */
BYTE GetKeyNoByCode(WORD funcCode)
{
    int i;
    for (i=0;i<MAXKEYB;i++)
    {
        if (funcCode==ApplVar.AP.KeyTable[i])
            return i;
        else if (ApplVar.AP.KeyTable[i]==0 && ApplVar.AP.KeyTable[i+1]==0)
            break;
    }
    return 0xff;
}

/************************************************************************
 * ��URL�з��������,Ȼ�����DNS��������IP��ַ
 *
 * @author EutronSoftware (2017-10-30)
 *
 * @param pURL :URL,��:"http://www.abcd.efg/myweb/websend.php"
 * @param pIP :��������IP��ַ(4�ֽ�),
 *
 * @return BYTE:=true,�����ɹ�;=false,����ʧ��
 ************************************************************************/
#if defined(DEBUGBYPC)
BYTE GetIPByDNSFromURL(BYTE *pIP,char *pURL,char pBlock)
{

    int i,j,l;
    char domain[32];


    l=strlen(pURL);
    if (l>=5 && CLONG(pURL[0])==(('p'<<24) +('t'<<16)+('t'<<8)+('h')) && pURL[4]==':')
    {
        if (l>=7 && CWORD(pURL[5])==(('/'<<8) +'/'))
            i=7;
        else
            i=5;
    }
    else
        i=0;
    for (j=0;(j<sizeof(domain)-1)&&i<l;j++)
    {
        if (pURL[i]!='/')
            domain[j]=pURL[i++];
        else
            break;
    }
    domain[j]=0;//�õ�����
    if (j>7)//Ϊ��Ч����,������"www.a.b"
    {
        for (i=0;i<j;i++)
        {
            if (domain[i]<'0' && domain[i]!='.' || domain[i]>'9')
                break;
        }
        if (i<j)
        {//Ϊ�ַ���ɵ�����
            //if (netconn_gethostbyname(URL, &ipAddr)==ERR_OK)
            if (CLONG(ApplVar.AP.NetWork.PrimaryDNS[0]))//&& ApplVar.AP.NetWork.ServerURL[0])
            {
                if (true)//dns_gethostbyname(domain,&ipAddr,IPByDNS_Found,NULL)==ERR_OK)
                {//147.102.24.100
                    pIP[0]=147;//IPByDNS[0];
                    pIP[1]=102;//IPByDNS[1];
                    pIP[2]=24;//IPByDNS[2];
                    pIP[3]=100;//IPByDNS[3];
                    return true;
                }
            }
        }
        else
        {//����Ϊֱ�ӵ�IP��ַ
            return (IPToNum(pIP,domain,j)==0);
        }
    }
    return false;
}

#if (0)
BOOL  GetIpByDomainName(char *szHost,char szIp[100][100],int *nCount)
{
    WSADATA        wsaData;
    char           szHostname[100];
    HOSTENT   *pHostEnt;
    int             nAdapter   =   0;
    struct       sockaddr_in   sAddr;
    if   (WSAStartup(0x0101,   &wsaData))
    {
        AfxMessageBox("WSAStartup   failed   %s/n",   WSAGetLastError());
        return FALSE;
    }

    pHostEnt   =  gethostbyname(szHost);
    if (pHostEnt)
    {
        while   (   pHostEnt->h_addr_list[nAdapter]   )
        {
            memcpy   (   &sAddr.sin_addr.s_addr,   pHostEnt->h_addr_list[nAdapter],   pHostEnt->h_length);
            char  szBuffer[1024] = {0};

            sprintf(szBuffer,"%s", inet_ntoa(sAddr.sin_addr));

            strcpy(szIp[nAdapter],szBuffer);
            OutputDebugString(szBuffer);
            nAdapter++;
        }

        *nCount = nAdapter;
    }
    else
    {
        DWORD  dwError = GetLastError();
        CString  csError;
        csError.Format("%d",dwError);
        OutputDebugString(csError);
        OutputDebugString("gethostbyname failed");
        *nCount = 0;
    }
    WSACleanup();
    return TRUE;

}
#endif
#endif

/*****************************************************************
 * �ڵ�y����ʾ�ַ���title,�ڵ�һ���ַ�λ��׷���ַ�pre
 *
 * @author EutronSoftware (2017-11-29)
 *
 * @param y
 * @param title
 * @param pre
 ****************************************************************/
void PutsPre(BYTE y,char* title,char pre)
{
    char dBuf[DISLEN+1];

    memset(dBuf,' ',DISLEN);
    if (pre)
    {
        dBuf[0]=pre;
        strncpy(dBuf+1,title,DISLEN-1);
    }
    else
        strncpy(dBuf,title,DISLEN);
    dBuf[DISLEN]=0;
#if (DISP2LINES)
    if (y==0)
        PutsO(dBuf);
    else
        Puts1(dBuf);
#else
    PutsO(dBuf);
#endif
}

/***********************************************************
 * ��������,�Դ��ڷ�ʽ��ʾ������֤����
 * ����У�鴢����ʱ,��ʾ������ʾ���ȴ�����
 * @author EutronSoftware (ccr2017-12-11)
 *
 * @param PWDType:������ʾ��Ϣ
 * @param pass:������õ�����
 * @param pwdFor:��������Ķ���(X/Z/SET/MG/CLERK)
 *
 * @return BYTE:=1,������֤��ȷ;=0,������֤ʧ��;=0xff,ȡ��
 *************************************************************/
BYTE SetPassword(const char* PWDType,char *pass,BYTE pwdFor)
{

    short pwdY;
    BYTE keyno;
    char sPass[SCREENWD+1];

	  keyno=*pass;//ccr2018-01-22 ���Ӵ����,����ʱ���ܱ��Ż���,���´������
    if (keyno!=0)
    {//1.У�������
		if (true)//ccr2018-01-22 ���Ӵ����,����ʱ���ܱ��Ż���,���´������
			pwdY=GetStrFromKBD('*',(char*)DText[DTEXT_PASSWORD],NULL,MAXPWD-1,'*',NO);
        if (pwdY<=0)
            return 0xff;
        else if (strcmp(pass,&AtEntryBuffer(Appl_EntryCounter)))
            pwdY=false;//����У��ʧ��
    }
    if (pwdY)
    {
        if (PWDType)
        {//2.����������
            pwdY=GetStrFromKBD('*',(char*)PWDType,NULL,MAXPWD-1,'*',NO);
        }
        else
        {
            pwdY=GetStrFromKBD('*',(char*)DText[DTEXT_NEWPWD],NULL,MAXPWD-1,'*',NO);
        }
        if (pwdY<0)
            return 0xff;
        if (pwdY==0)
            sPass[0]=0;//����Ϊ��
        else
            strcpy(sPass,&AtEntryBuffer(Appl_EntryCounter));
        //3.ȷ��������
        pwdY=GetStrFromKBD('*',(char*)DText[DTEXT_CONFIRMPWD],NULL,MAXPWD-1,'*',NO);
        if (pwdY>=0 && !strcmp(sPass,&AtEntryBuffer(Appl_EntryCounter)))
        {//���������óɹ�
            strcpy(pass,sPass);
            return true;
        }
    }
    //����У��ʧ��,��ʾ�������
    PutsO(DMes[ItemDMes18]);
    WAIT_INPUT(keyno);
    return false;
}

/*********************************************************
 * У������, ����У�鴢����ʱ,��ʾ������ʾ���ȴ�����
 *
 * @author EutronSoftware (2017-12-11)
 *
 * @param pwdFor :X/Z/SET/MG
 *
 * @return BYTE:=1,������֤��ȷ;=0,������֤ʧ��;=0xff,ȡ��
 *********************************************************/
BYTE CheckPassword(BYTE pwdFor)
{
    CONSTCHAR *sMode;
    short pwd;

    switch (pwdFor)
    {
    case X:
        sMode = ApplVar.AP.ModePwd.PwdX;
        break;
    case Z:
        sMode = ApplVar.AP.ModePwd.PwdZ;
        break;
    case SET:
        sMode = ApplVar.AP.ModePwd.PwdSET;
        break;
    case MG:
        sMode = ApplVar.AP.ModePwd.PwdMG;
        break;
    default:
        return 1;
    }
    if (sMode[0])
    {
        pwd=GetStrFromKBD('*',(char*)DText[DTEXT_PASSWORD],NULL,MAXPWD-1,'*',NO);
        if (pwd==-1)
            return 0xff;
        else if (pwd==0 || strcmp(&AtEntryBuffer(Appl_EntryCounter),sMode))
        {
            //����У��ʧ��,��ʾ�������
            PutsO(DMes[ItemDMes18]);
            WAIT_INPUT(pwd);
            return false;
        }
    }
    return 1;
}


/****************************************************
 * ������������֮�������
 *
 * @author EutronSoftware (2017-12-15)
 *
 * @param year_start
 * @param month_start
 * @param day_start
 * @param year_end
 * @param month_end
 * @param day_end
 *
 * @return int
 *******************************************/
int day_diff(int year_start, int month_start, int day_start,
             int year_end, int month_end, int day_end)
{
    int y2, m2, d2;
    int y1, m1, d1;

    m1 = (month_start + 9) % 12;
    y1 = year_start - m1/10;
    d1 = 365*y1 + y1/4 - y1/100 + y1/400 + (m1*306 + 5)/10 + (day_start - 1);

    m2 = (month_end + 9) % 12;
    y2 = year_end - m2/10;
    d2 = 365*y2 + y2/4 - y2/100 + y2/400 + (m2*306 + 5)/10 + (day_end - 1);

    return(d2 - d1);
}

#if defined(CASE_EURO) //!!! GREECE_ONLY !!!
#define  SECONDLAYERFR    35
BYTE KeyOfSecondLayer(BYTE keyno)
{
    WORD sKeyCode;
    BYTE sKey=keyno+SECONDLAYERFR;

    sKeyCode=ApplVar.AP.KeyTable[keyno];
    if (BIT(ApplVar.ArrowsAlfa,KEY2ndLAYER) && (sKeyCode<=DEPT || sKeyCode>=PLU1) && sKeyCode!=SHIFT1)
    {
        PutsO(Msg[SPACE].str);
        RESETBIT(ApplVar.ArrowsAlfa,KEY2ndLAYER);
        if ((keyno<=28)&& ApplVar.AP.KeyTable[sKey])
            return sKey;
    }
    return keyno;
}
#endif
/*******************************************************************
 * ���ַ����ͳ�������ϴ�ӡ,ռ��PRTLEN����,ʹ��SysBuf��Ϊ�ݴ���
 *
 * @author EutronSoftware (2018-01-19)
 *
 * @param aLong :��Ҫ��ӡ�ĳ�����
 *        aWidth:aLongռ�ÿ���.=0ʱ,����=aLongλ��;>0ʱ,����ͷ������0
 ***************************************************************/
void PrintStr_ULong(const char *caption,ULONG aLong,BYTE aWidth)
{
    memset(SysBuf,' ',PRTLEN);
    if (caption)
        CopyFrStr(SysBuf,caption);
    if (aWidth)
       ULongtoASCZER0(SysBuf+PRTLEN-1,aLong,aWidth);
    else
       ULongtoASC(SysBuf+PRTLEN-1,aLong);
    SysBuf[PRTLEN]=0;
    RJPrint(0,SysBuf);

}

