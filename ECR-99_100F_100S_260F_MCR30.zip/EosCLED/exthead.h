//------------------------For Debug--------------------------
#include "debug.h"
//------------------------For Debug--------------------------


/******************* Working Lay Out with Assembly language ******************/
extern BYTE    KeyFrHost;       //ApplVar.Key code from host computer.

extern struct LOGCOND LogDefine;

extern BYTE
    InActive,               /* Activity timer for displaying Time */
	CopyReceipt,
	ARROWS,         /* define ARROWS ArrowsRight */
                    //(ARROWS, BIT0);   set receipt on
                    //(ARROWS, BIT1);   set RG led,��ʶ��������״̬(û��ʹ��)
	Prefix1,
	Prefix2 ;

extern UnLong RamOffSet,
		 FisOffSet ;

extern ULONG Appl_NumberEntry;

extern CONST WORD SORT[7] ;

/******************* Working Memory Lay Out with C language ******************/


extern BCD
	ZERO,
	ONE,
	TEN,
	HUNDRED,
	THOUSAND,
	THOUSAND10,
	THOUSAND100,
	MAXBCDWORD,
	MAXBCDBYTE,
	MILLION,
	MILLION10,
	MAXBCDLONG,
    MAXBCDULONG;

#ifndef ReceiptMAX
extern  ULONG    ReceiptMAX;
#endif


extern struct APPTEXT DefaultText ;
extern struct APPLICATION Default ;
extern struct DEFAULT Def ;

extern CONSTCHAR *DMes[];//[lenDMes] ;//ccr2017-05-15
extern CONSTCHAR *DText[];//[lenDText] ;//ccr2017-05-15

extern CONST WORD TblAUX_Funcs[AUX_FUNCITEMS];
extern CONST BYTE TblXZ_Funcs[ITEMS_X+ITEMS_Z];

#if(DD_ZIP_21==1)
#define  ItemDTextTOT    0
#define  ItemDTextSUB    1
#define  ItemDTextCHG    2
#define  ItemDTextPRI    3
#define  ItemDTextCAN    4
#define  ItemDTextCUR    5
#define  ItemDTextCOV    6

extern CONSTCHAR CusDText[][4];//[4];
#endif


extern CONST char UPCOMM[][4];

#if COMPOSEIN
extern CONST char CodeASC[NUMASC][4];
#endif

extern CONST struct XZREPORT XZTitle[XZNUM];

extern CONST WORD  KeyTablePBF[MAXKEYB];

extern CONST char PortType[portTypeNum][PORTTYPELEN];

extern const BYTE KPArticleCmd[KPTypeNum-2];
extern CONST char KPType[KPTypeNum][7];
extern CONST char SPType[SPTypeNum][8];		//lyq added 20040331

extern CONST struct SYSFLAGIDX SysFlagUsed[SYSUSED];
extern CONST char GrapType[GRASETMAX][tCAPWIDTH];
extern CONST char GrapSet[4][tCAPWIDTH];

extern CONST char Release[16] ;
extern CONST char ReleaseDate[];


extern CONSTCHAR *ConfTab[];//[17];
extern CONSTCHAR *ConfTi[];//[PRTLEN+1];


extern CONST FSTRING Msg[];


extern CONST BYTE	ASCIIKEY[MAXKEYB];
extern CONST BYTE	NUMASC_KEYBOARD[MAXKEYB];


#if (DD_FISPRINTER)
extern BYTE	LED_BLNK;	//��ʼֵ=_LED_BLNKFreq,����0ʱ,�ı�ָʾ�Ƶ�״̬ //
extern BYTE 	LED_BLNKFreq; //ָʾ����˸Ƶ��,=0ʱ,����˸	//
extern WORD  SelectCounter,EnterCounter;// ͳ�Ƽ����µ�ʱ�� //

extern CONST FSTRING MsgError[];
#else
extern CONST FSTRING CommandSet[];
#endif

#if (pbAmtDisc)
extern WORD	LastKey;//ccr091210 �������۵��������һ�����۵ĵ�Ʒ����Ĺ�����() //
#endif

extern CONST struct PROMPTTEXT Prompt;
extern struct TimeDate     Now;
extern short	PCCounter,CCDCounter;

extern BYTE DialTime;// store the second when dialup
extern BYTE DialSkiped;//flags


extern BYTE
    ApplRamSaved,               //ApplVar �����־
    MACSwitch,  //0=MAC is off;1=MAC is on
    Appl_BitNumber,              /* used during programming */
    Appl_ProgStart,               /* programming started */
    Appl_ProgType,               /* programming type status */
    Appl_MaxEntry,               //Max length of input from keyboard
    Appl_EntryCounter;                   /* entry counter */

extern short
     Appl_ProgLine,                /* programming type line */
     Appl_ProgNumber;             /* item  (plu or function #) number of programming */

extern BYTE
    ModeHead[DISLEN+1],
    PwdInput[MAXPWD],       //    Save the password of input
    PCBuffer[PCBUFMAX], // !!!!!!!��Ҫ�ƶ�PCBuffer��Ϊ�˽�Լ�ռ�,��Щ�ط�����PCBuffer�����ı������ʹ�� !!!!!!//
    EntryBuffer[ENTRYSIZE],                /*    entry buffer is ((max caption size) * 2) + 1     */
    ProgLineMes[64],            /* Ϊ������ʾʱ,������ñ��������,��ʾ�ڵ�һ�� */
                                /* Ϊ˫����ʾʱ��������������ñ���,��ʾ�ڵ�һ�� */
#if (DISP2LINES)
    ProgLine1Mes[64],       //Ϊ˫����ʾʱ���������������,��ʾ�ڵڶ���
#endif
    SysBuf[128],            /*    System buffer max 128 positions     */
    SetDateFlg,             //used for set up date and time
    DateAsci[16],           /*    holds asci date: "Mon,2014-01-21" or "Mon,21-01-2014" */
    TimeAsci[10];                    /* holds asci time:12:23:34*/

#if DD_CHIPC
extern struct  ICStruct IC;                //ccr chipcard
#endif

extern APPLICATION_SAVE ApplVar;

#if defined(DEBUGBYPC)
extern BYTE LoopInput;
#endif

extern struct DISPLAY_RGBUF
    Appl_DispRGBuf;

extern WORD  CopyOfTax[8];//ccr2018-03-15�����ж��޸�˰���Ƿ�����ͬ��ֵ.
