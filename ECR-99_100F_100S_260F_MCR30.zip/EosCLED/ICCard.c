#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
#include "flowbill.h"
#if (DD_CHIPC==1 && CASE_MFRIC==1)
#include "MFRCard.h"
#include "MFRCard.c"
#endif

#if (DD_CHIPC==1)
//---------------------------------------------------------------------------
#if (DD_4442IC==0)
CONST char EUTRON[7]="EUTRON";
#else
CONST char EUTRON[9]="EUTRONHN";
#endif

//----------------------------------------------------------------------------
CONST BYTE TTbPswd[10][3]={// Table of passwords
    {0xE9,0x18,0x82},// 0
    {0x29,0xB1,0x40},// 1
    {0xAB,0x5D,0x26},// 2
    {0x7F,0xC7,0x64},// 3
    {0xAA,0x13,0x86},// 4
    {0x64,0x2F,0x17},// 5
    {0xF3,0x7A,0x1A},// 6
    {0x1C,0x2C,0x75},// 7
    {0x5A,0x3A,0xCB},// 8
    {0x43,0xD5,0xB9}// 9
};
//----------------------------------------------------------------------------
CONST BYTE TbCript[40]={// Table of codified areas decodification
    0x0D,0x79,0xAB,0xBA,0x96,0xCE,0xF7,0x89,0xF6,0xA1,
    0x79,0xDA,0x72,0x24,0xD3,0xA7,0x06,0x32,0xAB,0x12,
    0x30,0x01,0x1F,0x53,0xB3,0x52,0xEA,0x51,0x04,0x92,
    0xD4,0x17,0x4A,0x9B,0x05,0x5C,0x59,0x85,0x54,0x97
};
//------------------------------------------------------------------------------
#if (CASE_MFRIC==1)
#define  SCC_Ver() (1)
#else
#define  SCC_Ver() CC_VerifyPWD(IC.CHIP_PSWD)
#endif
#define  SCC_NewPwd(pPwd) CC_WritePWD(pPwd)
#define ReadFLAGS() CC_Read(IC.REC_Flags,ICR_FLAGS,sizeof(IC.REC_Flags))
#define ReadCUSTOMER() CC_Read(IC.REC_Customer,ICR_CLI,sizeof(IC.REC_Customer))
#define ReadCHARGE() CC_Read(IC.REC_VALATT,ICR_VALATT,sizeof(IC.REC_VALATT))//*2)
#define ReadInit() CC_Read(IC.REC_INIT,ICR_INIT,28)
//------------------------------------------------------------------------------
void PrintChipCard(BYTE pSel);
void PayByChipCard(BCD *pValue,BYTE pay);
BYTE ChipCard();
short ReadFactory();         //OK
char RD_ChipCard();
short Clear_CHIP();
signed char Initial_CHIP();
short Charge_CHIP();
void ProgClearChip();
void ProgChargeChip();
WORD EncodeDateSelf(char *frDate);
BYTE SCC_Ccrc(BYTE *pHL,short pB);
short SCC_Cript(BYTE pDE[],short pC); //OK
void SCC_SetPswd(short pType);
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// �����ţ����Ƚϡ������жϲ��������У�IC���Ƿ񻻹� //
// ccr050316
BYTE CheckCardNo()
{

        short sLp,sInt;
        short sOk;
		UnLong sCardNo;
#if(CASE_MFRIC==1)
	BYTE sREC_Factory[MFR_DSCAD+4]; //38 bytes
#else
        BYTE sREC_Factory[CC_FACTORY]; //38 bytes
#endif

#if(CASE_MFRIC==1)
	sOk = CC_ReadMFR(sREC_Factory,RW_Factory);
#else
        sOk=CC_Read(sREC_Factory,ICR_FACT,sizeof(sREC_Factory));
#endif
        if(sOk)
        {

#if(DD_4442IC == 1 || CASE_MFRIC == 1)
		for (sLp=0;sLp<4;sLp++)
#if(CASE_MFRIC==1)
			sREC_Factory[MFRCC_SERIE+sLp] = sREC_Factory[MFRCC_SERIE+sLp] ^ TbCript[sLp*sLp+10];
		memcpy	(&sCardNo,&sREC_Factory[MFRCC_SERIE],sizeof(sCardNo));
#else
			sREC_Factory[CC_SERIE+sLp] = sREC_Factory[CC_SERIE+sLp] ^ TbCript[sLp*sLp+10];
		memcpy(&sCardNo,&sREC_Factory[CC_SERIE],sizeof(sCardNo));
#endif
#else
		memcpy(&sCardNo,&sREC_Factory[CC_SERIE],sizeof(sCardNo));
#endif
			sOk = (sCardNo==IC.CardNo);
       	}
		return sOk;
}

BYTE ChipCard()
{
	BYTE sBuf[6];
	WORD sPINH;
	short i;

#if(CASE_MFRIC==0)
	if (BIT(ApplVar.ICCardSet.Options,IC_CHIPCARD) && CC_Insert())
	{
		if (!BIT(IC.ICState,IC_INSERT) && CC_Open(sBuf))
		{
			Delay(10);
#else
	if(BIT(ApplVar.ICCardSet.Options,IC_CHIPCARD) && CC_Request())
	{
		if(!MFRInsert)
		{
			MFRInsert = 1;
#endif
			ApplVar.ErrorNumber=0;
			IC.CHIP_Flag = RD_ChipCard();
			switch (IC.CHIP_Flag){
				case  IC_ILLERR :
					ApplVar.ErrorNumber=CWXXI50-CWXXI01+1;
					break;
				case  IC_POSERR	:
					ApplVar.ErrorNumber=CWXXI51-CWXXI01+1;
					break;
				case  IC_DATAERR:
					ApplVar.ErrorNumber=CWXXI52-CWXXI01+1;
					break;
				case  IC_DATEERR:
					ApplVar.ErrorNumber=CWXXI53-CWXXI01+1;
					break;
				case  IC_CANERR :
					ApplVar.ErrorNumber=CWXXI54-CWXXI01+1;
					break;
				case  IC_NEWERR :
					ApplVar.ErrorNumber=CWXXI56-CWXXI01+1;
					break;
/*
				case  IC_CUSTERR:
					ApplVar.ErrorNumber=CWXXI55-CWXXI01+1;
					break;
				case  IC_TYPEERR:
					ApplVar.ErrorNumber=CWXXI57-CWXXI01+1;
					break;
				case  IC_WRITERR:
					ApplVar.ErrorNumber=CWXXI58-CWXXI01+1;
					break;
				case  IC_NUMERR	:
					ApplVar.ErrorNumber=CWXXI59-CWXXI01+1;
					break;
*/
				case  IC_TYPE0 	:
					if (!BIT(ApplVar.ICCardSet.Options, IC_TYPE_0))
						{
						ApplVar.ErrorNumber=CWXXI60-CWXXI01+1;
						}
					break;
				case  IC_TYPE1 	:
					if (!BIT(ApplVar.ICCardSet.Options, IC_TYPE_1))
					{
						ApplVar.ErrorNumber=CWXXI61-CWXXI01+1;
						break;
					}
				case  IC_TYPE2	:
					if (IC.CHIP_Flag==IC_TYPE2 && !BIT(ApplVar.ICCardSet.Options, IC_TYPE_2))
					{
						ApplVar.ErrorNumber=CWXXI62-CWXXI01+1;
					}
					else
//cc 2007-01-30 for MFRIC>>>>>>>>>>>>>>>
#if(CASE_MFRIC==1)
						if(IC.REC_INIT[CC_FTIPO] && (IC.REC_INIT[CC_PINL] || IC.REC_INIT[CC_PINH]) && MFRInsert)
#else
						if (IC.REC_INIT[CC_FTIPO] && (IC.REC_INIT[CC_PINL] || IC.REC_INIT[CC_PINH]) && !BIT(IC.ICState,IC_NOTREMOVED))
#endif
//cc 2007-01-30 for MFRIC>>>>>>>>>>>>>>>
						{
							sPINH = (WORD)IC.REC_INIT[CC_PINH]*256+IC.REC_INIT[CC_PINL];//ccr040811>>>
							for (i=3;i>=0;i--)
							{
								sBuf[i] = (sPINH % 10)+'0';
								sPINH /= 10;
							}
							sBuf[4] = 0;
//cc 2007-01-30 for MFRIC>>>>>>>>>>>>>>>
#if(CASE_MFRIC==1)
							if (!CheckPWD(sBuf) || !CheckCardNo())
							{
								MFRInsert = 0;
#else
							if (!CheckPWD(sBuf) || !CC_Insert() || !CheckCardNo())
							{
								RESETBIT(IC.ICState,IC_NOTREMOVED);
#endif
//cc 2007-01-30 for MFRIC>>>>>>>>>>>>>>>
								IC.CHIP_Flag = -1;
								ApplVar.ErrorNumber=CWXXI36-CWXXI01+1;//error PIN
							}						//ccr040811<<<<
						}
					break;
				default:
//cc 2007-01-30 forMFRIC>>>>>>>>>>>>>>>
#if(CASE_MFRIC==1)
					MFRInsert = 0;
#endif
//cc 2007-01-30 forMFRIC>>>>>>>>>>>>>>>
					IC.CHIP_Flag = -1;
					ApplVar.ErrorNumber=CWXXI50-CWXXI01+1;
					break;
			}
//			if (ApplVar.ErrorNumber==0 && IC.CHIP_Flag>=0)
//				Collect_Data(INSERTICLOG);
//cc 2007-01-30 forMFRIC>>>>>>>>>>>>>>>
#if(CASE_MFRIC==1)
			if(Appl_ProgType)
                            ApplVar.ErrorNumber=0;
			if (!ApplVar.ErrorNumber)
				MFRInsert = 1;
#else
			if (ApplVar.ErrorNumber==0)
				SETBIT(IC.ICState,IC_NOTREMOVED);
#endif
			return TRUE;
		}
#if (CASE_MFRIC==0)
		else
			return false;
#endif
	}
	else
	{
		IC.CHIP_Flag = -1;
#if (CASE_MFRIC==0)
		if (BIT(IC.ICState,IC_INSERT))
			CC_Close();
		RESETBIT(IC.ICState,IC_INSERT | IC_NOTREMOVED);
#else
		MFRInsert = 0;
#endif
	}
	return false;
}
//------------------------------------------------------------------------------
char RD_ChipCard()

// It reads the chip-card, Supposes that the chip-card is inserted.
//
// ATTENTION : IT MUST BE PATCHED FOR THE POWER FAIL PROBLEM
//
// NOTE : It reads the chip-card and NOT verifies the password.
//     The password verification must be performed by the routine of
//     more high level during the PAYMENT, CHARGING, CREATION phases !!!
//
// It verifies the password re-calculating the password to applied
// in operation of chip-card type, of heading data preceding readed
// and of the eventual PIN code entered by the keyboard.
//
// Input  :
//     pDispTo:0-Skip display
//            :1-display data on GroupBoxNew;
//            :2-display data on GroupBoxVerify;
// Result<0---> NOT OK ,error code:
//Ccr "�����ʹ�!"          //-1
//Ccr "POS�����!"         //-2
//Ccr "�����ݴ�!"          //-3
//Ccr "Ϊ���ڿ�!"          //-4
//Ccr "Ϊ��ʧ��!"          //-5
//Ccr "�ͻ�����!"        //-6
//Ccr "Ϊ�¿�!"            //-7
//Ccr "���ǹ��￨!"        //-8
//Ccr "д������!"          //-9
//Ccr "���Ų���!"          //-10
//Result>=0:---> OK ,  A=0 !
//       0		Type0
//       1		Type1
//       2		Type2
//	      3             Type3	cc added 2005-03-11
//ccr "�ۿۿ�:",           //0
//ccr "�ֽ�:",           //1
//ccr "���ʿ�:",           //2
//cc "���ڿ�:",		//3
// 		  CHIP_TIPO  = type of chip-card
// 		  CHIP_FTIPO = Flags of type of chip-card
//
{
		WORD sTmp;
	short sRet;
		char sBuf[12];
#if(CASE_MFRIC==1)	//cc 20070717
		memset(&IC,0,	sizeof(IC.REC_Factory)+
						sizeof(IC.REC_Flags)+
						sizeof(IC.REC_INIT)+
						sizeof(IC.REC_Customer)+
		sizeof(IC.REC_VALATT) +

		sizeof(IC.MFR_Factory) +
		sizeof(IC.MFR_Facpre) +
		sizeof(IC.MFR_INIT) +
		sizeof(IC.MFR_Customer) +
		sizeof(IC.MFR_VALATT) +
		sizeof(IC.MFR_VALPRE));//*2);
#else
		memset(&IC,0,	sizeof(IC.REC_Factory)+
						sizeof(IC.REC_Flags)+
						sizeof(IC.REC_INIT)+
						sizeof(IC.REC_Customer)+
						sizeof(IC.REC_VALATT));//*2);
#endif

		SETBIT(IC.ICState,IC_INSERT);


        //test of application recognition pattern��read the "FACTORY" area��
//cc 2007-01-30 for MFRIC>>>>>>>>>>>>>>>>>
#if(CASE_MFRIC==1)		//cc 20070827
	if((sRet = ReadFactory())==0 || sRet==IC_NEWERR)
	{
		if (!sRet)
			return IC_ILLERR;
		else
		{
			CC_ReadMFR(IC.MFR_INIT,RW_Init);
			CC_ReadMFR(IC.MFR_Customer,RW_Customer);
			return IC_NEWERR;
		}
	}
	if(!CC_ReadMFR(IC.MFR_INIT,RW_Init) || !CC_ReadMFR(IC.MFR_Customer,RW_Customer) ||
	   !CC_ReadMFR(IC.MFR_VALATT,RW_Valatt) || !CC_ReadMFR(IC.MFR_VALPRE,RW_Valpre))
#else
		if(!ReadFactory() ||
        	!CC_Read(IC.REC_Flags, ICR_FLAGS, sizeof(IC.REC_Flags)+sizeof(IC.REC_INIT)+sizeof(IC.REC_Customer)+sizeof(IC.REC_VALATT)))//*2))
#endif
//cc 2007-01-30 for MFRIC>>>>>>>>>>>>>>>>>
//cc 2007-01-30 for MFRIC>>>>>>>>>>>>>>>>>
#if(CASE_MFRIC==1)
	else
		MFRToIC(RW_Flags);
#endif
//cc 2007-01-30 for MFRIC>>>>>>>>>>>>>>>>>
		if (QueryICBlock(IC.CardNo))
			return IC_CANERR;
        //test if the chip-card has been initialized
//cc 2007-01-30 for MFRIC>>>>>>>>>>>>>>>>>
#if(CASE_MFRIC==1)
	if(IC.REC_Flags[CC_AGGINIZ] == 0x55)
#else
        if((IC.REC_Flags[CC_VERG1]==0xff)&&(IC.REC_Flags[CC_VERG1+1]==0xff)||IC.REC_Flags[IC_AGGINIZ] == 0x55)
#endif
//cc 2007-01-30 for MFRIC>>>>>>>>>>>>>>>>>
		return IC_NEWERR;

        IC.CriptCnt=IC.CardNo%10;
        //decodify the 'INIT' record

#if(CASE_MFRIC==0)
        SCC_Cript(IC.REC_INIT,28); //Decode of INIT record
        if(IC.REC_INIT[CC_CRCINIT]!=SCC_Ccrc(IC.REC_INIT,sizeof(IC.REC_INIT)-1))
            return IC_DATAERR;
#else
	if(!MFRToIC(RW_Init))
	{
		return IC_DATAERR;
	}
#endif

        if(IC.REC_INIT[CC_TIPO]==TIPO_OPE)
            return IC_TYPEERR; //Operator/Supervisor type

		else
        	{
                if(IC.REC_INIT[CC_TIPO]>TIPO_CLIC) //Is it "Customer" (0,1, or 2) type ?
				return IC_CUSTERR;

                IC.PosCode=0;
                CLONG(IC.PosCode)=CLONG(IC.REC_INIT[CC_CODPOS]);

                IC.CHIP_TIPO=IC.REC_INIT[CC_TIPO];
                IC.CHIP_FTIPO=IC.REC_INIT[CC_FTIPO];
                IC.CHIP_PROT=IC.CHIP_FTIPO&3; //Set the protection type

                SCC_SetPswd(0);
                //read and decodify the customer data

#if(CASE_MFRIC==0)
                SCC_Cript(IC.REC_Customer,64); //Decode of Customer Area
#else
		if(!MFRToIC(RW_Customer))
		{
			return IC_DATAERR;
		}
#endif

				if (IC.PosCode!=ApplVar.ICCardSet.PosCode)
					return IC_POSERR;

				if ((IC.REC_INIT[CC_FTIPO] & (1 << FLT0_Scad)) && BIT(ApplVar.ICCardSet.Options,IC_DEAD))
				{
					memset(sBuf,' ',10);
					HEXtoASC(sBuf,(char *)&Now.year,2);
					HEXtoASC(sBuf+5,&Now.month,1);
					HEXtoASC(sBuf+8,&Now.day,1);//2005-02-04
					sTmp = EncodeDateSelf(sBuf);
					if (sTmp>*((WORD *)(IC.REC_Flags+ CC_DSCAD)))
							return IC_DATEERR;
				}
#if(CASE_MFRIC==0)
                if(IC.REC_Customer[CC_CRCCLI]!=SCC_Ccrc(IC.REC_Customer,sizeof(IC.REC_Customer)-1))
				return IC_DATAERR;
                //read and decodify the 'CHARGE-VALUE' data

                SCC_Cript(IC.REC_VALATT,sizeof(IC.REC_VALATT));//*2);

                if(SCC_Ccrc(IC.REC_VALATT,sizeof(IC.REC_VALATT)-2)!=IC.REC_VALATT[CC_CRCVAL])//checksum of charge-value field
				return IC_DATAERR;
#else
		if(!MFRToIC(RW_Valatt))
		{
			return IC_DATAERR;
		}
#endif
//             if(SCC_Ccrc(IC.REC_VALPRE,sizeof(IC.REC_VALPRE)-2)!=IC.REC_VALPRE[CC_CRCVAL])//checksum of charge-value field
//                 return IC_DATAERR;
				if (IC.REC_Flags[CC_AGGINIZ] == 0x55)
					return IC_DATAERR;
        }
        return IC.CHIP_TIPO;
}

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
void icBCD2EcrBCD(BCD *ecrBCDTo,char *icBCDFr,BYTE pLenFr)
{
    short sLp,sLen;

    memset(ecrBCDTo,0,sizeof(BCD));
    sLen = pLenFr-1;

    for (sLp=0;sLp<pLenFr;sLp++)
    {
        ecrBCDTo->Value[sLp] = icBCDFr[sLen];
        sLen--;
    }
}

//------------------------------------------------------------------------------
void EcrBCD2icBCD(char *icBCDTo,BCD *ecrBCDFr,BYTE pLenTo)
{
    short sLp,sLen;

    memset(icBCDTo,0,pLenTo);
    sLen = pLenTo-1;

    for (sLp=0;sLp<pLenTo;sLp++)
    {
        icBCDTo[sLen] = ecrBCDFr->Value[sLp];
        sLen--;
    }
}

//------------------------------------------------------------------------------
void DecodeDateSelf(WORD pD0,char toDate[])
/*
; 01/01/92 (1992) <--- 0000000-0001-00001  = 0021 : min value
; 31/12/91 (2091) <--- 1100011-1100-11111  = C79F : max value
; toDate ="2003-01-01"
*/
{
	WORD  sYear, sDay, sMonth;
	memset(toDate,' ',10);

  	sYear = (pD0>>9) + 1992;
  	sMonth = (pD0>>5) & 0x0f;
  	if (sMonth<1 || sMonth>12)
        sMonth = 1;
  	sDay = pD0 & 0x1F;
  	if (sDay<1 || sDay>31)
        sDay=1;
	WORDtoASC(toDate+3, sYear);
	WORDtoASC(toDate+6, sMonth);
	if (toDate[5]==' ')
		toDate[5]='0';
	WORDtoASC(toDate+9, sDay);
	if (toDate[8]==' ')
		toDate[8]='0';
    toDate[4]=toDate[7]='-';
	toDate[10] = 0;
}


WORD EncodeDateSelf(char *frDate)
/*
; It converts a date from the TDate format in a binary number of two bytes.
; The year is denoted by only the last two digit. (0..99)
;
; NOTE : the packing starts from the date 01/01/92
;
; The resultant number is so greater as greater is the date
;
; 01/01/92 (1992) --> 0000000-0001-00001  = 0021 : min value
; 31/12/91 (2091) --> 1100011-1100-11111  = C79F : max value
;
; Input : frDate="2001-01-01"
; Output: BC = value calculated
*/
{

  WORD sYear, sDay, sMonth;

  sYear = (frDate[0] & 0x0f)*1000 + (frDate[1] & 0x0f)*100+(frDate[2] & 0x0f)*10+(frDate[3] & 0x0f) - 1992;
  sMonth = (frDate[5] & 0x0f)*10+(frDate[6] & 0x0f);
  sDay = (frDate[8] & 0x0f)*10+(frDate[9] & 0x0f);;
  return (sYear<<9) + (sMonth<<5) + sDay;
}

//------------------------------------------------------------------------------
BYTE SCC_Ccrc(BYTE *pHL,short pB)  //OK
//; Subroutine SCC_Ccrc
//;
//; It calculates the checksum to control a certain area.
//;
//; Input : HL -> source area
//;          B =  size of area
//; Result :  CRC calculated (16 bits)
//;
{
        short sLp ;
        BYTE sSum;
        sSum=0;
        for(sLp=0;sLp<pB;sLp++)
                sSum=sSum+pHL[sLp];
        sSum++;
        return sSum;
}
//------------------------------------------------------------------------------
short SCC_Cript(BYTE pDE[],short pC) //OK
//; Subroutine SCC_Cript
//;
//; It codifies / decodifies a certain area
//;
//; Input : DE -> area in ram to codify / decodify
//;          C =  #bytes (1..N)
//;
//;         CriptCnt = current counter on codify table
{
        short sLp,sBX;
        sBX=IC.CriptCnt;
        for(sLp=0;sLp<pC;sLp++)
        {
                pDE[sLp]=pDE[sLp]^TbCript[sBX];
                sBX=(sBX+1)%40;
        }
        IC.CriptCnt=sBX;
        return 1;
}
//------------------------------------------------------------------------------
void SCC_SetPswd(short pType)     //OK
/*{; Subroutine SCC_SetPswd
; Set the current password in operation of data readed from the chip-card,
; and store it into the CHIP_PSWD buffer.
;
; If CHIP_PROT=1 or 2 (protec. level)--> CHIP_PIN must contains the PIN-code !!!
;}*/
{
        short sLp,sInt;
        sInt=IC.CardNo%10;
        for(sLp=0;sLp<=2;sLp++)
                IC.CHIP_PSWD[sLp]=TTbPswd[sInt][sLp];
        if((IC.CHIP_PROT>0)&&(pType==0))
        {
                sInt=(IC.CHIP_PSWD[0]+((short)IC.CHIP_PSWD[1]<<8))
                      +(IC.REC_INIT[CC_PINL]+((short)IC.REC_INIT[CC_PINH]<<8));
                IC.CHIP_PSWD[0]=sInt&0xff;
                IC.CHIP_PSWD[1]=(sInt>>8)&0xff;
        }
}
//------------------------------------------------------------------------------
short ReadFactory()         //OK
{
	short sLp,sInt,sFlag;
        short sOk;
#if(CASE_MFRIC==1)
	sOk = CC_ReadMFR(IC.MFR_Factory,RW_Factory);
	CC_ReadMFR(IC.MFR_Facpre,RW_Facpre);	//cc 20070827
	if(sOk)		//cc 20070825
	{
		if (IC.MFR_Factory[MFRCC_AGGINIZ] == 0x55)//ccr090311
			return IC_NEWERR;//ccr090311

		if(IC.MFR_Factory[MFRCC_AGGVAL] == 0x55)
		{
			IC.MFR_Facpre[MFRCC_AGGVAL] = 0x55;
			sFlag = 1;
		}
		else
			sFlag = 0;

		if(IC.MFR_Factory[MFRCC_CRCFACT] != 0xff &&
			IC.MFR_Factory[MFRCC_CRCFACT] != SCC_Ccrc(IC.MFR_Factory,sizeof(IC.MFR_Factory)-1))
		{
			memcpy(IC.MFR_Factory,IC.MFR_Facpre,sizeof(IC.MFR_Facpre));
			if(sFlag)
			{
				IC.MFR_Factory[MFRCC_AGGVAL] = 0x55;
				IC.MFR_Factory[MFRCC_CRCFACT] = SCC_Ccrc(IC.MFR_Factory, 15);
			}
			CC_WriteMFR(IC.MFR_Factory,RW_Factory);
//			return false;
		}

		if(IC.MFR_Facpre[MFRCC_CRCFACT] != 0xff &&
			IC.MFR_Facpre[MFRCC_CRCFACT] != SCC_Ccrc(IC.MFR_Facpre,sizeof(IC.MFR_Facpre)-1))
		{
			memcpy(IC.MFR_Facpre,IC.MFR_Factory,sizeof(IC.MFR_Facpre));
			CC_WriteMFR(IC.MFR_Facpre,RW_Facpre);
//			return false;
		}

		if(IC.MFR_Facpre[MFRCC_CRCFACT] != 0xff && memcmp(IC.MFR_Factory,IC.MFR_Facpre,sizeof(IC.MFR_Facpre)))
		{
			memcpy(IC.MFR_Factory,IC.MFR_Facpre,sizeof(IC.MFR_Facpre));
			if(sFlag)
			{
				IC.MFR_Factory[MFRCC_AGGVAL] = 0x55;
				IC.MFR_Factory[MFRCC_CRCFACT] = SCC_Ccrc(IC.MFR_Factory, 15);
			}
			CC_WriteMFR(IC.MFR_Factory,RW_Factory);
//			return false;
		}

		MFRToIC(RW_Factory);
	}
#else
        sOk=CC_Read(IC.REC_Factory,ICR_FACT,sizeof(IC.REC_Factory));
#endif
        if(sOk)
        {

	        IC.CardNo=0;
#if(DD_4442IC==1 || CASE_MFRIC==1)
		    for (sLp=0;sLp<4;sLp++)
        		IC.REC_Factory[CC_SERIE+sLp] = IC.REC_Factory[CC_SERIE+sLp] ^ TbCript[sLp*sLp+10];
#endif

	        CLONG(IC.CardNo)=CLONG(IC.REC_Factory[CC_SERIE]);

		    sInt = IC.CardNo % 40;

#if(DD_4442IC==1 || CASE_MFRIC==1)
		    for (sLp=0;sLp<sizeof(EUTRON)-1;sLp++)
		    {
		        IC.REC_Factory[sLp+CC_PATT] = IC.REC_Factory[sLp+CC_PATT] ^ TbCript[sInt];
		        sInt=(sInt+1) % 40;
		    }
#endif
            for(sLp=0;sLp<sizeof(EUTRON)-1;sLp++)
            { //verify "EUTRON"
                    sOk=sOk&(IC.REC_Factory[sLp+CC_PATT]==EUTRON[sLp]);
                    if(!sOk)
                            break;
            }
        }
        return sOk;
}


//---------------------------------------------------------------------------
//
//
short Clear_CHIP()
{
#if(CASE_MFRIC==1)
	BYTE sFactory[MFR_DSCAD+4];
#endif
	if (IC.CHIP_Flag==-1)//
		return IC.CHIP_Flag;
    else //it must be not initialized
   	{

      if (SCC_Ver())
	  {
#if(CASE_RAMBILL)
		memcpy(FlowBuff.CDC_refreshic.RValue,&IC.REC_VALATT[CC_VAL],sizeof(FlowBuff.CDC_refreshic.RValue));
		FlowBuff.CDC_refreshic.OpType = 1;
		memcpy(FlowBuff.CDC_refreshic.RPoint,&IC.REC_VALATT[CC_PUNTI],sizeof(FlowBuff.CDC_refreshic.RPoint));
		Collect_Data(REFRESHICLOG);
#endif
#if(CASE_MFRIC==1)
			memset(IC.MFR_INIT,0xff,sizeof(IC.MFR_INIT));
			memset(IC.MFR_Customer,0xff,sizeof(IC.MFR_Customer));
			memset(IC.MFR_VALATT,0xff,sizeof(IC.MFR_VALATT));
			IC.MFR_Factory[MFRCC_AGGINIZ] = 0x55;
			IC.MFR_Factory[MFRCC_AGGVAL] = 0xff;
			memset(&IC.MFR_Factory[MFRCC_DSCAD],0x00,4);
			IC.MFR_Factory[MFRCC_CRCFACT] = SCC_Ccrc(IC.MFR_Factory, 15);	//cc 20070825
			if(!CC_WriteMFR(IC.MFR_Factory,RW_Factory) ||!CC_WriteMFR(IC.MFR_INIT,RW_Init) ||
		    	    !CC_WriteMFR(IC.MFR_Customer,RW_Customer) || !CC_WriteMFR(IC.MFR_VALATT,RW_Valatt) ||
		    	    !CC_WriteMFR(IC.MFR_Factory, RW_Facpre) || !CC_WriteMFR(IC.MFR_VALATT,RW_Valpre))
#else
		memset(IC.REC_Flags,0xff,	sizeof(IC.REC_Flags)+
									sizeof(IC.REC_INIT)+
									sizeof(IC.REC_Customer)+
									sizeof(IC.REC_VALATT)*2);


		IC.REC_Flags[CC_AGGINIZ] = 0x55;
		if(!CC_Write(IC.REC_Flags,ICR_FLAGS,sizeof(IC.REC_Flags)+
									sizeof(IC.REC_INIT)+
									sizeof(IC.REC_Customer)+
									sizeof(IC.REC_VALATT)))//*2);
#endif
		{
				return -1;
		}
        IC.REC_INIT[CC_PINL] = 0; //set PIN-L (olny if Protection= 0 or 1)
        IC.REC_INIT[CC_PINH] = 0; //set PIN-H (olny if Protection= 0 or 1)


        SCC_SetPswd(1);
#if(CASE_MFRIC==0)
        if (!SCC_NewPwd(IC.CHIP_PSWD))
			return -1;
#endif
#if(CASE_MFRIC==0)
		IC.REC_Flags[CC_AGGINIZ] = 0xff;
			if(!CC_Write(IC.REC_Flags,IC_AGGINIZ,1))
			{
				return -1;
			}
#endif
#if(CASE_MFRIC==1)
			if(!CC_ReadMFR(sFactory,RW_Factory))
			{
				return -1;
			}
			if(sFactory[MFRCC_AGGINIZ] != 0x55)
			{
				return -1;
			}
//			IC.CHIP_Flag = 1;
//			RJPrint(0,Msg[QCHICKA].str);
//			PrintChipCard(2);
			return IC_NEWERR;
#else
		IC.CHIP_Flag = RD_ChipCard();
		return IC.CHIP_Flag;
#endif
      }
      else
        return -1;
   	}

}

//---------------------------------------------------------------------------

signed char Initial_CHIP()
{
#if (CASE_MFRIC==1)
	BYTE	cpPin[2],icProt;
#endif

	if (IC.CHIP_Flag!=IC_NEWERR)//
		return -1;
	else
   	{
       SCC_SetPswd(1);


      if (SCC_Ver())
	  {
        IC.CriptCnt = IC.CardNo % 10;
#if (CASE_MFRIC==1)
		cpPin[0] = IC.REC_INIT[CC_PINL];	cpPin[1] = IC.REC_INIT[CC_PINH];
		icProt = IC.CHIP_PROT;
#else
        SCC_SetPswd(0);
#endif
	IC.REC_Flags[CC_AGGINIZ] = 0x55;
#if(CASE_MFRIC==0)
        IC.REC_INIT[CC_CRCINIT] = SCC_Ccrc(IC.REC_INIT, 27);
        SCC_Cript(IC.REC_INIT, sizeof(IC.REC_INIT));
        IC.REC_Customer[CC_CRCCLI] = SCC_Ccrc(IC.REC_Customer, 63);
        SCC_Cript(IC.REC_Customer, sizeof(IC.REC_Customer));
        IC.REC_VALATT[CC_CRCVAL] = SCC_Ccrc(IC.REC_VALATT, 30);
		memcpy(IC.REC_VALPRE,IC.REC_VALATT,sizeof(IC.REC_VALATT));
        SCC_Cript(IC.REC_VALATT, sizeof(IC.REC_VALATT));//*2);
#else
			ICToMFR(RW_ALL);
			IC.MFR_Factory[MFRCC_CRCFACT] = SCC_Ccrc(IC.MFR_Factory, 15);	//cc 20070825
#endif
		IC.REC_Flags[CC_AGGINIZ] = 0x55;
#if(CASE_MFRIC==1)
			if(!CC_WriteMFR(IC.MFR_Factory,RW_Factory) ||!CC_WriteMFR(IC.MFR_INIT,RW_Init) ||
	           	    !CC_WriteMFR(IC.MFR_Customer,RW_Customer) || !CC_WriteMFR(IC.MFR_VALATT,RW_Valatt))
#else
        if (!CC_Write(IC.REC_Flags, ICR_FLAGS, sizeof(IC.REC_Flags)+sizeof(IC.REC_INIT)+sizeof(IC.REC_Customer)+sizeof(IC.REC_VALATT)))//*2))
#endif
			return IC_WRITERR;

		IC.REC_Flags[CC_AGGINIZ] = 0xff;
#if(CASE_MFRIC==1)
			ICToMFR(RW_Flags);
			IC.MFR_Factory[MFRCC_CRCFACT] = SCC_Ccrc(IC.MFR_Factory, 15);	//cc 20070825
	 		if(!CC_WriteMFR(IC.MFR_Factory,RW_Factory))
#else
        if (!CC_Write(IC.REC_Flags, IC_AGGINIZ, 1)) //Clear area $55
#endif
			return IC_WRITERR;
#if (CASE_MFRIC==1)
			if(!CC_WriteMFR(IC.MFR_Factory,RW_Facpre) || !CC_WriteMFR(IC.MFR_VALATT,RW_Valpre))
				return IC_WRITERR;
#endif

#if(CASE_MFRIC==0)
        if (SCC_NewPwd(IC.CHIP_PSWD))
			IC.CHIP_Flag = RD_ChipCard();
		else
			IC.CHIP_Flag = -1;
#else
			IC.CHIP_Flag = RD_ChipCard();
#endif
#if(CASE_RAMBILL)
		if (IC.CHIP_Flag>=0)
		{
			FlowBuff.CDC_refreshic.OpType = 5;
			Collect_Data(REFRESHICLOG);
		}
#endif

		return IC.CHIP_Flag;
      }
      else
        return -1;
   	}
}
//---------------------------------------------------------------------------

short Charge_CHIP()
{
    BCD sInt;
	char sResult;
#if(CASE_MFRIC==1)
    	BYTE sVALATT[MFRCC_CRCVAL+1]; // 32 bytes  Area of the "current charge-value"
#else
    BYTE sVALATT[CC_CRCVAL+1]; // 32 bytes  Area of the "current charge-value"
#endif


	if (IC.CHIP_Flag<0)//
		return -1;
	else
   	{
       	SCC_SetPswd(0);

      	if (SCC_Ver())
	  	{
	        IC.CriptCnt = IC.CardNo % 10;

#if(CASE_MFRIC==0)
	        IC.REC_INIT[CC_CRCINIT] = SCC_Ccrc(IC.REC_INIT, 27);
	        SCC_Cript(IC.REC_INIT, sizeof(IC.REC_INIT));
	        IC.REC_Customer[CC_CRCCLI] = SCC_Ccrc(IC.REC_Customer, 63);
	        SCC_Cript(IC.REC_Customer, sizeof(IC.REC_Customer));
#else
			ICToMFR(RW_Init);
			ICToMFR(RW_Customer);
#endif

			icBCD2EcrBCD(&sInt, &IC.REC_VALATT[CC_NOPER],2);
			Add(&sInt, &ONE);
			EcrBCD2icBCD( &IC.REC_VALATT[CC_NOPER], &sInt,2);

#if(CASE_MFRIC==0)
	        IC.REC_VALATT[CC_CRCVAL] = SCC_Ccrc(IC.REC_VALATT, 30);
			memcpy(IC.REC_VALPRE,IC.REC_VALATT,sizeof(IC.REC_VALATT));
	        SCC_Cript(IC.REC_VALATT, sizeof(IC.REC_VALATT));//*2);


			CC_Read(sVALATT, ICR_VALATT, sizeof(IC.REC_VALATT));
#else
			ICToMFR(RW_Valatt);
			CC_ReadMFR(sVALATT,RW_Valatt);
#endif

			IC.REC_Flags[CC_AGGVAL] = 0x55;

#if(CASE_MFRIC==1)
			ICToMFR(RW_Flags);
			IC.MFR_Factory[MFRCC_CRCFACT] = SCC_Ccrc(IC.MFR_Factory, 15);	//cc 20070825
			if(sResult = CC_WriteMFR(IC.MFR_Factory,RW_Factory))
			{
				if(sResult = CC_WriteMFR(IC.MFR_VALATT,RW_Valatt))
				{
#else
        	if (sResult = CC_Write(IC.REC_Flags+CC_AGGVAL, IC_AGGVAL, 1)) //Set area $55
       	    {
			 	if (sResult = CC_Write(IC.REC_VALATT, ICR_VALATT, sizeof(IC.REC_VALATT)))//*2))
	            {
#endif
					IC.REC_Flags[CC_AGGVAL] = 0xff;
#if(CASE_MFRIC==1)
					ICToMFR(RW_Flags);
					IC.MFR_Factory[MFRCC_CRCFACT] = SCC_Ccrc(IC.MFR_Factory, 15);	//cc 20070825
					sResult = CC_WriteMFR(IC.MFR_Factory,RW_Factory);
#else
			        sResult = CC_Write(IC.REC_Flags+CC_AGGVAL, IC_AGGVAL, 1); //Clear area $ff
#endif
	            }
				 if (!sResult)//*2))
	            {
#if(CASE_MFRIC==1)
					CC_WriteMFR(sVALATT,RW_Valatt);
#else
		            CC_Write(sVALATT, ICR_VALATT, sizeof(IC.REC_VALATT));
#endif
					return IC_WRITERR;
	            }
       	    }
       	    else
				return IC_WRITERR;

 /*           if (sResult=CC_Write(IC.REC_Flags,ICR_FLAGS,sizeof(IC.REC_Flags)+
								sizeof(IC.REC_INIT)+
								sizeof(IC.REC_Customer)+
								sizeof(IC.REC_VALATT)))// *2);
            {
				IC.REC_Flags[CC_AGGVAL] = 0xff;
		        sResult = CC_Write(IC.REC_Flags+CC_AGGVAL, IC_AGGVAL, 1); //Clear area $ff
            }
*/

			if (!sResult)
			{
#if(CASE_MFRIC==1)
				CC_WriteMFR(sVALATT,RW_Valatt);
#else
	            CC_Write(sVALATT, ICR_VALATT, sizeof(IC.REC_VALATT));
#endif
				return IC_WRITERR;
			}

#if(CASE_MFRIC==0)
			IC.CHIP_Flag = RD_ChipCard();
			if (IC.CHIP_Flag<0)
	            CC_Write(sVALATT, ICR_VALATT, sizeof(IC.REC_VALATT));
			return IC.CHIP_Flag;
#else
			if(!CC_WriteMFR(IC.MFR_Factory,RW_Facpre) || !CC_WriteMFR(IC.MFR_VALATT,RW_Valpre))	//cc 20070825
				ErrorNum = 77;
			//SysBuf[0] = ErrorNum;
			//PrnBuffer((char *)&SysBuf,1);
			return 1;
#endif
   		}
		else
			return -1;
   	}
}


//---------------------------------------------------------------------------
//Print Chip card on printer
//pSel:select the message for print
//	=0,display only
//	=1,print selected
//  =2,print all the message

void PrintChipCard(BYTE pSel)
{

  BCD sVal1,sVal2;
  short sInt;
  BYTE	sICOpt;
  char sNumber[5];	//cc 20070813


	sICOpt = ApplVar.ICCardSet.Options;
	if (pSel==0)
		RESETBIT(sICOpt, IC_REPORT);
	if (IC.CHIP_Flag>=0)
	{
		if (BIT(sICOpt,IC_REPORT))
		{
			PrintLine('-');
			memset(&sVal1,0,sizeof(BCD));
			ULongToBCDValue(sVal1.Value, IC.CardNo);
			FormatQtyStr(Msg[KAHAO].str, &sVal1, PRTLEN);
			RJPrint(0, SysBuf);
			if (pSel==2)
			{
				memset(SysBuf,' ',PRTLEN);
				CopyFrStr(SysBuf, Msg[KLXING].str);
				CopyFrStr(SysBuf+PRTLEN-8, Msg[ZHEKOUCA+IC.REC_INIT[CC_TIPO]].str);
			    SysBuf[PRTLEN-2] = 0;//delete :
				RJPrint(0, SysBuf);
			}
		}

		sInt = 1;
		if (IC.CHIP_Flag>0)
		{
			icBCD2EcrBCD(&sVal1,(char*)&IC.REC_VALATT[CC_VAL], 5);
			if  (IC.CHIP_Flag==2)
				SETBIT(sVal1.Sign,BIT7);
			if (BIT(sICOpt,IC_REPORT))
			{
				FormatAmtStr(Msg[KNJE].str, &sVal1, PRTLEN);
				RJPrint(0, SysBuf);
			}
			if (pSel==0)
			{
				FormatAmtStr(NULL, &sVal1, DISLEN);
				if (SysBuf[0]==' ' && SysBuf[1]==' ')
					SysBuf[0]= IC.REC_INIT[CC_TIPO]+'0';
				PutsO(SysBuf);
			}
		}
		else if (IC.CHIP_Flag==0 && pSel==0)
		{
				icBCD2EcrBCD(&sVal1,(char*)&IC.REC_Customer[CC_CPERC], 2);
				FormatAmtStr(NULL, &sVal1, DISLEN);
				if (SysBuf[0]==' ' && SysBuf[1]==' ')
					SysBuf[0]= '0';
				PutsO(SysBuf);
		}

		if (IC.REC_VALATT[CC_FORE]!=0 && BIT(sICOpt,IC_REPORT))
		{
			icBCD2EcrBCD(&sVal1,(char*)&IC.REC_VALATT[CC_FORE], 1);
			RJPrint(0, FormatQtyStr(Msg[KYJIN].str, &sVal1, PRTLEN));
		}

		if (BIT(sICOpt,IC_REPORT))
		{
			if (pSel==2){

				icBCD2EcrBCD(&sVal1,(char*)&IC.REC_VALATT[CC_PRGVEN], 5);
				FormatAmtStr(Msg[XFZE].str, &sVal1, PRTLEN);
				RJPrint(0, SysBuf);

#if(CASE_MFRIC==0)
				icBCD2EcrBCD(&sVal1,(char*)&IC.REC_VALATT[CC_PRGCAR], 5);
				RJPrint(0, FormatAmtStr(Msg[CHZHZE].str, &sVal1, PRTLEN));
#endif

				icBCD2EcrBCD(&sVal1,(char*)&IC.REC_VALATT[CC_NOPER], 2);
				RJPrint(0, FormatQtyStr(Msg[SHYCSHU].str, &sVal1, PRTLEN));
			}

#if(CASE_MFRIC==1)
				icBCD2EcrBCD(&sVal1,(char*)&IC.REC_VALATT[CC_PUNTI], MFRCC_FORE-MFRCC_PUNTI);
#else
			icBCD2EcrBCD(&sVal1,(char*)&IC.REC_VALATT[CC_PUNTI], CC_FORE-CC_PUNTI);
#endif
			if (CheckNotZero(&sVal1))
				RJPrint(0, FormatQtyStr(Msg[XFJIDIAN].str, &sVal1, PRTLEN));

			if (pSel==2){
				memset(SysBuf,' ',PRTLEN);
				CopyFrStr(SysBuf, Msg[JGLBIE].str);
				WORDtoASC(&SysBuf[PRTLEN-1], (IC.REC_Customer[CC_CLIST] & 3)+1);//ccr040809
				SysBuf[PRTLEN] = 0;
				RJPrint(0, SysBuf);
			}

			if (CWORD(IC.REC_Customer[CC_CPERC]) != 0)
			{
				icBCD2EcrBCD(&sVal1,(char*)&IC.REC_Customer[CC_CPERC], 2);
				FormatAmtStr(Msg[ZHKLVF].str, &sVal1, PRTLEN);
				RJPrint(0, SysBuf);
			}

			if (pSel==2){
				memset(SysBuf,' ',PRTLEN);
				CopyFrStr(SysBuf, Msg[ZHKRQI].str);
				SysBuf[PRTLEN-12] = '2';	SysBuf[PRTLEN-12+1] = '0';
				HEXtoASC(SysBuf+PRTLEN-12+2, &IC.REC_INIT[CC_DATAI + 2], 1);
				SysBuf[PRTLEN-12+4] = '-';
				HEXtoASC(SysBuf+PRTLEN-12+5, &IC.REC_INIT[CC_DATAI + 1], 1);
				SysBuf[PRTLEN-12+7] = '-';
				HEXtoASC(SysBuf+PRTLEN-12+8, &IC.REC_INIT[CC_DATAI], 1);
				SysBuf[PRTLEN-1]=0;
				RJPrint(0, SysBuf);

				if (CWORD(IC.REC_Flags[CC_DSCAD]))
				{
					memset(SysBuf,' ',PRTLEN);
					DecodeDateSelf(((WORD)(IC.REC_Flags[1 + CC_DSCAD]) << 8) + IC.REC_Flags[CC_DSCAD], SysBuf+PRTLEN-12);
					SysBuf[PRTLEN-1] = 0;
					CopyFrStr(SysBuf, Msg[KYXQI].str);
					RJPrint(0, SysBuf);
				}

				memset(SysBuf,' ',PRTLEN);
				strncpy(SysBuf+12,&IC.REC_Customer[CC_CNOME],PRTLEN-12);
				SysBuf[PRTLEN-1] = 0;
				CopyFrStr(SysBuf, Msg[KHMCHEN].str);
				RJPrint(0, SysBuf);
			}
			PrintLine('-');
			if (pSel==2)
			{
				RFeed(5);
				PrintHeader();
			}
		}

	}
}

//------------------------------------------------------------------------------
void PayByChipCard(BCD *pValue,BYTE pay)
{
	BCD	newValue;
	BCD	oldValue;

    if (IC.CHIP_Flag>0)
    {
		icBCD2EcrBCD(&newValue, &IC.REC_VALATT[CC_VAL],CC_PRGVEN-CC_VAL);
        switch (IC.CHIP_Flag){
            case IC_TYPE1:
				Subtract(&newValue, pValue);
				if (newValue.Sign & 0x80)
				{
                    ApplVar.ErrorNumber=CWXXI69-CWXXI01+1;
                    return;
				}
#if(CASE_RAMBILL)
				if (pay)
				{
					if (pValue->Sign & 0x80)
						FlowBuff.CDC_refreshic.OpType = 2;
					else
						FlowBuff.CDC_refreshic.OpType = 3;
				}
#endif
                break;
            case IC_TYPE2:
				Add(&newValue, pValue);
				if (newValue.Sign & 0x80)
				{
                    ApplVar.ErrorNumber=CWXXI69-CWXXI01+1;
                    return;
				}
#if(CASE_RAMBILL)
				if (pay)
				{
					if (pValue->Sign & 0x80)
						FlowBuff.CDC_refreshic.OpType = 2;
					else
						FlowBuff.CDC_refreshic.OpType = 3;
				}
#endif
                break;
            default:
                return;
        }
		if (pay)
		{
			EcrBCD2icBCD(&IC.REC_VALATT[CC_VAL], (BCD *)&newValue, CC_PRGVEN-CC_VAL);
#if(CASE_RAMBILL)
			memcpy(FlowBuff.CDC_refreshic.RValue,pValue->Value,sizeof(FlowBuff.CDC_refreshic.RValue));
#endif
			icBCD2EcrBCD(&newValue,&IC.REC_VALATT[CC_PRGVEN],CC_PRGCAR-CC_PRGVEN);
			Add(&newValue, pValue);
			EcrBCD2icBCD(&IC.REC_VALATT[CC_PRGVEN],&newValue, CC_PRGCAR-CC_PRGVEN);

			if (Charge_CHIP()<0)
				ApplVar.ErrorNumber=CWXXI70-CWXXI01+1;
#if(CASE_RAMBILL)
			else
				Collect_Data(REFRESHICLOG);
#endif
		}
    }
}
//------------------------------------------------------------------------------
void PointsByChipCard(BCD *pValue)
{
	BCD	newValue;
	BCD	oldValue;
	BYTE sUpdate;

	if (IC.CHIP_Flag>=0)
	{
		if (BIT(ApplVar.ICCardSet.Options,IC_POINTS))
		{
			memset(&oldValue,0,sizeof(BCD));
			memcpy(oldValue.Value,&ApplVar.ICCardSet.Value,sizeof(ApplVar.ICCardSet.Value));//ccr090311

			memset(&newValue,0,sizeof(BCD));
			memcpy(newValue.Value,&ApplVar.ICCardSet.MiniNum,sizeof(ApplVar.ICCardSet.MiniNum));//ccr090311

			if (CheckNotZero(&oldValue) &&
				CompareBCD(pValue,&newValue)>=0)//ccr090311
			{
				newValue = *pValue;

				Divide(&newValue, &oldValue);

				//ccr090311 trunc BCD>>>>>>>>>>>
				if (newValue.Sign & 1)
					BcdDiv10(&newValue);
				newValue.Sign &= 0x06;
				if (newValue.Sign)
				{
					sUpdate = newValue.Sign/2;
					memcpy(newValue.Value,newValue.Value+sUpdate,BCDLEN-sUpdate);
					memset(newValue.Value+BCDLEN-sUpdate,0,sUpdate);
					newValue.Sign = 0;
				}
				//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#if(CASE_RAMBILL)
				memcpy(FlowBuff.CDC_refreshic.RPoint,newValue.Value,sizeof(FlowBuff.CDC_refreshic.RPoint));
#endif
				icBCD2EcrBCD(&oldValue,&IC.REC_VALATT[CC_PUNTI], CC_FORE-CC_PUNTI);

				Add(&newValue, &oldValue);
				EcrBCD2icBCD(&IC.REC_VALATT[CC_PUNTI],&newValue, CC_FORE-CC_PUNTI);
				SETBIT(IC.ICState,IC_POINTS);
			}
		}
		if (IC.CHIP_Flag==0)
		{//ccr090311,�����ظ�ͳ�ƴ���. ��IC.CHIP_Flag>=0ʱ,Charge_CHIP��PayByChipCard����� //
			icBCD2EcrBCD(&newValue,&IC.REC_VALATT[CC_PRGVEN],CC_PRGCAR-CC_PRGVEN);
			Add(&newValue, pValue);
			EcrBCD2icBCD(&IC.REC_VALATT[CC_PRGVEN],&newValue, CC_PRGCAR-CC_PRGVEN);
			if (Charge_CHIP()<0)
				ApplVar.ErrorNumber=CWXXI70-CWXXI01+1;
		}
	}

}
//---------------------------------------------------------------------------

void ProgClearChip()
{
	BCD	sValue,sCopy;//ccr040809
	BYTE sFore;
	signed char sType;


/*
	if ((IC.ICState & (IC_NOTREMOVED | IC_INSERT))!=(IC_NOTREMOVED | IC_INSERT))
	{//�����γ�������ֹ����   ccr 050316//
		ApplVar.ErrorNumber=CWXXI50-CWXXI01+1;
		return;
	}
*/

    switch (Appl_ProgLine)
    {
	case 1:
		RESETBIT(IC.ICState,IC_FLAG);
		sType = 0;
		for (sFore=0;sFore<CC_PRGVEN-CC_VAL;sFore++)//ccr040809
			if (IC.REC_VALATT[CC_VAL+sFore])
			{
				sType = 1;
				break;
			}
		if (sType)
			strcpy(ProgLineMes, Msg[VALUEINIC].str);
		else
			strcpy(ProgLineMes, Msg[CLEARIC].str);
	    break;
	case 2:
		Appl_MaxEntry = 0;
		Appl_EntryCounter = 0;
		CheckBitValue(QUERENF,&IC.ICState,1,0);
		break;
	case 3:
		if BIT(IC.ICState, IC_FLAG)
		{
			RJPrint(0,Msg[QCHICKA].str);
			PrintChipCard(2);

			sFore = IC.REC_VALATT[CC_FORE];//ccr050316
			sType = IC.CHIP_Flag;
#if (CASE_MFRIC==1)
			if (!CheckCardNo() || Clear_CHIP()!=IC_NEWERR)
#else
			if (Clear_CHIP()!=IC_NEWERR)
#endif
				ApplVar.ErrorNumber=CWXXI64-CWXXI01+1;
			else//ccr040809
			{
				sCopy = ApplVar.Amt;
				if (sFore!=0)
				{
					memset(&ApplVar.Amt,0,sizeof(BCD));
					ApplVar.Amt.Value[1]=sFore;
					ApplVar.Amt.Sign = 0x80;
					ApplVar.PoRaNumber = 4;
					AddPoRaTotal();
					ApplVar.BufCC = 1;AddPoRaTotal();ApplVar.BufCC = 0;//ccr091216

					ApplVar.DrawNumber = 0;
					AddDrawerTotal();
				}
				ApplVar.Amt = sCopy;
			}
		}
		Appl_MaxEntry = ENTRYSIZE-2;
	    Appl_ProgLine = 0;
		IC.ICState &= IC_NOTREMOVED;
		if (ApplVar.CentralLock == (SETUPMG | MG))
		{
			ApplVar.CentralLock = MG;
			strcpy(ProgLineMes,ModeHead);
		}
	    break;
   	}
}

//---------------------------------------------------------------------------

void ProgChargeChip()
{
	BCD	newValue;
	short	i;

/*
	if ((IC.ICState & (IC_NOTREMOVED | IC_INSERT))!=(IC_NOTREMOVED | IC_INSERT))
	{//�����γ�������ֹ����   ccr 050316//
		ApplVar.ErrorNumber=CWXXI50-CWXXI01+1;
		return;
	}
*/

    switch (Appl_ProgLine)
    {
	case 1:
		strcpy(ProgLineMes, Msg[CHARGEIC].str);
		SETBIT(IC.ICState,IC_FLAG + IC_FLAG1);
	    ApplVar.NumberEntered = ZERO;
	    break;
	case 2:
		Appl_MaxEntry = 10;
		Appl_BitNumber = 0;
		GetBCDValue(Line_VALUE,ApplVar.NumberEntered.Value,IC_PRGVEN-IC_VAL,FALSE);
		break;
	case 3:		//	ѡ���ֵ�����˿�  //
		Appl_MaxEntry = 0;
		Appl_EntryCounter = 0;
		CheckBitValue(ItemPrompt77,&IC.ICState,2,0);//IC_FLAG1
		break;
	case 4:
		Appl_MaxEntry = 0;
		Appl_EntryCounter = 0;
		CheckBitValue(QUERENF,&IC.ICState,1,0);
		break;
	case 5:
		if BIT(IC.ICState, IC_FLAG){
			icBCD2EcrBCD(&newValue,&IC.REC_VALATT[CC_VAL],IC_PRGVEN-IC_VAL);

#if(CASE_RAMBILL)
			memcpy(FlowBuff.CDC_refreshic.RValue,ApplVar.NumberEntered.Value,sizeof(FlowBuff.CDC_refreshic.RValue));
#endif
			//if (BIT(IC.ICState, IC_FLAG1) ^ (IC.CHIP_Flag==2))//ccr040809
			if (BIT(IC.ICState, IC_FLAG1))//cc20050817>>>>>>>>>>>>>>>>>>>>>>>>
			{
				if (IC.CHIP_Flag==1)
				{
#if(CASE_RAMBILL)
					FlowBuff.CDC_refreshic.OpType = 4;
#endif
                    Add(&newValue, &ApplVar.NumberEntered);
				}
				else
				{
#if(CASE_RAMBILL)
					FlowBuff.CDC_refreshic.OpType = 3;
#endif
                    if (CompareBCD(&newValue, &ApplVar.NumberEntered)>=0)
				            Subtract(&newValue, &ApplVar.NumberEntered);
                    else
					     ApplVar.ErrorNumber=CWXXI65-CWXXI01+1;
				}
			}
			else
			{
				//if (CompareBCD(&newValue, &ApplVar.NumberEntered)>=0)
				//{
					if (IC.CHIP_Flag==1)
					{
#if(CASE_RAMBILL)
						FlowBuff.CDC_refreshic.OpType = 3;
#endif
                        if (CompareBCD(&newValue, &ApplVar.NumberEntered)>=0)
                            Subtract(&newValue, &ApplVar.NumberEntered);
                        else
		                	ApplVar.ErrorNumber=CWXXI65-CWXXI01+1;
					}
					else
					{
#if(CASE_RAMBILL)
						FlowBuff.CDC_refreshic.OpType = 4;
#endif
					       Add(&newValue, &ApplVar.NumberEntered);
					}
				//}
				//else
				//	ApplVar.ErrorNumber=CWXXI65-CWXXI01+1;
			}
			if (BCDWidth(&newValue)>(IC_PRGVEN-IC_VAL)*2)
				ApplVar.ErrorNumber=CWXXI65-CWXXI01+1;
			if (!ApplVar.ErrorNumber)
			{
				EcrBCD2icBCD(&IC.REC_VALATT[CC_VAL],&newValue, IC_PRGVEN-IC_VAL);
				icBCD2EcrBCD(&newValue,&IC.REC_VALATT[CC_PRGCAR],IC_PRGCAR-IC_PRGVEN);
				if (BIT(IC.ICState, IC_FLAG1))
				{
					i = ICKCHZHI;
					Add(&newValue, &ApplVar.NumberEntered);
				}
				else
				{
					i = ICKTKUAN;
					Subtract(&newValue, &ApplVar.NumberEntered);
				}
				EcrBCD2icBCD(&IC.REC_VALATT[CC_PRGCAR],&newValue, IC_PRGCAR-IC_PRGVEN);

#if (CASE_MFRIC==1)
				if (!CheckCardNo() || Charge_CHIP()<0)
#else
				if (Charge_CHIP()<0)
#endif
					ApplVar.ErrorNumber=CWXXI66-CWXXI01+1;
				else
				{
					newValue = ApplVar.Amt;
					ApplVar.Amt = ApplVar.NumberEntered;
					if (!BIT(IC.ICState, IC_FLAG1))//ccr040809
					{
						ApplVar.Amt.Sign ^= 0x80;
						ApplVar.PoRaNumber = 2;//charge IC
					}
					else
						ApplVar.PoRaNumber = 3;//decrease IC
					AddPoRaTotal();
					ApplVar.BufCC = 1;AddPoRaTotal();ApplVar.BufCC = 0;//ccr091216

					ApplVar.DrawNumber = 0;
					AddDrawerTotal();
					ApplVar.Amt = newValue;

					RJPrint(0, FormatAmtStr(Msg[i].str, &ApplVar.NumberEntered,PRTLEN));
					PrintChipCard(2);
#if(CASE_RAMBILL)
					Collect_Data(REFRESHICLOG);
#endif
				}
			}

		}
		Appl_MaxEntry = ENTRYSIZE-2;
	    Appl_ProgLine = 0;
		IC.ICState &= IC_NOTREMOVED;
		if (ApplVar.CentralLock == (SETUPMG | MG))
		{
			ApplVar.CentralLock = MG;
			strcpy(ProgLineMes,ModeHead);
		}
	    break;
   	}
//
}

void ProgPoints()
{
	BCD	newValue;

/*
	if ((IC.ICState & (IC_NOTREMOVED | IC_INSERT))!=(IC_NOTREMOVED | IC_INSERT))
	{//�����γ�������ֹ����   ccr 050316//
		ApplVar.ErrorNumber=CWXXI50-CWXXI01+1;
		return;
	}
*/
    switch (Appl_ProgLine)
    {
	case 1:
		strcpy(ProgLineMes, Msg[ADPOINTS].str);
		RESETBIT(IC.ICState,IC_FLAG);
		SETBIT(IC.ICState,IC_FLAG1);
	    ApplVar.NumberEntered = ZERO;
	    break;
	case 2:
		Appl_MaxEntry = 6;
		Appl_BitNumber = 0;
		GetBCDValue(Line_POINT,ApplVar.NumberEntered.Value,CC_FORE-CC_PUNTI,TRUE);
		break;
	case 3://	ѡ����㻹���͵�  //
		Appl_MaxEntry = 0;
		Appl_EntryCounter = 0;
		CheckBitValue(ItemPrompt68,&IC.ICState,2,0);//IC_FLAG1
		break;
	case 4:
		Appl_MaxEntry = 0;
		Appl_EntryCounter = 0;
		CheckBitValue(QUERENF,&IC.ICState,1,0);
		break;
	case 5:
		if BIT(IC.ICState, IC_FLAG)
		{
			icBCD2EcrBCD(&newValue,&IC.REC_VALATT[CC_PUNTI], CC_FORE-CC_PUNTI);
			if (!BIT(IC.ICState, IC_FLAG1))
				Add(&newValue, &ApplVar.NumberEntered);
			else
			{
				if (CompareBCD(&newValue, &ApplVar.NumberEntered)>=0)
					Subtract(&newValue, &ApplVar.NumberEntered);
				else
					ApplVar.ErrorNumber=CWXXI65-CWXXI01+1;
			}
			if (BCDWidth(&newValue)>(CC_FORE-CC_PUNTI)*2)
				ApplVar.ErrorNumber=CWXXI65-CWXXI01+1;
			if (!ApplVar.ErrorNumber)
			{
				EcrBCD2icBCD(&IC.REC_VALATT[CC_PUNTI],&newValue, CC_FORE-CC_PUNTI);
#if (CASE_MFRIC==1)
					if (!CheckCardNo() ||  Charge_CHIP()<0)
#else
				if (Charge_CHIP()<0)
#endif
					ApplVar.ErrorNumber=CWXXI58-CWXXI01+1;
			}

		}
		Appl_MaxEntry = ENTRYSIZE-2;
	    Appl_ProgLine = 0;
		IC.ICState &= IC_NOTREMOVED;
		if (ApplVar.CentralLock == (SETUPMG | MG))
		{
			ApplVar.CentralLock = MG;
			strcpy(ProgLineMes,ModeHead);
		}
	    break;
   	}
}
//---------------------------------------------------------------------------
void ProgInitialChip()
{
	WORD	sWord;
	short		sLp,sInt;
    BYTE    CHIP_FSCAD;
	UnLong	sLong;
	BCD		sValue;

/*
	if ((IC.ICState & (IC_NOTREMOVED | IC_INSERT))!=(IC_NOTREMOVED | IC_INSERT))
	{//�����γ�������ֹ����   ccr 050316//
		ApplVar.ErrorNumber=CWXXI50-CWXXI01+1;
		return;
	}
*/

	switch (Appl_ProgLine)  {
       case 1 :
			RESETBIT(ApplVar.ArrowsAlfa,SETCONFIRM);//ccr040809
			strcpy(ProgLineMes, Msg[INITIC].str);
			SETBIT(IC.ICState,IC_FLAG);
		    ApplVar.NumberEntered = ZERO;
			memset(IC.REC_Flags,0,sizeof(IC.REC_Flags)+sizeof(IC.REC_INIT)+sizeof(IC.REC_Customer)+sizeof(IC.REC_VALATT)*2); //"FLAGS" Area
			memset(&IC.REC_Customer[CC_CNOME],'.',19);
			CWORD(IC.CHIP_PSWD) = 0;
			IC.REC_Customer[CC_CLIST] = 1;
    	    break;
       case 2 :   //DES
   	        Appl_MaxEntry = 20;
			SetInputMode('a');
   	        GetString((char*)Prompt.LineCap[2],&IC.REC_Customer[CC_CNOME],20);
   	        break;
       case 3 :   //TYPE
		    Appl_MaxEntry = 1;
		    GetByteValue(Line_TYPE,&IC.REC_INIT[CC_TIPO],2); //0,1,2
		    break;
       case 4 :   //PROT_LEVL
			if (IC.REC_INIT[CC_TIPO]>0)
			{
    	        Appl_MaxEntry = 1;
    	        GetByteValue(Line_PROTOCOL,&IC.REC_INIT[CC_FTIPO],1); //0,1,2
    	        break;
    	    }
    	    else
				Appl_ProgLine = 5;
       case 5 :  //PASSWORD(PIN)
           	if (IC.REC_INIT[CC_FTIPO]>0)//ccr040809
  	       	{
    	        Appl_MaxEntry = 4;
                SETBIT(ApplVar.ArrowsAlfa,INPUTPWD);
                Appl_BitNumber = 0;
                GetBCDValue(Line_PASSWORD,IC.CHIP_PSWD,2,TRUE);
				IC.CHIP_PSWD[2] = 0xff;
				if (Appl_EntryCounter>0)
				{
					Appl_EntryCounter = 0;
					Appl_ProgLine = 6;
				}
				else
	    	        break;
   	       	}
   	       	else
		   		Appl_ProgLine = 7;
       case 6 :  //PASSWORD(PIN)
           	if (IC.REC_INIT[CC_FTIPO]>0 && CWORD(IC.CHIP_PSWD)>0)//ccr040809
  	       	{
    	        Appl_MaxEntry = 4;
                SETBIT(ApplVar.ArrowsAlfa,INPUTPWD+SETCONFIRM); //ccr040809
                Appl_BitNumber = 0;
				sWord = 0;
                GetBCDValue(Line_CONFIRM,(char *)&sWord,2,TRUE);
				if (IC.CHIP_PSWD[2] != 0xff && sWord!=CWORD(IC.CHIP_PSWD))
					ApplVar.ErrorNumber=CWXXI36 - CWXXI01 + 1;
				IC.CHIP_PSWD[2] = 0x00;
				if (Appl_EntryCounter>0 && ApplVar.ErrorNumber==0)
				{
	                RESETBIT(ApplVar.ArrowsAlfa,INPUTPWD+SETCONFIRM); //ccr040809
					Appl_EntryCounter = 0;
					Appl_ProgLine = 7;
				}
				else
	    	        break;
   	       	}
   	       	else
		   		Appl_ProgLine = 7;
       case 7:  //Discount
			RESETBIT(ApplVar.ArrowsAlfa,SETCONFIRM);//ccr040809
   	        Appl_MaxEntry = 6;
   	        Appl_BitNumber = 0;
			icBCD2EcrBCD(&sValue, (char *)&IC.REC_Customer[CC_CPERC],2);
    		GetOpt(40, sValue.Value, 2);
			EcrBCD2icBCD((char *)&IC.REC_Customer[CC_CPERC], &sValue, 2);
   	        break;
       case 8:  //Foregift
   	        Appl_MaxEntry = 2;
   	        Appl_BitNumber = 0;
   	        GetBCDValue(Line_FOREGIFT,&IC.REC_VALATT[CC_FORE],1,TRUE);
   	        break;
       case 9 :   //PriceLevl
   	        Appl_MaxEntry = 1;			//ccr040809
			CHIP_FSCAD = 1;
   	        GetByteValue(Line_PRILEVEL,&CHIP_FSCAD,4);  //0/1/2/3/4
   	        if (CHIP_FSCAD>0)
				CHIP_FSCAD--;
			IC.REC_Customer[CC_CLIST] = CHIP_FSCAD & 0x03;
   	        break;
       case 10:  //Dead
   	        Appl_MaxEntry = 8;//ccr040805>>>>>>>>
			if (Appl_EntryCounter>0 && Appl_EntryCounter!=6 && Appl_EntryCounter!=8)
				ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
			else
			{
	   	        GetBCDValue(Line_DATETO,&IC.REC_Flags[CC_DSCAD],4,TRUE);
				if (Appl_EntryCounter>0)
				{
				    if (IC.REC_Flags[CC_DSCAD+3]<0x20)
						IC.REC_Flags[CC_DSCAD+3]=0x20;
					if (IC.REC_Flags[CC_DSCAD]==0 || IC.REC_Flags[CC_DSCAD]>0x31 ||
						IC.REC_Flags[CC_DSCAD+1]==0 || IC.REC_Flags[CC_DSCAD+1]>0x12)
						ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
				}
			}								//ccr040805<<<<<<<
   	        break;
       case 11:
			Appl_MaxEntry = 0;
			Appl_EntryCounter = 0;
			CheckBitValue(QUERENF,&IC.ICState,1,0);
   	       	break;
       case 12:
	   		if BIT(IC.ICState, IC_FLAG)
   			{
				IC.REC_Flags[CC_VERG1] = 0x55;
				IC.REC_Flags[CC_VERG2] = 0x55;
				sLong = BCDValueToULong(&IC.REC_Flags[CC_DSCAD], 4);

		        if (sLong>0)
		       	{
		          CHIP_FSCAD = 1;
		          sWord = (sLong / 10000);
				  if (sWord<2000)
				  	sWord += 2000;
				  sWord-=1992;
		          sWord = (sWord<<9) + (((sLong % 10000)/100)<<5) + (sLong % 100);
		       	}
		        else
		       	{
		          CHIP_FSCAD = 0;
		          sWord = 0;
		        }
		        IC.REC_Flags[CC_DSCAD] = sWord & 0xFF;
		        IC.REC_Flags[CC_DSCAD + 1] = (sWord>>8);

		          //Create INIT area

		        IC.REC_INIT[CC_FTIPO] |= (CHIP_FSCAD<<FLT0_Scad); //set the protection level and expiration

		        sLong = ApplVar.ICCardSet.PosCode;
		        for (sLp = CC_CODPOS;sLp<=CC_CODPOS + 3;sLp++)
		       	{
		          IC.REC_INIT[sLp] = sLong & 0xFF;
		          sLong >>= 8;
		       	}

				//Set date ICCard created
		        IC.REC_INIT[CC_DATAI + 2] = Now.year; //BCD for year;
		        IC.REC_INIT[CC_DATAI + 1] = Now.month; //BCD for ApplVar.Month;
		        IC.REC_INIT[CC_DATAI] = Now.day; //BCD for ApplVar.Day;

		        IC.REC_INIT[CC_ECR] = 0; //
		        IC.REC_INIT[CC_ECRSW] = 0x10; //Set ECR version

				sWord = BCDValueToULong(IC.CHIP_PSWD, 2);
		        IC.REC_INIT[CC_PINL] = sWord & 0xFF; //set PIN-L (olny if Protection= 0 or 1)
		        IC.REC_INIT[CC_PINH] = (sWord >> 8); //set PIN-H (olny if Protection= 0 or 1)


		        IC.REC_INIT[CC_AUTOC] = 0; //set #function of automatic closing

                IC.CHIP_TIPO=IC.REC_INIT[CC_TIPO];
                IC.CHIP_FTIPO=IC.REC_INIT[CC_FTIPO];
                IC.CHIP_PROT=IC.CHIP_FTIPO&3; //Set the protection type

		          //Create Cutomer area
//		        for (sLp = CC_CCF;sLp<=CC_CCOD - CC_CCF - 1;sLp++) //Clear
//			          IC.REC_Customer[sLp] = sLp+'0'; //' '

#if (CASE_MFRIC==1)
				if (!CheckCardNo() || Initial_CHIP()<0)
#else
				if (Initial_CHIP()<0)
#endif
					ApplVar.ErrorNumber=CWXXI67-CWXXI01+1;
				else
				{
					if (IC.REC_VALATT[CC_FORE]!=0)//ccr040809
					{
						sValue = ApplVar.Amt;
						memset(&ApplVar.Amt,0,sizeof(BCD));
						ApplVar.Amt.Value[1]=IC.REC_VALATT[CC_FORE];
						ApplVar.PoRaNumber = 5;
						AddPoRaTotal();
						ApplVar.BufCC = 1;AddPoRaTotal();ApplVar.BufCC = 0;//ccr091216

						ApplVar.DrawNumber = 0;
						AddDrawerTotal();
						ApplVar.Amt = sValue;
					}
						PrintChipCard(2);
				}
   			}
			Appl_MaxEntry = ENTRYSIZE-2;
		    Appl_ProgLine = 0;
			IC.ICState &= IC_NOTREMOVED;
			if (ApplVar.CentralLock == (SETUPMG | MG))
			{
				ApplVar.CentralLock = MG;
				strcpy(ProgLineMes,ModeHead);
			}
		    break;
	}
}
//---------------------------------------------------------------------------
//---------------------------------------------------------------------------
//cc 2007-01-30 for MFRIC>>>>>>>>>>>>>>
#if(CASE_MFRIC==1)
BYTE MFRToIC(short pSel)
{
	BYTE sMFR_VALATT[MFRCC_CRCVAL+1],sMFR_VALPRE[MFRCC_CRCVAL+1];
	short sBx;
	if(pSel == RW_Factory || pSel == RW_ALL)
	{
		memset(IC.REC_Factory,0xff,sizeof(IC.REC_Factory));
		CLONG(IC.REC_Factory[CC_SERIE])=CLONG(IC.MFR_Factory[MFRCC_SERIE]);//ccr090310,SERIELEN);

		CLONG(IC.REC_Factory[CC_PATT])=CLONG(IC.MFR_Factory[MFRCC_PATT]);//ccr090310,PATTLEN);
		CWORD(IC.REC_Factory[CC_PATT+4])=CWORD(IC.MFR_Factory[MFRCC_PATT+4]);//ccr090310,PATTLEN);
	}
	if(pSel == RW_Flags || pSel == RW_ALL)
	{
		memset(IC.REC_Flags,0xff,sizeof(IC.REC_Flags));
		IC.REC_Flags[CC_AGGINIZ] = IC.MFR_Factory[MFRCC_AGGINIZ];
		IC.REC_Flags[CC_AGGVAL] = IC.MFR_Factory[MFRCC_AGGVAL];
		CWORD(IC.REC_Flags[CC_DSCAD])=CWORD(IC.MFR_Factory[MFRCC_DSCAD]);//ccr090310,DSCADLEN);
	}
	if(pSel == RW_Init || pSel == RW_ALL)
	{
		SCC_Cript(IC.MFR_INIT,16); //Decode of INIT record
		if(IC.MFR_INIT[MFRCC_CRCINIT] != SCC_Ccrc(IC.MFR_INIT,sizeof(IC.MFR_INIT)-1))
              	return 0;
		memset(IC.REC_INIT,0xff,sizeof(IC.REC_INIT));
		IC.REC_INIT[CC_TIPO] = IC.MFR_INIT[MFRCC_TIPO];
		IC.REC_INIT[CC_FTIPO] = IC.MFR_INIT[MFRCC_FTIPO];
		CWORD(IC.REC_INIT[CC_DATAI])=CWORD(IC.MFR_INIT[MFRCC_DATAI]);//ccr090310,DATAILEN);
		IC.REC_INIT[CC_DATAI+2]=IC.MFR_INIT[MFRCC_DATAI+2];//ccr090310,DATAILEN);
		IC.REC_INIT[CC_ECR] = IC.MFR_INIT[MFRCC_ECR];
		IC.REC_INIT[CC_ECRSW] = IC.MFR_INIT[MFRCC_ECRSW];
		CLONG(IC.REC_INIT[CC_CODPOS])=CLONG(IC.MFR_INIT[MFRCC_CODPOS]);//ccr090310,CODPOSLEN);
		IC.REC_INIT[CC_PINH] = IC.MFR_INIT[MFRCC_PINH];
		CWORD(IC.REC_INIT[CC_AUTOC])=CWORD(IC.MFR_INIT[MFRCC_AUTOC]);//ccr090310,AUTOCLEN);
		IC.REC_INIT[CC_PINL] = IC.MFR_INIT[MFRCC_PINL];
	}
	if(pSel == RW_Customer || pSel == RW_ALL)
	{
		SCC_Cript(IC.MFR_Customer,32); //Decode of Customer Area
		if(IC.MFR_Customer[MFRCC_CRCCLI] != SCC_Ccrc(IC.MFR_Customer,sizeof(IC.MFR_Customer)-1))
              	return 0;
		memset(IC.REC_Customer,0xff,sizeof(IC.REC_Customer));
		CWORD(IC.REC_Customer[CC_CPERC])=CWORD(IC.MFR_Customer[MFRCC_CPERC]);//ccr090310,CPERCLEN);
		CWORD(IC.REC_Customer[CC_CLIST])=CWORD(IC.MFR_Customer[MFRCC_CLIST]);//ccr090310,CLISTLEN);
		memcpy(&IC.REC_Customer[CC_CNOME],&IC.MFR_Customer[MFRCC_CNOME],CNOMELEN);
	}
	if(pSel == RW_Valatt || pSel == RW_ALL)
	{
		memcpy(sMFR_VALATT,IC.MFR_VALATT,sizeof(IC.MFR_VALATT));
		memcpy(sMFR_VALPRE,IC.MFR_VALPRE,sizeof(IC.MFR_VALPRE));

		sBx = IC.CriptCnt;
		SCC_Cript(IC.MFR_VALATT,sizeof(IC.MFR_VALATT));
		if(SCC_Ccrc(IC.MFR_VALATT,sizeof(IC.MFR_VALATT)-2) != IC.MFR_VALATT[MFRCC_CRCVAL])//checksum of charge-value field
		{
			memcpy(IC.MFR_VALATT,IC.MFR_VALPRE,sizeof(IC.MFR_VALATT));
			CC_WriteMFR(sMFR_VALPRE,RW_Valatt);
//			return 0;
		}
		IC.CriptCnt = sBx;
		SCC_Cript(IC.MFR_VALPRE,sizeof(IC.MFR_VALPRE));
		if(SCC_Ccrc(IC.MFR_VALPRE,sizeof(IC.MFR_VALPRE)-2) != IC.MFR_VALPRE[MFRCC_CRCVAL])//checksum of charge-value field
		{
			memcpy(IC.MFR_VALPRE,IC.MFR_VALATT,sizeof(IC.MFR_VALATT));
			CC_WriteMFR(sMFR_VALATT,RW_Valpre);
//			return 0;
		}
		if(memcmp(IC.MFR_VALATT,IC.MFR_VALPRE,sizeof(IC.MFR_VALATT)))
		{
			if(IC.MFR_Factory[MFRCC_AGGVAL] == 0x55)
			{
				memcpy(IC.MFR_VALATT,IC.MFR_VALPRE,sizeof(IC.MFR_VALATT));
				CC_WriteMFR(sMFR_VALPRE,RW_Valatt);
			}
			else
			{
				memcpy(IC.MFR_VALPRE,IC.MFR_VALATT,sizeof(IC.MFR_VALATT));
				CC_WriteMFR(sMFR_VALATT,RW_Valpre);
			}
		}
		memset(IC.REC_VALATT,0,sizeof(IC.REC_VALATT));

		CWORD(IC.REC_VALATT[CC_NOPER])=CWORD(IC.MFR_VALATT[MFRCC_NOPER]);//ccr090310,,NOPERLEN);

		CLONG(IC.REC_VALATT[CC_VAL+1])=CLONG(IC.MFR_VALATT[MFRCC_VAL]);//ccr090310,,VALLEN);
		CLONG(IC.REC_VALATT[CC_PRGVEN+1])=CLONG(IC.MFR_VALATT[MFRCC_PRGVEN]);//ccr090310,PRGVENLEN);

		CWORD(IC.REC_VALATT[CC_PUNTI]) = CWORD(IC.MFR_VALATT[MFRCC_PUNTI]);//ccr090310,PUNTILEN
		IC.REC_VALATT[CC_PUNTI+2] = IC.MFR_VALATT[MFRCC_PUNTI+2];//ccr090310,PUNTILEN
		IC.REC_VALATT[CC_FORE] = IC.MFR_VALATT[MFRCC_FORE];
		IC.REC_VALATT[CC_ICTYPE] = IC.MFR_VALATT[MFRCC_ICTYPE];
	}

	return 1;
}
//------------------------------------------------------------------------
void ICToMFR(short pSel)
{
	if(pSel == RW_Flags || pSel == RW_ALL)
	{
		IC.MFR_Factory[MFRCC_AGGINIZ] = IC.REC_Flags[CC_AGGINIZ];
		IC.MFR_Factory[MFRCC_AGGVAL] = IC.REC_Flags[CC_AGGVAL];
		CWORD(IC.MFR_Factory[MFRCC_DSCAD])=CWORD(IC.REC_Flags[CC_DSCAD]);//ccr090310,DSCADLEN);
	}
	if(pSel == RW_Init || pSel == RW_ALL)
	{
		IC.MFR_INIT[MFRCC_TIPO] = IC.REC_INIT[CC_TIPO];
		IC.MFR_INIT[MFRCC_FTIPO] = IC.REC_INIT[CC_FTIPO];
		CWORD(IC.MFR_INIT[MFRCC_DATAI])=CWORD(IC.REC_INIT[CC_DATAI]);//ccr090310,DATAILEN);
		IC.MFR_INIT[MFRCC_DATAI+2]=IC.REC_INIT[CC_DATAI+2];//ccr090310,DATAILEN);
		IC.MFR_INIT[MFRCC_ECR] = IC.REC_INIT[CC_ECR];
		IC.MFR_INIT[MFRCC_ECRSW] = IC.REC_INIT[CC_ECRSW];
		CLONG(IC.MFR_INIT[MFRCC_CODPOS])=CLONG(IC.REC_INIT[CC_CODPOS]);//ccr090310,CODPOSLEN);
		IC.MFR_INIT[MFRCC_PINH] = IC.REC_INIT[CC_PINH];
		CWORD(IC.MFR_INIT[MFRCC_AUTOC])=CWORD(IC.REC_INIT[CC_AUTOC]);//ccr090310,AUTOCLEN);
		IC.MFR_INIT[MFRCC_PINL] = IC.REC_INIT[CC_PINL];
		IC.MFR_INIT[MFRCC_CRCINIT] = SCC_Ccrc(IC.MFR_INIT,sizeof(IC.MFR_INIT)-1);
		SCC_Cript(IC.MFR_INIT,16); //Decode of INIT record
	}
	if(pSel == RW_Customer || pSel == RW_ALL)
	{
		CWORD(IC.MFR_Customer[MFRCC_CPERC])=CWORD(IC.REC_Customer[CC_CPERC]);//ccr090310,CPERCLEN);
		CWORD(IC.MFR_Customer[MFRCC_CLIST])=CWORD(IC.REC_Customer[CC_CLIST]);//ccr090310,,CLISTLEN);
		memcpy(&IC.MFR_Customer[MFRCC_CNOME],&IC.REC_Customer[CC_CNOME],CNOMELEN);
		IC.MFR_Customer[MFRCC_CRCCLI] = SCC_Ccrc(IC.MFR_Customer,sizeof(IC.MFR_Customer)-1);
		SCC_Cript(IC.MFR_Customer,32); //Decode of Customer Area
	}
	if(pSel == RW_Valatt || pSel == RW_ALL)
	{
		CWORD(IC.MFR_VALATT[MFRCC_NOPER])=CWORD(IC.REC_VALATT[CC_NOPER]);//ccr090310,NOPERLEN);

		CLONG(IC.MFR_VALATT[MFRCC_VAL])=CLONG(IC.REC_VALATT[CC_VAL+1]);//ccr090310,VALLEN);
		CLONG(IC.MFR_VALATT[MFRCC_PRGVEN])=CLONG(IC.REC_VALATT[CC_PRGVEN+1]);//ccr090310,PRGVENLEN);

		CWORD(IC.MFR_VALATT[MFRCC_PUNTI])=CWORD(IC.REC_VALATT[CC_PUNTI]);//ccr090310,PUNTILEN);
		IC.MFR_VALATT[MFRCC_PUNTI+2] = IC.REC_VALATT[CC_PUNTI+2];
		IC.MFR_VALATT[MFRCC_FORE] = IC.REC_VALATT[CC_FORE];
		IC.MFR_VALATT[MFRCC_ICTYPE] = IC.REC_VALATT[CC_ICTYPE];
		IC.MFR_VALATT[MFRCC_CRCVAL] = SCC_Ccrc(IC.MFR_VALATT,sizeof(IC.MFR_VALATT)-2);
		SCC_Cript(IC.MFR_VALATT,sizeof(IC.MFR_VALATT));
	}
}
#endif
#endif
