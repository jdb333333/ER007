#define TIMER_C	1
#include "king.h"				/* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
#include "fiscal.h"


/********************************************************************
 *
 * @author EutronSoftware (2017-06-15)
 *
 * @param sSour :Ϊϵͳ��ʽ����(BCD��),��������
 * @param sDest :Ϊѹ��������
 * @param sTime[3] :ΪBCDʱ��,���ֽ�,��:0x235959;sTime=nullʱ,���Ƚ�ʱ��
 *
 * @return short :=1,����һ��;=0,ͬһ��;=-1,ǰһ��
 *********************************************************************/
short CompDateTime(struct TimeDate *sSour,WORD sDest,char *sTime)
{
    short ret;

    WORD sWord;
    ULONG timeS,timeD;

    sWord = EncordBCDDate(sSour->year & 0xff, sSour->month, sSour->day);

    if (sWord > sDest)
        ret = 1;
    else if (sWord == sDest)
        ret = 0;
    else
        ret = -1;
    if (!sTime && !ret)
    {//ͬһ��ʱ,�ٱȽ�ʱ��
        timeS=(ULONG)sSour->hour*10000+(ULONG)sSour->min*100+sSour->sec;
        timeD=(ULONG)sTime[0]*10000+(ULONG)sTime[1]*100+sTime[2];
        if (timeS > timeD)
            ret = 1;
        else if (timeS == timeD)
            ret = 0;
        else
            ret = -1;
    }
    return ret;
}


/***************************************************************/
//pAll==true,ǿ�ƽ�������ʱ��ת��
//pAll bit7=1,����ȡ����ʱ��,ֱ��ʹ��Now����ת��
//InActive bit7=1,��ʾ����;=0,��ʾʱ��
void CheckTime(BYTE pAll)
{
    short  d;
    BYTE t,sBuf[16];
    static BYTE day,min,sec;

    if (ApplVar.FRegi==0 || pAll)   /*    in transaction ?     */
    {
        GetTimeDate(&Now);  /*    read timer     */
        if (pAll & 0x7f)
            day=min=sec=0xff;

        if (sec == Now.sec)
            return;

        sec = Now.sec;
        t = Now.hour;

        if (BIT(AM_PM, BIT0))   /* AM-PM */
        {
            //hh:mm:ssP
            if (Now.hour > 0x11)
                TimeAsci[8] = 'P';
            else
                TimeAsci[8] = 'A';
            if (Now.hour == 0x20 || Now.hour == 0x21)
                t -= 0x18;
            else if (Now.hour > 0x12)
                t -= 0x12;
            else if (!Now.hour)
                t = 0x12;
        }
        else
            TimeAsci[8] = ' ';
        TimeAsci[0] = (t >> 4)+'0';
        TimeAsci[1] = (t & 0xf)+'0';
        TimeAsci[2] = ':';
        TimeAsci[3] = (Now.min >> 4)+'0';
        TimeAsci[4] = (Now.min & 0x0f)+'0';
        TimeAsci[5] = ':';      /* use '-' for MA  numeric display */
        TimeAsci[6] = (Now.sec >> 4)+'0';
        TimeAsci[7] = (Now.sec & 0xf)+'0';
        TimeAsci[9] = 0;
//ccr2017-12-18    #if defined(FISCAL)
//ccr2017-12-18        if ((ApplVar.FiscalFlags == FISCALOK || ApplVar.FiscalFlags == FMLESS || ApplVar.FiscalFlags == EJLESS)
//ccr2017-12-18            && ApplVar.ZReport != 1
//ccr2017-12-18            && CompDateTime(&Now, ApplVar.FisNumber.LastZDate,0)!=0)
//ccr2017-12-18        {
//ccr2017-12-18                ApplVar.ZReport = 2;    /* �����,���ñ����ӡZ������־ */
//ccr2017-12-18        }
//ccr2017-12-18    #endif

        if (day != Now.day)
        {

            day = Now.day;
            MemSet(DateAsci, sizeof(DateAsci), ' ');
            CLONG(DateAsci)=CLONG(Prompt.DayCap[Now.dow-1]);        /* ApplVar.Day of week */
            DateAsci[3]=',';
            d = 4;            /* default"mon,DD MM YYYY" */
            if (TIME_DATE == 1)          /*"mon,MM DD YYYY" */
                d = 7;
            else if (TIME_DATE == 2)     /*"mon,YYYY MM DD" */
                d = 12;
            DateAsci[d] = (Now.day>>4)+'0';
            DateAsci[d+1] = (Now.day & 0x0f)+'0';
            if (d>4)
                DateAsci[d-1]=DATECHAR;

            Now.year &= 0x00ff;
            Now.year |= 0x2000;

            t = Now.month;
            if (Now.month > 9)
                t -= 7;
            else
                t--;

            d = 7;                   /* default"mon,DD MM YYYY" */
            if (TIME_DATE == 1)          /*"mon,MM DD YYYY" */
                d = 4;
            else if (TIME_DATE == 2)     /*"mon,YYYY MM DD" */
                d = 9;

            DateAsci[d] = (Now.month>>4)+'0';
            DateAsci[d+1] = (Now.month & 0x0f)+'0';
            if (d>4)
                DateAsci[d-1]=DATECHAR;

            d = 10;                   /* default"mon,DD MM YYYY" */
            if (TIME_DATE == 2)     /*"mon,YYYY MM DD" */
                d = 4;

            if (d>4)
                DateAsci[d-1]=DATECHAR;

            DateAsci[d++] = (Now.year>>12)+'0';
            DateAsci[d++] = ((Now.year>>8) & 0x0f)+'0';
            DateAsci[d++] = ((Now.year>>4) & 0x0f)+'0';
            DateAsci[d++] = (Now.year & 0x0f)+'0';
        }
        //ccr2014-10-29>>>>
        if (ApplVar.CentralLock == SET && Appl_ProgType==SETTIME && Appl_ProgLine==1 && Appl_EntryCounter==0)
        {//��������ʱ��ʱ,�ڵ�һ����ʾ��ǰʱ��
            sBuf[0]=0x20;
            sBuf[1]=0x20;
            strcpy(sBuf+2,TimeAsci);
            PutsO(sBuf);
        }//<<<<<<<<<<<<<<<<<
        else if (ACTIVE && InActive > ACTIVE)
        //		|| ApplVar.CentralLock == SET || ApplVar.CentralLock == Z || ApplVar.CentralLock == X)     /* Inactive longer then allowed */
        {// ��ʾʱ��
    #if !defined(DEBUGBYPC)
            if (!ApplVar.LCD_Operator[0])
                Copy_LCD(true);//ccr20130308
    #endif
    //testonly		if (!(pAll & 0x80))		LightLCD(0);
            memset(sBuf,' ',sizeof(sBuf));
            sBuf[15]=0;
    #if (DISLEN>13)
            if (TIME_DATE == 2)     /*   "mon,YYYY MM DD"     */
                memcpy(sBuf+1,DateAsci+9,5);
            else
                memcpy(sBuf+1,DateAsci+4,5);
            memcpy(sBuf+7, TimeAsci, 8);
    #else
            if (InActive & 0x80)
                memcpy(sBuf+1, DateAsci+4, 10);
            else
                memcpy(sBuf+2, TimeAsci, 8);
    #endif
    #if(DD_ZIP==1)
            if (!Appl_ProgType)
            {
                PutsO(DateAsci);
                Puts1(TimeAsci);
            }
    #elif (DD_ZIP_21==1)
            if (!Appl_ProgType)
            {
                PutsO(DateAsci);
                sBuf[0]=sBuf[1]=sBuf[2]=sBuf[3]=0x20;
                for (t=0;t<12;t++)
                {
                    sBuf[4+t]=TimeAsci[t];
                }
                Puts1(sBuf);    /*   ��������    */
                PutsC(sBuf+2);  /*     ����ʾ    */
            }
    #else
            PutsO(sBuf);
    #endif
    #if (defined(FOR_DEBUG) && !defined(DEBUGBYPC))
    //        //ccr2017-09-30>>>>>>>>>>>>>>>>����͹���ģʽ>>>>
    //        if (ApplVar.CentralLock != SET || Appl_ProgType!=SETTIME)
    //        {
    //            Save_ConfigVar(true);//ccr2016-01-15
    //
    //            EnterSTOP();
    //            InActive=0;
    //        }
    //        //ccr2017-09-30<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    #endif
        }
        else if (min != Now.min)
        {
            min = Now.min;
            if ((InActive & 0x7f)<0x70)
                InActive++;
        }
        if (BIT(AM_PM, BIT0))   /*AM-PM */
        {
            TimeAsci[5] = ' ';
            TimeAsci[6] = TimeAsci[8];
            TimeAsci[7] = 'M';
            TimeAsci[8] = 0;
        }
    #if (DD_ZIP_21==1 || DD_LCD_1601==1)
        if ( ((ApplVar.CentralLock!=RG)&&(ApplVar.CentralLock!=MG)) )
        {
            sBuf[0]=0x20;
            sBuf[1]=0x20;
            for (t=0;t<12;t++)
            {
                sBuf[2+t]=TimeAsci[t];
            }
            PutsC(sBuf);
        }
    #endif
    }
}

/* set up correct hour, day and month pointer */

void GetTimeZones()
{
    WORD now;

    now = (Now.hour * 0x0100) + Now.min;
    if (ApplVar.AP.Zone.Number)
        ApplVar.Zone = ApplVar.AP.Zone.Number - 1;
    else
        ApplVar.Zone = 0;
    while (ApplVar.Zone)
    {
        if (now < ApplVar.AP.Zone.Start[ApplVar.Zone])
            ApplVar.Zone--;
        else
            break;
    }
    ApplVar.Day = Now.dow;
    if (ApplVar.Day >= ApplVar.AP.Day.Number)
        ApplVar.Day = 0;
    /* used for salesperson */
    ApplVar.Month = Now.month;
    if (ApplVar.Month > 9)
        ApplVar.Month -= 6;
    if (ApplVar.Month > ApplVar.AP.Month.Number)
        ApplVar.Month = 0;
    else
        ApplVar.Month--;

}

/******************************************************

//  ��С����������  //
//  ������µ��������� //

******************************************************/

BYTE  GetMonthMaxDay(BYTE  tyear,BYTE  tmonth)
{
    short iyear;

    switch (tmonth)
    {
    case 2:
        {
            iyear=2000+(tyear/16)*10+tyear%16;
            if ((!(iyear%4) && (iyear%100)) || !(iyear%400))
                return 0x29;
            else
                return 0x28;
        }
    case 4:
    case 6:
    case 9:
    case 11:
        return 0x30;
    default:
        return 0x31;
    }

}
/**********************************************************************************
 * Set date and time
 *
 * @author EutronSoftware (2017-08-11)
 *
 * @param type & 0x0f:=1,ʹ��EntryBuffer�е���������Now�е���������
 *                    =2,ʹ��EntryBuffer�е���������Now�е�ʱ������
 *                    =3,ʹ��ApplVar.Entry����������Now�е���������
 *        type & 0xf0:=0x1*,����������ʱ��,��ϵͳʱ���EntryBuff�������ʱ�����Now
 *                    =0x0*,ʹ��Now�е�������������/ʱ��,��������ʾ����ʱ��
 *                    =0xf*,����ȡϵͳ���ں�ʱ��
 *********************************************************************************/
void NewTimeDate(BYTE type)
{
    short i;
    struct TimeDate   tempdate;
    WORD sWord,dWord;

    if ((type & 0xf0)!=0xf0)
        GetTimeDate(&Now);      /* restore old values */
    tempdate = Now;
    if ((type & 0x0f) != 3)
        StrToBCDValue(ApplVar.Entry.Value, &EntryBuffer[ENTRYSIZE - 2], BCDLEN);

    if ((type & 0x0f) == 1)   /* set date */
    {//Format for date string:'wddmmyyyy' or 'wmmddyyyy' or 'wyyyymmdd'
//liuj 0728
        if (Appl_EntryCounter != 9 && Appl_EntryCounter != 8 && Appl_EntryCounter != 4)
            ApplVar.ErrorNumber=ERROR_ID(CWXXI02);
        if (Appl_EntryCounter != 4)
        {
            if (TIME_DATE == 2)     /*wYYYYMMDD */
                Now.year = ((WORD)ApplVar.Entry.Value[3] << 8) |  ApplVar.Entry.Value[2];
            else           /*wMMDDYYYY or wDDMMYYYY*/
                Now.year = ((WORD)ApplVar.Entry.Value[1] << 8) | ApplVar.Entry.Value[0];
        }
        if (TIME_DATE == 1)     /*wMMDDYYYY */
        {
            if (Appl_EntryCounter == 4)
            {
                Now.month = ApplVar.Entry.Value[1];
                Now.day = ApplVar.Entry.Value[0];
            }
            else
            {
                Now.month = ApplVar.Entry.Value[3];
                Now.day = ApplVar.Entry.Value[2];
            }
        }
        else if (TIME_DATE == 2)     /*wYYYYMMDD*/
        {
            Now.month = ApplVar.Entry.Value[1];
            Now.day = ApplVar.Entry.Value[0];
        }
        else                            /*wDDMMYYYY */
        {
            if (Appl_EntryCounter == 4)
            {
                Now.month = ApplVar.Entry.Value[0];
                Now.day = ApplVar.Entry.Value[1];
            }
            else
            {
                Now.day = ApplVar.Entry.Value[3];
                Now.month = ApplVar.Entry.Value[2];
            }
        }
        if (Now.month > 0x12 )
            ApplVar.ErrorNumber=ERROR_ID(CWXXI02);
        else        //liuj 0621
        {
            if (Now.day > GetMonthMaxDay( Now.year & 0xff, Now.month))
                ApplVar.ErrorNumber=ERROR_ID(CWXXI02);
        }

        if (Appl_EntryCounter == 9)
            Now.dow = ApplVar.Entry.Value[4] - 1;
        else
            Now.dow = 0x10;
        if (type<0x0f)
            InActive = 0x80 + ACTIVE + 1;
    }
    else if ((type & 0x0f) == 2)//Set time
    {
        switch (Appl_EntryCounter)
        {
        case 3:
        case 4:
        case 5:
            i = 2;
            Now.sec = 0;
            Now.min = ApplVar.Entry.Value[0];
            Now.hour = ApplVar.Entry.Value[1];
            break;
        case 6:
        case 7:
            Now.sec = ApplVar.Entry.Value[0];
            Now.min = ApplVar.Entry.Value[1];
            Now.hour = ApplVar.Entry.Value[2];
            i = 3;
            break;
        default:
            ApplVar.ErrorNumber=ERROR_ID(CWXXI03);
        }
        if (BIT(AM_PM, BIT0))     /* am - pm */
        {
            if (!Now.hour || Now.hour > 0x12)        /* hour must be 1 - 12 */
                ApplVar.ErrorNumber=ERROR_ID(CWXXI03);
            else if (ApplVar.Entry.Value[i] && ApplVar.Entry.Value[i] != 0x01)
                ApplVar.ErrorNumber=ERROR_ID(CWXXI03);
            else if (Now.hour == 0x12)
            {
                if (!ApplVar.Entry.Value[i])
                    Now.hour = 0;
            }
            else if (ApplVar.Entry.Value[i])
            {
                if (Now.hour == 0x08 || Now.hour == 0x09)
                    Now.hour += 0x18;
                else
                    Now.hour += 0x12;
            }
        }
        else if (Now.hour > 0x23)
            ApplVar.ErrorNumber=ERROR_ID(CWXXI03);
        if (Now.min > 0x59 || Now.sec > 0x59)
            ApplVar.ErrorNumber=ERROR_ID(CWXXI03);
        if ((type & 0xf0)==0)//Ϊ��������ʱ��
            InActive = ACTIVE + 1;
    }
//liuj 0731
    if (!ApplVar.ErrorNumber && ((type & 0xf0)==0))//Ϊ��������ʱ��
    {
#if defined(FISCAL)
        if (ApplVar.FiscalFlags == FISCALOK)
        {//��˰�س�ʼ��֮��,�����ڲ���С��������
            sWord = EncordBCDDate(tempdate.year & 0xff, tempdate.month, tempdate.day);
            dWord = EncordBCDDate(Now.year & 0xff, Now.month, Now.day);
            if (sWord>dWord)
                ApplVar.ErrorNumber=ERROR_ID(CWXXI02);
        }
        if (!ApplVar.ErrorNumber)
#endif
            SetTimeDate(&Now);
//     Now.sec--;     Now.day--;
    }
}
/********ͨ������������ *************************************************
�����2010��12��05�������ڼ������� uchar   year,month,day;
            year=0x10;     //��ݣ�10��
            month=0x12;     //�·ݣ�12��
            day=0x05;     //�գ�    05��
������Ϊ��week1=GetWeekDay((year>>4)*10+(year&0x0f)+2000,
                           (month>>4)*10+(month&0x0f),
                           (day>>4)*10+(day&0x0f));
***********************************************************************/

CONST BYTE Month_Day[12]={31,28,31,30,31,30,31,31,30,31,30,31};

BYTE DaysAMonth(WORD y,BYTE m)  //���ĳ��ĳ���ж�����
{
       if(m==2)
          return(((y%4 == 0) && (y%100 != 0) || (y%400 == 0))? 29: 28);
       else
          return(Month_Day[m-1]);
}
//************************************************
//����ĳ��ĳ��ĳ�������ڼ���1900�꿪ʼ��
//1-����һ,...,6-������,7-������
//year, month, day ��ΪBCD����
BYTE GetWeekDay(WORD year,BYTE month,BYTE day)
{
    long nday=0;
    WORD i;



    year = BCD4toWORD(year);
    month = BCDtoDEC(month);
    day = BCDtoDEC(day);

    if (year<1900) year+=2000;

    for (i=1900;i<year;i++)
         nday +=((((i%4 == 0) && (i%100 != 0) || (i%400 == 0))? 366: 365));
    for (i=1;i<month;i++)
         nday+=DaysAMonth(year,i);
    nday = (nday + day)%7;
	if (nday==0) nday = 7;

//    nday--;

    return(nday);
}
