#define EJOURNAL_C
#include "king.h"
#include "exthead.h"
#include "exth.h"
#include "flowbill.h"
#include "fiscal.h"
#include "ejournal.h"
#include "message.h"

#ifdef CASE_FATFS_EJ
#include "RFC_SHA1.h"
#include "SDDisk_Utilities.h"
#include "AES256.h"

#if !defined(DEBUGBYPC)
#include "interface.h"
#include "httpClient.h"
#include "Ethernet_app.h"
#endif

#if (PC_EMUKEY==1)
    #include "FEcrTest.h"
#endif

//ccr2017-04-25>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
//���ڶ�дSD���ļ����ݵĻ�����
//��InitApplication�н�ʹ��SDRW_Buffer���ָ�����ÿһ�α��붨���㹻��Ŀռ�
BYTE SDRW_Buffer[SD_BLOCKSIZE*2];

#if defined(CASE_GREECE)//ccr2018-01-08�����վݼ���SHA1ǩ��
static char LASTD_ALLE[]= "1:/LASTD_Es.tmp";   //���һ��D.txt�����е�E.txt�ļ�ASED
static char LASTC_ALLB[]= "1:/LASTC_Bs.tmp";   //���һ��C.txt�����е�B.txt�ļ�ASED
#endif
//ccr2017-06-16>>>>>>>>>
#if SDCACHESIZE
#if defined(DEBUGBYPC)
BYTE SDCacheBuff[SDCACHESIZE];
#else
BYTE SDCacheBuff[SDCACHESIZE] __attribute__((at(ADDR_EXTRAM+SRAMSIZE)));
#endif
#endif

//*******************************************************************************************

//BYTE testonly_BADEJ;

void PrintEJLog(BYTE prnCtrl);

extern WORD BCC;


extern short LoadReceipLog();
extern BYTE CheckPrinter();


extern BYTE VerifyCRC(BYTE *Area,short pLen,short EnCode);

extern void PrintReceiptNum();

/////////////////////////////////////////////////////////
//CMD_EXPLOREEJ/CMD_EXPLOREEJ+1/CMD_EXPLOREEJ+2/CMD_EXPLOREEJ+3/CMD_EXPLOREEJ+4
void Search_EJ_Record()
{
#if (0)//ccr2017-12-06
    UnLong sVal;

    switch (LogDefine.idx)
    {
    case 0:// input receipt number from

        LogDefine.RecNumFr = BCDValueToULong(ApplVar.Entry.Value,BCDLEN);;
        LogDefine.RecNumTo = LogDefine.RecNumFr;
        PutsO(Msg[RECNUMTO].str);
        ClearEntry();
        LogDefine.idx++;
        Appl_MaxEntry = 10;
        break;
    case 1:// input receipt number from
        if (Appl_EntryCounter)
        {
            LogDefine.RecNumTo = BCDValueToULong(ApplVar.Entry.Value,BCDLEN);

            if (LogDefine.RecNumTo<LogDefine.RecNumFr)
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI02);
                ApplVar.FuncOnEnter = 0; // liuj 0528
                break;
            }
        }

        LogDefine.DateFr = (((UnLong)Now.year & 0xff)<<24) +    //YY
                                   ((UnLong)Now.month<<16) +       //MM
                                   ((UnLong)Now.day<<8);       //DD

        memset(SysBuf,' ',DISLEN);

        switch (TIME_DATE)
        {
        case 1:     //wMMDDYYYYHH//
            sVal = ((UnLong)Now.month <<24) +
                   ((UnLong)Now.day<<16) +
                   (((UnLong)Now.year& 0xff)<<8);
            break;
        case 2:     //wyyYYMMDDHH//
            sVal = (((UnLong)Now.year & 0xff)<<24) +
                   ((UnLong)Now.month<<16) +
                   ((UnLong)Now.day<<8);
            break;
        default:         //wDDMMYYYYHH//
            sVal = ((UnLong)Now.day<<24) +
                   ((UnLong)Now.month<<16) +
                   (((UnLong)Now.year & 0xff)<<8);
            break;
        }

        HEXtoASC(SysBuf+DISLEN-8,(char*)(&sVal),4);
        LogDefine.DateTo = sVal;// for remember input datefrom

        //HEXtoASC(SysBuf+DISLEN-8,(char*)(&LogDefine.DateFr),4);
        SysBuf[DISLEN] = 0;
#if(DD_ZIP==1)
        PutsO(Prompt.LineCap[Line_DATEFR]);
        Puts1(SysBuf);
#elif(DD_ZIP_21==1)
        PutsO(Prompt.LineCap[Line_DATEFR]);
        Puts1(SysBuf);
        PutsC(SysBuf+4);
#elif(DD_LCD_1601)
        memset(ProgLineMes,' ',DISLEN);
        CopyFrStr(ProgLineMes,Prompt.LineCap[Line_DATEFR]);
        strcpy(ProgLineMes+DISLEN-8,SysBuf+DISLEN-8);
        PutsO(ProgLineMes);
#else
        PutsO(Prompt.LineCap[Line_DATEFR]);
#endif
        ClearEntry();
        LogDefine.idx++;
        Appl_MaxEntry = 10;
        break;
    case 2:
        sVal = LogDefine.DateTo; // for remember input datefrom
        if (Appl_EntryCounter)
        {
            if (Appl_EntryCounter==6)
            {
                BcdMul10(&ApplVar.Entry);
                BcdMul10(&ApplVar.Entry);
            }

            switch (TIME_DATE)
            {
            case 1:     //wMMDDYYYYHH//
                LogDefine.DateFr = (((UnLong)ApplVar.Entry.Value[1])<<24) +     //YY
                                           ((UnLong)ApplVar.Entry.Value[3]<<16) +      //MM
                                           ((UnLong)ApplVar.Entry.Value[2]<<8) +       //DD
                                           ApplVar.Entry.Value[0];                 //HH

                if (ApplVar.Entry.Value[3] >0x12)
                    LogDefine.DateFr = 0;
                if (ApplVar.Entry.Value[2] > GetMonthMaxDay( ApplVar.Entry.Value[1] & 0xff,ApplVar.Entry.Value[3]))
                    LogDefine.DateFr = 0;
                if (ApplVar.Entry.Value[0]>0x24)
                    LogDefine.DateFr= 0;

                break;
            case 2:     //wyyYYMMDDHH//
                LogDefine.DateFr = (((UnLong)ApplVar.Entry.Value[3])<<24) +     //YY
                                           ((UnLong)ApplVar.Entry.Value[2]<<16) +      //MM
                                           ((UnLong)ApplVar.Entry.Value[1]<<8) +       //DD
                                           ApplVar.Entry.Value[0];                 //HH
//liuj 0731
                if (ApplVar.Entry.Value[2] >0x12)
                    LogDefine.DateFr = 0;
                if (ApplVar.Entry.Value[1] > GetMonthMaxDay( ApplVar.Entry.Value[3] & 0xff,ApplVar.Entry.Value[2]))
                    LogDefine.DateFr = 0;
                if (ApplVar.Entry.Value[0]>0x24)
                    LogDefine.DateFr= 0;
                break;
            default:         //wDDMMYYYYHH//
                LogDefine.DateFr = (((UnLong)ApplVar.Entry.Value[1])<<24) +     //YY
                                           ((UnLong)ApplVar.Entry.Value[2]<<16) +      //MM
                                           ((UnLong)ApplVar.Entry.Value[3]<<8) +       //DD
                                           ApplVar.Entry.Value[0];                 //HH
//liuj 0731
                if (ApplVar.Entry.Value[2] >0x12)
                    LogDefine.DateFr = 0;
                if (ApplVar.Entry.Value[3] > GetMonthMaxDay( ApplVar.Entry.Value[1] & 0xff,ApplVar.Entry.Value[2]))
                    LogDefine.DateFr = 0;
                if (ApplVar.Entry.Value[0]>0x24)
                    LogDefine.DateFr= 0;
                break;
            }
            sVal = (((UnLong)ApplVar.Entry.Value[3])<<24) +     //YY
                   ((UnLong)ApplVar.Entry.Value[2]<<16) +      //MM
                   ((UnLong)ApplVar.Entry.Value[1]<<8) ;       //DD
//															ApplVar.Entry.Value[0];					//HH  // liuj 0808

            if (LogDefine.DateFr == 0)
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI02);
                ApplVar.FuncOnEnter = 0; // liuj 0528
                break ;
            }
        }
        LogDefine.idx++;

        LogDefine.DateTo = (LogDefine.DateFr & 0xffffff00)+0x24;
        memset(SysBuf,' ',DISLEN);
        //HEXtoASC(SysBuf+DISLEN-8,(char*)(&LogDefine.DateTo),4);
//liuj0728
        sVal =  (sVal & 0xffffff00)+0x24;
        HEXtoASC(SysBuf+DISLEN-8,(char*)(&sVal),4);
        SysBuf[DISLEN] = 0;

#if(DD_ZIP==1)
        PutsO(Prompt.LineCap[Line_DATETO]);
        Puts1(SysBuf);
#elif(DD_ZIP_21==1)
        PutsO(Prompt.LineCap[Line_DATETO]);
        Puts1(SysBuf);
        PutsC(SysBuf+4);
#elif(DD_LCD_1601)
        memset(ProgLineMes,' ',DISLEN);
        CopyFrStr(ProgLineMes,Prompt.LineCap[Line_DATETO]);
        strcpy(ProgLineMes+DISLEN-8,SysBuf+DISLEN-8);
        PutsO(ProgLineMes);
#else
        PutsO(Prompt.LineCap[Line_DATETO]);
#endif

        ClearEntry();
        break;
    case 3:
        //sVal = LogDefine.DateTo; // for remember input datefrom
        if (Appl_EntryCounter)
        {
            if (Appl_EntryCounter==6)
            {
                BcdMul10(&ApplVar.Entry);
                BcdMul10(&ApplVar.Entry);
            }

            switch (TIME_DATE)
            {
            case 1:     //wMMDDYYHH//
                LogDefine.DateTo = (((UnLong)ApplVar.Entry.Value[1])<<24) +     //YY
                                           ((UnLong)ApplVar.Entry.Value[3]<<16) +      //MM
                                           ((UnLong)ApplVar.Entry.Value[2]<<8) +       //DD
                                           ApplVar.Entry.Value[0];                 //HH
                if (ApplVar.Entry.Value[3] >0x12)
                    LogDefine.DateTo= 0;
                if (ApplVar.Entry.Value[2] > GetMonthMaxDay( ApplVar.Entry.Value[1] & 0xff,ApplVar.Entry.Value[3]))
                    LogDefine.DateTo= 0;
                if (ApplVar.Entry.Value[0]>0x24)
                    LogDefine.DateTo= 0;
                break;
            case 2:     //wYYMMDDHH//
                LogDefine.DateTo = (((UnLong)ApplVar.Entry.Value[3])<<24) +     //YY
                                           ((UnLong)ApplVar.Entry.Value[2]<<16) +      //MM
                                           ((UnLong)ApplVar.Entry.Value[1]<<8) +       //DD
                                           ApplVar.Entry.Value[0];                 //HH
                if (ApplVar.Entry.Value[2] >0x12)
                    LogDefine.DateTo= 0;
                if (ApplVar.Entry.Value[1] > GetMonthMaxDay( ApplVar.Entry.Value[3] & 0xff,ApplVar.Entry.Value[2]))
                    LogDefine.DateTo = 0;
                if (ApplVar.Entry.Value[0]>0x24)
                    LogDefine.DateTo= 0;
                break;
            default:         //wDDMMYYHH//
                LogDefine.DateTo = (((UnLong)ApplVar.Entry.Value[1])<<24) +     //YY
                                           ((UnLong)ApplVar.Entry.Value[2]<<16) +      //MM
                                           ((UnLong)ApplVar.Entry.Value[3]<<8) +       //DD
                                           ApplVar.Entry.Value[0];                 //HH
                if (ApplVar.Entry.Value[2] >0x12)
                    LogDefine.DateTo = 0;
                if (ApplVar.Entry.Value[3] > GetMonthMaxDay( ApplVar.Entry.Value[1] & 0xff,ApplVar.Entry.Value[2]))
                    LogDefine.DateTo = 0;
                if (ApplVar.Entry.Value[0]>0x24)
                    LogDefine.DateTo= 0;
                break;
            }

        }
        if (LogDefine.DateTo!=0 && LogDefine.DateTo>=LogDefine.DateFr)
            PrintEJLog(true);
        else
            ApplVar.ErrorNumber=ERROR_ID(CWXXI02);

        ApplVar.FuncOnEnter = 0;
        ClearEntry();
        ClearLine2();
        PutsO(ModeHead);
        break;
    }
#endif
}


//>>>>>>>>>>ccr070718
BYTE MMC_CheckPresence()
{
    if (!Bios(BiosCmd_SD_CheckPresence, 0,0,0))
    {
        Save_ConfigVar(true);
        return false;
    }
    else
        return true;
}
//<<<<<<<<<<<<<<<<<<<<<<<<

//==========================================================
//��LogData�е����ݼ���SHA-1
int ComputeASEDS(char *LogData,int len)
{
    if (!ApplVar.SHA1_Error)
        ApplVar.SHA1_Error = SHA1Input(&ApplVar.SHA1,LogData,len);
    return ApplVar.SHA1_Error;
}
/********************************************************
 * ���վݽ��˺��Z������ӡ��ɺ��ӡSHA-1ǩ������,
 * ִ��PrintASEDS֮��Ĵ�ӡ���ݲ�����EJ
 * �������SD Cache��ʽʱ,�Ƚ�����д���ļ�
 *
 * @author EutronSoftware (2017-06-16)
 ********************************************************/
void PrintASEDS()
{
    char buff[48];
    int i,j;

    StoreEJEnd();//ccr2018-02-28 ��ӡ���ݲ�����EJ
#if defined(CASE_GREECE)//ccr2018-01-08�����վݼ���SHA1ǩ��
    if (!ApplVar.SHA1_Error && !(ApplVar.SHA1_Error=SHA1Result(&ApplVar.SHA1,ApplVar.SHA1_Digest)))
    {
          memcpy(ApplVar.SHA1_Copy,ApplVar.SHA1_Digest,SHA1HashSize);
          strcpy(buff,"ASEDS:");
          HEXtoASCL(buff+6,ApplVar.SHA1_Digest,10);buff[26]=0;
          RJPrint(0,buff);
          CLONG(buff[0])=0x20202020L;CWORD(buff[4])=0x2020;
          HEXtoASCL(buff+6,ApplVar.SHA1_Digest+10,10);buff[26]=0;
          RJPrint(0,buff);
    }
    else
    {
        sprintf(buff,"ASEDS:-----Error of SHA1:%d----",ApplVar.SHA1_Error);
        RJPrint(0,buff);
    }
#endif

#if (SDCACHESIZE)
    //��ǩ������д���ļ�
    //��SD Cache�е�����д���ļ���ͬʱ����ǩ����SD Cache�е����ݽ���ǩ��
//    SDCacheFlushData(true);
//    CheckEJSpace();
#endif
}

/*************************************************************************
 * ����STOREEJ2_AZ��־,��Ҫ��ӡ��һ���ַ�д��EJ��,ͬʱ������SHA-1ǩ������
 *
 * @author EutronSoftware (2017-06-21)
 *
 * @param str:��Ҫд����ַ���,�䳤��<=PRTLEN
 **********************************************************************/
void StoreEJData(BYTE *str)
{
    int j;
    BYTE LogData[PRTLEN+3];

    if (ApplVar.FiscalFlags != FISCALOK && ApplVar.FiscalFlags!=FMMACFULL)
        return;
    if (str != NULL && BIT(ApplVar.ContFlag, STOREEJ2_AZ))
    {
#if 1
        if (BIT(ApplVar.Fiscal_PrintFlag,(BIT0 | BIT1 | BIT2)))//�տ���������ۻ��ӡ˰��Z����״̬��
#else
        if ((ApplVar.CentralLock==RG || ApplVar.CentralLock==MG)//�տ�����������վ���
            || (ApplVar.CentralLock==Z))//�տ�����ڴ�ӡ˰��Z����״̬��
#endif
        {
            j = strlen(str);
            if (j>PRTLEN) j=PRTLEN;
            memcpy(LogData, str,j);
            AppendCRLF(LogData, j);//׷�ӻس�����
#if (SDCACHESIZE)//ccr2017-06-16>>>>
            if (ApplVar.SDCache.Type=='R' || ApplVar.SDCache.Type=='Z')//ccr2018-03-16
            {
                SDCachePushData(LogData,j);//ccr2018-02-23�����е�����д���ļ�
#if defined(CASE_GREECE)//ccr2018-01-08���վݼ���SHA1ǩ��
                ComputeASEDS(LogData,j);
#endif
            }
            else
#endif//ccr2017-06-16>>>>
            {
#if defined(TWO_SDCARDS)
                ff_SelectSDisk(FS_SD_2ND);
                ff_OpenFileWrite(ApplVar._a_txt,LogData,j);
                ff_SelectSDisk(FS_SD);
#endif
                ff_OpenFileWrite(ApplVar._a_txt,LogData,j);
#if defined(CASE_GREECE)//ccr2018-01-08�����վݼ���SHA1ǩ��
                if (ApplVar.CentralLock!=Z)//ccr2017-11-15_z.txt������SHA1
                    ComputeASEDS(LogData,j);
#endif
            }

        }

    }
}

/*-----------------------------------------------------------------------------
// ����ָ�������ڷ�Χ���վݺż�¼������ѯ��ӡEJ�е����� //
// ��û��ָ���վݺ�ʱ,��ӡ���ڷ�Χ�ڵ�ȫ���վ�      //
// prnCtrl:=false ��ӡEJ�е����һ���ĵ�,        //
//      =true,����ָ�������ڲ��ҷ����������ĵ� //
// ��EJ�н������������ݽ�����SysBuf��
The following sequence can be entered in the SET mode,
CMD_EXPLOREEJ/CMD_EXPLOREEJ+1/CMD_EXPLOREEJ+2/CMD_EXPLOREEJ+3/CMD_EXPLOREEJ+4
<200> < ENTER>:CMD_EXPLOREEJ:  Reprint Invoice documents from EJ;
<201> < ENTER>:CMD_EXPLOREEJ+1 Reprint No Fiscal documents from EJ;
<202> < ENTER>:CMD_EXPLOREEJ+2 Reprint Z Closure documents from EJ;
<203> < ENTER>:CMD_EXPLOREEJ+3 Reprint FM report documents from EJ.
<204> < ENTER>:CMD_EXPLOREEJ+4 Reprint All of the types of documents from EJ.
------------------------------------------------------------------------------*/

BYTE DataFromEJ[SD_BLOCKSIZE-8];

void PrintEJLog(BYTE prnCtrl)
{
    short  i, j;
    UnLong sSaveP,sRecno;
    UnLong sDateLog;
    BYTE sCh;   //cc 2006-07-07 for MMC
    WORD sDate;     //cc 2006-07-07 for MMC
    BYTE sActLog,           //=0,Document is not for printe,(�ĵ������ϲ�������)
                            //=1,Document must be printed,(�ĵ����ϲ�������)
                            //=2, At the end of document
    sEJcrc,             //EJУ��
    sLogStart,          //=1,�ĵ���ʼ;=0,�ļ�����
    sPrintIt,           // ���������������Ƿ��ӡ
    sFlag,              //������־
    sDbH;//=0,Ϊ�����ַ�;=1,Ϊ���ߴ�ӡ

    sActLog = sLogStart = sDbH = 0;
    j= 0;

#if (DD_FISPRINTER)//ccr091104>>>>>>>>
    SwitchLedON(100);
#else
    PutsO(Msg[WAITING].str);
#if (DISP2LINES)
    Puts1(STOPMESS);
#endif
#endif

    while (sSaveP<ApplVar.EJLogHeader.NextNP)/*    && !KbHit()    */
    {
#if (DD_FISPRINTER==0 && !defined(DEBUGBYPC))//ccr091104>>>>>>>>
        if (KbHit())
        {//��ӡ�����У�������ʱ��������ж�
            if (Getch() == CLEARKey)
                break;//while (sSaveP<ApplVar.EJLogHeader.NextNP)
        }
        FM_EJ_Exist();
#endif//<<<<<<<<<<<<<<<<<<<<<
            break;//EJ�洢����
    }
#if (DD_FISPRINTER)//ccr091104>>>>>>>>
    SwitchLedOFF();
#else
    PutsO(ModeHead);
#endif

    if (prnCtrl)
    {
        PrintLine('=');
#if defined(FISCAL)
        ApplVar.FStatus = 0;    //liuj 0611
#endif
        RFeed(1);
    }

}

/*  Get the real size of MMC  */
/**
 * ��ȡ���洢�ռ�
 *
 * @author EutronSoftware (2017-06-13)
 *
 * @param fsSD :=0,��ȡ������������
 *              =FS_SD,FS_SD_2ND
 */
void GetMMCSize(BYTE fsSD)
{
#if defined(TWO_SDCARDS)
    if (fsSD==0 || fsSD==FS_SD_2ND)
    {
        ff_MountSDisk(FS_SD_2ND);
        ff_SDiskSpace();
        ff_MountSDisk(FS_RELEASE);
    }
    if (!ApplVar.ErrorNumber && (fsSD==0 || fsSD==FS_SD))
#endif
    {
        ff_MountSDisk(FS_SD);
        ff_SDiskSpace();
        ff_MountSDisk(FS_RELEASE);
    }
}

/*************************************************************************
 * ����EJǰ,Ӧ���Ȳ���FM,FM��ȫ׼ȷʱ,�ٲ���EJ,����,��Ӧ�ý���˺���
 * return ApplVar.FiscalFlags:
 *
 * @author EutronSoftware (2017-06-19)
 *
 * @param getSize :�Ƿ��ȡSD����������
 ******************************************************************/
void CheckEJ(BYTE getSize)
{
    BYTE sBuf[32];
    ULONG sTp, sBegin;
    FRESULT result;
    struct FIS_EJTBL sEJTbl;

#if !defined(DEBUGBYPC)
    if (!MMC_CheckPresence() || SD_Init()!=SD_OK)
    {
        ApplVar.FiscalFlags = NOEJ;     // no EJ //
        ApplVar.ErrorNumber=ERROR_ID(CWXXI83);
        return;
    }
#if defined(TWO_SDCARDS)
    if (SD_Init_2nd()!=SD_OK)
    {
        ApplVar.FiscalFlags = NOEJ;     // no EJ //
        ApplVar.ErrorNumber=ERROR_ID(CWXXI112);
        return;
    }
#endif
//    PutsO("Get EJ Size>>>>");//ccr2017-06-14 testonly
    if (getSize)
        GetMMCSize(0);//ccr2017-06-19��ʱ�ϳ�

    if (ApplVar.ErrorNumber==ERROR_ID(CWXXI84) || ApplVar.ErrorNumber==ERROR_ID(CWXXI96))
    {
        ApplVar.FiscalFlags = BADEJ;//ccr091014
        return;
    }
#endif

#if defined(FISCAL)  // liuj 0813
    if (ApplVar.FiscalFlags!=FISCALOK && ApplVar.FiscalFlags != FMMACFULL ) //liuj 0611 ����EJǰ,Ӧ���Ȳ���FM,����,��Ӧ�ü���˺��� //
        return;

//ccr2017-06-20>>>����ڿ��Ƿ��ǵ�ǰʹ�õĿ�>>>>>>>>>>>>>

    if (ApplVar.FisNumber.TotalEJNum)
    {
        if (!Bios_FM_Read(&sEJTbl, FISEJADDR+(ApplVar.FisNumber.TotalEJNum-1)*sizeof(ApplVar.Fis_EJTbl), sizeof(ApplVar.Fis_EJTbl)))
        {// error found when read from FM //
            ApplVar.FiscalFlags = FMERROR;
            ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
            return;
        }

        if (CWORD(sEJTbl)==0xffff)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI90);
            ApplVar.FiscalFlags = MUSTINITEJ;// FM���޴�EJ�ĵǼǼ�¼,�����µ�EJ���� //
            return;
        }
#if defined(TWO_SDCARDS)
        if (!ReadSDInfor(FS_SD_2ND))
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI96);
            ApplVar.FiscalFlags = BADEJ;// EJ is damaged,can't write and read //
            return;
        }
        //���EJ�Ƿ��ڴ˻�����ʹ�ù�
        ff_SelectSDisk(FS_SD_2ND);
        result=FR_NOT_READY;
        if (sEJTbl.ManufacturerID[_FS_SD_2ND]==SDCardInfo.SD_cid.ManufacturerID &&/*!< ManufacturerID */
            sEJTbl.OEM_AppliID[_FS_SD_2ND]==SDCardInfo.SD_cid.OEM_AppliID &&    /*!< OEM/Application ID */
            sEJTbl.ProdSN[_FS_SD_2ND]==SDCardInfo.SD_cid.ProdSN &&              /*!< Product Serial Number */
            sEJTbl.ManufactDate[_FS_SD_2ND]==SDCardInfo.SD_cid.ManufactDate)  /*!< Manufacturing Date */
        {// EJ has been login in the FM //
                sprintf(sBuf,"%d:/GGPS/%s",ApplVar.FS_Current,ApplVar.ApprovalCode);
                result = ff_OpenFolder(sBuf);//��GGPS/TLD66000003�ļ���
        }
        if (result!=FR_OK)
        {//�ڿ����ǵ�ǰʹ�õĿ�
            ApplVar.ErrorNumber=ERROR_ID(CWXXI113);
            ApplVar.FiscalFlags = MUSTINITEJ;// FM���޴�EJ�ĵǼǼ�¼,�����µ�EJ���� //
            ff_SelectSDisk(FS_SD);
            return;
        }
#endif
//ccr2017-06-20<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        if (!ReadSDInfor(FS_SD))
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI84);
            ApplVar.FiscalFlags = BADEJ;// EJ is damaged,can't write and read //
            return;
        }

        //���EJ�Ƿ��ڴ˻�����ʹ�ù�
        ff_SelectSDisk(FS_SD);
        result=FR_NOT_READY;
        if (sEJTbl.ManufacturerID[_FS_SD]==SDCardInfo.SD_cid.ManufacturerID &&/*!< ManufacturerID */
            sEJTbl.OEM_AppliID[_FS_SD]==SDCardInfo.SD_cid.OEM_AppliID &&    /*!< OEM/Application ID */
            sEJTbl.ProdSN[_FS_SD]==SDCardInfo.SD_cid.ProdSN &&              /*!< Product Serial Number */
            sEJTbl.ManufactDate[_FS_SD]==SDCardInfo.SD_cid.ManufactDate)  /*!< Manufacturing Date */
        {// EJ has been login in the FM //
                sprintf(sBuf,"%d:/GGPS/%s",ApplVar.FS_Current,ApplVar.ApprovalCode);
                result = ff_OpenFolder(sBuf);//��GGPS/TLD66000003�ļ���
        }
        if (result==FR_OK)
        {
            ApplVar.FiscalFlags = FISCALOK;// SD����ʼ���� //
            return;
        }
    }
#endif
    ApplVar.ErrorNumber=ERROR_ID(CWXXI90);
    ApplVar.FiscalFlags = MUSTINITEJ;// FM���޴�EJ�ĵǼǼ�¼,�����µ�EJ���� //
}


//��ʼ��EJ: ����⵽��EJΪ�µ�EJʱ,����ִ�д˺���,��FM�еǼ�EJ //
//write EJ info to fiscal card
void ProcessEJ()
{
    ULONG sAddr,sLp,sPer,sPerInc;
    FRESULT result;

    ApplVar.ErrorNumber = 0;
    if (ApplVar.FiscalFlags != MUSTINITEJ )
    {
        if (ApplVar.FiscalFlags == FISCALOK)
            ApplVar.ErrorNumber=ERROR_ID(CWXXI79);
        else
            ApplVar.ErrorNumber=ERROR_ID(CWXXI84);
        return;
    }

#if defined(FISCAL) //liuj 0813

#if defined(TWO_SDCARDS)
    ff_SelectSDisk(FS_SD_2ND);
    sprintf(SysBuf,"%d:/GGPS/%s",ApplVar.FS_Current,ApplVar.ApprovalCode);
    if (ff_OpenFolder(SysBuf)!=FR_OK)//��GGPS/TLD66000003�ļ���,����ļ����Ƿ����
    {//�ļ��в�����,Ϊ�¿�
        ApplVar.ErrorNumber=0;
        result = ff_CreateFolders(SysBuf);//����GGPS/TLD66000003�ļ���

        if (result!=FR_OK)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI115);
            ApplVar.FiscalFlags = MUSTFORMATSD;
            ff_SelectSDisk(FS_SD);
            return;
        }
#if defined(CASE_GREECE)//ccr2018-01-08�����վݼ���SHA1ǩ��
        //ccr2017-11-14>>>>>>>���ڿ�ʱ,���ڿ��ϴ���LASTD_ALLE,LASTC_ALLB�ļ�,��д��20�ֽڵ�0(��ʼASED),
        ff_MountSDisk(FS_SD_2ND);
        if (ff_OpenFile(LASTD_ALLE,(FA_CREATE_ALWAYS+FA_WRITE))==FR_OK)
        {//����ǰһ��D�ļ���ASEDǩ��,FA_READ | FA_WRITE��ȷ�����ļ�ͷд������
            ff_WriteFile(ApplVar.ASEDLastD,SHA1HashSize);
            ff_CloseFile();
        }
        if (ff_OpenFile(LASTC_ALLB,(FA_CREATE_ALWAYS+FA_WRITE))==FR_OK)
        {//����ǰһ��D�ļ���ASEDǩ��,FA_READ | FA_WRITE��ȷ�����ļ�ͷд������
            ff_WriteFile(ApplVar.ASEDLastC,SHA1HashSize);
            ff_CloseFile();
        }
        ff_MountSDisk(FS_RELEASE);
        //ccr2017-11-14<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#endif
    }
#endif

    ff_SelectSDisk(FS_SD);
    sprintf(SysBuf,"%d:/GGPS/%s",ApplVar.FS_Current,ApplVar.ApprovalCode);
    if (ff_OpenFolder(SysBuf)!=FR_OK)//��GGPS/TLD66000003�ļ���,����ļ����Ƿ����
    {//�ļ��в�����,Ϊ�¿�
        ApplVar.ErrorNumber=0;
		result = ff_CreateFolders(SysBuf);//����GGPS/TLD66000003�ļ���
        if (result!=FR_OK)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI114);
            ApplVar.FiscalFlags = MUSTFORMATSD;
            return;
        }
#if defined(CASE_GREECE)//ccr2018-01-08�����վݼ���SHA1ǩ��
#if !defined(TWO_SDCARDS)//ccr2017-11-14>>>>>>ֻ��һ���⿨ʱ,���⿨�ϴ���LASTD_ALLE,LASTC_ALLB�ļ�
        //ccr2017-11-14����������ʱ�ļ�,��д��20�ֽڵ�0(��ʼASED)
        ff_MountSDisk(FS_MOUNT);
        if (ff_OpenFile(LASTD_ALLE,(FA_CREATE_ALWAYS+FA_WRITE))==FR_OK)
        {//����ǰһ��D�ļ���ASEDǩ��,FA_READ | FA_WRITE��ȷ�����ļ�ͷд������
            ff_WriteFile(ApplVar.ASEDLastD,SHA1HashSize);
            ff_CloseFile();
        }
        if (ff_OpenFile(LASTC_ALLB,(FA_CREATE_ALWAYS+FA_WRITE))==FR_OK)
        {//����ǰһ��D�ļ���ASEDǩ��,FA_READ | FA_WRITE��ȷ�����ļ�ͷд������
            ff_WriteFile(ApplVar.ASEDLastC,SHA1HashSize);
            ff_CloseFile();
        }
        ff_MountSDisk(FS_RELEASE);
        //ccr2017-11-14<<<<<<<<<<<<<<<<<<<<<<<<
#endif
#endif
    }

    //testonly_BADEJ=0;
    //write fiscal card
    memset(&ApplVar.Fis_EJTbl, 0xff, sizeof(ApplVar.Fis_EJTbl));    //memset(&ApplVar.Fis_EJTbl, 0, FEJTBLLEN);
    //read EJ ID from MMC card
    //ccr2017-06-20>>>>>>>>>>>>>>>>>>>>>
    if (!ReadSDInfor(FS_SD))
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI84);
        ApplVar.FiscalFlags = BADEJ;
        return;
    }
    else
    {
        ApplVar.Fis_EJTbl.ManufacturerID[_FS_SD]=SDCardInfo.SD_cid.ManufacturerID;/*!< ManufacturerID */
        ApplVar.Fis_EJTbl.OEM_AppliID[_FS_SD]=SDCardInfo.SD_cid.OEM_AppliID;    /*!< OEM/Application ID */
        ApplVar.Fis_EJTbl.ProdSN[_FS_SD]=SDCardInfo.SD_cid.ProdSN;              /*!< Product Serial Number */
        ApplVar.Fis_EJTbl.ManufactDate[_FS_SD]=SDCardInfo.SD_cid.ManufactDate;  /*!< Manufacturing Date */
#if defined(TWO_SDCARDS)
        if (!ReadSDInfor(FS_SD_2ND))
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI96);
            ApplVar.FiscalFlags = BADEJ;
            return;
        }
        else
        {
            ApplVar.Fis_EJTbl.ManufacturerID[_FS_SD_2ND]=SDCardInfo.SD_cid.ManufacturerID;/*!< ManufacturerID */
            ApplVar.Fis_EJTbl.OEM_AppliID[_FS_SD_2ND]=SDCardInfo.SD_cid.OEM_AppliID;    /*!< OEM/Application ID */
            ApplVar.Fis_EJTbl.ProdSN[_FS_SD_2ND]=SDCardInfo.SD_cid.ProdSN;              /*!< Product Serial Number */
            ApplVar.Fis_EJTbl.ManufactDate[_FS_SD_2ND]=SDCardInfo.SD_cid.ManufactDate;  /*!< Manufacturing Date */
        }
#endif
    }

    GetMMCSize(0);//ccr2017-06-19��ʱ�ϳ�
    //ccr2017-06-20<<<<<<<<<<<<<<<<<<<<<

    //count
    ApplVar.Fis_EJTbl.FEJID = ApplVar.FisNumber.TotalEJNum + 1;
    ApplVar.EJHeader.FEJID = ApplVar.FisNumber.TotalEJNum + 1;

    //Init Date & Time
    GetTimeDate(&Now);
    ApplVar.Fis_EJTbl.FInitDateTime[2] = Now.day;               //  YY
    ApplVar.Fis_EJTbl.FInitDateTime[1] = Now.month;         //  MM
    ApplVar.Fis_EJTbl.FInitDateTime[0] = (Now.year & 0xff); //  DD
    ApplVar.Fis_EJTbl.FInitDateTime[3] = Now.hour;          //  HH
    ApplVar.Fis_EJTbl.FInitDateTime[4] = Now.min;               //  MM
    ApplVar.Fis_EJTbl.FInitDateTime[5] = Now.sec;               //  SS
    //    Type of EJ

    (ApplVar.EJSpaceSize[_FS_SD]<=0x2000000L)?(ApplVar.Fis_EJTbl.FEJType=1):(ApplVar.EJSpaceSize[_FS_SD]<=0x8000000L)?(ApplVar.Fis_EJTbl.FEJType =2):(ApplVar.Fis_EJTbl.FEJType =3);
    ApplVar.Fis_EJTbl.FSize[_FS_SD]  = ApplVar.EJSpaceSize[_FS_SD]>>24;//��λΪM
#if defined(TWO_SDCARDS)
    (ApplVar.EJSpaceSize[_FS_SD_2ND]<=0x2000000L)?(ApplVar.Fis_EJTbl.FEJType|=0x10):(ApplVar.EJSpaceSize[_FS_SD_2ND]<=0x8000000L)?(ApplVar.Fis_EJTbl.FEJType =0x20):(ApplVar.Fis_EJTbl.FEJType =0x30);
    ApplVar.Fis_EJTbl.FSize[_FS_SD_2ND]  = ApplVar.EJSpaceSize[_FS_SD_2ND]>>24;//��λΪM
#endif
    //    CRC
    ApplVar.Fis_EJTbl.FCRC = VerifyCRC((BYTE *)&ApplVar.Fis_EJTbl,FEJTBLLEN,1);
    ApplVar.Fis_EJTbl.FunN = FISEJLOG;

    if (ApplVar.FTrain)               // trainning mode
        return;


    if (Write_FiscalRam(ApplVar.FiscalHead.EJTblP, &ApplVar.Fis_EJTbl, sizeof(ApplVar.Fis_EJTbl)))
    {
        ApplVar.FiscalHead.EJTblP += sizeof(ApplVar.Fis_EJTbl); //FEJTBLLEN;
        ApplVar.FisNumber.TotalEJNum++;
        ApplVar.FiscalFlags = FISCALOK;
    }
    else
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI76);                     // write fiscal date error
        ApplVar.FiscalFlags = BADFM;
    }
#endif

}

//��ӡ˰�ػ��Ѿ�ʹ�ù�������ʹ�õ�EJ�������Ϣ
void PrintEJInfo()
{
#if defined(FISCAL)
    int sBegin, slen;
    struct FIS_EJTBL sFis_EJTbl;

    Print_NonFiscal(1);

    PrintStr_Center((char *)Msg[EJXINXI].str,true);
    PrintLine('-');
    //tmp = ZERO;

    for (sBegin=0;sBegin<ApplVar.FisNumber.TotalEJNum;sBegin++)
    {
        if (!Bios_FM_Read(&sFis_EJTbl,FISEJADDR+sBegin*sizeof(sFis_EJTbl),sizeof(sFis_EJTbl)))
        {//ccr070719>>>>>>
            ApplVar.FiscalFlags = FMERROR;
            ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
            return ;
        }//<<<<<<<<<<<<<<

        if (CWORD(sFis_EJTbl)!=0xffff)
        {
            memset(SysBuf,' ',sizeof(SysBuf));
            CopyFrStr(SysBuf, Msg[EJBHAO].str);
            slen = strlen(Msg[EJBHAO].str);
            SysBuf[++slen] = ':';
            slen += 2;
            WORDtoASC(SysBuf + slen, (WORD)sFis_EJTbl.FEJID);
            slen = PRTLEN - 21;
            SysBuf[slen] = '2';SysBuf[slen+1] = '0';
            HEXtoASC(SysBuf + slen+2,&sFis_EJTbl.FInitDateTime[0],1);   SysBuf[slen + 4]='-';
            HEXtoASC(SysBuf + slen+5,&sFis_EJTbl.FInitDateTime[1],1);   SysBuf[slen + 7] = '-';
            HEXtoASC(SysBuf + slen+8,&sFis_EJTbl.FInitDateTime[2],1);       SysBuf[slen + 10] =' ';
            HEXtoASC(SysBuf+ slen + 13,&sFis_EJTbl.FInitDateTime[3],1); SysBuf[slen + 15] = ':';
            HEXtoASC(SysBuf+ slen + 16,&sFis_EJTbl.FInitDateTime[4],1); SysBuf[slen + 18] = ':';
            HEXtoASC(SysBuf+ slen + 19,&sFis_EJTbl.FInitDateTime[5],1);
            SysBuf[PRTLEN] = 0;
            RJPrint(0, SysBuf);

            memset(SysBuf,' ',PRTLEN);
            slen=strlen(MsgSizeOfEJ) ;
            memcpy(SysBuf, MsgSizeOfEJ,slen);
            SysBuf[slen]='-';
#if defined(TWO_SDCARDS)
            SysBuf[slen+1]='I';
            sprintf(SysBuf+23,"%8uM",sFis_EJTbl.FSize[_FS_SD_2ND]);
            RJPrint(0,SysBuf);
#endif
            SysBuf[slen+1]='E';
            sprintf(SysBuf+23,"%8uM",sFis_EJTbl.FSize[_FS_SD]);
            RJPrint(0,SysBuf);
        }
    }
    Print_NonFiscal(0);
    RFeed(1);
#endif
}

//////////////////////////////////////////////////////////////////////////////

//ccr070214>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

// ���뽫ReadComm�еĶ�������ʱ�Ӵ�ASECOND*3 //
void SendToHost(BYTE cBYTE)
{
    if (cBYTE==STX) BCC=0;

    SendComm(COMPUTER_1,cBYTE);
    BCC+=cBYTE;
}
//---------------------------------------------
void SendAWord(WORD pWord)
{
    BYTE sStr[5];
    HEXtoASC(sStr,(char *)&pWord,2);
    SendComm(COMPUTER_1,sStr[0]);
    BCC+=sStr[0];
    SendComm(COMPUTER_1,sStr[1]);
    BCC+=sStr[1];
    SendComm(COMPUTER_1,sStr[2]);
    BCC+=sStr[2];
    SendComm(COMPUTER_1,sStr[3]);
    BCC+=sStr[3];
}
//---------------------------------------------
void SendAByte(BYTE pByte)
{
    BYTE sStr[3];
    HEXtoASC(sStr,(char *)&pByte,1);
    SendComm(COMPUTER_1,sStr[0]);
    BCC+=sStr[0];
    SendComm(COMPUTER_1,sStr[1]);
    BCC+=sStr[1];
}

//---------------------------------------------
void SendAString(BYTE *sStr,BYTE sLen)
{
    short i;
    for (i=0;i<sLen;i++)
    {
        SendComm(COMPUTER_1,sStr[i]);
        BCC+=sStr[i];
    }
}

//---------------------------------------------

//return 0xffffffff: is not a digit
//else : return the digit
UnLong CheckDigit(char *Data, BYTE len)
{
    BYTE sTp;
    UnLong sLong = 0;

    for (sTp = 0; sTp < len; sTp++)
    {
        if (Data[sTp] > '9' || Data[sTp] < '0')
            return -1;
        sLong = sLong * 10 + Data[sTp] - '0';
    }
    return sLong;
}

//return 1: is a ascii string
//return 0: is not a ascii string
BYTE CheckString(BYTE *Data, BYTE len)
{
    BYTE sTp;

    for (sTp = 0; sTp < len; sTp++)
    {
        if (Data[sTp] > 0x7f || Data[sTp] < ' ')
            return 0;
    }
    return 1;
}


//=============================
BYTE Initial_EJ()
{
    int i;

    if (ApplVar.FiscalFlags >= FMISNEW)
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI81);
        return false;
    }

    if (ApplVar.FTrain)   //  in trainning mode //
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI80);
        return false;
    }
    ProcessEJ();
    if (ApplVar.ErrorNumber)
        return false;
    PrintLine('=');
    RJPrint(0, Msg[EJCSHUA].str);
    memset(SysBuf, ' ', PRTLEN);SysBuf[PRTLEN]=0;
    i = strlen(Msg[EJBHAO].str);
    memcpy(SysBuf, Msg[EJBHAO].str, i);
    WORDtoASC(SysBuf+i+4, ApplVar.EJHeader.FEJID);   //20070118
#if PRTLEN<25 // liuj 0716
    RJPrint(0, SysBuf);
    DateTimeToStr(SysBuf,3);
#else
    DateTimeToStr(SysBuf+(PRTLEN-20),3);
#endif
    RJPrint(0, SysBuf);

    memset(SysBuf,' ',PRTLEN);
    i=strlen(MsgSizeOfEJ) ;
    memcpy(SysBuf, MsgSizeOfEJ,i);
    SysBuf[i]='-';
#if defined(TWO_SDCARDS)
    SysBuf[i+1]='I';
    sprintf(SysBuf+23,"%9lu",ApplVar.EJSpaceSize[_FS_SD_2ND]);
    RJPrint(0,SysBuf);
#endif
    SysBuf[i+1]='E';
    sprintf(SysBuf+23,"%9lu",ApplVar.EJSpaceSize[_FS_SD]);
    RJPrint(0,SysBuf);

    PrintLine('=');

    RFeed(1);
#if (DISP2LINES)
    Puts1(Msg[EJXINXI].str);
#else
    PutsO(Msg[EJXINXI].str);
#endif
    ClearEntry();
    ApplVar.FStatus = 0;
    return true;
}
//ccr2017-04-17>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#if defined(CASE_GREECE)//ccr2018-01-08�����վݼ���SHA1ǩ��
/***********************************************************
 * New C file = all daily B files(aseds) + previous C file
 * New D file = all daily E files aseds + previous D file
 * @author EutronSoftware (2017-11-15)
 *
 * @param CorD
 * @param cdfile
 *
 * @return int :DRW_Buffer�е����ݳ���(SHA1HashSize*2)
 *      ApplVar.SHA1_Digest:����ǩ������
 *     SDRW_Buffer�а�����ASCII��ʽ��AESD����
 ***********************************************************/
int CalcAESDofCorD_txt(BYTE CorD,char *cdfile)
{
    FRESULT result;
    char pBuf[SHA1HashSize];
    int l;
#if defined(TWO_SDCARDS)
    ff_SelectSDisk(FS_SD_2ND);
#endif
    //Ϊ_s_txt�ļ�������SHA1ǩ������,��������_s.txt�ļ������һ��
    ApplVar.SHA1_Error=SHA1Reset(&ApplVar.SHA1);
    ff_MountSDisk(FS_MOUNT);
    if (!ApplVar.SHA1_Error)
    {
        if (CorD=='c')
            result=ff_OpenFileQ(LASTC_ALLB,FA_READ);
        else
            result=ff_OpenFileQ(LASTD_ALLE,FA_READ);
        if (result==FR_OK)
        {
            l = ff_ReadFile(pBuf, SHA1HashSize,FS_BINARY);//��ȡԤ�����һ��_c.txt�е�AESD
            if (l==SHA1HashSize)
            {
                //ccr2017-11-13>>>>��HEX��ʽת��
                while (!ff_EofFile())
                {//��ȡ���б����_b.txt��ǩ������
                    l = ff_ReadFile(SDRW_Buffer, sizeof(SDRW_Buffer),FS_BINARY);
                    if (l>0)
                        ApplVar.SHA1_Error=SHA1Input(&ApplVar.SHA1,SDRW_Buffer,l);//����ASED
                    else
                        break;
                }
                //pBuf��Ϊȫ0ʱ��Ϊ��һ��ʹ���տ��
                //if (CLONG(pBuf[0]) || CLONG(pBuf[4]) || CLONG(pBuf[8]) || CLONG(pBuf[12]) || CLONG(pBuf[16]))
                     ApplVar.SHA1_Error=SHA1Input(&ApplVar.SHA1,pBuf,SHA1HashSize);//����ASED
            }
            ff_CloseFile();
        }
    }

    //ccr2017-11-15��ȡ_c.txt��SHA1ǩ������(_z.txt������SHA1��ȡ_z.txt��SHA1ǩ������))
    if (!ApplVar.SHA1_Error && !(ApplVar.SHA1_Error=SHA1Result(&ApplVar.SHA1,ApplVar.SHA1_Digest)))
    {
          HEXtoASCL(SDRW_Buffer,ApplVar.SHA1_Digest,SHA1HashSize);
          l=SHA1HashSize*2;
    }
    else
    {
        sprintf(SDRW_Buffer,"Error of ASEDS:%d",ApplVar.SHA1_Error);
        l=strlen(SDRW_Buffer);
    }
    //��ǩ�����ݴ�����ʱ�ļ�,���´μ���ʹ��
    if (CorD=='c')
    {
        if (!ApplVar.SHA1_Error)
            memcpy(ApplVar.ASEDLastC,ApplVar.SHA1_Digest,SHA1HashSize);
#if SDCACHESIZE//ccr2018-03-16
        SDCachePushFileName('L',LASTC_ALLB);
#else
        result=ff_OpenFileQ(LASTC_ALLB,FA_CREATE_ALWAYS | FA_WRITE);
#endif
    }
    else
    {
        if (!ApplVar.SHA1_Error)
            memcpy(ApplVar.ASEDLastD,ApplVar.SHA1_Digest,SHA1HashSize);
#if SDCACHESIZE//ccr2018-03-16
        SDCachePushFileName('L',LASTD_ALLE);
#else
        result=ff_OpenFileQ(LASTD_ALLE,FA_CREATE_ALWAYS | FA_WRITE);
#endif
    }

#if SDCACHESIZE//ccr2018-03-16
    SDCachePushData(ApplVar.SHA1_Digest,SHA1HashSize);
    SDCachePushFileName(CorD,cdfile);
    SDCachePushData(SDRW_Buffer,l);
#else
    if (result==FR_OK)
    {//��ǰһ��D�ļ���ASED����ǩ��,FA_READ | FA_WRITE��ȷ�����ļ�ͷд������
        ff_WriteFile(ApplVar.SHA1_Digest,SHA1HashSize);
        ff_CloseFile();
    }
    ff_MountSDisk(FS_RELEASE);

    //ccr2017-11-15<<<<<<<<<<<<<<<<<<<<<<<<<<<
//ccr2018-02-27>>>>>>>>
#if defined(TWO_SDCARDS)
    ff_SelectSDisk(FS_SD_2ND);
//ccr2018-02-27    ff_OpenFileWrite(cdfile,SDRW_Buffer,l);
    ff_OpenFile(cdfile,(FA_CREATE_ALWAYS+FA_WRITE));//���ļ�,����ļ����������Զ�����
    ff_WriteFile(SDRW_Buffer,l);
    ff_CloseFile();
    ff_SelectSDisk(FS_SD);
#endif
    ff_OpenFile(cdfile,(FA_CREATE_ALWAYS+FA_WRITE));//���ļ�,����ļ����������Զ�����
    ff_WriteFile(SDRW_Buffer,l);
    ff_CloseFile();
//ccr2018-02-27    ff_OpenFileWrite(cdfile,SDRW_Buffer,l);
//ccr2018-02-27<<<<<<<<<<<<<<<<<<<<
#endif//ccr2018-03-16<<<<<<<<
    return l;
}

/*******************************************************************************
 * ���ݲ���fileB��ָ�����ļ�����,��TAX�����Լ�SHA1ǩ������д���ļ�
 * ��ʹ��SDRW_Buffer��SysBuf��Ϊ�����Ĺ�����
 *
 * @author EutronSoftware (2017-04-27)
 *
 * @param fileB:
 *        ='r': �վݽ��˺�,�����վݵ�_b.txt,_e.txt,_s.txt�ļ�����
 *        ='z': ��ӡ��Z������,Ϊ��Z��������_c.txt,_d.txt�Լ�_s.txt�ļ�
 *              ��ʹ��.Fis_ClearRecord�е����ݺ�_z.txt��SHA1����
 *             (Ӧ����PrintASEDS֮�����,�˺�����ɾ��_z.txt��SHA1ǩ������)
 *******************************************************************************/
void  StoreSHAorTAX(char fileB)
{
#define FisTaxSale ApplVar.FiscalBuff.Fis_ClearRecord.FTaxSale
#define FisTaxRate ApplVar.FiscalBuff.Fis_ClearRecord.FTaxAmt
#define FisTaxAmt ApplVar.FiscalBuff.Fis_ClearRecord.FTaxAmt
#define AppTaxSale ApplVar.TaxItem[0]
#define bcdValue SysBuf

    int ifTaxSale,i,j,k,l;
    WORD sYear,z;
    BYTE sMonth,sDay;
    double fTaxSale,fTaxAmt,fTaxRate;

    switch (fileB)
    {
    case 'r'://�վݽ��˺�,�����վݵ�_b.txt,_e.txt,_s.txt�ļ�����
            //ccr2017-06-21if (BIT(ApplVar.ContFlag, STORESHA2_B))
            {
                //>>>>>���վݵ�SHA1ǩ������д��_b.txt>>>>>
                //ccr2017-06-21RESETBIT(ApplVar.ContFlag, STORESHA2_B);
                //���վݵ�ASEDS���ݴ���_b.txt
                if (!ApplVar.SHA1_Error)
                {
                    HEXtoASCL(SDRW_Buffer,ApplVar.SHA1_Digest,SHA1HashSize);
                    i=strlen(ApplVar._a_txt);
                    ApplVar._a_txt[i-5]='b';
#if (SDCACHESIZE)//ccr2018-02-23>>>>>
                    SDCachePushFileName('L',LASTC_ALLB);
                    SDCachePushData(ApplVar.SHA1_Digest,SHA1HashSize);
                    SDCachePushFileName('b',ApplVar._a_txt);
                    SDCachePushData(SDRW_Buffer,SHA1HashSize*2);
#else
#if defined(TWO_SDCARDS)
                    ff_SelectSDisk(FS_SD_2ND);
                    ff_OpenFileWrite(ApplVar._a_txt,SDRW_Buffer,SHA1HashSize*2);
                    ff_OpenFileWrite(LASTC_ALLB,ApplVar.SHA1_Digest,SHA1HashSize);
                    ff_SelectSDisk(FS_SD);
#else
                    ff_OpenFileWrite(LASTC_ALLB,ApplVar.SHA1_Digest,SHA1HashSize);
#endif
                    ff_OpenFileWrite(ApplVar._a_txt,SDRW_Buffer,40);
#endif//ccr2018-02-23<<<<<
                }
//>>>>>>>����ApplVar.TaxItem[0]�����ݼ�˰����,����ϣ��˰�ؼ�˰�����ļ�_e.txt:
//979703476;TLD66000003;;201703201255;0001;0001040;0269;9.43;0.00;0.00;0.00;0.00;0.57;0.00;0.00;0.00;0;5F36AD7590349D334745ED0F571735F4C12B8EEA

                for(ApplVar.TaxNumber=0;ApplVar.TaxNumber<ApplVar.AP.Tax.Number;ApplVar.TaxNumber++)
                {
                    //��ȡ��Ӧ˰�ֵ����۽��
                    ifTaxSale=BCDValueToULong(AppTaxSale[ApplVar.TaxNumber].Value, BCDLEN);
                    if(AppTaxSale[ApplVar.TaxNumber].Sign & 0x80)
                           ifTaxSale = -ifTaxSale;
                    FisTaxSale[ApplVar.TaxNumber]=ifTaxSale;
                    //��ȡ��Ӧ˰�ֵ�˰��
                    ReadTax();
                    memset(bcdValue,0,BCDLEN);
                    CWORD(bcdValue[0]) = CWORD(ApplVar.Tax.Rate[0]);
                    FisTaxRate[ApplVar.TaxNumber]=BCDValueToULong(bcdValue, BCDLEN);
                }
                ApplVar.SHA1_Error = SHA1Reset(&ApplVar.SHA1);
                memset(SDRW_Buffer,0,sizeof(SDRW_Buffer));
                if (ApplVar.AP.NetWork.ECR_ID[0])
                {
                    strcpy(SDRW_Buffer,ApplVar.AP.NetWork.ECR_ID);// 1.personal tax registration number
                    k=strlen(SDRW_Buffer);//j,kָʾ����SHA��������
                }
                else
                    k=0;
                SDRW_Buffer[k++]=';';
                strcpy(SDRW_Buffer+k,ApplVar.ApprovalCode);//2. S/N of register(TLD66000003)
                k+=strlen(ApplVar.ApprovalCode);
                SDRW_Buffer[k++]=';';
                if (ApplVar.UserInfo.FVatNo[0])
                {
                    strcpy(SDRW_Buffer+k,ApplVar.UserInfo.FVatNo);// 3.Customer receipt card number  (NULL)
                    k+=strlen(ApplVar.UserInfo.FVatNo);
                }
                SDRW_Buffer[k++]=';';
                if (ApplVar.FTrain)
                {
                    i=ApplVar.ZCount[TRAINZNUM];
                    j=ApplVar.FisNumber.ReceiptNum[TRECEIPTS];
                    l=ApplVar.FisNumber.TotalReceiptNum[TRECEIPTS];
                }
                else
                {
                    i=ApplVar.ZCount[FISCALZNUM];
                    j=ApplVar.FisNumber.ReceiptNum[FRECEIPTS];//ApplVar.SaleReceipts
                    l=ApplVar.FisNumber.TotalReceiptNum[FRECEIPTS];
                }
                sprintf(SDRW_Buffer+k,"20%06u%04u;%04d;%07lu;%04u;",
                                        ApplVar.ReceiptDate,
                                        ApplVar.ReceiptTime,j,l,i);
                k=strlen(SDRW_Buffer);
                for(i=0;i<ApplVar.AP.Tax.Number;i++)
                {
                    fTaxSale=FisTaxSale[i];
                    fTaxSale=fTaxSale/100;

                    ifTaxSale=FisTaxRate[i];
                    if (ifTaxSale)
                    {
                        fTaxRate=ifTaxSale;
                        fTaxRate=fTaxRate/10000;
                        //������˰��
                        if (!BIT(ApplVar.Tax.Options, BIT0)) /* add on ? */
                        {//add onΪ����˰,��:���ۼ۸񲻰���˰
                            fTaxAmt = fTaxSale * fTaxRate;
                        }
                        else
                        {//VATΪ����˰,��:���ۼ۸����˰
                            fTaxAmt = fTaxSale;
                            fTaxSale = fTaxSale/(1+fTaxRate);
                            fTaxAmt = fTaxAmt- fTaxSale;
                        }
                        FisTaxRate[i]=(fTaxAmt+0.005)*100;//ccr2017-09-26�����������
                    }
                    sprintf(SDRW_Buffer+k,"%1.2f;",fTaxSale);
                    k=strlen(SDRW_Buffer);
                }
                for(i=0;i<ApplVar.AP.Tax.Number-1;i++)//ccr2017-09-21������VAT E(0)
                {
                    fTaxAmt=FisTaxRate[i];
                    fTaxAmt=fTaxAmt/100;
                    sprintf(SDRW_Buffer+k,"%1.2f;",fTaxAmt);
                    k=strlen(SDRW_Buffer);
                }
                SDRW_Buffer[k++]='0';//ccr2017-09-21 Currency code is alwasy '0'
                SDRW_Buffer[k++]=';';
                for (i=j=0;i<k;)
                {
                    //��������;֮�������
                    for (;j<k;j++)
                    {
                        if (SDRW_Buffer[j]==';')
                            break;
                    }
                    if (j>i)
                    {//������;��֮������ݼ���SHA1ǩ��
                        if (!ApplVar.SHA1_Error)
                        {
                            ApplVar.SHA1_Error = SHA1Input(&ApplVar.SHA1,SDRW_Buffer+i,j-i);
                        }
                    }
                    j++;//ָ����һ������
                    i=j;
                }

                if (!ApplVar.SHA1_Error && !(ApplVar.SHA1_Error=SHA1Result(&ApplVar.SHA1,ApplVar.SHA1_Digest)))
                {
                      HEXtoASCL(SDRW_Buffer+j,ApplVar.SHA1_Digest,SHA1HashSize);
                      j+=(SHA1HashSize*2);
                }
                else
                {
                    sprintf(SDRW_Buffer+j,"Error of ASEDS:%d",ApplVar.SHA1_Error);
                    j=strlen(SDRW_Buffer);
                }
                AppendCRLF(SDRW_Buffer, j);
                i=strlen(ApplVar._a_txt);
                ApplVar._a_txt[i-5]='e';
#if (SDCACHESIZE)//ccr2018-02-23>>>>>
                SDCachePushFileName('L',LASTD_ALLE);
                SDCachePushData(ApplVar.SHA1_Digest,SHA1HashSize);
                SDCachePushFileName('e',ApplVar._a_txt);//���վݵĽ�������д��_e.txt
                SDCachePushData(SDRW_Buffer,j);
                SDCachePushFileName('s',ApplVar._s_txt);//���վݵĽ�������д��_s.txt
                SDCachePushData(SDRW_Buffer,j);
                SDCachePushEnd();
#else
#if defined(TWO_SDCARDS)
                ff_SelectSDisk(FS_SD_2ND);
                ff_OpenFileWrite(ApplVar._a_txt,SDRW_Buffer,j);
                ff_OpenFileWrite(ApplVar._s_txt,SDRW_Buffer,j);
                ff_OpenFileWrite(LASTD_ALLE,ApplVar.SHA1_Digest,SHA1HashSize);
                ff_SelectSDisk(FS_SD);
#else
                ff_OpenFileWrite(LASTD_ALLE,ApplVar.SHA1_Digest,SHA1HashSize);
#endif
                ff_OpenFileWrite(ApplVar._a_txt,SDRW_Buffer,j);
                ff_OpenFileWrite(ApplVar._s_txt,SDRW_Buffer,j);
#endif//ccr2018-02-23<<<<<<
            }
            break;
    case 'z':   // ��ӡ��Z������,Ϊ��Z��������_c.txt,_d.txt�Լ�_s.txt�ļ�
                // ��ʹ��ApplVar.FiscalBuff.Fis_ClearRecord�е����ݺ�_z.txt��SHA1����,
                // (Ӧ����PrintASEDS֮�����,�˺�����ɾ��_z.txt��SHA1ǩ������)
        //ccr2017-06-21if (BIT(ApplVar.ContFlag, STORESHA2_B))
        {
            //ccr2017-06-21RESETBIT(ApplVar.ContFlag, STORESHA2_B);
            DecordDate(ApplVar.FiscalBuff.Fis_ClearRecord.FDate,&sYear,&sMonth,&sDay);
            sYear &= 0x00ff;

            (ApplVar.FTrain)?(k=4,z=ApplVar.ZCount[TRAINZNUM]):(k=3,z=ApplVar.ZCount[FISCALZNUM]); // ��ѵģʽ��,�ļ����а�����"/TRAIN" //

            for (i=j=0;ApplVar._a_txt[i];i++)
            {
                if ((ApplVar._a_txt[i]=='/') && ((++j)==k))
                    break;
            }
            if (j==k)
            {
                //������Z�����Ĵ�ӡʱ��Ϊ�ļ���
                i++;
                sprintf(ApplVar._a_txt+i,"%04d/%02x%02x%02x%02x%02x_c.txt",z,sYear,sMonth,sDay,
                                                              ApplVar.FiscalBuff.Fis_ClearRecord.FTime[0],
                                                              ApplVar.FiscalBuff.Fis_ClearRecord.FTime[1]);

                //ccr2017-11-15_z.txt������SHA1>>>>>>>>>>
                //New C file = all daily B files(aseds) + previous C file
                CalcAESDofCorD_txt('c',ApplVar._a_txt);
                //ccr2017-11-15<<<<<<<<<<<<<<<<<<<<<<<<<<<
                //Ϊ_s_txt�ļ�������SHA1ǩ������,��������_s.txt�ļ������һ��
                ApplVar._a_txt[strlen(ApplVar._a_txt)-5]='d';//��_c.txt���ƻ�Ϊ_d.txt
                //New D file = all daily E files aseds + previous D file
                j=CalcAESDofCorD_txt('d',ApplVar._a_txt);

#if SDCACHESIZE//ccr2018-03-16
                SDCachePushFileName('s',ApplVar._s_txt);
                SDCachePushData(SDRW_Buffer,j);
                sprintf(SDRW_Buffer,"%02x%02x%02x%02x%02x_s.txt",sYear,sMonth,sDay,
                                                              ApplVar.FiscalBuff.Fis_ClearRecord.FTime[0],
                                                              ApplVar.FiscalBuff.Fis_ClearRecord.FTime[1]);
                SDCachePushFileName('r',ApplVar._s_txt);//�ļ�����
                SDCachePushData(SDRW_Buffer,strlen(SDRW_Buffer)+1);
#else
#if defined(TWO_SDCARDS)
                ff_SelectSDisk(FS_SD_2ND);
                ff_OpenFileWrite(ApplVar._s_txt,SDRW_Buffer,j);
                ff_SelectSDisk(FS_SD);
#endif
                //��_d.txt��SHA1ǩ������д��_s.txt
                ff_OpenFileWrite(ApplVar._s_txt,SDRW_Buffer,j);
                sprintf(SDRW_Buffer,"%02x%02x%02x%02x%02x_s.txt",sYear,sMonth,sDay,
                                                              ApplVar.FiscalBuff.Fis_ClearRecord.FTime[0],
                                                              ApplVar.FiscalBuff.Fis_ClearRecord.FTime[1]);
#if defined(TWO_SDCARDS)
                ff_SelectSDisk(FS_SD_2ND);
                ff_RenameFile(ApplVar._s_txt,SDRW_Buffer); //��_s.txt�ļ�����ǰ����Z�����Ĵ�ӡʱ��
                ff_SelectSDisk(FS_SD);
#endif
                ff_RenameFile(ApplVar._s_txt,SDRW_Buffer); //��_s.txt�ļ�����ǰ����Z�����Ĵ�ӡʱ��
#endif
            }
        }
        break;
    }

}

/***************************************************************
 * ��LASTC_ALLB,LASTD_ALLE�����ļ���,�ָ�ASEDLastD,ASEDLastC
 *
 * @author EutronSoftware (2017-11-16)
 ***************************************************************/
void RecallLastASED()
{
    FRESULT result;
    char pBuf[SHA1HashSize];
    int l;

#if !defined(DEBUGBYPC)
    if (!MMC_CheckPresence() || SD_Init()!=SD_OK)
    {
        ApplVar.FiscalFlags = NOEJ;     // no EJ //
        ApplVar.ErrorNumber=ERROR_ID(CWXXI83);
        return;
    }
#if defined(TWO_SDCARDS)
    if (SD_Init_2nd()!=SD_OK)
    {
        ApplVar.FiscalFlags = NOEJ;     // no EJ //
        ApplVar.ErrorNumber=ERROR_ID(CWXXI112);
        return;
    }
#endif
#endif
//    PutsO("Get Size of SD>>");//ccr2017-06-14 testonly
    GetMMCSize(0);//ccr2017-06-19��ʱ�ϳ�
#if defined(TWO_SDCARDS)
    ff_SelectSDisk(FS_SD_2ND);
#endif
    ff_MountSDisk(FS_MOUNT);

    if (ff_OpenFileQ(LASTC_ALLB,FA_READ)==FR_OK)
    {
        l = ff_ReadFile(pBuf, SHA1HashSize,FS_BINARY);//��ȡԤ�����һ��_c.txt�е�AESD
        if (l==SHA1HashSize)
            memcpy(ApplVar.ASEDLastC,pBuf,SHA1HashSize);
        ff_CloseFile();
    }

    if (ff_OpenFileQ(LASTD_ALLE,FA_READ)==FR_OK)
    {
        l = ff_ReadFile(pBuf, SHA1HashSize,FS_BINARY);//��ȡԤ�����һ��_c.txt�е�AESD
        if (l==SHA1HashSize)
            memcpy(ApplVar.ASEDLastD,pBuf,SHA1HashSize);
        ff_CloseFile();
    }
    ff_MountSDisk(FS_RELEASE);

#if defined(TWO_SDCARDS)
     ff_SelectSDisk(FS_SD);
#endif
}
#endif//ccr2018-01-08<<<<<<<<<<<<<<<<<<<<<
/*********************************************************************************************
 * ���EJ�ռ�״��,�����ö�Ӧ��־
 *
 * @author EutronSoftware (2017-04-20)
 ********************************************************************************************/
WORD CheckEJSpace()
{
    static BYTE lessCount=0;

    if (ApplVar.EJSpaceFree[_FS_SD]<MMC_FULL)
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI88);
        //ApplVar.FiscalFlags = EJFULL;
    }
#if defined(TWO_SDCARDS)
    else if (ApplVar.EJSpaceFree[_FS_SD_2ND]<MMC_FULL)
    {
		ApplVar.ErrorNumber=ERROR_ID(CWXXI111);
        //ccr2017-06-21ApplVar.FiscalFlags = EJFULL;
    }
#endif
    else if (lessCount<3 && ApplVar.EJSpaceFree[_FS_SD]<MMC_LESS)
    {//ֻ����3��;
		ApplVar.ErrorNumber=ERROR_ID(CWXXI87);				// 40 KB left, only warn once
        //ccr2017-06-21ApplVar.FiscalFlags = EJLESS;
        lessCount++;
    }
//    else if (ApplVar.EJSpaceFree[_FS_SD_2ND]<MMC_LESS)
//    {
//        ApplVar.ErrorNumber=ERROR_ID(CWXXI87);				// 40 KB left, only warn once
//        ApplVar.FiscalFlags = EJLESS;
//    }
    return ApplVar.ErrorNumber;
}
/*********************************************************************************************
 * ����ʼһ�����վ�ʱ,����Z����������ļ���:
 * 1.����0269170320/TLD66000003/0269�ļ���
 * 2.����GGPS/TLD66000003/0269�ļ���
 * 3.����0269170320/TLD66000003/1703200269�ļ���
 * 4.����_a.txt�ļ����ƺ�_s.txt�ļ�����
 *
 * @author EutronSoftware (2017-04-17)
 *
 * @param ZNum :Z�������
 * @param ZDate :Z��������(YYMMDD)
 ********************************************************************************************/
void CreateNewFolders4Z()
{
    int i;
    WORD zNum;
    WORD recN;//�վݺ�

#if defined(CASE_GREECE)//ccr2018-01-11Ҫǩ��,�����ļ�
    ApplVar._s_txt[0]=ApplVar.FS_Current+'0';ApplVar._s_txt[1]=':';
#endif
    ApplVar._a_txt[0]=ApplVar.FS_Current+'0';ApplVar._a_txt[1]=':';
    if (ApplVar.FTrain)
    {
        recN=ApplVar.FisNumber.ReceiptNum[TRECEIPTS];
        zNum=ApplVar.ZCount[TRAINZNUM];
#if defined(CASE_GREECE)//ccr2018-01-11Ҫǩ��,�����ļ�
        if (recN==1)
            strcpy(ApplVar._s_txt+2,"/TRAIN");
#endif
        strcpy(ApplVar._a_txt+2,"/TRAIN");i=8;
    }
    else
    {
        recN=ApplVar.FisNumber.ReceiptNum[FRECEIPTS];//ApplVar.SaleReceipts
        zNum=ApplVar.ZCount[FISCALZNUM];
        i=2;
    }

    if (recN<=1)//ccr2017-11-17�п�����û�����۵�����´�ӡZ��������ʱrecN��0
    {//���վݺ�Ϊ1ʱ,�����µ�Z�й��ļ��к��ļ�
        ApplVar.ZDate=DateToYYMMDD();
#if defined(CASE_GREECE)//ccr2018-01-11Ҫǩ��,�����ļ�
#if (SDCACHESIZE)//ccr2018-02-23>>>>
        //1.����0269170320/TLD66000003/0269�ļ���
        //sprintf(ApplVar._s_txt+i,"/%04d%06d/%s/%04d",zNum,ApplVar.ZDate,ApplVar.ApprovalCode,zNum);
        //2.����GGPS/TLD66000003/0269�ļ��к��ļ�_s.txt
        sprintf(ApplVar._s_txt+i,"/GGPS/%s/%04d/_s.txt",ApplVar.ApprovalCode,zNum);
#else
        //1.����0269170320/TLD66000003/0269�ļ���
        sprintf(ApplVar._s_txt+i,"/%04d%06d/%s/%04d",zNum,ApplVar.ZDate,ApplVar.ApprovalCode,zNum);
#if defined(TWO_SDCARDS)
        ff_SelectSDisk(FS_SD_2ND);
        ff_CreateFolders(ApplVar._s_txt);
        ff_SelectSDisk(FS_SD);
#endif
        ff_CreateFolders(ApplVar._s_txt);
        //2.����GGPS/TLD66000003/0269�ļ��к��ļ�_s.txt
        sprintf(ApplVar._s_txt+i,"/GGPS/%s/%04d/_s.txt",ApplVar.ApprovalCode,zNum);
#if defined(TWO_SDCARDS)
        ff_MountSDisk(FS_SD_2ND);
        ff_OpenFile(ApplVar._s_txt,(FA_CREATE_ALWAYS+FA_WRITE));
        ff_CloseFile();
        ff_MountSDisk(FS_RELEASE);
#endif
        ff_MountSDisk(FS_SD);
        ff_OpenFile(ApplVar._s_txt,(FA_CREATE_ALWAYS+FA_WRITE));
        ff_CloseFile();
#endif
        ff_MountSDisk(FS_RELEASE);
#endif//ccr2018-02-23<<<<
    }
    SDCacheReset('R');//ccr2018-02-27
#if defined(CASE_GREECE)//ccr2018-02-27
    ApplVar.SHA1_Error = SHA1Reset(&ApplVar.SHA1);//ccr2018-02-27
#endif
    if (recN>0)//ccr2017-11-17�п�����û�����۵�����´�ӡZ��������ʱrecN��0�����봴��a.txt�ļ�
    {
#if (SDCACHESIZE)//ccr2018-02-23>>>>
        //3.����0269170320/TLD66000003/1703200269/0001/_a.txt�ļ�
        sprintf(ApplVar._a_txt+i,"/%04d%06d/%s/%06d%04d/%04d/_a.txt",
                                zNum,
                                ApplVar.ZDate,
                                ApplVar.ApprovalCode,
                                ApplVar.ZDate,
                                zNum,
                                recN);

        SDCachePushFileName('a',ApplVar._a_txt);

/*****  �ᵼ���ظ�д��Ʊͷ����??? ************************
        //��Ʊͷд��EJ�վ��ļ�CACHE��,�������㹻�Ŀռ䱣������
        for (i=0;i<HEADLINES;i++)
        {
            if (ApplVar.TXT.Header[i][0])
            {
                strcpy(SDRW_Buffer,ApplVar.TXT.Header[i]);
                zNum = strlen(SDRW_Buffer);
                AppendCRLF(SDRW_Buffer,zNum);
                RamOffSet=ApplVar.SDCache.Length+ADDR_SDCACHE;
                WriteRam(SDRW_Buffer,zNum);
                ApplVar.SDCache.Length+=zNum;
            }
            else
                break;
        }
********************************************************/
#else
        //3.����0269170320/TLD66000003/1703200269/0001�ļ���
        sprintf(ApplVar._a_txt+i,"/%04d%06d/%s/%06d%04d/%04d",
                                zNum,
                                ApplVar.ZDate,
                                ApplVar.ApprovalCode,
                                ApplVar.ZDate,
                                zNum,
                                recN);
#if defined(TWO_SDCARDS)
        ff_SelectSDisk(FS_SD_2ND);
        ff_CreateFolders(ApplVar._a_txt);
        ff_SelectSDisk(FS_SD);
#endif
        ff_CreateFolders(ApplVar._a_txt);
        strcat(ApplVar._a_txt,"/_a.txt");//�����վ������ļ�����

#if defined(TWO_SDCARDS)
        for (ApplVar.FS_Current=FS_SD;ApplVar.FS_Current<=FS_SD_2ND;ApplVar.FS_Current++)
#endif
        {
            ff_MountSDisk(ApplVar.FS_Current);
            //�����վ��ļ�
            ff_OpenFileQ(ApplVar._a_txt,(FA_CREATE_ALWAYS+FA_WRITE));

//#if defined(CASE_GREECE)//ccr2018-01-08�����վݼ���SHA1ǩ��
//            if (ApplVar.CentralLock!=Z)//ccr2017-11-15_z.txt������SHA1
//            {
//#if defined(TWO_SDCARDS)
//                if (ApplVar.FS_Current==FS_SD)
//#endif
//                    ApplVar.SHA1_Error = SHA1Reset(&ApplVar.SHA1);
//            }
//#endif
            //��Ʊͷд��EJ�վ��ļ���
            for (i=0;i<HEADLINES;i++)
            {
                if (ApplVar.TXT.Header[i][0])
                {
                    strcpy(SDRW_Buffer,ApplVar.TXT.Header[i]);
                    zNum = strlen(SDRW_Buffer);
                    AppendCRLF(SDRW_Buffer,zNum);
                    ff_WriteFile(SDRW_Buffer,zNum);
#if defined(CASE_GREECE)//ccr2018-01-08�����վݼ���SHA1ǩ��
                    if (ApplVar.CentralLock!=Z)//ccr2017-11-15_z.txt������SHA1
                    {
#if defined(TWO_SDCARDS)
                        if (ApplVar.FS_Current==FS_SD)
#endif
                            ComputeASEDS(SDRW_Buffer,zNum);
                    }
#endif
                }
                else
                    break;
            }
            ff_CloseFile();
            ff_MountSDisk(FS_RELEASE);
        }
#if defined(TWO_SDCARDS)
         ff_SelectSDisk(FS_SD);
#endif
#endif  //SDCACHESIZE//ccr2017-06-16<<<<<<<<<<<<<<<<<
    }
}

/*************************************************************
 * ����ӡZ����ʱ,����Z������_z.txt�ļ�
 *
 * @author EutronSoftware (2017-05-03)
 *
 * @return BYTE :=true,��Z��������;=false,��Z��������
 ***************************************************************/
BYTE CreateFileZ_TXT()
{
    int  i;
    WORD n,z;

    if (ApplVar.FTrain)
        n=ApplVar.FisNumber.ReceiptNum[TRECEIPTS]+1;
    else
        n=ApplVar.FisNumber.ReceiptNum[FRECEIPTS]+1;//ApplVar.SaleReceipts
    z=(n>1);
    if (!z)
    {//ccr2017-11-17�������վ�ʱҲ��ӡZ����
        z = (WaitForYesNo(MSG_ZEROZREPORT,0,1,true)=='Y');
        if (z)  CreateNewFolders4Z();//ccr2017-11-17�������վ�ʱҲ��ӡZ����,���ȴ�����ص��ļ���
        ClearLine2();
    }

    if (z)//ccr2017-08-01 �������վ�ʱҲ��ӡZ���� (n>1,����������,��Z������Ҫ��ӡ.�����µ�Z�й��ļ��к��ļ�)
    {
        ApplVar._a_txt[0]=ApplVar.FS_Current+'0';ApplVar._a_txt[1]=':';

        if (ApplVar.FTrain)
        {
            z = ApplVar.ZCount[TRAINZNUM];
            strcpy(ApplVar._a_txt+2,"/TRAIN");i=8;
        }
        else
        {
            z=ApplVar.ZCount[FISCALZNUM];
            i=2;
        }
        //����0269170320/TLD66000003/1703200269/0001/_z.txt�ļ�
        sprintf(ApplVar._a_txt+i,"/%04d%06d/%s/%06d%04d/%04d/_z.txt",
                                z,
                                ApplVar.ZDate,
                                ApplVar.ApprovalCode,
                                ApplVar.ZDate,
                                z,
                                n);
//ccr2018-03-16>>>>>>SDCache>>>
#if (SDCACHESIZE)
        if (ApplVar.SDCache.Type==0)
        {
             SDCacheReset('Z');//ccr2018-03-19
        }
#if defined(CASE_GREECE)//ccr2018-03-19
        ApplVar.SHA1_Error = SHA1Reset(&ApplVar.SHA1);
#endif
        SDCachePushFileName('z',ApplVar._a_txt);
#else
#if defined(TWO_SDCARDS)
        //����Z�����ļ�
        for (ApplVar.FS_Current=FS_SD;ApplVar.FS_Current<=FS_SD_2ND;ApplVar.FS_Current++)
#endif
        {
            ff_MountSDisk(ApplVar.FS_Current);
            ff_OpenFile(ApplVar._a_txt,(FA_CREATE_ALWAYS+FA_WRITE));
            ff_CloseFile();
            ff_MountSDisk(FS_RELEASE);
        }
#if defined(TWO_SDCARDS)
        ff_SelectSDisk(FS_SD);
#endif
#endif
//ccr2018-03-16<<<<<<<<<<<<<<<<<<<<<<<<<
       StoreEJStart();
//     if (ApplVar.FTrain)
//         PrintStr_Center((char*)MsgTEMPRECEIPTSTART,true);
//     else
//         PrintStr_Center((char*)MsgRECEIPTSTART,true);

        return true;
    }
    else//û������ʱ,����ӡZ����
        return false;
}
/*********************************************************************************************
 * ɾ��Z����������ļ���
 *
 * @author EutronSoftware (2017-04-17)
 *
 * @param ZNum :Z�������
 * @param ZDate :Z��������(YYMMDD)
 ********************************************************************************************/
void DeleteZFolders(WORD ZNum,ULONG ZDate)
{
    char sFolder[32];

    sprintf(sFolder,"%d:/%04d%06d",ApplVar.FS_Current,ZNum,ZDate);
    //xprintf(">>>>The 1st-Delete Folder:%s\n",SysBuf);
    ff_DeleteTree(sFolder);//ɾ��0269170320�ļ���
#if defined(CASE_GREECE)//ccr2018-01-11Ҫǩ��,�����ļ�
    sprintf(sFolder,"%d:/GGPS/%s/%04d",ApplVar.FS_Current,ApplVar.ApprovalCode,ZNum);
//    xprintf(">>>>The 2nd-Delete Folder:%s\n",SysBuf);
    ff_DeleteTree(sFolder);//ɾ��GGPS/TLD66000003/0269�ļ���
#endif
}

/************************************************************************
 *  ��ȡSD������Ϣ,����ȡ��BiosCmd_SD_ReadInfo,��������ȷ��SD���Ƿ����
 *
 * @author EutronSoftware (2017-06-19)
 *
 * @param fsSD :FS_SD��FS_SD_2ND
 * @return BYTE:true-��ȡ�ɹ�
 ***********************************************************************/
BYTE ReadSDInfor(BYTE fsSD)
{
#if defined(DEBUGBYPC)
    if (fsSD==FS_SD)
    {
        SDCardInfo.SD_cid.ManufacturerID='E';    /*!< ManufacturerID */
        SDCardInfo.SD_cid.OEM_AppliID=0x0001;    /*!< OEM/Application ID */
        SDCardInfo.SD_cid.ProdSN=0x0003;         /*!< Product Serial Number */
        SDCardInfo.SD_cid.ManufactDate=0x0101;   /*!< Manufacturing Date */
    }
    else
    {
        SDCardInfo.SD_cid.ManufacturerID='E';/*!< ManufacturerID */
        SDCardInfo.SD_cid.OEM_AppliID=0x8001;    /*!< OEM/Application ID */
        SDCardInfo.SD_cid.ProdSN=0x8001;              /*!< Product Serial Number */
        SDCardInfo.SD_cid.ManufactDate=0x0601;  /*!< Manufacturing Date */
    }
#else
    if (fsSD==FS_SD)
    {
        if((SD_Detect()!= SD_PRESENT) || SD_GetCardInfo(&SDCardInfo) != SD_OK)
             return false;
    }
    else if (SD_GetCardInfo_2nd(&SDCardInfo) != SD_OK)
        return false;
#endif
    return true;

}
/********************************************************************
 * ����ȡ���е����Z�����ļ����͸���̨ :
 * 1._s.txt:λ���ļ���GGPS/TLD66000003/0269��
 * 2._z.txt:λ��0269170320/TLD66000003/1703200269/0004��
 * 3._c.txt��_d.txt:λ���ļ���0269170320/TLD66000003/0269��
 *
 * @author EutronSoftware (2017-06-28)
 *
 * @return BYTE
 ********************************************************************/
BYTE  SendFiscalZData()
{

     WORD sYear,sYearF,sDate;
     BYTE sMonthF,sDayF,sMonth,sDay;
     FRESULT result;
     int32_t bw;
     int i,fLen;

     char sFileName[_MAX_PATH];

#if defined(TWO_SDCARDS)
    ff_MountSDisk(FS_SD_2ND);
#else
    ff_MountSDisk(FS_SD);
#endif

#if defined(CASE_GREECE)//ccr2018-01-11Ҫǩ��,�����ļ�
    for (i=0;i<4;i++)//һ������4���ļ�
    {
        switch (i)
        {
        case 0://1.����_s.txt�ļ�,λ���ļ���GGPS/TLD66000003/0269��
            DecordDate(ApplVar.FiscalBuff.Fis_ClearRecord.FDate,&sYear,&sMonth,&sDay);
            sprintf(sFileName,"%d:/GGPS/%s/%04d/%02x%02x%02x%02x%02x_s.txt",ApplVar.FS_Current,
                                    ApplVar.ApprovalCode,
                                    ApplVar.FiscalBuff.Fis_ClearRecord.FCount,
                                    sYear & 0xff,sMonth,sDay,
                                    ApplVar.FiscalBuff.Fis_ClearRecord.FTime[0],
                                    ApplVar.FiscalBuff.Fis_ClearRecord.FTime[1]);
            break;
        case 1://2.����_c.txt�ļ�,λ���ļ���0269170320/TLD66000003/0269��
            DecordDate(ApplVar.FiscalBuff.Fis_ClearRecord.FZDateFrom,&sYearF,&sMonthF,&sDayF);
            sprintf(sFileName,"%d:/%04d%02x%02x%02x/%s/%04d/%02x%02x%02x%02x%02x_c.txt",ApplVar.FS_Current,
                                    ApplVar.FiscalBuff.Fis_ClearRecord.FCount,
                                    sYearF & 0xff,sMonthF,sDayF,
                                    ApplVar.ApprovalCode,
                                    ApplVar.FiscalBuff.Fis_ClearRecord.FCount,
                                    sYear & 0xff,sMonth,sDay,
                                    ApplVar.FiscalBuff.Fis_ClearRecord.FTime[0],
                                    ApplVar.FiscalBuff.Fis_ClearRecord.FTime[1]);
            break;
        case 2://3.����_d.txt�ļ�,λ���ļ���0269170320/TLD66000003/0269��
            sFileName[fLen-5]='d';
            break;
        case 3://3.����_z.txt�ļ�,λ���ļ���0269170320/TLD66000003/1703200269/0004��
            sprintf(sFileName,"%d:/%04d%02x%02x%02x/%s/%02x%02x%02x%04d/%04d/_z.txt",ApplVar.FS_Current,
                                    ApplVar.FiscalBuff.Fis_ClearRecord.FCount,
                                    sYearF & 0xff,sMonthF,sDayF,
                                    ApplVar.ApprovalCode,
                                    sYearF & 0xff,sMonthF,sDayF,
                                    ApplVar.FiscalBuff.Fis_ClearRecord.FCount,
                                    ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice[FRECEIPTS]+1);
            break;
        }
#else//ccr2018-01-08��ǩ��,ֻ���ʹ��ļ�
    {
        //����_z.txt�ļ�,λ���ļ���0269170320/TLD66000003/1703200269/0004��
        sprintf(sFileName,"%d:/%04d%02x%02x%02x/%s/%02x%02x%02x%04d/%04d/_z.txt",ApplVar.FS_Current,
                                ApplVar.FiscalBuff.Fis_ClearRecord.FCount,
                                sYearF & 0xff,sMonthF,sDayF,
                                ApplVar.ApprovalCode,
                                sYearF & 0xff,sMonthF,sDayF,
                                ApplVar.FiscalBuff.Fis_ClearRecord.FCount,
                                ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice[FRECEIPTS]+1);
#endif

        fLen=strlen(sFileName);
        SDRW_Buffer[0]='E';SDRW_Buffer[1]='J';SDRW_Buffer[2]='N';
        memcpy(SDRW_Buffer+3,sFileName,fLen+1);
        SendRecord(SDRW_Buffer,fLen+1+3);
        /* ���ļ� */
        result = ff_OpenFileQ(sFileName, FA_OPEN_EXISTING | FA_READ);
        if (result ==  FR_OK)
        {
            /* ��ȡ�ļ� */

            while (!ff_EofFile())
            {
                SDRW_Buffer[0]='E';SDRW_Buffer[1]='J';SDRW_Buffer[2]='D';
                bw = ff_ReadFile(SDRW_Buffer+3,250,FS_BINARY);
                if (bw>0)
                {
                    SendRecord(SDRW_Buffer,bw+3);
                }
                else
                {
                    break;
                }
            }
        }
        /* �ر��ļ�*/
        ff_CloseFile();
        *((WORD *)SDRW_Buffer) = 0;  /* 0 means end */
        SendRecord(SDRW_Buffer, 2);   /* send end record */
    }
    ff_MountSDisk(FS_RELEASE);

}
/*********************************************************************
 * ��ָ���������EJ˰�����ݷ��͸�������
 *
 * @author EutronSoftware (2017-06-28)
 *
 * @param zDate:yymmdd
 * @param sType:'J'=SD�ڿ��ϵ�EJ����;'F'-FM�е�˰������
 *
 * @return BYTE :=true,�����ݷ���;=false:�����ݷ���
 ********************************************************************/
BYTE SendEJByDate(ULONG zDate,BYTE sType)
{
     WORD sDate;
     ULONG sFMOffset;
     BYTE sRet=false;

    sDate=EncordDECDDate(zDate/10000,(zDate/100)%100,zDate%100);
    sFMOffset= ApplVar.FiscalHead.ClearP;//ֱ��ָ��DAYSBEFOR��ǰ�ļ�¼
    for (sFMOffset=FISDATAADDR;sFMOffset<=ApplVar.FiscalHead.ClearP;sFMOffset+=FISRECORDLEN)
    {
        if (!Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,sFMOffset,FISRECORDLEN))
        {
            ApplVar.FiscalFlags = FMERROR; ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
            break ;
        }
        if (ApplVar.FiscalBuff.Fis_ClearRecord.FunN==FISCLEARLOG)
        {//Z���ݷ�����������
            if (ApplVar.FiscalBuff.Fis_ClearRecord.FZDateFrom==sDate)
            {
                if (sType=='F')
                {
                    SDRW_Buffer[0]='E';SDRW_Buffer[1]='F';SDRW_Buffer[2]='D';
                    memcpy(SDRW_Buffer+3,(BYTE*)&ApplVar.FiscalBuff.Fis_ClearRecord,FISRECORDLEN);
                    SendRecord(SDRW_Buffer,FISRECORDLEN+3);
                }
                else
                    SendFiscalZData();
                sRet=true;
            }
            else if (ApplVar.FiscalBuff.Fis_ClearRecord.FZDateFrom>sDate)
                break;
        }
    }
    return sRet;
}

/*********************************************************************
 *  ��ָ��Z�����EJ˰�����ݷ��͸�������
 *
 * @author EutronSoftware (2017-06-28)
 *
 * @param zNumber:Z������
 * @param sType:'J'=SD�ڿ��ϵ�EJ����;'F'-FM�е�˰������
 *
 * @return BYTE :=true,�����ݷ���;=false:�����ݷ���
 ********************************************************************/
BYTE SendEJByZNumber(WORD zNumber,BYTE sType)
{
     ULONG sFMOffset;
     BYTE sRet=false;

    for (sFMOffset=FISDATAADDR;sFMOffset<=ApplVar.FiscalHead.ClearP;sFMOffset+=FISRECORDLEN)
    {
        if (!Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,sFMOffset,FISRECORDLEN))
        {
            ApplVar.FiscalFlags = FMERROR; ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
            break ;
        }
        if (ApplVar.FiscalBuff.Fis_ClearRecord.FunN==FISCLEARLOG)
        {
            if (ApplVar.FiscalBuff.Fis_ClearRecord.FCount==zNumber)
            {//Z���ݷ�������
                if (sType=='F')
                {
                    SDRW_Buffer[0]='E';SDRW_Buffer[1]='F';SDRW_Buffer[2]='Z';
                    memcpy(SDRW_Buffer+3,(BYTE*)&ApplVar.FiscalBuff.Fis_ClearRecord,FISRECORDLEN);
                    SendRecord(SDRW_Buffer,FISRECORDLEN+3);
                }
                else
                    SendFiscalZData();
                sRet=true;
                break;
            }
            else if (ApplVar.FiscalBuff.Fis_ClearRecord.FCount>zNumber)
                break;
        }
    }
    return sRet;
}
/**
 * ö���ڿ��ϵ������ļ��к��ļ�
 *
 * @author EutronSoftware (2017-06-29)
 */
void ListFoldersFiles(BYTE sType)
{
#if defined(TWO_SDCARDS)
        ff_SelectSDisk(FS_SD_2ND);
#else
        ff_SelectSDisk(FS_SD);
#endif
        SDRW_Buffer[0]=ApplVar.FS_Current+'0';//ccr2017-06-15
        SDRW_Buffer[1]=':';SDRW_Buffer[2]=0;
#if defined(DEBUGBYPC)
        sprintf(SysBuf,"[Scan Folder:%s]\n",SDRW_Buffer);
        SendString(SysBuf,strlen(SysBuf));
#else
        xprintf("[Scan Folder:%s]\n",SDRW_Buffer);
#endif
        if (sType=='F')
        {
#if !defined(DEBUGBYPC)
            ff_ListFolder(SDRW_Buffer);
#endif
        }
        else
        {
            ff_MountSDisk(FS_MOUNT);
            fsSDiskP->Files=fsSDiskP->Folders=fsSDiskP->FilesSpace=0;
            ff_ScanFiles(SDRW_Buffer,fsSDiskP);
    #if defined(DEBUGBYPC)
            sprintf(SysBuf,"Folders:%d\t  Files:%d\t FilesSpace:%lu\n",fsSDiskP->Folders,fsSDiskP->Files,fsSDiskP->FilesSpace);
            SendString(SysBuf,strlen(SysBuf));
    #else
            xprintf("Folders:%d\t  Files:%d\t FilesSpace:%lu\n",fsSDiskP->Folders,fsSDiskP->Files,fsSDiskP->FilesSpace);
    #endif
            ff_MountSDisk(FS_RELEASE);
    #if defined(TWO_SDCARDS)
            ff_SelectSDisk(FS_SD);
    #endif
        }
        CWORD(SDRW_Buffer[0]) = 0;
        SendString(SDRW_Buffer,2);
}
/**
 *
 *
 * @author EutronSoftware (2017-07-04)
 */
void  PrintEJReceiptDate()
{
    ULONG sFMOffset,sDateTo;
    WORD sYearF,sYear[2];
    BYTE sMonthF,sDayF,sMonth[2],sDay[2];
    FRESULT result;
    FILINFO finfo;
    int32_t bw;
    int i;
    BYTE sFound=false;

    char sFileName[_MAX_PATH];

    switch (TIME_DATE)
    {
        default:
        case 0://day,DD-MM-YYYY//
            sFMOffset = (BCDtoDEC(Now.day)*100000000+BCDtoDEC(Now.month)*1000000+BCDtoDEC(Now.year & 0xff)*10000)+TimeToHHMM();
            break;
        case 1://day,MM-DD-YYYY//
            sFMOffset = (BCDtoDEC(Now.month)*100000000+BCDtoDEC(Now.day)*1000000+BCDtoDEC(Now.year & 0xff)*10000)+TimeToHHMM();
            break;
        case 2://day,YYYY-MM-DD//
            sFMOffset = DateToYYMMDD()*10000+TimeToHHMM();
            break;
    }
    {
        if (InputFromTo(TIMEFROM,sFMOffset)!=EXITKey)
        {//LogDefine.RecNumFrΪZ����,LogDefine.RecNumToΪ�վݺ���

            sFMOffset = LogDefine.RecNumFr/10000;
            sDateTo=LogDefine.RecNumTo/10000;
            switch (TIME_DATE)
            {
                default:
                case 0://day,DD-MM-YYYY//
                    sYear[0]=sFMOffset % 100;sFMOffset/=100;
                    sMonth[0]=sFMOffset%100; sDay[0]=sFMOffset/100;

                    sYear[1]=sDateTo % 100;sDateTo/=100;
                    sMonth[1]=sDateTo%100; sDay[1]=sDateTo/100;
                    break;
                case 1://day,MM-DD-YYYY//
                    sYear[0]=sFMOffset % 100;sFMOffset/=100;
                    sMonth[0]=sFMOffset/100; sDay[0]=sFMOffset%100;

                    sYear[1]=sDateTo % 100;sDateTo/=100;
                    sMonth[1]=sDateTo/100; sDay[1]=sDateTo%100;
                    break;
                case 2://day,YYYY-MM-DD//
                    sDay[1]=sDateTo % 100;sDateTo/=100;
                    sMonth[1]=sDateTo%100;sYear[1]=sDateTo/100;
                    break;
            }
            sFMOffset = LogDefine.RecNumFr%10000;
            sDateTo=LogDefine.RecNumTo%10000;

            LogDefine.DateFr=EncordDECDDate(sYear[0],sMonth[0],sDay[0]);
            LogDefine.DateTo=EncordDECDDate(sYear[1],sMonth[1],sDay[1]);
            LogDefine.RecNumFr=sYear[0]*100000000+sMonth[0]*1000000+sDay[0]*10000+sFMOffset;//yymmddhhmm
            LogDefine.RecNumTo=sYear[1]*100000000+sMonth[1]*1000000+sDay[1]*10000+sDateTo;  //yymmddhhmm


#if defined(TWO_SDCARDS)
            ff_MountSDisk(FS_SD_2ND);
#else
            ff_MountSDisk(FS_SD);
#endif

            for (sFMOffset=FISDATAADDR;sFMOffset<=ApplVar.FiscalHead.ClearP;sFMOffset+=FISRECORDLEN)
            {
                if (KbHit() && Getch()==CLEARKey)//CLEAR any key for stop
                    break;

                if (!Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,sFMOffset,FISRECORDLEN))
                {
                    ApplVar.FiscalFlags = FMERROR; ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
                    break ;
                }
                if (ApplVar.FiscalBuff.Fis_ClearRecord.FunN==FISCLEARLOG)
                {
                    if (ApplVar.FiscalBuff.Fis_ClearRecord.FZDateFrom>=LogDefine.DateFr &&
                        ApplVar.FiscalBuff.Fis_ClearRecord.FZDateFrom<=LogDefine.DateTo)
                    {//Z���ݷ�������

                        for (i=1;i<=ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice[FRECEIPTS];i++)
                        {
                           //����_a.txt�ļ�,λ���ļ���0269170320/TLD66000003/1703200269/0004��
                           //DecordDate(ApplVar.FiscalBuff.Fis_ClearRecord.FDate,&sYear,&sMonth,&sDay);
                           DecordDate(ApplVar.FiscalBuff.Fis_ClearRecord.FZDateFrom,&sYearF,&sMonthF,&sDayF);
                           sprintf(sFileName,"%d:/%04d%02x%02x%02x/%s/%02x%02x%02x%04d/%04d/_a.txt",ApplVar.FS_Current,
                                                           ApplVar.FiscalBuff.Fis_ClearRecord.FCount,
                                                           sYearF & 0xff,sMonthF,sDayF,
                                                           ApplVar.ApprovalCode,
                                                           sYearF & 0xff,sMonthF,sDayF,
                                                           ApplVar.FiscalBuff.Fis_ClearRecord.FCount,
                                                           i);

                           result=f_stat(sFileName,&finfo);//
                           if (result== FR_OK)
                           {
                               sDateTo=(((finfo.fdate >> 9) + 1980)%100)*100000000+((finfo.fdate >> 5) & 15)*1000000+(finfo.fdate & 31)*10000+(finfo.ftime >> 11)*100+((finfo.ftime >> 5) & 63);
                               if (sDateTo>=LogDefine.RecNumFr && sDateTo<=LogDefine.RecNumTo)
                               {
                                   /* ���ļ� */
                                   result = ff_OpenFileQ(sFileName, FA_OPEN_EXISTING | FA_READ | FA_TEXT);
                                   if (result ==  FR_OK)
                                   {
                                       /* ��ȡ�ļ� */
                                       PrintStr_Center((char*)MsgEXPLORERBEGIN,true);
                                       sFound=true;
                                       while (!ff_EofFile())
                                       {
                                           bw = ff_ReadFile(SDRW_Buffer,50,FS_TEXT);
                                           if (bw>0)
                                           {
                                               (bw>PRTLEN)?(bw=PRTLEN):(SDRW_Buffer[bw]==0x0a?(bw--):(bw=bw));
                                               SDRW_Buffer[bw]=0;
                                               RJPrint(0,SDRW_Buffer);
                                           }
                                           else
                                           {
                                               break;
                                           }
                                       }
                                       PrintStr_Center((char*)MsgEXPLOREREND,true);
                                       PrintLine('.');
                                   }
                                   /* �ر��ļ�*/
                                   ff_CloseFile();
                               }
                           }
                        }
                    }
                    else if (ApplVar.FiscalBuff.Fis_ClearRecord.FZDateFrom>LogDefine.DateTo)
                        break;
                }
            }
            ff_MountSDisk(FS_RELEASE);
            if (sFound)
                RFeed(PREHEADER+2);

        }
//        else
//            EXIT;
    }

}

/****************************************************
 * ����Z������վݺ����ѯ�վ�
 *
 * @author EutronSoftware (2017-07-04)
 **************************************************/
void PrintEJReceiptNum()
{
    ULONG sFMOffset;
    WORD sYear,sYearF;
    BYTE sMonthF,sDayF,sMonth,sDay;
    FRESULT result;
    int32_t bw;
    BYTE sFound=false;

    char sFileName[_MAX_PATH];

    sFMOffset = 9999;
    {
        if (InputFromTo(ZNumFORRECEIPT,sFMOffset)!=EXITKey)
        {//LogDefine.RecNumFrΪZ����,LogDefine.RecNumToΪ�վݺ���

#if defined(TWO_SDCARDS)
            ff_MountSDisk(FS_SD_2ND);
#else
            ff_MountSDisk(FS_SD);
#endif

            for (sFMOffset=FISDATAADDR;sFMOffset<=ApplVar.FiscalHead.ClearP;sFMOffset+=FISRECORDLEN)
            {
                if (KbHit() && Getch()==CLEARKey)//CLEAR any key for stop
                    break;
                if (!Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,sFMOffset,FISRECORDLEN))
                {
                    ApplVar.FiscalFlags = FMERROR; ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
                    break ;
                }
                if (ApplVar.FiscalBuff.Fis_ClearRecord.FunN==FISCLEARLOG)
                {
                    if (ApplVar.FiscalBuff.Fis_ClearRecord.FCount==LogDefine.RecNumFr &&
                        ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice[FRECEIPTS]>=LogDefine.RecNumTo)
                    {//Z���ݷ�������

                       //����_a.txt�ļ�,λ���ļ���0269170320/TLD66000003/1703200269/0004��
                       //DecordDate(ApplVar.FiscalBuff.Fis_ClearRecord.FDate,&sYear,&sMonth,&sDay);
                       DecordDate(ApplVar.FiscalBuff.Fis_ClearRecord.FZDateFrom,&sYearF,&sMonthF,&sDayF);
                       sprintf(sFileName,"%d:/%04d%02x%02x%02x/%s/%02x%02x%02x%04d/%04d/_a.txt",ApplVar.FS_Current,
                                                       ApplVar.FiscalBuff.Fis_ClearRecord.FCount,
                                                       sYearF & 0xff,sMonthF,sDayF,
                                                       ApplVar.ApprovalCode,
                                                       sYearF & 0xff,sMonthF,sDayF,
                                                       ApplVar.FiscalBuff.Fis_ClearRecord.FCount,
                                                       LogDefine.RecNumTo);
                       /* ���ļ� */
                       result = ff_OpenFileQ(sFileName, FA_OPEN_EXISTING | FA_READ | FA_TEXT);
                       if (result ==  FR_OK)
                       {
                           /* ��ȡ�ļ� */
                           PrintStr_Center((char*)MsgEXPLORERBEGIN,true);
                           sFound=true;
                           while (!ff_EofFile())
                           {
                               bw = ff_ReadFile(SDRW_Buffer,50,FS_TEXT);
                               if (bw>0)
                               {
                                   (bw>PRTLEN)?(bw=PRTLEN):(SDRW_Buffer[bw]==0x0a?(bw--):(bw=bw));
                                   SDRW_Buffer[bw]=0;
                                   RJPrint(0,SDRW_Buffer);
                               }
                               else
                               {
                                   break;
                               }
                           }
                           PrintStr_Center((char*)MsgEXPLOREREND,true);
                           PrintLine('.');
                       }
                       /* �ر��ļ�*/
                       ff_CloseFile();
                    }
                    else if (ApplVar.FiscalBuff.Fis_ClearRecord.FCount>LogDefine.RecNumFr)
                        break;
                }
            }
            ff_MountSDisk(FS_RELEASE);
            if (sFound)
                RFeed(PREHEADER+2);
        }
//        else
//            EXIT;
    }

}

/***********************************************
 * ��ѯSD���ϵ��վ�����
 *
 * @author EutronSoftware (2017-07-04)
 ***********************************************/
void  PrintEJReceipt()
{
    switch(ListItems(EJBYDATETIME,0,Msg[EJPrintReceipt].str,false,true))
    {
    case (EJBYDATETIME-EJBYDATETIME+1):       //�������ڲ�ѯ�����վ�
        PrintEJReceiptDate();
        break;
    case (EJBYZNUMBER-EJBYDATETIME+1):       //���ݺ���(ʲô����)��ѯ�����վ�
        PrintEJReceiptNum();
        break;
//    case It_EXIT:
    default:
        //EXIT;
        break;
    }
    EXIT;

}

/**********************************************************
 * ͨ������Z���뷶Χ��ѯEJ�е�Z��������
 *
 * @author EutronSoftware (2017-07-04)
 * @param sType:'N'=����Z�����ѯ;'D'-�������ڲ�ѯ
 **********************************************************/
void PrintEJLOGZReport(BYTE sType)
{
    ULONG sFMOffset=0;
    WORD sYear,sYearF;
    BYTE sMonthF,sDayF,sMonth,sDay;
    FRESULT result;
    int32_t bw;
    int i,fLen;
    BYTE sFound=false;

    char sFileName[_MAX_PATH];

    if  (sType=='N')
        sFMOffset = ApplVar.ZCount[FISCALZNUM];
    else if (sType=='D')
        sFMOffset = BCDtoDEC(Now.year>>8)*1000000 + DateToYYMMDD();
    if (sFMOffset !=0 )
    {
        if (sType=='N' && InputFromTo(RECEIPTFROM,sFMOffset)!=EXITKey
            ||
            sType=='D' && InputFromTo(DATEFROM,sFMOffset)!=EXITKey)
        {

#if defined(TWO_SDCARDS)
            ff_MountSDisk(FS_SD_2ND);
#else
            ff_MountSDisk(FS_SD);
#endif

            for (sFMOffset=FISDATAADDR;sFMOffset<=ApplVar.FiscalHead.ClearP;sFMOffset+=FISRECORDLEN)
            {
                if (KbHit() && Getch()==CLEARKey)//CLEAR any key for stop
                    break;
                if (!Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,sFMOffset,FISRECORDLEN))
                {
                    ApplVar.FiscalFlags = FMERROR; ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
                    break ;
                }
                if (ApplVar.FiscalBuff.Fis_ClearRecord.FunN==FISCLEARLOG)
                {
                    if (sType=='N' && ApplVar.FiscalBuff.Fis_ClearRecord.FCount>=LogDefine.RecNumFr &&
                        ApplVar.FiscalBuff.Fis_ClearRecord.FCount<=LogDefine.RecNumTo
                        ||
                        sType=='D' && ApplVar.FiscalBuff.Fis_ClearRecord.FZDateFrom>=LogDefine.DateFr &&
                        ApplVar.FiscalBuff.Fis_ClearRecord.FZDateFrom<=LogDefine.DateTo)
                    {//Z���ݷ�������

                       //����_z.txt�ļ�,λ���ļ���0269170320/TLD66000003/1703200269/0004��
                       //DecordDate(ApplVar.FiscalBuff.Fis_ClearRecord.FDate,&sYear,&sMonth,&sDay);
                       DecordDate(ApplVar.FiscalBuff.Fis_ClearRecord.FZDateFrom,&sYearF,&sMonthF,&sDayF);
                       sprintf(sFileName,"%d:/%04d%02x%02x%02x/%s/%02x%02x%02x%04d/%04d/_z.txt",ApplVar.FS_Current,
                                                       ApplVar.FiscalBuff.Fis_ClearRecord.FCount,
                                                       sYearF & 0xff,sMonthF,sDayF,
                                                       ApplVar.ApprovalCode,
                                                       sYearF & 0xff,sMonthF,sDayF,
                                                       ApplVar.FiscalBuff.Fis_ClearRecord.FCount,
                                                       ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice[FRECEIPTS]+1);
                       /* ���ļ� */
                       result = ff_OpenFileQ(sFileName, FA_OPEN_EXISTING | FA_READ | FA_TEXT);
                       if (result ==  FR_OK)
                       {
                           /* ��ȡ�ļ� */
                           PrintStr_Center((char*)MsgEXPLOREZBEGIN,true);
                           while (!ff_EofFile())
                           {
                               bw = ff_ReadFile(SDRW_Buffer,50,FS_TEXT);
                               if (bw>0)
                               {
                                   (bw>PRTLEN)?(bw=PRTLEN):(SDRW_Buffer[bw]==0x0a?(bw--):(bw=bw));
                                   SDRW_Buffer[bw]=0;
                                   RJPrint(0,SDRW_Buffer);
                               }
                               else
                               {
                                   break;
                               }
                           }
                           PrintStr_Center((char*)MsgEXPLOREZEND,true);
                           sFound=true;
                           PrintLine('.');
                       }
                       /* �ر��ļ�*/
                       ff_CloseFile();
                    }
                    else if (sType=='N' && ApplVar.FiscalBuff.Fis_ClearRecord.FCount>LogDefine.RecNumTo
                             ||
                             sType=='D' && ApplVar.FiscalBuff.Fis_ClearRecord.FZDateFrom>LogDefine.DateTo)
                        break;
                }
            }
            ff_MountSDisk(FS_RELEASE);
            if (sFound)
                RFeed(PREHEADER+2);
        }
//        else
//            EXIT;
    }

}
/**
 * ��ѯSD���ϵ�Z��������
 *
 * @author EutronSoftware (2017-07-04)
 */
void PrintEJZReport()
{
    switch(ListItems(EJBYDATETIME,0,Msg[EJPrintZRport].str,false,true))
    {
    case (EJBYDATETIME-EJBYDATETIME+1):       //�������ڲ�ѯZ�����վ�
        PrintEJLOGZReport('D');
        break;
    case (EJBYZNUMBER-EJBYDATETIME+1):       //���ݺ����ѯZ�����վ�
        PrintEJLOGZReport('N');
        break;
//    case It_EXIT:
    default:
        break;
    }
    EXIT;
}

/***********************************************
 * ���ƴ�ӡ���һ���վ�
 *
 * @author EutronSoftware (2017-07-31)
 *********************************************/
void CopyTheLastReceipt()
{
    int i;
    WORD zNum;
    WORD recN;//�վݺ�
#define _sBuf_ SysBuf

        _sBuf_[0]=ApplVar.FS_Current+'0';_sBuf_[1]=':';
        if (ApplVar.FTrain)
        {
            recN=ApplVar.FisNumber.ReceiptNum[TRECEIPTS];
            zNum=ApplVar.ZCount[TRAINZNUM];
            strcpy(_sBuf_+2,"/TRAIN");i=8;
        }
        else
        {
            recN=ApplVar.FisNumber.ReceiptNum[FRECEIPTS];//ApplVar.SaleReceipts
            zNum=ApplVar.ZCount[FISCALZNUM];
            i=2;
        }
        if (recN>0)// && zNum>0)
        {
            //����0269170320/TLD66000003/1703200269/0001/_a.txt�ļ�����
            sprintf(_sBuf_+i,"/%04d%06d/%s/%06d%04d/%04d/_a.txt",
                                    zNum,
                                    ApplVar.ZDate,
                                    ApplVar.ApprovalCode,
                                    ApplVar.ZDate,
                                    zNum,
                                    recN);
            ff_MountSDisk(FS_SD);
            if (ff_OpenFileQ(_sBuf_,FA_READ | FA_TEXT)==FR_OK)
            {
                PrintStr_Center((char*)MsgCOPYRECEIPTSTART,true);
#if defined(CASE_ITALIA)
                Print_NonFiscal(1);
#endif
                while (!ff_EofFile())
                {
					i = ff_ReadFile(SDRW_Buffer, PRTLEN+5,FS_TEXT);
                    if (i>0)
                    {
					   (i>PRTLEN)?(i=PRTLEN):(SDRW_Buffer[i]==0x0a?(i--):(i=i));
                        SDRW_Buffer[i]=0;
                        RJPrint(0,SDRW_Buffer);
                    }
                }
                ff_CloseFile();
#if defined(CASE_ITALIA)
                Print_NonFiscal(0);
#endif
                PrintStr_Center((char*)MsgCOPYRECEIPTEND,true);
            }
            ff_MountSDisk(FS_RELEASE);
            RFeed(PREHEADER+2);//��ӡ��˺ֽλ��
        }
}

#if 1	//testonly

#if defined(DEBUGBYPC)
extern  void Send_By_Http(char *);
char s_FileN4POST[34];       //�ṩ��HTTP POST�е��ļ�����
char s_File[_MAX_PATH];
unsigned char AESIV[AES_ENCR_LEN];	// ��ʼ������
#else
#define AESIV  Http_arg.AESIV
#endif


#if (defined(AESCIPHERFILE) || defined(DEBUGBYPC))
//========================================================================
char AESCipherFile[]="\0:/AESCipher.txt";//���ܺ�洢���ļ�����,AESCipherFile[0]=0ʱ,������


//////////////////////////////////////////////////////////////////////////
//	��������	AESEncrypt_SFile(���ڲ����ļ��ݴ��������)
//	������		���ļ�pS_TXT���ܺ�,�洢��AESCipherFileָ�����ļ���
//           ��PCƽ̨��,���������ļ�����ת���ļ�
//	���������	pS_TXT	-- ������ܵ��ļ����ơ�
//				pIV			-- ��ʼ�����������ʹ��ECBģʽ������ΪNULL��
//	���������	pCipherText	-- ���ģ��������ļ��ܺ�����ݣ�������pPlainText��ͬ��
//	����ֵ��	�ޡ�
//////////////////////////////////////////////////////////////////////////

FRESULT AESEncrypt_SFile(unsigned char *pS_TXT)
{
    FRESULT resultR;
    int32_t br;
    int i;
    BYTE rLen;

    FRESULT resultW=FR_OK;
    DWORD bw;
#if defined(DEBUGBYPC)
    FILE  *AESFile;         //�򿪵��ļ�    TSDISK fsSDisk;
#else
    FIL   AESFile;
#endif

    unsigned int nDataLen;
    unsigned char pCipherText[AES_ENCR_LEN];

//	unsigned char key[AES_KEY_BYTES]	= {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p'};	// ��Կ
#if (ENCRYPTBYAES && defined(AESCIPHERFILE) && (AES_MODE == AES_MODE_CBC))
	unsigned char IV[AES_ENCR_LEN] = {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};	// ��ʼ������
#endif

#if defined(TWO_SDCARDS)
    resultR=ff_MountSDisk(FS_SD_2ND);
    AESCipherFile[0]=FS_SD_2ND+'0';
#else
    resultR=ff_MountSDisk(FS_SD);
    AESCipherFile[0]=FS_SD+'0';
#endif
#if defined(DEBUGBYPC)
    AESCipherFile[0]='F';
#endif

    if (resultR != FR_OK)
    {
        AESCipherFile[0]=0;
        print_FResult("ff_MountSDisk",resultR);
        return resultR;
    }

    /* ���ļ� */
    resultR = ff_OpenFileQ(pS_TXT, FA_OPEN_EXISTING | FA_READ);

#if defined(DEBUGBYPC)
    if ((AESFile=fopen(AESCipherFile,"wb"))==NULL)
        resultW=FR_DISK_ERR;
#else
    resultW=f_open(&AESFile, AESCipherFile, FA_CREATE_ALWAYS | FA_WRITE);
#endif

    if (resultR==FR_OK && resultW==FR_OK)
    {

#if (ENCRYPTBYAES && defined(AESCIPHERFILE))//����
#if AES_MODE == AES_MODE_CBC
        for (i=0;i<sizeof(IV);i++)
            IV[i]= random(256);
        memcpy(AESIV,IV,sizeof(AESIV));
#endif
        AES_Init(ApplVar.AP.NetWork.SecurityCode);
#endif
        while (!ff_EofFile())
        {
            br = ff_ReadFile(pCipherText,AES_ENCR_LEN,FS_BINARY);
            if (br>0)
            {
                rLen=br;
                if (rLen<AES_ENCR_LEN)
                    memset(pCipherText+rLen,0,AES_ENCR_LEN-rLen);

#if (ENCRYPTBYAES && defined(AESCIPHERFILE))//����
#if AES_MODE == AES_MODE_CBC
        		XorBytes(pCipherText, IV, AES_ENCR_LEN);
        		BlockEncrypt(pCipherText);
                memcpy(IV,pCipherText,AES_ENCR_LEN);
#else
                BlockEncrypt(pCipherText);
#endif
#endif

#if defined(DEBUGBYPC)
                if ((bw=fwrite(pCipherText,1, br,AESFile))!=br)
                {
                    resultW=FR_INT_ERR;
                    break;
                }
#else
                if ((resultW=f_write(&AESFile, pCipherText, br, &bw))!=FR_OK)
                    break;
#endif
            }
            else
            {
                break;
            }
        }
    }
    /* �ر��ļ�*/
    ff_CloseFile();
#if !defined(DEBUGBYPC)
    f_close(&AESFile);
#else
    fclose(AESFile);
#endif
    ff_MountSDisk(FS_RELEASE);
    if (resultR!=FR_OK)
    {
        print_FResult("ff_MountSDisk",resultR);
        return resultR;
    }
    if (resultW!=FR_OK)
    {
        print_FResult("ff_MountSDisk",resultW);
        return resultW;
    }
}
#endif
/****************************************************************************
 * �����������ZNum��Z������Ӧ��s.txt�ļ����͸�������
 * ���洢��ApplVar.FiscalBuff.Fis_ClearRecord�е����ݷ��͸�������
 * @author EutronSoftware (2017-10-17)
 *
 * @return BYTE
 *****************************************************************************/
BYTE HTTPPost_DailyZAll()
{

    //1.��FM�в���ZNum��Ӧ������
    //2.�����ҵ�������,�����������ļ���:
    //   The filename should be CCN77000003 0120(number of Z) 1710171219_s.txt ,
    //   So it should be CCN7700000301201710171219_s.txt
    //3.�����ݽ��м���
    //4.��������

    ULONG sFMOffset=0;
    FRESULT resultAES=FR_OK;


    if (ApplVar.ZCount[FISCALZNUM])
    {
        for (sFMOffset=FISDATAADDR;sFMOffset<=ApplVar.FiscalHead.ClearP;sFMOffset+=FISRECORDLEN)
        {
            if (!Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,sFMOffset,FISRECORDLEN))
            {
                ApplVar.FiscalFlags = FMERROR; ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
                break ;
            }
            if (ApplVar.FiscalBuff.Fis_ClearRecord.FunN==FISCLEARLOG)
            {
#if defined(DEBUGBYPC)
#else
#if HTTP_ONLY1
                while (HTTP_state!=CLIENT_CLOSE) {};
#endif
#endif
                if (!HTTPPost_DailyZ()) break;
            }
        }
    }

}

/****************************************************************************
 * ��Fis_ClearRecord��Z���ݶ�Ӧ��s.txt�ļ����͸�������
 *
 * @author EutronSoftware (2017-10-17)
 *
 * @return BYTE:=true,���ͳɹ�
 *****************************************************************************/
BYTE HTTPPost_DailyZ()
{
    //1.����Fis_ClearRecord�е�����,�����������ļ���:
    //   The filename should be CCN77000003 0120(number of Z) 1710171219_s.txt ,
    //   So it should be CCN7700000301201710171219_s.txt
    //2.�����ݽ��м���
    //3.��������

    ULONG delayFor;
    int i;
    WORD sYear;
    BYTE sMonth,sDay;

    //FRESULT resultAES=FR_INVALID_PARAMETER;

#if !defined(DEBUGBYPC)
    struct tcp_pcb* client_pcb;
#if HTTP_ONLY1
    if (HTTP_state!=CLIENT_CLOSE && HTTP_state!=CLIENT_ERROR)
        return false;//ccr2017-10-17���þ�̬����,ֻ����һ��ͨѶ
#else
    struct HTTP_Client_app_arg *Http_arg;
#endif
#endif

    if (!ApplVar.AP.NetWork.ServerURL[0] && CLONG(ApplVar.AP.NetWork.PrimaryDNS[0])==0)
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI119);//û������URL��DNS
        return false;//
    }

    if (CLONG(ApplVar.AP.NetWork.IPAddress[0])==0)
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI121);//û�������տ��IP
        return false;//
    }

    if (ApplVar.ZCount[FISCALZNUM] && ApplVar.FiscalBuff.Fis_ClearRecord.FunN==FISCLEARLOG)
    {//ΪZ����

       //����_s.txt�ļ�,λ���ļ���0269170320/TLD66000003/1703200269/0004��
       DecordDate(ApplVar.FiscalBuff.Fis_ClearRecord.FDate,&sYear,&sMonth,&sDay);
       sprintf(s_File,"%d:/GGPS/%s/%04d/%02x%02x%02x%02x%02x_s.txt",ApplVar.FS_Current,
                               ApplVar.ApprovalCode,
                               ApplVar.FiscalBuff.Fis_ClearRecord.FCount,
                               sYear & 0xff,sMonth,sDay,
                               ApplVar.FiscalBuff.Fis_ClearRecord.FTime[0],
                               ApplVar.FiscalBuff.Fis_ClearRecord.FTime[1]);
       //POST���ļ�����ΪCCN77000003 0120 1710171219_s.txt
       sprintf(s_FileN4POST,"%s%04d%02x%02x%02x%02x%02x_s.txt",
                               ApplVar.ApprovalCode,
                               ApplVar.FiscalBuff.Fis_ClearRecord.FCount,
                               sYear & 0xff,sMonth,sDay,
                               ApplVar.FiscalBuff.Fis_ClearRecord.FTime[0],
                               ApplVar.FiscalBuff.Fis_ClearRecord.FTime[1]);
#if (defined(AESCIPHERFILE) || defined(DEBUGBYPC))
       //��*_s.txt���ݼ��ܺ�,������AESCipherFile��ָ�����ļ���
       if (AESEncrypt_SFile(s_File)!=FR_OK)
           return false;
#endif


#if defined(DEBUGBYPC)
       Send_By_Http(s_File);
       //ɾ����ʱ�ļ�
//ccr2017-12-25 testonly      if (AESCipherFile[0])
//ccr2017-12-25 testonly           ff_DeleteFolderFile(AESCipherFile);

       if (s_File[0])
       {
           if (s_File[0]=='E' && s_File[1]=='R' && s_File[2]=='R')
           {//ERR;EE;ZZZZ
               sDay=s_File[4]-'0';//�õ������
               if (s_File[5]>='0'&&s_File[5]<='9')
               {
                   sDay=sDay*10+s_File[5]-'0';//�õ������
                   i = 7;
               }
               else
                   i = 6;

               sYear=0;
               if (sDay>=3)
               {
                   for (;s_File[i]>='0'&&s_File[i]<='9';i++)
                       sYear=sYear*10+(s_File[i]-'0');
                   if (sDay<=4)
                       SetReadZByZNum(sYear+1);//������һ�������͵�Z���
               }
               PutsO(s_File);
               return false;
           }
           else
               return true;
       }
       else
       {
           //������
           PutsO("---ERROR---");
           return false;
       }
#else

        XPRINTF((">tcp client inti\n"));

#if (LWIP_DNS)
        //����ͨ��URL��������ȡ��������IP��ַ
        if (CLONG(ApplVar.AP.NetWork.ServerIP[0])==0 && BIT(ApplVar.AP.NetWork.Option,IPByDHCPFlag))
        {
            if (!GetIPByDNSFromURL(ApplVar.AP.NetWork.ServerIP,ApplVar.AP.NetWork.ServerURL,true))
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI120);//��������ʧ��
                return false;
            }
        }
#endif
        if (CLONG(ApplVar.AP.NetWork.ServerIP[0])==0)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI106);//û�з�������IP��ַ
            return false;
        }

        client_pcb = tcp_new();
        if (client_pcb != NULL)
        {
    //                tcp_bind(client_pcb,IP_ADDR_ANY,2200);
    #if HTTP_ONLY1
            tcp_arg(client_pcb, (void*)&Http_arg);
            HTTP_state = CLIENT_WAITING_FOR_CONNECTION;
            IP4_ADDR(&Http_arg.destip,ApplVar.AP.NetWork.ServerIP[0],ApplVar.AP.NetWork.ServerIP[1],ApplVar.AP.NetWork.ServerIP[2],ApplVar.AP.NetWork.ServerIP[3]);
            //IP4_ADDR(&destip, 147 ,102 , 24 , 100 );//  destip.addr = (uint32_t)147+(102<<8)+(24<<16)+(100<<24);//inet_addr("147.102.24.100")
            POSTResult[0]=0;
            tcp_connect(client_pcb, &Http_arg.destip, 80, HTTP_Client_connected);         //���������ӣ���������

    #else

            tcp_arg(client_pcb, mem_calloc(sizeof(struct HTTP_Client_app_arg), 1));
            Http_arg = client_pcb->callback_arg;
            HTTP_state = CLIENT_WAITING_FOR_CONNECTION;
            IP4_ADDR(&Http_arg->destip,ApplVar.AP.NetWork.ServerIP[0],ApplVar.AP.NetWork.ServerIP[1],ApplVar.AP.NetWork.ServerIP[2],ApplVar.AP.NetWork.ServerIP[3]);
            //IP4_ADDR(&destip, 147 ,102 , 24 , 100 );//  destip.addr = (uint32_t)147+(102<<8)+(24<<16)+(100<<24);//inet_addr("147.102.24.100")
            POSTResult[0]=0;
            tcp_connect(client_pcb, &Http_arg->destip, 80, HTTP_Client_connected);         //���������ӣ���������
    #endif
            //Ӧ���ڴ˴�����,�ȴ����������ؽ��
#if (1)     //����:�ȴ�ͨѶ����>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
            delayFor=GetSystemTimer();//+SECONDS(ACTIVE*60);//ccr2015-03-11

            while (GetSystemTimer()-delayFor<SECONDS(60)){
                if (HTTP_state==CLIENT_CLOSE || POSTResult[0])
                     break;
                else if (HTTP_state==CLIENT_ERROR)
                {
                     ApplVar.ErrorNumber=ERROR_ID(CWXXI105);
                     return false;
                }
            }

            //ɾ����ʱ�ļ�
#if defined(AESCIPHERFILE)
            if (AESCipherFile[0])
                ff_DeleteFolderFile(AESCipherFile);
#endif

            if (POSTResult[0])
            {
                if (POSTResult[0]=='E' && POSTResult[1]=='R' && POSTResult[2]=='R')
                {//ERR;EE;ZZZZ
                    sDay=POSTResult[4]-'0';//�õ������
                    if (POSTResult[5]>='0'&&POSTResult[5]<='9')
                    {
                        sDay=sDay*10+POSTResult[5]-'0';//�õ������
                        i = 7;
                    }
                    else
                        i = 6;

                    sYear=0;
                    if (sDay>=3)
                    {
                        for (;POSTResult[i]>='0'&&POSTResult[i]<='9';i++)
                            sYear=sYear*10+(POSTResult[i]-'0');
                        if (sDay<=4)
                            SetReadZByZNum(sYear+1);//������һ�������͵�Z���
                    }
                    sprintf(s_File,"POST-ERROR(%u;%u)",sDay,sYear);
#if (DISP2LINES)
                    Puts1(s_File);
#else
                    PutsO(s_File);
#endif
                    return false;
                }
                else
                    return true;
            }
            else
            {
                //������
                XPRINTF(("--POST TIMEOUT--\n"));
                ApplVar.ErrorNumber=ERROR_ID(CWXXI105);
                return false;
            }
#else
            return true;
#endif  //<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        } else
        {
            XPRINTF(("tcp create failed\n"));
            ApplVar.ErrorNumber=ERROR_ID(CWXXI110);
            return false;
        }
#endif

    }
}
#endif
/********************************************************************
 * ��δ�͵�Z������s�ļ����͸�������
 *
 * @author EutronSoftware (2017-10-19)
 *
 * @return BYTE
 *********************************************************************/
BYTE HTTPPost_SFiles(void)
{
    //1.��FM�в���ReadZNum��Ӧ������


    if (ApplVar.FiscalHead.ReadZNum<ApplVar.ZCount[FISCALZNUM] &&
        ApplVar.FiscalHead.ReadZ<ApplVar.FiscalHead.MaxP &&
        WaitForYesNo(MsgSendCurrentSFile,0,1,true)=='Y')
    {
        if (ApplVar.FiscalHead.ReadZ==0)
            ApplVar.FiscalHead.ReadZ=FISDATAADDR;

        for (;ApplVar.FiscalHead.ReadZ<ApplVar.FiscalHead.MaxP;ApplVar.FiscalHead.ReadZ+=FISRECORDLEN)
        {
            if (!Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,ApplVar.FiscalHead.ReadZ,FISRECORDLEN))
            {
                ApplVar.FiscalFlags = FMERROR; ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
                return false;
            }
            if (ApplVar.FiscalBuff.Fis_ClearRecord.FunN==FISCLEARLOG)
            {
#if defined(DEBUGBYPC)
#else
#if HTTP_ONLY1
                while (HTTP_state!=CLIENT_CLOSE)
                {
                    if (HTTP_state==CLIENT_ERROR)
                        return false;
                }
#endif
#endif
                if (!HTTPPost_DailyZ())
                    return false;
                ApplVar.FiscalHead.ReadZNum=ApplVar.FiscalBuff.Fis_ClearRecord.FCount;
            }
        }
    }
    return true;
}

/********************************************************************
 * ���մ�ӡ��Z������s�ļ����͸�������
 *
 * @author EutronSoftware (2017-10-19)
 *
 * @return BYTE
 *********************************************************************/
BYTE HTTPPost_LastSFile(void)
{
    if (ApplVar.FiscalHead.ReadZNum+1==ApplVar.FiscalBuff.Fis_ClearRecord.FCount //ApplVar.ZCount[FISCALZNUM]
        && WaitForYesNo(MsgSendCurrentSFile,0,1,true)=='Y')
    {
            if (ApplVar.FiscalBuff.Fis_ClearRecord.FunN==FISCLEARLOG)
            {
#if defined(DEBUGBYPC)
#else
#if HTTP_ONLY1
                while (HTTP_state!=CLIENT_CLOSE)
                {
                    if (HTTP_state==CLIENT_ERROR)
                        return false;
                }
#endif
#endif
                if (!HTTPPost_DailyZ())
                    return false;
                ApplVar.FiscalHead.ReadZNum=ApplVar.FiscalBuff.Fis_ClearRecord.FCount;
                ApplVar.FiscalHead.ReadZ=ApplVar.FiscalHead.MaxP;
            }
    }
    return true;
}


/********************************************************************
 * ����Z�����Ų�������FM�еĴ洢λ��,��������FiscalHead.ReadZ
 *
 * @author EutronSoftware (2017-10-19)
 *
 * @return BYTE
 *********************************************************************/
BYTE SetReadZByZNum(WORD zNum)
{
    if (zNum<ApplVar.ZCount[FISCALZNUM])
    {
        for (ApplVar.FiscalHead.ReadZ=FISDATAADDR;ApplVar.FiscalHead.ReadZ<ApplVar.FiscalHead.MaxP;ApplVar.FiscalHead.ReadZ+=FISRECORDLEN)
        {
            if (!Bios_FM_Read(&ApplVar.FiscalBuff.Fis_ClearRecord,ApplVar.FiscalHead.ReadZ,FISRECORDLEN))
            {
                ApplVar.FiscalFlags = FMERROR; ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
                return false;
            }
            if (ApplVar.FiscalBuff.Fis_ClearRecord.FunN==FISCLEARLOG && ApplVar.FiscalBuff.Fis_ClearRecord.FCount==zNum)
            {
                ApplVar.FiscalHead.ReadZNum=ApplVar.FiscalBuff.Fis_ClearRecord.FCount;
                return true;
            }
        }
    }
    return false;
}

//=======================================================================
#if (SDCACHESIZE)

/************************************************************************
 * 1. ��λSD ��cache����
 *
 * @author EutronSoftware (2018-02-06)
 *
 * @param cacheType :'R'-cache��Ϊ�վ�����,'Z'-cache��ΪZ��������
 ************************************************************************/
void SDCacheReset(char cacheType)
{
    //memset(&ApplVar.SDCache,0,sizeof(ApplVar.SDCache));
    ApplVar.SDCache.Finished=false;
    ApplVar.SDCache.Length=0;
    ApplVar.SDCache.FileName=NULL;
    ApplVar.SDCache.FileSize=NULL;
    ApplVar.SDCache.FileCount=0;
    ApplVar.SDCache.FileSaved=0;

    //ApplVar.SDCache.DataWrited=0;
    //ApplVar.SDCache.TotalWrited=0;

    ApplVar.SDCache.Type=cacheType;
    ApplVar.SDCache.ReceiptNo=ReceiptNumber();//ccr2018-02-06 ???? �Ƿ���Ҫ-1
    //memset(SDCacheBuff,0,sizeof(SDCacheBuff));
#if defined(DEBUGBYPC)//ccr2018-02-27
    DebugMessage(">>>SDCache Reset");
#endif
}
/*******************************************************
 * 2.���ļ�����д��SDCache��
 *
 * @author EutronSoftware (2018-02-06)
 *
 * @param fType:='L'ʱ,ֻд�뵽ָ����SD��,��д�⿨
 * @param fileName
 *******************************************************/
void SDCachePushFileName(char fType,char *fileName)
{
    WORD fLen=strlen(fileName)+2;//����fType���ļ���������\0

    ApplVar.SDCache.FileName=SDCacheBuff+ApplVar.SDCache.Length;
    (char*)ApplVar.SDCache.FileSize=ApplVar.SDCache.FileName+fLen;
    ApplVar.SDCache.FileName[0]=fType;
    strcpy(ApplVar.SDCache.FileName+1,fileName);
    *ApplVar.SDCache.FileSize=0;
    ApplVar.SDCache.FileCount++;
    ApplVar.SDCache.Length+=(fLen+2);//�������ȼ�����(WORD)
#if defined(DEBUGBYPC)//ccr2018-02-27
    char sBuf[200];
    strcpy(sBuf,">>>PushFile:");
    strcat(sBuf,fileName);
    DebugMessage(sBuf);
#endif

}
/**********************************************************
 * 3.���ļ�����ѹ��SDCACHE��
 *
 * @author EutronSoftware (2018-02-06)
 *
 * @param data
 * @param dLen
 ***********************************************************/
void SDCachePushData(BYTE *data,WORD dLen)
{
    memcpy(SDCacheBuff+ApplVar.SDCache.Length,data,dLen);
    ApplVar.SDCache.Length+=dLen;
    *ApplVar.SDCache.FileSize +=dLen;
#if defined(DEBUGBYPC)//ccr2018-02-27
    char sBuf[200];
    memset(sBuf,0,sizeof(sBuf));
    strcpy(sBuf,">>>PushData:");
    memcpy(sBuf+strlen(sBuf),data,dLen);
    DebugMessage(sBuf);
#endif

}

/************************************************************
 * 4.����ѹ��SD Cache����
 *
 * @author EutronSoftware (2018-02-06)
 ***********************************************************/
void SDCachePushEnd()
{
    ApplVar.SDCache.Finished=true;
#if defined(DEBUGBYPC)//ccr2018-02-27
    DebugMessage(">>>SDCache PushEnd");
#endif

}

/************************************************************************
 * 5.��������վ�����д���ļ�(_a.txt/_z.txt)
 *
 * @author EutronSoftware (2017-06-16)
 * @param resetTotal:=trueʱ,д������TotalWrited
 ************************************************************************/
void  SDCacheFlushData(BYTE resetTotal)
{
    int i;
    WORD sNumber;
    WORD fileSize;
    char fileType;
    char *cache;
    WORD fnLen;

    char sfn[_MAX_PATH];

#if defined(TWO_SDCARDS)
    WORD recN;
#endif

    if (ApplVar.SDCache.Length && ApplVar.SDCache.Type && ApplVar.SDCache.Finished && ApplVar.SDCache.FileSaved<ApplVar.SDCache.FileCount)
    {
#if defined(DEBUGBYPC)//ccr2018-02-27
        DebugMessage(">>>SDCache FlushData");
#endif
#if CC_DEBUG
        PutsO("Flush Cache >>");//testonly
#endif
        cache=SDCacheBuff;
        //�����Ѿ�д��SD�����ļ�
        for (i=0;i<ApplVar.SDCache.FileSaved;i++)
        {
            fnLen = strlen(cache);
            cache += (fnLen+1);//�ļ�������+������
            fnLen = CWORD(cache[0]);//�ļ����ݳ���
            cache += (fnLen+2);//cacheָ����һ���ļ�
        }
        for (;ApplVar.SDCache.FileSaved<ApplVar.SDCache.FileCount;ApplVar.SDCache.FileSaved++)
        {
                fileType=*cache++;ApplVar.SDCache.Length--;
                fnLen = strlen(cache);
                if (fnLen>=_MAX_PATH-1)//Cache�е��ļ����������쳣,��ֹ�����Cache
                    break;
                strcpy(sfn,cache);
                cache += (fnLen+1);ApplVar.SDCache.Length-=(fnLen+1);//�ļ�������+������
                fnLen = CWORD(cache[0]);//�ļ����ݳ���
                cache += 2;ApplVar.SDCache.Length-=2;//cacheָ���ļ�������
    #if defined(TWO_SDCARDS)
                recN=0;//�����ظ�����Ʊͷ��SHA1ǩ������
                if (fileType=='L')
                   ApplVar.FS_Current=FS_SD_2ND;
                else
                   ApplVar.FS_Current=FS_SD;
                for (;ApplVar.FS_Current<=FS_SD_2ND;ApplVar.FS_Current++)
    #else
                ApplVar.FS_Current=FS_SD;
    #endif
                {
                    ff_SelectSDisk(ApplVar.FS_Current);

                    ff_MountSDisk(ApplVar.FS_Current);
                    //д�������ݲ���д,�����ļ����ļ����Ѿ�����
                    if (fileType=='r')
                    {
                       ff_RenameFile(sfn,cache);
                    }
                    else
                    {
                       if (ApplVar.SDCache.Type=='R')
                       {
                            if (fileType!='s' || ApplVar.SDCache.ReceiptNo==1)
                                ff_OpenFile(sfn,(FA_CREATE_ALWAYS+FA_WRITE));//���ļ�,����ļ����������Զ�����
                            else
                                ff_OpenFile(sfn,(FA_OPEN_ALWAYS+FA_WRITE));//���ļ�,����ļ����������Զ�����
                       }
                       else
                           ff_OpenFile(sfn,(FA_CREATE_ALWAYS+FA_WRITE));//���ļ�,����ļ����������Զ�����
                       ff_WriteFile(cache,fnLen);
#if (0)//ccr2018-02-24defined(CASE_GREECE)//ϣ���汾�Ŷ��վݼ���SHA1ǩ��

                       if (ApplVar.SDCache.Type=='R' && fileType=='a')//ccr2017-11-15_z.txt������SHA1
                       {
       #if defined(TWO_SDCARDS)
                           if (!recN)
       #endif
                           {
                               ApplVar.SHA1_Error = SHA1Reset(&ApplVar.SHA1);
                               ComputeASEDS(cache,fnLen);
                           }
                       }
#endif
                       ff_CloseFile();
                    }

                    ff_MountSDisk(FS_RELEASE);
#if defined(TWO_SDCARDS)
                    recN=1;//��ʾ�������ǩ��
#endif
                }
                cache+=fnLen; ApplVar.SDCache.Length-=fnLen;//ָ����һ���ļ�
#if defined(TWO_SDCARDS)
                ff_SelectSDisk(FS_SD);
#endif
        }
#if defined(TWO_SDCARDS)
        ff_SelectSDisk(FS_SD_2ND);
        ff_MountSDisk(ApplVar.FS_Current);
        ff_SDiskSpace();//д���ļ���,��ȡʣ��ռ�(GetMMCSize());
        ff_MountSDisk(FS_RELEASE);
#endif
        ff_SelectSDisk(FS_SD);
        ff_MountSDisk(ApplVar.FS_Current);
        ff_SDiskSpace();//д���ļ���,��ȡʣ��ռ�(GetMMCSize());
        ff_MountSDisk(FS_RELEASE);

        //��������д�����
        ApplVar.SDCache.Type=0;
        ApplVar.SDCache.Finished=0;
        ApplVar.SDCache.Length=0;
        ApplVar.SDCache.FileCount=0;
        ApplVar.SDCache.FileSaved=0;
        CheckEJSpace();
#if CC_DEBUG
        PutsO("<<Flush Finished");//testonly
#endif
    }
}
#if 0
/************************************************************************
 * ��������վ�����д���ļ�(_a.txt/_z.txt)
 *
 * @author EutronSoftware (2017-06-16)
 * @param resetTotal:=trueʱ,д������TotalWrited
 ************************************************************************/
void   sSDCacheFlushData(BYTE resetTotal)
{
    int i;
    WORD sNumber;
#if defined(TWO_SDCARDS)
    WORD recN;
#endif

    if (ApplVar.SDCache.Length && ApplVar.SDCache.Type)
    {
#if CC_DEBUG
            PutsO("Flush Cache >>");//testonly
#endif
#if defined(TWO_SDCARDS)
            recN=0;//�����ظ�����Ʊͷ��SHA1ǩ������
            for (ApplVar.FS_Current=FS_SD;ApplVar.FS_Current<=FS_SD_2ND;ApplVar.FS_Current++)
#endif
            {
                ff_MountSDisk(ApplVar.FS_Current);
#if (0)
                //���Ǵ��ļ���ʼλ��д������
                ApplVar.SDCache.DataWrited[ApplVar.FS_Current-FS_SD]=0;//_FS_SD
                ff_OpenFileQ(ApplVar._a_txt,(FA_CREATE_ALWAYS+FA_WRITE),);//���ļ�,����ļ����������Զ�����
#else
                //д�������ݲ���д,�����ļ����ļ����Ѿ�����
                ff_OpenFileQ(ApplVar._a_txt,(FA_OPEN_ALWAYS+FA_WRITE));//���ļ�,����ļ����������Զ�����
#endif
#if defined(CASE_GREECE)//ccr2018-01-08�����վݼ���SHA1ǩ��
                if (ApplVar.SDCache.Type=='R')//ccr2017-11-15_z.txt������SHA1
                {
    #if defined(TWO_SDCARDS)
                    if (!recN && !ApplVar.SDCache.TotalWrited[ApplVar.FS_Current-FS_SD])
    #else
                    if (!ApplVar.SDCache.TotalWrited[ApplVar.FS_Current-FS_SD])
    #endif
                        ApplVar.SHA1_Error = SHA1Reset(&ApplVar.SHA1);
                }
#endif
                //��Ʊͷд��EJ�վ��ļ���//_FS_SD
                for (i=ApplVar.SDCache.DataWrited[ApplVar.FS_Current-FS_SD];i<ApplVar.SDCache.Length;i+=sizeof(SDRW_Buffer))
                {
                    RamOffSet=i+ADDR_SDCACHE;
                    if (i+sizeof(SDRW_Buffer)>ApplVar.SDCache.Length)
                        sNumber=ApplVar.SDCache.Length-i;
                    else
                        sNumber=sizeof(SDRW_Buffer);
                    ReadRam(SDRW_Buffer,sNumber);
                    ff_WriteFile(SDRW_Buffer,sNumber);
                    ApplVar.SDCache.DataWrited[ApplVar.FS_Current-FS_SD]+=sNumber;
                    ApplVar.SDCache.TotalWrited[ApplVar.FS_Current-FS_SD]+=sNumber;

#if defined(CASE_GREECE)//ccr2018-01-08�����վݼ���SHA1ǩ��
                    if (ApplVar.SDCache.Type=='R')//ccr2017-11-15_z.txt������SHA1
                    {
    #if defined(TWO_SDCARDS)
                        if (!recN)
    #endif
                            ComputeASEDS(SDRW_Buffer,sNumber);
                    }
#endif
                }

                ff_CloseFile();
                ff_SDiskSpace();//д���ļ���,��ȡʣ��ռ�(GetMMCSize());
                ff_MountSDisk(FS_RELEASE);
#if defined(TWO_SDCARDS)
                recN=1;//��ʾ�������ǩ��
#endif
            }
            ApplVar.SDCache.Length=0;//����д����;
            ApplVar.SDCache.DataWrited[_FS_SD]=0;
#if defined(TWO_SDCARDS)
            ff_SelectSDisk(FS_SD);
            ApplVar.SDCache.DataWrited[_FS_SD_2ND]=0;
#endif
            if (resetTotal)
            {
                ApplVar.SDCache.Type=0;
                ApplVar.SDCache.TotalWrited[_FS_SD]=0;
#if defined(TWO_SDCARDS)
                ApplVar.SDCache.TotalWrited[_FS_SD_2ND]=0;
#endif
            }
#if CC_DEBUG
             PutsO("<<Flush Finished");//testonly
#endif
    }
}
#endif
#endif

#endif//CASE_FATFS_EJ

//ccr2017-04-17<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
