#ifndef EXTH_H
#define EXTH_H

//------------------------For Debug--------------------------
#include "debug.h"
//------------------------For Debug--------------------------
extern void StrToBCDValue(char *to, char *from, short len);
extern BYTE  StrToBCDValueL(char *to, char *from, short len);        /* (void *to, char *from, short len) convert ascii to (BCD.Value)*/

int day_diff(int year_start, int month_start, int day_start, int year_end, int month_end, int day_end);

void PrintStr_ULong(const char *caption,ULONG aLong,BYTE aWidth);

void SystemTestMenu(void);
void PrintSetupMenu(void);
BYTE PosOfFuncKey(WORD funcKey);
BYTE GetKeyNoByCode(WORD funcCode);
ULONG ULongDateFrInput(void);
WORD ECRFuncCodeToTypeName(WORD fCode,char *fName);
int  ULongtoASC(char *to, ULONG num1);
ULONG DateToYYMMDD(void);
ULONG TimeToHHMM(void);
void PrintDateTime(void);
extern void PrintLine(char c);          /* print line of characters */

extern void PrintConfInf();

void PrintStr_Center(char *str,BYTE alCenter);
void PrintLongString(char *str,BYTE alRight);
void DateFrom__DATE__TIME(char *sDate);

extern void PutsPre(BYTE y,char* title,char pre);
extern void DispStrXY(CONSTBYTE *str ,BYTE x,BYTE y);
extern short GetStrFromKBD(BYTE type,char *prompt,char *strDefault,BYTE maxLen,char pwd,BYTE useDefault);
extern void DisplayDecXY(ULONG pDec,char *str,int y);
extern BYTE WaitForYesNo(const char *pMessage,BYTE x,BYTE y,BYTE pDefault);
extern BYTE Display_RGBuf(int UpDown);

extern BYTE AppendEntry(char chKey);
extern void DeleteEntry(BYTE disp);
extern void DateForDisplay(BYTE flag,BYTE width);

extern void DispInputMode(void);
extern char SetInputMode(char mode);
extern BYTE InputULong(char *str,ULONG vMax,BYTE y,BYTE enAMT,BYTE iniDisp);
extern BYTE InputFromTo(int msgID,ULONG vMAX);
extern void Initial_DateTime(BYTE idx);

extern int GetInput(char *sTo,BYTE sNum,bool alignRight);
extern void DisplayHex(char *pHex, short pWidth,BYTE y);
extern void DeptPluKeysCount(void);
extern void SetRTS(BYTE port);
extern void ClrRTS(BYTE port);
extern void DispSubTotal(void);

extern void ClsXRam(void);
extern void ClearCom(void);
extern BYTE PowerCheck(void);
extern BYTE GetInit(void);
extern void InitRtc(void);
extern long TestRam(void);
extern WORD CheckSum(void) ;
extern void DrawerOpen(void);
extern BYTE GetFontT(void);
extern BYTE GetFontB(void);
extern BYTE GetDotFont(void);

extern UnLong BCDValueToULong(BYTE *p, BYTE BcdBytes);
extern void PrintDotEpson(void);
extern void InitComm(void);

extern BYTE TestRtc(void);

extern void ReadRam(BYTE *to,WORD bytes);	    /* (void) read bytes from ram banks */
extern void WriteRam(BYTE *from,WORD bytes);     /* (void) write bytes to ram banks */

extern BYTE Recall_ApplRam(void);
void  LongToBCD(BCD  *to, long relong);

extern UnLong CheckDigit(char *Data, BYTE len);
#ifdef CASE_FATFS_EJ
extern void GetMMCSize(BYTE fsSD);
#endif
//cc 2006-07-03 for MMC>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

extern BYTE SetPassword(const char* PWDType,char *pass,BYTE pwdFor);
extern BYTE CheckPWD(char *pass);
extern void DateTimeToStr(char *sBuf,BYTE dt);
extern void SetComm(BYTE Com);
extern BYTE TestCom123(BYTE port);

extern void SendComm(BYTE,BYTE);
extern short ReadComm(BYTE);
extern WORD CheckComm(BYTE);
extern void EmptyComm(BYTE);

extern WORD EncordBCDDate(WORD sYear,BYTE sMonth,BYTE sDay);
extern WORD EncordDECDDate(WORD sYear,BYTE sMonth,BYTE sDay);
extern void DecordDate(WORD sDate,WORD *sYear,BYTE *sMonth,BYTE *sDay);

extern BYTE ChangePoint(void);
extern BYTE ChangePoint2(BYTE discPer);
extern BYTE TestChangePointMust(void);

extern int ULongtoASCZER0(char *to, ULONG num1,int width);

extern long StrToLong(char *pStr,BYTE pWidth);
extern long HexStrToLong(char *pStr,BYTE pWidth);
extern WORD StrToHex(char *pStr,BYTE pWidth);

extern void CutRPaper(short lines);

/***************************************************/


#ifndef MAIN_C


extern  void OutPrint(WORD Cmd, CONSTBYTE *Line);	//    Lancia stampa (standard)

#if !defined(DEBUGBYPC)
extern  void OutPrintEx(WORD Cmd, CONSTBYTE *Line, WORD DotLinesBlank);
#endif


extern  short CheckFunctionEntry(void);
extern  BYTE AmtInputMask(void);
extern  void ProcessKey(void);
extern  WORD KeyInput(void);

extern  void GetEntry(void);
#endif
/***************************************************/
#ifndef BUFFER_C
extern  void ProcessDeptRecord(void);
extern  void CheckModifier(void);
extern  void ProBuf(void);
extern  void ProcessBuffer(void);
extern  void StoreInBuffer(void);
#endif
/***************************************************/
#ifndef CLERK_C
extern void SetTrainMode(void);

extern  void GetClerkOffSet(void);
extern  void WriteClerk(void);
extern  void ReadClerk(void);
extern  void SelectClerk(BYTE lock);
extern  void PrintAllOfClerk(void);
#endif
/***************************************************/
#ifndef COMPUTER_C
extern char InitModem(void);
void SendString(CONSTCHAR *sStr,short len);
extern void DialOverModem(char *pTeleNo);
extern	short ReadString(char *sStr,short size);
extern  void PrnBuffer(char *buf,short len);
extern void HandDownModem(void);

extern  void Computer(void);
extern  void ProcessRecord(void);
extern  BYTE SendRecord(BYTE *p,BYTE length);	 //lyq2003
extern  BYTE SendComp(BYTE type,BCD *tot);
//extern  void SendRecord(void *p,BYTE length);	 //lyq2003
#endif
/***************************************************/
#ifndef CORREC_C
extern  void GetCorrecOffSet(void);
extern  void AddCorrecTotal(void);
extern  void WriteCorrec(void);
extern  void ReadCorrec(void);
extern  void Correction(void);
#if !defined(FISCAL) || MALTA == 1
extern  void TransactionVoid(void);
#endif
#endif
/***************************************************/
#ifndef CURRENCY_C
extern  void GetCurrOffSet(void);
extern  void AddCurrTotal(void);
extern  void WriteCurr(void);
extern  void ReadCurr(void);
extern  void GetCurrency(BYTE sell, BCD *amt);
extern  void Currency(void);
#endif
/***************************************************/
#ifndef DEPART_C
extern  void GetDeptOffSet(void);
extern  void AddDeptTotal(void);
extern  void WriteDept(void);
extern  void ReadDept(void);
extern  void PrintModifiers(void);
extern  char *GetPluPrint(char *temp,BYTE  cmd);
extern  BYTE CheckRefund(void);
extern  void ProcessDept(void);
extern  void PrintAllOfDepart(void);
#endif
/***************************************************/
#ifndef DISCOUNT_C
extern  void AddDiscTotal(void);
extern  void WriteDisc(void);
extern  void ReadDisc(void);
extern  void PrintPercentage(BCD *perc);
extern  void Discount(void);
extern  void GetDiscOffSet(void);
#endif
/***************************************************/
#ifndef DRAWER_C
extern  void GetDrawerOffSet(void);
extern  void AddDrawerTotal(void);
extern  void WriteDrawer(void);
extern  void ReadDrawer(void);
extern  void OpenDrawer(void);
extern  void Drawer(void);
extern void DispDrawerTotal(void);
#endif
/***************************************************/
//#ifndef FIRMKEY_C
extern  short DisplayOption(BYTE repeat);
extern  WORD CheckFirmKey(void);
extern 	BYTE CheckPassword(BYTE pwdFor);
extern 	BYTE CheckMode(void);
//#endif
/***************************************************/
#ifndef FIXED_C
extern  void CheckMultiply(void);
extern  void NewReceipt(void);
extern  void PrintNumber(BCD *num);
extern  void Suspend(void);
extern  void Fixed(void);
#endif
/*****************************************************/
//#ifndef FISCAL_C
extern void Fiscal_AddDatetimeChg(BYTE sSaveFM);

extern BYTE Initial_Fiscal(void);
extern void   PrintUserInput(void);

extern void DecordDateFiscal(WORD pD0,char toDate[]);
extern  void AddReceiptNumber(void) ;
extern WORD ReceiptNumber(void);
extern void ResetReceiptNumber(WORD num);
extern  void GetReceiptNumber(char *to) ;
extern void GetReceiptTotalNumber(char *to);//ccr2017-05-04

extern void CheckFisError(void);
extern  short BlankCheckProm(void) ;

extern  void CheckFiscal(bool ecrUsed);
extern  void PrintRfc(void) ;
extern  short CheckProm(void);
extern  void FiscalTrailer(void);
extern  void FiscalHeader(void);
extern  void GetFiscalTotal(void);
extern  void PrintFiscalTotal(void);
extern  void PrintFiscalTax(void) ;

extern  void DumpFiscal(void) ;
extern  void InitPrinter(void) ;
extern short Fiscal_RecallData(void);
extern short Fiscal_AddResetData(void);

extern BYTE Write_FiscalRam(UnLong DestAdr, VOIDFAR *Src, WORD Num);
extern BYTE Read_FiscalRam(VOIDFAR *Dest, UnLong SrcAdr, WORD Num);
extern short Read_FiscalData(BYTE sType,BYTE FMType);
extern void Print_FiscalReport(BYTE delOld);
extern void Fiscal_AddTaxRateChg(BYTE sSaveFM);
extern void Fiscal_AddHeaderChg(bool printIT);
extern void ProgUserInfo(int type);
extern void PrintAgain(void);
extern void Print_NonFiscal(BYTE inc);
extern short GetZAddrByDate(WORD pDate,bool ZOnly);
extern void PrintFMZByZ_Z(void);
extern void PrintFMZByDate(BYTE zType);
extern void CopyPrintLastZ(void);
extern void DeleteSDBefor60Days(int DAYSBEFOR);
//#endif

/***************************************************/
#ifndef FORMAT_C
extern void FormatAmtFix(char *to,BCD *amt);
extern  void FormatAmt(char *to,BCD *amt);
extern  void FormatQty(char *to ,BCD *qty );
extern  CONSTCHAR *FormatStrQtyPriAmt(CONSTCHAR *str,BCD *qty,BCD *pri,BCD *amt,short width);
extern  CONSTCHAR *FormatAmtStr(CONSTCHAR *str ,BCD *amt,short width);
extern  CONSTCHAR *FormatQtyStr(CONSTCHAR *str,BCD *qty,short width);
extern  void CheckDisPoint(void);
extern  CONSTCHAR *DispQtyStr(CONSTCHAR *str ,BCD *qty,BYTE length );
extern  CONSTCHAR *DispAmtStr(CONSTCHAR *str,BCD *amt,BYTE length);
extern WORD FormatTaxRate(char *str,BYTE sTAX,int width);
#endif
/***************************************************/
#ifndef GENERAL_C
extern  void PromtionCheck(void);
extern  void GetLongEntry(void);
extern  void AddTotal(void);
extern  void AddPointerTotal(void);
extern  void ClearEntry(void);
#if FRONT == 1
extern  void DisplayMessage(void);
#endif
extern  short CheckMaxEntry(BCD *bcd,BYTE a);
extern  void CheckError(short  a);
extern  void CheckBreakKey(void);
extern  void PrintMessage(WORD) ;
extern  WORD RegiInit(void);
extern  WORD RegiStart(void);
extern  void RegiEnd(BYTE total);//ccr2018-01-05
extern  void PrintTotal(void);
extern  void ReadTotal(void);
extern  void WriteTotal(void);
extern  void PrintPbTrailer(void);
extern void DiaplayTotal(void);
extern void DisplayPointerTotal(char *sFile);
#endif
/***************************************************/
#ifndef HARDTEST_C
void PrintMemoForFiscal(void);
extern void PrintVersion(void);

#if CHINA != 0
extern  void DumpChina(short progNumber);
#endif
extern  void HardTest(WORD idx);
extern  void CheckPluFile(WORD type) ;

#endif
/***************************************************/
extern void Initial_DateTime(BYTE idx);

#if (!defined(ApplVarInSRAM) || defined(DEBUGBYPC))
extern void Save_ConfigVar(bool);
extern void Save_Config(bool);
extern void Save_ApplRam(void);
#else
#define Save_ConfigVar(b) {}
#define Save_Config(b) {}
#define Save_ApplRam() {}
#endif

#ifndef INITAPPL_C

//����sizeof(APPLICATION_SAVE),������StartAddress
//toActual:=true,ת��Ϊʵ�ʵ�ַ,StartAddress[AddrEndP]=sizeof(APPLICATION_SAVE);
//     =false,ת��Ϊ��Ե�ַ,StartAddress[AddrEndP]=0
//return:=true,��ַδԽ��;=false,��ַԽ��
extern BYTE ResetStartAddress(BYTE toActual);

extern BYTE Recall_Config(void);
extern void InitPlu(void);
extern void InitDept(void);
extern void InitGroup(void);
extern void InitTender(void);
extern void InitDrawer(void);
extern void InitCorrec(void);
extern void InitCurr(void);
extern void InitDisc(void);
extern void InitPoRa(void);
extern void InitTax(void);
extern void InitPbF(void);
extern void InitClerk(void);
extern void InitModifier(void);
extern void ClearApplMemory(void);
extern void InitApplication(void);
#endif

/***************************************************/
#ifndef PLU_C
extern void LookPlu(BYTE pType);//pType=0,look price,pType>0 look inv
extern void GetPluOffSet(void);
extern void AddPluTotal(void);
extern void WritePluInventory(void);
extern void WritePlu(void);
extern void ReadPlu(void);
extern WORD  GetPluNumber(BYTE a,BYTE* b);
extern WORD  GetLinkNumber(void) ;
extern short CheckRandomPlu(BYTE a ,BYTE b);
extern void ProcessPlu(void);
extern void CheckMixMatch(short bufchk);
extern void PrintAllOfPLU(void);
#endif
/***************************************************/
#ifndef PORA_C
extern void GetPoRaOffSet(void);
extern void AddPoRaTotal(void);
extern void WritePoRa(void);
extern void ReadPoRa(void);

extern void PaidOutRa(void);
#endif
/***************************************************/
#ifndef PRINT_C
extern BYTE CheckChar(BYTE);
extern void DisplayStr(char *);
extern void ReleaseSlip(void);
extern BYTE CheckSlip(void);
extern void FeedSlip(BYTE);
extern BYTE PrintStr(CONSTCHAR *);
extern BYTE PrintQtyAmt(BCD *,CONSTCHAR *,BCD *);
extern void SendSlip(void);
extern void CmdSlip(char);
extern void PrintSlipPage(short);
extern void SlipMargin(void);
extern void PrintSlip(CONSTCHAR*);

extern void PrintHeader();
extern short CheckNewChinese(void);
extern short InitChinese(void);
extern short CheckChinese(void);
extern void PrintRJ(CONSTCHAR*);
extern void PrintMultiply(void);
extern void PrintSaleQty(void);
extern BYTE PrintPicture(short ,BYTE);
extern void PrintRegiInfo(BYTE prnGrp);
extern void ReceiptIssue(short);
extern void PrintMessage(WORD);
extern void PrintAllons(void);
#endif
/***************************************************/
#ifndef PROGDUMP_C
extern void ProgramDump(void);
extern void DumpDept(void);
extern void DumpTax(void);
#endif

#ifndef PROGOPT_C

extern void ProgCaptions(int setType,int recMax,int capSize);

#if (ASCIIINPUT==1 || COMPOSEIN==0)
extern char GetComposeASC(char sChar);
#elif  (COMPOSEIN==1)
extern char GetComposeASC(WORD key);
#endif

extern void GetHeader(int idx,int size);

extern int GetCaption(char *,BYTE);
extern void OptionToStr(BYTE opt,char * buf);
#if (SKIP & S_PROG)
extern BYTE GetOpt(BYTE,void *,BYTE);
#else
extern void GetByte(BYTE *, BYTE, BYTE);
extern void GetHexBytes(BYTE *,BYTE);
extern void InvertBit(BYTE,void *);
extern void Btoa(BYTE,void *);
extern BYTE GetOpt(BYTE,void *,BYTE);
#endif
#endif

/***************************************************/
//#ifndef PROGRAM_C

extern BYTE GetString(char *sMsg,char *val,WORD size);
extern void GetBCDValue(short MsgIdx,char *val,short BCDBytes,char IsQty);
extern void GetByteValue(short MsgIdx,BYTE *val,BYTE max);
extern void CheckBitValue(short MsgIdx,char *Opt,BYTE BitNo,BYTE sInv);

extern BYTE NumToIP(char *IPstr,BYTE *Num,BYTE fmt);
extern BYTE IPToNum(BYTE *Num,char *IPstr,short Counter);
extern BYTE GetIP(char *sMsg,BYTE *val);
extern void ProgNetWork(void);
void ProgNetFunctions(void);//NET Functions
void Print2Strings(char* strPrompt,char* strMess);

#if defined(CASE_GPRS)
extern void  ProgGPRSFuncs(void);
#endif

extern void InitSysFlag(void);
#if DD_FISPRINTER == 0
extern void ProgPlu(void);
extern void ProgPluStock(void);
extern void ProgDept(void);
extern void ProgGroup(void);
extern void ProgTend(void);
extern void ProgPoRa(void);
extern void ProgCorrec(void);
extern void ProgDisc(void);
extern void ProgCurr(void);
extern void ProgDraw(void);
extern void ProgPbF(void);
extern void ProgPbInfo(void);
extern void ProgTax(void);
extern void ProgClerk(void);
extern void ProgZone(void);
extern void ProgModi(void);
extern void ProgHeader(void);
extern void ProgTrailer(void);
extern void ProgSlipHead(void);
extern void ProgSysFlag(void);
extern void ProgSysMes(void);
extern void ProgReport(void);
extern void ProgPasswd(void);
extern void PrintUp(void) ;
extern void ProgFiscal(void) ;
extern void ProgSalPer(void) ;
extern void ProgDate(void) ;
extern void ProgTime(void) ;
extern void ProgOFF(void) ;
extern void ProgPort(BYTE port);
extern void ProgIC(void);  //ccr chipcard 2004-07-01
extern void ProgICBlock(void);  //ccr chipcard 2004-07-01
//#endif

extern void ProgPrnGraph(void);
extern void ProgPromotion(void);
extern void ProgAgree(void);
extern void ProgKPrn(void);
extern void ProgSlip(void);

#endif


#ifndef REPORT_C
extern void GetReport(BYTE zxNum);
extern void GetSystemReport(BYTE);
extern void PrintReportType(void);
extern void PrintDept(WORD);
extern void PrintPlu(WORD);
extern void PrintTender(WORD);
extern void PrintPoRa(WORD);
extern void PrintCurrency(WORD);
extern void PrintDrawer(WORD);
extern void PrintCorrec(WORD);
extern void PrintDisc(WORD);
extern void PrintTax(WORD);
extern WORD  PeriodSkip(struct REPSIZE *,BYTE);
extern short CheckBreak(void);
extern void PrintRange(void);
extern void ResetReport(void);
extern void PrintReport(short RepFor,struct REPSIZE *);
extern void PrintPluReport(short RepFor);
extern void PrintDeptReport(void);
extern void PrintGroupReport(void);
extern void PrintTendReport(void);
extern void PrintPoRaReport(void);
extern void PrintCurrReport(void);
extern void PrintDrawReport(void);
extern void PrintCorrecReport(void);
extern void PrintDiscReport(void);
extern void PrintTaxReport(void);
extern void PrintPbFReport(void);
extern void PrintPointReport(void);
extern void GetSystemReport(BYTE);
extern void PrintBARCustomer(BYTE xz);
#endif
/***************************************************/
#ifndef SEARCH_C
extern WORD  BinarySearch(	void *,WORD,BYTE,short );
#endif
/***************************************************/
#ifndef TAX_C
extern void CalculateRefundTax(BYTE tax,BCD *taxAmt, BYTE pbRefund);//ccr091223
extern void GetTaxOffSet(void);
extern void AddTaxTotal(void);
extern void WriteTax(void);
extern void ReadTax(void);
extern void AddTaxItem(BYTE,BYTE);
extern void AmtRound(BYTE,BCD *);
extern void RoundTaxable(BCD *amt);
extern void CalculateTax(BYTE);
#endif
/***************************************************/
#ifndef TENDER_C
extern short SelectCard(void);
extern void GetTenderOffSet(void);
extern void AddTenderTotal(void);
extern void WriteTender(void);
extern void ReadTender(void);
extern void Tender(void);
#endif
/***************************************************/
#ifndef TIMER_C

extern BYTE GetWeekDay(WORD year,BYTE month,BYTE day);

extern void MakeTime(char *,WORD);
extern void CheckTime(BYTE pAll);
extern void GetTimeZones(void);
extern void NewTimeDate(BYTE);
extern BYTE  GetMonthMaxDay(BYTE  tyear, BYTE tmonth);

#endif
/***************************************************/

#ifndef REPORT2_C
extern WORD  SetUpReport(void);
extern void MakeTime(char *,WORD);
extern void PrintPointType(void);
extern void ReportEnd(BYTE);
extern void ClearAllReport(void);
extern void PrintReportHeader(void);

#endif
/***************************************************/

#ifndef PB_C
extern short StorePbInvoice(short);
extern void PrintPbHeader(void);
extern void PrintNewBal(void) ;
extern void AddPbFTotal(void) ;
extern void ReadPbF(void) ;
extern void WritePbF(void) ;
extern void GetPbFOffSet(void);
extern short GetPbNumber(void) ;
extern void ClearPb(void) ;
extern void PbTotal(WORD pbnum, BYTE cmd) ;
extern void PbFunction(void) ;
extern void GetPbtOffSet(short pbnum);
extern void AddPbtTotal(void);
extern void PrintPbtReport(void);
extern void PrintPb(WORD number);
#endif

/***************************************************/
#ifndef KP_C
extern void CmdKp(BYTE) ;
extern void PrintKp(BYTE cmd, char *str) ;
extern void PrintPbKp(BYTE) ;
extern void KpHeader(void) ;
extern void IssueKp(void) ;
extern void KpEnd(BYTE) ;
extern void PrintArticle(BYTE cmd, BYTE kp);
#endif
/***************************************************/

#ifndef PBBUFFER_C
extern BYTE UpdatePbRecord(BYTE *,BYTE) ;
extern BYTE PbBuffer(WORD);
extern void PrintPbItem(BYTE *, BYTE *, BYTE *) ;
extern BYTE StorePbBuffer(void) ;
extern void ProcessPbBuffer(WORD) ;
#if (pbAmtDisc)
extern void ProcPbBufferDisc(BYTE toLast,BYTE discType);
#endif

#endif
/***************************************************/

#ifndef GROUP_C
extern void GetGroupOffSet(void) ;
extern void AddGroupTotal(void) ;
extern void WriteGroup(void) ;
extern void ReadGroup(void) ;
#endif
/***************************************************/


#ifndef SALPER_C
extern void GetSalPerOffSet(void) ;
extern void WriteSalPer(void) ;
extern void ReadSalPer(void) ;
extern void SelectSalPer(void) ;
#endif

/***************************************************/
#ifndef BARCODE_C
/***************************************************************/
#if !(SKIP & S_BAR)
extern void CheckInStore(void) ;
#endif
#endif
/***************************************************************/

#if BONUS == 1
#ifndef BANUS_C
extern void MakeWide(char *,short) ;
extern void CalcBonusPoints(void) ;
extern char *GetBonusLine(void) ;
#endif
#endif

#ifndef MODIFIER_C
extern void GetModiOffSet(void) ;
extern void WriteModi(void) ;
extern void ReadModi(void) ;
extern void GetModifier(void) ;
#endif

#ifndef OFF_C
extern void GetOFFPriceOffSet(void);
extern void ReadOFFPrice(void);
extern void WriteOFFPrice(void);
#endif

#ifndef PORT_C
extern void GetPortOffSet(void);
extern void ReadPortPrice(void);
extern void WritePortPrice(void);
extern void SetupPort(BYTE port);
extern BYTE EnCodeProto(char * pro);
extern void DeCodeProto(BYTE In, char * out);

extern void ReadPort(void);
extern void WritePort(void);
extern void SetPortForAppl(void);
#endif

#ifndef BALANCE_C
extern short 	BalCounter;
extern short BalanceWeight();
#endif

//#ifndef ICCARD_H	//ccr chipcard
extern void PointsByChipCard(BCD *pValue);
extern void PayByChipCard(BCD *pValue,BYTE pay);
extern BYTE ChipCard(void);
extern short ReadFactory(void);         //OK
extern char RD_ChipCard(void);
extern short Clear_CHIP(void);
extern signed char Initial_CHIP(void);
extern short Charge_CHIP(void);

extern void ProgClearChip(void);
extern void ProgChargeChip(void);
extern void ProgInitialChip(void);
extern void ProgPoints(void);

extern void PrintChipCard(BYTE pSel);
extern BYTE QueryICBlock(unsigned long pICCardNO);
extern void icBCD2EcrBCD(BCD *ecrBCDTo,char *icBCDFr,BYTE pLenFr);

//#endif
/*******************************************************************************
Function Prototypes
*******************************************************************************/
extern BYTE FlashRead( unsigned long ulOff );
extern void FlashReadReset( void );
extern short FlashAutoSelect( short iFunc );
extern short FlashBlockErase( BYTE ucNumBlocks, BYTE ucBlock[]);
extern short FlashChipErase( void );
extern short FlashProgram( unsigned long ulOff, size_t NumBytes, void *Array );
extern CONSTCHAR *FlashErrorStr( short iErrNum );

extern short mFlashBlockRead( unsigned long ulOff, size_t NumBytes, void *Array );
extern short mFlashProgram( unsigned long ulOff, size_t NumBytes, void *Array );
extern short mFlashChipErase( void );
extern short mFlashBlockErase( BYTE ucNumBlocks, BYTE ucBlock[] );

extern void PROGRAMEND(void);

#ifndef ICBLOCK_C  //ccr chipcard 2004-07-01
extern void GetICBlockOffSet(void) ;
extern void WriteICBlock(void) ;
extern void ReadICBlock(void) ;
extern void PrintICBlock(void);
#endif

#ifndef AGREE_C
extern void GetAgreeOffSet(void);
extern void WriteAgree(void);
extern void ReadAgree(void);
#endif
#if DD_FISPRINTER == 1

extern void FisPrinter_Debug(void);

#ifndef BUTTON_C
extern BYTE ProcessButton(void);
extern void DisplayMess(BYTE pos,char *pMess);
extern BYTE ReadKey(void);
#endif

#endif

#if defined(DEBUGBYPC)
extern void PutString(char *str);
extern BYTE GetsO_At(BYTE addr);
extern void ProcessMessages();
extern void EnableTimer(BYTE en);
#define TestPrintGoingOn() (0)
#else
#define PutString(str) {}
#endif

#if(defined(CASE_GPRS))
extern void ProgGprsUpdateECR(void);
extern BYTE EndGprs(void);
extern BYTE StartGprs(void);
extern BYTE ASC_2_HEX(BYTE pASC);
extern void GPRSSendHEX(BYTE byte);  //send data one byte, such as  SOH and so on..
extern BYTE GPRSSkipReceived(ULONG mWaitFor);
extern short GPRSReadAString(BYTE *str,short size,ULONG sWaitFor);
// ֱ�ӴӴ��ڶ�ȡGPRS���ص����� %IPDATA......//
extern short GPRSRead_IPDATA(char *pBuff,short size,ULONG sWaitFor);
// ͨ��AT%IPSEND �������� //

extern BYTE GPRSConnectAPN(void);
extern BYTE GPRSRegisterTCPIP(void);
extern BYTE GPRSConnect_TCPIP(/*CONSTCHAR *pIP,CONSTCHAR *pPort*/);
extern BYTE GPRSSIM_Exist(void);
extern BYTE GPRSCloseTCPIP(BYTE sMode);
extern void GPRSSendByte(BYTE byte);
extern void GPRSSendAString(CONST char * str, short len);
#endif


#if defined(CASE_ETHERNET)
void ProgMAC(void);
void  ProgEthernetFuncs(void);
void PingEthernet(void);
void ETHERNET_SetSendMode(void);
void ETHERNETSendECR_FM(void);
void ETHERNETSendECR_FM_All(void);
void ETHERNET_DownloadPLU(void);
void ETHERNET_DownloadDEPT(void);
void ETHERNET_DownloadCLERK(void);
void ETHERNET_DownloadHEAD(void);
void ETHERNET_DownloadPTRAIL(void);
void ETHERNET_DownloadALL(void);
void ETHERNET_Restart(void);
#endif

void  ProgAuxFunctions(void);

#if defined(DEBUGBYPC)

#define SetLoop()  {LoopInput=1;EnableTimer(true);}
#define ResetLoop() {LoopInput=0;EnableTimer(false);}

#define PRESS_ANY_KEY(yy) do {\
                            LoopInput=1;\
                            DispStrXY((BYTE*)MsgPRESSANYKEY,0,yy);\
                            while (!KbHit())  {};\
                            Getch(); \
                            LoopInput=0;\
                          } while (0)

#define WAIT_INPUT(key)   do {\
                            LoopInput=1;\
                            while (!KbHit()){};\
                            key=Getch();\
                            LoopInput=0;\
                          } while (0)

#define WAIT_PRESS()   do {\
                            LoopInput=1;\
                            while (!KbHit()){};\
                            Getch();\
                            LoopInput=0;\
                          } while (0)

#define SECONDS(s)      (1000*s)

#else

#define SetLoop()  {}
#define ResetLoop()  {}

#define PRESS_ANY_KEY(yy) do {\
                            DispStrXY((BYTE*)MsgPRESSANYKEY,0,yy);\
                            while (!KbHit())  {};\
                            Getch();\
                          } while (0)

#define WAIT_INPUT(key)   do {\
                            while (!KbHit()){};\
                            key=Getch();\
                          } while (0)

#define WAIT_PRESS()   do {\
                            while (!KbHit()){};\
                            Getch();\
                          } while (0)

#define SECONDS(s)      (1000L*s)//ccr2017-01-20
#endif

#if (DISP2LINES)
#define PutsM(m)    Puts1(m)
#else
#define PutsM(m)    PutsO(m)
#endif


#define PrintAmt(str,amt) PrintQtyAmt(0, str, amt)

#define PrintQty(str,qty) PrintQtyAmt(qty, str, 0)

void PrintBarcodeImage(BYTE *barcode_data, BYTE len);
void CreateBarcodeImage(BYTE *barcode_data, BYTE len);
//ccr2017-08-04>>>>>>>>>>>
//�����Э������ȡ�����������(1.2.3....)
#define DeCodeRate(In) (((In) & 0x07)+1)		//bit0..bit2:Speed
//�����������(1.2.3....),�������Э��,�ҹ̶�Ϊ8Bit,1Stop,��У��
#define EnCodeRate(rateID) (((rateID-1) & 0x07) | ((0)<<3) | ((1)<<5) |   ((1)<<6))

extern void GetPortRate(BYTE *val);
BYTE BalanceCMD(void);
//ccr2017-08-04<<<<<<<<<<
BYTE GetIPByDNSFromURL(BYTE *pIP,char* pURL,char pBlock);
void SetZReportMust(void);

#if defined(CASE_EURO) //!!! GREECE_ONLY !!!
BYTE KeyOfSecondLayer(BYTE keyno);
#endif

void PrintSetHold(void);
void SavePopOutOfReceipt(void);
void PrinAllOfHold(void);

void CopyTaxRate(void);

#endif
