#define COMPUTER_C 7

#include "king.h"
#include "exthead.h"
#include "exth.h"
#include "flowbill.h"  //lyq2003
#include "EJournal.h"
#include "fiscal.h"
#include "message.h"

#define ALARMDELAY		10


extern BYTE    KeyFrHost;       //ApplVar.Key code from host computer.

BYTE	Alarm;

void DowmLoadBINCLIB();

//void DowmLoadHEXCLIB();

void PrnBuffer(char *buf,short len);


//    #if (PCREMOTE==1)
#if (PC_EMUKEY==1)

#include "FEcrTest.h"

#if (CC_DEBUG==1)
CONST char CommCanBe[]="EJXPUDCISRFpwmMK";    //K for PCREMOTE
WORD	Viewpi;
BYTE	ViewBuffer[0xff+1];
#else
CONST char CommCanBe[]="EJXPUDCISRFK";		//K for PCREMOTE
#endif

#else

#if (CC_DEBUG==1)
CONST char CommCanBe[]="EJXPUDCISRFpwmM";    //K for PCREMOTE
WORD	Viewpi;
BYTE	ViewBuffer[0xff+1];
#else
CONST char CommCanBe[]="EJXPUDCISRF";		//K for PCREMOTE
#endif //    cc added end

#endif

BYTE	SOH_STX;	//ccr070214
WORD	BCC;

BYTE RS485Flag;	//��RS485Flag��sizeof(RS485_POLLME)+1ʱ�����տ���Ѿ�������485ͨѶ    //
BYTE RS485Ecr;	//����485����ʱ�ĵ�ǰ�տ����   050331

short		PCCounter;

BYTE DialTime;// store the second when dialup
BYTE DialSkiped;//flags

#if (CC_DEBUG==1)
void	SaveView(BYTE dat)
{
	ViewBuffer[Viewpi]=dat;
	Viewpi++;
	if (Viewpi>=sizeof(ViewBuffer))
		Viewpi = 0;
}
#endif

void ExchageXY(BYTE *x,BYTE *y)
{
    BYTE t;

    t = *x;
    *x = *y;
    *y =t;
}
//===================================================================
//  ��ȡ��ǰ��    //
BYTE GetSecond()
{
	Bios_1(BiosCmd_GetTime);
	DialTime = (rtc_time.ss>>4)*10 + (rtc_time.ss & 0x0f);
	DialSkiped = 0;
	return (DialTime);
}
//===================================================================
//�����GetSecond��ʼ���տ��������������  //
BYTE SecondsPassed()
{
	BYTE sSec;

	Bios_1(BiosCmd_GetTime);
	sSec = (rtc_time.ss>>4)*10 + (rtc_time.ss & 0x0f);
	if (sSec<DialTime)
		DialSkiped += sSec + 60 - DialTime;
	else
		DialSkiped += sSec - DialTime;
	DialTime = sSec;
	return DialSkiped;
}



void SendString(CONSTCHAR *sStr,short len)
{

	if (len==-1)
		len = strlen(sStr);
	Bios_PortWrite(COMPUTER_1+1, (void*)sStr, len, 1);
}

void DispProgress(short len,char sCh)
{
	char sBuf[DISLEN+1];

	MemSet(sBuf,DISLEN,' ');
	MemSet(sBuf,len%DISLEN+1,sCh);
	sBuf[DISLEN] = 0;
	PutsO(sBuf);
}

short ReadString(char *sStr,short size)
{
	short i,j,retry;
	i = retry = 0;
	while (i<size && retry<5)
	{
		j = ReadComm(COMPUTER_1);
		if (j!=-1)
		{
			sStr[i++]=j & 0xff;
			if (j==0x0d || j==0x0a)
			{
				sStr[i]=0;
				return i;
			}
		}
		else
			retry++;
	}
	return 1;
}


char InitModem()
{
    short i,j;

	SendString("ate0\r",-1);
	Delay(ASECOND/2);
 	SendString("atv0\r",-1);
	Delay(ASECOND/2);
	SendString("ats0=3\r",-1);
	Delay(ASECOND/2);
	SendString("at&w0\r",-1);
	Delay(ASECOND/2);
  	EmptyComm(COMPUTER_1);	/* empty port */
	SendString("at\r",-1);
	for (i=10;(i && (j=ReadComm(COMPUTER_1)) == -1);i--);
  	EmptyComm(COMPUTER_1);	/* empty port */
	DialTime = DialSkiped = 0;//flags
	return (j=='0');
}

void DialOverModem(char *pTeleNo)
{

	strcpy(SysBuf, "DIAL ");
	strcpy(SysBuf+5,pTeleNo);
	PutsO(SysBuf);
	SendString("atd ",-1);
	SendString(pTeleNo,-1);
	SendString("\r",-1);

	PCCounter = 0;
	Bios_1(BiosCmd_GetTime);
	GetSecond();
	DialSkiped = 1;//Must be
}


void HandDownModem()
{
	SendString("+++",-1);
	Delay(2*ASECOND);
	SendString("ath\r",-1);
	Delay(ASECOND);
   	EmptyComm(COMPUTER_1);	/* empty port */
   	PCCounter = 0;
	DialTime = DialSkiped = 0;//flags
}


/*
	When CheckComm return SOH, system can read data from rs232 use readcomm.
    the first byte is the length of data-L, then are the Byte data-B;
    the last is verify byte-V;
    V = ~(L + B)+1
*/
//ccr090409 485>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
BYTE SendRecord(BYTE *p ,BYTE length )
{
    BYTE bcc,retry,i,cpT,s485;
    BYTE *record;
    short sACK;

    if (!(length && COMPUTER))
		return FALSE;
   	EmptyComm(COMPUTER_1);	/* empty port */

	s485 = COMPUTER_1;
	if (ApplVar.PortList[COMPUTER_1].Type=='2')
		s485 |= 0x80;

    for (retry=0;retry<10;retry++)
    {
		if (s485 & 0x80)
			retry = 100;
		SendComm(s485, SOH);
	    for (i=10;(i && (sACK =ReadComm(COMPUTER_1)) != ACK && sACK != NAK);i--);
	    if (!i || sACK==NAK)
	     	return FALSE;
	    record = p;
	    bcc = length;

		if (s485 & 0x80)
		{
			bcc+=2;
		    SendComm(s485, bcc);
		    SendComm(s485, 0x80);
		    SendComm(s485, REGISTER);
			bcc += (0x80+REGISTER);
		}
		else
		    SendComm(s485, bcc);

        for (i = 0;i<length;i++)
        {
	        bcc += *record;
	        record += 1;
	    }
	    cpT = *record;
	    *record = (~bcc+1);

		if (s485 & 0x80)
		{
			Delay(DELAY485);
			ClrRTS(COMPUTER_1);
		}
		Bios_PortWrite(COMPUTER_1+1, p, length+1, 1);
		if (s485 & 0x80)
		{
			Delay(DELAY485);
			SetRTS(COMPUTER_1);
		}

        *record = cpT;

	    for (i=10;(i && ((sACK =ReadComm(COMPUTER_1)) != ACK) && sACK != NAK);i--);

	    if (sACK==NAK)
	    	return false;

	    if (i)
	    	return TRUE;
    }
    return FALSE;
}
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

BYTE SendComp(BYTE type,BCD *tot)
{
    if (!ApplVar.RepComputer)
		return 0;
    SysBuf[2] = type;
    memcpy(SysBuf+7, tot, sizeof(BCD));
    return SendRecord(SysBuf, 7 + sizeof(BCD));
}

void PrnBuffer(char *buf,short len)
{
	short i,j;
	char sBuf[36];

	i = 0;
	for (j=0;j<len;j++)
	{
		if (!i)
			memset(sBuf,' ',sizeof(sBuf));
		HEXtoASC(sBuf+i*3,buf+j,1);
		i++;
#if	(PRTLEN<25)
		if (j % 8 == 7)
#else
		if (j % 10 == 9)
#endif
		{
			RJPrint(0,sBuf);
			i = 0;
		}
	}
	if (i)
		RJPrint(0,sBuf);
}

short ReadModem()
{
    BYTE sOK;
    short c;

	sOK = FALSE;
	while (!sOK)
	{
		if (!CheckComm(COMPUTER_1) || (c = ReadComm(COMPUTER_1))==-1 || c<0x0a || c>'z')
			break;

		PCBuffer[PCCounter++] = c & 0xff;
		PCBuffer[PCCounter] = 0;
		PutsO(PCBuffer);
		if (PCCounter>=PCBUFMAX)
		{
			PCCounter = 0;
			break;
		}
		if  (c==0x0d || c==0x0a)
			sOK = TRUE;
	}
	return sOK;
}
//ccr090409 485>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
//communicat with Host computer throw Rs232 port
unsigned Computer()
{
	BYTE length, bcc,s485;
	short i;
    unsigned lp;

	if (COMPUTER)
	{
		ApplVar.PortNumber = COMPUTER_1;
		ReadPort();
		s485 = COMPUTER_1;
		switch (ApplVar.Port.Type){
			case '2':/* RS485 mode, ��������ڱ��տ��������,�������� */
				s485 |= 0x80;
				while (TRUE)
				{
					if (!CheckComm(COMPUTER_1) || (i = ReadComm(COMPUTER_1))==-1)//ccr485
						return false;
#if (DD_FISPRINTER==0)//ccr091223
					Alarm = ALARMDELAY;
#endif
					bcc = i & 0xff;
					if (!PCCounter)
					{
						if (bcc == SOH)/* Comm data not ok */
						{
							SOH_STX = SOH;
							PCCounter = 0xff;	/* set the flag,begin read data from host */
						}
						continue;
					}

					if (PCCounter == 0xff)
						PCCounter = 0;

					if (SOH_STX==SOH)//ccr070214
					{
						PCBuffer[PCCounter++] = bcc;
						if (PCCounter==4)
						{// Len+0x80+ECR+CMD received
							if (strchr(CommCanBe,bcc)==NULL || PCBuffer[1] != 0x80)
							{
								if(PCBuffer[0]==SOH)
								{
									PCBuffer[0] = PCBuffer[1];
									PCBuffer[1] = PCBuffer[2];
									PCBuffer[2] = PCBuffer[3];
									PCCounter = 3;
								} else if(PCBuffer[1]==SOH)
								{
									PCBuffer[0] = PCBuffer[2];
									PCBuffer[1] = PCBuffer[3];
									PCCounter = 2;
								} else if(PCBuffer[2]==SOH)
								{
									PCBuffer[0] = PCBuffer[3];
									PCCounter = 1;
								}else if (PCBuffer[3]==SOH)
								{
									PCCounter = 0xff;
								}
								else
								{
									SOH_STX = 0;
									PCCounter = 0;
								}
							}
						}

						if (PCCounter>PCBUFMAX-2)
						{
							PCCounter = 0;
//							SendComm(s485, NAK);        /* sent NAK */
							continue;
						}
						if (PCBuffer[0]==(PCCounter-2))
								break;/* a package recived,include verify byte */
					}
				}
				break;
			case '3':/* MODEM mode */
				if (DialSkiped>0 && DialSkiped<0xff)
				{
					if (SecondsPassed()>120)
						DialSkiped = 0;
				}
				if (DialSkiped<0xff)
				{
					if (ReadModem())
					{
#if (DD_FISPRINTER==0)//ccr091223
						Alarm = ALARMDELAY;
#endif
	//					if (PCCounter<=3)
						{
							PCCounter = 0;
							if (PCBuffer[0]>='0' && PCBuffer[0]<='9')
							{
								bcc = PCBuffer[0]-'0';
								if (PCBuffer[1]>='0' && PCBuffer[1]<='9')
									bcc = bcc * 10 + PCBuffer[1] - '0';
							}
							else if (PCBuffer[0]=='C' && PCBuffer[1]=='O' && PCBuffer[2]=='N' && PCBuffer[3]=='N'
								&& PCBuffer[4]=='E' && PCBuffer[5]=='C' && PCBuffer[6]=='T')
								bcc = 15;
							else
								bcc = 0;
							if (bcc>10)
							{
								PutsO(MessageE35);
								DialSkiped = 0xff;
							}
							else
								DialSkiped = 0;
							return FALSE;
						}
					}
				}
			case '1':
				while (TRUE)
				{
					if (!CheckComm(COMPUTER_1) || (i = ReadComm(COMPUTER_1))==-1)//ccr485
						return false;

#if (DD_FISPRINTER==0)//ccr091223
					Alarm = ALARMDELAY;
#endif
					bcc = i & 0xff;

					if (!PCCounter)
					{
						if (bcc == SOH)/* Request SOH Received */
						{
							SOH_STX = SOH;
							EmptyComm(COMPUTER_1);
//ccr2016-07-08 testonly							SendComm(COMPUTER_1, ACK);        /* sent ACK */
							PCCounter = 0xff;	/* set the flag,begin read data from host */

#if PC_EMUKEY == 0
							PutsO(MessageE36);
#endif

						}
#if defined(FISCAL)
						else if (bcc==STX)//ccr070214>>>>>>>>>>>>>
						{
							SOH_STX = STX;
							BCC = STX;
							PCCounter = 0xff;	/* set the flag,begin read data from host */
						}//<<<<<<<<<<<<<<
#endif
						continue;
					}

					if (PCCounter == 0xff)
						PCCounter = 0;

					if (SOH_STX==SOH)//ccr070214
					{
						PCBuffer[PCCounter++] = bcc;
						if (PCCounter==2)
						{
							if (ApplVar.Port.Type=='3' && PCBuffer[0]=='3' && PCBuffer[1]==0x0d)
							{
								PutsO(MessageE37);
								PCCounter = 0;
								DialTime = DialSkiped = 0;/* flags */
							}
							else if (strchr(CommCanBe,bcc)==NULL)
							{
								if(PCBuffer[0]==SOH)
								{
									PCBuffer[0] = PCBuffer[1];
									PCCounter = 1;
								}else if (PCBuffer[1]==SOH)
								{
									PCCounter = 0xff;
								}
								else
								{
									SOH_STX = 0;
									PCCounter = 0;
								}
							}
						}

						if (PCCounter>PCBUFMAX-2)
						{
							PCCounter = 0;
//ccr2016-07-08	testonly						SendComm(COMPUTER_1, NAK);        /* sent NAK */
							PutsO(MessageE1);
							RJPrint(0,MessageE2);

							continue;
						}
						if (PCBuffer[0]==(PCCounter-2))
								break;/* a package recived,include verify byte */
					}
#if defined(FISCAL)//ccr070214>>>>>>>>>>>>>>>>>>>>
					else if (SOH_STX==STX)
					{
						//ccr070322>>>>>>>>>>>>>>>
						if (!PCCounter)
							PCBuffer[PCCounter++] = FISCOMM;//Ϊ˰������ͨѶ����
						//<<<<<<<<<<<<<<<<<<<<<<<<

						BCC += bcc;
						PCBuffer[PCCounter++] = bcc;//ccr070322
						if (bcc==ETX)
						{
							for (length=0;length<4;length++)
							{// receive BCC from host(4 bytes)
								GetSecond();
								while (!CheckComm(COMPUTER_1) || (i = ReadComm(COMPUTER_1))==-1)
								{
									if (SecondsPassed()>2)
									{
										PCCounter = 0;
//ccr2016-07-08	testonly									SendComm(COMPUTER_1, NAK);        /* sent NAK */
										return false;
									}
								}
#if (DD_FISPRINTER==0)//ccr091223
								Alarm = ALARMDELAY;
#endif
								if (PCCounter>=PCBUFMAX)
								{
									PCCounter = 0;
//ccr2016-07-08	testonly								SendComm(COMPUTER_1, NAK);        /* sent NAK */
									return false;
								}
								else
									PCBuffer[PCCounter++] = (i & 0xff);
							}
							break;
						}

						else if (PCCounter>=PCBUFMAX)
						{
							PCCounter = 0;
//ccr2016-07-08	testonly						SendComm(COMPUTER_1, NAK);        /* sent NAK */
							continue;
						}
					}//<<<<<<<<<<<<<<<<<<<<<
#endif
				}
				break;
			default:
				PCCounter = 0;
				return false;
		}

		if (SOH_STX==SOH)//ccr070214
		{
			SOH_STX= 0;
			bcc = PCBuffer[0];
			for (lp=1;lp<=PCBuffer[0];lp++)
				bcc += PCBuffer[lp];

			if ((bcc+PCBuffer[PCCounter-1]) & 0xff)/* the verify error */
			{
				if (ApplVar.Port.Type!='2')
				{
					PutsO(MessageE3);
					if (TESTBIT(PRNHOST,BIT0))
					{
						RJPrint(0,MessageE3);
						PrnBuffer(PCBuffer,PCCounter);
					}
//ccr2016-07-08	testonly				SendComm(COMPUTER_1, NAK);
				}
//				else if (PCBuffer[2]==REGISTER)
//					SendComm(s485, NAK);
				PCCounter = 0;
				return false;
			}
			if (ApplVar.Port.Type=='2')
			{
				if (PCBuffer[2]!=REGISTER)
				{
					PCCounter = 0;
					return false;
				}
				lp = PCBuffer[0]-2;
				memcpy(PCBuffer,PCBuffer+3,lp);
			}else
			{

				lp = PCBuffer[0];
				memcpy(PCBuffer,PCBuffer+1,lp);
			}
#if PC_EMUKEY == 0
			PutsO(MessageE4);
#endif
//ccr2016-07-08 testonly			SendComm(s485, ACK);
			PCCounter = 0;
			return lp;// return the length
		}
#if defined(FISCAL)			//ccr070214>>>>>>>>>>>>>>>>>>
		else if (SOH_STX==STX)
		{
			SOH_STX= 0;

			if (BCC != StrToHex(PCBuffer+PCCounter-4,4))// error of BCC
			{
				PCCounter = 0;
//ccr2016-07-08	testonly			SendComm(COMPUTER_1, NAK);        /* sent NAK */
				return false;
			}
			lp = PCCounter;
			PCCounter = 0;
			return lp;
		}
#endif			//<<<<<<<<<<<<<<<<<<<<<<<<<<<<
	}
	//else
	return false;
}
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

/**
 * �����յ�����PC���������������
 * PCBuffer�а��������������
 * @author EutronSoftware (2015-04-22)
 */
extern void UpdateBIOS();
extern void EnterBootLoader();
#define SIZE_IAP    2048    //size of UpdateBios

void ProcessRecord()
{
    WORD start, end, sMax, id, save, type;
    short size;
    UnLong sAddr;
    char *record;
    BYTE sPC,sBAR,sBAL,sEcrNo,sLocate,sEXTMem;
	void  (*RefreshBIOS)();

    type = *((WORD *)(PCBuffer + 1));
    id = 0;
    if (type > PLU1 || (type >= UPDPLU && type <= REPPLU))
	    save = ApplVar.PluNumber;
    else if (type > DEPT)
        save = ApplVar.DeptNumber;
    else if (type > CLERK)
         save = ApplVar.ClerkNumber;
    else if (type > SALPER)
         save = ApplVar.SalPerNumber;
    switch(PCBuffer[0]){       /* determine record type */
    case 'U':
    #if !defined(DEBUGBYPC)
            if (PCBuffer[1]=='B' && PCBuffer[2]=='I' && PCBuffer[3]=='O' && PCBuffer[4]=='S')
    		{
                Save_ConfigVar(true);

                //������SET������MAC�������̽�
    			if (ApplVar.CentralLock == SET || Bios_TestMAC())
                {
                    strcpy(SysBuf,UPCOMM[UOK]);
                    SendRecord(SysBuf,3);

                    PutsO("Update BIOS----");
#if (DD_ZIP || DD_ZIP_21)
					Puts1("Don't Power off");
#endif
                    sAddr = ((ULONG)PCBuffer+260) & 0xfffffffcL;
                    if (sAddr+SIZE_IAP>=(SRAM_BASE+MCU_RAM_SIZE-256))
                    {
                        //DispStrXY(Msg[JSHDPSHL].str,0,2);//�ڴ����
                        sAddr = ((ULONG)PCBuffer-SIZE_IAP) & 0xfffffffcL;
                    }
                    {
                        __disable_irq();    //��ֹ�����ж�,���⽫����ϵͳ�����쳣
                        __disable_fault_irq();

                        if ((ULONG)&UpdateBIOS & 1)
                        {
                            memcpy((char *)sAddr,((char *)UpdateBIOS)-1,SIZE_IAP);//(char *)&EndOfIAP-(char *)&UpdateBIOS+1);
                            sAddr +=1;
                        }
                        else
                        {
                            memcpy((char *)sAddr,((char *)UpdateBIOS),SIZE_IAP);//(char *)&EndOfIAP-(char *)&UpdateBIOS+1);
                        }
                        RefreshBIOS = (void*)sAddr;

                        //RefreshBIOS = UpdateBIOS;
                        (*RefreshBIOS)();//    			UpdateBIOS();
                        while (1){}
                    }
                }
                else
                {
                    strcpy(SysBuf,UPCOMM[UCA]);
                    SendRecord(SysBuf,3);
                    return;
                }
                break;
    		}
    #endif
	case 'u':
	    if (type > MERGEPLU-1 && type < REPPLU+1)
	    {
			CheckPluFile(type);
			ApplVar.ErrorNumber=0;
			break;
		}
	case 'D':           /* command for dump program */
#if(defined(FISCAL))	//cc 20071026
//ccr2014-11-03		if(ApplVar.FTrain)
//ccr2014-11-03			return;
#endif

	    size = 0;
	    record = 0;
	    switch(type)  {
		case PROMO:
		    size = sizeof(ApplVar.AP.Promotion);
			record = (char *)&ApplVar.AP.Promotion;
			break;
		case SALPER:
		    size = sizeof(ApplVar.AP.SalPer);
			record = (char *)&ApplVar.AP.SalPer;
		    break;
		case OPTIONS:
		    size = sizeof(ApplVar.AP.Options);
			record = (char *)&ApplVar.AP.Options;
		    break;
		case PROGID :  /* program ID data */
		    size = sizeof(Release);
			record = (char *)Release;
		    break;
		case SYSFLG :  /* system Flags */
		    size = sizeof(ApplVar.AP.Flag);
			record = (char *)ApplVar.AP.Flag;
		    break;
		case START :  /* start addresses */
			size = sizeof(ApplVar.AP.StartAddress) ;
			record = (char *)ApplVar.AP.StartAddress;
		    break;
		case RCONFIG : /* config */
		    size = sizeof(ApplVar.AP.Config);
			record = (char *)&ApplVar.AP.Config;
		    break;
		case RDAY : /* DAY table */
		    size = sizeof(ApplVar.AP.Day);
			record = (char *)&ApplVar.AP.Day;
		    break;
		case RMONTH : /* ApplVar.Month table */
		    size = sizeof(ApplVar.AP.Month);
			record = (char *)&ApplVar.AP.Month;
		    break;
		case RZONE : /* zone table */
		    size = sizeof(ApplVar.AP.Zone);
			record = (char *)&ApplVar.AP.Zone;
		    break;
		case RTOTAL : /* ApplVar.Total sales */
		    size = sizeof(ApplVar.AP.Sales);
			record = (char *)&ApplVar.AP.Sales;
		    break;
		case KEY0 :
		    size = 64;     /* 64 bytes is 32 keys */
			record = (char *)ApplVar.AP.KeyTable;
		    break;
		case KEY32 :
		    size = 64;     /* 64 bytes is 32 keys */
			record = (char *)&ApplVar.AP.KeyTable[32];
		    break;
//		case KEY64 :
//		    size = 64;     /* 64 bytes is 32 keys */
//			record = (char *)&ApplVar.AP.KeyTable[64];
//		    break;
//		case KEY96 :
//		    size = 64;     /* 64 bytes is 32 keys */
//			record = (char *)&ApplVar.AP.KeyTable[96];
//		    break;
		case RREP1 :        /* user report 1,2 & 3 */
		    size =  3 * sizeof(struct FIXEDREPORT);
			record = (char *)&ApplVar.AP.ReportList[0];
		    break;
		case RREP2 :        /* user report 4,5 & 6 */
		    size =  3 * sizeof(struct FIXEDREPORT);
			record = (char *)&ApplVar.AP.ReportList[3];
		    break;
		case RREP3 :        /* user report 7,8 & 9 */
		    size = 3 * sizeof(struct FIXEDREPORT);
			record = (char *)&ApplVar.AP.ReportList[6];
		    break;
		case RREP4 :        /* user report 7,8 & 9 */
		    size = 3 * sizeof(struct FIXEDREPORT);
			record = (char *)&ApplVar.AP.ReportList[9];
		    break;
		case RREP5 :        /* user report 7,8 & 9 */
		    size = 1 * sizeof(struct FIXEDREPORT);
			record = (char *)&ApplVar.AP.ReportList[12];
		    break;

		case REPCAP1 :        /* report types 0 - 6 */
		    size = 7 * REPWIDTH;
			record = (char *)ApplVar.TXT.ReportType;
		    break;
		case REPCAP2 :        /* report types 7 - 13 */
		    size = 7 * REPWIDTH;
			record = (char *)ApplVar.TXT.ReportType[7];
		    break;
		case REPCAP3 :        /* messages 14 - 15 */
		    size = 2 * REPWIDTH;
			record = (char *)ApplVar.TXT.ReportType[14];
		    break;
		case RHEAD1 :       /* receipt header 0 - 4 */
		    size = 5 * sizeof(ApplVar.TXT.Header[0]);
			record = (char *)ApplVar.TXT.Header;
		    break;
		case RHEAD2 :       /* receipt header 5 - 7 */
		    size = 3 * sizeof(ApplVar.TXT.Header[0]);
			record = (char *)ApplVar.TXT.Header[5];
		    break;
		case RTRAIL1 :       /* receipt trailer 0 - 4 */
		    size = 5 * sizeof(ApplVar.TXT.Trailer[0]);
			record = (char *)ApplVar.TXT.Trailer;
		    break;
		case RTRAIL2 :       /* receipt trailer 5 - 5 */
		    size = 1 * sizeof(ApplVar.TXT.Trailer[0]);
			record = (char *)ApplVar.TXT.Trailer[5];
		    break;
		case RSLIPH1 :       /* slip header 0 - 2 */
		    size = 3 * SHEADWIDTH;
			record = (char *)ApplVar.TXT.SlipHeader;
		    break;
		case RSLIPH2 :       /* receipt header 3 - 5 */
		    size = 3 * SHEADWIDTH;
			record = (char *)ApplVar.TXT.SlipHeader[3];
		    break;

		case FIRM :
		    size = sizeof(ApplVar.AP.FirmKeys);
			record = (char *)ApplVar.AP.FirmKeys;
		    break;
		case MNGR :
		    size = sizeof(ApplVar.AP.Manager);
			record = (char *)ApplVar.AP.Manager;
		    break;
		case CORREC :
		    size = sizeof(ApplVar.AP.Correc);
			record = (char *)&ApplVar.AP.Correc;
		    break;
		case CURR :
		    size = sizeof(ApplVar.AP.Curr);
			record = (char *)&ApplVar.AP.Curr;
		    break;
		case DISC :
		    size = sizeof(ApplVar.AP.Disc);
			record = (char *)&ApplVar.AP.Disc;
		    break;
		case DRAW :
		    size = sizeof(ApplVar.AP.Draw);
			record = (char *)&ApplVar.AP.Draw;
		    break;
		case PBF :
		    size = sizeof(ApplVar.AP.Pb);
			record = (char *)&ApplVar.AP.Pb;
		    break;
		case PORA :
		    size = sizeof(ApplVar.AP.PoRa);
			record = (char *)&ApplVar.AP.PoRa;
		    break;
		case TEND :
		    size = sizeof(ApplVar.AP.Tend);
			record = (char *)&ApplVar.AP.Tend;
		    break;
		case MODI :
		    size = sizeof(ApplVar.AP.Modi);
			record = (char *)&ApplVar.AP.Modi;
		    break;
		case TAX :
		    size = sizeof(ApplVar.AP.Tax);
			record = (char *)&ApplVar.AP.Tax;
		    break;
		case CLERK :
		    size = sizeof(ApplVar.AP.Clerk);
			record = (char *)&ApplVar.AP.Clerk;
		    break;
		case GROUP :
		    size = sizeof(ApplVar.AP.Group);
			record = (char *)&ApplVar.AP.Group;
		    break;
		case DEPT :
		    size = sizeof(ApplVar.AP.Dept);
			record = (char *)&ApplVar.AP.Dept;
		    break;
		case PLU1 :
		    size = sizeof(ApplVar.AP.Plu);
			record = (char *)&ApplVar.AP.Plu;
		    break;
		case OFFER:
		    size = sizeof(ApplVar.AP.OFFPrice);
			record = (char *)&ApplVar.AP.OFFPrice;
		    break;
		case AGREE :
		    size = sizeof(ApplVar.AP.Agree);
			record = (char *)&ApplVar.AP.Agree;
		    break;
		case BLOCKIC:		//ccr chipcard
		    size = sizeof(ApplVar.AP.ICBlock);
			record = (char *)&ApplVar.AP.ICBlock;
			break;
		case CHIPCARDSET:	//ccr chipcard
		    size = sizeof(ApplVar.ICCardSet);
			record = (char *)&ApplVar.ICCardSet;
			break;
		case REMOTESETTIME :
			if (TESTBIT(ApplVar.MyFlags,ZREPORT))   /* z report taken ? */
			{
				CheckError(13);
				*((WORD *)PCBuffer) = 0xff;  /* id means end */
	    		SendRecord(PCBuffer, 2);   /* send end record */
			}
			else
            {
                if (ApplVar.ErrorNumber==0) //ccr2014-08-08
                {
                    memcpy(&EntryBuffer[sizeof(EntryBuffer) - 9],&PCBuffer[3],8);
                    Appl_EntryCounter = 8;
                    NewTimeDate(1);
                    memcpy(&EntryBuffer[sizeof(EntryBuffer) - 7],&PCBuffer[11],6);
                    Appl_EntryCounter = 6;
                    NewTimeDate(2);
                }
				if(ApplVar.ErrorNumber!=0)
				{
					CheckError(13);
					*((WORD *)PCBuffer) = 0xff;  /* id means end */
	    			SendRecord(PCBuffer, 2);   /* send end record */
				}
				else
				{
					CheckError(0);
					*((WORD *)PCBuffer) = 0;  /* id means end */
	    			SendRecord(PCBuffer, 2);   /* send end record */
				}
			}
	    	break;
		default :
		    break;
	    }//switch(type)
	    if (size)
	    {//update the definition of the file
		    if (PCBuffer[0] == 'U')   /* update */
		    {
#if defined(FISCAL)//ccr2014-11-03>>>>>>>>>>>
                if (ApplVar.ZReport != 1)   /* z report taken ? */
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI75);
                    return ;//ccr2014 break;
                }
#endif//<<<<<<<<<<<<<

				sEcrNo = REGISTER;
                sLocate = LOCATION;
	        	sPC = COMPUTER;
	        	sBAR = BARCODE;
				sBAL = BALANCE;//lyq added 2003\10\27
				sEXTMem = EXTRAMN;

				if (type == CHIPCARDSET)
					sAddr = ApplVar.ICCardSet.PosCode;
#if defined(FISCAL)//ccr070612>>>>>>
				if (type<RHEAD1 || type>RHEAD2)
#endif//<<<<<<<<<<<<<<<<<<<
					memcpy((char*)record, &PCBuffer[3], size);	//20111226

				if (type == CHIPCARDSET)
					ApplVar.ICCardSet.PosCode = sAddr;
		        if (type == SYSFLG)
		        {
			        InitSysFlag();
			        COMPUTER = sPC;
			        BARCODE = sBAR;
					BALANCE = sBAL;
					REGISTER = sEcrNo;
					EXTRAMN = sEXTMem;
                    LOCATION = sLocate;

			    }
			    else if (type == START)
			    {
					ClearAppMemory();
					if	(ResetStartAddress(true)==false)//�ָ�Ϊ���Ե�ַ
					{
						Bell(2);
						RJPrint(0,MessageE5);


                        //���¼����ڴ��п����ɵĵ�Ʒ��Ŀ
                        sAddr = ApplVar.AP.StartAddress[AddrEndP] - ApplVar.SIZE_EXTRAM;

                        sAddr /= pluRecordSize;
                        sAddr++;//Ϊ��Ҫ���ٵĵ�Ʒ��Ŀ
                        sMax = sAddr;
                        sAddr *= pluRecordSize;//�����ٵĵ�Ʒ��ռ�õĿռ�
                        if (sMax<ApplVar.AP.Plu.Number)
                        {
                            ApplVar.AP.Plu.Number -= sMax;
                            if (ApplVar.AP.Plu.RNumber>ApplVar.AP.Plu.Number)
                                ApplVar.AP.Plu.RNumber = ApplVar.AP.Plu.Number;
                        }
                        else
                        {
                            RJPrint(0,MessageE18);//"!!!! FAT(PLU) ERROR !!!!"
                            ApplVar.AP.Plu.Number = ApplVar.AP.Plu.RNumber = 0;
                        }

                        for (sMax = AddrPLU+1;sMax<AddrMAX;sMax++)
                            ApplVar.AP.StartAddress[sMax] -= sAddr;

					}
					//ApplVar.MyFlags = 0;
			    }
			    else if (type == KEY0 || type == KEY32)
			    {
			    	MaskKeyBoard(1);
					DeptPluKeysCount();

                    ApplVar.AP.FirmKeys[ID_SHIFTDEPT] = 0xff;
                    ApplVar.AP.FirmKeys[ID_DATE] = 0xff;
                    ApplVar.AP.FirmKeys[ID_RJFEED] = 0xff;
                    ApplVar.AP.FirmKeys[ID_CLEAR] = 0xff;
                    ApplVar.AP.FirmKeys[ID_LOCK] = 0xff;

                    for (id=0;id<MAXKEYB;id++)
                    {
                        switch (ApplVar.AP.KeyTable[id]){
                        case SHIFT1:
                            ApplVar.AP.FirmKeys[ID_SHIFTDEPT] = id;
                            break;
                        case DATETIME:
                            ApplVar.AP.FirmKeys[ID_DATE] = id;
                            break;
                        case JPF:
                        case RPF:
                            ApplVar.AP.FirmKeys[ID_RJFEED] = id;
                            break;
                        case CLEAR:
                            ApplVar.AP.FirmKeys[ID_CLEAR] = id;
                            break;
                        case MODELOCK:
							ApplVar.AP.FirmKeys[ID_LOCK] = id;
							break;
						}
					}
			    }
                Save_Config(true);//ccr2016-01-15
		        break;
		    }

            //Ϊ'D'����,���������ݷ��͸�����
            if (type == START)//ת��Ϊ��Ե�ַ���͸�����
                ResetStartAddress(false);
            *((WORD *)PCBuffer) = type;  /* id */
            memcpy(PCBuffer + 2, record, size);
            SendRecord(PCBuffer, size + 2);   /* send record */
            if (type == START)//�ָ�Ϊ���Ե�ַ
            {
                ResetStartAddress(true);
#if(CASE_RAMBILL)
                Init_Flow();
#endif
            }
            Save_Config(true);//ccr2014-10-30
	    }
	    else if (type == PBTRAIL)    /* ApplVar.PB Extra Trailer */
        {
	        if (ApplVar.AP.Pb.NumberOfPb && TESTBIT(ApplVar.AP.Pb.Random, BIT7))
	        {
	          	RamOffSet = (ApplVar.AP.Pb.Random & 0x0f) + ApplVar.AP.Pb.Text + ApplVar.AP.Pb.AmtSize + 6;
		        if (TESTBIT(PBINFO, BIT7))      /* Discount item stored ? */
			    	RamOffSet += ((ApplVar.AP.Pb.AmtSize + 1) * 2);
	            RamOffSet *= ApplVar.AP.Pb.NumberOfPb;
		        RamOffSet += ApplVar.AP.StartAddress[AddrPBt] ;

	            start = *((WORD *) &PCBuffer[3]);
	            if (start < 50)
	            {
		            start *= (PRTLEN+1);
	                RamOffSet += start;
		            if (PCBuffer[0] == 'U')    /* Update ? */
		            {
		                WriteRam(&PCBuffer[5], 5 * (PRTLEN+1));     /* write Block */
		                 break;
		            } else
		            {
		                *((WORD *)PCBuffer) = PBTRAIL;
		                start = 0;
		                for(;;)
		                {
			                ReadRam(&PCBuffer[4], 5 * (PRTLEN+1));     /* read Block */
			                *((WORD *)(PCBuffer + 2)) = start;
			                /* send record */
			                if (!SendRecord(PCBuffer, (5 * (PRTLEN+1)) + 4))
			                    break;
			                start += 5;
			                if (start > 45)
			                    break;
		                }
		            }
                }
	        }
        } else if (type == CCHAR) /* defined(CASE_FORHANZI)  characters ? */
	    {
	    	RamOffSet = 0 ;                                 /* always located at ram start */
            if (PCBuffer[0] == 'U')    /* Update ? */
            {
	            start = *((WORD *) &PCBuffer[3]);             /* character number */
			    if (start < ApplVar.AP.Options.ChinaChar) {
				    start *= 34;
			      	RamOffSet += start;
	            	WriteRam(&PCBuffer[5], 34);     /* write character */
			    }
                break;
		    } else
            {
	            *((WORD *)PCBuffer) = CCHAR;
                for(start = 0; start < ApplVar.AP.Options.ChinaChar; start++)
                {
		            ReadRam(&PCBuffer[4], 34);     /* read char */
	                *((WORD *)(PCBuffer + 2)) = start;
	                /* send record */
	                if (!SendRecord(PCBuffer, 34 + 4))
		                break;
                }
		    }
	    } else
        {
            if (type == ADDPLU || type == DELPLU || type == UPDPLU)
            {
                if (PCBuffer[0] != 'U')
	                break;
                if (ApplVar.AP.Plu.RandomSize && ApplVar.AP.Plu.Number)
                {
	                ApplVar.Key.Code = 0;   /* suppress repeat */
	                memcpy(&ApplVar.Plu, &PCBuffer[3], sizeof(ApplVar.Plu));
				    ApplVar.PluNumber = GetPluNumber(1, ApplVar.Plu.Random);        /* fill ApplVar.PluNumber with number */
		            switch(type) {
		            case DELPLU:
		                if (ApplVar.PluNumber)
                        {
			                CheckRandomPlu(1, 1);       /* delete plu */
                            SETBIT(ApplVar.MyFlags,CONFIGECR);
                        }
		                break;
		            case ADDPLU:
		                if (!ApplVar.PluNumber)  /* Not Found then move and Add */
		                {
			                if (CheckRandomPlu(0, 1))
								ApplVar.PluNumber = GetPluNumber(0, ApplVar.Plu.Random);        /* fill ApplVar.PluNumber with number */
		                }
		            case UPDPLU:
		                if (ApplVar.PluNumber)
		                {
			                ApplVar.PluNumber--;
			                WritePlu();
		                }
                        SETBIT(ApplVar.MyFlags,CONFIGECR);
		            default:
		                break;
		            }
	            }
	            if (type != UPDPLU)
	            {
		            *((WORD *)PCBuffer) = 0;  /* id means end */
		            SendRecord(PCBuffer, 2);   /* send end record */
	            }
	            break;
	        } else if (type > PBTOT)
            {
                if (PCBuffer[0] == 'U')   /* update */
                {
	                PbTotal(type - PBTOT, 0);
	                if (!(PBINFO & 0x04) && !(PBPRINT & 0x80))       /* open numbers ? */
	                    memcpy(ApplVar.PB.Random, &PCBuffer[3], 7);
	                memcpy(ApplVar.PB.Text, &PCBuffer[10], sizeof(ApplVar.PB.Text));
	                PbTotal(type - PBTOT, 3);
	                break;
                }
                id = PBTOT + 1;
			    if ((ApplVar.AP.Pb.Random & 0x0f) || ApplVar.AP.Pb.Text)
	                sMax = ApplVar.AP.Pb.NumberOfPb;
			    else
				    sMax = 0;                /* Not active */
                size = sizeof(ApplVar.PB.Random) + sizeof(ApplVar.PB.Text);
	            record = (char *)ApplVar.PB.Random;
            } else if (type > BLOCKIC)    /* Chipcard for block ? ccr chipcard */
           	{
                if (PCBuffer[0] == 'U')   /* update */
                {
                    ApplVar.ICBlockNumber = type - BLOCKIC - 1;
                    if (ApplVar.ICBlockNumber < ApplVar.AP.ICBlock.Number)
                   	{
                    	memcpy(&ApplVar.ICBlock, &PCBuffer[3], sizeof(ApplVar.ICBlock));
                    	WriteICBlock();
                	}
                    break;
                }
                id = BLOCKIC + 1;
                sMax = ApplVar.AP.ICBlock.Number;
                size = sizeof(ApplVar.ICBlock);
                record = (char *)&ApplVar.ICBlock;

            } else if (type > PLU1)    /* plu ? */
            {
                if (PCBuffer[0] == 'U')   /* update */
                {
                    ApplVar.PluNumber = type - PLU1 - 1;
                    if (ApplVar.PluNumber < ApplVar.AP.Plu.Number)
                    {
                        memcpy(&ApplVar.Plu, &PCBuffer[3], sizeof(ApplVar.Plu));
                        WritePlu();
                        if (ApplVar.AP.Plu.RandomSize &&    /* set PLU's used */
	                        (ApplVar.PluNumber >= ApplVar.AP.Plu.RNumber))
                        {
	                        ApplVar.AP.Plu.RNumber = (ApplVar.PluNumber + 1);
                        }
                        SETBIT(ApplVar.MyFlags,CONFIGECR);//ccr2016-01-15
                    }
                    break;
                }
                id = PLU1 + 1;
                if (ApplVar.AP.Plu.RandomSize)    /* set PLU's used */
	                sMax = ApplVar.AP.Plu.RNumber;
                else
	                sMax = ApplVar.AP.Plu.Number;
                size = sizeof(ApplVar.Plu);
                record = (char *)&ApplVar.Plu;
            } else if (type > DEPT)   /* dept */
            {
                if (PCBuffer[0] == 'U')   /* update */
                {
                    ApplVar.DeptNumber = type - DEPT - 1;
                    memcpy(&ApplVar.Dept, &PCBuffer[3], sizeof(ApplVar.Dept));
                    WriteDept();
                    break;
                }
                id = DEPT + 1;
                sMax = ApplVar.AP.Dept.Number;
                size = sizeof(ApplVar.Dept);
                record = (char *)&ApplVar.Dept;
            } else if (type > GROUP)   /* group */
            {
                if (PCBuffer[0] == 'U')   /* update */
                {
                    ApplVar.GroupNumber = type - GROUP - 1;
                    memcpy(&ApplVar.Group, &PCBuffer[3], sizeof(ApplVar.Group));
                    WriteGroup();
                    break;
                }
			    id = GROUP + 1;
			    sMax = ApplVar.AP.Group.Number;
			    size = sizeof(ApplVar.Group);
				record = (char *)&ApplVar.Group;
			} else if (type > OFFER)   /* OFFER */
			{
			    if (PCBuffer[0] == 'U')   /* update */
			    {
					ApplVar.OFFNumber = type - OFFER -1;
					memcpy(&ApplVar.OFFPrice, &PCBuffer[3], sizeof(ApplVar.OFFPrice));
					WriteOFFPrice();
					break;
			    }
			    id = OFFER+1;
			    sMax = ApplVar.AP.OFFPrice.Number;
			    size = sizeof(ApplVar.OFFPrice);
				record = (char *)&ApplVar.OFFPrice;
			} else if (type > CLERK)   /* clerk */
			{
			    if (PCBuffer[0] == 'U')   /* update */
			    {
					ApplVar.ClerkNumber = type - CLERK;
					memcpy(&ApplVar.Clerk, &PCBuffer[3], sizeof(ApplVar.Clerk));
					WriteClerk();
					break;
			    }
			    id = CLERK;
			    sMax = ApplVar.AP.Clerk.Number + 1;
			    size = sizeof(ApplVar.Clerk);
				record = (char *)&ApplVar.Clerk;
			} else if (type > TAX)    /* modifier */
			{
			    if (PCBuffer[0] == 'U')   /* update */
			    {
#if (!defined(FISCAL))//ccr070612
					ApplVar.TaxNumber = type - TAX - 1;
					memcpy(&ApplVar.Tax, &PCBuffer[3], sizeof(ApplVar.Tax));
					WriteTax();
#endif
					break;
			    }
			    id = TAX + 1;
			    sMax = ApplVar.AP.Tax.Number;
			    size = sizeof(ApplVar.Tax);
				record = (char *)&ApplVar.Tax;
			}else if (type > SALPER)    /* sales person */
			{
			    if (PCBuffer[0] == 'U')   /* update */
			    {
					ApplVar.SalPerNumber = type - SALPER;
					memcpy(&ApplVar.SalPer, &PCBuffer[3], sizeof(ApplVar.SalPer));
					WriteSalPer();
					break;
			    }
			    id = SALPER;
			    sMax = ApplVar.AP.SalPer.Number+1;
			    size = sizeof(ApplVar.SalPer);
				record = (char *)&ApplVar.SalPer;
			}else if (type > MODI)    /* modifier */
			{
			    if (PCBuffer[0] == 'U')   /* update */
			    {
				ApplVar.ModiNumber = type - MODI - 1;
				memcpy(&ApplVar.Modi, &PCBuffer[3], sizeof(ApplVar.Modi));
				WriteModi();
				break;
			    }
			    id = MODI + 1;
			    sMax = ApplVar.AP.Modi.Number;
			    size = sizeof(ApplVar.Modi);
				record = (char *)&ApplVar.Modi;
			}else
			{
			    id = (type / 100) * 100 + 1;
			    if (type > TEND)
			    {
					if (PCBuffer[0] == 'U')   /* update */
					{
					    ApplVar.TendNumber = type - TEND - 1;
					    memcpy(&ApplVar.Tend, &PCBuffer[3], sizeof(ApplVar.Tend));
					    WriteTender();
					    break;
					}
					sMax = ApplVar.AP.Tend.Number;
					size = sizeof(ApplVar.Tend);
					record = (char *)&ApplVar.Tend;
			    }else if (type > PORA)
			    {
					if (PCBuffer[0] == 'U')   /* update */
					{
					    ApplVar.PoRaNumber = type - PORA - 1;
					    memcpy(&ApplVar.PoRa, &PCBuffer[3], sizeof(ApplVar.PoRa));
					    WritePoRa();
					    break;
					}
					sMax = ApplVar.AP.PoRa.Number;
					size = sizeof(ApplVar.PoRa);
					record = (char *)&ApplVar.PoRa;
			    }else if (type > PBF)
			    {
					if (PCBuffer[0] == 'U')   /* update */
					{
					    ApplVar.PbFNumber = type - PBF - 1;
					    memcpy(&ApplVar.PbF, &PCBuffer[3], sizeof(ApplVar.PbF));
					    WritePbF();
					    break;
					}
					sMax = ApplVar.AP.Pb.Number;
					size = sizeof(ApplVar.PbF);
					record = (char *)&ApplVar.PbF;
			    } else if (type > DRAW)
			    {
					if (PCBuffer[0] == 'U')   /* update */
					{
					    ApplVar.DrawNumber = type - DRAW - 1;
					    memcpy(&ApplVar.Draw, &PCBuffer[3], sizeof(ApplVar.Draw));
					    WriteDrawer();
					    break;
					}
					sMax = ApplVar.AP.Draw.Number;
					size = sizeof(ApplVar.Draw);
					record = (char *)&ApplVar.Draw;
			    }else if (type > DISC)
			    {
					if (PCBuffer[0] == 'U')   /* update */
					{
					    ApplVar.DiscNumber = type - DISC - 1;
					    memcpy(&ApplVar.Disc, &PCBuffer[3], sizeof(ApplVar.Disc));
					    WriteDisc();
					    break;
					}
					sMax = ApplVar.AP.Disc.Number;
					size = sizeof(ApplVar.Disc);
					record = (char *)&ApplVar.Disc;
			    }else if (type > CURR)
			    {
					if (PCBuffer[0] == 'U')   /* update */
					{
					    ApplVar.CurrNumber = type - CURR - 1;
					    memcpy(&ApplVar.Curr, &PCBuffer[3], sizeof(ApplVar.Curr));
					    WriteCurr();
					    break;
					}
					sMax = ApplVar.AP.Curr.Number;
					size = sizeof(ApplVar.Curr);
					record = (char *)&ApplVar.Curr;
			    } else if (type > CORREC)
			    {
					if (PCBuffer[0] == 'U')   /* update */
					{
					    ApplVar.CorrecNumber = type - CORREC - 1;
					    memcpy(&ApplVar.Correc, &PCBuffer[3], sizeof(ApplVar.Correc));
					    WriteCorrec();
					    break;
					}
					sMax = ApplVar.AP.Correc.Number;
					size = sizeof(ApplVar.Correc);
					record = (char *)&ApplVar.Correc;
			    }
			    else
					break;
			}
			start = type - id;
			end = *((WORD *)(PCBuffer + 3)) - id + 1;
			if (end > sMax)
			    end = sMax;
			MemSet(record, size, 0);    /* clear memory */
			while(start < end)
			{
				memset(SysBuf,' ',DISLEN);
			    if (type > PBTOT)
			    {
			    	CopyFrStr(SysBuf,Prompt.TypeCap[SETPBINF-1]);
					PbTotal(start + 1, 0);  /* read */
			    }else if (type > BLOCKIC)//ccr chipcard
			    {
			    	CopyFrStr(SysBuf,Prompt.TypeCap[SETBLOCKIC-1]);
					ApplVar.ICBlockNumber = start;
					ReadICBlock();
			    }else if (type > PLU1)
			    {
			    	CopyFrStr(SysBuf,Prompt.TypeCap[SETPLU-1]);
					ApplVar.PluNumber = start;
					ReadPlu();
			    }else if (type > DEPT)
			    {
			    	CopyFrStr(SysBuf,Prompt.TypeCap[SETDEPT-1]);
					ApplVar.DeptNumber = start;
					ReadDept();
			    }else if (type > GROUP)
			    {
			    	CopyFrStr(SysBuf,Prompt.TypeCap[SETGROUP-1]);
					ApplVar.GroupNumber = start;
					ReadGroup();
			    } else if (type > OFFER)
			    {
			    	CopyFrStr(SysBuf,Prompt.TypeCap[SETOFF-1]);
					ApplVar.OFFNumber = start;
					ReadOFFPrice();
			    } else if (type > CLERK)
			    {
			    	CopyFrStr(SysBuf,Prompt.TypeCap[SETCLERK-1]);
					ApplVar.ClerkNumber = start;
					ReadClerk();
			    } else if (type > TAX)    /* tax */
			    {
			    	CopyFrStr(SysBuf,Prompt.TypeCap[SETTAX-1]);
					ApplVar.TaxNumber = start;
					ReadTax();
			    }
			    else if (type > SALPER)    /* salesperson */
			    {
			    	CopyFrStr(SysBuf,Prompt.TypeCap[SETSALER-1]);
					ApplVar.SalPerNumber = start;
					ReadSalPer();
			    } else if (type > MODI)    /* modifier */
			    {
			    	CopyFrStr(SysBuf,Prompt.TypeCap[SETMODIF-1]);
					ApplVar.ModiNumber = start;
					ReadModi();
			    } else if (type > TEND)    /* tender */
			    {
			    	CopyFrStr(SysBuf,Prompt.TypeCap[SETTEND-1]);
					ApplVar.TendNumber = start;
					ReadTender();
			    } else if (type > PORA)    /* pora */
			    {
			    	CopyFrStr(SysBuf,Prompt.TypeCap[SETPORA-1]);
					ApplVar.PoRaNumber = start;
					ReadPoRa();
			    } else if (type > PBF)    /* pb */
			    {
			    	CopyFrStr(SysBuf,Prompt.TypeCap[SETPBF-1]);
					ApplVar.PbFNumber = start;
					ReadPbF();
			    } else if (type > DRAW)    /* drawer */
			    {
			    	CopyFrStr(SysBuf,Prompt.TypeCap[SETDRAWER-1]);
					ApplVar.DrawNumber = start;
					ReadDrawer();
			    } else if (type > DISC)    /* discount */
			    {
			    	CopyFrStr(SysBuf,Prompt.TypeCap[SETDISC-1]);
					ApplVar.DiscNumber = start;
					ReadDisc();
			    } else if (type > CURR)    /* currency */
			    {
			    	CopyFrStr(SysBuf,Prompt.TypeCap[SETCURR-1]);
					ApplVar.CurrNumber = start;
					ReadCurr();
			    } else                  /* correction */
			    {
			    	CopyFrStr(SysBuf,Prompt.TypeCap[SETCORR-1]);
					ApplVar.CorrecNumber = start;
					ReadCorrec();
			    }
				WORDtoASC(SysBuf+DISLEN-1,start+1);
				PutsO(SysBuf);

			    *((WORD *)PCBuffer) = start + id;  /* id */
			    memcpy(PCBuffer + 2, record, size);
			    if (!SendRecord(PCBuffer, size + 2))   /* send record */
			    {
                    PutsO("Error on send!");
			    	break;
			    }
			    start++;
			}
	    }
	    *((WORD *)PCBuffer) = 0;  /* id means end */
	    SendRecord(PCBuffer, 2);   /* send end record */
	    break;

#if (CC_DEBUG==1)
    case 'p'://��ӡһ���ַ� //ccr2016-07-08
        RJPrint(0,PCBuffer+1);
        break;
    case 'w'://д˰�ش洢����SD������[��ַ][�ֽ���][����]
        ExchageXY(PCBuffer+1,PCBuffer+4);ExchageXY(PCBuffer+2,PCBuffer+3);
        ExchageXY(PCBuffer+5,PCBuffer+8);ExchageXY(PCBuffer+6,PCBuffer+7);
        record = (char*)(CLONG(PCBuffer[1]));//address
        sAddr = CLONG(PCBuffer[5]);//bytes
        if (sAddr > 128 ) sAddr=128;
        if (record>=(char *)0x08000000L && record<(char *)(FISMEMERYSIZE+0x08000000L))
        {//��ȡ˰�ش洢������
            record -= 0x08000000L;
            if (!Bios_FM_Write((UnLong)record,  PCBuffer+9, sAddr))
                PutsO("Write FM ERROR!");
            else
            {
                Bios_FM_Read(EntryBuffer,(UnLong)record, sAddr);
                if (memcmp(EntryBuffer,PCBuffer+9,sAddr)==0)
                    PutsO("Write FM OK!");
                else
                    PutsO("FM Data ERROR!");
            }
        }
        else if (record>=(char *)(0x09000000L) && record<(char *)(ApplVar.MMCSIZEMAX+0x09000000L))
        {//��ȡMMC���е�����
            record -= (0x09000000L);
            RamOffSet = (UnLong)record;
            if (!WriteStream( PCBuffer+9, sAddr,false))
                PutsO("Write SD ERROR!");
            else
                PutsO("Write SD OK!");
        }
        break;
	case 'M'://[��ַ][�ֽ���] ����ֽڶ�ȡ����
            ExchageXY(PCBuffer+1,PCBuffer+4);ExchageXY(PCBuffer+2,PCBuffer+3);
            ExchageXY(PCBuffer+5,PCBuffer+8);ExchageXY(PCBuffer+6,PCBuffer+7);

			record = (char*)(CLONG(PCBuffer[1]));//address
			sAddr = CLONG(PCBuffer[5]);//Bytes
            if (record>=(char *)0x08000000L && record<(char *)(FISMEMERYSIZE+0x08000000L))
			{//��ȡ˰�ش洢������
                //PutsO(MessageE42);
				record -= 0x08000000L;
				while (sAddr)
				{
					if (!Bios_FM_Read(PCBuffer,(UnLong)record, 1))
						break;
                    SendString(PCBuffer,1);
					sAddr--;
					record++;
                    //DisplayHex((char *)&sAddr, sizeof(sAddr));
				}
                //PutsO(MessageE43);
			}
            else
                PutsO("Address out!");
			break;
	case 'm'://[��ַ][�ֽ���]
			PutsO(MessageE42);
            ExchageXY(PCBuffer+1,PCBuffer+4);ExchageXY(PCBuffer+2,PCBuffer+3);
            ExchageXY(PCBuffer+5,PCBuffer+8);ExchageXY(PCBuffer+6,PCBuffer+7);
			record = (char*)(CLONG(PCBuffer[1]));//address
			sAddr = CLONG(PCBuffer[5]);//Bytes
			sAddr = (sAddr & 0x0ffffff0) + (((sAddr & 0x0f)>0)?0x10:0x00);
			sAddr >>= 4;
            //ÿ��ֻ��ȡ16�ֽ�
			if (record>=(char*)SRAM_BASE && record<(char *)(SRAM_BASE+0x20000))
			{
				while (sAddr)
				{
					memcpy(PCBuffer,record,16);
					SendString(PCBuffer,16);
					sAddr--;
					record += 16;
                    //DisplayHex((char *)&sAddr, sizeof(sAddr));
				}
			}
			else if (record>=(char *)ADDR_APPRAM && record<(char *)ADDR_APPRAM+ApplVar.SIZE_EXTRAM)
			{
				while (sAddr)
				{
                    RamOffSet =(ULONG)record-ADDR_APPRAM;
                    ReadRam(PCBuffer,16);
					SendString(PCBuffer,16);
					sAddr--;
					record += 16;
                    //DisplayHex((char *)&sAddr, sizeof(sAddr));
				}
			}
			else if (record>=(char *)0x08000000L && record<(char *)(FISMEMERYSIZE+0x08000000L))
			{//��ȡ˰�ش洢������
				record -= 0x08000000L;
				while (sAddr)
				{
					if (!Bios_FM_Read(PCBuffer,(UnLong)record, 16))
						break;
                    SendString(PCBuffer,16);
					sAddr--;
					record += 16;
                    //DisplayHex((char *)&sAddr, sizeof(sAddr));
				}
			}
			else if (record>=(char *)(0x09000000L) && record<(char *)(ApplVar.MMCSIZEMAX+0x09000000L))
			{//��ȡMMC���е�����
				record -= (0x09000000L);
				while (sAddr)
				{
					if (!ReadFromMMC(PCBuffer,(UnLong)record, 16))
						break;
                    SendString(PCBuffer,16);
					sAddr--;
					record += 16;
                    //DisplayHex((char *)&sAddr, sizeof(sAddr));
				}
			}
			//ccr2016-07-06PCBuffer[0] = 0x00;
			//ccr2016-07-06SendRecord(PCBuffer,3);
   		    PutsO(MessageE43);
			break;
	case 'C':
	case 'I':           /* init */
	    if (type == 0x544e) /* command "INT" */
	    {
		    ClearApplMemory();
			InitApplication();
		}
	    else if (type == 0x524c) /* command "CLR" */
		    {
				id = ApplVar.CentralLock;
				start = ApplVar.ClerkNumber;
				end = ApplVar.ClerkLock;
				sMax = ApplVar.SalPerNumber;
//				ClearApplMemory();
				ClearAllReport();
				ApplVar.CentralLock = id;
				ApplVar.ClerkNumber = start;
				ApplVar.ClerkLock = end;
				ApplVar.SalPerNumber = sMax;
		    }
//		else
//			break;
	    *((WORD *)PCBuffer) = 0;  /* id means end */
	    SendRecord(PCBuffer, 2);   /* send end record */
	    ARROWS = 0x01;
		break;
#endif
	case 'R':           /* command for getting user report */
	case 'S':           /* command for getting system report */
    	ApplVar.RepComputer = 0;
    	ApplVar.FReport = 0;
	    MemSet(SysBuf + 7, 24, ' ');
	    *((WORD *)(SysBuf)) = 1;        /* indicate counters */
	    SysBuf[2] = 1;      /* indicate text */
	    SysBuf[3] = 0;
	    SysBuf[4] = 0;
	    *((WORD *)(SysBuf + 5)) = 0;
	    GetReceiptNumber(SysBuf + 7);
	    SysBuf[15] = 'L';      /* location number */
	    SysBuf[16] = LOCATION;
	    SysBuf[19] = 'R';      /* register number */
	    SysBuf[20] = REGISTER;
	    SysBuf[24] = 'Z';
	    WORDtoASC(SysBuf + 25, ApplVar.ZCount[REPZNUM]);
	    SendRecord(SysBuf, 31);      /* send counter record */
	    SysBuf[0] = 2;              /* indicate time & date */
		memcpy(SysBuf + 7, DateAsci, 15);
	    SysBuf[22] = ' ';
	    memcpy(SysBuf + 23, TimeAsci, 8);
	    SendRecord(SysBuf, 31);      /* send time-date record */

		SysBuf[0] = PCBuffer[0];
		SysBuf[1] = PCBuffer[1];
	    if (ApplVar.FRegi)
			ApplVar.ErrorNumber=ERROR_ID(CWXXI14);
	    else if (!ApplVar.ErrorNumber)
    	{
			ApplVar.RepComputer = PCBuffer[1];        /* X or Z (only Z is checked) */
			if (ApplVar.RepComputer == 'Z' || ApplVar.RepComputer == 'C')
			    ApplVar.FReport = Z;
			else
			    ApplVar.FReport = X;
			if (PCBuffer[0] == 'R')       /* user report ? */
			{
			    ApplVar.ReportNumber = PCBuffer[2];
			    GetReport(ApplVar.ReportNumber);
			}
			else
			{
			    Appl_EntryCounter = 4;
			    memcpy(EntryBuffer + sizeof(EntryBuffer) - 5,PCBuffer + 2, 4);
			    GetSystemReport(0);
				ClearEntry();
			}
    	}

    	ApplVar.RepComputer = 0;
    	ApplVar.FReport = 0;
	    *((WORD *)(PCBuffer)) = 0;        /* indicate end */
	    PCBuffer[2] = 1;      /* indicate text */
	    PCBuffer[3] = 0;
	    PCBuffer[4] = 0;
	    *((WORD *)(PCBuffer + 5)) = 0;
	    if (ApplVar.ErrorNumber)        /* error occurred */
	    {
			*((WORD *)(PCBuffer + 5)) = ApplVar.ErrorNumber;
			strcpy(PCBuffer + 7, Prompt.Message[ApplVar.ErrorNumber - 1]);
			SendRecord(PCBuffer, 7 + sizeof(Prompt.Message[0]));
			ApplVar.ErrorNumber=0;
	    }
	    else
			SendRecord(PCBuffer, 7);
    	break;
////////////////////////pxxxb080812for Extract EJ and FM data
#if(defined(FISCAL))	//cc 20071026
	case 'E':
			sMax = 0;
			if (PCBuffer[1]=='J')
			{// �޸�ʽ����ָ����ַ�ϵ�EJ���� //
#if (DD_MMC)
				sAddr =  StrToLong(PCBuffer+2, 8);//CLONG(PCBuffer[2]);
				if (sAddr<ApplVar.EJLogHeader.NextNP)//ccr091021 ApplVar.MMCSIZEMAX)
				{
					if ((ApplVar.MMCSIZEMAX-sAddr)>sizeof(PCBuffer))
						sMax = sizeof(PCBuffer);
					else
						sMax = (ApplVar.MMCSIZEMAX-sAddr);
					memset(PCBuffer, 0, sizeof(PCBuffer));;
					if (sMax && ReadFromMMC(PCBuffer, sAddr,sMax))
					{
						if ((sAddr+sMax)>=ApplVar.EJLogHeader.NextNP)
						{//ccr091021
							id = ApplVar.EJLogHeader.NextNP - sAddr;
							CWORD(PCBuffer[id])=0xffff;
						}
					    SendRecord(PCBuffer, sMax);   /* send datas */
					}
					else
						sMax =0;
				}
#endif
			}
			else if (PCBuffer[1]=='F')
			{// �޸�ʽ����ָ����ַ�ϵ�FM���� //
				sAddr =  StrToLong(PCBuffer+2, 8);//CLONG(PCBuffer[2]);
				if (sAddr<FISMEMERYSIZE)
				{
					if ((FISMEMERYSIZE-sAddr)>sizeof(PCBuffer))
						sMax = sizeof(PCBuffer);
					else
						sMax = (FISMEMERYSIZE-sAddr);

					memset(PCBuffer, 0, sizeof(PCBuffer));;
					if (sMax && Read_FiscalRam(PCBuffer,sAddr, sMax))
					    SendRecord(PCBuffer, sMax);   /* send datas */
					else
						sMax =0;
				}

			}
			else if (PCBuffer[1]=='T')
			{// ����EJ��С //
				*((long *)PCBuffer) = ApplVar.MMCSIZEMAX;
				SendRecord(PCBuffer,sizeof(long));
				break;
			}

			if (sMax==0)
			{
				CWORD(PCBuffer[0]) = 0;
				SendRecord(PCBuffer,2);
			}
//			else
//				DisplayHex((char*)&sAddr,4);
			break;
#endif
////////////////////////pxxxb080812for Extract EJ and FM data
#if(CASE_RAMBILL)
	case 'F':// ����������ˮ���� //
#if(defined(FISCAL))	//    cc 20071026
		if(ApplVar.FTrain)
			return;
#endif

		if(type!=0)
			return;
		*(PCBuffer+1) = ECRNOLOG;
		*(PCBuffer+2) = REGISTER;
        *(PCBuffer+3) = LOCATION;
		SendRecord(PCBuffer, 4);
		for(;;)
		{
			//cc 2006-04-17>>>>>>>>>>>>>>>>>>>>>
			if(ApplVar.FRegi)
			{
				*(WORD *)PCBuffer = 0;
				SendRecord(PCBuffer,2);
				return;
			}
			else
			{
				size = Read_Flow(PCBuffer+1);	   //    lyq2003
				if((!size) ||(size==(-1)))
				{
					*(WORD *)PCBuffer = 0;
					SendRecord(PCBuffer, 2);
					if(size==-1)
					{
						CheckError(48);
						PutsO(MessageE44);
					}
					return;
				}
				else
				{
					if(!(SendRecord(PCBuffer, size+1)))
				 	{
				 		SUB_SCANFP(size);
						CheckError(48);
						PutsO(MessageE45);
						break;
				 	}
				}
			}
		}
	    break;

#endif

#if PC_EMUKEY==1

	case 'K'://    comman for emulate keyboard;

		if ((type & 0xff)==ApplVar.AP.FirmKeys[ID_CLEAR])
		{
			ClearEntry();
			ApplVar.ErrorNumber=0;
		}
		if (KeyFrHost!=0xff || (ApplVar.ErrorNumber && (type & 0xff) !=0) && (type & 0xff) !=PRNONOFF)
		{
			PCBuffer[0] = 0x8A;
			PCBuffer[1] = ApplVar.ErrorNumber & 0x7f;
			SendRecord(PCBuffer, 2);
			return;
		}
		else
		{
			if ((type & 0xff)==PRNONOFF)
			{
/*ccr091027>>>>>
				if (TESTBIT(ApplVar.MyFlags, PRNONPB+ENPRINTER))
					RESETBIT(ApplVar.MyFlags, PRNONPB+ENPRINTER);
				else
					SETBIT(ApplVar.MyFlags, PRNONPB+ENPRINTER);
<<<<<<<<<<<*/
				FisTestTask.PrnOFF ^= 1;
			}
			else
				KeyFrHost = type & 0xff;

			PCBuffer[0] = 0x85;

			PCBuffer[1] = Now.year&0xff;
			PCBuffer[2] = Now.month;
			PCBuffer[3] = Now.day;
			PCBuffer[4] = Now.hour;
			PCBuffer[5] = Now.min;
//ccr091027			PCBuffer[6] = ((ApplVar.MyFlags & (PRNONPB+ENPRINTER))==0);
			PCBuffer[6] = FisTestTask.PrnOFF;
			PCBuffer[7] = ApplVar.CentralLock;
			SendRecord(PCBuffer, 8);
		}

		break;
#endif
	case 'P':
		ApplVar.AP.Plu.RNumber = (CWORD(PCBuffer[1]));
		break;
#if defined(FISCAL)	//ccr030722>>>>
	case FISCOMM://������ȡ˰����������
		ProcessFiscalCmd();
		return;
#endif		//<<<<<<<<<<<<<<
    default :
        CWORD(PCBuffer[0]) = 0;
        SendRecord(PCBuffer,2);
	    break;
    }
#if DD_FISPRINTER
	if(PCBuffer[0] == STX)
		return;
#endif
    if (type > PLU1  && type<AGREE || (type >= UPDPLU && type <= REPPLU))
    {
		ApplVar.RepeatCount = 0 ;
		ApplVar.PluNumber = save;
		ReadPlu();
    } else if (type > DEPT  && type<PLU1)
    {
		ApplVar.DeptNumber = save;
		ReadDept();
    } else if (type > CLERK && type<OFFER)
    {
		ApplVar.ClerkNumber = save;

		if(save)
		{
			ReadClerk();
		}

    } else if (type > SALPER  && type<TAX)
    {
		ApplVar.SalPerNumber = save;
		ReadSalPer();
    }
    SetTrainMode();
}
//read a package from host,return the length of data in package
//return 0 if error
short  ReadRecord()
{
    BYTE length, bcc;
    short i;

	for (i=10;(i && (ReadComm(COMPUTER_1) != SOH));i--);
	if (!i)
	{
    	SendComm(COMPUTER_1,NAK);
        return 0;
	}
	EmptyComm(COMPUTER_1);
	SendComm(COMPUTER_1,ACK);

	for (bcc=10;(bcc && (i = ReadComm(COMPUTER_1)) == -1);bcc--);
	if (!bcc)
	{
    	SendComm(COMPUTER_1,NAK);
        return 0;
	}
    length = i;

    if (length > PCBUFMAX-2)
    {
    	SendComm(COMPUTER_1,NAK);
        return 0;
    }
    bcc = length;
    i = 0;
    for (i=0;i < length+1;i++)
    {
	    PCBuffer[i] = ReadComm(COMPUTER_1);
        bcc += PCBuffer[i];
    }
    if (bcc)//the verify error
    {
    	SendComm(COMPUTER_1,NAK);
        return 0;
    }
    else
    {
		SendComm(COMPUTER_1,ACK);
		return length;
	}
}


//communicat with Host computer throw Rs232 port
// 0 1 2 3 4 5 6
//:02000002F0000C
// |||  ||||  |\/______Check value
// |||  |||\__/________Datas (2 bytes)
// |||  |\/____________Flag, 00h=Data;01h=End of a segment;02h=New segment address;
// ||\__/______________Offset address in Segment
// \/__________________Length of Datas (02h=2 bytes
// 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0
//:10000000434C454152000000000000000000000089
//:100010004E554D31000000000000000000000000BF
//:04101000B3A32E0058
//:00000001FF		;End of the file


#define	DBUFFSIZE	1024	//������128�������� //
#define SECTOR_SIZE 128	//AT29LV020=256  W29C020=128  //

// download cclib or binary data from host. format of file is binary.
void DowmLoadBINCLIB()
{
}




