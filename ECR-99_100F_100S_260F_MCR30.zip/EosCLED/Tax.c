#define TAX_C 5
#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
//type=0:Total sales rounding;
//type=1:Rounding on MULT, TAX & Percentage discount

void AmtRound(BYTE type ,BCD *amt)
{
    BYTE b, sign;

    if ((!type && BIT(ROUNDMASK, BIT0+BIT1+BIT2+BIT3)) ||
        (type && BIT(ROUNDMASK, BIT4+BIT5+BIT6+BIT7)))   /* Detail rounding?*/
    {

        sign = amt->Sign;   /* save sign */
        amt->Sign = 0;
        b = ROUNDMASK & 0x0f;
        if (!b)
            b = (ROUNDMASK>>4) & 0x0f;
        switch (b)
        {
        case 1:
            if ((amt->Value[0] & 0x0f)>=0x05)
                Add(amt,&TEN);
            amt->Value[0] &= 0xf0;
            break;
        case 2:
            b = amt->Value[0];
            amt->Value[0] = 0;      /* 00 - 24 -->0 */
            if (b > 0x74)           /* 75 - 99  --> 100 */
                Add(amt, &HUNDRED);
            else if (b > 0x24)      /* 25 - 74 --> 50 */
                amt->Value[0] = 0x50;
            break;
        case 3:
            b = amt->Value[0] & 0xf0;
            amt->Value[0] = 0;      /* 00 - 49 -->0 */
            if (b >= 0x50)
                Add(amt, &HUNDRED);/* 50 - 99  --> 100 */
            break;
        case 4:
            b = amt->Value[0] & 0xf0;
            amt->Value[0] = 0;      /* 00 - 09 -->0 */
            if (b > 0x00)
                Add(amt, &HUNDRED);/* 10 - 99  --> 100 */
            break;
        }
        amt->Sign = sign;       /* restore sign */
    }
}

void RoundTaxable(BCD *amt)
{
    RoundBcd(amt, 0);
    AmtRound(1, amt);
}

void GetTaxOffSet()
{
    RamOffSet = ApplVar.TaxNumber * ApplVar.AP.Tax.RecordSize + ApplVar.AP.StartAddress[AddrTax];
}

void AddTaxTotal()
{
    GetTaxOffSet();
    RamOffSet += ApplVar.AP.Tax.TotalOffSet;
    for (ApplVar.PointerType = 0; ApplVar.PointerType < REPDEFMAX; ApplVar.PointerType++)
    {
        ApplVar.Size = ApplVar.AP.Tax.Size[ApplVar.PointerType];
        AddPointerTotal();
    }
}

void WriteTax()
{
    if (ApplVar.TaxNumber < ApplVar.AP.Tax.Number)
    {
        GetTaxOffSet();
        ApplVar.Tax.Rate[2] = 0;//ccr070614

        WriteRam(ApplVar.Tax.Name, ApplVar.AP.Tax.CapSize);
        WriteRam((BYTE *)ApplVar.Tax.Rate, sizeof(ApplVar.Tax.Rate));
        WriteRam(&ApplVar.Tax.Options, sizeof(ApplVar.Tax.Options));
    }
}
//Read ApplVar.Tax from area of TAX_C
void ReadTax()
{
    memset(&ApplVar.Tax,0,sizeof(ApplVar.Tax));
    if (ApplVar.TaxNumber < ApplVar.AP.Tax.Number)
    {
        GetTaxOffSet();

        ReadRam(ApplVar.Tax.Name, ApplVar.AP.Tax.CapSize);
        ReadRam(ApplVar.Tax.Rate, sizeof(ApplVar.Tax.Rate));
        ReadRam(&ApplVar.Tax.Options, sizeof(ApplVar.Tax.Options));
        ApplVar.Tax.Rate[2] = 0;//ccr070614
    }
}


//ccr091223>>>>>>>>>>>>>>>>
void CalculateRefundTax(BYTE tax,BCD *taxAmt, BYTE pbRefund)
{
    if (CheckNotZero(taxAmt))
    {
        if (pbRefund)
            Add(&ApplVar.FpbRetAmt, taxAmt);
        else
            Add(&ApplVar.FRetAmt, taxAmt);
        for (ApplVar.TaxNumber = 0; ApplVar.TaxNumber < ApplVar.AP.Tax.Number && tax; ApplVar.TaxNumber++,tax>>=1)
        {
            if (tax & 1)
            {
                ReadTax();
                ApplVar.Cost = ZERO;        /* clear calculated tax */
                ApplVar.Qty = ZERO;
                memcpy(ApplVar.Qty.Value, ApplVar.Tax.Rate, sizeof(ApplVar.Tax.Rate));
                if (!BIT(ApplVar.Tax.Options, BIT0)) /* add on ? */
                {
                    ApplVar.Cost = *taxAmt;
                    ApplVar.Qty.Sign = 0x04;
                    Multiply(&ApplVar.Cost, &ApplVar.Qty);
                    RoundBcd(&ApplVar.Cost, 0);
                    AmtRound(1, &ApplVar.Cost);
                }
                else
                {
                    ApplVar.Cost = *taxAmt; /* contains TAX */
                    ApplVar.DiscAmt = ApplVar.Cost; /* contains NET */
                    Add(&ApplVar.Qty, &THOUSAND10);
                    ApplVar.Qty.Sign = 0x04;
                    Divide(&ApplVar.DiscAmt, &ApplVar.Qty); /* calculate net */
                    RoundTaxable(&ApplVar.DiscAmt);
                    Subtract(&ApplVar.Cost, &ApplVar.DiscAmt);  /* taxable - net */
                }//if
                if (pbRefund)
                    Add(&ApplVar.FpbRetTax,  &ApplVar.Cost);
                else
                    Add(&ApplVar.FRetTax, &ApplVar.Cost);
            }
        }
    }
}
//<<<<<<<<<<<<<<<<<<<<<<<<


void AddTaxItem(BYTE tax,BYTE option)//ccr090108
{
    BYTE t, i;

#if	(pbAmtDisc)//ccr091210>>>>>>>>>>>>>>>>>>
    BCD sAmt=ApplVar.Amt;

    if (ApplVar.PBA.Disc.Sign!= 0xff)//ccr091210
    {
        Add(&sAmt,&ApplVar.PBA.Disc);
        if (BIT(sAmt.Sign,BIT7))// Ϊ�˻���
            CalculateRefundTax(tax, &sAmt,1);//ccr091223
    }
#endif//<<<<<<<<<<<<<<<<<<<


    t = 1;
    tax ^= ApplVar.TaxPerm; /* shift tax 1 & 2 if needed */
    tax ^= ApplVar.TaxTemp;

    for (i = 0; i < ApplVar.AP.Tax.Number; i++)
    {
        if (tax & t)
        {//ccr090108>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#if	(pbAmtDisc)//ccr091210>>>>>>>>>>>>>>>>>>
            Add(&ApplVar.TaxItem[0][i], &sAmt);
            if (BIT(option, BIT6))
                Add(&ApplVar.TaxItem[1][i], &sAmt);
            if (BIT(option, BIT7))
                Add(&ApplVar.TaxItem[2][i], &sAmt);
#else//<<<<<<<<<<<<<<<<<<<<<<<<<<
            Add(&ApplVar.TaxItem[0][i], &ApplVar.Amt);
            if (BIT(option, BIT6))
                Add(&ApplVar.TaxItem[1][i], &ApplVar.Amt);
            if (BIT(option, BIT7))
                Add(&ApplVar.TaxItem[2][i], &ApplVar.Amt);
#endif
        }//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
        t <<= 1;
    }
    Add(&ApplVar.SaleAmt, &ApplVar.Amt);
    Add(&ApplVar.SaleQty, &ApplVar.Qty);
    ApplVar.TaxTemp1 = ApplVar.TaxTemp;     /* save article tax shift */
    ApplVar.TaxTemp = 0;        /* reset article tax shift */
}

/* if type = 0 then add in report and calculate add on tax */
/* if type = 1 then not add in report and calculate add on tax */
/* if type = 2 then calculate and print add on tax not report */
/* if type = 3 then print inclusive tax */
/* if type = 5 then calculate tax ,story in Qty:���ڼ��˰���Ƿ�<0*/
/* GST is a special tax which is always ADD ON and calculated as */
/* a percentage on (SalesAmt + TAX1 + TAX2 ..)	*/
void CalculateTax(BYTE type )
{
    BYTE printsub;
    BYTE calcgst;
    BCD gst,sVal1, tAmt,tTax;
    int i;

    tAmt=ZERO;
    tTax = ZERO;

#if (defined(CASE_GREECE))//ϣ���ڽ��ǰ����ӡŷԪ����
    Prefix1 = 0;
    Prefix2 = 0;
#endif

    printsub = 0;
    calcgst = 0;    /* checkif tax used for GST (tax on total sales amount)*/
    if (!type)
        AmtRound(0, &ApplVar.SaleAmt);  /* sales amount rounding */
//pxxxb080717
    if (type!=5)    // liuj modify 080610 //pxxxb080718 for pay for Amount many times
        ApplVar.SubTotal = ApplVar.SaleAmt;

#if (defined(FISCAL))
    if (ApplVar.AP.Tax.Number)
#else
    if (ApplVar.AP.Tax.Number && !ApplVar.FNoTax)   /* if ApplVar.FNoTax == 1 then no tax */
#endif
    {
        for (;;)
        {
            for (ApplVar.TaxNumber = 0; ApplVar.TaxNumber < ApplVar.AP.Tax.Number; ApplVar.TaxNumber++)
            {
                ReadTax();
                if (BIT(ApplVar.Tax.Options, BIT3))        /* GST tax ? */
                {
                    if (calcgst == 2)
                    {
                        ApplVar.Amt = gst;       /* Taxable is Saleamt + ApplVar.Tax */
                        ApplVar.TaxItem[0][ApplVar.TaxNumber] = ApplVar.Amt;   /* ccr090108 used for external invoice */
                    }
                    else//calcgst==0
                    {
                        calcgst = 1;        /* set GST active �ȴ���ȡ��һ��˰�� */
                        continue;
                    }
                }//if
                else if (calcgst == 2)
                    continue;
                else
                    ApplVar.Amt = ApplVar.TaxItem[0][ApplVar.TaxNumber];//ccr090108
                ApplVar.Cost = ZERO;        /* clear calculated tax:ApplVar.Cost��Ų�ͬ˰�ֵ���˰�� */

                if (CheckNotZero(&ApplVar.Amt))
                {
                    ApplVar.Qty = ZERO;
                    memcpy(ApplVar.Qty.Value, ApplVar.Tax.Rate, sizeof(ApplVar.Tax.Rate));
                    if (!BIT(ApplVar.Tax.Options, BIT0)) /* add on ? */
                    {//add onΪ����˰,��:���ۼ۸񲻰���˰
                        ApplVar.Cost = ApplVar.Amt;
                        ApplVar.Qty.Sign = 0x04;
                        Multiply(&ApplVar.Cost, &ApplVar.Qty);
                        RoundBcd(&ApplVar.Cost, 0);
                        AmtRound(1, &ApplVar.Cost);//ApplVar.Cost������ͬ˰�ֵ���˰��

                        if (type!=5) //pxxxb080718 for pay for Amount many times
                            Add(&ApplVar.SubTotal, &ApplVar.Cost);
                    }
                    else
                    {//VATΪ����˰,��:���ۼ۸����˰
#if (defined(CASE_EURO))
                        if (type == 3|| type == 5||type == 2)
#else
                        if (type == 3|| type == 5)
#endif
                        {
                            ApplVar.Cost = ApplVar.Amt; /* contains TAX ()*/
                            if (ApplVar.Qty.Value[0] == 0x99 &&
                                ApplVar.Qty.Value[1] == 0x99 &&
                                ApplVar.Qty.Value[2] == 0x99)
                                ApplVar.DiscAmt = ZERO;     /* NET is zero */
                            else
                            {
                                ApplVar.DiscAmt = ApplVar.Amt;  /* contains NET */
                                Add(&ApplVar.Qty, &THOUSAND10);
                                ApplVar.Qty.Sign = 0x04;
                                Divide(&ApplVar.DiscAmt, &ApplVar.Qty); /* calculate net */
                                RoundTaxable(&ApplVar.DiscAmt);/* No Tax (NET) */
                                Subtract(&ApplVar.Cost, &ApplVar.DiscAmt);  /* taxable - net */
                                Subtract(&gst, &ApplVar.Cost);  /* calculate net for :ApplVar.Cost������ͬ˰�ֵ���˰�� */
                                /* add on tax for Argentina */
                            }
                            Add(&tAmt,&ApplVar.DiscAmt); /* contains NET */
                        }
                    }
                    Add(&tTax,&ApplVar.Cost); //liuj 0731 total tax

                    if (!type || type == 4)     /* add report */
                        AddTaxTotal();
                }//if
                if (type == 2)
                {
                    if (BIT(ApplVar.Tax.Options, BIT0) && BIT(ApplVar.Tax.Options,BIT1))
                    {                 /* ADD ON and print */
#if (defined(CASE_EURO))
                        if (CheckNotZero(&ApplVar.Cost) || CheckNotZero(&ApplVar.Amt) || BIT(ApplVar.Tax.Options, BIT2))
#else
                        if (CheckNotZero(&ApplVar.Cost) || BIT(ApplVar.Tax.Options, BIT2))
#endif
                        {           /* print also zero */
#if (!defined(CASE_EURO))
                            if (!printsub)
                            {
                                if (calcgst == 2)   /* GST subtotal ?*/
                                    PrintAmt(Prompt.Caption[ItemPrompt1], &gst);
                                else
                                    PrintAmt(Prompt.Caption[ItemPrompt1], &ApplVar.SaleAmt);
                                printsub = 1;
                            }
#endif
//ccr070614>>>>>>>>>
                            if (BIT(ApplVar.Tax.Options, BIT4))    /* print taxable */  //liuj 0613
                            {
#if ((PRINTTENDType == 0)|| defined(CASE_EURO))
                                if (CheckNotZero(&ApplVar.Amt))
                                {
                                    //SALES                      12.54
//                                 PrintAmt(Prompt.Caption[ItemPrompt46], &ApplVar.Amt);
#if (defined(FISCAL))
    /* Print out after tend
    --------------------------------
    SALES                      12.54
    TAXABLE A   7.00%          12.54
    SALES                      32.56
    TAXABLE B  10.00%          32.56
    SALES                      58.74
    TAXABLE C  15.00%          58.74
    SALES                       0.00
    TAXABLE D   0.00%           0.00
    SUM EXC.VAT                92.40
    VAT AMOUNT                 11.44
    */
                                    memset(ProgLineMes, ' ', sizeof(ProgLineMes));
                                    sVal1 = ZERO;
                                    CWORD(sVal1.Value[0]) = CWORD(ApplVar.Tax.Rate[0]);
                                    if (!BIT(ApplVar.Tax.Options, BIT0)) /* add on ? */
                                    {
                                        i = strlen(Msg[XIAOSHOUA].str);//ccr2017-05-17
                                        memcpy(ProgLineMes,Msg[XIAOSHOUA].str,i);//ccr2017-05-17
                                    }
                                    else
                                    {
                                        i = strlen(Prompt.Caption[ItemPrompt26]);//ccr2017-05-17���VAT��˰��ʽ
                                        memcpy(ProgLineMes,Prompt.Caption[ItemPrompt26],i);  //ccr2017-05-17���VAT��˰��ʽ
                                    }

                                    ProgLineMes[i+1] = 'A' + ApplVar.TaxNumber;
//ccr2017-05-16                                    ProgLineMes[i+1] = ApplVar.Tax.Name[0];
//ccr2017-06-08                                    sVal1.Sign = 2;
//ccr2017-06-08                                    FormatQty(ProgLineMes+16,&sVal1);//cr070424
//ccr2017-06-08                                    ProgLineMes[17] = '%';      //ProgLineMes[13] = '%';
                                    ProgLineMes[18] = 0;        //ccr090113
                                    PrintAmt(ProgLineMes,&ApplVar.Amt);
#endif
                                }
#else //PRINTTENDType == 1
/* Print out after tend
--------------------------------
SUBTOTAL F                 12.54
SUBTOTAL R                 25.36
SUBTOTAL E                 25.87
SUM EXC.VAT                57.27
VAT AMOUNT                  6.50
*/

                                //if(ApplVar.TaxNumber<3 ||( CheckNotZero(&Amt) && ApplVar.TaxNumber>2))		//liuj0829
                                if ( CheckNotZero(&ApplVar.Amt) )     // liuj 080430
                                {
                                    memset(ProgLineMes, ' ', sizeof(ProgLineMes));
                                    i= strlen(Prompt.Caption[ItemPrompt1]);
                                    memcpy(ProgLineMes,Prompt.Caption[ItemPrompt1],i);
                                    ProgLineMes[i+1] = ApplVar.Tax.Name[0];
                                    PrintAmt(ProgLineMes,&ApplVar.Amt);
                                }

#endif
                            }
#if (defined(CASE_EURO))
                            memset(ProgLineMes, ' ', sizeof(ProgLineMes));
                            CopyFrStr(ProgLineMes,ApplVar.Tax.Name);
                            sVal1 = ZERO;
                            CWORD(sVal1.Value[0]) = CWORD(ApplVar.Tax.Rate[0]);
                            sVal1.Sign = 2;
                            FormatQty(ProgLineMes+16,&sVal1);//cr070424
                            ProgLineMes[17] = '%';      //ProgLineMes[13] = '%';
                            ProgLineMes[18] = 0;        //ccr090113
                            PrintAmt(ProgLineMes, &ApplVar.Cost);
#endif
//<<<<<<<<<<<<<<<<<<<<<<
                        }

                    }
                }
                else if (type == 3)
                {
                    if (BIT(ApplVar.Tax.Options, BIT0) && BIT(ApplVar.Tax.Options, BIT1))       /* print include tax ? */
                    {
                        if (CheckNotZero(&ApplVar.Amt) || BIT(ApplVar.Tax.Options, BIT2))
                        {
//ccr070614>>>>>>>>>>>
                            memset(ProgLineMes, ' ', sizeof(ProgLineMes));
                            CopyFrStr(ProgLineMes,ApplVar.Tax.Name);

                            sVal1 = ZERO;
                            CWORD(sVal1.Value[0]) = CWORD(ApplVar.Tax.Rate[0]);
                            sVal1.Sign = 2;
                            FormatQty(ProgLineMes+16,&sVal1);//cr070424
                            ProgLineMes[17] = '%';      //ProgLineMes[13] = '%';
                            ProgLineMes[18] = 0;        //ccr090113

                            PrintAmt(ProgLineMes, &ApplVar.Cost);/* print also zero */
//ccr070614						    PrintAmt(ApplVar.Tax.Name, &ApplVar.Cost);
                            if (BIT(ApplVar.Tax.Options, BIT4))     /* print taxable ? */
                            {
                                PrintAmt(Prompt.Caption[ItemPrompt46], &ApplVar.DiscAmt);
#if (defined(FISCAL))
                                memset(ProgLineMes, ' ', sizeof(ProgLineMes));
                                i = strlen(Msg[XIAOSHOUA].str);
                                memcpy(ProgLineMes,Msg[XIAOSHOUA].str,i);
                                ProgLineMes[i+1] = 'A' + ApplVar.TaxNumber;

                                FormatQty(ProgLineMes+16,&sVal1);//cr070424
                                ProgLineMes[17] = '%';      //ProgLineMes[13] = '%';
                                ProgLineMes[18] = 0;        //ccr090113
                                PrintAmt(ProgLineMes,&ApplVar.DiscAmt);
#endif
                            }
//<<<<<<<<<<<<<<<<<<<<
                        }
                    }
                    ApplVar.Cost = ZERO;
                }//ccr2017-12-14>>>>>>>
                else if (type==5 && BIT(ApplVar.Cost.Sign,BIT7))
                {//��ֹ������˰���Ϊ��
                    ApplVar.Qty=ApplVar.Cost;
           			ApplVar.ErrorNumber=ERROR_ID(CWXXI101);
                    PutsO(DispAmtStr(ApplVar.Tax.Name,&ApplVar.Qty,DISLEN));
#if (DISP2LINES==0)
                    WAIT_PRESS();
#endif
                    break;
                }//ccr2017-12-14<<<<<<<<<<<<<<
            }//for
            if (calcgst == 1)       /* gst active ? */
            {
                AmtRound(0, &ApplVar.SubTotal);     /* sales amount rounding */
                gst = ApplVar.SubTotal;
                calcgst = 2;
                printsub = 0;
            }
            else
                break;
        }//for /* also calculate gst */
    }//if
//liuj 0731
    if (type == 5 && ApplVar.ErrorNumber!=ERROR_ID(CWXXI101)) //ccr2017-12-14
    {//����վ���˰���Ƿ�Ϊ��
        if (tTax.Sign & 0x80)
            ApplVar.Qty = tTax;//��˰�ܶ�<0
        else if (tAmt.Sign & 0x80)
            ApplVar.Qty = tAmt;//����˰���<0
        else if (ApplVar.SubTotal.Sign & 0x80)
            ApplVar.Qty = ApplVar.SubTotal;//������<0
        else
            ApplVar.Qty = ZERO;

    }
//liuj 0731

#if (defined(CASE_EURO))
    if (type == 2)
    {
        //RFeed(1);
/*ccr20140725 һ����Ʒ�ж��ּ�˰ʱ����������>>>>>>>>
        if (CheckNotZero(&tAmt)) // ����˰���
            PrintAmt(Msg[SUM_EXC_VAT].str,&tAmt);
<<<<<<<<<<<<*/

        if (CheckNotZero(&tTax)) // ˰��
            PrintAmt(Msg[VAT_AMOUNT].str, &tTax);
        //��ʾ��˰���Ӧ���ܽ��
        PutsO(DispAmtStr(DText[DTEXT_TOTAL], &ApplVar.SubTotal, DISLEN));//ccr20131104
    }
    Prefix1 = PREFIX_1;
    Prefix2 = PREFIX_2;
#endif

//	if (!FPb)
//	    AmtRound(0, &SubTotal);	/* sales amount rounding */
}
/*************************************************************************
 *
 *
 * @author EutronSoftware (2018-03-15)
 *************************************************************************/
void CopyTaxRate()
{
      for (ApplVar.TaxNumber = 0; ApplVar.TaxNumber < ApplVar.AP.Tax.Number; ApplVar.TaxNumber++)
      {
          ReadTax();
          CopyOfTax[ApplVar.TaxNumber]=CWORD(ApplVar.Tax.Rate[0]);
      }
}
