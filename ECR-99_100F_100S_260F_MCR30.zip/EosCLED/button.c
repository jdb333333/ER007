#define BUTTON_C

#include <stdio.h>

#include "king.h"                               /* Kingtron library and I/O routines */

#include "exthead.h"
#include "exth.h"
#include "fiscal.h"
#include "message.h"
#if(DD_FISPRINTER==1)

#define SHORTKEY	1
#if (DEBUGBYPC)
#define LONGKEY	1
#else
#define LONGKEY	2000
#endif

#define NO_KEY 0
#define SELECT_KEY 1
#define ENTER_KEY 2
#define ENTER_E_SELECT_KEY 3
#define LONG_SELECT_KEY	 4
#define LONG_ENTER_KEY	5
#define LONG_ENTER_E_SELECT_KEY	6


#if (DEBUGBYPC)
extern BYTE EnterKeyON;
extern BYTE SelectKeyON;
#else
extern BYTE EnterKeyON;
extern BYTE SelectKeyON;
#endif


void PrintReportZByDay();//daily  report Z  by Date range
void PrintFiscalByDay();//fiscal memory report by Date range
void PrintFiscalByMonth();//fiscal memory report by months range
void PrintFiscalByZ();    //fiscal memory report by Z#

BYTE GetDate(char *pBuff,BYTE pENTER_KEY);//get the curren date
BYTE GetMonth(char *pBuff,BYTE pENTER_KEY);//get the current month
BYTE GetNumber(char *pBuff,BYTE pENTER_KEY);//get the current number

//extern  short Read_FiscalData(short sType, WORD *StartZ=NULL, WORD* EndZ=NULL);


#define MAINMENU_MAX	5
#define SUBMENU_MAX	2

WORD  SelectCounter,EnterCounter;// ͳ�Ƽ����µ�ʱ�� //

BYTE EditArea;//

BYTE KeyMode;//bit0..3 main menu; bit4..7
char OperMess[2][DISLEN+1];
BYTE YearFr,MonthFr,DayFr,YearTo,MonthTo,DayTo;// Date range for report
WORD ZNumFr,ZNumTo;//#Z range for the report

const char MainMenu[MAINMENU_MAX+1][DISLEN+1]={
	MainMenu1,// -> daily  report
	MainMenu2,//  -> fiscal memory report by day
	MainMenu3,//   -> fiscal memory report by months
	MainMenu4,	// -> fiscal memory report by Z number	"",
	MainMenu5,	// -> Printe status,
	MainMenu6
};

#if (DEBUGBYPC==0)

#define DISPPORT 1

void DisplayMess(BYTE pos,char *pMess)
{//display then message on screen
	short i,slen;

#if (DISPPORT)
	SendComm(DISPPORT,0x1b);SendComm(DISPPORT,'Q');SendComm(DISPPORT,pos+'A');
	if (pMess==0)
		for (i=0;i<DISLEN;i++)
			SendComm(DISPPORT,' ');
	else
	{
		slen=strlen(pMess);
		if (slen>DISLEN)
			slen = DISLEN;
		else if (slen<DISLEN)
		{
			for (i=slen;i<DISLEN;i++)
				pMess[i]=' ';
		}

		for (i=0;i<DISLEN;i++)
			SendComm(DISPPORT,pMess[i]);
	}
	SendComm(DISPPORT,CRET);
#endif
}
#else
extern void DisplayMess(BYTE pos,char *pMess);
#endif

// Print daily report Z by the day
void PrintReportZByDay()//FUNC804 daily  report Z  by Date range
{
#if defined(FISCAL)
     ApplVar.FiscalDefine.DateFr =((YearFr << 9) | (MonthFr<< 5) |DayFr);
	 ApplVar.FiscalDefine.DateTo =((YearTo<< 9) | (MonthTo<< 5) |DayTo);
	Read_FiscalData(FUNC804-FUNC800);
#endif
}

//
void PrintFiscalByDay()//FUNC803 fiscal memory report by Date range
{
#if defined(FISCAL)
     ApplVar.FiscalDefine.DateFr =((YearFr << 9) | (MonthFr<< 5) |DayFr);
	 ApplVar.FiscalDefine.DateTo =((YearTo<< 9) | (MonthTo<< 5) |DayTo);
	Read_FiscalData(FUNC803-FUNC800);
#endif
}

void PrintFiscalByMonth()//FUNC803 fiscal memory report by months range
{
#if defined(FISCAL)
	ApplVar.FiscalDefine.DateFr = ((YearFr << 9) | (MonthFr<< 5) |0x01);
	ApplVar.FiscalDefine.DateTo = ((YearFr << 9) | (MonthFr<< 5) |0x31);

	Read_FiscalData(FUNC803-FUNC800);
#endif
}

void PrintFiscalByZ() //FUNC802 fiscal memory report by Z#
{
#if defined(FISCAL)
	ApplVar.FiscalDefine.RecNumFr = ZNumFr;
	ApplVar.FiscalDefine.RecNumTo= ZNumTo;
	Read_FiscalData(FUNC802-FUNC800);
#endif
}

//Adjust the day
void getTime(void)
{

    if(MonthFr==2){
        if(YearFr%4==0)
        {
            if (DayFr>29) DayFr=1;
        }
        else
            if (DayFr>28) DayFr=1;
    }
	else  if(MonthFr==4||MonthFr==6||MonthFr==9||MonthFr==11)
    {
        if (DayFr>30) DayFr=1;
    }
    else
        if (DayFr>31) DayFr=1;


   if(MonthTo==2){
        if(YearTo%4==0)
        {
            if (DayTo>29) DayTo=1;
        }
        else
            if (DayTo>28) DayTo=1;
    }
   else if(MonthTo==4||MonthTo==6||MonthTo==9||MonthTo==11)
   {
       if (DayTo>30) DayTo=1;
   }
   else
       if (DayTo>31) DayTo=1;

}



//get the  YearFr,MonthFr,DayFr and YearTo,MonthTo,DayTo;
// change them into pBuff in the format (yy/mm/dd-yy/mm/dd)
BYTE GetDate(char *sDisp,BYTE pENTER_KEY)//get the curren date
{
   switch (pENTER_KEY)
   {
       case 0:
            YearFr = ((Now.year & 0xf0)>>4)*10 + (Now.year & 0x0f);
            MonthFr = ((Now.month & 0xf0)>>4)*10 + (Now.month & 0x0f);
            DayFr = ((Now.day & 0xf0)>>4)*10 + (Now.day & 0x0f);

            YearTo = ((Now.year & 0xf0)>>4)*10 + (Now.year & 0x0f);
            MonthTo= ((Now.month & 0xf0)>>4)*10 + (Now.month & 0x0f);
            DayTo= ((Now.day & 0xf0)>>4)*10 + (Now.day & 0x0f);
			EditArea = 0;// point to the first area
            break;
       case ENTER_KEY:
         {
            EditArea++;
			if (EditArea>5)
				return true;
            break;
         }
       case SELECT_KEY:
         {
           switch (EditArea)
            {
              case 0:
                YearFr++;
                if (YearFr>90) YearFr=07;
                  break;
              case 1:
                  MonthFr++;
                  if (MonthFr>12) MonthFr=1;
                  break;
              case 2:
                  DayFr++;
                  break;
              case 3:
                  YearTo++;
                  if (YearTo>90) YearTo=07;
                  break;
              case 4:
                  MonthTo++;
                  if (MonthTo>12) MonthTo=1;
                  break;
              case 5:
                  DayTo++;
                  break;
            }
         }
   }
   getTime();
    memset(sDisp,' ',DISLEN);
   sDisp[0]=YearFr/10+'0';   sDisp[1]=YearFr%10+'0';   sDisp[2]='/';
   sDisp[3]=MonthFr/10+'0';  sDisp[4]=MonthFr%10+'0';  sDisp[5]='/';
   sDisp[6]=DayFr/10+'0';    sDisp[7]=DayFr%10+'0';    sDisp[8]='-';

   sDisp[9]=YearTo/10+'0';   sDisp[10]=YearTo%10+'0';   sDisp[11]='/';
   sDisp[12]=MonthTo/10+'0'; sDisp[13]=MonthTo%10+'0';  sDisp[14]='/';
   sDisp[15]=DayTo/10+'0';   sDisp[16]=DayTo%10+'0';

    sDisp[DISLEN-1]=EditArea+1+'0';
    sDisp[DISLEN]=0;
   return false;
}

//get the  YearFr,MonthFr and YearTo,MonthTo;
// change them into pBuff in the format (yy/mm-yy/mm)
BYTE GetMonth(char *sDisp,BYTE pENTER_KEY)//get the current month
{
    switch (pENTER_KEY) {
       case 0:
            YearFr = ((Now.year & 0xf0)>>4)*10 + (Now.year & 0x0f);
            MonthFr = ((Now.month & 0xf0)>>4)*10 + (Now.month & 0x0f);

            YearTo = ((Now.year & 0xf0)>>4)*10 + (Now.year & 0x0f);
            MonthTo= ((Now.month & 0xf0)>>4)*10 + (Now.month & 0x0f);
			EditArea = 0;// point to the first area
			break;

       case ENTER_KEY:
           EditArea++;
		   if (EditArea>3)
		   		return true;
           break;
       case SELECT_KEY:
       {
           switch (EditArea)
            {
              case 0:
                  YearFr++;
                  if (YearFr>90) YearFr=07;
                  break;
              case 1:
                  MonthFr++;
                  if (MonthFr>12) MonthFr=1;
                  break;
              case 2:
                  YearTo++;
                  if (YearTo>90) YearTo=07;
                  break;
              case 3:
                  MonthTo++;
                  if (MonthTo>12) MonthTo=1;
                  break;
             }
      }
   }
	DayFr = 1;	DayTo = 31;
    getTime();
	memset(sDisp,' ',DISLEN);

    sDisp[0]=YearFr/10+'0';    sDisp[1]=YearFr%10+'0';    sDisp[2]='/';
    sDisp[3]=MonthFr/10+'0';   sDisp[4]=MonthFr%10+'0';  sDisp[5]='-';

    sDisp[6]=YearTo/10+'0';    sDisp[7]=YearTo%10+'0';    sDisp[8]='/';
    sDisp[9]=MonthTo/10+'0';   sDisp[10]=MonthTo%10+'0';

    sDisp[DISLEN-1]=EditArea+1+'0';
    sDisp[DISLEN]=0;
	return false;
}
//get then ZNumFr and ZNumTo
// change them into pBuff in the format (ddddd-ddddd)
BYTE GetNumber(char *sDisp,BYTE pENTER_KEY)//get the current number
{
   short i,t,i10000,i1000,i100,i10,i1;

   if (	pENTER_KEY==0)
	  		ZNumFr = ZNumTo = 1;
   if (EditArea<5)
   {
       i10000=ZNumFr/10000;
       i1000=(ZNumFr%10000)/1000;
       i100=(ZNumFr%1000)/100;
       i10=(ZNumFr%100)/10;
       i1=(ZNumFr%10);
   }
   else//   if (EditArea>=5)
   {
       i10000=ZNumTo/10000;
       i1000=(ZNumTo%10000)/1000;
       i100=(ZNumTo%1000)/100;
       i10=(ZNumTo%100)/10;
       i1=(ZNumTo%10);
   }


   switch (pENTER_KEY)
   {
   	  case 0:
	  		ZNumFr = 1;ZNumTo = 1;
			EditArea = 0;// point to the first area
	  		break;
      case ENTER_KEY:
            EditArea++;
			if (EditArea>9)
				return true;
            break;

      case SELECT_KEY:
      {
          if (EditArea<=9)
          {
                switch (EditArea)
                {
                 case 0:
                 case 5:
                     i10000++;
                     if(i10000>5)   i10000=0;
                      break;
                 case 1:
                 case 6:
                     i1000++;
                     if(i1000>9)i1000=0;
                     break;
                 case 2:
                 case 7:
                     i100++;
                     if(i100>9)i100=0;
                     break;
                 case 3:
                 case 8:
                     i10++;
                     if(i10>9)i10=0;
                     break;
                 case 4:
                 case 9:
                     i1++;
                     if(i1>9)i1=0;
                     break;
                 }
              }
      }
   }

   memset(sDisp,' ',20);
   if(EditArea<5)
   {
     ZNumFr=i10000*10000+i1000*1000+i100*100+i10*10+i1;
   } else// if(EditArea>=5)
   {
     ZNumTo=i10000*10000+i1000*1000+i100*100+i10*10+i1;
   }

	WORDtoASCZero(sDisp+4, ZNumFr);
	sDisp[5]='-';
	WORDtoASCZero(sDisp+4+6, ZNumTo);

	WORDtoASC(sDisp+DISLEN-1, EditArea+1);

//   sprintf(sDisp,"%05d-%05d    %1d",ZNumFr,ZNumTo,EditArea+1);
   return false;


}



//ccr061231>>>>>>>>>>>>>>>>>>>>>>>>>>>>
/******************************************************************
 Funzione: BYTE ReadKey(void)
 Esegue:   Ritorna il tasto premuto che puo essere anche nessun tasto
 		o entambi i tasti ENTER e SELECT
 		0= NO_KEY
 		1=SELECT KEY
 		2=ENTER_KEY
 		3=ENTER_E_SELECT_KEY

 		se trova un tasto premuto aspetta il rilascio prima di tornare
******************************************************************/
BYTE ReadKey(void)
{
	BYTE sKey;

	sKey = NO_KEY;

	if(SelectKeyON && SelectKeyON)
	{
		if (SelectCounter<=LONGKEY)
			SelectCounter++;
	}
	else if (!SelectKeyON)
		SelectCounter = 0;

	if(EnterKeyON && EnterKeyON)
	{
		if (EnterCounter<=LONGKEY)
			EnterCounter++;
	}
	else if (!EnterKeyON)
		EnterCounter = 0;
	if (SelectCounter>=LONGKEY && EnterCounter)
	{
		sKey = ENTER_E_SELECT_KEY;
		SelectCounter = EnterCounter = 0;
	}
	if (SelectCounter>=LONGKEY)
	{
		SelectCounter = 0;
		sKey =  SELECT_KEY;
	}
	if (EnterCounter>=LONGKEY)
	{
		sKey =  ENTER_KEY;
		EnterCounter = 0;
	}

	return sKey;
}


BYTE ProcessButton()
{
	BYTE i;

	switch (ReadKey()){
	case ENTER_E_SELECT_KEY:
//     if (KeyMode & 0x0f)
// 		KeyMode = 0x00;
//     else
        {

			i = (ApplVar.ErrorNumber & 0x7fff)+(CWXXI01-1);

			if (i==CWXXI74 || i==CWXXI76 || i==CWXXI78 || i==CWXXI94 || i==CWXXI83 || i==CWXXI82)
//			if (ApplVar.FisCardFlag==FMISNEW || ApplVar.FisCardFlag==NOFM || ApplVar.FisCardFlag==BADFM || ApplVar.FisCardFlag==NOEJ)
			{
				CWORD(SysBuf[0])=0x2002;
				CWORD(SysBuf[2])=0x1ca5;
				CWORD(SysBuf[4])=0x3533;
				CWORD(SysBuf[6])=0x3003;
				CWORD(SysBuf[8])=0x3431;
				CWORD(SysBuf[10])=0x0045;
				SendString(SysBuf,11,-1);
			}

            DisplayMess(0,0);
            DisplayMess(1,0);

    		KeyMode = 0;
    		return 0;
        }
	case ENTER_KEY:
		if (KeyMode)
		{
			if ((KeyMode & 0x0f)==02)
			{
				KeyMode &= 0xf0;
			}
			else
			{
				if ((KeyMode & 0x0f)==01)
				{
//					EditArea++;//skip to the next area for iniput
					switch (KeyMode & 0xf0){
					case 0x10:
						if	(GetDate(OperMess[0],ENTER_KEY))//get the curren date
							PrintReportZByDay();// -> daily  report Z
						break;
					case 0x20:
						if (GetDate(OperMess[0],ENTER_KEY))
							PrintFiscalByDay();//fiscal memory report by ApplVar.Day
						break;
					case 0x30:
						if (GetMonth(OperMess[0],ENTER_KEY))
							PrintFiscalByMonth();//fiscal memory report by months
						break;
					case 0x40:
						if (GetNumber(OperMess[0],ENTER_KEY))
							PrintFiscalByZ();
						break;
					}
					DisplayMess(0,OperMess[0]);
					DisplayMess(1,OperMess[1]);
				}
				else
				{
					KeyMode |= 0x01;
					switch (KeyMode & 0xf0){
					case 0x10:
					case 0x20:
						GetDate(OperMess[0],0);//get the curren date
						break;
					case 0x30:
						GetMonth(OperMess[0],0);//get the current month
						break;
					case 0x40:
						GetNumber(OperMess[0],0);//get the current number
						break;
					case 0x50:
						HardTest(4096);//��ӡ�ļ������
						KeyMode &= 0xf0;
						return KeyMode;
					}
					strcpy(OperMess[1],MainMenu[MAINMENU_MAX]);
					DisplayMess(0,OperMess[0]);
					DisplayMess(1,OperMess[1]);
					return KeyMode;
				}
				break;
			}
		}
		else
		{
			RFeed(1);
			break;
		}
	case SELECT_KEY:
		{
			switch (KeyMode & 0x0f){
			case 0x01:
				switch (KeyMode & 0xf0){
				case 0x10:
				case 0x20:
					GetDate(OperMess[0],SELECT_KEY);//get the curren date
					break;
				case 0x30:
					GetMonth(OperMess[0],SELECT_KEY);//get the current month
					break;
				case 0x40:
					GetNumber(OperMess[0],SELECT_KEY);//get the current number
					break;
				}
				DisplayMess(0,OperMess[0]);
				DisplayMess(1,OperMess[1]);
				break;
			case 0x02:// goto the first line
				KeyMode = (KeyMode & 0xf0)+0x01;
				break;
			case 0x00:// select the main menu
				KeyMode+=0x10;

				if ((KeyMode>>4)>MAINMENU_MAX)
					KeyMode = 0x10;

				i = (KeyMode>>4)-1;
				strcpy(OperMess[0],MainMenu[i]);
				i++;
				if (i>=MAINMENU_MAX)
					i = 0;
				strcpy(OperMess[1],MainMenu[i]);
				DisplayMess(0,OperMess[0]);
				DisplayMess(1,OperMess[1]);
				return KeyMode;
			}
		}
		break;
	default:
		return false;
	}
}
//ccr<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#endif

