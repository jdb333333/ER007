#define BARCODE_C
#include "king.h"                               /* Kingtron library and I/O routines */

#include "exthead.h"
#include "exth.h"

#if 0

CONST BYTE digbar [10][3] = {
/*      set A, set B, set C             digit           code (7 bit) <-- 0 */
	{0x0d, 0x27,  0x72},   /* '0' -> 0001101, 0100111, 1110010 */
	{0x19, 0x33,  0x66},   /* '1' -> 0011001, 0110011, 1100110 */
	{0x13, 0x1b,  0x6c},   /* '2' -> 0010011, 0011011, 1101100 */
	{0x3d, 0x21,  0x42},   /* '3' -> 0111101, 0100001, 1000010 */
	{0x23, 0x1d,  0x5c},   /* '4' -> 0100011, 0011101, 1011100 */
	{0x31, 0x39,  0x4e},   /* '5' -> 0110001, 0111001, 1001110 */
	{0x2f, 0x05,  0x50},   /* '6' -> 0101111, 0000101, 1010000 */
	{0x3b, 0x11,  0x44},   /* '7' -> 0111011, 0010001, 1000100 */
	{0x37, 0x09,  0x48},   /* '8' -> 0110111, 0001001, 1001000 */
	{0x0b, 0x17,  0x74},   /* '9' -> 0001011, 0010111, 1110100 */
/* Guard Pattern 101, center pattern 01010 */
};

CONST BYTE dig13[10] = {
/*      13th digit is formed through pattern of digit 7 to 12
	according to following table, 0 = set A, 1 = set B,
	first 6 digit always use set C (right to left)
	     digit 12 11 10  9  8  7
*/
	0x00,   /*  A, A, A, A, A, A -> 13th digit 0 */
	0x0b,   /*  A, A, B, A, B, B -> 13th digit 1 */
	0x0d,   /*  A, A, B, B, A, B -> 13th digit 2 */
	0x0e,   /*  A, A, B, B, B, A -> 13th digit 3 */
	0x13,   /*  A, B, A, A, B, B -> 13th digit 4 */
	0x19,   /*  A, B, B, A, A, B -> 13th digit 5 */
	0x1c,   /*  A, B, B, B, A, A -> 13th digit 6 */
	0x15,   /*  A, B, A, B, A, B -> 13th digit 7 */
	0x16,   /*  A, B, A, B, B, A -> 13th digit 8 */
	0x1a,   /*  A, B, B, A, B, A -> 13th digit 9 */
};
#endif
short CCDCounter;
BYTE CCDBuff[CCDBUFMAX];

/***************************************************************/

/*
    IN STORE MARKING active when ARTLEVEL bit 3 is set

	    format FFRRRRRAAAAAC fixed 13 digits when BARCODE BIT 7 not set
		then
			 ONLY  FF = 21 Identifier, for Dansk it is 20
		else when BARCODE BIT 7 is set also
			FF = 02, 20, 26, 28


		When BARCODE BIT 6 is set also the weight can be decoded

		FF = 02, 20, 21, 26, 28 then format FFRRRRRAAAAAC
		FF = 25, 27, 29 the format FFRRRRRWWWWWC

    RRRRR = Random ApplVar.Plu Number
    AAAAA = Amount (qty is 1)
	WWWWW = ApplVar.Qty (xx.xxx fixed)
    C = check digit

	IN STORE MARKING for magazines is active when bit 4 of BARCODE is set
	format is fixed to FFFRRRRAAAAAC fixed 13 digits
	FFF = 379 Identifier
	RRRR = Standard Random ApplVar.Plu Number
	379RRRR = Random ApplVar.Plu number for Celigny France (BSF == 0)
	AAAAA = Amount
	ApplVar.Qty is ONE or ApplVar.Qty which is entered


	ApplVar.FBarcode
	1                       Standard Random Code
	2                       Code & ApplVar.Price for Presse (France) 379####PPPPPC
	3                       Code & ApplVar.Price XX#####PPPPPC
	4                       Code & Weight XX#####WWWWWC
	5                       depart, cost price, sales price  ###CCCCCPPPPPP

*/

void CheckInStore()
{
#if (DD_FISPRINTER==0)

	BYTE id;
	if (BIT(ART_LEVEL, BIT3) && (Appl_EntryCounter == 13 || Appl_EntryCounter == 12))
		/* In Store Marking ? */
	{
		if (Appl_EntryCounter == 12) /* if length 12 then EAN 13 with */
		{                                               /* preceding ZERO, add preceding ZERO */
	    	AtEntryBuffer(13) = '0';
		}
		id = ((AtEntryBuffer(13) - '0') * 0x10) +
			   (AtEntryBuffer(12) - '0');

		switch(id)
		{
			case 0x02:
			case 0x20:
			case 0x26:
			case 0x28:
				if (!BIT(BARCODE, BIT7))
					break;
			case 0x21:
				ApplVar.FBarcode = 3;
				break;
			case 0x37:
				if (BIT(BARCODE, BIT4) && EntryBuffer[ENTRYSIZE - 12] == '9')
					ApplVar.FBarcode = 2;
				break;
			case 0x25:
			case 0x27:
			case 0x29:
				if (BIT(BARCODE, BIT6))
					ApplVar.FBarcode = 4;
				break;
			default:
				break;
		}
		if (ApplVar.FBarcode > 1)
		{
			ApplVar.Entry = ZERO;
			{
				ApplVar.Entry.Value[0] = (EntryBuffer[ENTRYSIZE - 3] - '0')+
					((EntryBuffer[ENTRYSIZE - 4] - '0') * 0x10);
			    ApplVar.Entry.Value[1] = (EntryBuffer[ENTRYSIZE - 5] - '0')+
			    	((EntryBuffer[ENTRYSIZE - 6] - '0') * 0x10);
			    ApplVar.Entry.Value[2] =
			    	(EntryBuffer[ENTRYSIZE - 7] - '0');
				if (ApplVar.FBarcode == 4)      /* Weight xx.xxx in code */
				{
					ApplVar.Qty = ApplVar.Entry;
					ApplVar.Qty.Sign = 0x03;
					ApplVar.MultiplyCount = 1;
				}
				else if (!ApplVar.FPrice)
				{
					ApplVar.Price = ApplVar.Entry;
				    ApplVar.FPrice = 1;
				}
				if (ApplVar.FBarcode == 2)      /* price encoded on magazine ?*/
					Appl_EntryCounter = 7;
				else
				{
					EntryBuffer[ENTRYSIZE - 13] = ' ';
					EntryBuffer[ENTRYSIZE - 14] = ' ';
					if (ApplVar.FBarcode != 4)
						ApplVar.MultiplyCount = 0; /* reset multiply count */
					Appl_EntryCounter = 5;
				}
				for (id = 0; id < 7; id++)
			    {
				    EntryBuffer[ENTRYSIZE - 2 - id] =
					    EntryBuffer[ENTRYSIZE - 8 - id];
				    EntryBuffer[ENTRYSIZE - 8 - id] = ' ';
			    }
			}
			StrToBCDValue(ApplVar.Entry.Value, &EntryBuffer[ENTRYSIZE - 2], BCDLEN);
		}
    }
#endif
}

///////////////////////////////////////////////////////////////////////////
extern BYTE USB_Detect(void);//���USB�豸
extern int CheckUSBKey(void);//���USB�����Ƿ�������
extern short GetUSBKey(BYTE clean);//��ȡUSB��������

short BarCode()
{

#if (DD_FISPRINTER==0)

    BYTE bport,sOK;
    short c;

	bport = BARCODE & 0x07;
/*ccr2015-11-13 �������³����ʱ,���õ��޷�����USBɨ��ǹ
    2014-08-22 ���������ж�,���ʲô����?
    if (ApplVar.ErrorNumber
        || ApplVar.CentralLock==OFF
        || ApplVar.CentralLock==Z
        || ApplVar.CentralLock==X
        || (ApplVar.CentralLock==SET && Appl_ProgType!=SETPLU)
        )
*/
    if (ApplVar.ErrorNumber || ApplVar.CentralLock == OFF)
    {
#if (!defined(STM32F10X_HD))
		if (USB_Detect()==USB_KEYBOARD)
            GetUSBKey(true);
#endif
		return 0;
    }

    sOK = FALSE;
	while (!sOK)
	{
#if (!defined(STM32F10X_HD))
		if (USB_Detect()==USB_KEYBOARD && CheckUSBKey())
			c = GetUSBKey(false);
		else
#endif
		if (!bport || !CheckComm(bport-1) || (c = ReadComm(bport-1))==-1)
			return 0;

		CCDBuff[CCDCounter++] = c;
		if (CCDCounter>=CCDBUFMAX)
		{
			CCDCounter = 0;
			return 0;
		}
		switch (c){
		case STX:
		case '$':
			CCDCounter = 0;
			return 0;
		case 0x0a:
/*
			if (CCDBuff[CCDCounter-2] == 0x0d)
			{
				CCDCounter -=2;//Skip the end flag 0x0a
				CCDBuff[CCDCounter]=0;
				sOK = TRUE;
				break;
			}
			CCDCounter --;//Skip the end flag 0x0a
			CCDBuff[CCDCounter]=0;
			return 0;
*/
		case 0x0d:				//End of a Bar code
		case 0x09:				//End of a Bar code
		case ETX:				//End of a Bar code
			CCDCounter --;
			CCDBuff[CCDCounter]=0;
			if (CCDCounter==0)
				return 0;
			else
			{
				sOK = TRUE;
				break;
			}
        default:
            if ((c<0x20 || c>0x7e)&&CCDCounter)//ȥ������β�ʱ�ĸ�������
            {
                CCDCounter --;//Skip the end flag 0x0a
                CCDBuff[CCDCounter]=0;
            }
            break;
		}
	}
	InActive = 0;//Disable display datetime
    ClearEntry();
    if (ApplVar.CentralLock == SET && !Appl_ProgType)
    {
        PrintBarcodeImage(CCDBuff,CCDCounter);
        PutsM(CCDBuff);
	    RJPrint(0x02, CCDBuff);
        RFeed(4);
		CCDCounter = 0;
		return 0;
    }
	Appl_EntryCounter = CCDCounter;
	CCDCounter = 0;
    memcpy(EntryBuffer + ENTRYSIZE - Appl_EntryCounter - 1,CCDBuff, Appl_EntryCounter);
	ApplVar.FBarcode = 1;
	CheckInStore();
    if (ApplVar.CentralLock != RG && ApplVar.CentralLock != MG)
    {
		ApplVar.Key.Code = 0;
        ApplVar.FPrice = 0;
//ccr2017-05-09		ApplVar.KeyNo = ENTERKey; /* simulate number key */
//ccr2017-05-09		CheckFirmKey();
        ENTER;//ccr2017-05-09 ģ�ⰴȷ�ϼ�
		return 1;
    }
    else
    {
    	ApplVar.OldKey.Code = 0;
	    ApplVar.Key.Code = PLU1;
    	return 1;
    }
#else
	return 0;
#endif
}


