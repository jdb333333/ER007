#define PROGRAM_C
#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
#include "message.h"

#ifdef CASE_FATFS_EJ
    #include "flowbill.h"
#endif

#if (!defined(DEBUGBYPC) && defined(CASE_ETHERNET))
#include "Ethernet_App.h"

#include "lwip/opt.h"
#endif

#include "fiscal.h"

extern BYTE ProgType_Last;

CONST char Number0[]="Number=0";
BYTE ICBlockPrintFlag = 0;

short GrapNo;


void InitSysFlag()
{

    if (BIT(COPYRECEIP, BIT7))      // ��ӡ��0�ձ���ʱ,�Ƿ�λ�վݺ�   ///
        SETBIT(ApplVar.AP.ReportList[2].Options, BIT2);
    else
        RESETBIT(ApplVar.AP.ReportList[2].Options, BIT2);

    ApplVar.AmtDecimal = NO_DECIMAL;
    Prefix1 = PREFIX_1;
    Prefix2 = PREFIX_2;
    if (BIT(KEYTONE,BIT0))
    {
        Bios_1(BiosCmd_AutoClickOff);
    } else
    {
        Bios_1(BiosCmd_AutoClickOn);
    }

//    Density(0, DENSITY);      /* Density Receipt */
//    ApplVar.AP.Config.RDensity = DENSITY;
//    Density(1, DENSITY);       /* Density Journal */
//    ApplVar.AP.Config.JDensity = DENSITY;
//    ApplVar.AP.Config.Country = (CHARSET / 16);     /* set char set */
    if (ApplVar.AP.Config.Country > 4)
        ApplVar.AP.Config.Country = 0;
//    SetCountry(ApplVar.AP.Config.Country);      /* activate other character set */
#if !defined(FISCAL)
    Now.day--;      /* force new read of date and time incase format changed */
#endif

}


#if DD_FISPRINTER == 0
//BitNo:1..8  if (BitNo.Bit7=0),display it with caption
//����������1-No,0-Yesʱ,ʹ��sInv=YN������ȡ��
//��ʾPrompt.Caption[MsgIdx]
void CheckBitValue(short MsgIdx,char *Opt,BYTE BitNo,BYTE sInv)
{
    BYTE    BitV;

    BitV = BIT0<<((BitNo & 0x0f)-1);

    memset(ProgLineMes,' ',DISLEN+1);
    CopyFrStr(ProgLineMes+SETUPMARIN,Prompt.Caption[MsgIdx]);

#if (DISP2LINES)
    memset(ProgLine1Mes,' ',DISLEN+1);
#endif

    if (!Appl_BitNumber)//ֻ��ʾ������ĵ�ǰֵ
        Appl_BitNumber = ((BIT(*Opt,BitV)!=0) & 1)+1;
    else//�޸�������ĵ�ǰֵ
        SETMyFlags(CONFIGECR);
    if (Appl_BitNumber > 2)
        Appl_BitNumber = 1;
    if (Appl_BitNumber ==2)
    {
#if (DISP2LINES)
        ProgLine1Mes[DISLEN-1] = 'Y' ^ sInv;
#else
        ProgLineMes[DISLEN-1] = 'y' ^ sInv;
#endif
        SETBIT(*Opt,BitV);
    } else
    {
#if (DISP2LINES)
        ProgLine1Mes[DISLEN-1] = 'N' ^ sInv;
#else
        ProgLineMes[DISLEN-1] = 'n' ^ sInv;
#endif
        RESETBIT(*Opt,BitV);
    }


#if (DISP2LINES)
    if (ProgLine1Mes[DISLEN-1] == 'N')
    {
        ProgLine1Mes[DISLEN-3]='N';
        ProgLine1Mes[DISLEN-2] = 'o';
        ProgLine1Mes[DISLEN-1] = ' ';
    } else
    {
        ProgLine1Mes[DISLEN-3]='Y';
        ProgLine1Mes[DISLEN-2] = 'e';
        ProgLine1Mes[DISLEN-1] = 's';
    }
#endif

//#if(DD_ZIP==0 && DD_ZIP_21==0 || DD_LCD_1601==0)
    if (BIT(BitNo,BIT7))//ֻ��Ե���
        WORDtoASCL(ProgLineMes+strlen(Prompt.Caption[MsgIdx])+SETUPMARIN,BitNo & 0x0f);
//#endif

}

void GetBCDValue(short MsgIdx,char *val,short BCDBytes,char IsQty)
{
    if (Appl_EntryCounter)
    {
        if (Appl_EntryCounter > (BCDBytes * 2))
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
        else
        {
            StrToBCDValue(val, &EntryBuffer[ENTRYSIZE - 2], BCDBytes);

            SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
        }

    }

    ApplVar.Entry = ZERO;
    memcpy(ApplVar.Entry.Value, val, BCDBytes);
    strcpy(ProgLineMes+SETUPMARIN, Prompt.LineCap[MsgIdx]);
    ProgLineMes[lCAPWIDTH+1] = 0;
    if (IsQty)
    {
#if (DISP2LINES)
        if (BIT(ApplVar.ArrowsAlfa,INPUTPWD))
            memset(ProgLine1Mes,'-',DISLEN);
        else
        {
//     		memset(ProgLine1Mes,' ',sizeof());
            strncpy(ProgLine1Mes, DispQtyStr(ProgLine1Mes, &ApplVar.Entry,DISLEN),sizeof(ProgLine1Mes));
        }
#else
        if (BIT(ApplVar.ArrowsAlfa,INPUTPWD))
            memset(ProgLineMes+lCAPWIDTH,'-',DISLEN-lCAPWIDTH);
        else
            strncpy(ProgLineMes, DispQtyStr(ProgLineMes, &ApplVar.Entry,DISLEN),sizeof(ProgLineMes));
#endif

    } else
    {
        if (Appl_EntryCounter)
        {
            if (ApplVar.DecimalPoint)
                ApplVar.DecimalPoint--;
            GetEntry();
            ChangePoint();
            memcpy(val,ApplVar.Entry.Value,BCDBytes);
        }

#if (DISP2LINES)
        strncpy(ProgLine1Mes, DispAmtStr(ProgLine1Mes, &ApplVar.Entry,DISLEN),sizeof(ProgLine1Mes));
#else
        strncpy(ProgLineMes, DispAmtStr(ProgLineMes, &ApplVar.Entry,DISLEN),sizeof(ProgLineMes));
#endif

    }
}

void GetWordValue(short MsgIdx,WORD *val,WORD max)
{
    if (Appl_EntryCounter)
    {
        StrToBCDValue(ApplVar.Entry.Value, &EntryBuffer[ENTRYSIZE - 2], BCDLEN);
        GetLongEntry();
        if (max && Appl_NumberEntry>max)
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
        else
        {
            *val = Appl_NumberEntry;
            SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
        }
    }

    CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[MsgIdx]);
//     ProgLineMes[lCAPWIDTH] = 0;

#if (DISP2LINES)
    WORDtoASC(ProgLine1Mes + DISLEN-2, *val);
#else
    WORDtoASC(ProgLineMes + DISLEN-2, *val);
#endif

}

/**
 *
 *
 * @author EutronSoftware (2016-12-21)
 *
 * @param sMsg :���������
 * @param val :���������ַ���
 * @param size :��󳤶�
 *
 * @return BYTE :=0,������;=1,������
 */
BYTE GetString(char *sMsg,char *val,WORD size)
{
    short   sLp,sP;
    BYTE sByte;

    MemSet(ProgLineMes, DISLEN+1, ' ');

    if (size)
    {
        if (Appl_EntryCounter)
        {
            GetCaption((char *) val, size);
            SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
            val[size]=0;
        }
        if (sMsg)
            CopyFrStr(ProgLineMes, sMsg);

#if (DISP2LINES)
        sP = 0;
#else
        sP = 4;
#endif
        for (sLp=0;sLp<size && sP<DISLEN;sLp++)
        {
            sByte =((char *)val)[sLp];
#if defined(CASE_FORHANZI)
            if (sByte>160)
            {//Ϊ����
                sByte -= 160;

#if (DISP2LINES)

                ProgLine1Mes[sP++] = (sByte /10) | 0xB0;
#else
                ProgLineMes[sP++] = (sByte /10) | 0xB0;
#endif

                sByte = (sByte % 10) | 0xB0;
            }
#endif

#if (DISP2LINES)
            ProgLine1Mes[sP++] = sByte;
#else
            ProgLineMes[sP++] = sByte;
#endif
            if (!sByte) break;
        }
        ProgLineMes[DISLEN]=0;

#if (DISP2LINES)
        ProgLine1Mes[DISLEN]=0;
#endif

        return 1;
    } else
    {
        Appl_ProgLine++;
        return 0;
    }
}

void GetByteValue(short MsgIdx,BYTE *val,BYTE max)
{
    WORD sVal;

    sVal = *val;
    GetWordValue(MsgIdx,&sVal,max);
    *val = sVal;
}

//============ hf added 20040908 ================
/*****************************************
*

* IPstr:��     	*
******************************************/
/**
 * �Ҷ��뷽ʽ�����ָ�ʽIPת��Ϊ�ַ���IP��ַ*
 *
 * @author EutronSoftware (2016-12-20)
 *
 * @param IPstr :ת�����IP��ַ�ַ���
 *       "192.168.123.234",15���ֽ�*
 *                IPstr-^          *
 *
 * @param Num :��ת����IP ���飬4�ֽ� *
 * @param fmt :=0,ת��Ϊ"192.168.0.1"��ʽ;=1,ת��Ϊ"192.168.  0.  1"��ʽ*
 * @return BYTE :ת����IP��ַ����
 */
BYTE NumToIP(char *IPstr,BYTE *Num,BYTE fmt)
{
    int i,j,k;
    BYTE sDot=0;

    k = 0;
    for (i=3;i>=0;i--)
    {
        j=WORDtoASC(IPstr,Num[i]);
        if (fmt)
            j=3;//ccr2017-09-26��ʾIP��ַʱ,ת��Ϊ"192.168.  0.  1"��ʽ�̶���λ��
        {
            IPstr -= j;
            if (i)
            {
                *IPstr-- = '.';
                j++;
            }
        }
        k += j;
    }
    return k;
}

/*****************************************
* ��IP ��ַ��ʽת��Ϊ���ָ�ʽ    *
* IPstr:��ת����IP ��ַ�ַ�����   *
*         ��ʽ��:192.168.0.1�����16 �� *
*         �ֽ�(����'\0')                                 *
* Num:ת�����IP ���飬4 ���ֽ� *
******************************************/
BYTE IPToNum(BYTE *Num,char *IPstr,short strLen)
{
    short ip = 0;
    BYTE i,j;

    for (i = 0,j = 0;i < strLen;i++)
    {
        /*�ǿո�������*/
        if (IPstr[i] == ' ')
            continue;
        else if (IPstr[i] != '.')
            ip = ip * 10 + (IPstr[i] & 0x0f);
        else
        {
            if (ip < 256)
            {
                Num[j] = ip;
                ip = 0;
                j++;
            } else
                return ERROR_ID(CWXXI71);
        }
    }
    if (j == 3 && ip < 256)
    {
        Num[j] = ip;
        return 0;
    } else
        return CWXXI71 - CWXXI01 + 1;
}

/**
 * �������IP��ַת��Ϊ����,����val
 *
 * @author EutronSoftware (2016-12-20)
 *
 * @param sMsg :������ʾ����Ϣ
 * @param val :�������IP,����Ϊ4�ֽ�
 * @return BYTE:=true,�޸���IP
 */
BYTE GetIP(char *sMsg,BYTE *val)
{
    short sP,slen,sCp;
    BYTE  sip[4];

    if (Appl_EntryCounter)
    {
        if ((ApplVar.ErrorNumber=IPToNum(sip, &AtEntryBuffer(Appl_EntryCounter), Appl_EntryCounter))==0);
        {
            memcpy(val,sip,4);
            SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
        }
    }
//     memcpy(EntryBuffer + ENTRYSIZE - sP- 1,ProgLineMes+DISLEN-sP-1,sP);

#if (DISP2LINES)
    if (sMsg)
        CopyFrStr(ProgLineMes,sMsg);
    sP = NumToIP(ProgLine1Mes+DISLEN-1, val,1);
    ProgLine1Mes[DISLEN]=0;
#else
    //�鲢С����
    if (sMsg)
        CopyFrStr(ProgLineMes,sMsg);
    sP = NumToIP(ProgLineMes+DISLEN-1, val,0);
    ProgLineMes[DISLEN]=0;
#endif
    return (Appl_EntryCounter);
}
//====================== hf added end ==================


void ProgPlu()
{
    WORD i;
    BYTE sBuf[10];

    if (Appl_ProgNumber >= ApplVar.AP.Plu.Number)
    {
        if (ApplVar.AP.Plu.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            Appl_ProgNumber = -1;
            Appl_ProgLine = 0;//
        }
        return;
    }
    ApplVar.PluNumber = Appl_ProgNumber;
    ReadPlu();
    switch (Appl_ProgLine)
    {
    case 1:
        if (ApplVar.AP.Plu.RandomSize)
            Appl_MaxEntry = ApplVar.AP.Plu.RandomSize * 2;
        break;
    case 2:     /*Get PLU bar code*/
#if (0)
		if (ApplVar.AP.Plu.RandomSize)
        {
            SetInputMode('9');
            Appl_MaxEntry = 0;//ApplVar.AP.Plu.RandomSize * 2;

            if (Appl_EntryCounter)
            {
                StrToBCDValue(ApplVar.Entry.Value, &EntryBuffer[ENTRYSIZE - 2], BCDLEN);
                memset(ApplVar.Plu.Random,0,sizeof(ApplVar.Plu.Random));
                memcpy(ApplVar.Plu.Random,ApplVar.Entry.Value,ApplVar.AP.Plu.RandomSize);
            }


            CopyFrStr(ProgLineMes, MsgBARCODE);

            HEXtoASC(ProgLineMes + DISLEN - Appl_MaxEntry,ApplVar.Plu.Random,ApplVar.AP.Plu.RandomSize);
            for (i=0;i<ApplVar.AP.Plu.RandomSize;i++)
            {
                if (ProgLineMes[DISLEN - Appl_MaxEntry + i]=='0')
                    ProgLineMes[DISLEN - Appl_MaxEntry + i]=' ';
                else
                    break;
            }
            break;
        }
        else
#endif
            Appl_ProgLine = 3;
    case 3:     /* PLU name */
        SetInputMode('a');
        Appl_MaxEntry = ApplVar.AP.Plu.CapSize;
        GetOpt(0, ApplVar.Plu.Name, ApplVar.AP.Plu.CapSize);
#if (DISP2LINES)
        //ccr2017-05-09>>>>�ڵ�һ����ʾ��Ʒ����>>>>>>>>>>>>>>>>>
        for (i=6;i>=0;i--)
        {//�������λ��
            if (ApplVar.Plu.Random[i]!=0)
                break;
        }
        memset(ProgLineMes,' ',sizeof(ProgLineMes));
        CopyFrStr(ProgLineMes, PLUBARCODE);
        if (i<0)
            ProgLineMes[DISLEN-1] = '?';
        else
        {
            i++;
            i <<= 1;
            if (i>DISLEN)
                i = DISLEN;
            HEXtoASC(ProgLineMes + DISLEN-i, ApplVar.Plu.Random,(i>>1));
            if (ProgLineMes[DISLEN-i]=='0' || ProgLineMes[DISLEN-i]==' ')
                ProgLineMes[DISLEN-i]='#';
            //else if (i != DISLEN)
            //    ProgLineMes[DISLEN-i-1]='#';
        }
        //ccr2017-05-09<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#endif
        break;

    case 4:     /* price 1 */
    case 5:     /* price 2 */
    case 6:     /* price 3 */
    case 7:     /* price 4 */
        SetInputMode('9');
        Appl_MaxEntry = 10;
        if ((Appl_ProgLine - 3) > ApplVar.AP.Plu.Level)
            Appl_ProgLine = 8;
        else if (GetOpt(4 + Appl_ProgLine, ApplVar.Plu.Price[Appl_ProgLine - 4], ApplVar.AP.Plu.PriceSize))
            break;
    case 8:     /* plu dept */
        Appl_MaxEntry = 3;
        i =  ApplVar.PluDept;
        GetOpt(1, &i, ApplVar.AP.Dept.Number);
        ApplVar.PluDept = i;
        ApplVar.Plu.Dept = *((BYTE *)&ApplVar.PluDept);
        ApplVar.Plu.DeptHi = *(((BYTE *)&ApplVar.PluDept)+1);
        break;
    case 9:     /* costprice */
        Appl_MaxEntry = 10;
        memcpy(sBuf,ApplVar.Plu.Cost,sizeof(ApplVar.Plu.Cost));
        if (ApplVar.AP.Plu.Cost && GetOpt(12, sBuf, ApplVar.AP.Plu.PriceSize))
        {
            memcpy(ApplVar.Plu.Cost,sBuf,sizeof(ApplVar.Plu.Cost));
            break;
        } else
            Appl_ProgLine = 10;
    case 10:        //OFF index for PLU
#if offNumber
        Appl_MaxEntry = 4;
        i = ApplVar.Plu.OFFIndex;
        if (ApplVar.AP.OFFPrice.Number && GetOpt(33, &i, ApplVar.AP.OFFPrice.Number))
        {
            ApplVar.Plu.OFFIndex = i;
            break;
        } else
#endif
            Appl_ProgLine = 11;
    case 11:         /* Linked ApplVar.Plu */
        Appl_MaxEntry = 4;
        i = ApplVar.Plu.Link;
        if (BIT(ApplVar.AP.Options.Plu, BIT0) &&
            GetOpt(32, &i, ApplVar.AP.Plu.Number))
        {
            ApplVar.Plu.Link = i;
            break;
        }
#if (0)//ccr2017-09-15 ��������stock�����ó���
        else
            Appl_ProgLine = 12;
    case 12:     //ccr2017-09-14 STOCK */
        if (ApplVar.AP.Plu.InvSize)
        {
            Appl_MaxEntry = 0;

            CopyFrStr(ProgLineMes+SETUPMARIN, DMes[ItemDMes33]);
#if (DISP2LINES)
            strncpy(ProgLine1Mes, DispQtyStr(0, &ApplVar.Plu.Inventory,DISLEN),DISLEN);
#else
            strncpy(ProgLineMes, DispQtyStr(ProgLineMes, &ApplVar.Plu.Inventory,DISLEN),DISLEN);
#endif
            return;
        }
        else
            Appl_ProgLine = 13;
    case 13:     //ccr2017-09-14 ADD STOCK */
        if (ApplVar.AP.Plu.InvSize)
        {
            Appl_MaxEntry = ApplVar.AP.Plu.InvSize*2+1;
            memset(sBuf,0,sizeof(BCD));
            if (GetOpt(47, sBuf, ApplVar.AP.Plu.InvSize))
            {
                if (Appl_EntryCounter)
                {
                    ApplVar.PluInventory=ApplVar.Plu.Inventory;
                    Add(&ApplVar.PluInventory,&ApplVar.Entry);
                    //if (!ApplVar.FTrain)
                        WritePluInventory();
                    Appl_ProgLine = 12;
                    memset(ProgLineMes,' ',sizeof(ProgLineMes));
                    memset(ProgLine1Mes,' ',sizeof(ProgLine1Mes));
                    ProgPlu();
                }
                return;
            }
        }
        else
            Appl_ProgLine = 14;
    case 14:     //ccr2017-09-14 REMOVE STOCK */
        if (ApplVar.AP.Plu.InvSize)
        {
            Appl_MaxEntry = ApplVar.AP.Plu.InvSize*2+1;
            memset(sBuf,0,sizeof(BCD));
            if (GetOpt(48, sBuf, ApplVar.AP.Plu.InvSize))
            {
                if (Appl_EntryCounter)
                {
                    ApplVar.PluInventory=ApplVar.Plu.Inventory;
                    Subtract(&ApplVar.PluInventory,&ApplVar.Entry);
                    //if (!ApplVar.FTrain)
                        WritePluInventory();
                    Appl_ProgLine = 12;
                    memset(ProgLineMes,' ',sizeof(ProgLineMes));
                    memset(ProgLine1Mes,' ',sizeof(ProgLine1Mes));
                    ProgPlu();
                }
                return;
            }
        }
#endif
    default:
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;//�ظ���ǰPLU������
        break;
    }
    if (Appl_ProgStart!=2)//ccr2017-05-10
        WritePlu();
}

/**
 *
 *
 * @author EutronSoftware (2017-09-15)
 */
void ProgPluStock()
{
    WORD i;
    BYTE sBuf[10];

    if (Appl_ProgNumber >= ApplVar.AP.Plu.Number)
    {
        if (ApplVar.AP.Plu.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            Appl_ProgNumber = -1;
            Appl_ProgLine = 0;//
        }
        return;
    }
    ApplVar.PluNumber = Appl_ProgNumber;
    ReadPlu();
    switch (Appl_ProgLine)
    {
    case 1:
        Appl_ProgLine=2;
    case 2:     /* PLU name */
        Appl_MaxEntry = 0;
        memset(ProgLineMes,' ',sizeof(ProgLineMes));
        strncpy(ProgLineMes, ApplVar.Plu.Name,DISLEN);
        if (ApplVar.AP.Plu.InvSize)
        {
#if (DISP2LINES)
            strcpy(ProgLine1Mes, DMes[ItemDMes33]);
            strncpy(ProgLine1Mes, DispQtyStr(ProgLine1Mes, &ApplVar.Plu.Inventory,DISLEN),DISLEN);
#else
            strncpy(ProgLineMes, DispQtyStr(ProgLineMes, &ApplVar.Plu.Inventory,DISLEN),DISLEN);
#endif
            return;
        }
        else
            Appl_ProgLine = 3;
    case 3:     //ccr2017-09-14 ADD STOCK */
        if (ApplVar.AP.Plu.InvSize)
        {
            Appl_MaxEntry = ApplVar.AP.Plu.InvSize*2+1;
            memset(sBuf,0,sizeof(BCD));
            if (GetOpt(47, sBuf, ApplVar.AP.Plu.InvSize))
            {
                if (Appl_EntryCounter)
                {
                    ApplVar.PluInventory=ApplVar.Plu.Inventory;
                    Add(&ApplVar.PluInventory,&ApplVar.Entry);
                    //if (!ApplVar.FTrain)
                        WritePluInventory();
                    Appl_ProgLine = 2;
                    memset(ProgLineMes,' ',sizeof(ProgLineMes));
                    memset(ProgLine1Mes,' ',sizeof(ProgLine1Mes));
                    ProgPluStock();
                }
                return;
            }
        }
        else
            Appl_ProgLine = 4;
    case 4:     //ccr2017-09-14 REMOVE STOCK */
        if (ApplVar.AP.Plu.InvSize)
        {
            Appl_MaxEntry = ApplVar.AP.Plu.InvSize*2+1;
            memset(sBuf,0,sizeof(BCD));
            if (GetOpt(48, sBuf, ApplVar.AP.Plu.InvSize))
            {
                if (Appl_EntryCounter)
                {
                    ApplVar.PluInventory=ApplVar.Plu.Inventory;
                    Subtract(&ApplVar.PluInventory,&ApplVar.Entry);
                    //if (!ApplVar.FTrain)
                        WritePluInventory();
                    Appl_ProgLine = 2;
                    memset(ProgLineMes,' ',sizeof(ProgLineMes));
                    memset(ProgLine1Mes,' ',sizeof(ProgLine1Mes));
                    ProgPluStock();
                }
                return;
            }
        }
    default:
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;//�ظ���ǰPLU������
        break;
    }
}


void ProgDept()
{
    //ccr2014-07-26>>>>>>>�жϳ�����ӡ��
    struct PRINTER *SetKP;
    unsigned int i;
    //<<<<<<<
    if (Appl_ProgNumber >= ApplVar.AP.Dept.Number)
    {
        if (ApplVar.AP.Dept.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            Appl_ProgNumber = -1;
            Appl_ProgLine = 0;
        }
        return;
    }
    ApplVar.DeptNumber = Appl_ProgNumber;
    ReadDept();
    switch (Appl_ProgLine)
    {
    case 1:
        break;
    case 2:     /* dept name */
        SetInputMode('a');
        Appl_MaxEntry = ApplVar.AP.Dept.CapSize;
        GetOpt(0, ApplVar.Dept.Name, ApplVar.AP.Dept.CapSize);
        break;
    case 3:     /* ApplVar.Dept price */
        SetInputMode('9');
        Appl_MaxEntry = 10;
        GetOpt(8, ApplVar.Dept.Price, ApplVar.AP.Dept.PriceSize);
        break;
    case 4:     /* ApplVar.Dept price */
        Appl_MaxEntry = 10;
        GetOpt(14, ApplVar.Dept.PriceMax, ApplVar.AP.Dept.PriMaxSize);
        break;
    case 5:     /* tax */
//ccr070723>>>>>>>>>>
        Appl_MaxEntry = ApplVar.AP.Tax.Number;
        GetOpt(46, &ApplVar.Dept.Tax, ApplVar.AP.Tax.Number);
        break;
// <<<<<<<<<<<<<<<<<<<

    case 6:     /*    group     */
        Appl_MaxEntry = 3;
        Appl_BitNumber = 0;
        GetOpt(2, &ApplVar.Dept.Group, ApplVar.AP.Group.Number);
        break;
    case 7:  //���ó�����ӡ��(1-8)
    case 8:
    case 9:
    case 10:
    case 11:
    case 12:
    case 13:
    case 14:
#if defined(CASE_EURO) //ccr2017-09-14>>>>>>KITCHEN PRINT 0-5 (0 = NO)>>>>>
        Appl_ProgLine=14;
        Appl_MaxEntry = 1;
        Appl_BitNumber = 0;


        //memset(ProgLineMes,' ',DISLEN+1);
        CopyFrStr(ProgLineMes+SETUPMARIN,Prompt.Caption[ItemPrompt51]);

        if (Appl_EntryCounter)
        {
            i = Appl_NumberEntry;
            if (i>KPRNMAX)
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                break;
            }
            else if (i)
                ApplVar.Dept.Kp=(1<<(i-1));
            else
                ApplVar.Dept.Kp=0;
        }
        if (ApplVar.Dept.Kp)
        {
            for (i=0;i<KPRNMAX;i++)
            {
                if (ApplVar.Dept.Kp & (1<<i))
                {
                    i++;
                    break;
                }
            }
        }
        else
            i=0;
#if (DISP2LINES)
        //memset(ProgLine1Mes,' ',DISLEN+1);
        WORDtoASC(ProgLine1Mes+DISLEN-1,i);
#else
        WORDtoASC(ProgLineMes+DISLEN-1,i);
#endif
        break;
#else
        //ccr2014-07-26>>>>>>>>>>>
        i = Appl_ProgLine-7;
        SetKP = (struct PRINTER *) &KPSTART;
        SetKP += i;
        while (i<KPRNMAX)
        {
            if (SetKP->type & 0x0f)
                break;
            else
            {//������ӡ��������
                i++;
                SetKP++;
            }
        }
        if (i<KPRNMAX)
        {
            Appl_ProgLine = i + 7;
            Appl_MaxEntry = 0;
            Appl_EntryCounter = 0;
            CheckBitValue(ItemPrompt51,&ApplVar.Dept.Kp,1+(Appl_ProgLine-7)+0x80,0);
            break;
        } else
            Appl_ProgLine = 15;
#endif//ccr2017-09-14<<<<<KITCHEN PRINT 0-5 (0 = NO)<<<<<<

    case 15:     /* options */
#if defined(CASE_EURO) //ccr2017-09-14>>>>>>KITCHEN PRINT 0-5 (0 = NO)
       Appl_ProgLine = 21;
#else
       Appl_ProgLine = 16;

#if ((DISP2LINES)||DD_LCD_1601==1)
    case 16:
#if defined(CASE_EURO)
        Appl_ProgLine = 17;
#else
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        CheckBitValue(ItemPrompt79,&ApplVar.Dept.Options,1+(Appl_ProgLine-16+1),0);
        break;
#endif
    case 17:
    case 18:
    case 19:
    case 20:
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        CheckBitValue(Appl_ProgLine-17+ItemPrompt80,&ApplVar.Dept.Options,1+(Appl_ProgLine-17+4),0);
        break;
#else
    case 16:
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        CheckBitValue(ItemPrompt50,&ApplVar.Dept.Options,1+(Appl_ProgLine-16+1)+0x80,0);
        break;
    case 17:
    case 18:
    case 19:
    case 20:
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        CheckBitValue(ItemPrompt50,&ApplVar.Dept.Options,1+(Appl_ProgLine-17+4)+0x80,0);
        break;
#endif
#endif
    case 21://ccr2017-08-02 set active flag>>>>
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        CheckBitValue(ItemPrompt115,(char*)&ApplVar.Dept.Print,8,YN);
        break;//ccr2017-08-02<<<<<<<<<<<<<<<<

//	case 9:     /* print */
//		Appl_MaxEntry = 8;
//	    if (GetOpt(3, &ApplVar.Dept.Print, 8))
//		break;
    default:
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;//�ظ���ǰDepart������
        break;
    }
    if (Appl_ProgStart!=2)//ccr2017-05-10
        WriteDept();
}


void ProgGroup()
{
    WORD tmpW;

    if (Appl_ProgNumber >= ApplVar.AP.Group.Number)
    {
        if (ApplVar.AP.Group.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            Appl_ProgNumber = -1;
            Appl_ProgLine = 0;
        }
        return;
    }
    ApplVar.GroupNumber = Appl_ProgNumber;
    ReadGroup();
    switch (Appl_ProgLine)
    {
    case 1:
        break;
    case 2:     /* group name */
        SetInputMode('a');
        Appl_MaxEntry = ApplVar.AP.Group.CapSize;
        GetOpt(0, ApplVar.Group.Name, ApplVar.AP.Group.CapSize);
        break;
    case 3:     /* Family now used for maxentry */
        SetInputMode('9');
        Appl_MaxEntry = 3;
        tmpW = ApplVar.Group.Family;

        if (GetOpt(30, &tmpW, 99))
        {
            ApplVar.Group.Family = tmpW;
            break;
        }

    default:
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        break;
    }
    if (Appl_ProgStart!=2)//ccr2017-05-10
        WriteGroup();
}


void ProgTend()
{
    if (Appl_ProgNumber >= ApplVar.AP.Tend.Number)
    {
        if (ApplVar.AP.Tend.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            Appl_ProgNumber = -1;
            Appl_ProgLine = 0;
        }
        return;
    }
    ApplVar.TendNumber = Appl_ProgNumber;
    ReadTender();
    switch (Appl_ProgLine)
    {
    case 1:
        break;
    case 2:     /* tendering name */
        Appl_BitNumber = 0;
        Appl_MaxEntry = ApplVar.AP.Tend.CapSize;
        SetInputMode('a');
        GetOpt(0, ApplVar.Tend.Name, ApplVar.AP.Tend.CapSize);
        break;
    case 3:     /* options */
    case 4:     /* options */
    case 5:     /* options */
    case 6:     /* options */
    case 7:     /* options */
        SetInputMode('9');
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;

#if ((DISP2LINES)||DD_LCD_1601==1)
        CheckBitValue(Appl_ProgLine-3+ItemPrompt87,&ApplVar.Tend.Options,1+(Appl_ProgLine-3),0);
#else
        CheckBitValue(ItemPrompt50,&ApplVar.Tend.Options,1+(Appl_ProgLine-3)+0x80,0);
#endif

        break;
//	case 4:     /* print */
//		Appl_MaxEntry = 8;
//	    if (GetOpt(3, &ApplVar.Tend.Print, 8))
//		break;
    case 8:     /* Drawer */
        Appl_MaxEntry = 8;
        GetOpt(21, &ApplVar.Tend.Drawer, ApplVar.AP.Draw.Number);
        break;
    case 9:     /* Over */
        Appl_MaxEntry = 8;
        GetOpt(22, &ApplVar.Tend.Over, ApplVar.AP.Draw.Number);
        break;
    default:
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        break;
    }
    if (Appl_ProgStart!=2)//ccr2017-05-10
        WriteTender();
}


void ProgPoRa()
{
    if (Appl_ProgNumber >= ApplVar.AP.PoRa.Number)
    {
        if (ApplVar.AP.PoRa.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            Appl_ProgNumber = -1;
            Appl_ProgLine = 0;
        }
        return;
    }
    ApplVar.PoRaNumber = Appl_ProgNumber;
    ReadPoRa();
    switch (Appl_ProgLine)
    {
    case 1:
        break;
    case 2:     /* pora name */
        Appl_MaxEntry = ApplVar.AP.PoRa.CapSize;
        SetInputMode('a');

        Appl_BitNumber = 0;
        GetOpt(0, ApplVar.PoRa.Name, ApplVar.AP.PoRa.CapSize);
        break;
    case 3:     /* options */
    case 4:     /* options */
    case 5:     /* options */
    case 6:     /* options */
        SetInputMode('9');
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;

#if((DISP2LINES)||DD_LCD_1601==1)
        CheckBitValue(Appl_ProgLine-3+ItemPrompt92,&ApplVar.PoRa.Options,1+(Appl_ProgLine-3),0);
#else
        CheckBitValue(ItemPrompt50,&ApplVar.PoRa.Options,1+(Appl_ProgLine-3)+0x80,0);
#endif

        break;
//	case 4:     /* print */
//		Appl_MaxEntry = 8;
//	    if (GetOpt(3, &ApplVar.PoRa.Print, 8))
//			break;
    case 7:     /* Drawer 1 */
        Appl_MaxEntry = 8;
        GetOpt(21, &ApplVar.PoRa.Drawer, ApplVar.AP.Draw.Number);
        break;
    default:
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        break;
    }
    if (Appl_ProgStart!=2)//ccr2017-05-10
        WritePoRa();
}


void ProgCorrec()
{
    if (Appl_ProgNumber >= ApplVar.AP.Correc.Number)
    {
        if (ApplVar.AP.Correc.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            Appl_ProgNumber = -1;
            Appl_ProgLine = 0;
        }
        return;
    }
    ApplVar.CorrecNumber = Appl_ProgNumber;
    ReadCorrec();
    switch (Appl_ProgLine)
    {
    case 1:
        break;
    case 2:     /* name */
        Appl_MaxEntry = ApplVar.AP.Correc.CapSize;
        SetInputMode('a');
        Appl_BitNumber = 0;
        GetOpt(0, ApplVar.Correc.Name, ApplVar.AP.Correc.CapSize);
        break;
//	case 3:     /* options */
/*		Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        if (!Appl_BitNumber)
            Appl_BitNumber = ApplVar.Correc.Options+1;
        if (Appl_BitNumber > 4 )
            Appl_BitNumber = 1;
        ApplVar.Correc.Options = Appl_BitNumber - 1;
        CopyFrStr(ProgLineMes , Prompt.LineCap[Line_TYPE]);
        CopyFrStr(ProgLineMes+ DISLEN - 5,Prompt.Caption[ItemPromptAppl_BitNumber - 1 + 80]);
        break;*/
//	case 4:     /* print */
//		Appl_MaxEntry = 8;
//	    if (GetOpt(3, &ApplVar.Correc.Print, 8))
//		break;
    default:
        SetInputMode('9');
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        break;
    }
    if (Appl_ProgStart!=2)//ccr2017-05-10
        WriteCorrec();
}

void ProgDisc()
{
    if (Appl_ProgNumber >= ApplVar.AP.Disc.Number)
    {
        if (ApplVar.AP.Disc.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            Appl_ProgNumber = -1;
            Appl_ProgLine = 0;
        }
        return;
    }
    ApplVar.DiscNumber = Appl_ProgNumber;
    ReadDisc();
    switch (Appl_ProgLine)
    {
    case 1:
        break;
    case 2:     /* name */
        SetInputMode('a');
        Appl_MaxEntry = ApplVar.AP.Disc.CapSize;
        if (GetOpt(0, ApplVar.Disc.Name, ApplVar.AP.Disc.CapSize))
            break;
    case 3:
        SetInputMode('9');
        Appl_MaxEntry = 8;
        if (BIT(ApplVar.Disc.Options, BIT0))    /* amount ? */
            GetOpt(13, ApplVar.Disc.Fixed, sizeof(ApplVar.Disc.Fixed));
        else
            GetOpt(15, ApplVar.Disc.Fixed, sizeof(ApplVar.Disc.Fixed));
        break;
    case 4: /* max */
        Appl_BitNumber = 0;
        Appl_MaxEntry = 8;
        if (BIT(ApplVar.Disc.Options, BIT0))    /* amount ? */
            GetOpt(14, ApplVar.Disc.Max, sizeof(ApplVar.Disc.Max));
        else
            GetOpt(16, ApplVar.Disc.Max, sizeof(ApplVar.Disc.Max));
        break;
    case 5:     /* options */
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        if (!Appl_BitNumber)
            Appl_BitNumber = (ApplVar.Disc.Options & 0x3)+1;
        if (Appl_BitNumber > 3 )
            Appl_BitNumber = 1;
        ApplVar.Disc.Options &= 0xfc;
        ApplVar.Disc.Options |= (Appl_BitNumber - 1);
        CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[Line_TYPE]);

#if (DISP2LINES)
        CopyFrStr(ProgLine1Mes+ DISLEN - (CAPWIDTH-1),Prompt.Caption[Appl_BitNumber - 1 + 52]);
#else
        CopyFrStr(ProgLineMes+ DISLEN - 6,Prompt.Caption[Appl_BitNumber - 1 + 52]);
#endif

        break;
    case 6:
/*		Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        if (!Appl_BitNumber)
            Appl_BitNumber = ((ApplVar.Disc.Options>>2) & 0x07)+1;
        if (Appl_BitNumber > 5)
            Appl_BitNumber = 5;
        ApplVar.Disc.Options &= 0xc3;
        ApplVar.Disc.Options |= ((Appl_BitNumber - 1)<<2);
        CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[Line_TYPE]);
        CopyFrStr(ProgLineMes+ DISLEN - 6,Prompt.Caption[ItemPromptAppl_BitNumber - 1 + 87]);
        break;*/
        Appl_ProgLine = 7;
    case 7:
    case 8:
    case 9:
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;

#if((DISP2LINES) ||DD_LCD_1601==1)
        CheckBitValue(Appl_ProgLine-7+ItemPrompt96,&ApplVar.Disc.Options,1+(Appl_ProgLine- 7 + 5),0);
#else
        CheckBitValue(ItemPrompt50,&ApplVar.Disc.Options,1+(Appl_ProgLine- 7 + 5)+0x80,0);
#endif

//ccr090108>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
        if (BIT(ApplVar.Disc.Options,BIT2))
        {// �ֽ��ۿ۽�ֹ�����ۿ� //
            RESETBIT(ApplVar.Disc.Options,BIT6+BIT7);
        }
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

        break;
//	case 6:     /* print */
//		Appl_MaxEntry = 8;
//	    if (GetOpt(3, &ApplVar.Disc.Print, 8))
//		break;
    case 10:     /* tax */
//ccr070723>>>>>>>>>>
        Appl_MaxEntry = ApplVar.AP.Tax.Number;
        GetOpt(46, &ApplVar.Disc.Tax, ApplVar.AP.Tax.Number);
        break;
//<<<<<<<<<<<<<<<<<<<
    default:
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        break;
    }
    if (Appl_ProgStart!=2)//ccr2017-05-10
        WriteDisc();
}



void ProgCurr()
{
    if (Appl_ProgNumber >= ApplVar.AP.Curr.Number)
    {
        if (ApplVar.AP.Curr.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            Appl_ProgNumber = -1;
            Appl_ProgLine = 0;
        }
        return;
    }
    ApplVar.CurrNumber = Appl_ProgNumber;
    ReadCurr();

    switch (Appl_ProgLine)
    {
    case 1:
        break;
    case 2:     /* name */
        SetInputMode('a');
        Appl_MaxEntry = ApplVar.AP.Curr.CapSize;
        if (GetOpt(0, ApplVar.Curr.Name, ApplVar.AP.Curr.CapSize))
            break;
    case 3:
        SetInputMode('9');
        Appl_MaxEntry = 8;
        GetOpt(18, ApplVar.Curr.BuyRate, sizeof(ApplVar.Curr.BuyRate));
        break;
    case 4:
        Appl_BitNumber = 0;
        Appl_MaxEntry = 8;
        GetOpt(19, ApplVar.Curr.SellRate, sizeof(ApplVar.Curr.SellRate));
        break;
    case 5:     /* options */
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
#if((DISP2LINES)||DD_LCD_1601==1)
        CheckBitValue(ItemPrompt99,&ApplVar.Curr.Options,1+(Appl_ProgLine- 4),0);
#else
        CheckBitValue(ItemPrompt50,&ApplVar.Curr.Options,1+(Appl_ProgLine- 4),0);
#endif
        break;
    case 6:
        Appl_MaxEntry = 8;
        GetOpt(21, &ApplVar.Curr.Drawer, ApplVar.AP.Draw.Number);
        break;
    case 7:
        Appl_MaxEntry = 8;
        GetOpt(26, &ApplVar.Curr.Prefix1, 255);
        break;
    case 8:
        Appl_MaxEntry = 8;
        GetOpt(27, &ApplVar.Curr.Prefix2, 255);
        break;
    default:
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        break;
    }
    if (Appl_ProgStart!=2)//ccr2017-05-10
        WriteCurr();
}

void ProgDraw()
{
    if (Appl_ProgNumber >= ApplVar.AP.Draw.Number)
    {
        if (ApplVar.AP.Draw.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            Appl_ProgNumber = -1;
            Appl_ProgLine = 0;
        }
        return;
    }
    ApplVar.DrawNumber = Appl_ProgNumber;
    ReadDrawer();
    switch (Appl_ProgLine)
    {
    case 1:
        break;
    case 2:     /* name */
        Appl_BitNumber = 0;
        SetInputMode('a');
        Appl_MaxEntry = ApplVar.AP.Draw.CapSize;
        if (GetOpt(0, ApplVar.Draw.Name, ApplVar.AP.Draw.CapSize))
            break;
    case 3:     /* options */
//	    case 4:     /* options */
        SetInputMode('9');
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
#if((DISP2LINES)||DD_LCD_1601==1)
        CheckBitValue(ItemPrompt101,&ApplVar.Draw.Options,2,0);
#else
        CheckBitValue(ItemPrompt55,&ApplVar.Draw.Options,2,0);
#endif
        break;
    default:
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        break;
    }
    if (Appl_ProgStart!=2)//ccr2017-05-10
        WriteDrawer();
}


void ProgPbF()
{
    if (!ApplVar.AP.Pb.NumberOfPb || Appl_ProgNumber >= ApplVar.AP.Pb.Number)
    {
        if (ApplVar.AP.Pb.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            Appl_ProgNumber = -1;
            Appl_ProgLine = 0;
        }
        return;
    }
    ApplVar.PbFNumber = Appl_ProgNumber;
    ReadPbF();
    switch (Appl_ProgLine)
    {
    case 1:
        break;
    case 2:     /* name */
        SetInputMode('a');
        Appl_MaxEntry = 32;
        if (GetOpt(0, ApplVar.PbF.Name, ApplVar.AP.Pb.CapSize))
            break;
    case 3:     /* options */
        SetInputMode('9');
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        if (!Appl_BitNumber)
            Appl_BitNumber = ApplVar.PbF.Options+1;
        if (Appl_BitNumber > 11)
            Appl_BitNumber = 1;
        ApplVar.PbF.Options = Appl_BitNumber - 1;
        CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[Line_TYPE]);
#if (DISP2LINES)
        CopyFrStr(ProgLine1Mes+ DISLEN - (CAPWIDTH - 1),Prompt.Caption[ApplVar.PbF.Options + 55]);
#else
        CopyFrStr(ProgLineMes+ DISLEN - 6,Prompt.Caption[ItemPromptApplVar.PbF.Options + 55]);
#endif
        break;
//	    case 4:     /* print */
//			Appl_MaxEntry = 8;
//			if (GetOpt(3, &ApplVar.PbF.Print, 8))
//			    break;
    default:
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        break;
    }
    if (Appl_ProgStart!=2)//ccr2017-05-10
        WritePbF();
}

void ProgPbInfo()
{
    if (Appl_ProgNumber > ApplVar.AP.Pb.NumberOfPb || !ApplVar.AP.Pb.Text)
    {
        if (ApplVar.AP.Pb.NumberOfPb==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            Appl_ProgNumber = -1;
            Appl_ProgLine = 0;
        }
        return;
    }
    ApplVar.PbNumber = Appl_ProgNumber + 1;

    if (!ApplVar.AP.Pb.Text)
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
        return;
    }
    PbTotal(ApplVar.PbNumber, 0);     /* read */
    switch (Appl_ProgLine)
    {
    case 1:
        break;
    case 2:     /* ApplVar.PB text */
        SetInputMode('a');
        Appl_MaxEntry = ApplVar.AP.Pb.Text * 2;
        if (GetOpt(0, ApplVar.PB.Text, ApplVar.AP.Pb.Text))
            break;
    case 3:
        SetInputMode('9');
        Appl_MaxEntry = 16;
        if (!BIT(PBINFO, BIT2) && !(PBPRINT & 0x80)
            && (ApplVar.AP.Pb.Random & 0x0f))  /* random number ? */
        {
            if (GetOpt(31, ApplVar.PB.Random, ApplVar.AP.Pb.Random & 0x0f))
                break;
        }
    default:
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        break;
    }
    PbTotal(ApplVar.PbNumber, 3);     /* write text + Random */
}

void ProgTax()
{
    BYTE invF=0,setOP=0;
    int i;
#if defined(CASE_EURO) //!!! GREECE_ONLY !!!//ccr2017-09-13>>>>>VAT E -> Hidden>>>>
    static struct TAXRECORD sTAX;

    if (Appl_ProgNumber+1 >= ApplVar.AP.Tax.Number)
#else
    if (Appl_ProgNumber >= ApplVar.AP.Tax.Number)
#endif//ccr2017-09-13<<<<<<<VAT E -> Hidden<<<<<<<
    {
        if (ApplVar.AP.Tax.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            Appl_ProgNumber = -1;
            Appl_ProgLine = 0;
        }
        return;
    }
    ApplVar.TaxNumber = Appl_ProgNumber;
    ReadTax();
#if defined(CASE_EURO) //!!! GREECE_ONLY !!!//ccr2017-09-13>>>>>SAVE CHANGES>>>>
    if (Appl_ProgLine<3)
        sTAX=ApplVar.Tax;
//ccr2017-12-21    else
//ccr2017-12-21        ApplVar.Tax=sTAX;
#endif//ccr2017-09-13<<<SAVE CHANGES<<<<<<
    switch (Appl_ProgLine)
    {
    case 1:
        break;
    case 2:     /* name */
#if defined(CASE_GREECE)//ccr2018-01-12����ʾ����
        Appl_ProgLine=3;
        Appl_EntryCounter = 0;//ccr070614 Replace Tax.Name not allowed
#else
        SetInputMode('a');
//        Appl_EntryCounter = 0;//ccr070614 Replace Tax.Name not allowed
//        Appl_MaxEntry =0; //ccr2017-09-12��ֹ�޸����� ApplVar.AP.Tax.CapSize;
        Appl_MaxEntry =ApplVar.AP.Tax.CapSize;
        if (GetOpt(0, ApplVar.Tax.Name, ApplVar.AP.Tax.CapSize))
            break;
#endif
    case 3:
        SetInputMode('9');
        Appl_BitNumber = 0;
        Appl_MaxEntry = 5;

        if (Appl_EntryCounter>0)
        {
            if (ApplVar.FisNumber.TotalTaxChangeNum>=FTAXCHGMAX)//˰���޸Ĵ�������
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI117);//����������������
                Appl_EntryCounter = 0;
            }
#if defined(CASE_EURO) //!!! GREECE_ONLY !!!//ccr2017-12-21>>>>>>>>>>>>>>
            else
            {
                if (WaitForYesNo(MsgSaveChanges,0,1,true)=='Y')
                    ApplVar.FMPullOut[NEWTAX_FLAG]|=0x09;//���������޸ĵı�־,���ݽ������ļ�
                else
                {
                    ApplVar.FMPullOut[NEWTAX_FLAG]&=0xf0;
                    Appl_EntryCounter = 0;
                }
            }
#else
            else
                ApplVar.FMPullOut[NEWTAX_FLAG]=0x69;
#endif//ccr2017-12-21<<<<<<<<<<<<
        }

        GetOpt(17, ApplVar.Tax.Rate, sizeof(ApplVar.Tax.Rate));
        //ccr2018-03-15>>>>>>>��ֹ�ظ�˰��>>>>>>>>>>
        for (i=0;i<ApplVar.AP.Tax.Number;i++)
        {
           if (i!=ApplVar.TaxNumber && CopyOfTax[i]==CWORD(ApplVar.Tax.Rate[0]))
           {
              ApplVar.ErrorNumber=ERROR_ID(CWXXI125);//"RATA DUPLICATION"
              CWORD(ApplVar.Tax.Rate[0])=CWORD(sTAX.Rate[0]);
              ClearEntry();
              GetOpt(17, ApplVar.Tax.Rate, sizeof(ApplVar.Tax.Rate));
              break;
           }
        }
        //ccr2018-03-15<<<<<<<<<<<<<<<<<<<<<<<<<<<
        break;
#if !defined(CASE_GREECE)//ccr2017-09-13 only vat percentage can be changed and not caption
    case 4:   /*    options.BIT0:=1,VAT����˰;=0:(Add on)����˰(Ӫҵ˰) */
        invF = YN;//ccr2014-07-22
        setOP = 1;
        break;
    case 5:     /*    options.BIT1:��ӡ˰����,ֻ��VAT��˰ģʽ������     */
        setOP = 1;
        if (!BIT(ApplVar.Tax.Options,BIT0))//only for VAT type
            Appl_ProgLine=7;
        break;
    case 6:     /*    options.BIT2:��ӡ0˰��     */
        setOP = 1;
        if (!BIT(ApplVar.Tax.Options,BIT1))//only for VAT type
            Appl_ProgLine=7;
        break;
    case 7:     /*    options.BIT3:ΪGST��˰    */
#if (0)  //ccr2017-05-04
        setOP = 1;
        break;
#else
        Appl_ProgLine=8;
#endif
    case 8:     /*    options.BIT4:��ӡ˰��     */
        //ccr2014-07-22>>>>>>>>>>
        if (BIT(ApplVar.Tax.Options,BIT1 + BIT0)==(BIT1 + BIT0))
        {//only for VAT type
            setOP = 1;
            break;
        }//<<<<<<<<<<<<<<<<
#endif
    default:
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        break;
    }
#if defined(CASE_EURO) //!!! GREECE_ONLY !!!//ccr2017-12-21>>>>
    if (Appl_ProgStart!=2 && (ApplVar.FMPullOut[NEWTAX_FLAG] & 0x0f)==0x09)//�����޸�
    {
        if (CWORD(sTAX.Rate[0])!=CWORD(ApplVar.Tax.Rate[0]))
        {
            CWORD(sTAX.Rate[0])=CWORD(ApplVar.Tax.Rate[0]);
            CopyOfTax[ApplVar.TaxNumber]=CWORD(ApplVar.Tax.Rate[0]);
            WriteTax();
            ApplVar.FMPullOut[NEWTAX_FLAG] |= 0x60;   //��ʾ˰���й��޸�
        }
        else
            ApplVar.FMPullOut[NEWTAX_FLAG] &= 0xf0;   //�����ǰ˰���޸ı��
    }
#if !defined(CASE_GREECE)
    if (setOP)
    {
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
#if ((DISP2LINES)||DD_LCD_1601==1 )
        CheckBitValue(Appl_ProgLine-4+ItemPrompt102,&ApplVar.Tax.Options,1+(Appl_ProgLine-4),invF);
#else
        CheckBitValue(ItemPrompt50,&ApplVar.Tax.Options,1+(Appl_ProgLine-4)+0x80,invF);
#endif
    }
#endif
#else
    if (Appl_ProgStart!=2)//ccr2017-05-10
        WriteTax();
#endif//ccr2017-12-21<<<<<<
}


void ProgClerk()
{
    WORD saveClerk;     //cc 20071023
    BYTE saveOption;

    if (Appl_ProgNumber >= ApplVar.AP.Clerk.Number)
    {
        if (ApplVar.AP.Clerk.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            Appl_ProgNumber = -1;
            Appl_ProgLine = 0;
        }
        return;
    }
    saveClerk = ApplVar.ClerkNumber;    //cc 20071023
    saveOption = ApplVar.Clerk.Options & BIT7;
    ApplVar.ClerkNumber = Appl_ProgNumber + 1;
    ReadClerk();
    switch (Appl_ProgLine)
    {
    case 1:
        break;
    case 2:     /* name */
        Appl_MaxEntry = ApplVar.AP.Clerk.CapSize;
        SetInputMode('a');
        Appl_BitNumber = 0;
        if (GetOpt(0, ApplVar.Clerk.Name, ApplVar.AP.Clerk.CapSize))
            break;
    case 3:
        SetInputMode('9');
        if (BIT(CLERKFIX,BIT5))
        {
            Appl_MaxEntry = sizeof(ApplVar.Clerk.Passwd) * 2;
//				SETBIT(ApplVar.ArrowsAlfa,INPUTPWD);
            Appl_BitNumber = 0;
            GetBCDValue(Line_PASSWORD,ApplVar.Clerk.Passwd,3,TRUE);
            break;
        } else
            Appl_ProgLine = 4;
    case 4:
    case 5:
    case 6:
    case 7:
    case 8:
    case 9:
    case 10:
#if !defined(CASE_GREECE) //ccr2018-03-15
    case 11:
#endif
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
#if ((DISP2LINES)||DD_LCD_1601==1 )
        CheckBitValue(Appl_ProgLine-4+ItemPrompt107,&ApplVar.Clerk.Options,1+(Appl_ProgLine-4),YN);
#else
        CheckBitValue(ItemPrompt50,&ApplVar.Clerk.Options,1+(Appl_ProgLine-4)+0x80,YN);
#endif
        break;
    default:
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        break;
    }
//ccr100330>>>>>>>>>>>>>
    if (ApplVar.ClerkNumber == saveClerk && (ApplVar.Clerk.Options & BIT7)!=saveOption)
    {// ��ֹ�ı䵱ǰ��¼���տ�Ա����ѵģʽ //

        if (MyFlags(ZREPORT))   /* z report taken ? */
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI75);
            INVERTBIT(ApplVar.Clerk.Options,BIT7);
        } else
        {
            SetTrainMode();
        }
    }
    if (Appl_ProgStart!=2)//ccr2017-05-10
        WriteClerk();
    if (ApplVar.ClerkNumber != saveClerk)
    {
        ApplVar.ClerkNumber = saveClerk;
        ReadClerk();
    }
//<<<<<<<<<<<<<<<<<<<<<
}


void ProgSalPer()
{
    if (Appl_ProgNumber >= ApplVar.AP.SalPer.Number)
    {
        if (ApplVar.AP.SalPer.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            Appl_ProgNumber = -1;
            Appl_ProgLine = 0;
        }
        return;
    }
    ApplVar.SalPerNumber = Appl_ProgNumber + 1;
    ReadSalPer();
    switch (Appl_ProgLine)
    {
    case 1:
        break;
    case 2:     /* name */
        Appl_MaxEntry = ApplVar.AP.SalPer.CapSize;
        SetInputMode('a');
        if (GetOpt(0, ApplVar.SalPer.Name, ApplVar.AP.SalPer.CapSize))
            break;
    default:
        SetInputMode('9');
        Appl_ProgLine = 0;
        Appl_MaxEntry = 6;
        break;
    }
    if (Appl_ProgStart!=2)//ccr2017-05-10
        WriteSalPer();
}

void ProgZone()
{
    if (Appl_ProgNumber >= ApplVar.AP.Zone.Number)
    {
        if (ApplVar.AP.Zone.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            Appl_ProgNumber = -1;
            Appl_ProgLine = 0;
        }
        return;
    }
    if (Appl_ProgLine == 1)
        return;
    else if (Appl_ProgLine > 2)
    {
        Appl_ProgLine = 0;
    } else
        GetOpt(20, &ApplVar.AP.Zone.Start[Appl_ProgNumber], 2);
    Appl_MaxEntry = 6;
}

void ProgModi()
{
#if 1
    if (ApplVar.AP.Modi.Number==0)
        strcpy(ProgLineMes,Number0);
    else
        ProgCaptions(SETMODIF,ApplVar.AP.Modi.Number,ApplVar.AP.Modi.CapSize);
#else
    int sP,sLp,idx;

    if (Appl_ProgNumber >= ApplVar.AP.Modi.Number)
    {
        if (ApplVar.AP.Modi.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            SetInputMode('9');
            Appl_ProgNumber = -1;
            Appl_ProgLine = 0;
        }
        return;
    }

    if (Appl_ProgLine==1)
    {
        Appl_ProgLine = Appl_ProgNumber+2;
        SetInputMode('a');
        Appl_ProgNumber = 0;
    }

    if (Appl_ProgLine>=2 && Appl_ProgLine<=ApplVar.AP.Modi.Number+2)
    {
        Appl_MaxEntry = ApplVar.AP.Modi.CapSize;
        idx = Appl_ProgLine-2;

        ApplVar.ModiNumber = idx;
        ReadModi();

        if (Appl_EntryCounter)
        {
            sLp=GetCaption(ApplVar.Modi.Name, ApplVar.AP.Modi.CapSize);
            SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
            ApplVar.Modi.Name[sLp]=0;

            if (sLp==1 && ApplVar.Modi.Name[0]==' ')
                memset(ApplVar.Modi.Name,0, ApplVar.AP.Modi.CapSize);
            WriteModi();
        }

        sP = strlen(Prompt.LineCap[Line_CAPTION]);//lCAPWIDTH;
        CopyFrStr(ProgLineMes, Prompt.LineCap[Line_CAPTION]);
        sP += WORDtoASCL(ProgLineMes+sP,idx+1);
        ProgLineMes[sP++]=':';

        for (sLp=0;sLp<DISLEN;sLp++)
        {
#if (DISP2LINES)
            ProgLine1Mes[sLp] = ApplVar.Modi.Name[sLp];
#else
            ProgLineMes[sP++] = ApplVar.Modi.Name[sLp];
            if (sP>=DISLEN) break;
#endif
        }
    } else
    {
        SetInputMode('9');
        Appl_ProgLine = 0;
        Appl_ProgNumber = 0;
        Appl_MaxEntry = ApplVar.AP.Modi.CapSize;
    }
#endif
}

void ProgHeader()
{
    ProgCaptions(SETHEAD,8,PRTLEN);
}

void ProgTrailer()
{
#if 1
    ProgCaptions(SETTRAIL,6,PRTLEN);
#else
    int sP,sLp,idx;

    if (Appl_ProgNumber >= 6)
    {
        SetInputMode('9');
        Appl_ProgNumber = -1;
        Appl_ProgLine = 0;
        return;
    }
    if (Appl_ProgLine==1)
    {
        Appl_ProgLine = Appl_ProgNumber+2;
        SetInputMode('a');
        Appl_ProgNumber = 0;
    }

    if (Appl_ProgLine>=2 && Appl_ProgLine<=7)
    {
        Appl_MaxEntry = PRTLEN;
        idx = Appl_ProgLine-2;

        if (Appl_EntryCounter)
        {
            sLp=GetCaption(ApplVar.TXT.Trailer[idx], PRTLEN);
            SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
            ApplVar.TXT.Trailer[idx][sLp]=0;

            if (sLp==1 && ApplVar.TXT.Trailer[idx][0]==' ')
                memset(ApplVar.TXT.Trailer[idx],0, PRTLEN+1);
        }

        sP = strlen(Prompt.LineCap[Line_CAPTION]);//lCAPWIDTH;
        CopyFrStr(ProgLineMes, Prompt.LineCap[Line_CAPTION]);
        ProgLineMes[sP++] = idx+'1';
        ProgLineMes[sP++] = ':';

        for (sLp=0;sLp<DISLEN;sLp++)
        {
#if (DISP2LINES)
            ProgLine1Mes[sLp] = ApplVar.TXT.Trailer[idx][sLp];
#else
            ProgLineMes[sP++] = ApplVar.TXT.Trailer[idx][sLp];
            if (sP>=DISLEN) break;
#endif
        }
    } else
    {
        SetInputMode('9');
        Appl_ProgLine = 0;
        Appl_ProgNumber = 0;
        Appl_MaxEntry = PRTLEN;
    }
#endif
}

void ProgSlipHead()
{
#if (DD_SETSLIP)
    ProgCaptions(SETSHEAD,6,SHEADWIDTH);
#elif (0)
    int sP,sLp,idx;

    if (Appl_ProgNumber >= 6)
    {
        SetInputMode('9');
        Appl_ProgNumber = -1;
        Appl_ProgLine = 0;
        return;
    }
    if (Appl_ProgLine==1)
    {
        Appl_ProgLine = Appl_ProgNumber+2;
        SetInputMode('a');
        Appl_ProgNumber = 0;
    }

    if (Appl_ProgLine>=2 && Appl_ProgLine<=7)
    {
        Appl_MaxEntry = SHEADWIDTH;
        idx = Appl_ProgLine-2;

        if (Appl_EntryCounter)
        {
            sLp=GetCaption(ApplVar.TXT.SlipHeader[idx], SHEADWIDTH);
            SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
            ApplVar.TXT.SlipHeader[idx][sLp]=0;

            if (sLp==1 && ApplVar.TXT.SlipHeader[idx][0]==' ')
                memset(ApplVar.TXT.SlipHeader[idx],0, SHEADWIDTH+1);
        }

        sP = strlen(Prompt.LineCap[Line_CAPTION]);//lCAPWIDTH;
        CopyFrStr(ProgLineMes, Prompt.LineCap[Line_CAPTION]);
        ProgLineMes[sP++] = idx+'1';
        ProgLineMes[sP++] = ':';

        for (sLp=0;sLp<DISLEN;sLp++)
        {
#if (DISP2LINES)
            ProgLine1Mes[sLp] = ApplVar.TXT.SlipHeader[idx][sLp];
#else
            ProgLineMes[sP++] = ApplVar.TXT.SlipHeader[idx][sLp];
            if (sP>=DISLEN) break;
#endif
        }
    } else
    {
        SetInputMode('9');
        Appl_ProgLine = 0;
        Appl_ProgNumber = 0;
        Appl_MaxEntry = SHEADWIDTH;
    }
#endif
}

BYTE ProgSysFlagNew(BYTE y,WORD recNo)
{
#define  sDispBuf SysBuf
    BYTE BitV, i;
    WORD BitN;
    BYTE updownkey;
    short   sIdx;

    if (recNo<SYSUSED)
    {
        sIdx = SysFlagUsed[recNo].Index;

        if (SysFlagUsed[recNo].Bit)
        {//Ϊyes/noѡ����
            BitV = BIT0<<(SysFlagUsed[recNo].Bit-1);
            BitN = (ApplVar.AP.Flag[sIdx] & BitV);
            while (true)
            {
                if (BitN)
                {
                    i = 'y' ^ SysFlagUsed[recNo].Invert;
                    SETBIT(ApplVar.AP.Flag[sIdx],BitV);
                } else
                {
                    i = 'n' ^ SysFlagUsed[recNo].Invert;
                    RESETBIT(ApplVar.AP.Flag[sIdx], BitV);
                }
                memset(sDispBuf,' ',SCREENWD);
#if DISP2LINES
                PutsO((char*)SysFlagUsed[recNo].Name);
                if (i == 'y')
                    strcpy(sDispBuf+SCREENWD-3,Prompt.LineCap[Line_YES]);
                else
                    strcpy(sDispBuf+SCREENWD-3,Prompt.LineCap[Line_NO]);
                Puts1(sDispBuf);
#else
                CopyFrStr(sDispBuf,SysFlagUsed[recNo].Name);
                if (i == 'y')
                    strcpy(sDispBuf+SCREENWD-3,Prompt.LineCap[Line_YES]);
                else
                    strcpy(sDispBuf+SCREENWD-3,Prompt.LineCap[Line_NO]);
                DispStrXY(sDispBuf, 0 ,y);
#endif
                InitSysFlag();
                Save_Config(true);

                WAIT_INPUT(updownkey);
                if (updownkey==UPKey || updownkey==DOWNKey)//ccr2017-12-05
                    BitN = !BitN;
                else if (updownkey==ENTERKey)
                    return DOWNKey;
                else if (updownkey==CLEARKey)//ccr2017-09-11��CLEAR�˳�����
                    return EXITKey;
                else
                    return updownkey;
            }

        } else
        {//Ϊ��ֵ���
            if (sIdx==FLAGRECEIPTMAX)
            {
                Appl_MaxEntry=9;
                Appl_NumberEntry=ReceiptMAX;
            } else
            {
                Appl_MaxEntry=3;
                if (sIdx==62)//�����վݴ�����Աȶ�
                {
                    //��4λΪ��־,��4Ϊ��ֵ  //
                    i = ApplVar.AP.Flag[sIdx] & 0xf0;   //���ݱ�־λ
                    ApplVar.AP.Flag[sIdx] &= 0x0f;      //Ϊ����ʾ��ֵ�����������λ
                } else
                    i = 0;
                Appl_NumberEntry=ApplVar.AP.Flag[sIdx];
            }
            //ccr2018-01-16 ��ʾС��.00>>>>>>>>>>>>>>
#if DISP2LINES
            PutsO((char*)SysFlagUsed[recNo].Name);
#endif
            if (sIdx==FLAGRECEIPTMAX)
            {//
                ApplVar.Amt=ZERO;
                ULongToBCDValue(ApplVar.Amt.Value+1,Appl_NumberEntry);
#if DISP2LINES
                Puts1(DispAmtStr(0,&ApplVar.Amt,DISLEN));
#else
                DispStrXY(DispAmtStr((char*)SysFlagUsed[recNo].Name,&ApplVar.Amt,DISLEN),0,y);
#endif
            }
            else//ccr2018-01-16<<<<<<<<<<<<
#if DISP2LINES
                DisplayDecXY(Appl_NumberEntry,0,1);//�Ӵ���ʾ��Ŀ����ȥ������
            updownkey = InputULong(0,SysFlagUsed[recNo].Max,1,sIdx==FLAGRECEIPTMAX,false);
#else
                DisplayDecXY(Appl_NumberEntry,(char*)SysFlagUsed[recNo].Name,y);//�Ӵ���ʾ��Ŀ����ȥ������
            updownkey = InputULong((char*)SysFlagUsed[recNo].Name,SysFlagUsed[recNo].Max,y,sIdx==FLAGRECEIPTMAX,false);
#endif
            if (sIdx==FLAGRECEIPTMAX)
            {
                //ccr2018-01-16 ��ʾС��.00>>>>>>>>>>>>>>
                ApplVar.Amt=ZERO;
                ULongToBCDValue(ApplVar.Amt.Value+1,Appl_NumberEntry);
#if DISP2LINES
                Puts1(DispAmtStr(0,&ApplVar.Amt,DISLEN));
#else
                DispStrXY(DispAmtStr((char*)SysFlagUsed[recNo].Name,&ApplVar.Amt,DISLEN),0,y);
#endif
                //ccr2018-01-16<<<<<<<<<<<<<<<<<<<<<<<<<<<
                ReceiptMAX = Appl_NumberEntry;
#ifndef ReceiptMAX
                ApplVar.AP.Flag[57]=ReceiptMAX>>24;
                ApplVar.AP.Flag[56]=ReceiptMAX>>16;
                ApplVar.AP.Flag[55]=ReceiptMAX>>8;
                ApplVar.AP.Flag[54]=ReceiptMAX & 0xff;
#endif
            } else
                ApplVar.AP.Flag[sIdx] = Appl_NumberEntry | i;
            Save_Config(true);
            InitSysFlag();
            if (updownkey==ENTERKey)
                return DOWNKey;
            else
                return updownkey;
        }
    }
}

void ProgSysFlag()
{
    BYTE BitV, i;
    short   sIdx;
    long    sVal;

    if (Appl_ProgLine==1 || Appl_ProgLine>=SYSUSED+2)
        Appl_ProgLine = 2;
    if (Appl_ProgLine>=2 && Appl_ProgLine<SYSUSED+2)
    {
        sIdx = SysFlagUsed[Appl_ProgLine-2].Index;

#if((DISP2LINES) || DD_LCD_1601==1)
        CopyFrStr(ProgLineMes , SysFlagUsed[Appl_ProgLine-2].Name);
#else
        CopyFrStr(ProgLineMes , Prompt.Caption[ItemPrompt50]);//    SysOpt
        WORDtoASC(ProgLineMes+7,Appl_ProgLine-1);
        if (ProgLineMes[6]==' ')
            ProgLineMes[6] = '_';
#endif
        if (SysFlagUsed[Appl_ProgLine-2].Bit)
        {

            BitV = BIT0<<(SysFlagUsed[Appl_ProgLine-2].Bit-1);
            Appl_MaxEntry = 0;
            Appl_EntryCounter = 0;
            if (!Appl_BitNumber)
                Appl_BitNumber = ((ApplVar.AP.Flag[sIdx] & BitV)==0)+1;//ccr2017-07-31
            else
                SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ

            if (Appl_BitNumber > 2)
                Appl_BitNumber = 1;
            if (Appl_BitNumber ==2)
            {
#if (DISP2LINES)
                ProgLine1Mes[DISLEN-3] = 'N' ^ SysFlagUsed[Appl_ProgLine-2].Invert;
#else
                ProgLineMes[DISLEN-1] = 'n' ^ SysFlagUsed[Appl_ProgLine-2].Invert;
#endif
                if (Appl_ProgStart!=2)//ccr2017-07-31
                    ApplVar.AP.Flag[sIdx] |= BitV;
            } else
            {
#if (DISP2LINES)
                ProgLine1Mes[DISLEN-3] = 'Y' ^ SysFlagUsed[Appl_ProgLine-2].Invert;
#else
                ProgLineMes[DISLEN-1] = 'y' ^ SysFlagUsed[Appl_ProgLine-2].Invert;
#endif
                if (Appl_ProgStart!=2)//ccr2017-07-31
                    ApplVar.AP.Flag[sIdx] &= ~(BitV);
            }
#if (DISP2LINES)
            if (ProgLine1Mes[DISLEN-3] == 'N')
            {
                ProgLine1Mes[DISLEN-2] = 'o';
                ProgLine1Mes[DISLEN-1] = ' ';
            } else
            {
                ProgLine1Mes[DISLEN-2] = 'e';
                ProgLine1Mes[DISLEN-1] = 's';
            }
#endif
            SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ

        } else
        {
            Appl_BitNumber = 0;
            if (sIdx==FLAGRECEIPTMAX)
            {
                Appl_MaxEntry = 9;
                sVal = ReceiptMAX;
                i = 0;
            } else
            {
                Appl_MaxEntry = 3;
                if (sIdx==62)
                {               //��4λΪ��־,��4ΪΪ��ֵ  //
                    i = ApplVar.AP.Flag[sIdx] & 0xf0;
                    ApplVar.AP.Flag[sIdx] &= 0x0f;
                } else
                    i = 0;
                sVal = ApplVar.AP.Flag[sIdx];
            }
            if (Appl_EntryCounter)
            {
                if (SysFlagUsed[Appl_ProgLine-2].Max && Appl_NumberEntry>SysFlagUsed[Appl_ProgLine-2].Max)
                {
                    if (Appl_ProgStart!=2)//ccr2017-07-31
                        ApplVar.AP.Flag[sIdx] |= i;
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                    return;
                }
                SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
                if (sIdx==FLAGRECEIPTMAX)
                {
                    ReceiptMAX=Appl_NumberEntry;
#ifndef ReceiptMAX
                    ApplVar.AP.Flag[57]=ReceiptMAX>>24;
                    ApplVar.AP.Flag[56]=ReceiptMAX>>16;
                    ApplVar.AP.Flag[55]=ReceiptMAX>>8;
                    ApplVar.AP.Flag[54]=ReceiptMAX & 0xff;
#endif
                } else//   if (Appl_ProgStart!=2)//ccr2017-07-31
                    ApplVar.AP.Flag[sIdx] = Appl_NumberEntry;
            }
            //ccr2018-01-16>>�̶�Ϊ��λС��>>>>>>>>>>
            if (sIdx==FLAGRECEIPTMAX)
            {
                ApplVar.Entry=ZERO;
                ULongToBCDValue(ApplVar.Entry.Value+1,sVal);
                //ApplVar.Entry.Sign=2;
#if (DISP2LINES)
                memcpy(ProgLine1Mes,DispAmtStr(0,&ApplVar.Entry,DISLEN),DISLEN);
#else
                memcpy(ProgLineMes,DispAmtStr(0,&ApplVar.Entry,DISLEN),DISLEN);
#endif
            }
            else//ccr2018-01-16<<�̶�Ϊ��λС��<<<<<
            {
#if (DISP2LINES)
                ULongtoASC(ProgLine1Mes + DISLEN-1, sVal);
#else
                ULongtoASC(ProgLineMes + DISLEN-1, sVal);
#endif
            }
            //if (Appl_ProgStart!=2)//ccr2017-07-31
            ApplVar.AP.Flag[sIdx] |= i;
        }
    }

    if (Appl_ProgStart != 2)
    {
        InitSysFlag();
    }
}


void ProgSysMes()
{
    BYTE max=0;

    switch (Appl_ProgLine)
    {
    case 1:
        break;
    case 2:     /* name */
        SetInputMode('a');
        Appl_MaxEntry = 32;
        if (!(Appl_ProgType == SETFIXCAP || Appl_ProgType == SETERRMSG||Appl_ProgType == SETWEEKCAP||Appl_ProgType == SETMONTHCAP))
        {
            GetOpt(0, ApplVar.TXT.ReportType[Appl_ProgNumber], 16);
            max = 13;
        }
        if (Appl_ProgNumber > max)
        {
            Appl_ProgNumber = -1;
            Appl_ProgLine = 0;
        }
        Now.day--;  /* force new read of date and time incase */
        /* caption changed */
        break;
    default:
        SetInputMode('9');
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        break;
    }
}

void ProgReport()
{
    short i;

    if (Appl_ProgNumber > XZNUM-1)
    {
        Appl_ProgNumber = -1;
        Appl_ProgLine = 0;
        return;
    }
    i = XZTitle[Appl_ProgNumber].Index-1;

    switch (Appl_ProgLine)
    {
    case 1:
        break;
    case 2:     /* name */
        SetInputMode('a');

        Appl_MaxEntry = 32;
        GetOpt(0, ApplVar.AP.ReportList[i].Name, 16);
        Appl_BitNumber = 0;
        break;
//	case 3:
//		Appl_MaxEntry = 8;
//	    if (GetOpt(3, &ApplVar.AP.ReportList[i].PrintLayOut, 8))
//			break;
    case 3:     /* options */
//lyq delete 2003\10\27 start
//	case 4:     /* options */
//	case 5:     /* options */
//	case 6:     /* options */
//lyq delete 2003\10\27 end
        SetInputMode('9');
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
#if ((DISP2LINES)|| DD_LCD_1601==1)
        CheckBitValue(ItemPrompt101,&ApplVar.AP.ReportList[i].Options,1+(Appl_ProgLine-3),0);
#else
        CheckBitValue(ItemPrompt50,&ApplVar.AP.ReportList[i].Options,1+(Appl_ProgLine-3),0);
#endif
        break;
    case 4:    /* period */
        Appl_MaxEntry = 8;
        GetOpt(24, &ApplVar.AP.ReportList[i].Period, 3);
        break;
    case 5:     /* pointer type */
        Appl_MaxEntry = 8;
        GetOpt(25, &ApplVar.AP.ReportList[i].PointerType, 4);
        break;
    default:     /* link */
        if (Appl_ProgLine < (6+16))
            GetOpt(28, &ApplVar.AP.ReportList[i].Link[Appl_ProgLine - 6], REPORTTYPE_MAX+1);//9--6 lyq
        else
            Appl_ProgLine = 0;
        break;
    }
}
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
void ProgDate()
{
    switch (Appl_ProgLine)
    {
    case 1:
        SetDateFlg = 1;
        Appl_MaxEntry = 10;
        CheckTime(true | 0x80);
        MemSet(ProgLineMes, sizeof(ProgLineMes), ' ');
#if (DISP2LINES)
        memset(ProgLine1Mes,' ',sizeof(ProgLine1Mes));
//ccr2017-12-13        strcpy(ProgLine1Mes,EXITMESS);
#endif
        memcpy(ProgLineMes+SETUPMARIN,DateAsci+4, 10);
        if (!CheckPWD((char*)PWD4Technician))
            ApplVar.ErrorNumber=ERROR_ID(CWXXI36);
        else  if (!Bios_TestMAC())//ccr2017-12-13
            ApplVar.ErrorNumber=ERROR_ID(CWXXI04);
        break;
    case 2:         /* set date */
        if (!Bios_TestMAC())//ccr2017-12-13
            ApplVar.ErrorNumber=ERROR_ID(CWXXI04);
        else if (ApplVar.FisNumber.TotalDateChangeNum>=FDATECHGMAX)//ccr2017-08-08>>>>
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI117);//����������������
        }//ccr2017-08-08<<<<<<<<<
        else
        {
            if (Appl_EntryCounter>0)
            {
                if (MyFlags(ZREPORT))   /* z report taken ? */
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI13);
                } else
                {
                    Fiscal_AddDatetimeChg(0);
                    SetDateFlg = 2;
                    NewTimeDate(1);

                    Appl_ProgLine = 1;

                    if (!ApplVar.ErrorNumber)
                    {
                        //ccr2017-08-10 �����ٵ���һ��SetTimeDate,�����ȡ��������Ȼ������ǰ������,WHY?????
                        SetTimeDate(&Now);
                        Fiscal_AddDatetimeChg(1);
                    }

                    CheckTime(TRUE | 0x80);
	                MemSet(SysBuf, DISLEN, ' ');
    	            memcpy(SysBuf,DateAsci+4,10);
        	        SysBuf[DISLEN]=0;
                    PutsO(SysBuf);
					while (Bios_TestMAC())  //ccr2018-01-19
                        PutsM((char*)MsgREMOVEMAC);//ccr2018-01-19
#if (DISP2LINES)
                    Puts1(EXITMESS);//ccr20131120
#endif
                }
            } else
                SetDateFlg = 3;
        }
        break;
    default:
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        break;
    }
}

void ProgTime()
{
    switch (Appl_ProgLine)
    {
    case 1:
        SetDateFlg = 1;
        Appl_MaxEntry = 8;
        CheckTime(true | 0x80);
        MemSet(ProgLineMes, sizeof(ProgLineMes), ' ');
#if (DISP2LINES)
       memset(ProgLine1Mes,' ',sizeof(ProgLine1Mes));
//ccr2017-12-13        strcpy(ProgLine1Mes,EXITMESS);
#endif
        memcpy(ProgLineMes+2,TimeAsci, 8);
        if (!CheckPWD((char*)PWD4Technician))
            ApplVar.ErrorNumber=ERROR_ID(CWXXI36);
        else  if (!Bios_TestMAC())//ccr2017-12-13
            ApplVar.ErrorNumber=ERROR_ID(CWXXI04);//δ��Ȩ

        break;
    case 2:     /* set time */
        if (!Bios_TestMAC())//ccr2017-12-13
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI04);//δ��Ȩ
        }
        else if (ApplVar.FisNumber.TotalDateChangeNum>=FDATECHGMAX)//ccr2017-08-08>>>>
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI117);//����������������
        }//ccr2017-08-08<<<<<<<<<
        else
        {
            if (Appl_EntryCounter>0)
            {
                if (MyFlags(ZREPORT))   /* z report taken ? */
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI13);
                } else
                {
                    Fiscal_AddDatetimeChg(0);
                    SetDateFlg = 2;
                    Appl_ProgLine = 1;
                    NewTimeDate(2);

                    if (!ApplVar.ErrorNumber)
                    {//������־
                        Fiscal_AddDatetimeChg(1);
                    }
                    while (Bios_TestMAC())  //ccr2018-01-19
                    {
                        PutsM((char*)MsgREMOVEMAC);//ccr2018-01-19
#if (DISP2LINES==0)
                        Delay(ASECOND/2);
#endif
                        CheckTime(TRUE | 0x80);
                        MemSet(SysBuf, DISLEN, ' ');
                        memcpy(SysBuf+2,TimeAsci, 8);
                        SysBuf[10]=0;
                        PutsO(SysBuf);
                    }
#if (DISP2LINES)
                    Puts1(EXITMESS);//ccr20131120
#endif

                }
            } else
                SetDateFlg = 3;
        }
        break;
    default:
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        break;
    }
}


void ProgPort(BYTE port)
{
    short i;
    BYTE    oldICPort;

    ApplVar.PortNumber = port;
    ReadPort();
    switch (Appl_ProgLine)
    {
    case 1:
        Appl_ProgLine = 2;
    case 2:     /* ApplVar.Port type (Option)*/
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        if (Appl_BitNumber==0)
            Appl_BitNumber = ApplVar.Port.Type-'0';
        if (COMPUTER && COMPUTER!=TCPIPPORT && COMPUTER_1 != port && Appl_BitNumber==(PORT4HOSTPC-'0'))
        {// ����һ����������Ϊ������ʱ����ֹ��������������  ccr 050227//
            ApplVar.Port.Type = PORT4BARCODE;
            Appl_BitNumber = PORT4BARCODE-'0';
        }
        GetOpt(44, &ApplVar.Port.Type, portTypeNum);
        if (COMPUTER && COMPUTER!=TCPIPPORT && COMPUTER_1 != port && ApplVar.Port.Type==PORT4HOSTPC)
        {// ����һ����������Ϊ������ʱ����ֹ��������������  //
            ApplVar.Port.Type = PORT4BARCODE;
            Appl_BitNumber = PORT4BARCODE-'0';
            GetOpt(44, &ApplVar.Port.Type, portTypeNum);
        }
        break;
    case 3:     /* Protocl string */
#if 0   //ccr2017-08-04>>>>>>ͨ��Select��ѡ������>>>>>>
        CopyFrStr(ProgLineMes, Prompt.LineCap[Line_PROTOCOL]);
        Appl_MaxEntry=1;
        if (Appl_BitNumber==0)
        {
            Appl_BitNumber = DeCodeRate(ApplVar.Port.Prot[ApplVar.Port.Type-0x31]);
            if (Appl_BitNumber==0)  Appl_BitNumber=1;
        }
        GetPortRate(&ApplVar.Port.Prot[ApplVar.Port.Type-0x31]);
        //ccr2017-08-04<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#else
        Appl_MaxEntry = 5;
        Appl_BitNumber = 0;
        GetOpt(45, &ApplVar.Port.Prot[ApplVar.Port.Type - 0x31], 5);
#endif
        break;
    default:
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        break;
    }

    oldICPort = ApplVar.MFRCardPort;
    ApplVar.MFRCardPort = COMPUTER = BALANCE =0;
    BARCODE &= 0xf8;
    PCCounter = CCDCounter = BalCounter = 0;
    WritePort();
    SetComm(ApplVar.PortNumber);
    EmptyComm(ApplVar.PortNumber);

    if (ApplVar.Port.Type == PORT4HOSTPC)
        COMPUTER = ApplVar.PortNumber+1;
    else if (ApplVar.Port.Type == PORT4BARCODE)
        BARCODE = (BARCODE & 0xf8) | (ApplVar.PortNumber+1);
    else if (ApplVar.Port.Type == PORT4SCALE)
        BALANCE = ApplVar.PortNumber+1;

    SetPortForAppl();
#if 0	//cc 20070930
#if (CASE_MFRIC==1)
    if (ApplVar.MFRCardPort  && oldICPort!=ApplVar.MFRCardPort && BIT(ApplVar.ICCardSet.Options,IC_CHIPCARD))//MI_OK)
    {
        PutsO(Msg[WAITEICCARD].str);
        if (mifs_config()!=0)
        {
            ApplVar.ErrorNumber=CWXXI72-CWXXI01+1;
            ApplVar.MFRCardPort = 0;
        }
    }
#endif
#endif
}



    #if 1
/**
 * �±�LOGO��ӡ����:ȥ���н�ͼƬ����
 *
 * @author EutronSoftware (2017-08-07)
 */
void ProgPrnGraph()
{
    BYTE    sIdx;

    switch (Appl_ProgLine)
    {
    case 1:
        Appl_ProgLine = 2;
    case 2:     /* Print LOGO or not */
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        if (Appl_BitNumber==0)
            Appl_BitNumber = (FLAGPRNLOGO)+1;
        CheckBitValue(ItemPrompt116,&DBLHIPRN,1,0);
        break;
    case 3://Picture number for Ʊͷ
        Appl_MaxEntry = 6;
        Appl_BitNumber = 0;
        if (!Appl_EntryCounter)
            sIdx = ApplVar.Graph[0].PictNo;
        else
        {
            if (Appl_NumberEntry>GRAPHICMAX)
            {//=1ʱ��Ϊ�û��Զ���ͼƬ
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                return;
            }
            sIdx = Appl_NumberEntry;
        }
        CopyFrStr(ProgLineMes,MsgLOGOOnHEAD);
#if (DISP2LINES)
        WORDtoASC(ProgLine1Mes+DISLEN-1,sIdx);
#else
        WORDtoASC(ProgLineMes+DISLEN-1,sIdx);
#endif
        ApplVar.Graph[0].PictNo = sIdx;

        break;
    case 4://Picture number  for Ʊβ
        if (!Appl_EntryCounter)
            sIdx = ApplVar.Graph[GRAFESTMAX+1].PictNo;
        else
        {
            if (Appl_NumberEntry>GRAPHICMAX)
            {//=1ʱ��Ϊ�û��Զ���ͼƬ
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                return;
            }
            sIdx = Appl_NumberEntry;
        }
        CopyFrStr(ProgLineMes,MsgLOGOOnTRAIL);
#if (DISP2LINES)
        WORDtoASC(ProgLine1Mes+DISLEN-1,sIdx);
#else
        WORDtoASC(ProgLineMes+DISLEN-1,sIdx);
#endif
        ApplVar.Graph[GRAFESTMAX+1].PictNo = sIdx;

        break;
    default:
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        break;
    }
}

    #else

void ProgPrnGraph()
{
    BYTE    sIdx;

    if (Appl_ProgNumber==3)
    {
        if (Appl_ProgLine==1)
            return;

        if (Appl_ProgLine>=2 && Appl_ProgLine<TEXTSOFGRAPH+2)
        {
            Appl_MaxEntry = PRTLEN;
            SetInputMode('a');
            GetOpt(0,ApplVar.GrafTexts[Appl_ProgLine-2], PRTLEN);
            ProgLineMes[0]='C';
            ProgLineMes[1]='A';
            WORDtoASC(ProgLineMes+2,Appl_ProgLine-1);
        } else
        {
            SetInputMode('9');
            Appl_ProgLine = 0;
        }
        return;
    } else if (Appl_ProgNumber ==2)
        GrapNo = GRAFESTMAX+1;
    else if (Appl_ProgNumber==0)
        GrapNo = 0;
    else if (!GrapNo && Appl_ProgNumber ==1)
        GrapNo = 1;
    switch (Appl_ProgLine)
    {
    case 1:
        break;
    case 2://Festival number
        if (GrapNo==0 || GrapNo == GRAFESTMAX+1)
        {
            Appl_ProgLine = 3;
            ProgPrnGraph();
            return;
        } else
        {
            if (Appl_EntryCounter)
            {
                sIdx = Appl_NumberEntry;
                if (sIdx==0 || sIdx>GRAFESTMAX)
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                    return;
                }
                GrapNo = sIdx;
            }
            CopyFrStr(ProgLineMes+SETUPMARIN,GrapSet[Appl_ProgLine-2]);
            WORDtoASC(ProgLineMes+DISLEN-1,GrapNo);
            break;
        }
    case 3://Picture number
        if (!Appl_EntryCounter)
            sIdx = ApplVar.Graph[GrapNo].PictNo;
        else
        {
            if (Appl_NumberEntry>GRAPHICMAX)
            {//=1ʱ��Ϊ�û��Զ���ͼƬ
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                return;
            }
            sIdx = Appl_NumberEntry;
        }
        CopyFrStr(ProgLineMes+SETUPMARIN,GrapSet[Appl_ProgLine-2]);
        WORDtoASC(ProgLineMes+DISLEN-1,sIdx);
        ApplVar.Graph[GrapNo].PictNo = sIdx;

        break;
    case 4://Date from
        if (GrapNo==0 || GrapNo == GRAFESTMAX+1)
        {
            Appl_ProgLine = 6;
            ProgPrnGraph();
            return;
        } else
        {
            Appl_MaxEntry = 8;
            GetOpt(35, ApplVar.Graph[GrapNo].DateFrom, sizeof(ApplVar.Graph[GrapNo].DateFrom));
            break;
        }
    case 5://date to
        if (GrapNo==0 || GrapNo == GRAFESTMAX+1)
        {
            Appl_ProgLine = 6;
            ProgPrnGraph();
            return;
        } else
        {
            Appl_MaxEntry = 8;
            GetOpt(36, ApplVar.Graph[GrapNo].DateTo, sizeof(ApplVar.Graph[GrapNo].DateTo));
            break;
        }
    default:
        GrapNo++;
        if (GrapNo > GRAFESTMAX+1)
            GrapNo = 0;
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        break;
    }
}
    #endif

void ProgIC()  //ccr chipcard 2004-06-28
{
#if DD_CHIPC
    BYTE TempStr[15];
    short i;
    UnLong  sLong;


    switch (Appl_ProgLine)
    {
    case 1 :
        RESETBIT(ApplVar.ArrowsAlfa,SETCONFIRM);//ccr040809
        Appl_ProgLine = 2;
    case 2 ://ICCard Enable
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        CheckBitValue(ItemPrompt69,(BYTE *)&ApplVar.ICCardSet.Options,1 + 0x80,0);
        break;
    case 3 ://Manager PASSWORD VERIFY
/*	           if (BIT(ApplVar.ICCardSet.Options,BIT0))
               {
                Appl_MaxEntry = sizeof(ApplVar.ICCardSet.Password) * 2;
                Appl_BitNumber = 0;
                SETBIT(ApplVar.ArrowsAlfa,INPUTPWD);
                GetBCDValue(ICSZMIMA,ApplVar.ICCardSet.Password,3,TRUE);
                break;
               }
               else
               {
                Appl_MaxEntry = 0;
                Appl_ProgLine = 0;
                break;
               }
*/
        if (!BIT(ApplVar.ICCardSet.Options, IC_CHIPCARD))
        {
            Appl_MaxEntry = 4;
            Appl_ProgLine = 0;
            break;
        } else
            Appl_ProgLine = 4;
    case 4 : //POSCODE SET
        Appl_MaxEntry = sizeof(ApplVar.ICCardSet.PosCode) * 2;
        Appl_BitNumber = 0;
        memset(TempStr,0,sizeof(TempStr));//ccr20120101
        ULongToBCDValue(TempStr,ApplVar.ICCardSet.PosCode);
        SETBIT(ApplVar.ArrowsAlfa,INPUTPWD);
        GetBCDValue(Line_POSCODE,TempStr,4,TRUE);
        if (Appl_EntryCounter)
        {
            ApplVar.ICCardSet.PosCode=BCDValueToULong(TempStr,BCDLEN);
            IC.CHIP_PSWD[2] = 0xff;
            Appl_ProgLine = 5;
            Appl_EntryCounter = 0;
        } else
            break;
    case 5 : //POSCODE confirm
        if (ApplVar.ICCardSet.PosCode)
        {
            SETBIT(ApplVar.ArrowsAlfa,SETCONFIRM);//ccr040809
            Appl_MaxEntry = sizeof(ApplVar.ICCardSet.PosCode) * 2;
            Appl_BitNumber = 0;
            memset(TempStr,0,sizeof(TempStr));
            SETBIT(ApplVar.ArrowsAlfa,INPUTPWD);
            GetBCDValue(Line_CONFIRM,TempStr,4,TRUE);
            sLong = 0;                              //ccr020809
            if (Appl_EntryCounter)
            {
                sLong=BCDValueToULong(TempStr,BCDLEN);
                if (sLong != ApplVar.ICCardSet.PosCode)
                {
                    ApplVar.ErrorNumber=CWXXI51 - CWXXI01 + 1;
                    break;
                } else
                {
                    Appl_ProgLine = 6;
                    Appl_EntryCounter = 0;
                }
            } else
                break;
        } else
            Appl_ProgLine = 6;
    case 6 : //Type 0 Card Enable
    case 7 : //Type 1 Card Enable
    case 8 : //Type 2 Card Enable
    case 9 : //ApplVar.Report
    case 10 : //Discount
    case 11://Points
        RESETBIT(ApplVar.ArrowsAlfa,SETCONFIRM);//ccr040809
        Appl_MaxEntry = 0;
        CheckBitValue(ItemPrompt70+Appl_ProgLine-6,(BYTE *)&ApplVar.ICCardSet.Options,2+(Appl_ProgLine-6) + 0x80,0);
        break;
    case 12://Value
        if (BIT(ApplVar.ICCardSet.Options,BIT6))
        {
            Appl_MaxEntry = 6;
            Appl_BitNumber = 0;
            GetBCDValue(Line_VALUE,ApplVar.ICCardSet.Value,3,FALSE);
            break;
        } else  Appl_ProgLine = 13;
    case 13://MIniNum
        if (BIT(ApplVar.ICCardSet.Options,BIT6))
        {
            Appl_MaxEntry = 6;
            Appl_BitNumber = 0;
            GetBCDValue(Line_MINIMUM,ApplVar.ICCardSet.MiniNum,3,FALSE);
            break;
        } else Appl_ProgLine = 14;
    case 14://Toc_CC
        Appl_MaxEntry = 0;
        CheckBitValue(ItemPrompt76,(BYTE *)&ApplVar.ICCardSet.Options,8 + 0x80,0);
        break;
    case 15://IC_DEAD
        Appl_MaxEntry = 0;
        CheckBitValue(ItemPrompt78,(BYTE *)&ApplVar.ICCardSet.Options+1,1 + 0x80,0);// ָ��Options�ĸ��ֽ�  //
        break;
    default:
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        break;
    }
#endif
}

    #if (DD_PROMOTION)
void ProgPromotion()
{

    WORD i;

    switch (Appl_ProgLine)
    {
    case 1:
        Appl_BitNumber = 0;
        Appl_ProgLine = 2;
    case 2:     /* JOLLY ?*/
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        CheckBitValue(ItemPrompt66,&PROMOTION,1,YN);
        break;
    case 3:
        if (!BIT(PROMOTION,BIT0))
        {
            Appl_MaxEntry = 4;
            Appl_BitNumber = 0;
            i = ApplVar.AP.Promotion.Freq;
            GetWordValue(Line_FREQUENT,&i,9999);
            ApplVar.AP.Promotion.Freq = i;
            break;
        } else
            Appl_ProgLine = 4;
    case 4:
        if (!BIT(PROMOTION,BIT0))
        {
            Appl_MaxEntry = 8;
            Appl_BitNumber = 0;
            GetBCDValue(Line_MINIMUM,ApplVar.AP.Promotion.JollyMin,4,TRUE);
            break;
        } else
            Appl_ProgLine = 5;
    case 5:
        if (!BIT(PROMOTION,BIT0))
        {
            Appl_MaxEntry = 2;
            GetByteValue(Line_GRAPHIC,&ApplVar.AP.Promotion.GrapIdx,22);
            break;
        } else
            Appl_ProgLine = 6;
    case 6:
        if (!BIT(PROMOTION,BIT0))
        {
            SetInputMode('a');

            Appl_MaxEntry = 32;
            GetOpt(0, ApplVar.AP.Promotion.Memo, sizeof(ApplVar.AP.Promotion.Memo)-1);
            break;
        } else
            Appl_ProgLine = 7;
    case 7:
        SetInputMode('9');
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        CheckBitValue(ItemPrompt67,&PROMOTION,2,YN);
        break;
    case 8:
        if (!BIT(PROMOTION,BIT1))
        {
            Appl_MaxEntry = 8;
            Appl_BitNumber = 0;
            GetBCDValue(Line_VALUE,ApplVar.AP.Promotion.PointVal,4,FALSE);
            break;
        } else
            Appl_ProgLine = 9;
    case 9:
        if (!BIT(PROMOTION,BIT1))
        {
            Appl_MaxEntry = 8;
            Appl_BitNumber = 0;
            GetBCDValue(Line_MINIMUM,ApplVar.AP.Promotion.PointMin,4,FALSE);
            break;
        } else
            Appl_ProgLine = 9;
    default:
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        break;
    }
}
    #endif

void ProgNULL()
{
    switch (Appl_ProgLine)
    {
    case 1:
        break;
    case 2:
        break;
    default:
        Appl_ProgLine = 0;
        break;
    }
}

void ProgOFF()
{
#if offNumber
    if (Appl_ProgNumber >= ApplVar.AP.OFFPrice.Number)
    {
        if (ApplVar.AP.OFFPrice.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            Appl_ProgNumber = -1;
            Appl_ProgLine = 0;
        }
        return;
    }
    ApplVar.OFFNumber = Appl_ProgNumber;
    ReadOFFPrice();
    switch (Appl_ProgLine)
    {
    case 1:
        break;
    case 2:     /* ApplVar.OFFPrice name */
        SetInputMode('a');
        Appl_MaxEntry = ApplVar.AP.OFFPrice.CapSize;
        if (GetOpt(0, ApplVar.OFFPrice.Name, ApplVar.AP.OFFPrice.CapSize))
            break;
    case 3:     /* OFF type */
        SetInputMode('9');
        Appl_MaxEntry = 1;
        if (GetOpt(34, &ApplVar.OFFPrice.Type, 3))
            break;
    case 4:     /* DateFrom */
        if (ApplVar.OFFPrice.Type>0)
        {
            Appl_MaxEntry = 4;
            GetOpt(35, ApplVar.OFFPrice.DateFrom, sizeof(ApplVar.OFFPrice.DateFrom));
            break;
        }
    case 5:     /* DateTo */
        if (ApplVar.OFFPrice.Type>0)
        {
            Appl_MaxEntry = 4;
            if (GetOpt(36, ApplVar.OFFPrice.DateTo, sizeof(ApplVar.OFFPrice.DateFrom)))
                break;
        }
    case 6:     /* TimeFrom */
        if (ApplVar.OFFPrice.Type>0)
        {
            Appl_MaxEntry = 4;
            if (GetOpt(37, ApplVar.OFFPrice.TimeFrom, sizeof(ApplVar.OFFPrice.DateFrom)))
                break;
        }
    case 7:     /* TimeTo */
        if (ApplVar.OFFPrice.Type>0)
        {
            Appl_MaxEntry = 4;
            if (GetOpt(38, ApplVar.OFFPrice.TimeTo, sizeof(ApplVar.OFFPrice.DateFrom)))
                break;
        }
    case 8:     /* WeekDay */
        if (ApplVar.OFFPrice.Type>0)
        {
            Appl_MaxEntry = 7;
            GetOpt(39, &ApplVar.OFFPrice.WeekDay, 7);
            break;
        }
    case 9:     /* Discount or Package */
        if (ApplVar.OFFPrice.Type>0)
        {
            if (ApplVar.OFFPrice.Type==1)
            {
                Appl_MaxEntry = 3;
                GetOpt(41, &ApplVar.OFFPrice.OFFVal.TYPE1.NumItems, 255);
                break;
            } else if (ApplVar.OFFPrice.Type==2)
            {
                Appl_MaxEntry = 6;
                GetOpt(40, ApplVar.OFFPrice.OFFVal.Discount, 2);
                break;
            }
        } else
            Appl_ProgLine = 10;
    case 10:        //OFF ApplVar.Price for a unit
        if (ApplVar.OFFPrice.Type==1)
        {
            Appl_MaxEntry = 4;
            GetOpt(42, ApplVar.OFFPrice.OFFVal.TYPE1.PriceU,ApplVar.AP.OFFPrice.PriUSize);
            break;
        } else
            Appl_ProgLine = 11;
    case 11:        //OFF ApplVar.Price for a package
        if (ApplVar.OFFPrice.Type==1)
        {
            Appl_MaxEntry = 4;
            GetOpt(43, ApplVar.OFFPrice.OFFVal.TYPE1.PriceP,sizeof(ApplVar.OFFPrice.OFFVal.TYPE1.PriceP));
            break;
        }
    default:
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        break;
    }
    if (Appl_ProgStart!=2)//ccr2017-05-10
        WriteOFFPrice();
#endif
}



void ProgAgree()
{
    if (Appl_ProgNumber >= ApplVar.AP.Agree.Number)
    {
        if (ApplVar.AP.Agree.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            Appl_ProgNumber = -1;
            Appl_ProgLine = 0;
        }
        return;
    }
    ApplVar.AgreeNumber = Appl_ProgNumber;
    ReadAgree();
    switch (Appl_ProgLine)
    {
    case 1:
        break;
    case 2:     /* ApplVar.Agree name */
        SetInputMode('a');
        Appl_MaxEntry = ApplVar.AP.Agree.CapSize * 2;
        if (GetOpt(0, ApplVar.Agree.Name, ApplVar.AP.Agree.CapSize))
            break;
    case 3:     /* ApplVar.Agree name */
        SetInputMode('a');
        Appl_MaxEntry = sizeof(ApplVar.Agree.Addr) * 2;
        GetString((char*)Prompt.LineCap[30],ApplVar.Agree.Addr, sizeof(ApplVar.Agree.Addr));
        break;
    case 4:     /* ApplVar.Agree ApplVar.Tax */
        SetInputMode('9');
        Appl_MaxEntry = sizeof(ApplVar.Agree.Tax) * 2;
        GetString((char*)Prompt.LineCap[9],ApplVar.Agree.Tax, sizeof(ApplVar.Agree.Tax));
        break;
    default:
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        break;
    }
    if (Appl_ProgStart!=2)//ccr2017-05-10
        WriteAgree();
}

void ProgKPrn()
{
    struct PRINTER *SetKP;

    SetKP = (struct PRINTER *) &KPSTART;
    if (Appl_ProgNumber > KPRNMAX)
    {
        Appl_ProgNumber = -1;
        Appl_ProgLine = 0;
        return;
    }
    SetKP = SetKP + Appl_ProgNumber;
    SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
    switch (Appl_ProgLine)
    {
    case 1:
        break;
    case 2:     /* Type of printer */
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        if (!Appl_BitNumber)
            Appl_BitNumber = (SetKP->type & 0x0f) + 1;
        if (Appl_BitNumber > KPTypeNum )
            Appl_BitNumber = 1;
        SetKP->type = (SetKP->type & 0xf0) + Appl_BitNumber-1;

        CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[Line_PRTTYPE]);
#if (DISP2LINES)
        memcpy(ProgLine1Mes+ DISLEN - sizeof(KPType[0])-1,KPType[Appl_BitNumber-1],sizeof(KPType[0]));
#else
        memcpy(ProgLineMes+ DISLEN - sizeof(KPType[0])-1,KPType[Appl_BitNumber-1],sizeof(KPType[0]));
#endif
        break;
    case 3:
    case 4:
    case 5:
        //ccr2014-07-26>>>>>>>>>>>>>
        if (SetKP->type & 0x0f)
        {
            Appl_MaxEntry = 0;
            Appl_EntryCounter = 0;

#if ((DISP2LINES) || DD_LCD_1601==1)
            CheckBitValue(Appl_ProgLine-3+ItemPrompt84,&SetKP->type,1+(Appl_ProgLine-3+5),0);
#else
            CheckBitValue(ItemPrompt50,&SetKP->type,1+(Appl_ProgLine-3+5)+0x80,0);
#endif
        } else
        {//���رճ�����ӡ��ʱ,������к�������
            Appl_MaxEntry = 4;
            Appl_ProgLine = 0;
        }
        //<<<<<<<<<<<<<<<<<<<<<<<<<<
        break;
    case 6:     /* ApplVar.Port */
        Appl_BitNumber = 0;
        Appl_MaxEntry = 1;
        GetByteValue(Line_PORT,&SetKP->port,ApplVar.AP.Port.Number);
        //ccr2014-07-26>>>>ǿ�����ô�������
        if (SetKP->port)
        {
            ApplVar.PortNumber = SetKP->port-1;
            ReadPort();
            switch (ApplVar.Port.Type)
            {
            case PORT4HOSTPC:
                COMPUTER = 0; PCCounter = 0;
                break;
            case PORT4BARCODE:
                CCDCounter = 0;BARCODE &= 0xf0;
                break;
            case PORT4SCALE:
                BALANCE = 0;   BalCounter = 0;
                break;
            }
            ApplVar.Port.Type = PORT4KITCHEN;
            WritePort();
        }//<<<<<<<<<<<<
        break;
    case 7:     /* link with another ApplVar.KP */
        Appl_BitNumber = 0;
        Appl_MaxEntry = 1;
        SetKP->alter++;
        GetByteValue(Line_EXTRAKP,&SetKP->alter,KPRNMAX);
        if (SetKP->alter>0)
            SetKP->alter--;
        break;
    default:
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        break;
    }
}


void ProgSlip()      //Lyq added for set the control message of slip  20040331
{
//    BYTE  SP;
    if (Appl_ProgNumber > 4)
    {
        Appl_ProgNumber = -1;
        Appl_ProgLine = 0;
        return;
    }
    switch (Appl_ProgLine)
    {
    case 1:
        break;
    case 2:
        Appl_MaxEntry = 0;
        //Appl_EntryCounter = 0;
        if (!Appl_BitNumber)
            Appl_BitNumber = (SLIP & 0x0f) + 1;
        if (Appl_BitNumber > SPTypeNum  )
            Appl_BitNumber = 1;
        SLIP = Appl_BitNumber - 1;

        CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[Line_SLIPTYPE]);

#if ((DISP2LINES) )
        memcpy(ProgLine1Mes+ DISLEN - 8,SPType[Appl_BitNumber - 1],7);
#else
        memcpy(ProgLineMes+ DISLEN - sizeof(SPType[0]-1),SPType[Appl_BitNumber - 1],sizeof(SPType[0]));
#endif
        Appl_EntryCounter = 0;
        break;
    case 3:
        if (SLIP>0)
        {
            Appl_BitNumber = 0;
            Appl_MaxEntry = 2;
            GetByteValue(Line_BLANKLIN,&SLIP_TOP, 10);
            break;
        }
    case 4:
        if (SLIP>0)
        {
            Appl_BitNumber = 0;
            Appl_MaxEntry = 2;
            GetByteValue(Line_LINEPAGE,&SLIP_MAX,255);
            break;
        }
    case 5:
        if (SLIP>0)
        {
            MemSet(ProgLineMes, sizeof(ProgLineMes), ' ');
#if ((DISP2LINES) )
            memset(ProgLine1Mes,' ',sizeof(ProgLine1Mes));
#endif
            CopyFrStr(ProgLineMes+SETUPMARIN, Prompt.LineCap[Line_PRTINFO]);
            Appl_MaxEntry = 0;
            if (Appl_BitNumber<2)
                Appl_BitNumber = 1;
//			GetByteValue(Line_PRTINFO,&SLIPINFO);
            if (Appl_BitNumber==2)
            {
                Appl_BitNumber = 1;
                SLIPINFO ^= 0x08;
            }
#if ((DISP2LINES) )
            if (BIT(SLIPINFO, BIT3))
            {
                ProgLine1Mes[DISLEN-3] = 'Y';
                ProgLine1Mes[DISLEN-2] = 'e';
                ProgLine1Mes[DISLEN-1] = 's';
            } else
            {
                ProgLine1Mes[DISLEN-3] = 'N';
                ProgLine1Mes[DISLEN-2] = 'o';
                ProgLine1Mes[DISLEN-1] = ' ';
            }
#else
            if (BIT(SLIPINFO, BIT3))
                ProgLineMes[DISLEN-2] = 'y';
            else
                ProgLineMes[DISLEN-2] = 'n';
#endif
            break;
        }
    case 6:     /* ApplVar.Port */
//		if(SLIP>0)
//		{
//			Appl_BitNumber = 0;
//			Appl_MaxEntry = 2;
//			SP = SECOND &0xf0;
//			SECOND &= 0x0f;
//			GetByteValue(Line_SECOND,&SECOND);
//			SECOND |= SP;
//			break;
//		}
//	case 7:     /* link with another ApplVar.KP */
        if (SLIP>0)
        {
            Appl_BitNumber = 0;
            Appl_MaxEntry = 2;
            GetByteValue(Line_LEFTMAR,&LMARGE, 50);
            break;
        }
    case 7:     /* port */
        if (SLIP>0)
        {
            Appl_BitNumber = 0;
            Appl_MaxEntry = 1;
            GetByteValue(Line_PORT,&ApplVar.AP.Flag[32],ApplVar.AP.Port.Number);
            break;
        }
    default:
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        break;
    }
}



void ProgICBlock()  //ccr chipcard 2004-07-01
{
    BYTE TempStr[15];
    unsigned long ICCardNOBK;

    if (Appl_ProgLine == 1)
    {
//		Appl_ProgNumber = 0;
//		Appl_ProgLine = 2;
        return;
    } else if (Appl_ProgLine > 2)
    {
        Appl_ProgNumber++;
        Appl_ProgLine = 2;
    }
    if (Appl_ProgNumber >= ApplVar.AP.ICBlock.Number)
    {
        if (ApplVar.AP.ICBlock.Number==0)
            strcpy(ProgLineMes,Number0);
        else
        {
            Appl_ProgNumber = -1;
            Appl_ProgLine = 0;
        }
        return;
    }

    ApplVar.ICBlockNumber = Appl_ProgNumber;
    ReadICBlock();
/*
    if(ICBlockPrintFlag == 1)
    {
        ICBlockPrintFlag = 0;
        Appl_ProgNumber = -1;
        Appl_ProgLine = 0;
        PrintICBlock();
        return;
    }
    ICBlockPrintFlag = 0;
*/
    Appl_MaxEntry = 8;
    memset(TempStr,0,sizeof(TempStr));//ccr20120101
    if (Appl_EntryCounter==0)
        ULongToBCDValue(TempStr,ApplVar.ICBlock.ICCardNO);

    GetBCDValue(Line_BUYRATE,TempStr,4,TRUE);

    memset(SysBuf,' ',8);                   //ccr040809
    WORDtoASCZero(SysBuf+4,Appl_ProgNumber+1);
    ProgLineMes[1] = SysBuf[2];
    ProgLineMes[2] = SysBuf[3];
    ProgLineMes[3] = SysBuf[4];

    ApplVar.ICBlock.ICCardNO = BCDValueToULong(TempStr,BCDLEN);
    if (Appl_EntryCounter)
    {
        if (ApplVar.ICBlock.ICCardNO == 99999999)
        {
            PrintICBlock();//ICBlockPrintFlag = 1;
            if (Appl_ProgNumber>0)
                Appl_ProgNumber--;

        } else
        {
            WriteICBlock();
//			Appl_ProgNumber++;
        }
    }
}

/*******************************************************************
 *
 * ���±�дNET WORK����,��ProgIP��ΪProgNetWork
 * @author EutronSoftware (2017-09-18)
 *****************************************************************/
#if defined(CASE_ETHERNET)
typedef enum {
    caseDHCP=2,
    caseIPADDRESS,
    caseGATEWAY,
    casePRIMARYDNS,
    caseSECONDARYDNS,
    caseMASK,
    casePRINTNETWORK
} enumNetWork;
#elif defined(CASE_GPRS)
typedef enum {
    caseIPADDRESS=2,
    caseSERVERIP,
    casePORT,
    caseGPRSSEND,
    caseGPRSAPN,
    caseUSERNAME,
    casePASSWORD,
    casePRINTNETWORK
} enumNetWork;
#endif

void ProgNetWork()//NET WORK
{
#if (defined(CASE_ETHERNET) || defined(CASE_GPRS))
  	int i;
    WORD pPort;
    static BYTE newNet=0;//������ʾ���������Ƿ����޸�

    SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
    switch (Appl_ProgLine)
    {
    case 1:
        Appl_ProgLine=2;
        Appl_BitNumber=0;
#if defined(CASE_ETHERNET)
    case caseDHCP://DHCP (YES/NO)
        Appl_MaxEntry = 0;
        Appl_EntryCounter = 0;
        if (!Appl_BitNumber)
        {
            Appl_BitNumber = BIT(ApplVar.AP.NetWork.Option,DHCPFlag) ? 2:1;
        }
        else
        {
            SETMyFlags(CONFIGECR+REBOOTMUST);//�޸�������ĵ�ǰֵ
        }
        if (Appl_BitNumber > 2  )
            Appl_BitNumber = 1;
        if (Appl_BitNumber==1)
            RESETBIT(ApplVar.AP.NetWork.Option,DHCPFlag);
        else
            SETBIT(ApplVar.AP.NetWork.Option,DHCPFlag);

        CopyFrStr(ProgLineMes+SETUPMARIN, Msg[DHCP].str);

#if ((DISP2LINES) )
        memcpy(ProgLine1Mes+ DISLEN - 3,Prompt.LineCap[Line_YES+2-Appl_BitNumber],3);
#else
        memcpy(ProgLineMes+ DISLEN - 3,Prompt.LineCap[Line_YES+2-Appl_BitNumber],3);
#endif
        break;
#endif
    case caseIPADDRESS://set Client IP
        if (BIT(ApplVar.AP.NetWork.Option,DHCPFlag))
            Appl_MaxEntry = 0;
        else
            Appl_MaxEntry = 15;

        Appl_BitNumber=0;
        SetInputMode('0');
        if (GetIP((char*)MsgCLIENTIP,ApplVar.AP.NetWork.IPAddress))
            SETMyFlags(CONFIGECR+REBOOTMUST);//�޸�������ĵ�ǰֵ
        if (CLONG(ApplVar.AP.NetWork.IPAddress[0]))
            SETBIT(ApplVar.AP.NetWork.Option,IPByDHCPFlag);//ccr2017-09-28��DHCP��ʽ,Ĭ��IP��Ч
        break;
#if defined(CASE_ETHERNET)
    case caseGATEWAY://GATEWAY��������
        if (BIT(ApplVar.AP.NetWork.Option,DHCPFlag))
            Appl_MaxEntry = 0;
        else
            Appl_MaxEntry = 15;
        SetInputMode('0');
        if (GetIP((char*)MsgGATEWAY,ApplVar.AP.NetWork.GateWay))
            SETMyFlags(CONFIGECR+REBOOTMUST);//�޸�������ĵ�ǰֵ
        break;
    case casePRIMARYDNS://PRIMARY DNS
        Appl_MaxEntry = 15;
        SetInputMode('0');
        if (GetIP((char*)Msg[PRIMARYDNS].str,ApplVar.AP.NetWork.PrimaryDNS))
            SETMyFlags(CONFIGECR+REBOOTMUST);//�޸�������ĵ�ǰֵ
        break;
    case caseSECONDARYDNS://SECONDARY DNS
        SetInputMode('0');
        Appl_MaxEntry=15;
        if (GetIP((char*)Msg[SECONDARYDNS].str,ApplVar.AP.NetWork.SecondDNS))
            SETMyFlags(CONFIGECR+REBOOTMUST);//�޸�������ĵ�ǰֵ
        break;
    case caseMASK://����MASK
        if (BIT(ApplVar.AP.NetWork.Option,DHCPFlag))
            Appl_MaxEntry = 0;
        else
            Appl_MaxEntry = 15;
        SetInputMode('0');
        if (GetIP((char*)MsgIPMASK,ApplVar.AP.NetWork.IPMask))
            SETMyFlags(CONFIGECR+REBOOTMUST);//�޸�������ĵ�ǰֵ
        break;
#elif defined(CASE_GPRS)
    case caseSERVERIP:
        Appl_MaxEntry = 15;
        SetInputMode('0');
        MemSet(ProgLineMes, sizeof(ProgLineMes), ' ');
#if ((DISP2LINES) )
        memset(ProgLine1Mes,' ',sizeof(ProgLine1Mes));
#endif
        GetIP((char*)MsgSERVERIP,ApplVar.AP.NetWork.ServerIP);
        break;
    case casePORT:
        SetInputMode('9');
        Appl_MaxEntry = 6;
        Appl_BitNumber = 0;
        if (ApplVar.AP.NetWork.ServerPort==0)
            ApplVar.AP.NetWork.ServerPort = 80;//COM PORT BY DEFAULT IS 80
        pPort = ApplVar.AP.NetWork.ServerPort;
        if (Appl_EntryCounter)
            SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
        GetWordValue(Line_PORT,&pPort,65530);
        ApplVar.AP.NetWork.ServerPort = pPort;
        break;
    case caseGPRSSEND://GPRS SEND?(YES/NO)
        Appl_MaxEntry = 0;
        //Appl_EntryCounter = 0;
        if (!Appl_BitNumber)
            Appl_BitNumber = BIT(ApplVar.DaysMust,BIT7) ? 2:1;
        else
            SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ

        if (Appl_BitNumber > 2  )
            Appl_BitNumber = 1;
        if (Appl_BitNumber==1)
            RESETBIT(ApplVar.DaysMust,BIT7);
        else
            SETBIT(ApplVar.DaysMust,BIT7);

        CopyFrStr(ProgLineMes+SETUPMARIN, Msg[GPRSSEND].str);

#if ((DISP2LINES) )
        memcpy(ProgLine1Mes+ DISLEN - 3,Prompt.LineCap[Line_YES+2-Appl_BitNumber],3);
#else
        memcpy(ProgLineMes+ DISLEN - 3,Prompt.LineCap[Line_YES+2-Appl_BitNumber],3);
#endif
        break;
    case caseGPRSAPN:
//ccr2018-01-04        if (BIT(ApplVar.DaysMust,BIT7))
        {
            SetInputMode('a');
            Appl_MaxEntry=sizeof(ApplVar.AP.NetWork.APN)-1;
            ApplVar.AP.NetWork.APN[Appl_MaxEntry]=0;
            if (Appl_EntryCounter)
                SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
            GetString((char*)MsgGPRSAPNNAME, ApplVar.AP.NetWork.APN, Appl_MaxEntry);
            break;
        }
    case caseUSERNAME://ccr2015-03-11>>>>>>>>
//ccr2018-01-04        if (BIT(ApplVar.DaysMust,BIT7))
        {
            SetInputMode('a');
            Appl_MaxEntry=sizeof(ApplVar.AP.NetWork.UserName)-1;
            ApplVar.AP.NetWork.UserName[Appl_MaxEntry]=0;
            if (Appl_EntryCounter)
                SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
            GetString((char*)MsgGPRSUSERNAME, ApplVar.AP.NetWork.UserName, Appl_MaxEntry);
            break;
        }
    case casePASSWORD:
//ccr2018-01-04        if (BIT(ApplVar.DaysMust,BIT7))
        {
            if (ApplVar.AP.NetWork.UserName[0])
            {
                SetInputMode('a');
                Appl_MaxEntry=sizeof(ApplVar.AP.NetWork.Password)-1;
                ApplVar.AP.NetWork.Password[Appl_MaxEntry]=0;
                if (Appl_EntryCounter)
                    SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
                GetString((char*)GPRSPASSWORD, ApplVar.AP.NetWork.Password, Appl_MaxEntry);
                break;
            }//ccr2015-03-11<<<<<<<<<<<
        }
#endif
    case casePRINTNETWORK://print settings
        //��ӡ��������
        if (WaitForYesNo(Msg[PRINTSETTINGS].str,0,0,true)=='Y')
        {
            PrintStr_Center(MSG_SETTINS4NETWORK,true);
#if defined(CASE_ETHERNET)
            memset(ProgLineMes,' ',PRTLEN);
            i = BIT(ApplVar.AP.NetWork.Option,DHCPFlag) ? 0:1;
            CopyFrStr(ProgLineMes, Msg[DHCP].str);
            strcpy(ProgLineMes+ PRTLEN - 3,Prompt.LineCap[i]);
            RJPrint(0,ProgLineMes);
#endif
            memset(ProgLineMes,' ',PRTLEN);
            CopyFrStr(ProgLineMes,MsgCLIENTIP);
            NumToIP(ProgLineMes+PRTLEN-1, ApplVar.AP.NetWork.IPAddress,0);
            ProgLineMes[PRTLEN]=0;
            RJPrint(0,ProgLineMes);

            memset(ProgLineMes,' ',PRTLEN);
            CopyFrStr(ProgLineMes,MsgGATEWAY);
            NumToIP(ProgLineMes+PRTLEN-1, ApplVar.AP.NetWork.GateWay,0);
            ProgLineMes[PRTLEN]=0;
            RJPrint(0,ProgLineMes);

#if defined(CASE_ETHERNET)
            memset(ProgLineMes,' ',PRTLEN);
            CopyFrStr(ProgLineMes,Msg[PRIMARYDNS].str);
            NumToIP(ProgLineMes+PRTLEN-1, ApplVar.AP.NetWork.PrimaryDNS,0);
            ProgLineMes[PRTLEN]=0;
            RJPrint(0,ProgLineMes);

            memset(ProgLineMes,' ',PRTLEN);
            CopyFrStr(ProgLineMes,Msg[SECONDARYDNS].str);
            NumToIP(ProgLineMes+PRTLEN-1, ApplVar.AP.NetWork.SecondDNS,0);
            ProgLineMes[PRTLEN]=0;
            RJPrint(0,ProgLineMes);
#elif defined(CASE_GPRS)
            memset(ProgLineMes,' ',PRTLEN);
            CopyFrStr(ProgLineMes,MsgSERVERIP);
            NumToIP(ProgLineMes+PRTLEN-1, ApplVar.AP.NetWork.ServerIP,0);
            ProgLineMes[PRTLEN]=0;
            RJPrint(0,ProgLineMes);

            memset(ProgLineMes,' ',PRTLEN);
            CopyFrStr(ProgLineMes, Prompt.LineCap[Line_PORT]);
            WORDtoASC(ProgLineMes+PRTLEN-1,ApplVar.AP.NetWork.ServerPort);
            ProgLineMes[PRTLEN]=0;
            RJPrint(0,ProgLineMes);

            memset(ProgLineMes,' ',PRTLEN);
            i = BIT(ApplVar.DaysMust,BIT7) ? 0:1;
            CopyFrStr(ProgLineMes, Msg[GPRSSEND].str);
            strcpy(ProgLineMes+ PRTLEN - 3,Prompt.LineCap[i]);
            RJPrint(0,ProgLineMes);

            Print2Strings((char*)MsgGPRSAPNNAME,ApplVar.AP.NetWork.APN);
            Print2Strings((char*)MsgGPRSUSERNAME,ApplVar.AP.NetWork.UserName);
            Print2Strings(GPRSPASSWORD,ApplVar.AP.NetWork.Password);
#endif
            memset(ProgLineMes,' ',PRTLEN);
            CopyFrStr(ProgLineMes,MsgIPMASK);
            NumToIP(ProgLineMes+PRTLEN-1, ApplVar.AP.NetWork.IPMask,0);
            ProgLineMes[PRTLEN]=0;
            RJPrint(0,ProgLineMes);
            RFeed(PREHEADER+2);
        }
    default:
#if (0)//defined(CASE_ETHERNET)
        if (Appl_EntryCounter)//�������µĶ˿�����ʱ,�Զ��˳�����
            Ethernet_Start();
#endif
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        EXIT;//ccr2015-10-12�˳�����
        if (MyFlags(REBOOTMUST))//�޸�������ĵ�ǰֵ
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI118);//ccr2017-09-26��Ҫ���������տ��
            CLRMyFlags(REBOOTMUST);
        }
        break;
    }

#endif
}


#if defined(CASE_ETHERNET)

/*******************************************************************
 *
 * ���±�дNET WORK����,��ProgIP��ΪProgNetWork
 * @author EutronSoftware (2017-09-18)
 *****************************************************************/
typedef enum {
    caseMINISTRY=2,
    caseSERVERURL,
    caseSERVERIP,
    casePORT,
    casePERSONALCODE,
    caseAESKEY,
    caseGPRSSEND,
    caseGPRSAPN,
    caseUSERNAME,
    casePASSWORD,
    casePRINTNETFUNC
} enumNetFunc;

void ProgNetFunctions()//NET Functions
{
    int i;
    WORD pPort;

    SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
    switch (Appl_ProgLine)
    {
    case 1:
        Appl_ProgLine=2;
        Appl_BitNumber=0;
        Appl_EntryCounter = 0;
    case caseMINISTRY://MINISTRY SEND?? (YES/NO)
        Appl_MaxEntry = 0;
        //Appl_EntryCounter = 0;
        if (!Appl_BitNumber)
            Appl_BitNumber = BIT(ApplVar.AP.NetWork.Option,MINISTRYFlag) ? 2:1;
        else
            SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
        if (Appl_BitNumber > 2  )
            Appl_BitNumber = 1;
        if (Appl_BitNumber==1)
            RESETBIT(ApplVar.AP.NetWork.Option,MINISTRYFlag);
        else
            SETBIT(ApplVar.AP.NetWork.Option,MINISTRYFlag);

        CopyFrStr(ProgLineMes+SETUPMARIN, Msg[MINISTRYSEND].str);

#if ((DISP2LINES) )
        memcpy(ProgLine1Mes+ DISLEN - 3,Prompt.LineCap[Line_YES+2-Appl_BitNumber],3);
#else
        memcpy(ProgLineMes+ DISLEN - 3,Prompt.LineCap[Line_YES+2-Appl_BitNumber],3);
#endif
        break;
    case caseSERVERURL://SERVER? (WE HAVE TO ENTER URL)

        Appl_MaxEntry=sizeof(ApplVar.AP.NetWork.ServerURL)-1;
        ApplVar.AP.NetWork.ServerURL[Appl_MaxEntry]=0;
        if (BIT(GetStrFromKBD('*',(char*)Msg[SERVERURL].str,(char*)ApplVar.AP.NetWork.ServerURL,Appl_MaxEntry,0,YES),NEWSTRING))
        {
            SETMyFlags(CONFIGECR+REBOOTMUST);//�޸�������ĵ�ǰֵ
#if (0)//LWIP_DNS)
            CLONG(ApplVar.AP.NetWork.ServerIP[0])=0;
            if (BIT(ApplVar.AP.NetWork.Option,IPByDHCPFlag))//&& ApplVar.AP.NetWork.ServerURL[0]
            {
                if (!GetIPByDNSFromURL(ApplVar.AP.NetWork.ServerIP,ApplVar.AP.NetWork.ServerURL,true))
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI120);//��������ʧ��
                    break;
                }
            }
#endif
        }
        Appl_EntryCounter=0;
        Appl_BitNumber=0;
        Appl_ProgLine++; //break;
    case caseSERVERIP:
        Appl_MaxEntry = 15;
        SetInputMode('0');
        MemSet(ProgLineMes, sizeof(ProgLineMes), ' ');
#if ((DISP2LINES) )
        memset(ProgLine1Mes,' ',sizeof(ProgLine1Mes));
#endif
        GetIP((char*)MsgSERVERIP,ApplVar.AP.NetWork.ServerIP);
        break;
    case casePORT:
        SetInputMode('9');
        Appl_MaxEntry = 6;
        Appl_BitNumber = 0;
        if (ApplVar.AP.NetWork.ServerPort==0)
            ApplVar.AP.NetWork.ServerPort = 80;//COM PORT BY DEFAULT IS 80
        pPort = ApplVar.AP.NetWork.ServerPort;
        if (Appl_EntryCounter)
            SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
        GetWordValue(Line_PORT,&pPort,65530);
        ApplVar.AP.NetWork.ServerPort = pPort;
        break;
    case casePERSONALCODE:
        SetInputMode('9');
        Appl_MaxEntry=9;//sizeof(ApplVar.AP.NetWork.ECR_ID)*2;
        if (Appl_EntryCounter)
            SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
        if (GetString(Prompt.LineCap[Line_PERSONALCODE], ApplVar.AP.NetWork.ECR_ID, Appl_MaxEntry))
            break;
    case caseAESKEY: //ccr2017-11-02����AES����
        HEXtoASCL(SysBuf,ApplVar.AP.NetWork.SecurityCode,32);
        SysBuf[64]=0;
        i=GetStrFromKBD('*',(char*)MsgAESKey,SysBuf,64,0,YES);
        if (BIT(i,NEWSTRING) &&
            (EXCEPTBIT(i,NEWSTRING)!=64 ||(!StrToBCDValueL(ApplVar.AP.NetWork.SecurityCode,SysBuf,32))))
        {//��������64λ���ȵ���Ч16��������
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            break;
        }
        SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
        Appl_EntryCounter=0;
        Appl_BitNumber=0;
        Appl_ProgLine=caseGPRSSEND; //break;
    case caseGPRSSEND://GPRS SEND?(YES/NO)
        Appl_MaxEntry = 0;
        //Appl_EntryCounter = 0;
        if (!Appl_BitNumber)
            Appl_BitNumber = BIT(ApplVar.DaysMust,BIT7) ? 2:1;
        else
            SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ

        if (Appl_BitNumber > 2  )
            Appl_BitNumber = 1;
        if (Appl_BitNumber==1)
            RESETBIT(ApplVar.DaysMust,BIT7);
        else
            SETBIT(ApplVar.DaysMust,BIT7);

        CopyFrStr(ProgLineMes+SETUPMARIN, Msg[GPRSSEND].str);

#if ((DISP2LINES) )
        memcpy(ProgLine1Mes+ DISLEN - 3,Prompt.LineCap[Line_YES+2-Appl_BitNumber],3);
#else
        memcpy(ProgLineMes+ DISLEN - 3,Prompt.LineCap[Line_YES+2-Appl_BitNumber],3);
#endif
        break;
    case caseGPRSAPN:
        if (BIT(ApplVar.DaysMust,BIT7))
        {
            SetInputMode('a');
            Appl_MaxEntry=sizeof(ApplVar.AP.NetWork.APN)-1;
            ApplVar.AP.NetWork.APN[Appl_MaxEntry]=0;
            if (Appl_EntryCounter)
                SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
            if (GetString((char*)MsgGPRSAPNNAME, ApplVar.AP.NetWork.APN, Appl_MaxEntry))
                break;
        }
    case caseUSERNAME://ccr2015-03-11>>>>>>>>
        if (BIT(ApplVar.DaysMust,BIT7))
        {
            SetInputMode('a');
            Appl_MaxEntry=sizeof(ApplVar.AP.NetWork.UserName)-1;
            ApplVar.AP.NetWork.UserName[Appl_MaxEntry]=0;
            if (Appl_EntryCounter)
                SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
            if (GetString((char*)MsgGPRSUSERNAME, ApplVar.AP.NetWork.UserName, Appl_MaxEntry))
                break;
        }
    case casePASSWORD:
        if (BIT(ApplVar.DaysMust,BIT7))
        {
            if (ApplVar.AP.NetWork.UserName[0])
            {
                SetInputMode('a');
                Appl_MaxEntry=sizeof(ApplVar.AP.NetWork.Password)-1;
                ApplVar.AP.NetWork.Password[Appl_MaxEntry]=0;
                if (Appl_EntryCounter)
                    SETMyFlags(CONFIGECR);//�޸�������ĵ�ǰֵ
                if (GetString((char*)GPRSPASSWORD, ApplVar.AP.NetWork.Password, Appl_MaxEntry))
                    break;
            }//ccr2015-03-11<<<<<<<<<<<
        }
    case casePRINTNETFUNC://print settings
        //��ӡ��������
        if (WaitForYesNo(Msg[PRINTSETTINGS].str,0,0,true)=='Y')
        {
            PrintStr_Center(MSG_SETTINS4NETFUNC,true);
            memset(ProgLineMes,' ',PRTLEN);
            i = BIT(ApplVar.AP.NetWork.Option,MINISTRYFlag) ? 0:1;
            CopyFrStr(ProgLineMes, Msg[MINISTRYSEND].str);
            strcpy(ProgLineMes+ PRTLEN - 3,Prompt.LineCap[i]);
            RJPrint(0,ProgLineMes);

            Print2Strings((char*)Msg[SERVERURL].str,ApplVar.AP.NetWork.ServerURL);

            memset(ProgLineMes,' ',PRTLEN);
            CopyFrStr(ProgLineMes,MsgSERVERIP);
            NumToIP(ProgLineMes+PRTLEN-1, ApplVar.AP.NetWork.ServerIP,0);
            ProgLineMes[PRTLEN]=0;
            RJPrint(0,ProgLineMes);


            memset(ProgLineMes,' ',PRTLEN);
            CopyFrStr(ProgLineMes, Prompt.LineCap[Line_PORT]);
            WORDtoASC(ProgLineMes+PRTLEN-1,ApplVar.AP.NetWork.ServerPort);
            ProgLineMes[PRTLEN]=0;
            RJPrint(0,ProgLineMes);

            //memset(ProgLineMes,' ',PRTLEN);
            //CopyFrStr(ProgLineMes, Prompt.LineCap[Line_PERSONALCODE]);
            //HEXtoASCx0(ProgLineMes+PRTLEN-1,ApplVar.AP.NetWork.ECR_ID,sizeof(ApplVar.AP.NetWork.ECR_ID));
            //ProgLineMes[PRTLEN]=0;
            //RJPrint(0,ProgLineMes);
            Print2Strings((char*)Prompt.LineCap[Line_PERSONALCODE],ApplVar.AP.NetWork.ECR_ID);

            HEXtoASCL(SysBuf,ApplVar.AP.NetWork.SecurityCode,32);
            SysBuf[64]=0;
            Print2Strings((char*)MsgAESKey,SysBuf);

            memset(ProgLineMes,' ',PRTLEN);
            i = BIT(ApplVar.DaysMust,BIT7) ? 0:1;
            CopyFrStr(ProgLineMes, Msg[GPRSSEND].str);
            strcpy(ProgLineMes+ PRTLEN - 3,Prompt.LineCap[i]);
            RJPrint(0,ProgLineMes);

            Print2Strings((char*)MsgGPRSAPNNAME,ApplVar.AP.NetWork.APN);
            Print2Strings((char*)MsgGPRSUSERNAME,ApplVar.AP.NetWork.UserName);
            Print2Strings(GPRSPASSWORD,ApplVar.AP.NetWork.Password);
            RFeed(PREHEADER+2);
        }
    default:
#if (0)//defined(CASE_ETHERNET)
        if (Appl_EntryCounter)//�������µĶ˿�����ʱ,�Զ��˳�����
            Ethernet_Start();
#endif
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        EXIT;//ccr2015-10-12�˳�����
        if (MyFlags(REBOOTMUST))//�޸�������ĵ�ǰֵ
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI118);//ccr2017-09-26��Ҫ���������տ��
            CLRMyFlags(REBOOTMUST);
        }
        break;
    }

#if 0    //>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    case 3:
        SetInputMode('9');
        Appl_MaxEntry = 6;
        Appl_BitNumber = 0;
        if (ApplVar.AP.NetWork.ClientPort==0)
            ApplVar.AP.NetWork.ClientPort = 11024;//Ĭ��11024
        pPort = ApplVar.AP.NetWork.ClientPort;
        GetWordValue(Line_PORT,&pPort,65530);
        ApplVar.AP.NetWork.ClientPort = pPort;
#if (0)//defined(CASE_ETHERNET)
        if (Appl_EntryCounter)
            Ethernet_Start();
#endif
        break;



    case 5:
        SetInputMode('9');
        Appl_MaxEntry = 6;
        Appl_BitNumber = 0;
        if (ApplVar.AP.NetWork.ServerPort==0)
            ApplVar.AP.NetWork.ServerPort = 11024;//Ĭ��11024
        pPort = ApplVar.AP.NetWork.ServerPort;
        GetWordValue(Line_PORT,&pPort,65530);
        ApplVar.AP.NetWork.ServerPort = pPort;
        break;

    default:
        Appl_MaxEntry = 6;
        Appl_ProgLine = 0;
        EXIT;//ccr2015-10-12�˳�����
        break;
    }
#endif//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
}
#endif


#endif

#if defined(CASE_GPRS)
void  ProgGPRSFuncs()
{
    WORD sInput;

        do
        {
            sInput = ListItems(SETGPRSFUNC,0,"GPRS",true,true);
            switch (sInput)
            {
            case (gprsSETMODE -GPRSFUNC1ST+1):
                GPRS_SetSendMode();                //Ccr���÷��ͷ�ʽ//
                break;
            case (gprsSendECRLog -GPRSFUNC1ST+1):
                GPRSSendECR_FM();                 //Ccr������ˮ//
                break;
            case (gprsSendECRLogAll -GPRSFUNC1ST+1):
                GPRSSendECR_FM_All();                 //Ccr����ȫ����ˮ//
                break;
            case (gprsDownloadPLU -GPRSFUNC1ST+1):
                GPRS_DownloadPLU();         //"���ص�Ʒ�ļ�"
                break;
            case (gprsDownloadDEPT -GPRSFUNC1ST+1):
                GPRS_DownloadDEPT();            //"���ز����ļ�"
                break;
            case (gprsDownloadCLERK -GPRSFUNC1ST+1):
                GPRS_DownloadCLERK();          //"�����տ�Ա"
                break;
            case (gprsDownloadHEAD -GPRSFUNC1ST+1):
                GPRS_DownloadHEAD();           //"����Ʊͷ"
                break;
            case (gprsDownloadTRAIL -GPRSFUNC1ST+1):
                GPRS_DownloadPTRAIL();          //"����Ʊβ"
                break;
            case (gprsDownloadALL -GPRSFUNC1ST+1):
                GPRS_DownloadALL();          //"����ȫ������"
                break;
            case (gprsSENDMESS -GPRSFUNC1ST+1)://
                TestSendMess();                    //Ccr���Ͷ���Ϣ//
                break;
            case (gprsRestart -GPRSFUNC1ST+1):
                GPRS_Restart();          //"��λGPRS"
                //break;
            case 0:
            case It_EXIT:
            default:
                Appl_MaxEntry = 6;
                Appl_ProgLine = 0;
                ProgType_Last = Appl_ProgType-1;
                Appl_ProgType = 0;
                Appl_ProgStart = 0;
                ENTER;//EXIT;//ccr2015-10-12�˳�����
                return;
            }
        } while (true);

}
#endif

#if defined(CASE_ETHERNET)

void  ProgEthernetFuncs()//NET FUNCTIONS
{
    WORD sInput;
    do
    {
        sInput = ListItems(SETETHERNETFUNC,0,"ETHERNET",true,true);
        switch (sInput)
        {
        case (net_PINGMESS -net_PINGMESS+1)://
            PingEthernet();                    //Ccr�������//
            break;
        case (net_SETMODE -net_PINGMESS+1):
            ETHERNET_SetSendMode();                //Ccr���÷��ͷ�ʽ//
            break;
        case (net_SendECRLog -net_PINGMESS+1):
            ETHERNETSendECR_FM();                 //Ccr������ˮ//
            break;
        case (net_SendECRLogAll -net_PINGMESS+1):
            ETHERNETSendECR_FM_All();                 //Ccr����ȫ����ˮ//
            break;
        case (net_UpdatePLU -net_PINGMESS+1):
            ETHERNET_DownloadPLU();         //"���ص�Ʒ�ļ�"
            break;
        case (net_UpdateDEPT -net_PINGMESS+1):
            ETHERNET_DownloadDEPT();            //"���ز����ļ�"
            break;
        case (net_UpdateCLERK -net_PINGMESS+1):
            ETHERNET_DownloadCLERK();          //"�����տ�Ա"
            break;
        case (net_UpdateHEAD -net_PINGMESS+1):
            ETHERNET_DownloadHEAD();           //"����Ʊͷ"
            break;
        case (net_UpdateTRAIL -net_PINGMESS+1):
            ETHERNET_DownloadPTRAIL();          //"����Ʊβ"
            break;
        case (net_UpdateALL -net_PINGMESS+1):
            ETHERNET_DownloadALL();          //"����ȫ������"
            break;
        case (net_Restart -net_PINGMESS+1):
            ETHERNET_Restart();          //"��λETHERNET"
            break;
        case 0:
        case It_EXIT:
        default:
            Appl_MaxEntry = 6;
            Appl_ProgLine = 0;
            EXIT;//ccr2015-10-12�˳�����
            return;
        }
    } while (true);

}

/**
 * ����MAC��ַ------
 *
 * @author EutronSoftware (2017-02-28)
 */
BYTE OTPFlash_WriteMAC(BYTE* pBuffer);
void ProgMAC()
{
    BYTE sMAC[6];
    BYTE sKey;

#if !defined(DEBUGBYPC)
    sMAC[5]=MAC_ADDR[0];
    sMAC[4]=MAC_ADDR[1];
    sMAC[3]=MAC_ADDR[2];
    sMAC[2]=MAC_ADDR[3];
    sMAC[1]=MAC_ADDR[4];
    sMAC[0]=MAC_ADDR[5];
#endif
    Appl_EntryCounter=0;

    DisplayHex(sMAC,6,1);
    if (CLONG(sMAC[0])==0xffffffff)
    {
        if (GetStrFromKBD('*',"MAC",NULL,12,0,NO)>0)
        {
            StrToBCDValue(sMAC, &AtEntryBuffer(1), 6);
            DisplayHex(sMAC,6,0);
    #if ((DISP2LINES) )
            Puts1("Confirm?");
    #endif
            WAIT_INPUT(sKey);
    #if ((DISP2LINES) )
            Puts1(Msg[SPACE].str);
    #endif
            if (sKey==ENTERKey)
            {
                sKey=sMAC[0];sMAC[0]=sMAC[5];sMAC[5]=sKey;
                sKey=sMAC[1];sMAC[1]=sMAC[4];sMAC[4]=sKey;
                sKey=sMAC[2];sMAC[2]=sMAC[3];sMAC[3]=sKey;
    #if !defined(DEBUGBYPC)
                OTPFlash_WriteMAC(sMAC);
    #endif
            }
        }
    } else
    {
        WAIT_INPUT(sKey);
    }
}
#endif

//ccr2017-05-08>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
/**
 * ɾ����ǰƱͷ,�����Ʊͷ��ǰ�춯
 *
 * @author EutronSoftware (2016-01-19)
 *
 * @param hIdx :Ʊͷ���(0..7)
 */
void DeleteHeader(BYTE hIdx)
{
    if (hIdx<(HEADLINES-1))
        memcpy(ApplVar.TXT.Header[hIdx],ApplVar.TXT.Header[hIdx+1],(PRTLEN+1)*(HEADLINES-hIdx));
    memset(ApplVar.TXT.Header[HEADLINES-1],0,(PRTLEN+1));
    ApplVar.FMPullOut[NEWHEAD_FLAG]=0x69;
}

/**
 * ɾ����ǰƱβ,�����Ʊͷ��ǰ�춯
 *
 * @author EutronSoftware (2016-01-19)
 *
 * @param hIdx :Ʊͷ���(0..7)
 */
void DeleteTrailer(BYTE hIdx)
{
    if (hIdx<5)
        memcpy(ApplVar.TXT.Trailer[hIdx],ApplVar.TXT.Trailer[hIdx+1],(PRTLEN+1)*(6-hIdx));
    memset(ApplVar.TXT.Trailer[5],0,(PRTLEN+1));
}

/**
 * ɾ����ǰ����Ʊβ,�����Ʊͷ��ǰ�춯
 *
 * @author EutronSoftware (2016-01-19)
 *
 * @param hIdx :Ʊͷ���(0..7)
 */
void DeleteSlipHead(BYTE hIdx)
{
    if (hIdx<5)
        memcpy(ApplVar.TXT.SlipHeader[hIdx],ApplVar.TXT.SlipHeader[hIdx+1],(SHEADWIDTH+1)*(6-hIdx));
    memset(ApplVar.TXT.SlipHeader[5],0,(SHEADWIDTH+1));
}

/*************************************************************
 * �տ���ĸ�������
 *
 * @author EutronSoftware (2017-05-10)
 **********************************************************/

void  ProgAuxFunctions()
{
    WORD sInput,pwd;
    int i;
    do
    {
        sInput = ListItems(SETAUXFUNCS,0,"AUX FUNCTIONS",false,true);

        if (sInput>=1 && sInput<=AUX_FUNCITEMS)
        {
            switch (sInput-1)
            {
            case AUX_PRINTPLU-AUX_PRINTPLU://��ӡ��Ʒ��Ϣ
                PrintAllOfPLU();
                break;
#ifdef CASE_FATFS_EJ//��ѯ��ӡEJ�е��ĵ�
            case AUX_EXPLOREEJ-AUX_PRINTPLU:// Reprint Invoice documents from EJ;
                switch(ListItems(AUX_EXPLOREEJ,0,Msg[AUX_EXPLOREEJ].str,false,true))
                {
                case (EJPrintReceipt-EJPrintReceipt+1):       //��ѯ�����վ�
                    PrintEJReceipt();
                    break;
                case (EJPrintZRport-EJPrintReceipt+1):          //��ѯZ����
                    PrintEJZReport();
                    break;
//                case It_EXIT:
                default:
                    //EXIT;
                    break;
                }
                SetItemDefault(SETAUXFUNCS,CMD_EXPLOREEJ);
                break;
#endif
            case AUX_PRINTFISCAL-AUX_PRINTPLU://��ӡ������˰����Ϣ
                PrintMemoForFiscal();
                break;
            case AUX_PRINTEJ-AUX_PRINTPLU://��ӡEJ��Ϣ
                if (CheckInFiscalMode())
                {
                    PrintEJInfo();
                    RFeed(1);
                }
                break;
            case AUX_SETPWDX-AUX_PRINTPLU://Set password for X
                pwd=SetPassword(0,ApplVar.AP.ModePwd.PwdX,X);
                break;
            case AUX_SETPWDZ-AUX_PRINTPLU://Set password for Z
                pwd=SetPassword(0,ApplVar.AP.ModePwd.PwdZ,Z);
                break;
            case AUX_SETPWDSET-AUX_PRINTPLU://Set password for SET
                pwd=SetPassword(0,ApplVar.AP.ModePwd.PwdSET,SET);
                break;
            case AUX_SETPWDMG-AUX_PRINTPLU://Set password for MG
                pwd=SetPassword(0,ApplVar.AP.ModePwd.PwdMG,MG);
                break;
            case AUX_INITFISCAL-AUX_PRINTPLU://FUNC800,˰�س�ʼ��
                CheckFiscal(false);
                if (ApplVar.FiscalFlags == FMISNEW)  /* new card */
                {
/*ccr2014-PANAMA-TRAIN
                    if (MyFlags(ZREPORT))   //z report taken ?
                    {
                        ApplVar.ErrorNumber=ERROR_ID(CWXXI75);
                        ApplVar.FuncOnEnter = 0; //liuj 0528
                        return TRUE;
                    }
*/
                    Initial_Fiscal();
                }
                else
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI79);     /* already initialied */
                //���ϴ����ʱ,��������ʾ��ʼ��EJ  EXIT;
                break;
#if(defined(CASE_FATFS_EJ))
            case AUX_INITEJ-AUX_PRINTPLU:
                Initial_EJ();//ccr091125
                //���ϴ����ʱ,�������EJ��ʼ����� EXIT;
                break;
#endif
            case AUX_PRNGAPHIC-AUX_PRINTPLU:       //print graphics
                StoreEJEnd();//ccr070609pm

                for (i=1;i<=GRAPHICMAX;i++)
                {//�����Զ���ͼƬ
                    memset(SysBuf,' ',PRTLEN);

                    CopyFrStr(SysBuf,Msg[SETGRAP].str);

                    WORDtoASC(SysBuf+PRTLEN-5,i);

                    RJPrint(0,SysBuf);
                    Bios(BiosCmd_PrintGraph, (void*)(i), 1 , 0); //�����Դ�����
                }
                CutRPaper(2);RFeed(4);//ccr070612
                break;
            case AUX_ECRCONFIG-AUX_PRINTPLU:
                PrintConfInf();
                CutRPaper(2);RFeed(4);//ccr070612
                break;
#if (0)
            case CMD_RESTAURANT://��������
                if (pbNumber>10)
                {
                    PutsO(DMes[ItemDMes24]);//confirm

                    while (!KbHit())   FM_EJ_Exist();
                    if (Getch() == ENTERKey)  /*    CR is accept     */
                    {
                        memcpy((void*)&ApplVar.AP.KeyTable,(void*)&KeyTablePBF,sizeof(KeyTablePBF));
                        PutsO(DText[DTEXT_RESTAURANT]);
                        CLRMyFlags( CLOSEPRNONPB);// |
                        SETMyFlags(CONFIGECR);

                    }
                }
                break;

            case CMD_MARKET://���м���
                PutsO(DMes[ItemDMes24]);//confirm
                while (!KbHit())  FM_EJ_Exist();

                if (Getch() == ENTERKey)  /* CR is accept */
                {
                    memcpy((void*)&ApplVar.AP.KeyTable,(void*)&Default.KeyTable,sizeof(Default.KeyTable));//???????????
                    PutsO(DText[DTEXT_RETALL]);
                    CLRMyFlags( CLOSEPRNONPB);// |
                }
                break;
#endif
            }
            //ccr2017-05-15 ��������������ķ�ʽʱ�¸�����
//ccr2017-12-11            VirtualInputWORD(ENTERKey,TblAUX_Funcs[sInput-1]);
//ccr2017-12-11            Appl_ProgType=0;//ccr2017-12-05
//ccr2017-12-11            sInput=0;
        }
//        if (sInput==0 || sInput==It_EXIT)
        {
            Appl_ProgStart=0;
            Appl_MaxEntry = 6;
            Appl_ProgLine = 0;
        }
        ProgType_Last=Appl_ProgType-1;//����ֱ��ѡ�����һ�ν��������
        Appl_ProgType = 0;//�޴����ʱ,���˲��� Appl_ProgType��ָ������
        ENTER;//ccr2018-01-18
        break;
    } while (true);
}
/*************************************************************************
 * �������ַ�����ϴ�ӡ���,����Ϻ�ĳ��ȴ�ӡ��ӡ������ʱ,�����д�ӡ
 * ���е�strMess�Ҷ����ӡ
 * @author EutronSoftware (2017-09-20)
 *
 * @param strPrompt
 * @param strMess
 ************************************************************************/
void Print2Strings(char* strPrompt,char* strMess)
{
    int i;

    i=strlen(strMess);
    if (i+strlen(strPrompt)>PRTLEN)
    {
        RJPrint(0,strPrompt);
        PrintLongString(strMess,true);
    }
    else
    {
        memset(ProgLineMes,' ',PRTLEN);
        CopyFrStr(ProgLineMes,strPrompt);
        strcpy(ProgLineMes+PRTLEN-i,strMess);
        RJPrint(0,ProgLineMes);
    }
}

