#ifndef MESSAGE_H
#define MESSAGE_H

#if (defined(DEBUGBYPC) || defined(FOR_DEBUG))
#include "MessageEN.h"//captions for current mode
#elif(VV_RUSSIA)
#include "MessageRU.h"
#elif (CASE_SPANISH)
#include "MessageSP.h"
#elif (CASE_GREECE)
#include "MessageGREECE.h"
#elif (0)//CASE_ITALIA)
#include "MessageITA.h"
#else
#include "MessageEN.h"//captions for current mode
#endif

#endif
