#define TENDER_C 5
#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
#include "flowbill.h" //lyq200
#if 0	//cc 20070930
#if !defined(FISCAL)
#include "ePosCard.h"//ccr epos
#endif
#endif
#include "fiscal.h"
#if (defined(CASE_GPRS))
#include "Gprs.h"
#endif

#if (PC_EMUKEY==1)
#include "FEcrTest.h"
#endif
/*   *****************************************************************    */
void GetTenderOffSet()
{
   RamOffSet = ApplVar.TendNumber * ApplVar.AP.Tend.RecordSize + ApplVar.AP.StartAddress[AddrTend];
}

void AddTenderTotal()
{
   GetTenderOffSet();
   RamOffSet += ApplVar.AP.Tend.TotalOffSet;
   for (ApplVar.PointerType = 0; ApplVar.PointerType < REPDEFMAX; ApplVar.PointerType++)
   {
      ApplVar.Size = ApplVar.AP.Tend.Size[ApplVar.PointerType];
      AddPointerTotal();
   }
}

void WriteTender()
{
   if (ApplVar.TendNumber < ApplVar.AP.Tend.Number)
   {
      GetTenderOffSet();
      WriteRam((BYTE *)&ApplVar.Tend, ApplVar.AP.Tend.TotalOffSet);      /* write function options */
   }
}

void ReadTender()
{
   GetTenderOffSet();

   ReadRam((BYTE *)&ApplVar.Tend, ApplVar.AP.Tend.TotalOffSet);    /* write function options */
   ApplVar.Tend.Name[ApplVar.AP.Tend.CapSize] = 0;
}


void Tender()
{
   BYTE	payIC = 0; //ccr chipcard ccr epos:=1ΪIC�� ��2 ΪePos //
   BCD	sSave, sTotal;
   BYTE	sEntryCou;
   WORD	sKeyCode;
   long sAmount;
   BYTE endOfTend=0;//ccr2018-03-07��ʾ�����Ƿ����

   if (BIT(CLERKFIX, BIT7) && !ApplVar.FSub && !ApplVar.FTend) //ccr101111
   {
      ApplVar.ErrorNumber = ERROR_ID(CWXXI46);
      return;
   }

   if (ApplVar.FRefund == 1 && ApplVar.FRegi == 0)
   { //ccr 050111
      ApplVar.ErrorNumber = ERROR_ID(CWXXI01);
      ApplVar.FRefund = 0;
      return;
   }
#if defined(CASE_EURO) //!!! GREECE_ONLY !!!
   if (ApplVar.Key.Code == TEND && ApplVar.FRegi && !Appl_EntryCounter)
   { //ccr2017-12-18 ���б���ѡ�񸶿ʽ
      switch (sKeyCode = ListItems(SETTEND, true, 0, false, NO))
      {
      case It_EXIT:    //�˳�����
      case 0:         //��Items
         return;
      default: //�������³����ʱ,ֱ�ӽ�������
         ApplVar.Key.Code = TEND + sKeyCode;
         break;
      }
   } //ccr2017-12-18  <<<<<<<<<<<<<<<<<<<<<<<
#endif
#if 0	//cc 20070930
   if (ApplVar.Key.Code == (TEND + 5) && !ApplVar.ePosPort)
   {
      ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
      return;
   }
#endif
#if (DD_CHIPC==1)
//Ccr chipcard>>auto discount>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#if (CASE_MFRIC==1)
   if (ApplVar.Key.Code == (TEND + 6))
   {
      if (ApplVar.MFRCardPort == 0)
      {
         ApplVar.ErrorNumber = ERROR_ID(CWXXI72);
         return;
      }
      else
      {
         PutsO(Msg[WAITEICCARD].str);
         if (!ChipCard() || IC.CHIP_Flag <= 0)
         {
            if (!ApplVar.ErrorNumber) ApplVar.ErrorNumber = ERROR_ID(CWXXI50);
            return;
         }
         else PrintChipCard(0);
      }
   }
#else
   if (ApplVar.Key.Code == (TEND + 6) && IC.CHIP_Flag <= 0)
   {
      ApplVar.ErrorNumber = ERROR_ID(CWXXI50);
      return;
   }

   if (IC.CHIP_Flag > 0 && !Appl_EntryCounter && ApplVar.Key.Code == TEND + 1
       && BIT(ApplVar.ICCardSet.Options, IC_TOT_CC)) //ccr chipcard
      ApplVar.Key.Code = TEND + 6; //ChipCard payment
#endif

   if ((IC.CHIP_Flag == 0 || (IC.CHIP_Flag == 1 || IC.CHIP_Flag == 2) && ApplVar.Key.Code == (TEND + 6))
       && !BIT(IC.ICState, IC_DISCOUNT) && BIT(ApplVar.ICCardSet.Options, IC_DISCOUNT) && ApplVar.FRegi //ccr040809
       && CWORD(IC.REC_Customer[CC_CPERC]) != 0) //ccr chipcard
   {
      SETBIT(IC.ICState, IC_DISCOUNT);
      sSave = ApplVar.Entry;
      sEntryCou = Appl_EntryCounter;
      sKeyCode = ApplVar.Key.Code;
      Appl_EntryCounter = 0;
      if (!ApplVar.FSub)
      {
         ApplVar.Key.Code = SUB;
         Fixed();
      }
      for (ApplVar.DiscNumber = 0; ApplVar.DiscNumber < ApplVar.AP.Disc.Number; ApplVar.DiscNumber++)
      {
         GetDiscOffSet();
         ReadDisc();
         if (ApplVar.Disc.Options == 0x11)  //Discount %
            break;
      }
      if (ApplVar.DiscNumber >= ApplVar.AP.Disc.Number);
      ApplVar.DiscNumber = 1;

      ApplVar.Key.Code = ApplVar.DiscNumber + DISC + 1;
      Appl_EntryCounter = 0;
      icBCD2EcrBCD(&ApplVar.Entry, (char *)&IC.REC_Customer[CC_CPERC], 2);
      Discount();
      ApplVar.Key.Code = sKeyCode;
      Appl_EntryCounter = sEntryCou;
      ApplVar.Entry = sSave;
   }
#endif

#if defined(CASE_EURO)
   //input Customer receipt card
#if (PC_EMUKEY)
   if (!FisTestTask.Going) //�Զ���������ʱ��������Customer card
#endif
      if (!ApplVar.FTend && ApplVar.FRegi && RECEIPT_CARD)
      {
         sSave = ApplVar.Entry;
         sEntryCou = Appl_EntryCounter;
         sKeyCode = ApplVar.Key.Code;

         memset(ApplVar.UserInfo.FVatNo, 0, sizeof(ApplVar.UserInfo.FVatNo));
         if (GetStrFromKBD('9', (char *)MsgCUSTOMERCARD, NULL, 19, 0, NO) > 0) //CUSTOMER RECEIPT CARD,19λ����
         {
            strncpy(ApplVar.UserInfo.FVatNo, &AtEntryBuffer(Appl_EntryCounter), 19);
         }
         ApplVar.Key.Code = sKeyCode;
         Appl_EntryCounter = sEntryCou;
         ApplVar.Entry = sSave;
      }
#endif

   if (ApplVar.FSub || ApplVar.FTend) //ccr2014-12-22
      sSave = ApplVar.SubTotal;
   else sSave = ApplVar.SaleAmt;

#if defined(FISCAL) && DD_FISPRINTER == 0
   if (CheckNotZero(&sSave) && sSave.Sign & 0x80)    //ccr2014-08-06	// not allow negative
   {
      ApplVar.ErrorNumber = ERROR_ID(CWXXI101);
      return;
   }

   CalculateTax(5); //������۽��/˰���Ƿ�<0
                    //ccr2017-12-14>>>>>>>>>>>>
   if (ApplVar.ErrorNumber == ERROR_ID(CWXXI101)) return; //������˰��Ϊ��
                                                          //ccr2017-12-14<<<<<<<<<<<<
   if (CheckNotZero(&ApplVar.Qty) && ApplVar.Qty.Sign & 0x80) //ccr2014-08-06		// not allow negative
   { //��˰�ܶ�򸶿���Ϊ����
      ApplVar.ErrorNumber = ERROR_ID(CWXXI101);
      return;
   }
   ApplVar.Qty = ZERO;


#endif


#if (DD_CHIPC==1)
   if ((IC.CHIP_Flag == 0 || (IC.CHIP_Flag > 0  && ApplVar.Key.Code == TEND + 6)) &&
       ApplVar.FRegi && CheckNotZero(&sSave)) //Chipcard payment 040805
   {
      if (!Appl_EntryCounter) //Chipcard payment 040805
      {
         PayByChipCard(&sSave, FALSE); //���Կ��Ͻ���Ƿ��㹻���� //
         if (ApplVar.ErrorNumber) return;
      }

      if (!BIT(IC.ICState, IC_POINTS)) //ccr 040805
      {
         if (!BIT(sSave.Sign, BIT7))
         {
            if (BIT(ApplVar.ICCardSet.Options, IC_REPORT)) payIC = 1;
            PointsByChipCard(&sSave);
         }
      }
   }
//ccr chipcard<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#endif

   ApplVar.TendNumber = ApplVar.Key.Code - TEND - 1;
   if (ApplVar.TendNumber < ApplVar.AP.Tend.Number)
   {
      ReadTender();       /* read function */
   }
   else
   {
      ApplVar.ErrorNumber = ERROR_ID(CWXXI42);
      return;
   }
   if ((BIT(PBINFO, BIT3) && ApplVar.FPb) || BIT(ApplVar.FNoPb, BIT1))       /* pb used ? */
   {
      ApplVar.ErrorNumber = ERROR_ID(CWXXI07);
      return;
   }

   if (!Appl_EntryCounter)
   {
      if (BIT(ApplVar.Tend.Options, BIT1) && !ApplVar.FRefund)   /* entry compulsory ? */
      {
         if (!BIT(ApplVar.SaleAmt.Sign, BIT7))   /* negative then allowed */
         {
            ApplVar.ErrorNumber = ERROR_ID(CWXXI43);
            return;
         }
      }
   }
   else
   {
      if (BIT(ApplVar.Tend.Options, BIT2) && !ApplVar.FRefund)   /* no entry allowed ? */
      {
         ApplVar.ErrorNumber = ERROR_ID(CWXXI04);
         return;
      }
   }
   if (AmtInputMask()) return;
   if (ApplVar.FRegi)
   {
      if (BIT(ApplVar.Tend.Options, BIT3) && !ApplVar.FNum)   /* number entry ? */
      {
         ApplVar.ErrorNumber = ERROR_ID(CWXXI30);
         return;
      }
   }
#if DD_FISPRINTER == 0	//liuj0911
   if (ApplVar.FRefund)
   {

      if (ApplVar.FCurr || ApplVar.FCanc || !Appl_EntryCounter)
      {
         ApplVar.ErrorNumber = ERROR_ID(CWXXI01);
         return;
      }
#if defined(FISCAL)
      ApplVar.FStatus = 0;        /* set non fiscal receipt */
#endif

      if (RegiStart()) return;
      ApplVar.SubTotal = ApplVar.Entry;
      Add(&ApplVar.SubTotal, &ApplVar.Entry);
      ApplVar.FTend = 1;
      ApplVar.FRegi = 1;
      SETMyFlags(OPENRECEIPT); //ccr2017-05-23
#if(CASE_RAMBILL)
      Collect_Data(REGISLOG);
#endif
   }
#endif
   if (ApplVar.PbNumber) ApplVar.Tend.Print = ApplVar.PbF.Print;

   ApplVar.PrintLayOut = ApplVar.Tend.Print;
   if (BIT(ApplVar.Tend.Options, BIT5))   /* if set no tax calc */
      ApplVar.FNoTax = 1;

   if (!ApplVar.FTend)   /* already in tender ? */
   {
      if (ApplVar.FRegi)   /* registration */
      {
         ApplVar.BufKp = 1;          /* set ApplVar.KP not printed yet */
         CalculateTax(0);	    /* calculate and add report */   //@@@@@@@@@@@
         if (ApplVar.PbNumber)
         {
            ClearPb();
#if !defined(FISCAL)
            if (BIT(PBINFO, BIT4)) AddReceiptNumber(); // liuj 0704
#endif
            AmtRound(0, &ApplVar.SubTotal);     /* total sales rounding */
            if (BIT(ApplVar.FNoPb, BIT2))   /* store ApplVar.PbInvoice ? */
            {
               StorePbInvoice(0);
            }
         }
      }
      else CalculateTax(1);        /* calulate and not add report */
   }

   if (!Appl_EntryCounter)
   {
#if (DD_CHIPC==1)
//ccr chipcard>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (IC.CHIP_Flag > 0 && (ApplVar.Key.Code == TEND + 6) && ApplVar.FRegi
          && CheckNotZero(&ApplVar.SubTotal)) //Chipcard payment 040805
      {
         PayByChipCard(&ApplVar.SubTotal, true);
         if (ApplVar.ErrorNumber)
         {
            IC.CHIP_Flag = RD_ChipCard();
            return;
         }
         if (BIT(ApplVar.ICCardSet.Options, IC_REPORT)) payIC = 1;
      }
//ccr chipcard<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#endif
      ApplVar.Entry = ApplVar.SubTotal;
      ApplVar.Amt = ApplVar.SubTotal;
      if (ApplVar.FCurr) GetCurrency(0, &ApplVar.Entry);   /* subtotal to currency */
   }
   else
   {
//		ApplVar.Entry.Sign = ApplVar.SubTotal.Sign;
      ApplVar.Amt = ApplVar.Entry;    /* entry has sign of total positive */
      if (ApplVar.FCurr) GetCurrency(1, &ApplVar.Amt);   /* entry to local */
   }
   if (ApplVar.FCurr) ApplVar.AmtDecimal = ApplVar.Curr.Options & BIT0;   /* decimal in amount ? */
   if (Appl_EntryCounter)
   {
      if (CompareBCD(&ApplVar.SubTotal, &ApplVar.Amt) < 1)    /* overtendering ? */
      {
         RESETBIT(ARROWS, BIT1); /* reset RG led */
         if (BIT(ApplVar.Tend.Options, BIT4))   /* overtender is tipp? */
         {
#if(DD_ZIP==1)
            if (ApplVar.FCurr) PutsO(DText[DTEXT_CURRENCY]);
            else PutsO(DText[DTEXT_TOTAL]);
            Puts1(DispAmtStr(0, &ApplVar.Entry, DISLEN));
#elif(DD_ZIP_21==1)
            Puts1(DispAmtStr(0, &ApplVar.Entry, DISLEN));
            if (ApplVar.FCurr)
            {
               PutsO(DText[DTEXT_CURRENCY]);
               if (SysBuf[sizeof(SysBuf) - DISLENC + 3] == ' ') CopyFrStr(&SysBuf[sizeof(SysBuf) - DISLENC], CusDText[ItemDTextCUR]);
               PutsC(&SysBuf[sizeof(SysBuf) - DISLENC]);
            }
            else
            {
               PutsO(DText[DTEXT_TOTAL]);
               if (SysBuf[sizeof(SysBuf) - DISLENC + 3] == ' ') CopyFrStr(&SysBuf[sizeof(SysBuf) - DISLENC], CusDText[ItemDTextTOT]);
               PutsC(&SysBuf[sizeof(SysBuf) - DISLENC]);
            }
#else
            if (ApplVar.FCurr)
            {
               PutsO(DispAmtStr(DText[DTEXT_CURRENCY], &ApplVar.Entry, DISLEN));
            }
            else
            {
               PutsO(DispAmtStr(DText[DTEXT_TOTAL], &ApplVar.Entry, DISLEN));
            }
#endif
         }
         else
         { //��ʾ������
            ApplVar.AmtDecimal = NO_DECIMAL;     /* local format */
            ApplVar.Price = ApplVar.Amt;
            Subtract(&ApplVar.Price, &ApplVar.SubTotal);
#if(DD_ZIP==1)
            Puts1(DispAmtStr(DText[DTEXT_CHANGE], &ApplVar.Price, DISLEN)); //ccr20131104
#elif(DD_ZIP_21==1)
            Puts1(DispAmtStr(DText[DTEXT_CHANGE], &ApplVar.Price, DISLEN)); //ccr20131104
            PutsC(DispAmtStr(CusDText[ItemDTextCHG], &ApplVar.Price, DISLENC)); //ccr20131104
#else
            PutsO(DispAmtStr(DText[DTEXT_CHANGE], &ApplVar.Price, DISLEN));
#endif
         }
         if (!ApplVar.FRegi)       /* registration */
            ApplVar.FTend = 0;
      }
      else
      {           /* undertendering */
         ApplVar.Price = ApplVar.SubTotal;
         ApplVar.AmtDecimal = NO_DECIMAL;
         Subtract(&ApplVar.Price, &ApplVar.Amt);
         //��ʾ�������
//ccr20131104>>>>>>>>>>>>
#if(DD_ZIP==1)
         PutsO(DispAmtStr(DText[DTEXT_OBLI], &ApplVar.Price, DISLEN));
#elif(DD_ZIP_21==1)
         PutsO(DispAmtStr(DText[DTEXT_OBLI], &ApplVar.Price, DISLEN));
         PutsC(DispAmtStr(CusDText[ItemDTextSUB], &ApplVar.Price, DISLENC));
#else
         PutsO(DispAmtStr(DText[DTEXT_OBLI], &ApplVar.Price, DISLEN)); /*    sub in local     */
#endif
//<<<<<<<<<<<<<<
         if (!ApplVar.FRegi)
         {
            ApplVar.FTend = 1;
            ApplVar.SubTotal = ApplVar.Price;
         }
      }
   }
   else if (ApplVar.FRegi || ApplVar.FTend) /* registration or tender ? */
   {
      RESETBIT(ARROWS, BIT1); /* reset RG led */
//ccr20131104>>>>>>>>>>>>>
//�ڵ�һ����ʾӦ�ս��
#if(DD_ZIP==1)
      if (ApplVar.FCurr)
      {
         PutsO(DispAmtStr(DText[DTEXT_CURRENCY], &ApplVar.Entry, DISLEN));
      }
      else
      {
         PutsO(DispAmtStr(DText[DTEXT_TOTAL], &ApplVar.Amt, DISLEN));
      }
#elif(DD_ZIP_21==1)
      if (ApplVar.FCurr)
      {
         PutsO(DispAmtStr(DText[DTEXT_CURRENCY], &ApplVar.Entry, DISLEN));
         PutsC(DispAmtStr(CusDText[ItemDTextCUR], &ApplVar.Entry, DISLENC));
      }
      else
      {
         PutsO(DispAmtStr(DText[DTEXT_TOTAL], &ApplVar.Amt, DISLEN));
         PutsC(DispAmtStr(CusDText[ItemDTextTOT], &ApplVar.Amt, DISLENC));
      }
#else
      if (ApplVar.FCurr)
      {
         PutsO(DispAmtStr(DText[DTEXT_CURRENCY], &ApplVar.Entry, DISLEN));
      }
#if (!defined(CASE_EURO))
      else
      {
         PutsO(DispAmtStr(DText[DTEXT_TOTAL], &ApplVar.Amt, DISLEN));
      }
#endif
#endif
//<<<<<<<<<<<<<<<<<
      if (!ApplVar.FRegi) ApplVar.FTend = 0;
   }

   if (ApplVar.FRegi)   /* registration */
   {

      ApplVar.TendFlags |= (1 << ApplVar.TendNumber); //��Ǹ��ʽ

      ApplVar.AmtDecimal = NO_DECIMAL;
      if (BIT(ApplVar.Tend.Options, BIT0)) /* open drawer ? */
         ApplVar.OpDraw = 1;
      if (ApplVar.FRecIssue)
      {
         NewReceipt();
         RESETBIT(ApplVar.PrintLayOut, BIT1);
         RESETBIT(ApplVar.Tend.Print, BIT1);
      }
      ApplVar.FRecIssue = 0;
      StoreInBuffer();
      ApplVar.RGRec.Key.Code = 0;
      PrintSetHold();//ccr2018-03-01
      if (!ApplVar.FTend)   /* already in tender ? */
      {
         ApplVar.Price = ApplVar.Amt;    /* save ApplVar.Amt */
         RegiEnd(true);   //@@@@@@@@@@@@@@@@@

         ApplVar.FSale = 0;
         ApplVar.Amt = ApplVar.Price;
         ApplVar.PrintLayOut = ApplVar.Tend.Print;       /* restore print */
         ApplVar.RGRec.Key.Code = 299;    /* end transaction */
         StoreInBuffer();
         ApplVar.RGRec.Key.Code = 0;
         ApplVar.FTend = 1;
#if defined(FISCAL)    // liuj 0805
         if (BIT(ApplVar.Fiscal_PrintFlag, BIT0)) SETBIT(ApplVar.Fiscal_PrintFlag, BIT1);
#endif
      }

      if (BIT(ApplVar.Tend.Options, BIT3) && ApplVar.FNum == 1)    /* number entry ? */
         PrintNumber(&ApplVar.NumberEntered);
      ApplVar.FNum = 0;

      ApplVar.Price = ZERO;
      if (Appl_EntryCounter)
      {
         if (CompareBCD(&ApplVar.SubTotal, &ApplVar.Amt) < 1 || ((ApplVar.SubTotal.Sign & 0x80) == 0x80 && (ApplVar.Amt.Sign & 0x80) == 0))   /* overtendering ? */
         { //���踶��������(����Ľ���������֧�����)
            Subtract(&ApplVar.Amt, &ApplVar.SubTotal);  /* calculate change */

            sAmount = BCDValueToULong(ApplVar.SubTotal.Value, BCDLEN);
            if (BIT(ApplVar.Entry.Sign, BIT7)) sAmount = -sAmount;
            if (ApplVar.Tend.Over && BIT(ApplVar.Tend.Options, BIT4))   /* overtender is tipp? */
            {
               ApplVar.DrawNumber = ApplVar.Tend.Over - 1;    /* add tip */
               ReadDrawer();
               PrintAmt(ApplVar.Draw.Name, &ApplVar.Amt);
               ApplVar.RGRec.Key.Code = DRAW + ApplVar.Tend.Over;    /* store overtender */
               ApplVar.RGRec.Amt = ApplVar.Amt;
               ApplVar.RGRec.Amt.Sign ^= 0x80;
               ApplVar.RGRec.Qty = ONE;
               StoreInBuffer();
               ApplVar.RGRec.Key.Code = 0;
               ApplVar.Price = ApplVar.Entry;
               if (ApplVar.FCurr) Add(&ApplVar.Price, &ApplVar.Amt);  /* Add ApplVar.Entry in ApplVar.Report */
            }
            else ApplVar.Price = ApplVar.SubTotal;
            if (ApplVar.FCurr)
            {
               PrintStr(ApplVar.Curr.Name);
               ApplVar.AmtDecimal = ApplVar.Curr.Options & BIT0;
               Prefix1 = ApplVar.Curr.Prefix1;
               Prefix2 = ApplVar.Curr.Prefix2;
               GetCurrency(0, &ApplVar.Price); /* calculate currency */
            }

            if (!BIT(ApplVar.Tend.Options, BIT4))   /* overtender is tipp? */
            {
               PrintAmt(ApplVar.Tend.Name, &ApplVar.Entry); //ccr2014-08-19
                                                            //ccr2014-08-19PrintAmt(Prompt.Caption[ItemPrompt8], &ApplVar.Entry);
            }
            else //ccr20130417
               PrintAmt(ApplVar.Tend.Name, &ApplVar.Price);

            ApplVar.AmtDecimal = NO_DECIMAL;
            Prefix1 = PREFIX_1;
            Prefix2 = PREFIX_2;
            ApplVar.Price = ApplVar.Amt;    /* change */
            if (BIT(ApplVar.Tend.Options, BIT4))   /* overtender is tipp? */
               ApplVar.Amt = ApplVar.Entry;
            else
            {
               SETBIT(ApplVar.PrintLayOut, BIT2);  /* double height */
               ApplVar.SlipDouble = 1;
               if (CheckNotZero(&ApplVar.Price)) //ccr091015
                  PrintAmt(Prompt.Caption[ItemPrompt9], &ApplVar.Price); //��ӡ������
               ApplVar.PrintLayOut = ApplVar.Tend.Print;       /* restore print */
               if (ApplVar.FCurr)      /* print change in currency ? */
               {
                  if (BIT(ApplVar.Curr.Options, BIT1))
                  {
                     GetCurrency(2, &ApplVar.Price);
                     ApplVar.AmtDecimal = ApplVar.Curr.Options & BIT0;
                     Prefix1 = ApplVar.Curr.Prefix1;
                     Prefix2 = ApplVar.Curr.Prefix2;
                     PrintAmt(ApplVar.Curr.Name, &ApplVar.Price);
                     Subtract(&ApplVar.Entry, &ApplVar.Price);
                  }
               }
               ApplVar.Amt = ApplVar.SubTotal;
            }
            ApplVar.FTend = 0;
            ApplVar.FRegi = 0;
#if DD_FISPRINTER
            SETBIT(ApplVar.DocCount, OVERTEND);     //20070313
#endif
         }
         else //(����Ľ����������֧�����)
         {           /* undertendering */
            if (!ApplVar.FBuffer)   /* buffer full then must */
            {       /* finalise without split */
               if (ApplVar.FCurr)
               {
                  PrintStr(ApplVar.Curr.Name);
                  ApplVar.AmtDecimal = ApplVar.Curr.Options & BIT0;
                  Prefix1 = ApplVar.Curr.Prefix1;
                  Prefix2 = ApplVar.Curr.Prefix2;
               }
               if (ApplVar.FRefund) ApplVar.Entry.Sign ^= 0x80;
               PrintAmt(ApplVar.Tend.Name, &ApplVar.Entry); /* ��ӡ������ */
#if (DISP2LINES)
               /* ��ʾ������ */
               Puts1(DispAmtStr(ApplVar.Tend.Name, &ApplVar.Entry, DISLEN)); //ccr20131104
#endif
               sAmount = BCDValueToULong(ApplVar.Entry.Value, BCDLEN);
               if (BIT(ApplVar.Entry.Sign, BIT7)) sAmount = -sAmount;
               Subtract(&ApplVar.SubTotal, &ApplVar.Amt);
               if (ApplVar.FCurr)
               {
                  ApplVar.AmtDecimal = NO_DECIMAL;
                  Prefix1 = PREFIX_1;
                  Prefix2 = PREFIX_2;
                  PrintAmt(Prompt.Caption[ItemPrompt1], &ApplVar.SubTotal);

               }
#if DD_FISPRINTER
               SETBIT(ApplVar.DocCount, HAVETEND);     //20070313
#endif
            }
            else
            {
               ApplVar.ErrorNumber = ERROR_ID(CWXXI44);  /* must finalise without split */
               PrinAllOfHold();//ccr2018-03-01
               return;
            }
         }
      }
      else //û������������,Ĭ��ȫ���,���踶��������
      {
         if (ApplVar.FCurr)
         {
            PrintStr(ApplVar.Curr.Name);
            ApplVar.AmtDecimal = ApplVar.Curr.Options & BIT0;
            Prefix1 = ApplVar.Curr.Prefix1;
            Prefix2 = ApplVar.Curr.Prefix2;
         }
         //���ø�����
         PrintAmt(ApplVar.Tend.Name, &ApplVar.Entry);
//ccr20131104>>>>>
//�ڵڶ�����ʾʵ�ս��
#if (DISP2LINES)
         Puts1(DispAmtStr(ApplVar.Tend.Name, &ApplVar.Entry, DISLEN));
#else
//	    	PutsO(DispAmtStr(ApplVar.Tend.Nam, &ApplVar.Entry,DISLEN));
#endif
//<<<<<<<<<<<<<<<<<<<

         sAmount = BCDValueToULong(ApplVar.Entry.Value, BCDLEN);
         if (BIT(ApplVar.Entry.Sign, BIT7)) sAmount = -sAmount;
         ApplVar.FRegi = 0;
         ApplVar.FTend = 0;
#if DD_FISPRINTER
         SETBIT(ApplVar.DocCount, OVERTEND);     //20070313
#endif

      }

#if (DD_CHIPC==1)
      if (payIC == 1 && !Appl_EntryCounter) //ccr chipcard ccr epos
      {
         PrintChipCard(payIC);
         ApplVar.PluPriceLevel = 0;
      }
//		else //ccr ePos
#endif

#if 0	//cc 20070930
#if !defined(FISCAL)
//ccr ePos>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (payIC==2)
      {
         PrintePosTAC();
      }
//ccr epos<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#endif
#endif
      if (ApplVar.FRefund)
      {
         ApplVar.FRefund = 0;
         ApplVar.Amt.Sign ^= 0x80;
      }
      ApplVar.Qty = ONE;
      if (ApplVar.FCurr) AddCurrTotal();
      else
      {
#if(CASE_RAMBILL)
         Collect_Given(); //    lyq2003
#endif
         AddTenderTotal();
      }
      if (ApplVar.PbNumber)
      {
         Add(&ApplVar.FRetAmt, &ApplVar.FpbRetAmt);       //ccr091223
         Add(&ApplVar.FRetTax, &ApplVar.FpbRetTax);       //ccr091223
         ApplVar.FpbRetAmt = ApplVar.FpbRetTax = ZERO;   //ccr091223

         AddPbtTotal();
      }
      ApplVar.RGRec.Key.Code = ApplVar.Key.Code;
      ApplVar.RGRec.Amt = ApplVar.Amt;
      ApplVar.RGRec.Qty = ZERO;
      ApplVar.BufCmd = 0;     /* don't consolidate tendering functions */


      if (ApplVar.FCurr || ApplVar.Tend.Over) ApplVar.Amt = ApplVar.Entry;
      if (ApplVar.FCurr) *((WORD *)ApplVar.RGRec.Qty.Value) = CURR + ApplVar.CurrNumber;
      StoreInBuffer();

      ApplVar.RGRec.Key.Code = 0;

      if (ApplVar.FCurr)
      {
         if (ApplVar.Curr.Drawer)
         {
            ApplVar.DrawNumber = ApplVar.Curr.Drawer - 1;
            AddDrawerTotal();
            ApplVar.RGRec.Key.Code = DRAW + ApplVar.Curr.Drawer;    /* store drawer */
            ApplVar.RGRec.Amt = ApplVar.Amt;
            ApplVar.RGRec.Qty = ZERO;
            StoreInBuffer();
            ApplVar.RGRec.Key.Code = 0;
         }
         ApplVar.Amt = ZERO;
         if (!BIT(ApplVar.Curr.Options, BIT1))    /* change in local */
         {
            if (!ApplVar.Tend.Over)
            {
               ApplVar.Amt = ApplVar.Price;            /* change in local */
               ApplVar.Amt.Sign ^= 0x80; /* invert sign */
            }
         }
         else ApplVar.Price = ZERO;
      }

      if (ApplVar.Tend.Drawer)
      {
         ApplVar.DrawNumber = ApplVar.Tend.Drawer - 1;
         AddDrawerTotal();
         ApplVar.RGRec.Key.Code = DRAW + ApplVar.Tend.Drawer;    /* store drawer */
         ApplVar.RGRec.Amt = ApplVar.Amt;
         ApplVar.RGRec.Qty = ZERO;
         StoreInBuffer();
         ApplVar.RGRec.Key.Code = 0;
      }
      if (ApplVar.Tend.Over)
      {

         ApplVar.Amt = ApplVar.Price;
         ApplVar.Amt.Sign ^= 0x80; /* invert sign */

         ApplVar.DrawNumber = ApplVar.Tend.Over - 1;
         AddDrawerTotal();
         if (!BIT(ApplVar.Tend.Options, BIT4))   /* overtender is not tip? */
         {
            ApplVar.RGRec.Key.Code = DRAW + ApplVar.Tend.Over;    /* store overtender */
            ApplVar.RGRec.Amt = ApplVar.Amt;
            ApplVar.RGRec.Qty = ZERO;
            StoreInBuffer();
            ApplVar.RGRec.Key.Code = 0;
         }
      }

      if (!ApplVar.FRegi)   /* end of registration ? */
      { //���踶����֧�����,�վݽ���
//         PrintSetHold();//ccr2018-03-01
         ApplVar.UserInfo.InputType = 0; //ccr2014-PANAMA
//ccr2018-03-20#if (defined(CASE_GREECE))
          if (PRINTTAXAMT)
          {
             //PrintLine('-');  //��Լֽ�� ��ӡ�����������˰����֮��ķָ���
             CalculateTax(2);        /* ccr091210 only print and calculate tax */
          }
//ccr2018-03-20#endif
         ApplVar.AmtDecimal = NO_DECIMAL;        /* restore local values for kp */
         Prefix1 = PREFIX_1;             /* and VAT print */
         Prefix2 = PREFIX_2;
         if (ApplVar.OpDraw) OpenDrawer();
         StoreInBuffer();

         if (ApplVar.PbNumber) PrintNewBal();

         if (PVAT) CalculateTax(3);    /* print inclusive tax */
         PrintLine('-'); //ccr2017-05-17
         PrintSaleQty(); //��ӡ������Ŀ��Ŀ

#if (DD_PROMOTION)
         PromtionCheck();
#endif
         ReceiptIssue(1);       //���踶��������,��ӡƱβ����(����,Ʊβ...)

#if (defined(CASE_EURO))
         ApplVar.UserInfo.FVatNo[0] = 0; //�������Ĺ˿�˰��
#endif
         ApplVar.BufCC = 1;             /* set add Customer Count */
         ProcessBuffer();    /* reset Customer count and print kp */
         ApplVar.PbNumber = 0;
         ApplVar.FNoPb = 0;      /* reset extra ApplVar.PB Trailer and NO ApplVar.PB */
         ApplVar.FSplit = 0;
#if (defined(CASE_INDONESIA) && (defined(CASE_GPRS)))
         if (BIT(ApplVar.DaysMust, BIT7)) //���Զ��������ݣ�������ˮ
         {
            SETMyFlags(ZREPORT);
            ApplVar.FCurr = 0;
            ApplVar.AmtDecimal = NO_DECIMAL;        /* restore local values */
            Prefix1 = PREFIX_1;
            Prefix2 = PREFIX_2;
            GPRSSendECR_LOG();
         }
#endif
#if defined(FISCAL)
         if (!BIT(ApplVar.Fiscal_PrintFlag, BIT7)) ApplVar.Fiscal_PrintFlag = 0;
#endif
         CLRMyFlags(OPENRECEIPT + ENSLIPPB); //ccr2017-05-23
         SETMyFlags(ZREPORT);
         ApplVar.FCurr = 0;
         ApplVar.AmtDecimal = NO_DECIMAL;        /* restore local values */
         Prefix1 = PREFIX_1;Prefix2 = PREFIX_2;
         endOfTend=1;//ccr2018-03-07�������,�������,�վݽ���
#if (DISP2LINES)
         /* ������� */
         Puts1(DText[DTEXT_FINISHED]); //ccr20131104 finished
#endif
      }
   }
   else //ccr 050301>>>>>>>>>>>>>>>>>>>>>>>>>>>
      if (BIT(ApplVar.Tend.Options, BIT0) && !Appl_EntryCounter)
      {
         if (ApplVar.CentralLock == MG)
         {
            ApplVar.DrawNumber = ApplVar.TendNumber;
            DispDrawerTotal();
         }
      }
   CLRMyFlags(ENSLIPPB);   //lyq added for slip 20040324
   SETMyFlags(ZREPORT);
   ApplVar.FCurr = 0;
   ApplVar.AmtDecimal = NO_DECIMAL;        /* restore local values */
   Prefix1 = PREFIX_1;Prefix2 = PREFIX_2;
   PrinAllOfHold();//ccr2018-03-01
   if (endOfTend)//ccr2018-03-07�������,�������,�վݽ���
   {
#if defined(CASE_GREECE)//ccr2018-04-02
      if (ApplVar.FisNumber.ReceiptNum[FRECEIPTS]>=FZRECEIPTMAX)
      {
         ApplVar.ZReport = 2;
         ApplVar.ErrorNumber=ERROR_ID(CWXXI75);       /* first take fiscal Z-ApplVar.Report */
      }
#endif//ccr2018-04-02
#if (SDCACHESIZE)//ccr2018-02-23>>>>>
      SDCacheFlushData(true);//ccr2018-03-01
#endif//ccr2018-02-24<<<<<<<
   }

}


