#ifndef MESSAGEH
#define MESSAGEH


#if (1)//Msg[]>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#if ((DISP2LINES)||DD_LCD_1601||DD_FISPRINTER) //======MAX LENGTH:16
#define StrSPACE    " "
#define CaptionCWXXI1	"INVALID ENTRY"				//    CWXXI01//    Ccr "��Ч����!"
#define CaptionCWXXI2	"INVALID DATE"					//    CWXXI02//    Ccr "��Ч����!"
#define CaptionCWXXI3	"INVALID TIME"					//    CWXXI03//    Ccr "��Чʱ��!"
#define CaptionCWXXI4	"NOT ALLOWED"					//    CWXXI04//    Ccr "��ֹ����!"
#define CaptionCWXXI5	"NO SUCH PLU"						//    CWXXI05//    Ccr "PLU����Ϊ��!"
#define CaptionCWXXI6	"PLU OVERFLOW"					//    CWXXI06//    Ccr "PLU�ļ����!"
#define CaptionCWXXI7	"TABLE OCCUPIED"					//    CWXXI07//    Ccr "��̨��ռ��!"
#define CaptionCWXXI8	"TABLE OPENED"					//    CWXXI08//    Ccr "��̨�Ѵ�!"
#define CaptionCWXXI9	"WRONG TABLE#"					//    CWXXI09//    Ccr "��̨�Ų���!"
#define CaptionCWXXI10	"ENTER TABLE#"            		//    CWXXI10//    Ccr "��������̨��"
#define CaptionCWXXI11	"NO TABLE#"           		//    CWXXI11//    Ccr "��̨û�п�̨"
#define CaptionCWXXI12	"PB OVERFLOW"            		//    CWXXI12//    Ccr "��̨�������"
#define CaptionCWXXI13	"NOT ALLOWED"       			//    CWXXI13//    Ccr "��ֹ�޸�ʱ��"
#define CaptionCWXXI14	"IN TRADING!"					//    CWXXI14//    Ccr "����������!"
#define CaptionCWXXI15	"MEMORY OVERFLOW"              	//    CWXXI15//    Ccr "���ۻ�������"
#define CaptionCWXXI16	"ITEM NOT SOLD"         		//    CWXXI16//    Ccr "��Ʒû���۳�"
#define CaptionCWXXI17	"IN CHECKOUT"						//    CWXXI17//    Ccr "���ڽ�����!"
#define CaptionCWXXI18	"ENTRY OVERFLOW"            			//    CWXXI18//    Ccr "�������ݳ���"
#define CaptionCWXXI19	"IN TENDERING"					//    CWXXI19//    Ccr "���ڸ���!"
#define CaptionCWXXI20	"GUEST OVERFLOW"						//    CWXXI20//    Ccr "�������!"
#define CaptionCWXXI21	"CONFIRM NEEDED"						//    CWXXI21//    Ccr "û��ȷ�Ͻ���"
#define CaptionCWXXI22	"NOT ALLOWED"        			//    CWXXI22//    Ccr "��ֹȡ������"
#define CaptionCWXXI23	"NO SUCH ITEM"        			//    CWXXI23//    Ccr "�޲���!"
#define CaptionCWXXI24	"NO SUCH CLERK"					//    CWXXI24//    Ccr "�޴��տ�Ա!"
#define CaptionCWXXI25	"CLERK SHIFTED"              	//    CWXXI25//    Ccr "�տ�Ա�ı�"
#define CaptionCWXXI26	"NO SUCH REPORT"					//    CWXXI26//    Ccr "�޴��౨��!"
#define CaptionCWXXI27	"REPORT.PRT FAIL"            		//    CWXXI27//    Ccr "������ӡ�ж�"
#define CaptionCWXXI28	"MANAGER ONLY"					//    CWXXI28//    Ccr "�����ھ�����"
#define CaptionCWXXI29	"IN SPLITTING"          		//    CWXXI29//    Ccr "���ܷ���ʱ��"
#define CaptionCWXXI30	"INPUT CARD#"					//    CWXXI30//    Ccr "�����������"
#define CaptionCWXXI31	"TRANSFER TO"        			//    CWXXI31//    Ccr "ת�뵽"
#define CaptionCWXXI32	"UNAUTHORIZED"        			//    CWXXI32//    Ccr "δ��Ȩ!"
#define CaptionCWXXI33	"CLERK OBLI."            		//    CWXXI33//    Ccr "��ָ���տ�Ա" obligatory
#define CaptionCWXXI34	"SALESPERSON OBLI"            		//    CWXXI34//    Ccr "��ָ��ӪҵԱ"
#define CaptionCWXXI35	"NOT ALLOWED"        			//    CWXXI35//    Ccr "��ֹPLU��ۣ�"
#define CaptionCWXXI36	"PASSWORD ERROR"					//    CWXXI36//    Ccr "���벻��!"
#define CaptionCWXXI37	"KITCHEN PRT ERR."            		//    CWXXI37//    Ccr "������ӡ����"
#define CaptionCWXXI38	"SLIP PRT ERROR."            		//    CWXXI38//    Ccr "Ʊ�ݴ�ӡ����"
#define CaptionCWXXI39	"PRINTER OPEN"            		//    CWXXI39//    Ccr "��ӡѹ��̧��"
#define CaptionCWXXI40	"PAPER OUT"            		//    CWXXI40//    Ccr "��ӡֽ����!"
#define CaptionCWXXI41	"PRINTER OVERHEAT"            			//    CWXXI41//    Ccr "��ӡ�¶�̫��"
#define CaptionCWXXI42	"UNDEFINED KEY"					//    CWXXI42//    Ccr "����δ����!"
#define CaptionCWXXI43	"0.00 NOT ALLOWED"					//    CWXXI43//    Ccr "����������" /* zero price not allowed enter amount */
#define CaptionCWXXI44	"SPLIT TENDER"         		 		//    CWXXI44//    Ccr "��ֹ���ָ���"
#define CaptionCWXXI45	"NO SUCH FUNCTION"        			 	//    CWXXI45//    Ccr "�޴˹���"
#define CaptionCWXXI46	"SUBTOTAL OBLI."        		 		//    CWXXI46//    Ccr "δ��С�Ƽ�!"
#define CaptionCWXXI47	"STOCK TAKING"            		 	//    CWXXI47//    Ccr "���ڹ������"
#define CaptionCWXXI48	"EJ ERROR"           		 	//    CWXXI48//    Ccr "������ˮ��"
#define CaptionCWXXI49	"MODEM ERROR"			         	//    CWXXI49//    Ccr "MODEMͨѶ��!"
#define CaptionCWXXI50	"ACCESS CARD ERR"               	 	//    CWXXI50//    Ccr "����������!"
#define CaptionCWXXI51	"POS-CODE ERROR"                 		//    CWXXI51//    Ccr "POS�����!"
#define CaptionCWXXI52	"READING ERROR"                  		//    CWXXI52//    Ccr "�����ݴ�!"
#define CaptionCWXXI53	"EXPIRED CARD"               			//    CWXXI53//    Ccr "Ϊ���ڿ�!"
#define CaptionCWXXI54	"BLOCKED CARD"                   		//    CWXXI54//    Ccr "Ϊ��ʧ��!"
#define CaptionCWXXI55	"WRONG CARD TYPE"              	 		//    CWXXI55//    Ccr "�ͻ�����!"
#define CaptionCWXXI56	"NEW CARD"                    			//    CWXXI56//    Ccr "Ϊ�¿�!"
#define CaptionCWXXI57	"NOT CASH CARD"            			//    CWXXI57//    Ccr "���ǹ��￨!"
#define CaptionCWXXI58	"WRITING ERROR"                 		//    CWXXI58//    Ccr "д������!"
#define CaptionCWXXI59	"WRONG NUMBER"                  		//    CWXXI59//    Ccr "���Ų���!"
#define CaptionCWXXI60	"DISC.FORBIDDEN"					//    CWXXI60//    Ccr "�����ۿۿ�!"
#define CaptionCWXXI61	"CASH FORBIDDEN"					//    CWXXI61//    Ccr "�����ֽ�!"
#define CaptionCWXXI62	"CREDIT FORBIDDEN"					//    CWXXI62//    Ccr "�������ʿ�!"
#define CaptionCWXXI63	"CARD FORBIDDEN"					 	//    CWXXI63//    Ccr "����IC��!"
#define CaptionCWXXI64	"CLEARANCE ERROR"				//    CWXXI64//    Ccr "�忨����!"
#define CaptionCWXXI65	"DATA OVERFLOW"						//    CWXXI65//    Ccr "�������!"
#define CaptionCWXXI66	"CARD CHARGE ERR"					//    CWXXI66//    Ccr "IC��ֵ����!"
#define CaptionCWXXI67	"INIT. ERROR"					//    CWXXI67//    Ccr "IC��ʼ������"
#define CaptionCWXXI68	"INIT. DISABLED"					 	//    CWXXI68//    Ccr "��ֹ��ʼ��!"
#define CaptionCWXXI69	"LOWER BALANCE"					//    CWXXI69//    Ccr "IC����!"
#define CaptionCWXXI70	"TENDERING ERROR"					//    CWXXI70//    Ccr "IC�������!"
#define CaptionCWXXI71	"IP ADDRESS ERROR"				 		//    CWXXT71//    Hf "IP��ַ��"
#define CaptionCWXXI72	"M1 ERROR"				//    CWXXI72//     ccr "��Ƶ������!"
#define CaptionCWXXI73	"CONNECTION FAIL"				//    CWXXI73//    Cc "����ʧ��!"
#define CaptionCWXXI74	"NO FISCAL MEMORY"   				//    CWXXI74>>>>>for fiscal
#define CaptionCWXXI75	"Z-REPORT REQUIRE"   				//    CWXXI75
#define CaptionCWXXI76	"ACCESS FM ERROR"   				//    CWXXI76
#define CaptionCWXXI77	"FM NEAR FULL"    				//    CWXXI77 FM���� //
#define CaptionCWXXI78	"FM ERROR"     				//    CWXXI78
#define CaptionCWXXI79	"FISCALIZED"    				//    CWXXI79
#define CaptionCWXXI80	"TRAIN MODE"   				//    CWXXI80
#define CaptionCWXXI81	"INITIALIZE FM"   				//    CWXXI81
#define CaptionCWXXI82	"FM DATA ERROR"   				//    CWXXI82 FM�е������д� //
#define CaptionCWXXI83	"NO EJ"        				//    CWXXI83
#define CaptionCWXXI84	"ACCESSING EJ ERR"   				//    CWXXI84 EJ ��д���� //
#define CaptionCWXXI85	"NO DATA IN EJ"   				//    CWXXI85 EJ������ //
#define CaptionCWXXI86	"FM IS FULL"   				//    CWXXI86
#define CaptionCWXXI87	"EJ NEAR FULL"   				//    CWXXI87 EJ���� //
#define CaptionCWXXI88	"EJ IS FULL"   				//    CWXXI88
#define CaptionCWXXI89	"MUST FORMAT SD"    				//    CWXXI89
#define CaptionCWXXI90	"NEW EJ"        				//    CWXXI90
#define CaptionCWXXI91	"MAC LIMIT: 200"    				//    CWXXI91 ���200�μӵ��ʼ�� //
#define CaptionCWXXI92	"CHECKSUM ERROR"  				//    CWXXI92
#define CaptionCWXXI93	"FM NOT MATCH ECR"     				//    CWXXI93 FM ���տ����ƥ�� //
#define CaptionCWXXI94	"NEW FM"        				//    CWXXI94
#define CaptionCWXXI95	"O.Battery Low!"   				//    CWXXI95
#define CaptionCWXXI96	"INNER EJ ERROR"   				//    CWXXI96
#define CaptionCWXXI97	"INITIALIZE EJ"   				//    CWXXI97
#define CaptionCWXXI98	"EJ NOT MATCH ECR"     				//    CWXXI98 EJ���տ����ƥ�� //
#define CaptionCWXXI99	"STOCK DISABLED"     				//    CWXXI99
#define CaptionCWXXI100	"INVALID TAX"     				//    CWXXI100
#define CaptionCWXXI101 "NEGATIVE TAX"          //CWXXI101 ˰��<0 //ccr2014-08-06 new

#define CaptionGPRSERR  "GPRS ERROR!"          //CWXXI102 //GPRS����
#define CaptionSENDERR  "SEND ERROR!"          //CWXXI103 //�������ݳ���
#define CaptionRECVERR  "ERROR RECEIVED"          //CWXXI104 //�������ݳ���
#define CaptionNOSERVER "NO SERVER!"           //CWXXI105 //�޷����ӷ�����
#define CaptionIPERROR  "ERROR IP/PORT"         //CWXXI106 //�޷�����IP��ַ
#define CaptionNOSIM    "NO SIM CARD"          //CWXXI107 //��SIM��
#define CaptionGPRSKO   "GPRS NOT OK"          //CWXXI108 //GPRSδ����
#define CaptionLINEOFF  "NETWORK BREAK"          //(CWXXI109) //����δ���
#define CaptionTCPERROR "CREATE TCP FAIL"   // (CWXXI110) //����ͨѶʧ��

//ccr2017-06-16>>>����������SD��������Ϣ>>>
#define CaptionCWXXI111 "SD-I MAYBE FULL"           //INNER SD ����//
#define CaptionCWXXI112 "SD-I NOT FOUND"           //������EJ
#define CaptionCWXXI113 "MUST INIT SD-I "           //�����ʼ��
//ccr2017-06-16<<<<<<<<<<<<<<<<<<<<<<<<<
#define CaptionCWXXI114 "FILE.E C/R/W ERR"     //�⿨�ļ�����ʧ��
#define CaptionCWXXI115 "FILE.I C/R/W ERR"      //�ڿ��ļ�����ʧ��
#define CaptionCWXXI116 "NOT ACTIVED"           //ccr2017-08-02
#define CaptionCWXXI117 "OP-Times Overflow" //ccr2017-08-08
#define CaptionCWXXI118 "MUST RESTART ECR" //ccr2017-09-26

#define CaptionCWXXI119 "URL or DNS NULL" //ccr2017-10-30
#define CaptionCWXXI120 "FAILER LINK DNS" //ccr2017-10-30
#define CaptionCWXXI121 "ECR IP NULL" //ccr2017-10-30
#define CaptionCWXXI122 "NO FILE/FOLDER-E"
#define CaptionCWXXI123 "NO FILE/FOLDER-I"
#define CaptionCWXXI124 "CACHE FULL"
#define CaptionCWXXI125 "RATA DUPLICATION"
#define CaptionCWXXI126 "PRINT DISCONNECT"   //ccr2018-04-02

#endif	//(DD_ZIP||DD_ZIP_21)
#define SERVING		    "Serving"			//ccro91127
#define INITEJPROMPT 	"Initial EJ ?"				//ccr091117
//--------------------------------------------------------
#define MessageN1		"SERIAL#:"				//KAHAO//Ccr 	"����:"				//KAHAO
#define MessageN2		"CARD TYPE:"				//KLXING//Ccr 	"������:"				//KLXING
#define MessageN3		"BALANCE:"			//KNJE//Ccr 	"���ڽ��:"			//KNJE
#define MessageN4		"FOREGIFT:"				//KYJIN//Ccr 	"��Ѻ��:"				//KYJIN
#define MessageN5		"PAYMENT:"			//XFZE//Ccr 	"�����ܶ�:"			//XFZE
#define MessageN6		"CHARGE:"			//CHZHZE//Ccr 	"��ֵ�ܶ�:"			//CHZHZE
#define MessageN7		"TIMES:"		//SHYCSHU//Ccr 	"ʹ�ô���:"			//SHYCSHU
#define MessageN8		"PRI.LEVEL:"		//JGLBIE//Ccr 	"�۸񼶱�:"			//JGLBIE
#define MessageN9		"PIN CODE:"				//PINMA//Ccr 	"PIN��:"				//PINMA
#define MessageN10		"SECURITY LEVEL:"			//BHJBIE//Ccr 	"��������:"			//BHJBIE
#define MessageN11		"AUTO TENDER:"			//ZDJZHANG//Ccr 	"�Զ�����:"			//ZDJZHANG ZWQ
#define MessageN12		"OPEN DATE:"			//ZHKRQI//Ccr 	"�ƿ�����:"			//ZHKRQI ZWQ
#define MessageN13		"EXPIRED DATE:"			//KYXQI//Ccr 	"����Ч��:"			//KYXQI
#define MessageN14		"HOLDER:"			//KHMCHEN//Ccr 	"�ͻ�����:"			//KHMCHEN5
#define MessageN15		"INITIALIZATION"				//CHSHHICKA//ccr	"��ʼ��IC"								//CHSHHICKA
#define MessageN16		"CHARGE"						//ICKCHZHI//ccr	"IC����ֵ"									//ICKCHZHI
#define MessageN17		"CLEAR"						//QCHICKA//ccr	"���IC��"									//QCHICKA
#define MessageN18		"BLACKLIST"  //GUASHIIC//ccr "��ʧ����"     //GUASHIIC      //ICCard Part ccr chipcard 2004-06-28
#define MessageN19		"DISCOUNT:" //ZHEKOUCA//ccr "�ۿۿ�:"            //ZHEKOUCA
#define MessageN20		"CASH:"        //XIANJINKA//ccr "�ֽ�:"           //XIANJINKA
#define MessageN21		"CREDIT:"  //SHEZHANGKA//ccr "���ʿ�:"           //SHEZHANGKA
#define MessageN22		"POINT:"  // ���ѼƵ�:	//KAOQINKA
#define MessageN23		"DISCOUNT(%):"    //    ZHKLVF//    Ccr "�ۿ���(%):"         //    ZHKLVF
#define MessageN24		"WITHDRAWAL"        //    ICKTKUAN//    Ccr "IC���˿�" 			//    ICKTKUAN
#define MessageN25		"POINT REDEEM"     //    ICKDJDIANG//    Ccr "IC���ҽ�����" 			//    ICKDJDIANG
#define MessageN26		"GIFT POINTS"      //    ICKSDIAN//    Ccr "IC���͵���" 			//    ICKSDIAN
#define MessageN27		"CHECK"               //    ZHUOTAI//    Ccr "��̨"                        //    ZHUOTAI
#define MessageN28		"RCP#_FROM"         // "��ʼ�վݺ�" 	//    RECNUMFR
#define MessageN29		"RCP#_END"         // "�����վݺ�" 	//    RECNUMTO

#define MessageN30		"EJ INITIALISATION:"       // "EJ��ʼ��"		//    EJCSHUA
#define MessageN31		"CODE"      //    hf 	"EJ���"			//    EJBHAO
#define MessageN32		"~E.~J. ~R~E~P~O~R~T" // "EJ ����"			//    EJBBIAO
#define MessageN33		"GRAND TOTAL"              //"~��~��~��" 		//GRANDTOTAL
#if (defined(FISCAL) || DD_FISPRINTER==1)
#define MessageN34		"CHECK"
#define VAT_A_P         4   //˰���ַ�A��λ��
#define MessageN35		"VAT A " //ITEMTAXA !!!! CopyFrStr(SysBuf,Msg[ITEMTAXA].str);SysBuf[VAT_A_P]+=i;
#define MessageN48		"VAT A RATE CHANGE"	//TAXACHG !!!! strcpy(SysBuf,Msg[TAXACHG].str); SysBuf[VAT_A_P]+=i;

#define MessageN43		"TAX SUM"      //TAXTOTAL

#if (0)//defined(CASE_GREECE)
#define MessageN431     "NUMBER OF Z"   //TOTALZCOUNTER
#else
#define MessageN431     "TOTAL Z REPORTS"   //TOTALZCOUNTER
#endif

#define MessageN44		"NET SALE"
#define MessageN45		"RCP.NUMBER"

#define MessageN46		"FM DISCONNECT"
#define MessageN47		"HEADER CHANGES"
#define MessageNDATE    "TECH-INTERVENTION"        //CHANGEDATETIME//"��������ʱ��"

#define MSG_ECRxEJ      "EJ DISCONNECT"//SD���γ�����ͳ��
#define MSG_ECRCMOSERR  "CMOS ERRORS" //CMOS����(���ݴ�)����ͳ��
#define MSG_ECRxPRINTER "PRINTER DISCONNECT"  //��ӡ���Ͽ�����ͳ��


#define MessageN56		"FROM "			//"FROM"		//TAXFROM
#define MessageN57		"TO "           //"TO"		//TAXTO
#if(PRTLEN < 36)
#define MessageN58		"~F~M ~R~E~P~O~R~T"	//Cc"˰�ش洢������" //PRNFISCAL
#else
#define MessageN58		"~F~I~S~C~A~L ~M~E~M~O~R~Y ~R~E~P~O~R~T"
#endif
#define MessageN59		"PERIOD TOTALS"	//"�����ܼ�"		//PRNTOTAL
#define MessageN60		"Z-CLOSURES"		//"�����ܼ�"		//CLEARTOTAL
#define MessageN61		"MAC RESETS"		//"��λ�ܼ�"		//MACRESET
#define MessageN62		"VAT RATE CHANGES"		//Cc"˰�ʸ����ܼ�"	//CHANGETAX
#define MessageN63		"DAILY TOTAL OF TAX"      //SHKZBB   "˰���ձ���"
#define MessageN64		"SERIAL:"		    //hf 	"˰����"			//TAXCODE
#define MessageN65		"R.U.C:"		    //PANAMA 	"RIF����"			//RIFCODE
#if defined(CASE_EURO)//ccr2017-08-02
#define MessageN67		"NET VALUE E"	    //"��˰����"		//MIANSHUI
#else
#define MessageN67		"TAX-EXEMPT"	    //"��˰����"		//MIANSHUI
#endif
#define MessageN68		"TAX"		//hf 	"˰Ŀ A"			//SHUIMUA
#define MessageN69		"CUSTOMER: "		//"�ͻ�����"		//KHMINGCH		//20070308
#define MessageN70		"SERIAL NUMBER: "			//"������"			//JIQIHAO		//20070308
#define MessageN71		"DATE"						//"����"			//RIQI			//20070308
#define MessageN72		"TIME"						//"ʱ��"			//SHIJIAN		//20070308
#define MessageN73		"TAXABLE SUM"				//"�����ܼ�"		//XSHZHJI
#define MessageN74		"Refund.TAX SUM"		//"�˻��ܼ�"		//THUOZHJI
#define MessageN75		"Disc.TAX SUM"		//"�ۿ��ܼ�"		//ZHKOUZHJI
#define MessageN76		"NET VALUE"					//XIAOSHOUA	"������"
#define MessageN761		"NET AMOUNT "	    //"˰�����۶�"		//NETAFTERTAX
#define MessageN762		"AMOUNT WITH "	    //"��˰���۶�"		//AMTWITHTAX

#define MessageN77		"REFUND "				// " �˻�����"		//    THXIAOSHOU
#define MessageN78		"DISCOUNT"				// "�ۿ�����"		//    ZHKOUXSH
#define MessageN79		"Refund.TAX SUM"		// "�˻�˰��"		//    THZJSHUI
#define MessageN80		"Disc.TAX SUM"		// "�ۿ�˰��"		//    ZHKZJSHUI

#define MessageN81		"EJ INITIALIZED"		//    hf 	"EJ��Ϣ"			//    EJXINXI
#define MessageN82		"EJ INIT DATE"			//    hf "EJ��ʼ��ʱ��"		//    EJSHJIAN
#define MessageN83		"== NON FISCAL =="			// "�Ƿ�Ʊ"			//    NONFISCAL
#define MessageN84		"ECR FISCALIZED"		//  SHKCSHUA
#define MessageN85		"DATE>="			// "��ʼ����" ����<(DISLEN-8)	//DATEFROM
#define MessageN86		"DATE<="			// "��������" ����<(DISLEN-8)	//DATETO
#define MessageN87		"TIME>="			// "��ʼʱ��"		//    TIMEFROM
#define MessageN871		"TIME<="			// "����ʱ��"		//    TIMETO
#define MessageN88		"RECEIPTS"			// "�ܼƷ�Ʊ��"	//    ZHJIFPHAO
#define MessageN89		"NO.NC" 				// "�ܼ��˻���"	//    ZHJITHHAO ???
#define MessageN90		"NO.NF"				// "�ܼƷ�˰��"	//    ZHJIFSHHAO  ???
#define MessageN91		"RECEIPTS"			// "��Ʊ��"			//    FAPIAOHAO
#define MessageN911     "DAILY RECEIPTS"                    //DAILYRECEIPTS
#define MessageN92		"# NCD"				// "�˻���"			//    THUOHAO   ???
#define MessageN93		"# NFD"				// "��˰��"			//    FEISHUIHAO  ???
#define MessageN94		"# FMD"				// "˰�ر�����"	//    SHKBBHAO  ???
#define MessageN95		"Z:"					// "���ʼ���"		//    QZHJSHU
#define MessageN96		"ZEROING. AVAILAB:"					//REPLEFT
#define MessageN97		"FM(KB)"							//SIZEFM
#endif //end fiscal
#define MessageN98		"SIZE OF EJ"							//SIZEEJ
#define MessageN99		"VALUE IN IC"			//    VALUEINIC
#define MessageN100		"LOWER BAT  "							//    LOWBAT
#define MessageN101		"CLEAR IC"				//    CLEARIC
#define MessageN102		"CHARGE IC"			//    CHARGEIC
#define MessageN103		"GIFT POINTS"		//    ADPOINTS
#define MessageN104		"INIT_ IC"				//    INITIC
#define MessageN105		"WAIT IC_____"			//WAITEICCARD
#define MessageN106		"IC CARD OK__"			//ICCARDOK
#define MessageN107		"CARD NO.:"			//ePOSTAC //ccr epos//ccr "ePOS��֤��:"			//ePOSTAC //ccr epos
#define MessageN108		"WAIT EPOS___"					//WAITEPOS
#define MessageN109		"ACCOUNTS:"			//ePOSCARNO//ccr "��ͨ����:"					//ePOSCARNO
#define MessageN110		"EFT BALANCE:"	//eCARREMAIN//ccr "��ͨ�����:"					//eCARREMAIN
#define MessageN111		"ID:"			//TMHYHAO//ccr "��Ա��:"			//TMHYHAO
#define MessageN112		"MEMBERSHIP"   //BARREPORT//ccr  �� Ա �� ��   //
#define MessageN113		"AMOUNT"				//XFJE//ccr "���ѽ��"				//XFJE
#define MessageN114		"TOTAL"                 //ZONGJI//Ccr "�ܼ�"                       //ZONGJI
#define MessageWait		"Waiting....."          //WAITING
#define MessageInit     "Initializing......"    //INITWAITING

#define MessageRecFr	"REC# FROM"         //"��ʼ�վݺ�" 	//    RECEIPTFROM
#define MessageRecTo	"REC# TO"         //"�����վݺ�" 	//    RECEIPTTO

#define MessageRecZNum	"#Z OF RECEIPT"         //"�վݺ�����Z������" 	//  ZNumFORRECEIPT
#define MessageRecNum	"RECEIPT NUMBER"         //"��ѯ���վݺ�" 	//    RECEIPTNUMBER

#define MessageEXC_VAT  "SUM EXCEPT.TAX"    //SUM_EXC_VAT ����˰���۽��
#define MessageVAT      "TAX AMOUNT"        //VAT_AMOUNT ˰��
//ccr2017-05-09>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#define MessMODEReg     "REGIST"       //REG_MODE
#define MessMODEX       "X REPORTS"         //X_MODE
#define MessMODEZ       "Z REPORTS"         //Z_MODE
#define MessMODESET     "PROGRAM"      //SET_MODE
#define MessMODEMAN     "MANAGE"       //MG_MODE

//>>>>>>>>����X��������>>>>>>>>>
#define strxDAILYJOURNAL     	"DAILY JOURNAL"
#define strxDEPARTMENTDAILY  	"DEPARTMENT DAILY"
#define strxPLUDAILY         	"PLU DAILY"
#define strxCLERKSDAILY      	"CLERKS DAILY"
#define strxWAITERSDAILY     	"WAITERS DAILY"
#define strxCATEGORY          	"CATEGORY DAILY"
#define strxALLDAILY         	"ALL DAILY"
#define strxGENERALPARAM			"GENERAL FILES"

//>>>>>>>>>����Z��������>>>>>>>>>>>
#define strzPRINTZREPORT  		"PRINT Z REPORT"
#define strzCOPYLASTZ  		    "COPY OF LAST Z"
#define strzDEPTSALES		    "DEPARTMENT SALES"
#define strzPLUSALES       		"PLU SALES"
#define strzCLERKSSALES   		"CLERKS  SALES"
#define strzWAITERSSALES  		"WAITERS  SALES"

#define strzZERODEPARTMENT 		"ZERO DEPARTMENT"
#define strzZEROPLUSALES  		"ZERO PLU SALES"
#define strzZEROCLERKS     		"ZERO CLERKS"
#define strzZEROWAITERS    		"ZERO WAITERS"

#define strzZEROALLSALES  		"ZERO ALL SALES"
#define strzFMREADZ_Z     		"FM READ Z-Z"
#define strzFMREADDATE    		"FM READ DATE"
#define strzFMREADTAXRATE        "READ TAX RATE "
#define strzFMREADHEAD           "READ HEAD "
#define strzFMREADSETDATE        "READ DATE CHANGED"
#define strzHTTPPOSTSFILE        "SEND S-FILE OF Z"
//X���µ�xGENERALPARAM���ܲ˵�
#define strxLISTPLU              "PLU LIST"          //xLISTPLU
#define strxLISTDEPARTMENT       "DEPARTMENT LIST"   //xLISTDEPARTMENT
#define strxLISTCLERK            "CLERK LIST"        //xLISTCLERK
//FM Read �˵�����
#define strSYNOPSIS    "SYNOPSIS"  //��������
#define strANALYTICAL  "ANALYTICAL"    //��ϸ����


#define strEJLOGBYDATE  "EJ BY DATETIME" //EJBYDATETIME
#define strEJLOGBYZ_Z   "EJ BY Z NUMBER" //EJBYZNUMBER

#define strRECEIPTPRINT "RECEIPT PRINT"   //EJPrintReceipt
#define strZREPORTPRINT "Z REPORT PRINT"  //EJPrintZRport

#endif//Msg[]<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

//>>>>>>>>>>>>>>>>>  Ʊͷ ENGLISH>>>>>>>>>>>>

#if (PRTLEN>45)                    /*	   12345678901234567890123 */
#define Header1		  "**********************************************"
#define Header2		  "   Thanks for Choosing Eutron Cash Register   "
#define Header3		  "**********************************************"

#elif (PRTLEN<25)
/*	                 12345678901234567890*/
#define Header1	 	"* SHOP LEGAL NAME  *"  //ZWQ
#define Header2	 	"*  SHOP  ADDRESS   *"
#define Header3	 	"*   TAX  ID CODE   *" //Ccr" 	 �� �� �� ��     �� �� �� ��   *"*/
#define Header4	 	"* --------------   *" //Ccr" 	 �� �� �� ��     �� �� �� ��   *"*/
#elif (PRTLEN<36)
              /*	 12345678901234567890123456789012*/
#define Header1	 	"*    SHOP REGISTERED NAME      *"
#define Header2	 	"*     SHOP LEGAL ADDRESS       *"
#define Header3	 	"*         TAX ID CODE          *" //Ccr" 	 �� �� �� ��     �� �� �� ��   *"*/
#define Header4	 	"*         --------------       *" //Ccr" 	 �� �� �� ��     �� �� �� ��   *"*/

#else
              /*	 12345678901234567890123456789012*/
#define Header1	 	"*    SHOP  REGISTERED NAME     *"
#define Header2	 	"*       SHOP LEGAL ADDRESS     *"
#define Header3	 	"*         TAX ID CODE          *" //Ccr" 	 �� �� �� ��     �� �� �� ��   *"*/
#define Header4	 	"*         --------------       *" //Ccr" 	 �� �� �� ��     �� �� �� ��   *"*/
#endif

//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

//>>>>>>>>>>>>>>   �������� ENGLISH   >>>>>>>>>>>>>>>>>>>
#define ReportType0     "  GRAND TOTAL   "        //"   ��  ��  ��   "
#define ReportType1     "  GROUP         "        //" ��  ��  ��  �� " //1
#define ReportType2     "  DEPARTMENT    "        //" ��  ��  ��  �� " //2
#define ReportType3     "  PLU           "        //" ��  Ʒ  ��  �� "      /* 3 Used with Plu Report */
#define ReportType4     "  TENDER        "        //" ��  ��  ��  Ϣ " //4
#define ReportType5     "  PORA          "        //" �� �� �� �� Ϣ " //5
#define ReportType6     "  DRAWER        "        //" Ǯ  ��  ��  Ϣ " //6
#define ReportType7     "  CORRECTION    "        //" ��  ��  ��  Ϣ " //7
#define ReportType8     "  DISCOUNT      "        //" ��  ��  ��  Ϣ " //8
#define ReportType9     "  CURRENCY      "        //" ��  ��  ��  Ϣ " //9
#define ReportType10    "  TAX           "        //" ��  ˰  ��  Ϣ " //10
#define ReportType11    " PB FUNCTIONS   "        //" ��  ��  ��  Ϣ " //11
#define ReportType12    "PREVIOUS BALANCE"        //" ��  ̨  ��  Ϣ " //12
#define ReportType13    "  TABLES        "        //" ��  ̨  ��  Ϣ " //13
#define ReportType14    "  PLU STOCK     "        //" ��  Ʒ  ��  �� " //14
#define ReportType15    "  PB INVOICES   "	      // �������ָʲô? ZWQ û����
#define ReportType16    "  TENDER BUFFER "        // �������ָʲô? ZWQ û����

//>>>>>>>>>>>>ReportList*����ӡ��Length<17>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#define ReportList1		"CLERK DAILY" //CCR" �� �� Ա �� �� "
#define ReportList2		"CLERK SALES" //CCR" �� �� Ա �� �� "
#define ReportList3		"DAILY REPORT" //CCR" ��  ��  ��  �� "
#define ReportList4		"SALES REPORT" //CCR" ��  ��  ��  �� "
#define ReportList5		"PLU DAILY" //CCR" ��  Ʒ  ��  �� "
#define ReportList6		"TABLES REPORT" //CCR" ��  ��  ��  �� "
#define ReportList7		"TIMES ZONE" //CCR" ʱ  ��  ��  �� "
#define ReportList8		"CLERKS DAILY" //CCR"  ȫ�տ�Ա�ձ�  "
#define ReportList9	    "CLERKS SALES" //CCR"  ȫ�տ�Ա�ܱ�  "
#define ReportList10	"SALER DAILY" /* Ӫ ҵ Ա �� �� */
#define ReportList11	"SALER SALES" //CCRӪ ҵ Ա �� ��//
#define ReportList12	"SALERS DAILY" //CCR"  ȫӪҵԱ�ձ�  "
#define ReportList13	"SALERS SALES" //CCR"  ȫӪҵԱ�ܱ�  "
//ccr2017-05-27>>>>>>>>>>>>>>>>>>>>
#define ReportList14    "DEPARTMENT DAILY" //{14,"�����ձ���"},   REPID_DEPTDAILY ,
#define ReportList15    "DEPARTMENT SALES"  //{15,"�������ڱ���"},REPID_DEPTPERIOD,
#define ReportList16    "GROUPS DAILY"   //{16,"�����ձ���"},     REPID_GROUPDAILY,
#define ReportList17    "PLUS SALES"               //{17, "��Ʒ���ڱ���"},  REPID_PLUPERIOD,

//ccr2017-05-27<<<<<<<<<<<<<<<<<<<<

//>>>>>>>>>>>>>>>>  Ʊβ  ENGLISH  >>>>>>>>>>>>>>>>>>>>>

#if (PRTLEN<25)
#define 	Trailer1 	"WELCOME TO EUTRON" //Ccr 	"     ~��  ~л  ~��  ~��     "
#define 	Trailer2 	"    GOODBYE       " //Ccr 	"          ~��  ~��         "
#else
#if (defined(CASE_EURO))
#define 	Trailer1 	"  THANK YOU FOR SHOPPING   "
#define 	Trailer2 	"    PLEASE VISIT AGAIN     "
#else
#define 	Trailer1 	"WELCOME TO EUTRON" //Ccr 	"     ~��  ~л  ~��  ~��     "
#define 	Trailer2 	"    GOODBYE       " //Ccr 	"          ~��  ~��         "
#endif
#endif
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

//>>>>>>>��  ~ϲ  ~��  ~��>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

#define Promotion1		"  CONGRATULATIONS!  " //		"  ~��  ~ϲ  ~��  ~��"
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


#define Correc1 		  "VOID    " //Ccr 		{ PLAYOUT, 0x01, " ȡ��   "},
#define Correc2 		  "CORRECT " //Ccr 		{ PLAYOUT, 0x00, "����    "},
#define Correc3 		  "RETURN  " //Ccr 		{ PLAYOUT, 0x02, "�˻�    "},
#define Correc4 		  "CANCEL  " /* "ȡ������" */

#define CURRENCY1	      "DOLLAR  "
#define CURRENCY2         "YEN     "  //"��Ԫ    "
#define CURRENCY3         "HK $    "  //"�۱�    "
#define CURRENCY4         "CURR   1"  //"���1   "
#define CURRENCY5         "CURR   2"  //"���2   "

#define DISCOUNT1         "(+%)SURC"  //"+%�ӳ�"
#define DISCOUNT2         "(-%)DISC"  //"(-%)�ۿ�"
#define DISCOUNT3         "NET SURC"  //"���ӳ�"		ZWQ
#define DISCOUNT4         "NET DISC"  //"����ۿ�"		ZWQ

#define DRAWER1           "CASH    "  //"�ֽ�    "
#define DRAWER2           "CHECK   "  //"֧Ʊ    "
#define DRAWER3           "C.CARD  "  //"���ÿ�  "
#define DRAWER4           "COUPON  "  //"����ȯ  "
#define DRAWER5           "CREDIT  "   //"����    "
#define DRAWER6           "CHIPCARD"  //"IC��    "
#define DRAWER7           "FEE     "  //"С��    "
#define DRAWER8           "DRAWER 8"  // "DRAWER 8"


#define PBFunction0       "OPEN    "  // "����"
#define PBFunction1       "ADD     "  // "��̨����"
#define PBFunction2       "SERVICE "  //  "�ݽ�"
#define PBFunction3       "CONFIRM "  //  "ȷ�Ͻ���"
#define PBFunction4       "PRINT   "  //   "��ӡ��̨"
#define PBFunction5       "PRT BILL"  //   "��ӡ�ʵ�"
#define PBFunction6       "CANCEL  "  //   "ȡ��ȷ��'
#define PBFunction7       "SPLIT   "  //   "����"
#define PBFunction8       "TRANSFER"  //   "ת��"
#define PBFunction9       "MOVE TO "  //   "ת����"
#define PBFunction10      "GUSET   "  //   "����"
#define PBFunction11      "COMBINE "  //   "�ϲ�"

#define PORAType1         "P.O.    "  // "����    "
#define PORAType2         "R.A.    "  // "���    "
#define PORAType3         "REFUND  "  //"IC���˿�"
#define PORAType4         "CHARGE  "  //"IC����ֵ"
#define PORAType5         "REDEEM  "  //"��ICѺ��"  ZWQ
#define PORAType6         "DEPOSIT "  //"��ICѺ��"  ZWQ

#define TendType1         "CASH    "  //"�ֽ�    "
#define TendType2         "CHECK   "  //"֧Ʊ    "
#define TendType3         "C.CARD  "  //"���ÿ�  "
#define TendType4         "COUPON  "  //"����ȯ  "
#define TendType5         "CREDIT  "  //"����"
#define TendType6         "CHIPCARD"  //"ICCard"

#define Modifier1         "MODIFIER"  //"˵��    "
#define ClerkRec1         "CLERK"  //"�տ�Ա  "
#define GroupRec1         "GROUP   "  //"����    "
#define DeptRec1          "DEPT    "  //"����    "
#define PLURec1           "PLU     "  //"��Ʒ    "
#define SalesPersonRec1   "S.PERSON"  //"ӪҵԱ  "	ZWQ
#define OffRec1           "OFFER   "  //"�������"
#define PortRec1		  "PORT "
#define AgreeRec1		  "AGREEMENT"
#define TeleRec1		  "TELE"		// ???


#define TAXType1	"VAT A"
#define TAXType2	"VAT B"
#define TAXType3	"VAT C"
#define TAXType4	"VAT D"
#define TAXType5	"VAT E"
#define TAXType6	"VAT F"
#define TAXType7	"VAT G"
#define TAXType8	"VAT H"

//===end Def=


//===========Messages for Display:DMes==============
//DMes1,DMes2,DMes3,DMes4,DMes5,DMes6,DMes7,DMes8,DMes14,DMes16,DMes19,DMes20,DMes25�����������ʾPutsO(DMes1)
#if((DISP2LINES) || DD_LCD_1601==1)
//ccr20140715 Max.Length<16 >>>>>>>>>>
#define DMes1    " CHANGE PRICE "		/* 0, Plu Price Change (PutsO)*/
#define DMes2    " ADD"		/* 1, Inventory ++  (PutsO)*/
#define DMes3    " REMOVE "		/* 2, Inventory --  (PutsO)*/
#define DMes4    " KP_GROUP"		/* 3, Kitchen Printer Group  (PutsO)*/
#define DMes5    " CORRECT"		/* 4, Correction (PutsO)*/
#define DMes6    " REFUND"			/* 5, Refund (PutsO)*/
#define DMes7    " CANCEL 1"		/* 6, Cancel 1 function (PutsO)*/
#define DMes8    " CANCEL 2"		/* 7, Cancel 2 function (PutsO)*/
#define DMes9    " RS232 ERROR"		/* 8, RS232 Test */
#define DMes10   " RS232 OK"		/* 9, RS232 Test */
#define DMes11   " RTC ERROR"		/* 10, RTC Test Error */
#define DMes12   " CTC ERROR"		/* 11, CTC Test Error */
#define DMes13   " FPROM ERROR"		/* 12, Fiscal Prom Error */
#define DMes14   "INITIALIZATION"		/* 13, Clearing RAM (PutsO)*/
#define DMes15   " INIT END"			/* 14, Initialising Application */
#define DMes16   " SLIP PAPER"		/* 15, Change Slip Paper (PutsO)*/
#define DMes17   " PASSWORD? "		/* 16, Secret Clerk Code */
#define DMes18   " ERROR- "			/* 17, Error code        */
#define DMes19   "PASSWORD ERROR"	/* 18, Error code   (PutsO)     */
#define DMes20   " ACCEPTED"		/* 19, Error code   (PutsO)     */
#define DMes21   "CLERK:"		/*20 �տ�Ա��  */
#define DMes22   "S.PERSON: "		/* 21 ӪҵԱ:  */
#define DMes23   "ECR#:"	/*22 �տ����  */  //ZWQ
#define DMes24   "LOCATION:"		/*23 λ��  */ //ZWQ
#define DMes25   "CONFIRM ?"		//24 (PutsO)
#define DMes26   "COMPLETED"			//25		???
#if defined(FOR_DEBUG)
#define DMes27   "VERSION(DEBUG):"		//26 "���а汾"	//
#else
#define DMes27   "VERSION(RELEASE):"		//26 "���а汾"	//
#endif
#define DMes28   "POINTS"			//27 "�������ѵ�"	 //
#define DMes29   "ADD PLU "			//28 "���ӵ�Ʒ:"	//
#define DMes30   "DELETE PLU:"		//29"ɾ����Ʒ:"	//
#define DMes31   "TEST STARTED>>"		//30"��ʼ���"	//
#define DMes32   "TEST COMPLETED"		//31"������"	// ZWQ
#define DMes33   "PRICE"			//32
#define DMes34   "STOCK"		//33
//<<<<<<<<<<<<<<<<<<<<
#else//ENGLISH
//ccr20140715 Max.Length<12 >>>>>>>>
#define DMes1    " PLU EPP"    /* 0, Plu Price Change */
#define DMes2    " INV.ADD"    /* 1, Inventory ++  */
#define DMes3    " INV.SUB"    /* 2, Inventory --  */
#define DMes4    " GROUP"    /* 3, Kitchen Printer Group  */
#define DMes5    " CORR."    /* 4, Correction */
#define DMes6    " REFUND"    /* 5, Refund */
#define DMes7    " CANCEL 1"    /* 6, Cancel 1 function */
#define DMes8    " CANCEL 2"    /* 7, Cancel 2 function */
#define DMes9    " RS232 ERR"    /* 8, RS232 Test */
#define DMes10    " RS232 OK"    /* 9, RS232 Test */
#define DMes11    " RTC ERR"    /* 10, RTC Test Error */
#define DMes12    " CTC ERR"    /* 11, CTC Test Error */
#define DMes13    " FPROMERR"    /* 12, Fiscal Prom Error */
#define DMes14    " INIT----"    /* 13, Clearing RAM */
#define DMes15    " INIT END"    /* 14, Initialising Application */
#define DMes16    " CHG SLIP"    /* 15, Change Slip Paper */
#define DMes17    " PASS ?"    /* 16, Secret Clerk Code */
#define DMes18    " ERROR-"     /* 17, Error code        */
#define DMes19    " PWD ERROR"     /* 18, Error code        */
#define DMes20    " ACCEPTED "     /* 19, Error code        */
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#if (PRTLEN<25)
//ccr20140715 Max.Length<6 >>>>>>>>>>>
#define DMes21    "OPER.:"	//*20 �տ�Ա��
#define DMes22    "S.PER.:"		//* 21 ӪҵԱ:
#define DMes23    "ECR#:"	//*22 �տ����
//<<<<<<<<<<<<<
#else
//ccr20140715 Max.Length<9 >>>>>>>>>>>
#define DMes21    "CLERK:"	//*20 �տ�Ա��
#define DMes22    "S.PERSON:"		//* 21 ӪҵԱ:
#define DMes23    "ECR#:"	//*22 �տ����
//<<<<<<<<<<<<<<<
#endif
#define DMes24    "LOCATION:"				//*23 λ��
#define DMes25    "CONFIRM ?"	 //24
#define DMes26    " FINISH "		 //25
#if defined(FOR_DEBUG)
#define DMes27   "VERSION(DEBUG):"		//26 "���а汾"	//
#else
#define DMes27   "VERSION(RELEASE):"		//26 "���а汾"	//
#endif
#define DMes28	"POINTS"	//27 "�������ѵ�"	 //
#define DMes29	"ADD PLU:" //28 "���ӵ�Ʒ:"	//
#define DMes30	"DEL PLU:" //29"ɾ����Ʒ:"	//
#define DMes31	"TEST START" //30"��ʼ���"	//
#define DMes32	"TEST COMPLETED" //31"������"	//
#define DMes33    "PRI_"								//32
#define DMes34    "INV_"							//33
#endif
//==end DMess

#define UPCOMM1    "UOK"			//0
#define UPCOMM2    "UCA"			//1
#define UPCOMM3    "UEN"			//2
#define UPCOMM4    "UER"			//3

//=========DText==========//
#if(DD_LCD_1601==1 || (DISP2LINES))
//#define DTEXTLEN 15
#define DText1    "CURRENCY"		/* 0, Foreign Currency */
#define DText2    "TOTAL"		/* 1, Sales Total */
#define DText3    "CHANGE"			/* 2, Change */
#define DText4    "SUBTOTAL"		/* 3, Subtotal */ //ZWQ
#define DText5    "DISCOUNT"		/* 4, Discount */
#define DText6    "P.O"			/* 5, Paid Out */	//ZWQ
#define DText7    "R.A"		/* 6, Received On Account */ //ZWQ
#define DText8    "DRAWER"		/* 7, Drawer */
#define DText9    "TABLE#"		/* 8, Table Number */
#define DText10   "SERVICE"			/* 9, Service */
#define DText11   "CHECKS PAID"		/* 10, Checks Paid */
#define DText12   "CHECK CANCEL"		/* 11, cancel Checks Paid */
#define DText13   "GUEST"			/* 12, Covers */
#define DText14   "CLERK"		/* 13, Clerk */
#define DText15   "MODIFIER"		/* 14, Modifier */
#define DText16   "HOLD"			/* 15, Suspend/Recall tekst */
#define DText17   "CANCEL"			/* 16, Transaction void */
#define DText18   "SALESPERSON"		/* 17, SalesPerson */
#define DText19   "OFF"			// 18, LOCK mode

#define DText20   MessMODEReg   	// 19,Reg mode
#define DText21   MessMODEX     		// 20,X report mode
#define DText22   MessMODEZ     	// 21,Z report mode
#define DText23   MessMODESET   // 22, SET mode
#define DText24   MessMODEMAN 		// 23, Manager mode
                                    //
#define DText25   "PASSWORD"		// 24,Password for XMode
#define DText26   "NEW PASSWORD"		// 25,New password for xMode
#define DText27   "CONFIRM PWD"		// 26,Confirm new password for XMode
#define DText28   "PRICE:"			/* 27	���� */
#define DText29   "AMT.:"			/* 28  ��� */
#define DText30   "RETAIL"		// 29		ZWQ
#define DText31   "RESTAURANT"		// 30
#define DText32   "-"					/* 1 �� */
#define DText33   "-"					/* 32 ��  */
#define DText34   " "					/* 33 ��  */
#define DText35   "TEST MODE"		// 34
#define DText36   "RAM:"			//35
#define DText37   "OBLI."		/* 36  Subtotal */ //ZWQ
#define DText38     "FINISHED"		/* 37, cash finished  */

#else
//#define DTEXTLEN 6
//ccr20140715 Max.Length<6>>>>>>>>>>>>>>
#define DText1    "CUR"          /* 0, Foreign Currency */
#define DText2    "TOT"          /* 1, Sales Total */
#define DText3    "CHG"          /* 2, Change */
#define DText4    "SUB"          /* 3, Subtotal */
#define DText5    "DSC"          /* 4, Discount */
#define DText6    "PO"          /* 5, Paid Out */
#define DText7    "RA"          /* 6, Received On Account */
#define DText8    "DRAW"          /* 7, Drawer */
#define DText9    "TABLE"          /* 8, Table Number */
#define DText10   "SER"          /* 9, Service */
#define DText11   "CPA"          /* 10, Checks Paid */
#define DText12   "CCP"          /* 11, Cancel Checks Paid */
#define DText13   "COV"          /* 12, Covers */
#define DText14   "OPER"          /* 13, Clerk */
#define DText15   " ADD"          /* 14, Modifier */
#define DText16   "HOLD"          /* 15, Suspend/Recall tekst */
#define DText17   "CANC"          /* 16, Transaction void */
#define DText18   "SALP"          /* 17, SalesPerson */
#define DText19		"OFF"		  // 18, OFF mode ZWQ
                                  //
#define DText20		MessMODEReg      // 19,Reg mode
#define DText21		MessMODEX        // 20,X report mode
#define DText22		MessMODEZ        // 21,Z report mode
#define DText23		MessMODESET      // 22, SET mode
#define DText24		MessMODEMAN      // 23, Manager mode

#define DText25		"Pwd"			  // 24,Password for XMode
#define DText26		"Pwd1"			  // 25,New password for xMode
#define DText27		"Pwd2"			  // 26,Confirm new password for XMode
#define DText28		"PRI.:"	  /* 27	���� */
#define DText29		"AMT.:"	  /* 28  ��� */
#define DText30		"RETAIL"					// 29
#define DText31		"HOSP."					// 30
#define DText32		"-"		/* 31 �� */
#define DText33		"-"		/* 32 ��  */
#define DText34		" "		/* 33 ��  */
#define DText35		"TEST"		// 34
#define DText36     "RAM:"				//35
#define DText37     "OBLI."		/* 36, Subtotal */
#define DText38     "FINISHED"		/* 37, cash finished  */
#endif
//==end DText
//ccr20140715 Max.Length<6>>>>>>>>>>>>>>
#define	CusDText1	"TOT"
#define	CusDText2	"SUB"
#define	CusDText3	"CHG"
#define	CusDText4	"PRI"
#define	CusDText5	"CAN"
#define	CusDText6	"CUR"
#define	CusDText7	"COV"
//<<<<<<<<<<<<<<<<<<<<<
//=========XZTitle ����ʾ��==============//
#if((DISP2LINES)  || DD_LCD_1601==1)

//ccr20140715 Max.Length<15>>>>>>>>>>>>>>
#define XZTitle1		"JOURNAL DAILY"
#define XZTitle2		"JOURNAL SALES"
#define XZTitle3		"PLU REPORT"
#define XZTitle4		"TABLE REPORT"
#define XZTitle5		"TIME ZONE"
#define XZTitle6		"CLERK-1 DAILY"
#define XZTitle7		"CLERK-1 SALES"
#define XZTitle8		"CLERK DAILY"
#define XZTitle9		"CLERK SALES"
#define XZTitle10		"SALER-1 DAILY"
#define XZTitle11		"SALER-1 SALES"
#define XZTitle12		"SALER DAILY"
#define XZTitle13		"SALER SALES"
//ccr2017-05-27>>>>>>>>>>>>>>>>>>>>
#define XZTitle14       "DEPART DAIILY" //{14,"�����ձ���"},     ItemXZ_DEPTDAILY ,
#define XZTitle15       "DEPART SALES"  //{15,"�������ڱ���"},   ItemXZ_DEPTPERIOD,
#define XZTitle16       "GROUP DAILY"   //{16,"�����ձ���"},     ItemXZ_GROUPDAILY,
#define XZTitle17       "PLUS SALES"    //{17, "��Ʒ���ڱ���"},  ItemXZ_PLUPERIOD,

//ccr2017-05-27<<<<<<<<<<<<<<<<<<<<
#define XZTitleBAR		"MEMBERSHIP"
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#else
//ccr20140715 Max.Length<8>>>>>>>>>>>>>>
#define XZTitle1		"JOURN_D"
#define XZTitle2		"PERIOD"
#define XZTitle3		"PLUS_D"
#define XZTitle4		"TABLE J_"
#define XZTitle5		"ZONE"
#define XZTitle6		"CLERK_D"
#define XZTitle7		"CLERK_S"
#define XZTitle8		"CLERKS_D"
#define XZTitle9		"CLERKS_S"
#define XZTitle10		"SALER_D"
#define XZTitle11		"SALER_S"
#define XZTitle12		"SALERS_D"
#define XZTitle13		"SALERS_S"
//ccr2017-05-27>>>>>>>>>>>>>>>>>>>>
#define XZTitle14       "DEPART_D" //{14,"�����ձ���"},     ItemXZ_DEPTDAILY ,
#define XZTitle15       "DEPART_S"  //{15,"�������ڱ���"},   ItemXZ_DEPTPERIOD,
#define XZTitle16       "GROUP_D"   //{16,"�����ձ���"},     ItemXZ_GROUPDAILY,
#define XZTitle17       "PLUS_S"    //{17, "��Ʒ���ڱ���"},  ItemXZ_PLUPERIOD,
//ccr2017-05-27<<<<<<<<<<<<<<<<<<<<

#define XZTitleBAR		"Bar_USER"
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#endif
//==end XZTitle

//==============PortType============//
#if (DISP2LINES)
//ccr20140715 Max.Length<16>>>>>>>>>>>>>>
#define PortType1		"        BARCODE" //OLD "       HOST(PC)"
#define PortType2		"          SCALE" //OLD "          RS485"
#define PortType3		"   EXTERNAL LCD" //OLD "          MODEM"
#define PortType4		"  EXT. KEYBOARD" //OLD "         READER"
#define PortType5		" KITCHEN RINTER" //OLD "          SCALE"
#define PortType6		"       HOST(PC)" //OLD "KITCHEN PRINT"
#define PortType7		"       NOT USED" //OLD "   SLIP PRINT"
//#define PortType8		"           EFT"	//ccr epos

//<<<<<<<<<<<<<<<<<<
#else
//ccr20140715 Max.Length<7>>>>>>>>>>>>>>
#define PortType1		"BARCOD" //old "  HOST"
#define PortType2		" SCALE" //old " RS485"
#define PortType3		"EXTLCD" //old " MODEM"
#define PortType4		"EXTKEY" //old "READER"
#define PortType5		" K_PRN" //old " SCALE"
#define PortType6		"  HOST" //old "KP_PRT"
#define PortType7		"  NONE" //old "  SLIP"
//#define PortType8		"  EFT"	//ccr EFT POS ZWQ
//<<<<<<<<<<<<<<<<<<<<<<<<<
#endif
//==END PortType

//=============KPType=============//
#define KPType1		"   OFF"		//�̶�Ϊ[7]
#define KPType2		"INTERL"		//�̶�Ϊ[7]
#define KPType3		" EP-42"    //EPSON��ӡ��,ʹ��A����, 42�ַ�����
#define KPType4		"  EP-A"    //EPSON��ӡ��,ʹ��A����, 30�ַ�����
#define KPType5		"  EP-B"    //EPSON��ӡ��,ʹ��B����, 42�ַ�����
#define KPType6		" EP-48"    //EPSON��ӡ��,���е�, 48�ַ�����
#define KPType7		" CT-30"    //�����Ǵ�ӡ��, 30�ַ�����
#define KPType8		"PRT-58"    //POS58��ӡ��,���е�,30�ַ�����
//==end KPType

//=========SPType==============//
#define SPType1		"   OFF "
#define SPType2		"CTM-290"
#define SPType3		"TM290-2"
#define SPType4		"EP-C"
#define SPType5		"EP-NC"
//==end SPType

//================SysFlagUsed=============//
#if(0)//ccr2017-05-08((DISP2LINES) || DD_LCD_1601==1)
#define SysFlag_ECRNo	"ECR#:     "		//(1)0 	 0-255"ECR_no    "
#define SysFlag_SHOPNo	"LOCATE#:  "		//(1)0 	 0-255"LOCATION  "
#define SysFlag_ROUND	"ROUNDING:      "		//(2)1 	 0,1,2,3,4"Round_    "
#define SysFlag_CHGPRICE	"PRICE VARIED:  "		//(3)2	 bit1"PLU_Free  "
#define SysFlag_BEEP	"BUZZER:        "			//(4)3	 bit0"beep      "
#define SysFlag_CLERKMUST	"CLERK OBLI.:"	//(5)4	 bit0"Obl_Oper  "
#define SysFlag_CLERKLOGIN	"CHANGE OPER.?: "	//(6)5	 bit0"DisX_Oper "
#define SysFlag_CLERKPWD	"CLERK PWD:  "		//(7)6	 bit0"Pass_Oper "
#define SysFlag_PRNSALER	"PRINT S.PERSON:"		//(8)7 bit0"Saleper_Num  "
#define SysFlag_CLERK	"PRINT CLERK:"		//(9)8	 bit0"Prin_Oper "
#define SysFlag_PRNRECNo	"PRINT RECEIPT#:"		//(10)9   bit3"Prin_Recn "
#define SysFlag_PAPER	"HEAVY PRINT"			//(11)10  1,2,3"Paper_Type  "
#define SysFlag_SALERMUST	"S.PERSON OBLI.:"		//(12)11 bit6"Obl_Saleper_ "
#define SysFlag_PRNPLUNo	"PRINT PLU#:    "		//(13)12 bit0"ArtCode   "
#define SysFlag_SUBTMUST	"SUBTOTAL OBLI.:"		//(14)13 bit0"Obl_Subt_ "
#define SysFlag_PRNITEMS	"PRINT ITEMS:"		//(15)14 bit0"Art_no_   "
#define SysFlag_PRNALLONE	"STUB PRINT:    "		//(16)15 bit7"TALLONS   "
#define SysFlag_ALLONEHEAD	"STUB FORMAT:   "		//(17)16 bit0"TALLON HEADER AND TAILER "
#define SysFlag_SHIFTDEPT	"SHIFT LOCKED:  "		//(18)17 bit7"En_Shift"
#define SysFlag_IDLETIME	"IDLE TIME:     "			//(19)18 0..99"Time_IDLE "
#define SysFlag_COPYRECEIPT	"RECEIPT COPIES:"		//(20)19 0..15"CopyReceipt "
#define SysFlag_PREONAMT	"PRICE CODE:    "			//(21)20 bit3 "EANSpec_"
#define SysFlag_AMTPOINT	"AMT POINT:"	//(22)21  bit4"select collect flow " //lyq2003
#define SysFlag_PRNBALANCE	"PRT PRE.BALANCE"		//(23)22  bit4"select pb print " //lyq2003
#define SysFlag_PRNSTOCK	"PRT STOCK:     "		//(24)23  bit4"select inv print " //lyq2003
#define SysFlag_DISPRINT	"RECEIPT PRINT: "	//(25)24  bit5"allow press operator key to close printer" //lyq2003
#define SysFlag_TABLEMUST	"TABLE OBLI.:   "	//(26)25  "���뿪̨:"},
#define SysFlag_KEEPRECNo	"KEEP R-NO#:    "		//(27)26  "�����վݺ�"},
#define SysFlag_COPYKPRN	"K.PRT COPY:    "			//(28)27   //ccr040810
#define SysFlag_RESETRECNo	"RESET R-NO:    "		//(29)28  "�վݺŸ�λ" //
#define SysFlag_CUTTER 	    "CUTTER:        "            // (29)28"ʹ���е�" //
#define SysFlag_DATETYPE 	"DATE TYPE:     "          // (30)29      0-2"Date Type "
#define SysFlag_TIMETYPE 	"TIME 24H:      "           // (31)30  bit0 "time format 12 or 24"
#define SysFlag_HEADCENTER  "HEAD CENTER:   "  // "Ʊͷ���д�ӡ"
#define SysFlag_TRAILCENTER "TRAIL CENTER   "  // "Ʊβ���д�ӡ"
#define SysFlag_SUMMERTIME  "DAYLIGHT TIME  "  //ccr2017-08-07 ��ʱ��
#define SysFlag_PRINTTAXAMT "PRINT TAX AMT  "  //ccr2018-03-20

#else

#define SysFlag_ECRNo	    "ECR#:"		//(1)0 	 0-255"ECR_no    "
#define SysFlag_SHOPNo	    "LOCATE#:"		//(1)0 	 0-255"LOCATION  "
#define SysFlag_ROUND	    "ROUNDING:"		//(2)1 	 0,1,2,3,4"Round_    "
#define SysFlagAmtMax       "AMOUNT MAX:"     // �վ������������
#define SysFlag_CHGPRICE	 "PRICE CHANGE:"	//(3)2	 bit1"PLU_Free  "
#define SysFlag_BEEP	    "BUZZER:"			//(4)3	 bit0"beep      "
#define SysFlag_CLERKMUST	 "OPER. OBL:"	//(5)4	 bit0"Obl_Oper  "
#define SysFlag_CLERKLOGIN	 "CHANGE OPER:"	//(6)5	 bit0"DisX_Oper "
#define SysFlag_CLERKPWD	 "CLERK PWD:"		//(7)6	 bit0"Pass_Oper "
#define SysFlag_PRNSALER	 "PRINT SALER:"		//(8)7 bit0"Saleper_Num  "
#define SysFlag_CLERK	    "PRN CLERK:"		//(9)8	 bit0"Prin_Oper "
#define SysFlag_PRNRECNo	 "PRINT RCP#:"		//(10)9   bit3"Prin_Recn "
#define SysFlag_PAPER	    "DENSITY:"			//(11)10  1,2,3"Paper_Type  "
#define SysFlag_SALERMUST	 "SALER OBL:"		//(12)11 bit6"Obl_Saleper_ "
#define SysFlag_PRNPLUNo	 "PRINT PLU#:"		//(13)12 bit0"ArtCode   "
#define SysFlag_SUBTMUST	 "SUBTOTAL OBL:"		//(14)13 bit0"Obl_Subt_ "
#define SysFlag_PRNITEMS	 "PRINT ITEMS:"		//(15)14 bit0"Art_no_   "
#define SysFlag_PRNALLONE	 "STUB PRINT:"		//(16)15 bit7"TALLONS   "
#define SysFlag_ALLONEHEAD	 "STUB FORMAT:"		//(17)16 bit0"TALLON HEADER AND TAILER "
#define SysFlag_SHIFTDEPT	 "SHIFT LOCK:"		//(18)17 bit7"En_Shift"
#define SysFlag_IDLETIME	 "IDLE TIME:"			//(19)18 0..99"Time_IDLE "
#define SysFlag_COPYRECEIPT	 "COPY RECEIPT:"		//(20)19 0..15"CopyReceipt "
#define SysFlag_PREONAMT	 "PRICE CODE:"			//(21)20 bit3 "EANSpec_"
#define SysFlag_AMTPOINT	 "DECIMAL:"	//(22)21  bit4"select collect flow " //lyq2003
#define SysFlag_PRNBALANCE	 "PRN.BALANCE:"		//(23)22  bit4"select pb print " //lyq2003
#define SysFlag_PRNSTOCK	 "PRN.STOCK:"	//(24)23  bit4"select inv print " //lyq2003
#define SysFlag_DISPRINT	 "CLOSE PRINT:" //(25)24  bit5"allow press operator key to close printer" //lyq2003
#define SysFlag_TABLEMUST	 "TABLE MUST:"	//(26)25  "���뿪̨:"},
#define SysFlag_KEEPRECNo	 "KEEP RCP#:"	//(27)26  "�����վݺ�"},
#define SysFlag_COPYKPRN	 "COPY K.P:"		//(28)27   //ccr040810
#define SysFlag_RESETRECNo	 "RESET RCP#:"	//(29)28  "�վݺŸ�λ" //
#define SysFlag_CUTTER       "CUTTER:"            // (29)28"ʹ���е�" //
#define SysFlag_DATETYPE     "DATE TYPE:"          // (30)29      0-2"Date Type "
#define SysFlag_TIMETYPE     "TIME 24H:"           // (31)30  bit0 "time format 12 or 24"
#define SysFlag_HEADCENTER   "HEAD Center:"  // "Ʊͷ���д�ӡ"
#define SysFlag_TRAILCENTER  "TRAIL Center"  // "Ʊβ���д�ӡ"
#define SysFlag_SUMMERTIME   "DAYLIGHT TIME"  //ccr2017-08-07 ��ʱ��
#define SysFlag_CUSTOMERCARD  "CUSTOMER CARD"  //ccr2017-09-21
#define SysFlag_PRINTTAXAMT  "PRINT TAX AMT"  //ccr2018-03-20

#endif
//==end SysFlagUsed

//=============Grap============//
#define GrapType1		"SHOP TYPE"
#define GrapType2		"FESTIVAL "
#define GrapType3		"LOGO     "
#define GrapType4		"PROG_MSG?"
#define GrapSet1		"NUMBER   "
#define GrapSet2		"PICTURE  "
#define GrapSet3		"FROM     "
#define GrapSet4		"TO       "
//===end Grap

//=============ConfigTable=============//

#define ConfTab1		"FILES"
#define ConfTab2		"FILE MEMORY"		     //	"�ļ��ռ䣺"1
#define ConfTab3		"STATISTIC"		       //"ͳ���ļ�"2
#define ConfTab4		"TENDER"		         //"������Ϣ"	3
#define ConfTab5		"PO/RA"		           //"�������Ϣ"4
#define ConfTab6		"DRAWER"		         //"Ǯ����Ϣ"5
#define ConfTab7		"CORRECT"		         //"������Ϣ"6
#define ConfTab8		"CURRENCY"	  		   //"�����Ϣ"7
#define ConfTab9		"TAX"	               //"��˰"8
#define ConfTab10		"PREV. BALANCE"      //"��̨����"��9
#define ConfTab11		"OFFER"              //"��������ļ���"	10
#define ConfTab12		"AGREEMENT"          //"ǩ���ļ�:"11
#define ConfTab13		"PLU CODE"		       //"��Ʒ�����ļ���"12
#define ConfTab14		"PB FUNCTION"		             //"������Ϣ"13
#define ConfTab15		"PB BUFFER"          //"��̨������"14
#define ConfTab16		"SIZE OF EJ"		     //"��ˮ�ռ䣺"15
#define ConfTab17		"PORT"               //"����"	16
#define ConfTab18		"SIZE OF RAM"        //17
#define ConfTab19		"BLOCKED ID"            //18 GUASHIIC
#define ConfTab20		"SIZE OF FM"         //19
#define ConfTab21		"       FREE"         //19
#define ConfTab22		" FREE OF FM"         //19

#define REMAINEJ		"       FREE"       //20"��ˮ�ռ䣺"15
#define REMAINFM		" FREE OF FM"

#define DATEOFZ		"Z-DATE"
#define DATEOFEJ	"EJ-DATE"



#if (PRTLEN<25)
#define ConfTi1		"FILE   RECORD   RAM "
#define ConfTi2 	"PORT   TYPE     PROT"
#else
#define ConfTi1		"FILE           RECORD       RAM "
#define ConfTi2 	"PORT         TYPE       PROTOCOL"
#endif

//==end ConfTab

//==============Prompt=================//
#if ((DISP2LINES) || DD_LCD_1601==1)
#define Prompt1		"TOTAL"	// Ӧ�� 0 */
#define Prompt2		"SUBTOTAL"		// 1
#define Prompt3		"SPENDING"		// 2"�����ܶ� "
#define Prompt4		"AMOUNT AFTER DISC."		// 3
#define Prompt5		"PRICE"				// 4
#define Prompt6		"TRANSACTIONS"	//5
#define Prompt7		"QUANTITIES"		//6
#define Prompt8		"AMOUNT"			//7
#define Prompt9		"COLLECT"		//8   ZWQ
#define Prompt10	"CHANGE"		//9
#define Prompt11	" "					/* 10 */
#define Prompt12	" "					/* 11 */
#define Prompt13	"-"					/* 12 */
#define Prompt14	"-"					/* 13 */
#define Prompt15	"STANDARD"		/* 14 */
#define Prompt16	"CLERK"		//15
#define Prompt17	" "			//16
#define Prompt18	" "					//17
#define Prompt19	"-"				//18
#define Prompt20	"REPORT"		/* 19 */
#define Prompt21	"REFUND"		/* 20 */
#define Prompt22	"DISCOUNT"		//21
#define Prompt23	"COST"		//22
#define Prompt24	"TABLE#"			//23
#define Prompt25	"CHECK#"		/* 24 used for Register ID with EFT */
#define Prompt26	"QUANTITIES"		//25
#define Prompt27	"GROSS SALES"		//26
#define Prompt28	"TAX"			//27
#define Prompt29	"PAGE"		//28   ???
#define Prompt30	"No.#:"		//29
#define Prompt31	"SERVICE"		//30
#define Prompt32	"PREV. BALANCE "		//31
#define Prompt33	"Z COUNT"		//32
#define Prompt34	"CLEAR"		//33
#define Prompt35	"SYSTEM REPORT"	//34
#define Prompt36	"GROSS PROFIT"		//35
#define Prompt37	"STOCK UPDATE"	//36
#define Prompt38	"FORMER PB:"		//37
#define Prompt39	"CREDIT CARD#"	//38
#define Prompt40	"NEW TABLE:"		//39
#define Prompt41	"GUESTS"		//40
#define Prompt42	"EXCHANGE"		//41
#define Prompt43	"ADD NEW PLU?"		//ccr  42 Add random number
#define Prompt44	"DELETE PLU?"		//ccr  43 delete random number
#define Prompt45	"DISCOUNT 1"		//44
#define Prompt46	"DISCOUNT 2"		//45
#define Prompt47	"SALES"		//46
#define Prompt48	"MIX-MATCH"		//47
#define Prompt49	"STOCK"		//48
#define Prompt50	"OFFER"		//49
#define Prompt51	"OPTIONS"			//50 for options
#define Prompt52	"KITCHEN PRINT"		//51 for KP option
#define Prompt53	"FIXED DISCOUNT"	//52 Options for Discount
#define Prompt54	"FLOAT DISCOUNT"	//53
#define Prompt55	"FIXED+FLOAT"		//54
#define Prompt56	"OPEN()"		//55 Options for PBFunction
#define Prompt57	"OP_ADD"		//56
#define Prompt58	"SERVICE"		//57
#define Prompt59	"CONFIRM"		//58
#define Prompt60	"PRINT/OPEN"		//59
#define Prompt61	"PRINT BILL"		//50
#define Prompt62	"CANCEL"		//61
#define Prompt63	"SPLIT BILL"		//62
#define Prompt64	"TRANSFER"		//63
#define Prompt65	"MOVE TO"		//64
#define Prompt66	"GUEST"		//65
#define Prompt67	"JOLLY ?"		//66
#define Prompt68	"POINT ?"		//67
#define Prompt69	"DECREASE ?"		//68 ???
#define Prompt70	"CHIP CARD?"		//69
#define Prompt71	"DISCOUNT"		//70
#define Prompt72	"CASH"		//71
#define Prompt73	"CREDIT"	//72
#define Prompt74	"CARD INFO.PRT"		//73
#define Prompt75	"AUTO DISCOUNT "	//74
#define Prompt76	"POINTS"		//75
#define Prompt77	"<CASH> CLOSE"	//76 ZWQ
#define Prompt78	"CHARGE/DISCHG?"	//77
#define Prompt79	"EXPIRED DATE "		//78

//Option for dept==================

#define Prompt80	"ZERO PRICE:"		// 79	Ccr "��ֹ��۸�"		//JZHLJGE
#define Prompt81	"SEPARAT LINE"		// 80	Ccr "��ӡ�ָ���"		//DYFGXIAN
#define Prompt82	"SINGLE ITEM:"		// 81	Ccr "��������:"		//DXXSHOU
#define Prompt83	"DISCOUNT 1:"		// 82 	Ccr "�ۿ��� 1:"		//ZHKXIANG1
#define Prompt84	"DISCOUNT 2:"		// 83 	Ccr "�ۿ��� 2:"		//ZHKXIANG2
//Option for KP===================
#define Prompt85	"PRINT TOTAL:"		// 84	Ccr "��ӡ�ܶ�:"		//KPDYZE
#define Prompt86	"COMBINATION:"		// 85	Ccr "����ͬ��ӡ"		//KPCXTDY
#define Prompt87	"SORTED:"		// 86	Ccr "�˲�ͬ��ӡ"		//KPCBTDY  ZWQ
//Options for tend=================
#define Prompt88	"OPEN DRAWER:"		// 87	Ccr "��Ǯ��:"		//DKQXIANGF
#define Prompt89	"AMT.COMPULSORY"	// 88	Ccr "������:"		//SHRJE
#define Prompt90	"AMT.FORBIDDEN:"	// 89	Ccr "��ֹ����:"		//JZHSHRU
#define Prompt91	"INPUT CODE:"		// 90	Ccr "�������:"		//SHRHMA
#define Prompt92	"TIP:"			// 91	Ccr "����ΪС��"		//ZHLXFEI
//Options for PoRa=================
#define Prompt93	"OPEN DRAWER:"		// 92	Ccr "��Ǯ��:"		//DKQXIANGP
#define Prompt94	"<TENDER>:"		// 93	Ccr "���ʽ��"		//FKFSHJIAN
#define Prompt95	"DEPOSIT:"		// 94	Ccr "������:"		//CRJE
#define Prompt96	"TYPE:"			// 95	Ccr "���/����"		//RJCHJIN
//Option for Disc==================
#define Prompt97	"PRINT DISC.:"		// 96	Ccr "��ӡ�ۿ۶�"		//DYZHKE
#define Prompt98	"DISCOUNT 1:"		// 97	Ccr "ʹ���ۿ�1:"		//SHYZHK1
#define Prompt99	"DISCOUNT 2:"		// 98	Ccr "ʹ���ۿ�2:"		//SHYZHK2
//Options for currency==============
#define Prompt100	"CHANGE:"		// 99	Ccr "����������"		//MCHJZHLIN
//Options for Draw================
#define Prompt101	"NON DECIMAL:"		// 100	Ccr "��С����:"		//WXSHDIAN
#define Prompt102	"OPEN DRAWER:"		// 101	Ccr "��Ǯ��:"		//DKQXIANGD
//Options for Tax=================
#define Prompt103	"ADD ON:"		// 102	Ccr "Ӫҵ/��ֵ/"        //YYZZHI
#define Prompt104	"PRINT TAX:"		// 103	Ccr "��ӡ˰����"		//DYSHLXIANG
#define Prompt105	"PRINT ZERO:"		// 104	Ccr "��ӡ0˰��"		//DYLSHXXI
#define Prompt106	"GST:"			// 105	Ccr "ΪGST��˰"		//WGSTSHUI
#define Prompt107	"PRINT TAX.AMT:"		// 106	Ccr "��ӡ˰��:"		//DYSHE
//Options for clerk================
#define Prompt108	"VOID:"			// 107	Ccr "ȡ������:"		//QXXZHI
#define Prompt109	"CORRECT:"		// 108	Ccr "��������:"		//GGXZHI
#define Prompt110	"CANCEL:"		// 109	Ccr "ȡ������:"		//QXJYIXZHI
#define Prompt111	"REFUND:"		// 110	Ccr "�˻�����:"		//THXZHI
#define Prompt112	"%DISCOUNT:"		// 111	Ccr "%�ۿ�����:"		//BFBZHKXZHI
#define Prompt113	"%SURCHARGE:"	// 112	Ccr "%�ӳ�����:"		//BFBJCHXZHI
#define Prompt114	"NET DIS/SURCH."	// 113	Ccr "+-�������"		//JJJEXZHI
#define Prompt115	"TRAINING MODE:"	// 114	Ccr "��ѵģʽ:"		//PSHMSHI
#define PromptActive "ACTIVE:"       //ItemPrompt115  "ACTIVE"         //ACTIVE
#define PromptPrnLogo  "PRINT LOGO"      //ItemPrompt116  ,        //PRINTLOGO

////////////////////////////////////////////////////////////////
#define DayCap1		"MONDAY  "
#define DayCap2		"TUESDAY "
#define DayCap3		"WEDNSDAY"
#define DayCap4		"THURSDAY"
#define DayCap5		"FRIDAY  "
#define DayCap6		"SATURDAY"
#define DayCap7		"SUNDAY  "
#if (PRTLEN<25)
#define TitleN1		"ITEM     QTY    AMT" //======MAX LENGTH:20
#elif (PRTLEN<=36)
#define TitleN1		"ITEM      QTY      PRI     AMT" //======MAX LENGTH:32
#else
#define TitleN1		"ARTICLE       QUANTITY    PRICE       AMOUNT " //======MAX LENGTH:45
#endif
#define MessageF1	" INVALID ENTRY"		/* 1 */
#define MessageF2	"UNDEFINED CODE!"	/* 2 */
#define MessageF3	"IN TENDERING "		/* 3 */
#define MessageF4	"  INVALID DATE"		/* 4 */
#define MessageF5	"  INVALID TIME"			/* 5 */
#define MessageF6	" ENTER AMOUNT"		/* 6 */
#define MessageF7	"UNKNOWN ARTICLE"		/* 7 */
#define MessageF8	"NO ENTRY ALLOWED"         /* 8 */
#define MessageF9	"TABLE STILL OPEN"		/* 9 */
#define MessageF10	"NO SPLIT TENDER"		/* 10 */
#define MessageF11	"TABLE OPENED"		/* 11 */
#define MessageF12	"UNKNOWN TABLE"		/* 12 */
#define MessageF13	"TABLE REQUIRED"		/* 13 */
#define MessageF14	"TABLE NOT OPEN"		/* 14 */
#define MessageF15	"NO TRACK BUFFER"		/* 15 */
#define MessageF16	"TRACKBUFFER FULL"		/* 16 */
#define MessageF17	"** IN TRADING **"		/* 17 */
#define MessageF18	"UNKNOWN OPER."		/* 18 */
#define MessageF19	"UNKNOWN REPORT"		/* 19 */
#define MessageF20	"* BUF.OVERFLOW *"		/* 20 */
#define MessageF21	"ARTICLE NOT USED"		/* 21 */
#define MessageF22	" ENTRY TO HIGH"		/* 22 */ //???
#define MessageF23	"CHECK KP PRINTER"		/* 23 */
#define MessageF24	"NO PAPER IN SLIP"		/* 24 */
#define MessageF25	" NEW SLIP PAPER"		/* 25 */
#define MessageF26	"INVOICE NUMBER :"		/*"NOT CHECKED OUT"  26 */
#define MessageF27	"STILL IN CK OUT"		/* 27 */
#define MessageF28	"SUSPEND/RECALL"		/*"ONLY CHECK OUT"28 */
#define MessageF29	"OVER MAX COVERS"		/* 29 */
#define MessageF30	" ONLY WITH ITEM"		/* 30 */
#define MessageF31	"KP ERROR!"			/* 31 */
#define MessageF32	"MAX 4 MODIFIERS"		/* 32 */
#define MessageF33	"CHECK SLIP PRINT"		/* 33 */
#define MessageF34	"  WRONG OPER."		/* 34 */
#define MessageF35	"MANAGER KEY REQ"		/* 35 */
#define MessageF36	"**  **"					/* 36 */
#define MessageF37	"**RECEIPT COPY**"		/* 37 */
#define MessageF38	"* SPLIT - BILL *"			/* 38 */
#define MessageF39	"NEAREND R OR J !"		/* 39 */
#define MessageF40	"ENTER NUMBER !!"		/* 40 */
#define MessageF41	"NOT WITH SPLITBI"		/* 41 */
#define MessageF42	"TRANSFERRED TO :"		/* 42 */
#define MessageF43	"*TRAINNING MODE*"		/* 43 */
#define MessageF44	"**INITIALIZING**"		/* 44 */
#define MessageF45	"*** POWER ON ***"		/* 45 */
#define MessageF46	"NOT AUTHORIZED !"		/* 46 */
#define MessageF47	"*INVENTORY +/-*"		/* 47 */ //ZWQ
#define MessageF48	"**CHANGE PRICE**"		/* 48 *///Ccr 	"*** ��Ʒ��� ***"         /* 48 */
#define MessageF49	"KP #1"			/* 49 */
#define MessageF50	"KP #2"			/* 50 */
#define MessageF51	"KP #3"			/* 51 */
#define MessageF52	"KP #4"			/* 52 */
#define MessageF53	"KP #5"			/* 53 */
#define MessageF54	"KP #6"			/* 54 */
#define MessageF55	"KP #7"			/* 55 */
#define MessageF56	"KP #8"			/* 56 */
#define MessageF57	"**** CANCEL ****"		/* 57 *///Ccr 	"***** ȡ�� *****"         /* 57 */
#define MessageF58	"PROFORMA INVOICE"		/* 58 */
#define MessageF59	"KP TOTAL"			/* 59 */
#define MessageF60	"CLERK NULL"			/* 60 */

#define MonthCap1	"JANUARY "
#define MonthCap2	"FEBRUARY"
#define MonthCap3	"MARCH   "
#define MonthCap4	"APRIL   "
#define MonthCap5	"MAY     "
#define MonthCap6	"JUNE    "
#define MonthCap7	"JULY    "
#define MonthCap8	"AUGUST  "
#define MonthCap9	"SEPTMBER"
#define MonthCap10	"OCTOBER "
#define MonthCap11	"NOVEMBER"
#define MonthCap12	"DECEMBER"

#if (DD_LCD_1601==1) //  MAX LENGTH :8
#define LineCap1		"YES"			/*    0     */
#define LineCap2			" NO"			/*    1     */
#define LineCap3			"CAPTION"		/*    2     */
#define LineCap4			"DEPART"		/*    3     */
#define LineCap5			"GROUP"			/*    4     */
#define LineCap6			"SYS FLAG"			/*    5     */
#define LineCap7			"PRINT"			/*    6     */
#define LineCap8			"OPTION"			/*    7     */
#define LineCap9			"EXTRA KP"		/*    8 KP EP = extra printer     */
#define LineCap10			"TAX USED"		/*    9     */
#define LineCap11			"LOC"			/*    10     */
#define LineCap12			"PRICE"			/*    11     */
#define LineCap13			"PRICE 2"			/*    12    */
#define LineCap14			"PRICE 3"			/*    13    */
#define LineCap15			"PRICE 4"			/*    14    */
#define LineCap16			"COST"		/*    15     */  //ZWQ
#define LineCap17			"FIXED"			/*    16 fixed     */
#define LineCap18			"MAX"			/*     17 max      */
#define LineCap19			"FIXED"			/*    18     */
#define LineCap20			"MAX"			/*    19     */
#define LineCap21			"TAX RATE"		/*    20     */
#define LineCap22			"BUY RATE"		/*    21     */
#define LineCap23			"SEL RATE"		/*    22     */
#define LineCap24			"START"			/*    23     */
#define LineCap25			"DRAWER"		/*    24     */
#define LineCap26			"OTD"			/*    25 ��������С��    */
#define LineCap27			"PRT TYPE"		/*    26     */ //???
#define LineCap28			"PERIOD"			/*    27     */
#define LineCap29			"REP TYPE"		/*    28     */
#define LineCap30			"PREFIX"			/*    29     */
#define LineCap31			"LINK"			/*    30     */
#define LineCap32			"KEY CODE"	/*    31     */
#define LineCap33			"MANAGE-K"			/*    32     */
#define LineCap34			"TYPE"			/*    33     */
#define LineCap35			"DATE FR"		/*    34  MAX.Length<=7    */
#define LineCap36			"DATE TO"		/*    35  MAX.Length<=7     */
#define LineCap37			"TIME FR"		/*    36       */
#define LineCap38			"TIME TO"			/*    37     */
#define LineCap39			"WEEK DAY"		/*    38     */
#define LineCap40			"DISCOUNT"		/*    39     */
#define LineCap41			"PACK QTY"		/*    40     */
#define LineCap42			"U.PRICE"		//  41
#define LineCap43			"P.PRICE"		//  42
#define LineCap44			"PROTOCOL"		//  43
#define LineCap45			"TELE#"		    //  44
#define LineCap46			"PASSWORD"		//  45
#define LineCap47			"FREQUENT"		//  46
#define LineCap48			"MINIMUM"		//  47
#define LineCap49			"PORT"			//  48
#define LineCap50			"VALUE"			//  49
#define LineCap51			"GRAPHIC"		//  50
#define LineCap52			"SLIPTYPE"		//  51
#define LineCap53			"BLANKLIN"		//  52  ???
#define LineCap54			"LINEPAGE"		//  53
#define LineCap55			"PRT INFO"		//  54
#define LineCap56			"SECOND"			//  55
#define LineCap57			"LEFT MAR"		//  56
#define LineCap58			"POINT"			//  57
#define LineCap59			"PRILEVEL"			//  58
#define LineCap60			"CONFIRM?"		//  59
#define LineCap61			"FOREGIFT"		//  60
#define LineCap62			"POS CODE"		//  61
#define LineCap63			"USE CASH"		//  62
#define LineCap64			"DEADLINE"		//  63
#define LineCap65           "PERSONAL CODE" //Line_PERSONALCODE
#else //MAX LENGTH :12
#define LineCap1			"YES"			/*    0     */
#define LineCap2			" NO"			/*    1     */
#define LineCap3			"CAPTION"		/*    2     */
#define LineCap4			"DEPART"		/*    3     */
#define LineCap5			"GROUP"			/*    4     */
#define LineCap6			"SYSTEM FLAG"			/*    5     */
#define LineCap7			"PRINT"			/*    6     */
#define LineCap8			"OPTION"			/*    7     */
#define LineCap9			"EXTRA KP"		/*    8 KP EP = extra printer     */
#define LineCap10			"TAX USED"		/*    9     */
#define LineCap11			"LOC"			/*    10     */
#define LineCap12			"PRICE"			/*    11     */
#define LineCap13			"PRICE 2"			/*    12    */
#define LineCap14			"PRICE 3"			/*    13    */
#define LineCap15			"PRICE 4"			/*    14    */
#define LineCap16			"COST"		/*    15     */
#define LineCap17			"FIXED"			/*    16 fixed     */
#define LineCap18			"MAX"			/*     17 max      */
#define LineCap19			"FIXED"			/*    18     */
#define LineCap20			"MAX"			/*    19     */
#define LineCap21			"TAX RATE"		/*    20     */
#define LineCap22			"BUYING RATE"		/*    21     */
#define LineCap23			"SELLING RATE"		/*    22     */
#define LineCap24			"START"			/*    23     */
#define LineCap25			"DRAWER"		/*    24     */
#define LineCap26			"OUT DRAWER"			/*    25     */
#define LineCap27			"PRINTER TYPE"		/*    26     */
#define LineCap28			"PERIOD"			/*    27     */
#define LineCap29			"REPORT TYPE"		/*    28     */
#define LineCap30			"PREFIX"			/*    29     */
#define LineCap31			"LINK"			/*    30     */
#define LineCap32			"KEY CODE"	/*    31     */
#define LineCap33			"MANAGER KEY"			/*    32     */
#define LineCap34			"TYPE"			/*    33     */
#define LineCap35			"DATE FROM"		/*    34      */
#define LineCap36			"DATE TO"		/*    35       */
#define LineCap37			"TIME FROM"		/*    36       */
#define LineCap38			"TIME TO"			/*    37     */
#define LineCap39			"WEEK DAY"		/*    38     */
#define LineCap40			"DISCOUNT"		/*    39     */
#define LineCap41			"PACK QTY."		/*    40     */
#define LineCap42			"UNIT PRICE"		//  41
#define LineCap43			"PACK PRICE"		//  42
#define LineCap44			"PROTOCOL"		//  43
#define LineCap45			"TELEPHONE"		//  44
#define LineCap46			"PASSWORD"		//  45
#define LineCap47			"FREQUENCY:"		//  46
#define LineCap48			"MINIMUM"		//  47
#define LineCap49			"PORT"			//  48
#define LineCap50			"VALUE"			//  49
#define LineCap51			"GRAPHIC"		//  50
#define LineCap52			"SLIP TYPE"		//  51
#define LineCap53			"BLANK LINE"		//  52
#define LineCap54			"LINE OF PAGE"		//  53
#define LineCap55			"PRINT INFO"		//  54
#define LineCap56			"SECOND"			//  55
#define LineCap57			"LEFT MARGIN"		//  56
#define LineCap58			"POINT"			//  57
#define LineCap59			"PRI LEVEL"			//  58
#define LineCap60			"CONFIRM ?"		//  59
#define LineCap61			"FOREGIFT"		//  60
#define LineCap62			"POS CODE"		//  61
#define LineCap63			"USE <CASH>"		//  62
#define LineCap64			"DEADLINE"		//  63
#define LineCap65           "PERSONAL CODE" //Line_PERSONALCODE
#endif
//MAX LENGTH : 12(tCAPWIDTH),For SETUP
#define MsgSETDEPT         		"DEPARTMENT"		//SETDEPT    /*    0     */
#define MsgSETPLU          		"PLU"			    //SETPLU     /*    1     */
#define MsgSETPLUSTOCK     		"STOCK"			//SETPLUSTOCK     /*    1     */
#define MsgSETTAX          		"TAX"			    //SETTAX     /*    2     */
#define MsgSETHEAD         		"HEADER"		    //SETHEAD    /*    3     */
#define MsgSETDISC         		"DISCOUNT"		    //SETDISC    /*    4     */
#define MsgSETSALER        		"SALESPERSON"		//SETSALER   /*    5     */
#define MsgSETSYSFLAG      		"SYSTEM SETUP"		//SETSYSFLAG /*    6 system flags     */
#define MsgSETCURR         		"CURRENCY"		    //SETCURR    /*    7     */
#define MsgSETPORT1        		"PORT 1"			//SETPORT1   /*    8     */
#define MsgSETPORT2       		"PORT 2"		    //SETPORT2   /*    9     */
#define MsgSETPORT3       		"PORT 3"			//SETPORT3   /*    18     */
#define MsgSETDATE        		"DATE"			    //SETDATE    /*    10     */
#define MsgSETTIME        		"TIME"			    //SETTIME    /*    11     */
#define MsgSETPERIPHERALS       "PERIPHERALS"       ////ccr2017-08-04
#define MsgSETGRAP        		"GRAPHIC"		    //SETGRAP    /*    12     */
#define MsgSETGROUP       		"GROUP"			    //SETGROUP   /*    13     */
#define MsgSETTEND        		"TENDER"		    //SETTEND    /*    14     */
#define MsgSETIC          		"CHIP CARD"		    //SETIC      /*    15     */
#define MsgSETPROM        		"PROMOTION"		    //SETPROM    /*    16     */
#define MsgSETPBF         		"PREV. BALANCE"		//SETPBF     /*    17     */
#define MsgSETKP          		"KITCHEN PRINT"	//SETKP      	/*    21     */
#define MsgSETCLERK       		"CLERK"		    //SETCLERK   /*    23     */
#define MsgSETMODIF       		"MODIFIER"		    //SETMODIF   /*    23     */
#define MsgSETPBINF       		"TABLE NAME"		//SETPBINF   /*    24 PB Info     */
#define MsgSETCORR        		"CORRECTION"		//SETCORR    /*    25     */
#define MsgSETZONES       		"TIME ZONE"	        //SETZONES   /*    26     */
#define MsgSETKEYB        		"KEYBOARD"		    //SETKEYB    /*    27 keyboard     */
#define MsgSETREPTYPE     		"REPORT"		    //SETREPTYPE /*    28 user reports     */
#define MsgSETREPORT      		"REPORT CAPTION"	//SETREPORT  	/*    29 report messages     */
#define MsgSETOFF         		"OFFER"			    //SETOFF     /*    30     */
#define MsgSETPORA        		"PO&RA"			    //SETPORA    /*    31     */
#define MsgSETDRAWER      		"DRAWER"		    //SETDRAWER  /*    32     */
#define MsgSETTRAIL       		"TRAILER"			//SETTRAIL   /*    33     */
#define MsgSETSP          		"SLIP PRINTER"		//SETSP      /*    34     */
#define MsgSETSHEAD       		"SLIP HEADER"		//SETSHEAD   /*    35 Slip head(lyq added 20040331)    */
#define MsgSETBLOCKIC     		"BLOCKED CARD"		//SETBLOCKIC //  36 ccr chipcard
#define MsgSETNETWORK          	"NET WORK"		    //SETNETWORK      //  37 ccr IP address
#define MsgSETGPRSFUNC    		"GPRS FUNCTIONS"	//SETGPRSFUNC
#define MsgSETETHERNETFUNC      "NET FUNCTIONS"    //SETETHERNETFUNC
#define MsgSETAUXFUNCS          "AUX FUNCTIONS"    //SETAUXFUNCS

#else//

#define Prompt1				"TOTAL"
#define Prompt2				"SUBTOTAL"			//1
#define Prompt3				"SPENDING"
#define Prompt4				"NET AMT"			//3
#define Prompt5				"PRICE"			//4
#define Prompt6				"TRADE"	//5
#define Prompt7				"QUANTITY"			//6
#define Prompt8				"AMT"			//7
#define Prompt9				"COLLECT"			//8 ZWQ
#define Prompt10			"CHANGE"			//9
#define Prompt11			" "       		/* 10 */
#define Prompt12			" "		 		/* 11 */
#define Prompt13			"-"		 		/* 12 */
#define Prompt14			"-"		 		/* 13 */
#define Prompt15			"STANDARD"         /* 14 */
#define Prompt16			"CLERK"	//15
#define Prompt17			"    HOUR"				//16
#define Prompt18			" "				//17
#define Prompt19			" --"				//18
#define Prompt20			"REPORT  "         /* 19 */
#define Prompt21			" RETURN "         /* 20 */
#define Prompt22			" DISC   "			//21
#define Prompt23			" COST   "			//22
#define Prompt24			"TABLE#  "			//23
#define Prompt25			"CHECK# "   /* 24 used for Register ID with EFT */
#define Prompt26			"QUANTITIES"			//25
#define Prompt27			"GROSS SALES"       //26
#define Prompt28			" TAX    "         //27
#define Prompt29			" PAGE   "         //28
#define Prompt30			"No.#: "         //29
#define Prompt31			"SERVICE "   //30
#define Prompt32			"P.B.    "         //31
#define Prompt33			"Z COUNT " //32
#define Prompt34			"CLEAR   "         //33
#define Prompt35			"S-REPORT"         //34
#define Prompt36			" GROSS  "         //35
#define Prompt37			"STOCK   " //36
#define Prompt38			"FORMER: "       //37
#define Prompt39			"CREDIT# "       //38
#define Prompt40			"TABLE:  "       //39
#define Prompt41			"GUESTS  "         	//40
#define Prompt42			"EXCHANGE"         	//41
#define Prompt43			"INSERT  "         		//ccr  42 Add random number
#define Prompt44			"DELETE  "         		//ccr  43 delete random number
#define Prompt45			"DISC 1  "         //44
#define Prompt46			"DISC 2  "         //45
#define Prompt47			"SALE    "         //46
#define Prompt48			"PREFER  "		//47
#define Prompt49			"STOCK   "		//48
#define Prompt50			"OFFER   " 	//49
#define Prompt51			"OPTION  "								//50 for options
#define Prompt52			"USE KP  "								//51 for KP option
#define Prompt53			"FI_DIS  "								//52 Options for Discount
#define Prompt54			"FL_DIS  "                             //53
#define Prompt55			"F2_DIS  "                             //54
#define Prompt56			"OPEN()  "							//55 Options for PBFunction
#define Prompt57			"OP_ADD  "                             //56
#define Prompt58			"CLOS_T  "                             //57
#define Prompt59			"CONF_   "                             //58
#define Prompt60			"PROPEN  "                             //59
#define Prompt61			"PRBILL  "                             //50
#define Prompt62			"CANCEL  "                             //61
#define Prompt63			"S_BILL  "                            //62
#define Prompt64			"X_BILL  "                             //63
#define Prompt65			"X_CLERK "                             //64
#define Prompt66			"CUSTNO  "                             //65
#define Prompt67			"JOLLY?  "								//66
#define Prompt68			"POINT?  "								//67
#define Prompt69			"DECREASE"								//68
#define Prompt70			"ENABLE ?"								//69
#define Prompt71			"TYPE0 ? "								//70
#define Prompt72			"TYPE1 ? "								//71
#define Prompt73			"TYPE2 ? "								//72
#define Prompt74			"PRN.IC? "								//73
#define Prompt75			"AUTODIS?"								//74
#define Prompt76			"AUTOPOI?"								//75
#define Prompt77			"T_CC?   "								//76
#define Prompt78			"ADD/SUB?"								//77
#define Prompt79			"IC_DEAD?"								//78
#define Prompt80			"DUAL PRI"
#define DayCap1				"MONDAY  "
#define DayCap2				"TUESDAY "
#define DayCap3				"WEDNSDAY"
#define DayCap4				"THURSDAY"
#define DayCap5				"FRIDAY  "
#define DayCap6				"SATURDAY"
#define DayCap7				"SUNDAY  "
#if (PRTLEN<24)
#define TitleN1	"ITEM     QTY    AMT "
/*	             12345678901234567890123*/
#elif (PRTLEN<36)
#define TitleN1	"ITEM      QTY      PRI   AMT "
/*	             12345678901234567890123456789012*/
#else
#define TitleN1	"ITEM                 QUANTITY     PRICE      AMOUNT"
/*	             123456789012345678901234567890123456*/
#endif
//======MAX LENGTH:16
#define MessageF1	" INVALID ENTRY"		/* 1 */
#define MessageF2	"UNKNOWN KEYCODE!"	/* 2 */
#define MessageF3	"STILL IN TENDER"		/* 3 */
#define MessageF4	"  INVALID DATE"		/* 4 */
#define MessageF5	"  INVALID TIME"			/* 5 */
#define MessageF6	" ENTER AMOUNT"		/* 6 */
#define MessageF7	"UNKNOWN ARTICLE"		/* 7 */
#define MessageF8	"NO ENTRY ALLOWED"         /* 8 */
#define MessageF9	" PB STILL OPEN"		/* 9 */
#define MessageF10	"NO SPLIT TENDER"		/* 10 */
#define MessageF11	"PB ALREADY OPEN"		/* 11 */
#define MessageF12	" UNKNOWN  PB"		/* 12 */
#define MessageF13	" PB REQUIRED"		/* 13 */
#define MessageF14	"  PB NOT OPEN"		/* 14 */
#define MessageF15	"NO TRACK BUFFER"		/* 15 */
#define MessageF16	"TRACKBUFFER FULL"		/* 16 */
#define MessageF17	"** IN TRADING **"
#define MessageF18	"UNKNOWN OPER."         /* 18 */
#define MessageF19	"UNKNOWN REPORT"         /* 19 */
#define MessageF20	"* BUF.OVERFLOW *"
#define MessageF21	"ARTICLE NOT USED"		/* 21 */
#define MessageF22	" ENTRY TO HIGH"		/* 22 */
#define MessageF23	"CHECK KP PRINTER"		/* 23 */
#define MessageF24	"NO PAPER IN SLIP"		/* 24 */
#define MessageF25	" NEW SLIP PAPER"		/* 25 */
#define MessageF26	"INVOICE NUMBER :"		/*"NOT CHECKED OUT"  26 */
#define MessageF27	"**    **"
#define MessageF28	"SUSPEND/RECALL"         /*"ONLY CHECK OUT"28 */
#define MessageF29	"OVER MAX COVERS"         /* 29 */
#define MessageF30	" ONLY WITH ITEM"         /* 30 */
#define MessageF31	"KP ERROR!"
#define MessageF32	"MAX 4 MODIFIERS"         /* 32 */
#define MessageF33	"CHECK SLIP PRINT"         /* 33 */
#define MessageF34	"  WRONG OPER."        /* 34 */
#define MessageF35	"MANAGER KEY REQ"        /* 35 */
#define MessageF36	"**  **"         /* 36 *///Ccr 	"** �û��ж� ! **"         /* 36 */
#define MessageF37	"**COPY RECEIPT**"         /* 37 *///Ccr 	"*** �����վ� ***"         /* 37 */]
#define MessageF38	"* SPLIT - BILL *"         /* 38 */
#define MessageF39	"NEAREND R OR J !"         /* 39 */
#define MessageF40	"ENTER NUMBER !!"         /* 40 */
#define MessageF41	"NOT WITH SPLITBI"         /* 41 */
#define MessageF42	"TRANSFERRED TO :"         /* 42 */
#define MessageF43	"*TRAINNING MODE*"         /* 43 *///Ccr 	"*** ��ѵ״̬ ***"         /* 43 */
#define MessageF44	"**INITIALIZING**"         /* 44 *///Ccr 	"** �����ʼ�� **"         /* 44 */
#define MessageF45	"*** POWER ON ***"         /* 45 *///Ccr 	"***** �ӵ� *****"         /* 45 */
#define MessageF46	"NOT AUTHORIZED !"         /* 46 */
#define MessageF47	"*I/D INVENTORY*"         /* 47 *///Ccr 	"*** ������� ***"         /* 47 */
#define MessageF48	"**OTHER PRICE**"         /* 48 *///Ccr 	"*** ��Ʒ��� ***"         /* 48 */
#define MessageF49	"KP #1"         /* 49 */
#define MessageF50	"KP #2"         /* 50 */
#define MessageF51	"KP #3"         /* 51 */
#define MessageF52	"KP #4"         /* 52 */
#define MessageF53	"KP #5"         /* 53 */
#define MessageF54	"KP #6"         /* 54 */
#define MessageF55	"KP #7"         /* 55 */
#define MessageF56	"KP #8"         /* 56 */
#define MessageF57	"**** CANCEL ****"         /* 57 *///Ccr 	"***** ȡ�� *****"         /* 57 */
#define MessageF58	"PROFORMA INVOICE"         /* 58 */
#define MessageF59	"KP TOTAL"         /* 59 */
#define MessageF60	"CLERK NULL"         /* 60 */

#define MonthCap1	"JANUARY "
#define MonthCap2	"FEBRUARY"
#define MonthCap3	"MARCH   "
#define MonthCap4	"APRIL   "
#define MonthCap5	"MAY     "
#define MonthCap6	"JUNE    "
#define MonthCap7	"JULY    "
#define MonthCap8	"AUGUST  "
#define MonthCap9	"SEPTMBER"
#define MonthCap10	"OCTOBER "
#define MonthCap11	"NOVEMBER"
#define MonthCap12	"DECEMBER"
//======MAX LENGTH:4
#define LineCap1		"YES"     /* 0 */
#define LineCap2		" NO"     /* 1 */
#define LineCap3		"CAP-"     /* 2 */
#define LineCap4		"DEPT"     /* 3 */
#define LineCap5		"GROU"     /* 4 */
#define LineCap6		"SFG"     /* 5 */
#define LineCap7		"PRT"     /* 6 */
#define LineCap8		"OPT"     /* 7 */
#define LineCap9		"E_KP"     /* 8 KP EP = extra printer */
#define LineCap10		"TAX-"     /* 9 */
#define LineCap11		"LOC"     /* 10 */
#define LineCap12		"Pr1"     /* 11 */
#define LineCap13		"Pr2"     /* 12*/
#define LineCap14		"Pr3"     /* 13*/
#define LineCap15		"Pr4"     /* 14*/
#define LineCap16		"CPR"     /* 15 */
#define LineCap17		"FIX"     /* 16 fixed */
#define LineCap18		"MAX"     /*  17 max  */
#define LineCap19		"FIX_"     /* 18 */
#define LineCap20		"MAX_"     /* 19 */
#define LineCap21		"RAT"     /* 20 */
#define LineCap22		"BUY"     /* 21 */
#define LineCap23		"SEL"     /* 22 */
#define LineCap24		"STAT"     /* 23 */
#define LineCap25		"DR1"     /* 24 */
#define LineCap26		"OTD"     /* 25 */
#define LineCap27		"KP_"     /* 26 */
#define LineCap28		"PER"     /* 27 */
#define LineCap29		"POI"     /* 28 */
#define LineCap30		"PRE"     /* 29 */
#define LineCap31		"LINK"     /* 30 */
#define LineCap32		"CODE"     /* 31 */
#define LineCap33		"NGR"		/* 32 */
#define LineCap34		"Type"		/* 33 */
#define LineCap35		"DtFr"		/* 34  */
#define LineCap36		"DtTo"		/* 35   */
#define LineCap37		"TmFr"		/* 36   */
#define LineCap38		"TmTo"		/* 37 */
#define LineCap39		"WDay"		/* 38 */
#define LineCap40		"DISC"		/* 39 */
#define LineCap41		"PKGN"		/* 40 */
#define LineCap42		"PriU"		// 41
#define LineCap43		"PriP"		// 42
#define LineCap44		"Prot"		// 43
#define LineCap45		"Tele"		// 44
#define LineCap46		"Pass"		// 45
#define LineCap47		"Freq"		// 46
#define LineCap48		"Min_"		// 47
#define LineCap49		"Port"		// 48
#define LineCap50		"Val_"		// 49
#define LineCap51		"Gra_"		// 50
#define LineCap52		"SpTy"		// 51
#define LineCap53		"TBLs"    // 52
#define LineCap54		"PgLs"		// 53
#define LineCap55		"Pinf"		// 54
#define LineCap56		"Seco"		// 55
#define LineCap57		"Lmge"     // 56
#define LineCap58		"Poi_"			// 57
#define LineCap59		"PriL"			// 58
#define LineCap60		"Conf"			// 59
#define LineCap61		"Fore"			// 60
#define LineCap62		"Pos_"			// 61
#define LineCap63		"T_CC"			// 62
#define LineCap64		"Time"			//63
#define LineCap65       "ID" //Line_PERSONALCODE
//======MAX LENGTH:9
#define MsgSETDEPT         	"DEPT"     /* 0 */
#define MsgSETPLU          	"PLU"     /* 1 */
#define MsgSETPLUSTOCK     	"STOCK"	//SETPLUSTOCK     /*    1     */
#define MsgSETTAX          	"TAX"     /* 2 */
#define MsgSETHEAD         	"HEADER"     /* 3 */
#define MsgSETDISC         	"DISCOUNT"     /* 4 */
#define MsgSETSALER        	"SALESMAN"     /* 5 */
#define MsgSETSYSFLAG      	"SYS SETUP"     /* 6 system flags */
#define MsgSETCURR         	"CURRENCY"     /* 7 */
#define MsgSETPORT1        	"PORT1"     /* 8 */
#define MsgSETPORT2       	"PORT2"     /* 9 */
#define MsgSETPORT3       	"PORT3"     /* 9 */
#define MsgSETDATE        	"DATE"     /* 10 */
#define MsgSETTIME        	"TIME"     /* 11 */
#define MsgSETPERIPHERALS   "PERIPHER_"       //ccr2017-08-04
#define MsgSETGRAP        	"GRAPHIC"     /* 12 */
#define MsgSETGROUP       	"GROUP"     /* 13 */
#define MsgSETTEND        	"SUB TEND_"     /* 14 */
#define MsgSETIC          	"CHIP CARD"     /* 15 */
#define MsgSETPROM        	"PROMOTION"     /* 16 */
#define MsgSETPBF         	"PB FUNC"     /* 17 */
#define MsgSETKP          	"K_PRINTER"     /* 21 */
#define MsgSETCLERK       	"CLERKS"     /* 23 */
#define MsgSETMODIF       	"MODIFIER"     /* 23 */
#define MsgSETPBINF       	"TABLE DES"     /* 24 PB Info */
#define MsgSETCORR        	"CORREC"     /* 25 */
#define MsgSETZONES       	"TIME ZONE"     /* 26 */
#define MsgSETKEYB        	"KEYBOARD"     /* 27 keyboard */
#define MsgSETREPTYPE     	"REPORT"     /* 28 user reports */
#define MsgSETREPORT      	"REPORTDES"     /* 29 report messages */
#define MsgSETOFF         	"OFFER"     /* 30 */
#define MsgSETPORA        	"PO-RA"     /* 31 */
#define MsgSETDRAWER      	"DRAW"     /* 32 */
#define MsgSETTRAIL       	"TRAI"     /* 33 */
#define MsgSETSP          	"SLIP"     /* 34 */
#define MsgSETSHEAD       	"SLIPHEAD"     /* 35 Slip head(lyq added 20040331)*/
#define MsgSETBLOCKIC     	"BLOCKIC"	  // 36 ccr chipcard
#define MsgSETNETWORK          	"NET WORK"	  // 37 ccr IP address
#define MsgSETGPRSFUNC    	"GPRS FUNC"	//SETGPRSFUNC
#define MsgSETETHERNETFUNC  "NET FUNCS"    //SETETHERNETFUNC
#define MsgSETAUXFUNCS      "AUX FUNCS"    //SETAUXFUNCS
#endif


#if(DD_ZIP==1)
#define MessageE1	"ERROR0 FROM HOST"
#define MessageE3   "ERROR1 FROM HOST"
#else
#define MessageE1	"ERR0 FR HOST"
#define MessageE3   "Err1 Fr Host"
#endif

#define MessageE2	"ERR: TOO LONG FROM HOST"


#define MessageE4       "END  HOST"

#define MessageE5       "!!!! MEMORY OVERFLOW !!!!"
#define MessageE6       "PLU LIST"
#define MessageE7       "PLU "
#define MessageE8       "STOCK"
#define MessageE9       "CODE"
#define MessageE10      "PRICE"

#define MessageDEPT    "DEPARTMENT LIST"
#define MessageCLERK    "CLERKS LIST"

#define MessageE12      "PIC:"
#define MessageE13      "1.NORMAL PRINTING" 		//Normale
#define MessageE14      "2.DOUBL HIGH" 				//Doppia altezza
#define MessageE15      "3.~D~O~U~B~L ~W~I~D~T~H" 	//Raddoppio caratteri
#define MessageE16      "4.~D~O~U~B~L ~W~I~D~T~H" 	//Raddoppio caratteri
#define MessageE17      "5.~D~O~U~B~L ~H~I~G~H"		//Dopia altezza + Raddoppio caratteri
#define MessageE18       "!!!! FAT(PLU) ERROR !!!!"


#define MessageE20      "GRAPHIC 1"
#define MessageE21      "GRAPHIC 2"
#define MessageE22      "GRAPHIC 3"
#define MessageE23      "GRAPHIC 4"
#define MessageE25      "RAM SIZE:"
#define MessageE26      "ERROR AT:"
#define MessageE27      "PG RAM SIZE:"
#define MessageE28      "FORMAT ERROR ON DATETIME."

#define MessageE24      "-SUM:"

#define MessageE29      "PORT 1 TEST ERROR!"
#define MessageE30      "PORT 1 TEST OK!"
#define MessageE31      "PORT 2 TEST ERROR!"
#define MessageE32      "PORT 2 TEST OK!"

#define MessageE33_Err  "PORT 3 TEST ERROR!"
#define MessageE33_OK   "PORT 3 TEST OK!"

#define MessageE33      "CURRENT TIME:"
#define MessageE34      "****  PRINT INTERRUPTED ****"
#define MessageE35		"MODEM CONN_"
#define MessageE36		"FROM HOST"
#define MessageE37		"MODEM CLOS_"
#define MessageE38		"@UPDATE IS GOING....."
#define MessageE39		"UPDATE BIOS"
#define MessageE40		"UPDATE CLIB"
#define MessageE41		"UPDATE GRAP"
#define MessageE42		"Send to host"
#define MessageE43		"Send End."
#define MessageE44		"READ ERROR"
#define MessageE45		"SEND ERROR"
#define MessageE46		"Write Err"
#define MessageE47		"PRINT DOT EPSON"
#define MessageE48		"RESERVED"
#define MessageE49		"PRINTER ON"
#define MessageE50		"PRINTER OFF"
#define MessageE51		"FM:"
#define MessageE52		"EJ:"
#define MessageE53		"SIZE OF SD"
#define MessageE54		"EJ ERROR AT:  "
#define MessageE55		"Clear Fiscal Memory"
#define MessageE56		"FM ERROR AT:"
#define MessageE57		"SIZE OF FM:  "
#define MessageE58		"CLEAR REPORT"
#define MessageE59		"ECR LOCKED"
#define MessageE60		"**Copy for paper out**"
#define MessageE61		"Fiscal Memory Cleard!"
#define MessageE62		"Fiscal Memory Error!"
#define MessageE63		"EJ IS FULL"			//ZWQ
#define MessageE64		"PLU TEST"
#define MessageE65		"PLUs TOO LARGE"

#define MainMenu1		"1.Report Z By Day" // -> daily  report
#define MainMenu2		"2.Report FM By Day" //  -> fiscal memory report by day
#define MainMenu3		"3.Report FM By Month" //   -> fiscal memory report by months
#define MainMenu4		"4.Report FM By #Z"	// -> fiscal memory report by Z number	""
#define MainMenu5		"5.Printer Status"	// -> Printe status,
#define MainMenu6		"Menu   Enter"


#if DD_FISPRINTER
#define CaptionCWXXI0		"Printer Status:"
#else
#define CaptionCWXXI0		"ECR Status:"
#endif

#if (PRTLEN>30)
#define FISCALMESSAGE "@   INFORMATION ON FM & EJ"
#else
#define FISCALMESSAGE "@INFORMATION ON FM & EJ"
#endif

#define STOPMESS    "<Clear> To Stop."
#define CLEANFILES  "Clear Files?"



//ccr2016-12-20>>>>>>>>>>>>>>>>>>>
#if (DISP2LINES)
#define msg_AESKey    "AES KEY"     //MsgAESKey[]

#define msg_SendSFiles      "Send All S.TXT"    // MsgSendSFiles[]
#define msg_SendCurrentFile "Send S.File?"    // MsgSendCurrentSFile[]

#define msg_CLIENTIP    "CLIENT IP"
#define msg_SERVERIP    "SERVER IP"
#define msg_GATEWAY     "GATE WAY"
#define msg_IPMASK      "IP MASK"

#define GPRSAPNNAME        "APN"           //GPRSAPNNAME
#define GPRSUSERNAME        "USER NAME"           //GPRSUSERNAME

    //>>>>>For NET Functions
#define Msg_MINISTRYSEND    "MINISTRY SEND"
#define Msg_SERVERURL       "SERVER(URL)"
#define Msg_PERSONALCODE    "PERSONAL CODE"
#define Msg_GPRSSEND        "GPRS SEND"
    //>>>>>For Net Work
#define Msg_DHCP            "DHCP"
#define Msg_PRIMARYDNS      "PRIMARY DNS"
#define Msg_SECONDARYDNS    "SECONDARY DNS"
#define Msg_PRINTSETTINGS   "PRINT SETTINGS"

#else

#define msg_SendSFiles  "Send S.Files"    // MsgSendSFiles[]

#define msg_CLIENTIP    "IP-C"
#define msg_SERVERIP    "IP-S"
#define msg_GATEWAY     "GATE"
#define msg_IPMASK      "MASK"

#define GPRSAPNNAME     "APN"           //GPRSAPNNAME
#define GPRSUSERNAME    "USER"           //GPRSUSERNAME

    //>>>>>For NET Functions
#define Msg_MINISTRYSEND    "MINISTRY SEND"
#define Msg_SERVERURL       "URL"
#define Msg_PERSONALCODE    "ID"
#define Msg_GPRSSEND        "GPRS SEND"
    //>>>>>For Net Work
#define Msg_DHCP            "DHCP"
#define Msg_PRIMARYDNS      "PRI-DNS"
#define Msg_SECONDARYDNS    "SEC-DNS"
#define Msg_PRINTSETTINGS   "PRINT SETTINGS"

#endif

#if (defined(CASE_GPRS) || defined(CASE_ETHERNET))
#define GPRSPASSWORD    Prompt.LineCap[Line_PASSWORD]// "Password"           //GPRSPASSWORD

#define GPRSServerIP			"SERVER IP" //"������IP"
#define GPRSServerPort		    "PORT" //"�˿ں�"

#define GPRSSendMESS        "Send Message" //ccr2014-11-11 NEWSETUP
#define GPRSSetMode         "Set Sent Mode"    //gprsSETMODE //ccr2014-11-11 NEWSETUP-step2
#define GPRSSendECRLog      "Send NEW FM"       //gprsSendECRLog //ccr2014-11-11 NEWSETUP-step2
#define GPRSSendECRLogAll   "Send All FM"    //gprsSendECRLogAll //ccr2014-11-11 NEWSETUP-step2
#define GPRSDownloadPLU     "Update PLU"    //gprsDownloadPLU //ccr2014-11-11 NEWSETUP-step2
#define GPRSDownloadDEPT    "Update DEPT"    //gprsDownloadDEPT //ccr2014-11-11 NEWSETUP-step2
#define GPRSDownloadCLERK   "Update CLERK"    //gprsDownloadCLERK //ccr2014-11-11 NEWSETUP-step2
#define GPRSDownloadHEAD    "Update HEAD"       //gprsDownloadHEAD //ccr2014-11-11 NEWSETUP-step2
#define GPRSDownloadTRAIL   "Update TRAIL"      //gprsDownloadTRAIL //ccr2014-11-11 NEWSETUP-step2
#define GPRSDownloadALL     "Update ALL"      //gprsDownloadALL //ccr2016-08-18
#define GPRSRestart         "RESET GPRS"      //gprsRestart //ccr2016-08-26

#define GPRSstr1 "DATA ERROR!"  // "�������ʹ�"
#define GPRSstr2 "GPRS OK"
#define GPRSstr3 "GPRS NOT OK"
#define GPRSstr4 "CONFIRM?"
#define GPRSstr5 "IP/PORT:NULL"
#define GPRSstr6 "ERROR:IP/PORT"
#define GPRSstr7 "WAITING GPRS"
#define GPRSstr8 "YES"   // "��"
#define GPRSstr9 " NO"    // "fou "
#define GPRSstr10 "TRANSMITTING..."  // "���ݷ�����.. "
#define GPRSstr11 "FINISHED"  // "�����ѷ���.. "
#define GPRSstr28 "SUCCESS........"						// "���ͳɹ�.."
#define GPRSstr31 "FAILURE ON CONNECT"	//						// "����ʧ��"
#define GPRSstr32 "FAILURE ON READ"                                           // "����ʧ��"
#define GPRSstr33 "CONFIRMA ERR"			// "����ȷ��ʧ��"
#define GPRSstr34 "FAILURE........"							// "����ʧ��"
#define GPRSstr58 "CONNECT........."		// "���ڽ�������.."
#define GPRSstr59 "CONNECT........."		// " ׼����������.."
#define GPRSstr60 "RESTART GPRS"	// "���ڸ�λģ��.."
#define GPRSstr61 "END OF SEND." // "�������,���˳�"

#define GPRSxACK  "Wait ACK Error"
#endif

#if defined(CASE_ETHERNET)
#define ETHERNETSendMESS        "TEST SERVER" //CCR2014-11-11 NEWSETUP
#define ETHERNETSetMode         "SET SENT MODE"    //net_SETMODE //ccr2014-11-11 NEWSETUP-step2
#define ETHERNETSendECRLog      "SEND NEW FISCAL"       //net_SendECRLog //ccr2014-11-11 NEWSETUP-step2
#define ETHERNETSendECRLogAll   "SEND ALL FISCAL"    //net_SendECRLogAll //ccr2014-11-11 NEWSETUP-step2
#define ETHERNETDownloadPLU     "UPDATE PLU"    //net_UpdatePLU //ccr2014-11-11 NEWSETUP-step2
#define ETHERNETDownloadDEPT    "UPDATE DEPT"    //net_UpdateDEPT //ccr2014-11-11 NEWSETUP-step2
#define ETHERNETDownloadCLERK   "UPDATE CLERK"    //net_UpdateCLERK //ccr2014-11-11 NEWSETUP-step2
#define ETHERNETDownloadHEAD    "UPDATE HEAD"       //net_UpdateHEAD //ccr2014-11-11 NEWSETUP-step2
#define ETHERNETDownloadTRAIL   "UPDATE TRAIL"      //net_UpdateTRAIL //ccr2014-11-11 NEWSETUP-step2
#define ETHERNETDownloadALL     "UPDATE ALL"      //net_UpdateALL //ccr2016-08-18
#define ETHERNETRestart         "RESET ETHERNET"      //net_Restart //ccr2016-08-26
#endif
//ccr2017-05-10>>>>>>For AUX Functions>>>>>>>>>>>>>>>>>>>>>>>
#define MsgAUX_PRINTPLU		 "PRINT PLU"        //��ӡ��Ʒ��Ϣ
#define MsgAUX_EXPLOREEJ	 "EXPLORE EJ"	    //��ѯEJ����
#define MsgAUX_PRINTFISCAL	 "PRINT FISCAL"	    //��ӡ������˰����Ϣ
#define MsgAUX_PRINTEJ		 "PRINT EJ"	        //��ӡEJ��Ϣ
#define MsgAUX_SETPWDX		 "SET PWD FOR X"	    //����X��������
#define MsgAUX_SETPWDZ		 "SET PWD FOR Z"	    //����Z��������
#define MsgAUX_SETPWDSET	 "PWD FOR SET"	    //����SET��������
#define MsgAUX_SETPWDMG		 "SET PWD FOR MG"	//���þ���MG��������
#define MsgAUX_INITFISCAL	 "INITIAL FISCAL"	//˰�س�ʼ��
#define MsgAUX_INITEJ		 "INITIAL EJ"	    //��ʼ��EJ
#define MsgAUX_PRNGAPHIC	 "PRINT GRAPHIC"	    //��ӡ�տ��ͼ��
#define MsgAUX_ECRCONFIG     "PRINT CONFIG" //��ӡ�տ������
//ccr2017-05-10<<<<<<<<<<<<<<<<<<<<<<<
//ccr2017-12-08>>>>>>>>>>>>>>>>>>>>>>>
#define msg_SETTSTDISP          "DISPLAY"       //msg_SETTSTDISP  //"��ʾ����"
#define msg_SETTSTCUST         "CUSTOMER"       //msg_SETTSTCUST  //"����ʾ����
#define msg_SETTSTPRT          "PRINTER"        //msg_SETTSTPRT   //"��ӡ�汾"
#define msg_SETTSTMEM           "CHECK RAM"     //msg_SETTSTCLK   //"ʱ�Ӳ���"
#define msg_SETTSTCLK          "CLOCK"          //msg_SETTSTMEM   //RAM����
#define msg_SETTSTBELL          "BUZZER"        //msg_SETTSTBELL  //"����������
#define msg_SETTSTDRAW          "DRAWER"        //msg_SETTSTDRAW  //"Ǯ�����"
#define msg_SETTSTKBD          "KEYBOARD"       //msg_SETTSTKBD   //"���̲���"
#define msg_SETTSTCOMM          "SERIAL PORTS"  //msg_SETTSTCOMM  //"���ڲ���"
#if defined(FOR_DEBUG)
#define msg_SETTSTERASEFM       "ERASE FM"      //msg_SETTSTERASEFM    //"���FM"
#define msg_SETTSTFM            "CHECK FM"      //msg_SETTSTFM    //"����FM"
#endif                                   //           //
#define msg_SETTSTAUTO          "SELF-TEST"     //msg_SETTSTAUTO  //"�Զ�����"
//ccr2017-12-08<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#define SHANCHU         "DELETE ?"


#define PRESSANYKEY     "PRESS A KEY"

#define SENDLOGAUTO     "SEND AUTO:"
#define DAYSFORLOG      "DAYS FOR SEND:"
#define ACKMUSTNEED     "ACK NEEDED:"
#define SPACEOVER        "FILE OVERFLOW!"  // "�ļ��ռ�Խ��"
#define FATERROR        "FAT(PLU) ERR"

//.......�������Ӧ������.........................................
#define MsgKEYCORR      "CORRECT"
#define MsgKEYCURR      "CURRENCY"
#define MsgKEYDISC      "DISCOUNT"
#define MsgKEYPBFUN     "PB-FUNC"
#define MsgKEYPORA      "PORA"
#define MsgKEYPO_RA      "PO/RA"
#define MsgKEYTEND      "TENDER"
#define MsgKEYCLEAR     "CLEAR"
#define MsgKEYFEED      "FEED"
#define MsgKEYMULT      "X"
#define MsgKEYSUBTOT    "SUBTOTAL"
#define MsgKEYPRICE     "PRICE"
#define MsgKEYPRICEN    "PRICE#"
#define MsgKEYPRICE1    "PRICE1"
#define MsgKEYPRICE2    "PRICE2"
#define MsgKEYPRICE3    "PRICE3"
#define MsgKEYPRICE4    "PRICE4"
#define MsgKEYSHIFT     "SHIFT"
#define MsgKEYDATE      "DATE"
#define MsgKEYWEIGHT    "WEIGHT"
#define MsgKEYCLERKN    "CLERK#"
#define MsgKEYDEPT      "DEPT~"
#define MsgKEYDEPTNo    "DEPT#"
#define MsgKEYPLUNo     "PLU#"
#define MsgKEYDRAW      "OPEN-DRAW"
#define MsgKEYMEMO      "MODIFIER"
#define MsgKEYCLERK     "CLERK*"
#define MsgKEYPLUDIR    "PLU~"
#define MsgKEYLOCK      "MODE KEY"
#define MsgKEYDRAWFUN   "DRAW FUNC*"
#define MsgKEYSALPN     "SALPER#"
#define MsgKEYSALP      "SALPER"
#define MsgKEYDOT       "'.'"
#define MsgKEYZERO2     "'00'"
#define MsgKEYNUMBER    "0~9"
#define MsgKEYSUSPEND   "HOLD"
#define MsgFUNCLOOK1    "FUNC LOOK1"
#define MsgFUNCLOOK2    "FUNC LOOK2"
#define MsgMODELOCK     "MODE KEY"
#define MsgVIPLOGIN     "ACCOUNT LOGIN"
#define MsgINPUTNUM     "INPUT CODE"
#define MsgCUSTOMER    "CUSTOMER"
#define MsgKEYNULL      "(OTHERS)"

#define MsgRHEADER      "Header*"
#define MsgRTRAILER     "Trail*"
#define MsgKEYBOARD     "Keyboard*"
#define MsgSYSFLAGS     "System*"
#define MsgDATETIME     "Datetime"
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//ccr2016-12-20<<<<<<<<<<<<<<<<<<<


#define BADEJBYZ		 "**Error When Write To EJ**"	//ccr091228
#define PRINTZBADEJ	"Replace EJ."					//ccr091228
#define ZONLY			"Z ONLY"

#define DEVICECODE  "DEVICE:"    //PANAMA
#define FISCALNAME  "NAME:"    //PANAMA
#define FISCALADDR  "ADDR:"    //PANAMA
#define RIFCUSTOMER "CUSTOMER RIF:"

#define SELECTMESS  "    <SELECT>MENU"
#define ENTERMESS   "         <ENTER>"
#define EXITMESS    "          <EXIT>"
#define INPUTRECNo  " REC# or <ENTER>"

#define BUTTONBATLOW "S.Battery Low!"
#define CHARGEBATNOW "O.Battery Low!"

#define REPRN_PWON  "Re-Print When Power ON........."
#define REPRN_PAPERON  "Re-Print When Paper OK......"

#define CUMULATIVE  "CUMULATIVE TOTAL OF TAX"

#define SRAMNOTFOUND "no SRAM!HALT!"


#define MESG_FCName   "NAME:"	//1-�˿�����
#define MESG_FCAddr   "ADDR:"	//2-�˿͵�ַ
#define MESG_FCRUC	  "RUC:"	//3-�˿�RUC,
#define MESG_FVatNo   "FIS:"   //4-��������վݵĹ˿�˰����
#define MESG_FCDebit  "RCP#:"	//5-�����վݺ�
//01234567890123456789012345678901
#define MESG_CUSTOMER   "------Messages of Customer------"
//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#define MESG_Z_BALANCE   "FREE CLOSURES IN FM"  //ccr2014-08-04 new
#define MESG_Z_START     " FIRST CLOSURE IN FM"      //ccr2014-08-04 new
#define MESG_Z_LAST      " LAST CLOUSURE IN FM"             //ccr2014-08-04 new

#define MESG_EJ_START    " STARTING DATE"      //ccr2014-08-04 new
#define MESG_EJ_LAST     " LAST DATE"             //ccr2014-08-04 new

#define MESG_ERASE_EJ    "Erase EJ........"       //ccr2014-08-04 new

#define MESG_EJ_ID      "EJ ID."
#define MESG_EJ_REC     "EJ REC."

#define MESG_Z_REMAIN   "Z-CLOUSURE CAN"

//ccr2017-05-04>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#define MESG_TRAINRECNo     "RECEIPT TRAIN No."
#define MESG_RECEIPTNo      "RECEIPT No."

#define MESG_TRAINRECNoT     "TRAIN TOTAL No."

#if (0)//defined(CASE_GREECE)
#define MESG_RECEIPTSUMNo    "DAILY ASEDS"
#else
#define MESG_RECEIPTSUMNo    "TOTAL INCOME RECEIPTS"
#endif

#define MESG_NONEFISRECEIPT  "NONE FISCAL TOTAL No."
//ccr2017-05-17>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#define RECEIPTSTART "* RECEIPT - START *"
#define RECEIPTEND   "*  RECEIPT - END  *"

#define TEMPRECEIPTSTART "*PROVISIONAL DCOUMENT START*" //Provisional receipts
#define TEMPRECEIPTEND   "* PROVISIONAL DCOUMENT END *"  //Provisional receipts
#define COLLECTION  "COLLECTION"

#define COPYRECEIPTEND "*****COPY RECEIPT-END*****"
#define COPYRECEIPTSTART "*****COPY RECEIPT-START*****"

#define NOTARECEIPT     "THIS IS NOT A RECEIPT"

#define ZAFTERPOWERFAIL1 "POWER FAILURE"
#define ZAFTERPOWERFAIL2 "UNSUCCESSFUL ISSUING OF Z"
#define COPYOFLASTZ     "COPY OF THE LAST Z DAILY REPORT"

#define Msg_READFMALL	 "READ FM ALL"	    //��ȡFM��ȫ����¼����
#define Msg_READZNUM	 "READ Z BY NUM"	//��ȡFM��ָ��Z�ŷ�Χ�ĸ���Z��������
#define Msg_READFMDATE	 "READ FM BY DATE"	//��ȡFM��ָ�����ڷ�Χ��ȫ������
#define Msg_READZTOTAL	 "READ Z TOTAL"	    //����FM��ָ�����ڷ�Χ�ڵ�Z��������

#define SAVECHANGES     "SAVE CHANGES?"     //ccr2017-09-13 MsgSaveChanges[]
#define PLUBARCODE      "BARCODE"          //ccr2017-09-14 MsgBARCODE[]


#define NOFMDATA        "* NO FISCAL DATA  *"

#define DELZBEFOR60     "DEL Z BEFOR 60 ?"  //ccr2017-06-19
#define DELZBEFOR60ING  "DEL Z BEFOR 60D>"  //ccr2017-06-19

#define Z60DELETED   "Z DATA DELETED"
#define CONTINUEDEL  "CONTINUE DEL Z ?"

#define EXPLOREZBEGIN   "* EXPLORE Z REPORT-START *"
#define EXPLOREZEND   "* EXPLORE Z REPORT-END *"

#define EXPLORERBEGIN   "* EXPLORE RECEIPT-START *"
#define EXPLOREREND   "* EXPLORE RECEIPT-END *"
#define LOGOOnHEAD    "LOGO ON HEAD"    //  MsgLOGOOnHEAD[]
#define LOGOOnTRAIL   "LOGO ON TRAIL"   // MsgLOGOOnTRAIL[]

#define MSG_ZEROZREPORT  "ZERO Z REPORT?"

#define MSG_SETTINS4NETWORK     "**** SETTINGS FOR NET WORK ****"
#define MSG_SETTINS4NETFUNC     "** SETTINGS FOR NET FUNCTIONS **"


#define MSG_SECONDLAYER  "SECOND LAYER"
#define MSG_FIRSTLAYER   "FIRST LAYER"

#define MSG_COMMENTS    "COMMENT"


#define TOWINTERTIME "AUTO ADJUSTMENT TO WINTER TIME"
#define TOSUMMERTIME "AUTO ADJUSTMENT TO SUMMER TIME" //���Ҵ�ӡ��ǰʱ�䣨WT hh:mm ���� ST�� hh:mm)
#define VATCHANGESCAN "REMAINING FOR VAT CHANGES"
#define VATCHANGES    "CHANGES OF VATS"

///////////////////////////////////////////////////////////
#define POWEROFFONZ1  "POWER FAILURE"
#define POWEROFFONZ2  "UNSUCCESSFUL ISSUING OF Z"

#define UPDATEBIOS          "Update BIOS----"
#define DONTPOWEROFF        "Don't Power off"
#define ERRORONSEND         "Error on send!"
#define STARTETHERNET       "Start Ethernet>>"
#define COMMANDSFORSETUP    "COMMANDS FOR SETUP"
#define ASCIIONKEYBOARD     "ASCII CHARACTERS ON KEYBOARD"
#define SPECIALONKEYBOARD   "SPECIAL CHARACTERS ON KEYBOARD"
#define SIMCARDOK           "SIM CARD OK."

#define MSG_INITPORT        "Init Port"
#define MSG_INITJOURNAL     "Init Journal"
#define MSG_INITTENDER	   	"Init Tender"
#define MSG_INITPORA	 	"Init PoRa"
#define MSG_INITDRAWER	   	"Init Drawer"
#define MSG_INITPLU	 	    "Init Plu"
#define MSG_INITDEPT	 	"Init Dept"
#define MSG_INITGROUP	 	"Init Group"
#define MSG_INITCORREC	   	"Init Correc"
#define MSG_INITCURR	 	"Init Curr"
#define MSG_INITDISCOUNT	"Init Discount"
#define MSG_INITTAX	 	    "Init Tax"
#define MSG_INITPBF	 	    "Init PbF"
#define MSG_INITOPERATOR  	"Init Operator"
#define MSG_INITSALPER	   	"Init SalPer"
#define MSG_INITMODIFIER  	"Init Modifier"
#define MSG_INITOFFPRICE  	"Init OFFPrice"
#define MSG_INITAGREE	 	"Init Agree"
#define MSG_INITGRAPHIC  	"Init Graphic"
#define MSG_NEXT            "NEXT"
#define MSG_REPORTCLEARED   "REPORT CLEARED"
#define MSG_REPORTCLEAREDP   "** ALL OF REPORTS CLEARED **"

#define MSG_COPYZSTART      "*COPY LAST Z DAILY REPORT-START*"
#define MSG_COPYZEND        "**COPY LAST Z DAILY REPORT-END**"

#define MSG_HEADEROLD       "HEADER OF OLD VERSION"
#define MSG_HEADERNEW       "HEADER OF NEW VERSION"

#define PWD4TECHNICIAN      "246810"
#define MSG_REMOVEMAC	"REMOVE MAC-JUMP"

#define MSG_SAVETOSDCARD   "SAVE TO SD?" //ccr2018-04-02

#endif

