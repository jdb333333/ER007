#define DRAWER_C 1
#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"

#include "flowbill.h"  //lyq2003


/***************************************************************/

void GetDrawerOffSet()
{
	RamOffSet = ApplVar.DrawNumber * ApplVar.AP.Draw.RecordSize + ApplVar.AP.StartAddress[AddrDrawer];
}

void AddDrawerTotal()
{
    if (ApplVar.DrawNumber < ApplVar.AP.Draw.Number)
    {
		GetDrawerOffSet();
	    RamOffSet += ApplVar.AP.Draw.TotalOffSet;
		for (ApplVar.PointerType = 0; ApplVar.PointerType < REPDEFMAX; ApplVar.PointerType++)
		{
		    ApplVar.Size = ApplVar.AP.Draw.Size[ApplVar.PointerType];
		    AddPointerTotal();
		}
    }
}

void WriteDrawer()
{
    if (ApplVar.DrawNumber < ApplVar.AP.Draw.Number)
    {
		GetDrawerOffSet();
		WriteRam((BYTE *)&ApplVar.Draw, ApplVar.AP.Draw.TotalOffSet);
    }
}

void ReadDrawer()
{
    GetDrawerOffSet();
    ReadRam((BYTE *)&ApplVar.Draw, ApplVar.AP.Draw.TotalOffSet);
}

void OpenDrawer()
{
	DrawerOpen();
    ApplVar.OpDraw = 0;
}

/* DRAW OPTIONS */
/*
	If BIT 1 is set then Drawer Open ApplVar.Total
	BIT0	BIT2	-> Decimal point position
	0		0		1,00
	1		0		1
	0		1		1,000
	1		1		1,0
*/
void Drawer()
{

    ApplVar.DrawNumber = 0;
    if (ApplVar.Key.Code == DRAW)
    {
		if (!Appl_EntryCounter || Appl_NumberEntry > 99)
		{
		    ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
		    return;
		}
		ApplVar.DrawNumber = Appl_NumberEntry;
    }
    else
		ApplVar.DrawNumber = ApplVar.Key.Code - DRAW;
    if (!ApplVar.DrawNumber || ApplVar.DrawNumber > ApplVar.AP.Draw.Number ||
	!(ApplVar.AP.Draw.Size[0].Periods & 0x01) || !ApplVar.AP.Draw.Size[0].Amt)
    {
		ApplVar.ErrorNumber=ERROR_ID(CWXXI42);
		return;
    }
#if(CASE_RAMBILL)
	Collect_Data(NOADDLOG);
#endif
    ApplVar.DrawNumber--;
	ReadDrawer();
    if (BIT(ApplVar.Draw.Options, BIT1))	    /* open drawer counter? */
    {
		if (!ApplVar.ClerkNumber)
		{
		    ApplVar.ErrorNumber=ERROR_ID(CWXXI33);	    /* select clerk */
		    return;
		}

		if (ApplVar.AP.SalPer.Number && !ApplVar.SalPerNumber)
		{
			if (!BIT(KEYTONE, BIT6))
			{
				ApplVar.SalPerNumber = 1;
			}
			else
			{
			    ApplVar.ErrorNumber=ERROR_ID(CWXXI34);	    /* select salesperson */
			    return;
			}
		}
		OpenDrawer();
//ccr2014-09-03		ApplVar.Amt = ONE;
//ccr2014-09-03		AddDrawerTotal();
	    if (!ApplVar.FRegi)
		{
			if (BIT(CLERKFIX, BIT0) && !ApplVar.ClerkLock)    /* clerk compulsory, no key */
			{
				ApplVar.ClerkNumber = 0;
				ApplVar.FTrain = 0;
			}
#if (salNumber)
			if (BIT(KEYTONE, BIT6))    /* Salesp compulsory */
				ApplVar.SalPerNumber = 0;
			else if (BIT(AM_PM, BIT4))	  /* Salesp reset to 1*/
			{
				ApplVar.SalPerNumber = 1;
				ReadSalPer();
			}
#endif
		}
    }
    else
    {
		ApplVar.Size = ApplVar.AP.Draw.Size[0];
		GetDrawerOffSet();
		RamOffSet += ApplVar.AP.Draw.TotalOffSet;
		ReadTotal();
		if (BIT(ApplVar.Draw.Options, BIT2))
			ApplVar.AmtDecimal = 2;
		else
			ApplVar.AmtDecimal = 0;
		ApplVar.AmtDecimal += ApplVar.Draw.Options & BIT0;
		PutsO(DispAmtStr(DText[DTEXT_DRAWER], &ApplVar.Total.Amt,DISLEN));
//		PutsO(DispAmtStr(ApplVar.Draw.Name, &ApplVar.Total.Amt));
		ApplVar.AmtDecimal = NO_DECIMAL;		/* restore amount format */
		Appl_EntryCounter = 1;   /* force clear of entry */
    }
    if (Appl_EntryCounter)
	ClearEntry();
}

//ccr 050301>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
void DispDrawerTotal()
{
    if (ApplVar.DrawNumber < ApplVar.AP.Draw.Number)
    {
    	ReadDrawer();
		ApplVar.Draw.Name[ApplVar.AP.Draw.CapSize] = 0;
		GetDrawerOffSet();
	    RamOffSet += ApplVar.AP.Draw.TotalOffSet;
		ApplVar.PointerType = 0;
//		for (; ApplVar.PointerType < REPDEFMAX; ApplVar.PointerType++)
		{
		    ApplVar.Size = ApplVar.AP.Draw.Size[ApplVar.PointerType];
		    DisplayPointerTotal(ApplVar.Draw.Name);
		}
    }
}
//ccr 050301<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

