#define DEPART_C 4
#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
#include "Message.h"

#include "ejournal.h"

#include "flowbill.h"
#include "fiscal.h"
//lyq2003
extern  BCD THOUSAND100 ;
/***************************************************************/
//extern BYTE testonly_BADEJ;

void GetDeptOffSet()
{
    RamOffSet = (UnLong)ApplVar.DeptNumber * ApplVar.AP.Dept.RecordSize + ApplVar.AP.StartAddress[AddrDept];
}

void AddDeptTotal()
{
    if (ApplVar.DeptNumber < ApplVar.AP.Dept.Number)        /* just check dep sel. in plu */
    {
        GetDeptOffSet();
        RamOffSet += ApplVar.AP.Dept.TotalOffSet;
        for (ApplVar.PointerType = 0; ApplVar.PointerType < REPDEFMAX; ApplVar.PointerType++)
        {
            ApplVar.Size = ApplVar.AP.Dept.Size[ApplVar.PointerType];
            AddPointerTotal();
        }
    }
}

void WriteDept()
{
    if (ApplVar.DeptNumber < ApplVar.AP.Dept.Number)
    {
        GetDeptOffSet();
        WriteRam(ApplVar.Dept.Random, ApplVar.AP.Dept.RandomSize);
        WriteRam(ApplVar.Dept.Name, ApplVar.AP.Dept.CapSize);
        WriteRam(&ApplVar.Dept.Group, sizeof(ApplVar.Dept.Group));
        WriteRam(&ApplVar.Dept.Print, sizeof(ApplVar.Dept.Print));
        WriteRam(&ApplVar.Dept.Options, sizeof(ApplVar.Dept.Options));
//		if (ApplVar.AP.Tax.Number)
        WriteRam(&ApplVar.Dept.Tax, sizeof(ApplVar.Dept.Tax));
        WriteRam(&ApplVar.Dept.Kp, sizeof(ApplVar.Dept.Kp));
        WriteRam(ApplVar.Dept.Price, ApplVar.AP.Dept.PriceSize);
        WriteRam(ApplVar.Dept.PriceMax, ApplVar.AP.Dept.PriMaxSize);
    }
}

void ReadDept()
{
    GetDeptOffSet();

    ReadRam(ApplVar.Dept.Random, ApplVar.AP.Dept.RandomSize);
    ReadRam(ApplVar.Dept.Name, ApplVar.AP.Dept.CapSize);
    ApplVar.Dept.Name[ApplVar.AP.Dept.CapSize] = 0;
    ReadRam(&ApplVar.Dept.Group, sizeof(ApplVar.Dept.Group));
    ReadRam(&ApplVar.Dept.Print, sizeof(ApplVar.Dept.Print));
    ReadRam(&ApplVar.Dept.Options, sizeof(ApplVar.Dept.Options));
//	if (ApplVar.AP.Tax.Number)
    ReadRam(&ApplVar.Dept.Tax, sizeof(ApplVar.Dept.Tax));
    ReadRam(&ApplVar.Dept.Kp, sizeof(ApplVar.Dept.Kp));
    ReadRam(ApplVar.Dept.Price, ApplVar.AP.Dept.PriceSize);
    ReadRam(ApplVar.Dept.PriceMax, ApplVar.AP.Dept.PriMaxSize);
}


void PrintModifiers()
{
    BYTE j;

    if (!BIT(KPPRICE, BIT5))
        return;
    for (j = 0; j < ApplVar.ModiCount; j++)
    {
        ApplVar.ModiNumber = ApplVar.ModNum[j];
        ReadModi();
        MemSet(SysBuf, sizeof(ApplVar.Modi.Name), ' ');
        strcpy(SysBuf + 5, ApplVar.Modi.Name);
        PrintStr(SysBuf + 3);
    }
}


/* temp points to string for number and if cmd = 0 the R & J & Slip */
/* when cmd = 1 then ApplVar.KP black if cmd == 2 then ApplVar.KP red */

char *GetPluPrint(char *temp,BYTE  cmd)
{
    if (BIT(PLU_PRINT,BIT0))     /* print PLU #? */
    {
        if ((CHARSET & 0xf0) == 0x10 || (SLIP != 4 &&
              ((CHARSET & 0x0f) == 3 || (CHARSET & 0x0f) == 7)))  /* number sign not available */
            *temp = 'N';
        else
            *temp = '#';
        if (ApplVar.AP.Plu.RandomSize)
        {
            HEXtoASC(temp + 1, ApplVar.Plu.Random, ApplVar.AP.Plu.RandomSize);
            *(temp + ApplVar.AP.Plu.RandomSize * 2 + 1) = 0;
        }
        else
        {
            WORDtoASCZero(temp + 5, ApplVar.PluNumber + 1);
            *(temp + 6) = 0;
        }
        if ((PLU_PRINT & 0x0f) == 1)     /* only for plu# */
            return temp;
        if (!cmd)      /* R & J & SLIP */
            PrintStr(temp);
        else            /* type = 1 then black if type == 2 then red */
            PrintKp(cmd, temp);
    }
    if (cmd && ApplVar.AP.Plu.CapSize)
        return ApplVar.Plu.Name;            /* on ApplVar.KP always PLU name when active */
    switch (PLU_PRINT & 0x0f)
    {
    case 4:         /* print depart caption */
    case 5 :        /* print PLU# + Depart name */
        return ApplVar.Dept.Name;
    default:
        return ApplVar.Plu.Name;
    }
}



/*
    ApplVar.Dept.Options
    BIT 0 - If set then price is negative
    BIT 1 - if set then Zero ApplVar.Price not allowed
    BIT 2 - if set Single Ticket
    BIT 3 - if set then Double ticket (also Single set)
    BIT 4 - Print Line after article
    BIT 5 - if Set single item when start of sale on TEND#1
    BIT 6 - Add to Discount Itemizer 1
    BIT 7 - Add to Discount Itemizer 2
*/
void ProcessDept()
{
    char BCDValue1[4],temp[18];  /* used for converting a number */
    char *str;
    ULONG i;
    short k;
	BYTE t;
    BCD  sMaxPrice,sMulti;

    //ccr2017-06-21>>>��û�д��վ�ʱ,����SD���Ĵ洢�ռ�>>>>>>>>>>>
    if (!ApplVar.FRegi && CheckEJSpace())
        return;//�洢�ռ���ʱ,��ֹ����
#if (SDCACHESIZE)
    if (ApplVar.SDCache.Type=='R' && SDCACHESIZE-ApplVar.SDCache.Length<SDCACHEWARNING)
    {
       ApplVar.ErrorNumber=ERROR_ID(CWXXI124);
       return;
    }
#endif
    //ccr2017-06-21<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    ApplVar.FCurr = 0;
    if ((ApplVar.Key.Code == ApplVar.OldKey.Code && !ApplVar.OldMultiCount) || ApplVar.FVoid)    /* same or void */
    {
        //Multi Input of the same DEPT
        ApplVar.MultiplyCount = ApplVar.OldMultiCount;
        ApplVar.TaxTemp = ApplVar.TaxTemp1;     /* restore Temp ApplVar.Tax Shift */
        if (!ApplVar.FVoid) /* no void */
        {
            if (ApplVar.RepeatCount < 200)
                ApplVar.RepeatCount++;
            else
                ApplVar.RepeatCount = 1;
        }
        else
        {
            ApplVar.RepeatCount--;
            ApplVar.ModiCount = ApplVar.OldModiCount;
        }
    }//end of if ((ApplVar.Key.Code == ApplVar.OldKey.Code && !ApplVar.OldMultiCount) || ApplVar.FVoid)
    else
    {                /* not same DEPT and no void */
        ApplVar.OldModiCount = 0;
        if (ApplVar.Key.Code < PLU1)
        {
            if (ApplVar.Key.Code == DEPT)
            {
                if (!Appl_EntryCounter)
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                    return;
                }
                ApplVar.DeptNumber = Appl_NumberEntry;
                if (!ApplVar.FPrice)        /* amount entered? */
                {
                    ApplVar.DeptNumber--;
                    ReadDept();
                    ApplVar.Price = ZERO;
                    memcpy(ApplVar.Price.Value,ApplVar.Dept.Price,ApplVar.AP.Dept.PriceSize);
                    ApplVar.DeptNumber++;
                }
            }
            else
            {
                ApplVar.DeptNumber = ApplVar.Key.Code - DEPT;
                if (BIT(ApplVar.ArrowsAlfa,KEY2ndLAYER)) // Second layer
                    ApplVar.DeptNumber += ApplVar.DeptKeys;

                if (!BIT(SLFLAG,BIT7)) //SHIFT-dept only once if not set(һ����Ч)
                    RESETBIT(ApplVar.ArrowsAlfa,KEY2ndLAYER);
                if (!ApplVar.FPrice)
                {
                    if (AmtInputMask())
                        return;
                    //ReadDept();
                    if (Appl_EntryCounter)
                        ApplVar.Price = ApplVar.Entry;
                    else
                        ApplVar.Price = ZERO;
                }
                else if (Appl_EntryCounter)
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                    return;
                }
            }
            if (BIT(ARTLEVEL, BIT5))    /* Article shift also for DEPART? */
                ApplVar.DeptNumber += ApplVar.PluArtLevel;
            if (!ApplVar.DeptNumber || ApplVar.DeptNumber > ApplVar.AP.Dept.Number)
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI42);
                return;
            }
            ApplVar.FRemote = 0;
            ApplVar.FPlu = 0;
            ApplVar.DeptNumber--;
            //ccr2017-08-02>>>>>>>
            ReadDept();
            if (BIT(ApplVar.Dept.Print,BIT7))
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI116);//��ֹ����(NOt ACTIVED)
                return;
            }
            //ccr2017-08-02<<<<<<<
        }
        else     /* must be ApplVar.Plu? */
        {
            if (ApplVar.PluDept < ApplVar.AP.Dept.Number)
                ApplVar.DeptNumber = ApplVar.PluDept;
            else
                ApplVar.DeptNumber = 0;
            if (!ApplVar.FPrice)
            {
                ApplVar.Price = ZERO;   /* clear previous price */
                memcpy(ApplVar.Price.Value, ApplVar.Plu.Price[ApplVar.PluPriceLevel], ApplVar.AP.Plu.PriceSize);
            }
            else if (BIT(PLU_PRINT,BIT5))
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI35);
//				ApplVar.FPrice = 0;
                return;
            }
            ApplVar.FPlu = 1;
            ReadDept();//ccr2017-08-02
        }
        //ccr2017-08-02 ReadDept();
        if (!CheckNotZero(&ApplVar.Price))
            for (i=0;i<ApplVar.AP.Dept.PriceSize;i++)
                ApplVar.Price.Value[i] = ApplVar.Dept.Price[i];

        sMaxPrice =ZERO;
        ApplVar.ErrorNumber=0;
        for (i=0;i<ApplVar.AP.Dept.PriMaxSize;i++)
        {
            ApplVar.ErrorNumber |= (ApplVar.Dept.PriceMax[i] !=0);//ccr070725
            sMaxPrice.Value[i] = ApplVar.Dept.PriceMax[i];
        }

        if (ApplVar.ErrorNumber && CompareBCD(&ApplVar.Price,&sMaxPrice)>0)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI18); /* zero price not allowed enter amount */
            return;
        }
        ApplVar.ErrorNumber =0;
        if (!ApplVar.FInv && BIT(ApplVar.Dept.Options, BIT1) &&
            !CheckNotZero(&ApplVar.Price))   /* ZERO price allowed ? */
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI43); /* zero price not allowed enter amount */
            return;
        }
        if (!ApplVar.MultiplyCount)
            ApplVar.Qty = ONE;
        ApplVar.RepeatCount = 1;
        if (BIT(ApplVar.Dept.Options, BIT0))   /* negative ? */
            ApplVar.Price.Sign = 0x80;     /* make price negative */
        if (ApplVar.FPb)
            ApplVar.Dept.Print = (ApplVar.Dept.Print & 0xc0)+ ApplVar.PbF.Print;//ccr2017-08-02
        if (ApplVar.Dept.Group < ApplVar.AP.Group.Number)
            ApplVar.GroupNumber = ApplVar.Dept.Group;
        else
            ApplVar.GroupNumber = 0;
        ReadGroup();
    }
    if (ApplVar.FInv && ApplVar.FInv < 3 && !ApplVar.MultiplyCount)    /* inventory and no entry then not print */
        ApplVar.PrintLayOut = 0;
    else
    {
#if defined(FISCAL)
        if (!ApplVar.Dept.Tax )
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI100);
            return;
        }
#endif

        if (!ApplVar.FInv)
            ApplVar.PrintLayOut = ApplVar.Dept.Print & 0x3f;//ccr2017-08-02
        else
        {
            ApplVar.PrintLayOut = 0x03;     /* R & J */
            ApplVar.Price = ZERO;       /* clear current price */
        }
    }
    if (ApplVar.FVoid || ApplVar.FCorr || ApplVar.FRefund) /* void, corr, refund */
        ApplVar.Qty.Sign ^= 0x80;
    if (ApplVar.FCanc)
        ApplVar.Qty.Sign ^= 0x80;
    if (ApplVar.FBarcode==2 || ApplVar.FBarcode==3) //ccr 040412
    {
        ApplVar.Amt = ApplVar.Entry;
        ApplVar.Amt.Sign |= (ApplVar.Qty.Sign & 0x80);
    }
    else
    {
        ApplVar.Amt = ApplVar.Price;
        Multiply(&ApplVar.Amt, &ApplVar.Qty);
        RoundBcd(&ApplVar.Amt, 0);
#if (0)//ccr2014-08-06 /defined(FISCAL)	//cc 20071018
        if ((ApplVar.Amt.Sign & 0x80) && CompareBCD(&ApplVar.Amt, &ApplVar.FTotal) == 1)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI101);
            return;
        }
#endif

        if (ApplVar.Qty.Sign & 0x03)     /* ApplVar.Qty with decimal point? */
            AmtRound(1, &ApplVar.Amt);
    }
    if (!ApplVar.FInv  && CheckMaxEntry(&ApplVar.Amt, ApplVar.Group.Family))
    /*
         CompareBCD(&ApplVar.Amt, &MILLION) > -1)) */
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI18);
        return;
    }
    if (!ApplVar.FInv)
    {

        sMaxPrice = ApplVar.Amt;
        Add(&sMaxPrice,&ApplVar.TotalMax);//�վ��ܽ��

//ccr2018-01-17>>>>>>>>>>>>>>>
        if (ReceiptMAX)
        {
            sMulti=ZERO;
            ULongToBCDValue(sMulti.Value+1,ReceiptMAX);
            k=CompareBCD(&sMaxPrice, &sMulti);
        }
        else
            k=CompareBCD(&sMaxPrice, &MAXBCDLONG);
/*   		if ((ApplVar.Qty.Sign & 0x03) && CompareBCD(&ApplVar.Qty, &THOUSAND10) > -1)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI18);
            return;
        }
        else    */
        if ((CompareBCD(&ApplVar.Qty, &THOUSAND10) > -1) ||  k> 0)//ccr080901
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI18);
            return;
        }
//ccr2018-01-17<<<<<<<<<<<<<<<<
    }
    if (BIT(PBINFO, BIT0) && !ApplVar.PbNumber && !BIT(ApplVar.FNoPb, BIT0) && !ApplVar.FInv)  /* pb Compulsory */
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI10);
        return;
    }
//   if (RegiStart())  //ccr050411
//		return;  /* check if start of registration */
    if (!ApplVar.FInv)
    {
#if defined(FISCAL)
        if (!ApplVar.FRegi && !ApplVar.FInv)
            ApplVar.FStatus = 1;        /* set fiscal receipt */
#endif
        if (RegiStart())
            return;  /* ccr050411���ӿ��ʱ������ӡƱͷ check if start of registration */

        if (ApplVar.FVoid)
        {
            ApplVar.RGRec.Qty = ApplVar.Qty;    /* store ApplVar.Qty */
            ApplVar.RGRec.Amt = ApplVar.Amt;    /* store amount not price */
        }
        StoreInBuffer();
        if (ApplVar.RepeatCount > 1)
            ApplVar.ModiCount = ApplVar.OldModiCount;
        else
            ApplVar.OldModiCount = 0;
    }

    ApplVar.Cost = ZERO;
    if (!ApplVar.FPlu)   /* ApplVar.Dept ? */
        ApplVar.RGRec.Key.Code = DEPT + 1 + ApplVar.DeptNumber;
    else
    {
        if (ApplVar.AP.Plu.Cost && !BIT(ART_LEVEL, BIT2))
        {
            memcpy(ApplVar.Cost.Value, ApplVar.Plu.Cost, ApplVar.AP.Plu.PriceSize);
            Multiply(&ApplVar.Cost, &ApplVar.Qty);
            RoundBcd(&ApplVar.Cost, 0);
        }
        ApplVar.RGRec.Key.Code = PLU1 + 1 + ApplVar.PluNumber;
    }
    ApplVar.RGRec.Qty = ApplVar.Qty;
    ApplVar.RGRec.Amt = ApplVar.Price;
    ApplVar.RGRec.Group = ApplVar.GroupNumber;
    if (ApplVar.FPlu)
    {
        ApplVar.RGRec.Amt.Value[BCDLEN-1] = ApplVar.PluPriceLevel;
    }

    if (ApplVar.FCorr && (!ApplVar.PbNumber || (!ApplVar.AP.StartAddress[AddrTrack])))
    {
        ApplVar.BufCmd = 2;     /* only check if used */
        StoreInBuffer();    /* check if article used */
        if (ApplVar.ErrorNumber)
            return;
    }
    if (ApplVar.FPluEnq != 2 ||         /* if Link not store */
        !ApplVar.AP.Pb.ArtAmt ||    /* when no amount stores the always store */
        BIT(ApplVar.AP.Options.Plu, BIT2)) /* always store link ? */
    {
        //ccr091223>>>>>>>>>>>
        if (ApplVar.PbNumber && (BCDWidth(&ApplVar.RGRec.Amt)>ApplVar.AP.Pb.ArtAmt*2 || BCDWidth(&ApplVar.RGRec.Qty)>ApplVar.AP.Pb.Qty*2))
        {
            ApplVar.ErrorNumber = ERROR_ID(CWXXI65);
            return;
        }
        //<<<<<<<<<<<<<<<<<<<<<
        if (StorePbBuffer())     /* store in ApplVar.PB buffer */
        {
            ApplVar.RGRec.Key.Code = 0;
            return;
        }
    }
    if (ApplVar.FCorr || ApplVar.FRefund)
    {
        ApplVar.RGRec.Key.Code = CORREC + 1 + ApplVar.CorrecNumber;
        ApplVar.RGRec.Amt = ApplVar.Amt;        /* store total amount not price */
        if (ApplVar.FRefund)
            ApplVar.BufCmd = 0;             /* no consolidation for refund */
        StoreInBuffer();      /* store correction or refund function */
        if (ApplVar.FRefund)
            ApplVar.BufCmd = 0;             /* no consolidation for refund */
        ApplVar.RGRec.Amt = ApplVar.Price;
        if (!ApplVar.FPlu)   /* ApplVar.Dept ? */
            ApplVar.RGRec.Key.Code = DEPT + 1 + ApplVar.DeptNumber;
        else
        {
            ApplVar.RGRec.Key.Code = PLU1 + 1 + ApplVar.PluNumber;
            ApplVar.RGRec.Amt.Value[BCDLEN-1] = ApplVar.PluPriceLevel;
        }
    }


    memset(temp,' ',sizeof(temp));
#if (DISP2LINES)
    memset(BCDValue1,0 ,sizeof(BCDValue1));
    if (!ApplVar.FPlu)// || ApplVar.AP.Plu.RandomSize)
        strncpy(temp,ApplVar.Dept.Name,DISLEN);
    else
        strncpy(temp,ApplVar.Plu.Name,DISLEN);
    temp[DISLEN]=0;
//liuj 0615
    if (ApplVar.RepeatCount > 1 || (ApplVar.FVoid && ApplVar.RepeatCount))
    {
        i = ApplVar.RepeatCount;
        if (i > 99)
        {
            BCDValue1[2] = '0'+(i % 10);
            i /= 10;
        }
        if (i > 9)
        {
            BCDValue1[1] = '0'+ (i % 10);
            i /= 10;
        }
        BCDValue1[0] = '0'+i;
    }
//    liuj 0615
#elif (DD_LCD_1601==1)
    if (ApplVar.RepeatCount > 1 || (ApplVar.FVoid && ApplVar.RepeatCount))
    {
        i = ApplVar.RepeatCount;
        CLONG(temp[1])=0;
        memset(temp,0,sizeof(temp));
        if (i > 99)
        {
            temp[3] = '0'+(i % 10);
            i /= 10;
        }
        if (i > 9)
        {
            temp[2] = '0'+ (i % 10);
            i /= 10;
        }
        temp[0] = 'X';
        temp[1] = '0'+i;

    }
    else if (!ApplVar.FPlu || ApplVar.AP.Plu.RandomSize)
    {
        sprintf(temp,"D-%d",ApplVar.DeptNumber + 1);
    }
    else
    {
        sprintf(temp,"P-%d",ApplVar.PluNumber + 1);
    }


#else
    if (ApplVar.RepeatCount > 1 || (ApplVar.FVoid && ApplVar.RepeatCount))
    {
        i = ApplVar.RepeatCount;

        if (i > 99)
        {
            temp[2] = '0'+(i % 10);
            i /= 10;
        }
        if (i > 9)
        {
            temp[1] = '0'+ (i % 10);
            i /= 10;
        }
        temp[0] = '0'+i;
        temp[3] = 0;
    }
    else
    {//ccr090120>>>>>>>>>>>>>>>>>>>
        if (!ApplVar.FPlu || ApplVar.AP.Plu.RandomSize)
        {
            i = ApplVar.DeptNumber + 1;
            temp[0] = 'D';
        }
        else
        {
            i = ApplVar.PluNumber + 1;
            temp[0] = 'P';
        }
        temp[WORDtoASCL(temp+1,i)+1] = 0;   /* terminate string */
    }//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#endif


    if (!ApplVar.FInv)
    {

#if(DD_ZIP==1)

        PutsO(temp);

        Puts1(DispAmtStr(BCDValue1, &ApplVar.Amt,DISLEN));//    liuj 0615
#elif(DD_ZIP_21==1)

        PutsO(temp);

        Puts1(DispAmtStr(BCDValue1, &ApplVar.Amt,DISLEN));//    liuj 0615
         PutsC(DispAmtStr(CusDText[ItemDTextPRI], &ApplVar.Amt,DISLENC));//    PenGH
#else//if !defined(CASE_EURO)
        PutsO(DispAmtStr(temp, &ApplVar.Amt,DISLEN));
#endif

    }


    if (ApplVar.FVoid || ApplVar.FCorr || ApplVar.FRefund) /* void, corr, refund */
    {
        ApplVar.PrintLayOut = ApplVar.Correc.Print;
        PrintStr(ApplVar.Correc.Name);
        if (ApplVar.FRefund)   /* refund ? */
            ApplVar.RetQty = ApplVar.Qty;
    }
    else if (!CheckNotZero(&ApplVar.RetQty))    /* already zero ? */
        ApplVar.RetQty.Sign = ApplVar.Qty.Sign & 0x03;  /* decimal point must remain same */
    ApplVar.PrintLayOut = ApplVar.Dept.Print & 0x3f;//ccr2017-08-02

#if (PRINTITEMSType==0)
    if (!ApplVar.FInv)
        PrintMultiply();//print ApplVar.Qty * ApplVar.Amt(12 x 12.50)
#endif

#if (defined(CASE_GREECE)) //ϣ���ڽ��ǰ����ӡŷԪ����
    Prefix1 = 0;
    Prefix2 = 0;
#endif

#if DD_FISPRINTER
    str = ApplVar.ItemName;
#else
    if (ApplVar.FPlu)
        str = GetPluPrint(temp, 0);   /* get plu print receipt & journal & slip */
    else
        str = ApplVar.Dept.Name;
#endif

    if (ApplVar.FInv)       /* inventory ? */
    {
        if (ApplVar.FInv == 2)
            ApplVar.Qty.Sign ^= 0x80;   /* invert sign if subtract */
        if (ApplVar.MultiplyCount)  /* new entry ? */
        {
            if (ApplVar.FInv == 3)  /* easy price set ? */
            {
                ApplVar.Price = ApplVar.Qty;
                memcpy(ApplVar.Plu.Price[ApplVar.PluPriceLevel], ApplVar.Price.Value, ApplVar.AP.Plu.PriceSize);
                WritePlu();
                if (BIT(PBPRINT,BIT5))      //lyq20031230
                    PrintAmt(str, &ApplVar.Price);
            }
            else
            {
                Add(&ApplVar.PluInventory, &ApplVar.Qty);
                if (!ApplVar.FTrain)
                    WritePluInventory();
                if (BIT(PBPRINT,BIT5))    //lyq20031230
                {
                    PrintQty(Prompt.Caption[ItemPrompt36], &ApplVar.Qty); /* change inventory with */
                    PrintQty(str, &ApplVar.PluInventory);
                }
            }
        }
        if (ApplVar.FInv == 3)
        {

#if(DD_ZIP==1)
            PutsO(temp+3);
            Puts1(DispAmtStr(0, &ApplVar.Price,DISLEN));
#elif(DD_ZIP_21==1)     //    PenGH  2008-06-03
            PutsO(temp+3);
            Puts1(DispAmtStr(0, &ApplVar.Price,DISLEN));
            if (SysBuf[sizeof(SysBuf)- DISLENC + 3]==' ')
                CopyFrStr(&SysBuf[sizeof(SysBuf)- DISLENC], CusDText[ItemDTextPRI]);
            PutsC(&SysBuf[sizeof(SysBuf)- DISLENC]);
#else
            PutsO(DispAmtStr(temp + 3, &ApplVar.Price,DISLEN));
#endif

        }
        else
        {

#if(DD_ZIP==1)
            PutsO(temp+3);
            Puts1(DispAmtStr(0, &ApplVar.PluInventory,DISLEN));
#elif(DD_ZIP_21==1)    //    PenGH  2008-06-03
            PutsO(temp+3);
            Puts1(DispAmtStr(0, &ApplVar.PluInventory,DISLEN));
            PutsC(&SysBuf[sizeof(SysBuf)- DISLENC]);
#else
            PutsO(DispQtyStr(temp + 3, &ApplVar.PluInventory,DISLEN));
#endif
        }
    }
    else// if (!ApplVar.FInv)
    {
#if (PRINTITEMSType==0)
/* Print mode for the items
================================
GOODS F              12.54
*/

#if defined(CASE_GREECE)
//ccr2017-05-17        GOODS F          12.54 5.67%
        FormatTaxRate(0,ApplVar.Dept.Tax,PRTLEN);//ccr2017-06-01

        if (strlen(str)+BCDWidth(&ApplVar.Amt) > PRTLEN-7)
        {
            RJPrint(0, str);
            FormatAmtStr(0, &ApplVar.Amt, PRTLEN-7);
        }
        else
            FormatAmtStr(str, &ApplVar.Amt, PRTLEN-7);
        SysBuf[PRTLEN-7] = ' ';
        SysBuf[PRTLEN] = 0 ;
        RJPrint(0,SysBuf);
#else
        //GOODS F                  12.54

        if (strlen(str)+BCDWidth(&ApplVar.Amt) > PRTLEN-5)
        {
            RJPrint(0, str);
            memcpy(SysBuf,FormatAmtStr(0, &ApplVar.Amt, PRTLEN),PRTLEN);
        }
        else
            memcpy(SysBuf,FormatAmtStr(str, &ApplVar.Amt, PRTLEN),PRTLEN);
        RJPrint(0,SysBuf);
#endif

        if (ApplVar.RepeatCount <= 1)
        {
#if(DD_ZIP==1)
            PutsO(str);
            Puts1(DispAmtStr(0, &ApplVar.Amt, DISLEN));
#elif(DD_ZIP_21==1)    // PenGH  2008-06-03
            PutsO(str);
            Puts1(DispAmtStr(0, &ApplVar.Amt, DISLEN));
            PutsC(DispAmtStr(str, &ApplVar.Amt, DISLEN));
#else
            PutsO(DispAmtStr(str, &ApplVar.Amt, DISLEN));
#endif
        }
#else //if (PRINTITEMSType==1)
/* Print mode for the items
===========================
GOODS F  1   12.54    12.54
GOODS R  1   35.26    35.26
EXEMPT   1    5.84     5.84
 */
        PrintQtyAmt(&ApplVar.Qty, str, (BCD *)&ApplVar.Amt);

#endif
        //lyq20031229	end
        if (!BIT(PLU_PRINT,BIT2) || !ApplVar.AP.Plu.CapSize)    /* print depart name on receipt */
            PrintModifiers();
        if (BIT(ApplVar.Dept.Options, BIT4))    /* print line ? */
        {
            MemSet(SysBuf, sizeof(SysBuf), '-');
            PrintStr(SysBuf);
        }
//		if (!ApplVar.FCanc && BIT(ApplVar.Dept.Options, BIT2))   /* Single Ticket */
//		{
//		    ApplVar.BufKp = 2;	    /* set so no feed on issue */
//		    ApplVar.FRecIssue = 0;
//		    for(;;)
//		    {
//				ApplVar.PrintLayOut = 0x06;
//				if (!ApplVar.FReceipt)
//				{
//				    if(BIT(ARROWS, BIT0))	     /* receipt on ? */
//						RFeed(1);
//				    if (ApplVar.PbNumber)
//				    {
//						PrintPbKp(0);
//						MemSet(SysBuf, sizeof(SysBuf), ':');
//						ApplVar.PrintLayOut = 0x02;	/* normal size */
//						PrintStr(SysBuf);
//						ApplVar.PrintLayOut = 0x06;	/* double size */
//				    }
//				}
//				if (ApplVar.FRecIssue)
//				{
////				    PrintStr(Prompt.Caption[ItemPrompt49]);
//				    if (ApplVar.FVoid || ApplVar.FCorr || ApplVar.FRefund) /* void, corr, refund */
//				    {
//						ApplVar.PrintLayOut = ApplVar.Correc.Print & 0x06;
//						PrintStr(ApplVar.Correc.Name);
//						ApplVar.PrintLayOut = 0x06;	/* double size */
//				    }
//				}
//				PrintArticle(0,0);	/* 0 indicates NOT kp print */
//				PrintModifiers();
//				if(BIT(ARROWS, BIT0))	 /* receipt on ? */
//				    RFeed(1);
//				ApplVar.PrintLayOut = 0x02;
//				ReceiptIssue(0);
//				ApplVar.FReceipt = 0;
//				if (!BIT(ApplVar.Dept.Options, BIT3) || ApplVar.FRecIssue)	 /* Double Ticket */
//				    break;
//				ApplVar.FRecIssue = 1;
//		    }
//		    AddReceiptNumber();
//		    ApplVar.FRecIssue = 1;  /* set receipt issue used */
//		    ApplVar.BufKp = 0;
//		    ApplVar.PrintLayOut = ApplVar.Dept.Print & 0x3d;//ccr2017-08-02
//		}
        ApplVar.DiscAmt = ZERO;
        ApplVar.FMixMatch = 0;
        if (ApplVar.FPlu)
        {
#if(CASE_RAMBILL)
            Collect_Data(ARTLOG);
#endif
            CheckMixMatch(1);
        }
#if(CASE_RAMBILL)
        else
            Collect_Data(DPTLOG);
#endif

        AddGroupTotal();
        AddDeptTotal();

        if (ApplVar.FPlu)   /* ApplVar.Plu ? */
        {
            if (MyFlags(PLUDISC) && CheckNotZero(&ApplVar.DiscAmt))// ��Ϊ��������۽��д���ʱ�������ۿ���ˮ  //
            {
                //ccr 050613
                sMaxPrice = ApplVar.Amt;
                sMulti=ApplVar.Entry;
//				Subtract(&ApplVar.Amt, &ApplVar.DiscAmt);// ����������ۿ۽��׷�ӵ���Ʒ�۸��ϣ��ָ���Ʒ��ԭʼ�۸� //
//				Collect_Data(ARTLOG);

                ApplVar.Amt = ApplVar.DiscAmt;
                ApplVar.Entry = ZERO;
                memcpy(ApplVar.Entry.Value, ApplVar.Plu.Price[1], ApplVar.AP.Plu.PriceSize);
#if(CASE_RAMBILL)
                Collect_Data(DISCADDLOG);
#endif
                ApplVar.Entry = sMulti;
                ApplVar.Amt = sMaxPrice;
            }
//			else
//				Collect_Data(ARTLOG);

            AddPluTotal();
            if (ApplVar.AP.Plu.InvSize) /* inventory ? */
            {
                if (ApplVar.FCanc != 2) /* Not update inventory when cancel 2 */
                {
                    Subtract(&ApplVar.PluInventory, &ApplVar.Qty);
                    if (!ApplVar.FTrain)
                        WritePluInventory();
                }
            }
        }
#if	(pbAmtDisc)
        ApplVar.PBA.Disc.Sign= 0xff;//ccr091210
#endif
        AddTaxItem(ApplVar.Dept.Tax,ApplVar.Dept.Options);      /*ccr090108 add to tax itemizers */
        if (BIT(ApplVar.Dept.Options, BIT6))
            Add(&ApplVar.DiscItem[0], &ApplVar.Amt);
        if (BIT(ApplVar.Dept.Options, BIT7))
            Add(&ApplVar.DiscItem[1], &ApplVar.Amt);

#if defined(FISCAL)

        if (!ApplVar.FTrain && !ApplVar.FSplit )//ccr20140702!!!!
        {
            if (!ApplVar.Dept.Tax)
                Add(&ApplVar.FExento, &ApplVar.Amt);    /* exento for fiscal report */
            Add(&ApplVar.FTotal, &ApplVar.Amt);    /*    ApplVar.Total Sales for fiscal report     */       //    cc 20071018
            Add(&ApplVar.TotalMax, &ApplVar.Amt);   //    ccr080901
        }
        //	    Add(&ApplVar.FTotal, &ApplVar.Amt);    /* ApplVar.Total Sales for fiscal report */	//cc 2071018
#if DD_FISPRINTER == 1
        if (ApplVar.FRefund)
            Subtract(&ApplVar.RefundAmt,&ApplVar.Amt);
#endif

#else    // PenGH  2009-01-13 09:04:40
        if (!ApplVar.FSplit)     //PenGH  2009-01-14 08:33:34
            Add(&ApplVar.FTotal, &ApplVar.Amt);    /* PenGH 2009-01-13 09:14:19 */
#endif

        if (ApplVar.FVoid || ApplVar.FCorr || ApplVar.FRefund) /* void, corr, refund */
        {
            AddCorrecTotal();
            ApplVar.Key.Code = 0;   /* no repeat */
        }
        if (ApplVar.FCanc == 1)
        {
            ApplVar.CorrecNumber = ApplVar.CancelNumber;
            AddCorrecTotal();       /* add in cancel */
        }
    }//end if
#if (defined(CASE_GREECE))   //ϣ���ڽ��ǰ����ӡŷԪ����
    Prefix1 = PREFIX_1;
    Prefix2 = PREFIX_2;
#endif
    if (ApplVar.FCanc)      /* invert sign back */
        ApplVar.Qty.Sign ^= 0x80;
    ApplVar.FPrice = 0;
    ApplVar.OldMultiCount = ApplVar.MultiplyCount;
    ApplVar.MultiplyCount = 0;
    if (ApplVar.FVoid)
        ApplVar.Qty.Sign ^= 0x80;   /* invert sign back */
    ApplVar.FVoid = 0;
    ApplVar.FCorr = 0;
//ccr090918#if DD_FISPRINTER == 0
    ApplVar.FRefund = 0;
//ccr090918#endif
    if (ApplVar.FPlu && ApplVar.Plu.Link)       /* Linked ApplVar.Plu ? */
        return;
    ApplVar.RetQty = ZERO;
    if (PRICE_LEVEL & 0x01)
        ApplVar.PluPriceLevel = 0;
    if ((ART_LEVEL & 0x03) == 1)
        ApplVar.PluArtLevel = 0;

    if (!ApplVar.FSale && !ApplVar.FPb && ApplVar.AP.Tend.Number && BIT(ApplVar.Dept.Options,BIT5))
    {
        ClearEntry();
        ApplVar.FSale = 1;
        ApplVar.Key.Code = TEND+1;
        Tender();
    }
    else
        ApplVar.FSale = 1;
    ApplVar.FBalance = 0;       //cc 2006-06-29 for Balance
}


/***********************************************
 * ��ӡȫ����������
 *
 * @author EutronSoftware (2017-06-02)
 *********************************************/
void PrintAllOfDepart()
{
    WORD pMax,pFrom,pTo;
    BYTE sKey;

#if (defined(CASE_EURO))//ccr2017-06-01
     Prefix1 = Prefix2 = 0;
#endif
    pMax = ApplVar.AP.Dept.Number;
    if (pMax !=0 )
    {
        sKey = InputFromTo(RECEIPTFROM,pMax);
        if (sKey==EXITKey)
            return;
        pFrom=LogDefine.RecNumFr;
        if (pFrom) pFrom--;
        pTo=LogDefine.RecNumTo;

        SETBIT(ApplVar.PrintLayOut, BIT2);
        PrintStr_Center(MessageDEPT,true);
        RESETBIT(ApplVar.PrintLayOut, BIT2);
        PrintLine('=');

        for (ApplVar.DeptNumber = pFrom; ApplVar.DeptNumber < pTo; ApplVar.DeptNumber++)
        {
            ApplVar.Qty = ZERO;
            ApplVar.Price = ZERO;
            ReadDept();

            memcpy(&ApplVar.Price.Value,ApplVar.Dept.Price,5);
            ApplVar.Price.Sign = 2;

            //#001 Depart-Name       123.45
            memset(SysBuf,' ',PRTLEN);
            ULongtoASCZER0(SysBuf+3,ApplVar.DeptNumber+1,3);
            SysBuf[0]='#';
            CopyFrStr(SysBuf+5,ApplVar.Dept.Name);
            FormatAmt(SysBuf+PRTLEN-1,&ApplVar.Price);
            SysBuf[PRTLEN] = 0;
            RJPrint(0,SysBuf);

            //  GROUP       TAX       13.00%
            FormatTaxRate(0,ApplVar.Dept.Tax,PRTLEN);
            ApplVar.GroupNumber=ApplVar.Dept.Group;
            ReadGroup();
            CopyFrStr(SysBuf+3,ApplVar.Group.Name);
            pMax=strlen(Msg[SHUIMUA].str);
            memcpy(SysBuf+PRTLEN-7-pMax,Msg[SHUIMUA].str,pMax);
            SysBuf[PRTLEN] = 0;
            RJPrint(0,SysBuf);

            if (KbHit())
            {//any key for stop
                Getch();
                break;
            }
            FM_EJ_Exist();
        }
        PrintLine('=');
        ApplVar.BufKp = 0;
        CutRPaper(2);RFeed(4);//ccr070612
    }
#if (defined(CASE_EURO)) //ccr2017-06-01
    Prefix1 = PREFIX_1;
    Prefix2 = PREFIX_2;
#endif

}
