//---------------------------------------------------------------------------
#include "king.h"                               /* Kingtron library and I/O routines */
#include "bios_dir.h"	//direttive di compilazione del BIOS
#include "message.h"
//---------------------------------------------------------------------------


CONST FSTRING Msg[]={
    StrSPACE,          //space
//----------------setup index definitions------------------------
    MsgSETDEPT,              /* 0 */
    MsgSETPLU,                   /* 1 */
    MsgSETPLUSTOCK,     		//SETPLUSTOCK     /*    1     */
    MsgSETTAX,                   /* 2 */
    MsgSETHEAD,              /* 3 */
    MsgSETDISC,              /* 4 */
    MsgSETSYSFLAG,           /* 6 system flags */
    MsgSETGROUP,             /* 14 */
    MsgSETKEYB,              /* 25 */
    MsgSETDATE   ,               /* 11 */
    MsgSETTIME   ,           /* 12 */
    MsgSETGRAP,                  /* 13 */
    MsgSETPERIPHERALS,
#if (DD_CHIPC)
    MsgSETIC,                /* 16 */
#endif
#if (DD_PROMOTION)
    MsgSETPROM,              /* 17 */
#endif
#if (DD_FISPRINTER==0 && DD_DISABLEPBF==0)
    MsgSETPBF,                   /* 18 */
    MsgSETPBINF,             /* 23 */
#endif
    MsgSETCLERK,             /* 20 */
#if (DD_SETREPORT)
    MsgSETREPTYPE,           /* 26 */
    MsgSETREPORT,            /* 27 keyboard */
#endif
#if offNumber
    MsgSETOFF    ,           /* 28 user reports */
#endif
    MsgSETTRAIL,                 /* 31 */
#if (DD_SETSLIP)
    MsgSETSP,                /* 32 */
    MsgSETSHEAD,                 /* 33 */
#endif
#if (DD_CHIPC)
    MsgSETBLOCKIC,           /* 34 */
#endif
    MsgSETNETWORK ,               /* 35 NetWork address*/
#if defined(CASE_GPRS)
    MsgSETGPRSFUNC,
#endif
#if defined(CASE_ETHERNET)
    MsgSETETHERNETFUNC,      //SETGPRSFUNC
#endif
    MsgSETAUXFUNCS,
    //ccr2017-07-24>>ϣ����Ҫȡ��������>>>>>>>
//    MsgSETSALER,             /* 5 */
//    MsgSETCURR,              /* 7 */
//    MsgSETPORT3,                 /* 10 */
//    MsgSETTEND,              /* 15 */
//    MsgSETMODIF,             /* 21 */
//    MsgSETCORR,              /* 23 */
//    MsgSETZONES,             /* 24 ApplVar.PB Info */
//    MsgSETPORA,              /* 29 report messages */
//    MsgSETDRAWER,                /* 30 */
    //ccr2017-07-24<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#if ((DISP2LINES)||DD_LCD_1601)
    CaptionCWXXI1,          //CWXXI01//Ccr "��Ч����!",
    CaptionCWXXI2,          //CWXXI02//Ccr "��Ч����!",
    CaptionCWXXI3,          //CWXXI03//Ccr "��Чʱ��!",
    CaptionCWXXI4,          //CWXXI04//Ccr "��ֹ����!",
    CaptionCWXXI5,          //CWXXI05//Ccr "PLU����Ϊ��!",
    CaptionCWXXI6,          //CWXXI06//Ccr "PLU�ļ����!",
    CaptionCWXXI7,          //CWXXI07//Ccr "��̨��ռ��!",
    CaptionCWXXI8,          //CWXXI08//Ccr "��̨�Ѵ�!",
    CaptionCWXXI9,          //CWXXI09//Ccr "��̨�Ų���!",
    CaptionCWXXI10,          //CWXXI10//Ccr "��������̨��",
    CaptionCWXXI11,          //CWXXI11//Ccr "��̨û�п�̨",
    CaptionCWXXI12,          //CWXXI12//Ccr "��̨�������",
    CaptionCWXXI13,          //CWXXI13//Ccr "��ֹ�޸�ʱ��",
    CaptionCWXXI14,          //CWXXI14//Ccr "����������!",
    CaptionCWXXI15,          //CWXXI15//Ccr "���ۻ�������",
    CaptionCWXXI16,          //CWXXI16//Ccr "��Ʒû���۳�",
    CaptionCWXXI17,          //CWXXI17//Ccr "���ڽ�����!",
    CaptionCWXXI18,          //CWXXI18//Ccr "�������ݳ���",
    CaptionCWXXI19,          //CWXXI19//Ccr "���ڸ���!",
    CaptionCWXXI20,          //CWXXI20//Ccr "�������!",
    CaptionCWXXI21,          //CWXXI21//Ccr "û��ȷ�Ͻ���",
    CaptionCWXXI22,          //CWXXI22//Ccr "��ֹȡ������",
    CaptionCWXXI23,          //CWXXI23//Ccr "�޲���!",
    CaptionCWXXI24,          //CWXXI24//Ccr "�޴��տ�Ա!",
    CaptionCWXXI25,          //CWXXI25//Ccr "�տ�Ա�ı�",
    CaptionCWXXI26,          //CWXXI26//Ccr "�޴��౨��!",
    CaptionCWXXI27,          //CWXXI27//Ccr "������ӡ�ж�",
    CaptionCWXXI28,          //CWXXI28//Ccr "�����ھ�����",
    CaptionCWXXI29,          //CWXXI29//Ccr "���ܷ���ʱ��",
    CaptionCWXXI30,          //CWXXI30//Ccr "�����������",
    CaptionCWXXI31,          //CWXXI31//Ccr "ת�뵽",
    CaptionCWXXI32,          //CWXXI32//Ccr "δ��Ȩ!",
    CaptionCWXXI33,          //CWXXI33//Ccr "��ָ���տ�Ա",
    CaptionCWXXI34,          //CWXXI34//Ccr "��ָ��ӪҵԱ",
    CaptionCWXXI35,          //CWXXI35//Ccr "��ֹPLU��ۣ�",
    CaptionCWXXI36,          //CWXXI36//Ccr "���벻��!",
    CaptionCWXXI37,          //CWXXI37//Ccr "������ӡ����",
    CaptionCWXXI38,          //CWXXI38//Ccr "Ʊ�ݴ�ӡ����",
    CaptionCWXXI39,          //CWXXI39//Ccr "��ӡѹ��̧��",
    CaptionCWXXI40,          //CWXXI40//Ccr "��ӡֽ����!",
    CaptionCWXXI41,          //CWXXI41//Ccr "��ӡ�¶�̫��",
    CaptionCWXXI42,          //CWXXI42//Ccr "����δ����!",
    CaptionCWXXI43,          //CWXXI43//Ccr "����������",/* zero price not allowed enter amount */
    CaptionCWXXI44,          //CWXXI44//Ccr "��ֹ���ָ���",
    CaptionCWXXI45,          //CWXXI45//Ccr "�޴˹���",
    CaptionCWXXI46,          //CWXXI46//Ccr "δ��С�Ƽ�!",
    CaptionCWXXI47,          //CWXXI47//Ccr "���ڹ������",
    CaptionCWXXI48,          //CWXXI48//Ccr "������ˮ��",
    CaptionCWXXI49,          //CWXXI49//Ccr "MODEMͨѶ��!",
    CaptionCWXXI50,          //CWXXI50//Ccr "����������!",
    CaptionCWXXI51,          //CWXXI51//Ccr "POS�����!",
    CaptionCWXXI52,          //CWXXI52//Ccr "�����ݴ�!",
    CaptionCWXXI53,          //CWXXI53//Ccr "Ϊ���ڿ�!",
    CaptionCWXXI54,          //CWXXI54//Ccr "Ϊ��ʧ��!",
    CaptionCWXXI55,          //CWXXI55//Ccr "�ͻ�����!",
    CaptionCWXXI56,          //CWXXI56//Ccr "Ϊ�¿�!",
    CaptionCWXXI57,          //CWXXI57//Ccr "���ǹ��￨!",
    CaptionCWXXI58,          //CWXXI58//Ccr "д������!",
    CaptionCWXXI59,          //CWXXI59//Ccr "���Ų���!",
    CaptionCWXXI60,          //CWXXI60//Ccr "�����ۿۿ�!",
    CaptionCWXXI61,          //CWXXI61//Ccr "�����ֽ�!",
    CaptionCWXXI62,          //CWXXI62//Ccr "�������ʿ�!",
    CaptionCWXXI63,          //CWXXI63//Ccr "����IC��!",
    CaptionCWXXI64,          //CWXXI64//Ccr "�忨����!",
    CaptionCWXXI65,          //CWXXI65//Ccr "�������!",
    CaptionCWXXI66,          //CWXXI66//Ccr "IC��ֵ����!",
    CaptionCWXXI67,          //CWXXI67//Ccr "IC��ʼ������",
    CaptionCWXXI68,          //CWXXI68//Ccr "��ֹ��ʼ��!",
    CaptionCWXXI69,          //CWXXI69//Ccr "IC����!",
    CaptionCWXXI70,          //CWXXI70//Ccr "IC�������!",
    CaptionCWXXI71,          //CWXXT71//Hf "IP��ַ��",
    CaptionCWXXI72,          //CWXXI72//ccr "��Ƶ������!",
    CaptionCWXXI73,          //CWXXI73//Cc "����ʧ��!",
    CaptionCWXXI74,          //CWXXI74>>>>>for fiscal
    CaptionCWXXI75,          //CWXXI75 "Z-REPORT REQUIRE"
    CaptionCWXXI76,          //CWXXI76 "WRITE FM ERROR"
    CaptionCWXXI77,          //CWXXI77 FM����//
    CaptionCWXXI78,          //CWXXI78 "FM ERROR"
    CaptionCWXXI79,          //CWXXI79 "FISCALIZED"
    CaptionCWXXI80,          //CWXXI80 "TRAIN MODE"
    CaptionCWXXI81,          //CWXXI81 "INITIALIZE FM"
    CaptionCWXXI82,          //CWXXI82 EJ�е������д�//
    CaptionCWXXI83,          //CWXXI83 "NO EJ"
    CaptionCWXXI84,          //CWXXI84 EJ ��д����//
    CaptionCWXXI85,          //CWXXI85 EJ������//
    CaptionCWXXI86,          //CWXXI86 "FM IS FULL"
    CaptionCWXXI87,          //CWXXI87 EJ����//
    CaptionCWXXI88,          //CWXXI88 "EJ IS FULL"
    CaptionCWXXI89,          //CWXXI89 "MUST FORMAT SD"
    CaptionCWXXI90,          //CWXXI90 "NEW EJ"
    CaptionCWXXI91,          //CWXXI91 ���200�μӵ��ʼ��//
    CaptionCWXXI92,          //CWXXI92 "CHECKSUM ERROR"
    CaptionCWXXI93,          //CWXXI93 FM ���տ����ƥ��//
    CaptionCWXXI94,          //CWXXI94 "NEW FM"
    CaptionCWXXI95,          //CWXXI95 "O.Battery Low!"
    CaptionCWXXI96,          //CWXXI96 "INNER EJ ERROR"
    CaptionCWXXI97,          //CWXXI97 "INITIALIZE EJ"
    CaptionCWXXI98,          //CWXXI98 EJ���տ����ƥ��//
    CaptionCWXXI99,          //CWXXI99 "STOCK DISABLED"
    CaptionCWXXI100,          //CWXXI100 "INVALID TAX"
    CaptionCWXXI101,          //CWXXI101 ˰��<0

    CaptionGPRSERR,         //CWXXI102 //GPRS����
    CaptionSENDERR,         //CWXXI103 //�������ݳ���
    CaptionRECVERR,         //CWXXI104 //�������ݳ���
    CaptionNOSERVER,         //CWXXI105 //�޷����ӷ�����
    CaptionIPERROR,         //CWXXI106 //�޷�����IP��ַ
    CaptionNOSIM,         //CWXXI107 //��SIM��
    CaptionGPRSKO,         //CWXXI108 //GPRSδ����
    CaptionLINEOFF,        // (CWXXI109) //����δ���
    CaptionTCPERROR,        // (CWXXI110) //����ͨѶʧ��

    //ccr2017-06-16>>>����������SD��������Ϣ>>>
    CaptionCWXXI111,           //INNER SD ����//
    CaptionCWXXI112,           //������EJ
    CaptionCWXXI113,           //�����ʼ��
    //ccr2017-06-16<<<<<<<<<<<<<<<<<<<<<<<<<
    CaptionCWXXI114,           //"FILE-E FAILED'
    CaptionCWXXI115,           //"FILE-I FAILED'
    CaptionCWXXI116,            //"NOT ACTIVED"
    CaptionCWXXI117,           //"OP-Times overflow" //ccr2017-08-08
    CaptionCWXXI118,           //"MUST RESTART ECR" //ccr2017-09-26
                               //
    CaptionCWXXI119,           //"URL/DNS NULL" //ccr2017-10-30
    CaptionCWXXI120,           //"FAILER ON DNS" //ccr2017-10-30
    CaptionCWXXI121,           //"ECR IP NULL" //ccr2017-10-30
    CaptionCWXXI122,           //"NO FILE/FOLDER-E"
    CaptionCWXXI123,           //"NO FILE/FOLDER-I"
    CaptionCWXXI124,           // "CACHE FULL"
    CaptionCWXXI125,           //"RATA DUPLICATION"
    CaptionCWXXI126,           // "PRINT DISCONNECT"   //ccr2018-04-02

#endif	//(DD_ZIP||DD_ZIP_21)
    MsgSETPORT1,                 /* 8 *///ccr2017-08-04
    MsgSETPORT2,                 /* 9 *///ccr2017-08-04
    MsgSETKP,                    /* 19 *///ccr2017-08-04

    MessageN1,          //KAHAO//Ccr 	"����:",
    MessageN2,          //KLXING//Ccr 	"������:",
    MessageN3,          //KNJE//Ccr 	"���ڽ��:",
    MessageN4,          //KYJIN//Ccr 	"��Ѻ��:",
    MessageN5,          //XFZE//Ccr 	"�����ܶ�:",
    MessageN6,          //CHZHZE//Ccr 	"��ֵ�ܶ�:",
    MessageN7,          //SHYCSHU//Ccr 	"ʹ�ô���:",
    MessageN8,          //JGLBIE//Ccr 	"�۸񼶱�:",
    MessageN9,          //PINMA//Ccr 	"PIN��:",
    MessageN10,          //BHJBIE//Ccr 	"��������:",
    MessageN11,          //ZDJZHANG//Ccr 	"�Զ�����:",
    MessageN12,          //ZHKRQI//Ccr 	"�ƿ�����:",
    MessageN13,          //KYXQI//Ccr 	"����Ч��:",
    MessageN14,          //KHMCHEN//Ccr 	"�ͻ�����:",
    MessageN15,          //CHSHHICKA//ccr	"��ʼ��IC",
    MessageN16,          //ICKCHZHI//ccr	"IC����ֵ",
    MessageN17,          //QCHICKA//ccr	"���IC��",
    MessageN18,          //GUASHIIC//ccr "��ʧ����",
    MessageN19,          //ZHEKOUCA//ccr "�ۿۿ�:",
    MessageN20,          //XIANJINKA//ccr "�ֽ�:",
    MessageN21,          //SHEZHANGKA//ccr "���ʿ�:",
    MessageN22,          //XFJIDIAN//ccr "���ѼƵ�:",
    MessageN23,          //ZHKLVF//Ccr "�ۿ���(%):",
    MessageN24,          //ICKTKUAN//Ccr "IC���˿�",
    MessageN25,          //ICKDJDIANG//Ccr "IC���ҽ�����",
    MessageN26,          //ICKSDIAN//Ccr "IC���͵���",
    MessageN27,          //ZHUOTAI//Ccr "��̨",
    MessageN28,          //RECNUMFR//"��ʼ�վݺ�",
    MessageN29,          //RECNUMTO//"�����վݺ�",
    MessageN30,          //EJCSHUA //"EJ��ʼ��"
    MessageN31,          //EJBHAO  //hf 	"EJ���"
    MessageN32,          //EJBBIAO //"EJ ����"
    MessageN33,          //GRANDTOTAL//hf 	"~��~��~��",
#if (defined(FISCAL) || DD_FISPRINTER==1)
    MessageN35,          //ITEMTAXA     //"˰��A˰��",
    MessageN43,          //TAXTOTAL //"˰���ܼ�",
    MessageN431,          //TOTALZCOUNTER //" TOTAL Z REPORTS",
    MessageN44,          //NETSALE  //"������",
    MessageN45,          //RECNUMBER//"���ױ���",
    MessageN46,          //FMPULLOUT  ccr071212
    MSG_ECRxEJ,          //"EJ DISCONNECT"//SD���γ�����ͳ��
    MSG_ECRCMOSERR,      //"CMOS ERRORS" //CMOS����(���ݴ�)����ͳ��
    MSG_ECRxPRINTER,     //"PRINTER DISCONNECT"  //��ӡ���Ͽ�����ͳ��
    MessageN47,          //CHANGEHEAD//"����Ʊͷ",
    MessageNDATE,        //CHANGEDATETIME//"��������ʱ��",
    MessageN48,          //TAXACHG   //"����˰��A",
    MessageN56,          //TAXFROM   //"FROM ",
    MessageN57,          //TAXTO     //"TO ",
    MessageN58,          //PRNFISCAL//Cc"˰�ش洢������",
    MessageN59,          //PRNTOTAL  //"�����ܼ�",
    MessageN60,          //CLEARTOTAL//"�����ܼ�",
    MessageN61,          //MACRESET  //"��λ�ܼ�",
    MessageN62,          //CHANGETAX //Cc"˰�ʸ����ܼ�",
    MessageN63,          //SHKZBB    //hf 	"˰���ջ��ܱ���",
    MessageN64,          //TAXCODE   //hf 	"˰����",
    MessageN65,          //RIFCODE   //hf 	"RIF����",
    MessageN67,          //MIANSHUI  //"��˰����",
    MessageN68,          //SHUIMUA   //hf ����	"˰Ŀ A",
    MessageN69,          //KHMINGCH  //"�ͻ�����",
    MessageN70,          //JIQIHAO	 //"������",
    MessageN71,          //RIQI		 //"����",
    MessageN72,          //SHIJIAN	 //"ʱ��",
    MessageN73,          //XSHZHJI   //"�����ܼ�",
    MessageN74,          //THUOZHJI  //"�˻��ܼ�",
    MessageN75,          //ZHKOUZHJI //"�ۿ��ܼ�",
    MessageN76,          //XIAOSHOUA //hf 	"��ͨ����",		!!!!�µ����Ƶĳ��Ȳ�Ҫ����TAXABLE
    MessageN761,         //NETAFTERTAX //"NET AFTER TAX"	//"˰�����۶�"
    MessageN762,         //AMTWITHTAX		"AMOUNT WITH "	    //"��˰���۶�"
    MessageN77,          //THXIAOSHOU //hf	����	" �˻�����",
    MessageN78,          //ZHKOUXSH   //"�ۿ�����",
    MessageN79,          //THZJSHUI //"�˻�˰��"
    MessageN80,          //ZHKZJSHUI//"�ۿ�˰��"
    MessageN81,          //EJXINXI  //hf 	"EJ��Ϣ",
    MessageN82,          //EJSHJIAN //hf "EJ��ʼ��ʱ��",
    MessageN83,          //NONFISCAL//"�Ƿ�Ʊ",
    MessageN84,          //SHKCSHUA ˰�س�ʼ��liuj 0531 PM
    MessageN85,          //DATEFROM      //"��ʼ����",
    MessageN86,          //DATETO    //"��������",
    MessageN87,          //TIMEFROM   //"��ʼʱ��",
    MessageN871,		 //TIMETO     "����ʱ��"
    MessageN88,          //ZHJIFPHAO  //hf	����	"�ܼƷ�Ʊ��",
    MessageN89,          //ZHJITHHAO  //hf	����	"�ܼ��˻���",
    MessageN90,          //ZHJIFSHHAO //hf	����	"�ܼƷ�˰��",
    MessageN91,          //FAPIAOHAO  //"��Ʊ��",
    MessageN911,         //DAILYRECEIPTS
    MessageN92,          //THUOHAO    //hf	����	"�˻���",
    MessageN93,          //FEISHUIHAO //hf	����	"��˰��",
    MessageN94,          //SHKBBHAO   //hf	����	"˰�ر�����",
    MessageN95,          //QZHJSHU    //���� "���ʼ���"
    MessageN96,          //REPLEFT
    MessageN97,          //SIZEFM
#endif//FISCAL
    MessageN98,          //SIZEEJ
    MessageN99,          //VALUEINIC
    MessageN100,          //LOWBAT
    MessageN101,          //CLEARIC
    MessageN102,          //CHARGEIC
    MessageN103,          //ADPOINTS
    MessageN104,          //INITIC
    MessageN105,          //WAITEICCARD
    MessageN106,          //ICCARDOK
    MessageN107,          //ePOSTAC//ccr epos//ccr "ePOS��֤��:",			//ePOSTAC//ccr epos
    MessageN108,          //WAITEPOS
    MessageN109,          //ePOSCARNO//ccr "��ͨ����:",					//ePOSCARNO
    MessageN110,          //eCARREMAIN//ccr "��ͨ�����:",					//eCARREMAIN
    MessageN111,          //TMHYHAO//ccr "��Ա��:",			//TMHYHAO
    MessageN112,          //BARREPORT//ccr  �� Ա �� ��//
    MessageN113,          //XFJE//ccr "���ѽ��",				//XFJE
    MessageN114,          //ZONGJI//Ccr "�ܼ�",          //ZONGJI
    MessageWait,          //WAITING
    MessageInit,          //INITWAITING
    MessageRecFr,         //RECEIPTFROM    Cc  "��ʼ�վݺ�",   //
    MessageRecTo,        //RECEIPTTO    Cc   "�����վݺ�",   //
    MessageRecZNum,//	"#Z OF RECEIPT"         //"�վݺ�����Z������",	//  ZNumFORRECEIPT
    MessageRecNum,//	"RECEIPT NUMBER"         //"��ѯ���վݺ�",	//    RECEIPTNUMBER

    MessageEXC_VAT,       //SUM_EXC_VAT    //����˰���۽��
    MessageVAT,           //VAT_AMOUNT        //˰��

    MessMODEReg,        //REG_MODE
    MessMODEX  ,        //X_MODE
    MessMODEZ  ,        //Z_MODE
    MessMODESET,        //SET_MODE
#if !defined(CASE_GREECE)//ccr2017-12-14ȥ��������
    MessMODEMAN,        //MG_MODE
#endif
//>>>>>>>>����X��������>>>>>>>>>
    strxDAILYJOURNAL    ,// "DAILY JOURNAL"
    strxDEPARTMENTDAILY ,// "DEPARTMENT DAILY"
    strxPLUDAILY        ,// "PLU DAILY"
    strxCLERKSDAILY     ,// "CLERKS DAILY"
#if (salNumber)
    strxWAITERSDAILY    ,// "WAITERS DAILY"
#endif
    strxCATEGORY        ,//"CATEGORY DAILY"
    strxALLDAILY        ,// "ALL DAILY"
    strxGENERALPARAM	   ,// "GENERAL PARAMETERS"

//>>>>>>>>>����Z��������>>>>>>>>>>>
    strzPRINTZREPORT  ,// "PRINT Z REPORT"
#if defined(CMD_zHTTPPOSTSFILE)
    strzHTTPPOSTSFILE ,// "SEND S-FILES OF Z"
#endif
    strzCOPYLASTZ  	 ,//"COPY OF LAST Z"
    strzDEPTSALES	 ,//"DEPARTMENT SALES"
    strzPLUSALES      ,//  "PLU SALES"
    strzCLERKSSALES   ,// "CLERKS  SALES"
#if (salNumber)
    strzWAITERSSALES  ,// "WAITERS  SALES"
#endif
    strzZERODEPARTMENT,//  "ZERO DEPARTMENT"
    strzZEROPLUSALES  ,// "ZERO PLU SALES"
    strzZEROCLERKS    ,//  "ZERO CLERKS"
#if (salNumber)
    strzZEROWAITERS   ,//  "ZERO WAITERS"
#endif
    strzZEROALLSALES  ,// "ZERO ALL SALES"
    strzFMREADZ_Z     ,// "FM READ Z-Z"
    strzFMREADDATE    ,// "FM READ DATE"
#if defined(CMD_zFMREADTAXRATE)
    strzFMREADTAXRATE ,// "READ TAX RATE "
    strzFMREADHEAD    ,// "READ HEAD "
    strzFMREADSETDATE ,// "READ DATE CHANGED"
#endif
//X���µ�xGENERALPARAM���ܲ˵�>>>>>>
    strxLISTPLU       ,// "PLU LIST"          //xLISTPLU
    strxLISTDEPARTMENT,// "DEPARTMENT LIST"   //xLISTDEPARTMENT
    strxLISTCLERK     ,// "CLERK LIST"        //xLISTCLERK

//FM Read �˵�����
    strSYNOPSIS,    //"SYNOPSIS"      fmSYNOPSIS    //��������
    strANALYTICAL,  //"ANALYTICAL"    fmANALYTICAL  //��ϸ����

    strEJLOGBYDATE    ,// "EJ BY DATETIME" EJBYDATETIME
    strEJLOGBYZ_Z     ,// "EJ BY Z NUMBER" EJBYZNUMBER

//CMD_EXPLOEREJ�˵�,
    strRECEIPTPRINT,     //"RECEIPT PRINT"   EJPrintReceipt
    strZREPORTPRINT,     //"Z REPORT PRINT"  EJPrintZRport

#if(defined(CASE_GPRS))
    //ccr2014-11-11 NEWSETUP>>>>>GPRS ���ܲ˵� >>>>>>>>>>

    GPRSSetMode,            //gprsSETMODE //ccr2014-11-11 NEWSETUP-step2
    GPRSSendECRLog,         //gprsSENDECRLOG //ccr2014-11-11 NEWSETUP-step2
    GPRSSendECRLogAll,      //gprsSENDECRLOGAll //ccr2014-11-11 NEWSETUP-step2
    GPRSDownloadPLU   ,     //  "���ص�Ʒ"    //gprsDownloadPLU //ccr2014-11-11 NEWSETUP-step2
    GPRSDownloadDEPT  ,     //  "���ز���"    //gprsDownloadDEPT //ccr2014-11-11 NEWSETUP-step2
    GPRSDownloadCLERK ,     //  "�����տ�Ա"    //gprsDownloadCLERK //ccr2014-11-11 NEWSETUP-step2
    GPRSDownloadHEAD  ,     //  "����Ʊͷ"       //gprsDownloadHEAD //ccr2014-11-11 NEWSETUP-step2
    GPRSDownloadTRAIL ,     //  "����Ʊβ"      //gprsDownloadTRAIL //ccr2014-11-11 NEWSETUP-step2
    GPRSDownloadALL ,       //  "����ȫ������"      //gprsDownloadALL //ccr2016-08-18
    GPRSRestart,            //  "��λGPRSģ��"      //gprsRestart //ccr2016-08-26
    GPRSSendMESS,			//gprsSENDMESS
    //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#endif
#if(defined(CASE_ETHERNET))
    ////ccr2017-02-16 NEWSETUP>>>>>��̫�����ܲ˵� >>>>>>>>>>
    ETHERNETSendMESS,			//net_PINGMESS
    ETHERNETSetMode,            //net_SETMODE //ccr2014-11-11 NEWSETUP-step2
    ETHERNETSendECRLog,         //net_SENDECRLOG //ccr2014-11-11 NEWSETUP-step2
    ETHERNETSendECRLogAll,      //net_SENDECRLOGAll //ccr2014-11-11 NEWSETUP-step2
    ETHERNETDownloadPLU   ,     //  "���ص�Ʒ"    //net_UpdatePLU //ccr2014-11-11 NEWSETUP-step2
    ETHERNETDownloadDEPT  ,     //  "���ز���"    //net_UpdateDEPT //ccr2014-11-11 NEWSETUP-step2
    ETHERNETDownloadCLERK ,     //  "�����տ�Ա"    //net_UpdateCLERK //ccr2014-11-11 NEWSETUP-step2
    ETHERNETDownloadHEAD  ,     //  "����Ʊͷ"       //net_UpdateHEAD //ccr2014-11-11 NEWSETUP-step2
    ETHERNETDownloadTRAIL ,     //  "����Ʊβ"      //net_UpdateTRAIL //ccr2014-11-11 NEWSETUP-step2
    ETHERNETDownloadALL ,       //  "����ȫ������"      //net_UpdateALL //ccr2016-08-18
    ETHERNETRestart,            //  "��λETHERNETģ��"      //net_Restart //ccr2016-08-26
    //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#endif
//ccr2017-09-14>>>>>>>>>>>>>>>>>>>>>>>>>
#if(defined(CASE_ETHERNET)||defined(CASE_GPRS))
    Msg_MINISTRYSEND  ,//   "MINISTRY SEND"
    //>>>>>For NET Functions
    Msg_SERVERURL,
    Msg_PERSONALCODE,
    Msg_GPRSSEND,
    //>>>>>For Net Work
    Msg_DHCP          ,//  "DHCP"
    Msg_PRIMARYDNS    ,//  "PRIMARY DNS"
    Msg_SECONDARYDNS  ,//  "SECONDARY DNS"
    Msg_PRINTSETTINGS ,//  "PRINT SETTINGS"
#endif
//ccr2017-09-14<<<<<<<<<<<<<<<<<<<<<<<<<
    //ccr2017-05-10 SETAUXFUNCS>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
    MsgAUX_PRINTPLU		 ,//��ӡ��Ʒ��Ϣ
    MsgAUX_EXPLOREEJ	 ,//��ѯEJ����
    MsgAUX_PRINTFISCAL	 ,//��ӡ������˰����Ϣ
    MsgAUX_PRINTEJ		 ,//��ӡEJ��Ϣ
    MsgAUX_SETPWDX		 ,//����X��������
    MsgAUX_SETPWDZ		 ,//����Z��������
    MsgAUX_SETPWDSET	 ,//����SET��������
    MsgAUX_SETPWDMG		 ,//���þ���MG��������
    MsgAUX_INITFISCAL	 ,//˰�س�ʼ��
    MsgAUX_INITEJ		 ,//��ʼ��EJ
    MsgAUX_PRNGAPHIC	 ,//��ӡ�տ��ͼ��
    MsgAUX_ECRCONFIG     ,//��ӡ�տ������
    //ccr2017-12-08�µ�ϵͳ���Թ���
    msg_SETTSTDISP        ,//  "DISPLAY"       //SETTSTDISP  //"��ʾ����",
    msg_SETTSTCUST        ,// "CUSTOMER"       //SETTSTCUST  //"����ʾ����
    msg_SETTSTPRT         ,// "PRINTER"        //SETTSTPRT   //"��ӡ�汾",
    msg_SETTSTMEM         ,//  "CHECK RAM"     //SETTSTCLK   //"ʱ�Ӳ���",
    msg_SETTSTCLK         ,// "CLOCK"          //SETTSTMEM   //RAM����
    msg_SETTSTBELL        ,//  "BUZZER"        //SETTSTBELL  //"����������
    msg_SETTSTDRAW        ,//  "DRAWER"        //SETTSTDRAW  //"Ǯ�����",
    msg_SETTSTKBD         ,// "KEYBOARD"       //SETTSTKBD   //"���̲���",
    msg_SETTSTCOMM        ,//  "SERIAL PORTS"  //SETTSTCOMM  //"���ڲ���",
#if defined(FOR_DEBUG)//
    msg_SETTSTERASEFM     ,//  "ERASE FM"      //SETTSTERASEFM    //"���FM",
    msg_SETTSTFM          ,//  "CHECK FM"      //SETTSTFM    //"����FM",
#endif                //                   //       //
    msg_SETTSTAUTO        ,//  "SELF-TEST"     //SETTSTAUTO  //"�Զ�����",
    "",
};



CONST struct PROMPTTEXT Prompt =
{
    {/*    Prompt.Caption[50][15]     */
        Prompt1    ,          //ItemPrompt0   "TOTAL"         //Ӧ��
        Prompt2    ,          //ItemPrompt1   "SUBTOTAL"      //
        Prompt3    ,          //ItemPrompt2   "SPENDING"      //"�����ܶ� "
        Prompt4    ,          //ItemPrompt3   " NET AMOUNT"   //
        Prompt5    ,          //ItemPrompt4   " PRICE"        //
        Prompt6    ,          //ItemPrompt5   " TRANSACTIONS" //
        Prompt7    ,          //ItemPrompt6   " QUANTITIES"   //
        Prompt8    ,          //ItemPrompt7   " AMOUNT"       //
        Prompt9    ,          //ItemPrompt8   "RECEIVE"       //
        Prompt10   ,          //ItemPrompt9   "CHANGE"        //
        Prompt11   ,          //ItemPrompt10  " "             //
        Prompt12   ,          //ItemPrompt11  " "             //
        Prompt13   ,          //ItemPrompt12  "-"             //
        Prompt14   ,          //ItemPrompt13  "-"             //
        Prompt15   ,          //ItemPrompt14  "STANDARD"      //
        Prompt16   ,          //ItemPrompt15  "OPERATOR"      //
        Prompt17   ,          //ItemPrompt16  " "             //
        Prompt18   ,          //ItemPrompt17  " "             //
        Prompt19   ,          //ItemPrompt18  "-"             //
        Prompt20   ,          //ItemPrompt19  "REPORT"        //
        Prompt21   ,          //ItemPrompt20  " REFUND"       //
        Prompt22   ,          //ItemPrompt21  " DISCOUNT"     //
        Prompt23   ,          //ItemPrompt22  " COST"         //
        Prompt24   ,          //ItemPrompt23  "TABLE#"        //
        Prompt25   ,          //ItemPrompt24  "CHEQUE#"       // used for Registe
        Prompt26   ,          //ItemPrompt25  "OPTIONS:"      //
        Prompt27   ,          //ItemPrompt26  "GROSS SALES"   //
        Prompt28   ,          //ItemPrompt27  " TAX"          //
        Prompt29   ,          //ItemPrompt28  " PAGE"         //
        Prompt30   ,          //ItemPrompt29  "No.#:"         //
        Prompt31   ,          //ItemPrompt30  "SERVICE"       //
        Prompt32   ,          //ItemPrompt31  "PREV. BALANCE "//
        Prompt33   ,          //ItemPrompt32  "Z COUNT"       //
        Prompt34   ,          //ItemPrompt33  "CLEAR"         //
        Prompt35   ,          //ItemPrompt34  "SYSTEM REPORT" //
        Prompt36   ,          //ItemPrompt35  " GROSS PROFIT" //
        Prompt37   ,          //ItemPrompt36  "STOCK UPDATE"  //
        Prompt38   ,          //ItemPrompt37  "FORMER PB:"    //
        Prompt39   ,          //ItemPrompt38  "CREDIT CARD#"  //
        Prompt40   ,          //ItemPrompt39  "NEW TABLE:"    //
        Prompt41   ,          //ItemPrompt40  "GUESTS"        //
        Prompt42   ,          //ItemPrompt41  "EXCHANGE"      //
        Prompt43   ,          //ItemPrompt42  "INSERT"        // Add random n
        Prompt44   ,          //ItemPrompt43  "DELETE"        // delete rando
        Prompt45   ,          //ItemPrompt44  "DISCOUNT 1"    //
        Prompt46   ,          //ItemPrompt45  "DISCOUNT 2"    //
        Prompt47   ,          //ItemPrompt46  "SALES"         //
        Prompt48   ,          //ItemPrompt47  "MIX-MATCH"     //
        Prompt49   ,          //ItemPrompt48  "STOCK"         //
        Prompt50   ,          //ItemPrompt49  "OFFER"         //
        Prompt51   ,          //ItemPrompt50  "OPTIONS"       // for options
        Prompt52   ,          //ItemPrompt51  "USE KP "       // for KP option
        Prompt53   ,          //ItemPrompt52  "FIXED DISCOUNT"// Options for D
        Prompt54   ,          //ItemPrompt53  "FLOAT DISCOUNT"//
        Prompt55   ,          //ItemPrompt54  "FIXED+FLOAT"   //
        Prompt56   ,          //ItemPrompt55  "OPEN()"        // Options for PBFun
        Prompt57   ,          //ItemPrompt56  "OP_ADD"        //
        Prompt58   ,          //ItemPrompt57  "SERVICE"       //
        Prompt59   ,          //ItemPrompt58  "CONFIRM"       //
        Prompt60   ,          //ItemPrompt59  "PRINT/OPEN"    //
        Prompt61   ,          //ItemPrompt50  "PRINT BILL"    //
        Prompt62   ,          //ItemPrompt61  "CANCEL"        //
        Prompt63   ,          //ItemPrompt62  "SPLIT BILL"    //
        Prompt64   ,          //ItemPrompt63  "TRANSFER"      //
        Prompt65   ,          //ItemPrompt64  "MOVE TO"       //
        Prompt66   ,          //ItemPrompt65  "COVER"         //
        Prompt67   ,          //ItemPrompt66  "JOKERSLIP ?"   //
        Prompt68   ,          //ItemPrompt67  "POINT ?"       //
        Prompt69   ,          //ItemPrompt68  "DEC_ADD ?"     //
        Prompt70   ,          //ItemPrompt69  "CHIP CARD ?"   //
        Prompt71   ,          //ItemPrompt70  "DISCOUNT"      //
        Prompt72   ,          //ItemPrompt71  "CASH"          //
        Prompt73   ,          //ItemPrompt72  "CREDIT"        //
        Prompt74   ,          //ItemPrompt73  "PRT CARD INFO."//
        Prompt75   ,          //ItemPrompt74  "AUTO DISCOUNT "//
        Prompt76   ,          //ItemPrompt75  "POINTS"        //
        Prompt77   ,          //ItemPrompt76  "<CASH>KEY TEND"//
        Prompt78   ,          //ItemPrompt77  "CHARGE/DISCHG?"//
        Prompt79   ,          //ItemPrompt78  "EXPIRED DATE " //

#if(  (DISP2LINES) || DD_LCD_1601==1)

//Option for dept==================
        Prompt80   ,          //ItemPrompt79	"��ֹ��۸�",		//JZHLJGE
        Prompt81   ,          //ItemPrompt80	"��ӡ�ָ���",		//DYFGXIAN
        Prompt82   ,          //ItemPrompt81	"��������:",		//DXXSHOU
        Prompt83   ,          //ItemPrompt82 	"�ۿ��� 1:",		//ZHKXIANG1
        Prompt84   ,          //ItemPrompt83 	"�ۿ��� 2:",		//ZHKXIANG2
//Option for ApplVar.KP===================
        Prompt85   ,          //ItemPrompt84	"��ӡ�ܶ�:",		//KPDYZE
        Prompt86   ,          //ItemPrompt85	"����ͬ��ӡ",		//KPCXTDY
        Prompt87   ,          //ItemPrompt86	"�˲�ͬ��ӡ",		//KPCBTDY
//Options for tend=================
        Prompt88   ,          //ItemPrompt87	"��Ǯ��:",		//DKQXIANGF
        Prompt89   ,          //ItemPrompt88	"������:",		//SHRJE
        Prompt90   ,          //ItemPrompt89	"��ֹ����:",		//JZHSHRU
        Prompt91   ,          //ItemPrompt90	"�������:",		//SHRHMA
        Prompt92   ,          //ItemPrompt91	"����ΪС��",		//ZHLXFEI
//Options for ApplVar.PoRa=================
        Prompt93   ,          //ItemPrompt92	"��Ǯ��:",		//DKQXIANGP
        Prompt94   ,          //ItemPrompt93	"���ʽ��",		//FKFSHJIAN
        Prompt95   ,          //ItemPrompt94	"������:",		//CRJE
        Prompt96   ,          //ItemPrompt95	"���/����",		//RJCHJIN
//Option for ApplVar.Disc==================
        Prompt97   ,          //ItemPrompt96	"��ӡ�ۿ۶�",		//DYZHKE
        Prompt98   ,          //ItemPrompt97	"ʹ���ۿ�1:",		//SHYZHK1
        Prompt99   ,          //ItemPrompt98	"ʹ���ۿ�2:",		//SHYZHK2
//Options for currency==============
        Prompt100,          //ItemPrompt99	 "����������",		//MCHJZHLIN
//Options for ApplVar.Draw================
        Prompt101,          //ItemPrompt100	 "��С����:",		//WXSHDIAN
        Prompt102,          //ItemPrompt101	 "��Ǯ��:",		//DKQXIANGD
//Options for ApplVar.Tax=================
        Prompt103,          //ItemPrompt102	 "Ӫҵ/��ֵ:",		//YYZZHI
        Prompt104,          //ItemPrompt103	 "��ӡ˰����",		//DYSHLXIANG
        Prompt105,          //ItemPrompt104	 "��ӡ0˰��",		//DYLSHXXI
        Prompt106,          //ItemPrompt105	 "ΪGST��˰",		//WGSTSHUI
        Prompt107,          //ItemPrompt106	 "��ӡ˰��:",		//DYSHE
//Options for clerk================
        Prompt108,          //ItemPrompt107	 "ȡ������:",		//QXXZHI
        Prompt109,          //ItemPrompt108	 "��������:",		//GGXZHI
        Prompt110,          //ItemPrompt109	 "ȡ������:",		//QXJYIXZHI
        Prompt111,          //ItemPrompt110	 "�˻�����:",		//THXZHI
        Prompt112,          //ItemPrompt111	 "%�ۿ�����:",		//BFBZHKXZHI
        Prompt113,          //ItemPrompt112	 "%�ӳ�����:",		//BFBJCHXZHI
        Prompt114,          //ItemPrompt113	 "+-�������",		//JJJEXZHI
        Prompt115,          //ItemPrompt114	 "��ѵģʽ:",		//PSHMSHI    },
#endif
        PromptActive,       //ItemPrompt115  "ACTIVE",        //ACTIVE
        PromptPrnLogo       //ItemPrompt116  "PRINT LOGO",        //PRINTLOGO
    },
    {   /* DayCap[7][9] */
        DayCap1,
        DayCap2,
        DayCap3,
        DayCap4,
        DayCap5,
        DayCap6,
        DayCap7,
    },
    TitleN1,          //Title[PRTLEN+1],Title for receipt
    {       /*    Message[60][16]     */
        MessageF1,      /* 1 */
        MessageF2,  /* 2 */
        MessageF3,      /* 3 */
        MessageF4,      /* 4 */
        MessageF5,          /* 5 */
        MessageF6,      /* 6 */
        MessageF7,      /* 7 */
        MessageF8,         /* 8 */
        MessageF9,      /* 9 */
        MessageF10,     /* 10 */
        MessageF11,     /* 11 */
        MessageF12,     /* 12 */
        MessageF13,     /* 13 */
        MessageF14,     /* 14 */
        MessageF15,     /* 15 */
        MessageF16,     /* 16 */
        MessageF17,     /* 17 */
        MessageF18,     /* 18 */
        MessageF19,     /* 19 */
        MessageF20,     /* 20 */
        MessageF21,     /* 21 */
        MessageF22,     /* 22 */
        MessageF23,     /* 23 */
        MessageF24,     /* 24 */
        MessageF25,     /* 25 */
        MessageF26,     /* "NOT CHECKED OUT ",  26 */
        MessageF27,     /* 27 */
        MessageF28,     /* "ONLY CHECK OUT  "28 */
        MessageF29,     /* 29 */
        MessageF30,     /* 30 */
        MessageF31,         /* 31 */
        MessageF32,     /* 32 */
        MessageF33,     /* 33 */
        MessageF34,     /* 34 */
        MessageF35,     /* 35 */
        MessageF36,                 /* 36 */
        MessageF37,     /* 37 */
        MessageF38,         /* 38 */
        MessageF39,     /* 39 */
        MessageF40,     /* 40 */
        MessageF41,     /* 41 */
        MessageF42,     /* 42 */
        MessageF43,     /* 43 */
        MessageF44,     /* 44 */
        MessageF45,     /* 45 */
        MessageF46,     /* 46 */
        MessageF47,     /* 47 */
        MessageF48,     /* 48 *///Ccr 	"*** ��Ʒ��� ***",         /* 48 */
        MessageF49,         /* 49 */
        MessageF50,         /* 50 */
        MessageF51,         /* 51 */
        MessageF52,         /* 52 */
        MessageF53,         /* 53 */
        MessageF54,         /* 54 */
        MessageF55,         /* 55 */
        MessageF56,         /* 56 */
        MessageF57,     /* 57 *///Ccr 	"***** ȡ�� *****",         /* 57 */
        MessageF58,     /* 58 */
        MessageF59,         /* 59 */
        MessageF60,         /* 60 */
    },
    {       /* MonthCap[12][9] */
        MonthCap1,
        MonthCap2,
        MonthCap3,
        MonthCap4,
        MonthCap5,
        MonthCap6,
        MonthCap7,
        MonthCap8,
        MonthCap9,
        MonthCap10,
        MonthCap11,
        MonthCap12,
    },
    {    /*    *LineCap[100]([lCAPWIDTH = 8]),������ʾ     */
        LineCap1,      //Line_YES
        LineCap2,      //Line_NO
        LineCap3,      //Line_CAPTION
        LineCap4,      //Line_DEPART
        LineCap5,      //Line_GROUP
        LineCap6,      //Line_SYS_FLAG
        LineCap7,      //Line_PRINT
        LineCap8,      //Line_OPTION
        LineCap9,      //Line_EXTRAKP
        LineCap10,     //Line_TAXUSED
        LineCap11,     //Line_LOC
        LineCap12,     //Line_PRICE1
        LineCap13,     //Line_PRICE2
        LineCap14,     //Line_PRICE3
        LineCap15,     //Line_PRICE4
        LineCap16,     //Line_COST
        LineCap17,     //Line_FIXED
        LineCap18,     //Line_MAX
        LineCap19,     //Line_FIXED1
        LineCap20,     //Line_MAX1
        LineCap21,     //Line_TAXRATE
        LineCap22,     //Line_BUYRATE
        LineCap23,     //Line_SELRATE
        LineCap24,     //Line_START
        LineCap25,     //Line_DRAWER
        LineCap26,     //Line_OTD
        LineCap27,     //Line_PRTTYPE
        LineCap28,     //Line_PERIOD
        LineCap29,     //Line_REPTYPE
        LineCap30,     //Line_PREFIX
        LineCap31,     //Line_LINK
        LineCap32,     //Line_KEYCODE
        LineCap33,     //Line_MANAGE
        LineCap34,     //Line_TYPE
        LineCap35,     //Line_DATEFR
        LineCap36,     //Line_DATETO
        LineCap37,     //Line_TIMEFR
        LineCap38,     //Line_TIMETO
        LineCap39,     //Line_WEEKDAY
        LineCap40,     //Line_DISCOUNT
        LineCap41,     //Line_PACKQTY
        LineCap42,     //Line_UPRICE
        LineCap43,     //Line_PPRICE
        LineCap44,     //Line_PROTOCOL
        LineCap45,     //Line_TELE
        LineCap46,     //Line_PASSWORD
        LineCap47,     //Line_FREQUENT
        LineCap48,     //Line_MINIMUM
        LineCap49,     //Line_PORT
        LineCap50,     //Line_VALUE
        LineCap51,     //Line_GRAPHIC
        LineCap52,     //Line_SLIPTYPE
        LineCap53,     //Line_BLANKLIN
        LineCap54,     //Line_LINEPAGE
        LineCap55,     //Line_PRTINFO
        LineCap56,     //Line_SECOND
        LineCap57,     //Line_LEFTMAR
        LineCap58,     //Line_POINT
        LineCap59,     //Line_PRILEVEL
        LineCap60,     //Line_CONFIRM
        LineCap61,     //Line_FOREGIFT
        LineCap62,     //Line_POSCODE
        LineCap63,     //Line_USECASH
        LineCap64,     //Line_DEADLINE
        LineCap65,     //Line_PERSONALCODE
    },
};


#if (DD_FISPRINTER)
CONST FSTRING MsgError[]={
    CaptionCWXXI0,          //Fiscal status:
    CaptionCWXXI1,          //CWXXI01//Ccr "��Ч����!",
    CaptionCWXXI2,          //CWXXI02//Ccr "��Ч����!",
    CaptionCWXXI3,          //CWXXI03//Ccr "��Чʱ��!",
    CaptionCWXXI4,          //CWXXI04//Ccr "��ֹ����!",
    CaptionCWXXI5,          //CWXXI05//Ccr "PLU����Ϊ��!",
    CaptionCWXXI6,          //CWXXI06//Ccr "PLU�ļ����!",
    CaptionCWXXI7,          //CWXXI07//Ccr "��̨��ռ��!",
    CaptionCWXXI8,          //CWXXI08//Ccr "��̨�Ѵ�!",
    CaptionCWXXI9,          //CWXXI09//Ccr "��̨�Ų���!",
    CaptionCWXXI10,          //CWXXI10//Ccr "��������̨��",
    CaptionCWXXI11,          //CWXXI11//Ccr "��̨û�п�̨",
    CaptionCWXXI12,          //CWXXI12//Ccr "��̨�������",
    CaptionCWXXI13,          //CWXXI13//Ccr "��ֹ�޸�ʱ��",
    CaptionCWXXI14,          //CWXXI14//Ccr "����������!",
    CaptionCWXXI15,          //CWXXI15//Ccr "���ۻ�������",
    CaptionCWXXI16,          //CWXXI16//Ccr "��Ʒû���۳�",
    CaptionCWXXI17,          //CWXXI17//Ccr "���ڽ�����!",
    CaptionCWXXI18,          //CWXXI18//Ccr "�������ݳ���",
    CaptionCWXXI19,          //CWXXI19//Ccr "���ڸ���!",
    CaptionCWXXI20,          //CWXXI20//Ccr "�������!",
    CaptionCWXXI21,          //CWXXI21//Ccr "û��ȷ�Ͻ���",
    CaptionCWXXI22,          //CWXXI22//Ccr "��ֹȡ������",
    CaptionCWXXI23,          //CWXXI23//Ccr "�޲���!",
    CaptionCWXXI24,          //CWXXI24//Ccr "�޴��տ�Ա!",
    CaptionCWXXI25,          //CWXXI25//Ccr "�տ�Ա�ı�",
    CaptionCWXXI26,          //CWXXI26//Ccr "�޴��౨��!",
    CaptionCWXXI27,          //CWXXI27//Ccr "������ӡ�ж�",
    CaptionCWXXI28,          //CWXXI28//Ccr "�����ھ�����",
    CaptionCWXXI29,          //CWXXI29//Ccr "���ܷ���ʱ��",
    CaptionCWXXI30,          //CWXXI30//Ccr "�����������",
    CaptionCWXXI31,          //CWXXI31//Ccr "ת�뵽",
    CaptionCWXXI32,          //CWXXI32//Ccr "δ��Ȩ!",
    CaptionCWXXI33,          //CWXXI33//Ccr "��ָ���տ�Ա",
    CaptionCWXXI34,          //CWXXI34//Ccr "��ָ��ӪҵԱ",
    CaptionCWXXI35,          //CWXXI35//Ccr "��ֹPLU��ۣ�",
    CaptionCWXXI36,          //CWXXI36//Ccr "���벻��!",
    CaptionCWXXI37,          //CWXXI37//Ccr "������ӡ����",
    CaptionCWXXI38,          //CWXXI38//Ccr "Ʊ�ݴ�ӡ����",
    CaptionCWXXI39,          //CWXXI39//Ccr "��ӡѹ��̧��",
    CaptionCWXXI40,          //CWXXI40//Ccr "��ӡֽ����!",
    CaptionCWXXI41,          //CWXXI41//Ccr "��ӡ�¶�̫��",
    CaptionCWXXI42,          //CWXXI42//Ccr "����δ����!",
    CaptionCWXXI43,          //CWXXI43//Ccr "����������",
    CaptionCWXXI44,          //CWXXI44//Ccr "��ֹ���ָ���",
    CaptionCWXXI45,          //CWXXI45//Ccr "�޴˹���",
    CaptionCWXXI46,          //CWXXI46//Ccr "δ��С�Ƽ�!",
    CaptionCWXXI47,          //CWXXI47//Ccr "���ڹ������",
    CaptionCWXXI48,          //CWXXI48//Ccr "������ˮ��",
    CaptionCWXXI49,          //CWXXI49//Ccr "MODEMͨѶ��!",
    CaptionCWXXI50,          //CWXXI50//Ccr "����������!",
    CaptionCWXXI51,          //CWXXI51//Ccr "POS�����!",
    CaptionCWXXI52,          //CWXXI52//Ccr "�����ݴ�!",
    CaptionCWXXI53,          //CWXXI53//Ccr "Ϊ���ڿ�!",
    CaptionCWXXI54,          //CWXXI54//Ccr "Ϊ��ʧ��!",
    CaptionCWXXI55,          //CWXXI55//Ccr "�ͻ�����!",
    CaptionCWXXI56,          //CWXXI56//Ccr "Ϊ�¿�!",
    CaptionCWXXI57,          //CWXXI57//Ccr "���ǹ��￨!",
    CaptionCWXXI58,          //CWXXI58//Ccr "д������!",
    CaptionCWXXI59,          //CWXXI59//Ccr "���Ų���!",
    CaptionCWXXI60,          //CWXXI60//Ccr "�����ۿۿ�!",
    CaptionCWXXI61,          //CWXXI61//Ccr "�����ֽ�!",
    CaptionCWXXI62,          //CWXXI62//Ccr "�������ʿ�!",
    CaptionCWXXI63,          //CWXXI63//Ccr "����IC��!",
    CaptionCWXXI64,          //CWXXI64//Ccr "�忨����!",
    CaptionCWXXI65,          //CWXXI65//Ccr "�������!",
    CaptionCWXXI66,          //CWXXI66//Ccr "IC��ֵ����!",
    CaptionCWXXI67,          //CWXXI67//Ccr "IC��ʼ������",
    CaptionCWXXI68,          //CWXXI68//Ccr "��ֹ��ʼ��!",
    CaptionCWXXI69,          //CWXXI69//Ccr "IC����!",
    CaptionCWXXI70,          //CWXXI70//Ccr "IC�������!",
    CaptionCWXXI71,          //CWXXT71//Hf "IP��ַ��",
    CaptionCWXXI72,          //CWXXI72//ccr "��Ƶ������!",
    CaptionCWXXI73,          //CWXXI73//Cc "����ʧ��!",
    CaptionCWXXI74,          //CWXXI74>>>>>for fiscal
    CaptionCWXXI75,          //CWXXI75 "PRINT Z-REPORT"
    CaptionCWXXI76,          //CWXXI76 "WRITE FM ERROR"
    CaptionCWXXI77,          //CWXXI77 FM����//
    CaptionCWXXI78,          //CWXXI78 "FM ERROR"
    CaptionCWXXI79,          //CWXXI79 "FISCALIZED"
    CaptionCWXXI80,          //CWXXI80 "Reserved"
    CaptionCWXXI81,          //CWXXI81 "INITIALIZE FM"
    CaptionCWXXI82,          //CWXXI82 FM�е������д�//
    CaptionCWXXI83,          //CWXXI83 "NO EJ"
    CaptionCWXXI84,          //CWXXI84 EJ ��д����//
    CaptionCWXXI85,          //CWXXI85 EJ������//
    CaptionCWXXI86,          //CWXXI86 "FM IS FULL"
    CaptionCWXXI87,          //CWXXI87 EJ����//
    CaptionCWXXI88,          //CWXXI88 "EJ IS FULL"
    CaptionCWXXI89,          //CWXXI89 "MUST FORMAT SD"
    CaptionCWXXI90,          //CWXXI90  "New EJ"
    CaptionCWXXI91,          //CWXXI91 ���200�μӵ��ʼ��//
    CaptionCWXXI92,          //CWXXI92 "CHECKSUM ERROR"
    CaptionCWXXI93,          //CWXXI93 FM ���տ����ƥ��//
    CaptionCWXXI94,          //CWXXI94 "NEW FM"
    CaptionCWXXI95,          //CWXXI95 "PRINT Z-REPORT"
    CaptionCWXXI96,          //CWXXI96 "INNER EJ ERROR"
    CaptionCWXXI97,          //CWXXI97 "INITIALIZE EJ"
    CaptionCWXXI98,          //CWXXI98 EJ���տ����ƥ��//
    CaptionCWXXI99,          //CWXXI99 "STOCK DISABLED"
    CaptionCWXXI100,          //CWXXI100 "INVALID TAX"
    CaptionCWXXI101,          //CWXXI101 ˰��<0
#if (defined(CASE_GPRS) || defined(CASE_ETHERNET))
    CaptionGPRSERR,         //CWXXI102 //GPRS����
    CaptionSENDERR,         //CWXXI103 //�������ݳ���
    CaptionRECVERR,         //CWXXI104 //�������ݳ���
    CaptionNOSERVER,         //CWXXI105 //�޷����ӷ�����
    CaptionIPERROR,         //CWXXI106 //�޷�����IP��ַ
    CaptionNOSIM,         //CWXXI107 //��SIM��
    CaptionGPRSKO,         //CWXXI108 //GPRSδ����
    CaptionLINEOFF,        // (CWXXI108+1) //����δ���
    CaptionTCPERROR,        // (CWXXI109+1) //����ͨѶʧ��
#endif

};
#else

#endif


#if(defined(CASE_GPRS) || defined(CASE_ETHERNET))
CONST FSTRING GPRSMess[G_GPRSMessMax]={
	GPRSstr1,						//G_xDATATYPE 0            ccr"�������ʹ�"
	GPRSstr2,						//G_GPRSOK                 ccr"GPRS READY"
	GPRSstr3,						//G_GPRSNOTOK              ccr"GPRS ����"
	GPRSstr4,						//G_CONFIRM                ccr"��ȷ��"
	GPRSstr5,						//G_SERVERIP_NULL          ccr"������IPΪ��"
	GPRSstr6,						//G_X_IPPORT               ccr"������IP��"
	GPRSstr7,						//G_WAITFOR                ccr"�ȴ�GPRS"
	GPRSstr10,						//G_SHUJUFASONGZHONG       ccr"���ݷ�����.."
	GPRSstr11,						//G_SHUJUYIFACHU           "�����ѷ���.."
	GPRSstr28,                      //G_FASONGCHENGGONG        "���ͳɹ�.."
	GPRSstr31,                      //G_LIANJIESERVERSHIBAI    "���ӷ�����ʧ��"
	GPRSstr32,                      //G_JIESHOUSHIBAI          "����ʧ��"
	GPRSstr34,                      //G_FASONGSHIBAI           "����ʧ��"
	GPRSServerIP,                   //G_SERVERIP
	GPRSServerPort,                 //G_SERVERPORT
	GPRSstr58,                      //G_CONNECTING              "���ڽ�������.."
	GPRSstr59,                      //G_TOCONNECTING            "׼����������.."
	GPRSstr60,                      //G_FUWEIMOKUAI             "���ڸ�λģ��.."
	GPRSstr61                       //G_CHENGGONGTUICHU         "�������,���˳�.."
};
#endif

const char //ccr2017-10-20�ַ�������
    MsgSAVETOSDCARD[]=MSG_SAVETOSDCARD,//"SAVE TO SD?" //ccr2018-04-02
	MsgREMOVEMAC[]=MSG_REMOVEMAC,//"REMOVE MAC-JUMP"
    PWD4Technician[]=PWD4TECHNICIAN,
    MsgREPORTCLEARED[]=MSG_REPORTCLEARED,//"REPORTS CLEARED"
    MsgCOPYRECEIPTEND[]=COPYRECEIPTEND   ,//   "*****COPY RECEIPT-END*****"
    MsgCOPYRECEIPTSTART[]=COPYRECEIPTSTART ,//   "*****COPY RECEIPT-START*****"
    MsgNOTARECEIPT[]=NOTARECEIPT      ,//   "THIS IS NOT A RECEIPT"
    MsgZAFTERPOWERFAIL1[]=ZAFTERPOWERFAIL1 ,//   "POWER FAILURE"
    MsgZAFTERPOWERFAIL2[]=ZAFTERPOWERFAIL2 ,//   "UNSUCCESSFUL ISSUING OF Z"
    MsgCOPYOFLASTZ[]=COPYOFLASTZ      ,//   "COPY OF THE LAST Z DAILY REPORT"
    MsgCOMMENTS[]=MSG_COMMENTS,
    MsgAESKey[]=msg_AESKey,//"AES KEY"
    MsgSendCurrentSFile[]=msg_SendCurrentFile,//"Send S.File?"
    MsgSendSFiles[]=msg_SendSFiles,//"Send All S.Files"
    MsgCUSTOMERCARD[]=SysFlag_CUSTOMERCARD,// "CUSTOMER RECEIPT CARD"
    MsgCLIENTIP[]=msg_CLIENTIP,//    "Client IP"
    MsgSERVERIP[]=msg_SERVERIP,   // "Server IP"
    MsgGATEWAY[]= msg_GATEWAY,    // "GATE WAY"
    MsgIPMASK[]=  msg_IPMASK,    // "IP MASK"

    MsgGPRSAPNNAME[]= GPRSAPNNAME,//       "APN"           //GPRSAPNNAME
    MsgGPRSUSERNAME[]=GPRSUSERNAME,//        "USER NAME"           //GPRSUSERNAME

#if defined(CASE_EURO)
    MsgSaveChanges[]=SAVECHANGES,//"SAVE CHANGES?"
#endif
    MsgBARCODE[]=PLUBARCODE,   //"BAR-CODE"
    MsgNOFMDATA[]=NOFMDATA,  //      "* NO FISCAL DATA  *"
    MsgRECEIPTSTART[]=RECEIPTSTART,
    MsgRECEIPTEND[]=RECEIPTEND,
    MsgTEMPRECEIPTSTART[]=TEMPRECEIPTSTART,//Provisional receipts
    MsgTEMPRECEIPTEND[]=TEMPRECEIPTEND,//Provisional receipts
    MsgCOLLECTION[]=COLLECTION,    //COLLECTION
    MsgSRAMNOTFOUND[]=SRAMNOTFOUND,
    MsgFATERROR[]=FATERROR,
    MsgSPACEOVER[]=SPACEOVER,       //"FILE OVERFLOW!"  // "�ļ��ռ�Խ��",
    MsgSizeOfEJ[]=MessageE53,
    MsgPRESSANYKEY[]= PRESSANYKEY,
    MsgDELZBEFOR60[]=DELZBEFOR60,//     "DEL Z BEFOR 60 ?"  //ccr2017-06-19
    MsgDELZBEFOR60ING[]=DELZBEFOR60ING,//  "DEL Z BEFOR 60D>"  //ccr2017-06-19
    MsgZ60DELETED[]=Z60DELETED,//   "Z DATA DELETED"
    MsgCONTINUEDEL[]=CONTINUEDEL,//  "CONTINUE DEL Z ?"
    MsgEXPLOREZBEGIN[]=EXPLOREZBEGIN,//   "* EXPLORE Z REPORT-START *"
    MsgEXPLOREZEND[]=EXPLOREZEND,   //"* EXPLORE Z REPORT-END *"
    MsgEXPLORERBEGIN[]=EXPLORERBEGIN,   //"* EXPLORE RECEIPT-START *"
    MsgEXPLOREREND[]=EXPLOREREND,   //"* EXPLORE RECEIPT-END *"
    MsgLOGOOnHEAD[]=LOGOOnHEAD,//LOGO ON HEAD
    MsgLOGOOnTRAIL[]=LOGOOnTRAIL;//LOGO ON TRAIL

//////////////////////////////////////////////////////////////
#if defined(DEBUGBYPC)
//#include "exth.h"
extern void PrintRJ(char *);

void printMSG(char *name,char *str,int idx)
{
    static int sIdx;
    char buf[100];

    if (idx==0) sIdx=0;

    sprintf(buf," %3d:%-15s  %s",idx,name,str);
    if (idx!=sIdx)
    {//�������Ƿ�����,������ʱ,˵����Ϣ�����д���
         buf[0]='*';
         sIdx = idx;
    }
    sIdx++;
    PrintRJ(buf);

}

#define prnMSG(a) printMSG(#a,MSG(a),a)

void PrintMsg_Str()
{
    prnMSG(SPACE );    // 0
//----------------setup index definitions------------------------
    prnMSG(SETDEPT);   // 1     /* 1 dept ���뱣��Ϊ1 */
    prnMSG(SETPLU);// (SETDEPT+1)  /* 2 plu */
    prnMSG(SETPLUSTOCK); //SETPLUSTOCK
    prnMSG(SETTAX);// (SETPLU+1)    /* 3 tax */
    prnMSG(SETHEAD);// (SETTAX+1)  /* 4 program header */
    prnMSG(SETDISC);// (SETHEAD+1)  /* 5 disc */

    prnMSG(SETSYSFLAG);// (SETSALER+1)  /* 7 system flags */
    prnMSG(SETGROUP);// (SETGRAP+1)  /* 15 Group */
    prnMSG(SETKEYB);// (SETZONES+1)  /* 26 keyboard code and manager */
    prnMSG(SETDATE);// (SETPORT3+1) /* 12 keyswitch disable */
    prnMSG(SETTIME);// (SETDATE+1)   /* 13 keyswitch disable */
    prnMSG(SETGRAP);// (SETTIME+1)     // 14
    prnMSG(SETPERIPHERALS), //ccr2017-08-04
#if (DD_CHIPC)
    prnMSG(SETIC);// (SETTEND+1)     // 17
#endif
#if (DD_PROMOTION)
    prnMSG(SETPROM);// (SETIC+1)       // 18
#endif
#if (DD_FISPRINTER==0 && DD_DISABLEPBF==0)
    prnMSG(SETPBF);// (SETPROM+1)  /* 19 pb functions */
    prnMSG(SETPBINF);// (SETMODIF+1)   /* 23 keyswitch disable */
#endif
    prnMSG(SETCLERK);// (SETKP+1)  /* 21 clerk */
#if (DD_SETREPORT)
    prnMSG(SETREPTYPE);// (SETKEYB+1)  /* 27 report types */
    prnMSG(SETREPORT);// (SETREPTYPE+1)  // 28
#endif
#if offNumber
    prnMSG(SETOFF);// (SETREPORT+1)   // 29
#endif
    prnMSG(SETTRAIL);// (SETDRAWER+1)   // 32
#if (DD_SETSLIP)
    prnMSG(SETSP);// (SETTRAIL+1)    // 33
    prnMSG(SETSHEAD);// (SETSP+1)      /* 34 slip header */
#endif
#if (DD_CHIPC)
    prnMSG(SETBLOCKIC);// (SETSHEAD+1)/* 35 icblock*/   //ccr chipcard 2004-07-01
#endif
    prnMSG(SETNETWORK);// (SETBLOCKIC+1) /* 36 ����ip��ַ */

#if defined(CASE_GPRS)
    prnMSG(SETGPRSFUNC);// (SETNETWORK+1)       /* 37 GPRS����*/
#else
#endif

#if defined(CASE_ETHERNET)
    prnMSG(SETETHERNETFUNC);// (SETGPRSFUNC+1)       /* 38 ����ͨ�Ź���*/
#else
#endif

    prnMSG(SETAUXFUNCS);// (SETETHERNETFUNC+1) //39//ccr2017-05-10 ��������
      //ccr2017-07-24>>ϣ����Ҫȡ��������>>>>>>>
//    prnMSG(SETSALER);// (SETDISC+1)  /* 6 keyswitch disable */
//    prnMSG(SETCURR);// (SETSYSFLAG+1) /* 8 Curr */
//    prnMSG(SETPORT3);// (SETPORT2+1)    // 11
//    prnMSG(SETTEND);// (SETGROUP+1) /* 16 tend */
//    prnMSG(SETMODIF);// (SETCLERK+1)  /* 22 modifiers */
//    prnMSG(SETCORR);// (SETPBINF+1) /* 24 correc */
//    prnMSG(SETZONES);// (SETCORR+1)  /* 25 zones */
//    prnMSG(SETPORA);// (SETOFF+1)  /* 30 pora */
//    prnMSG(SETDRAWER);// (SETPORA+1)  /* 31 drawer */
      //ccr2017-07-24<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//---------------- end of setup index definitions---------------------


    prnMSG(CWXXI01);// (SETUPMAX+1)                     //="��Ч����!"
    prnMSG(CWXXI02);// (CWXXI01+1)           //="��Ч����!"
    prnMSG(CWXXI03);// (CWXXI02+1)           //="��Чʱ��!"
    prnMSG(CWXXI04);// (CWXXI03+1)           //="��ֹ����!"
    prnMSG(CWXXI05);// (CWXXI04+1)           //="PLU����Ϊ��!"
    prnMSG(CWXXI06);// (CWXXI05+1)           //="PLU�ļ����!"
    prnMSG(CWXXI07);// (CWXXI06+1)           //="��̨��ռ��!"
    prnMSG(CWXXI08);// (CWXXI07+1)           //="��̨�Ѵ�!"
    prnMSG(CWXXI09);// (CWXXI08+1)           //="��̨�Ų���!"
    prnMSG(CWXXI10);// (CWXXI09+1)           //="��������̨��"
    prnMSG(CWXXI11);// (CWXXI10+1)           //="��̨û�п�̨"
    prnMSG(CWXXI12);// (CWXXI11+1)           //="��̨�������"
    prnMSG(CWXXI13);// (CWXXI12+1)           //="��ֹ�޸�ʱ��"
    prnMSG(CWXXI14);// (CWXXI13+1)           //="����������!"
    prnMSG(CWXXI15);// (CWXXI14+1)           //="���ۻ�������"
    prnMSG(CWXXI16);// (CWXXI15+1)           //="��Ʒû���۳�"
    prnMSG(CWXXI17);// (CWXXI16+1)           //="���ڽ�����!"
    prnMSG(CWXXI18);// (CWXXI17+1)           //="�������ݳ���"
    prnMSG(CWXXI19);// (CWXXI18+1)           //="���ڸ���!"
    prnMSG(CWXXI20);// (CWXXI19+1)           //="�������!"
    prnMSG(CWXXI21);// (CWXXI20+1)           //="û��ȷ�Ͻ���"
    prnMSG(CWXXI22);// (CWXXI21+1)           //="��ֹȡ������"
    prnMSG(CWXXI23);// (CWXXI22+1)           //="�޲���!"
    prnMSG(CWXXI24);// (CWXXI23+1)           //="�޴��տ�Ա!"
    prnMSG(CWXXI25);// (CWXXI24+1)           //="�տ�Ա�ı�"
    prnMSG(CWXXI26);// (CWXXI25+1)           //="�޴��౨��!"
    prnMSG(CWXXI27);// (CWXXI26+1)           //="������ӡ�ж�"
    prnMSG(CWXXI28);// (CWXXI27+1)           //="�����ھ�����"
    prnMSG(CWXXI29);// (CWXXI28+1)           //="���ܷ���ʱ��"
    prnMSG(CWXXI30);// (CWXXI29+1)           //="�����������"
    prnMSG(CWXXI31);// (CWXXI30+1)           //="ת�뵽"
    prnMSG(CWXXI32);// (CWXXI31+1)           //="δ��Ȩ!"
    prnMSG(CWXXI33);// (CWXXI32+1)           //="��ָ���տ�Ա"
    prnMSG(CWXXI34);// (CWXXI33+1)           //="��ָ��ӪҵԱ"
    prnMSG(CWXXI35);// (CWXXI34+1)           //="��ֹPLU��ۣ�"
    prnMSG(CWXXI36);// (CWXXI35+1)           //="���벻��!"
    prnMSG(CWXXI37);// (CWXXI36+1)           //="������ӡ����"
    prnMSG(CWXXI38);// (CWXXI37+1)           //="Ʊ�ݴ�ӡ����"
    prnMSG(CWXXI39);// (CWXXI38+1)           //="��ӡѹ��̧��"
    prnMSG(CWXXI40);// (CWXXI39+1)           //="��ӡֽ����!"
    prnMSG(CWXXI41);// (CWXXI40+1)           //="��ӡ�¶�̫��"
    prnMSG(CWXXI42);// (CWXXI41+1)           //="����δ����!"
    prnMSG(CWXXI43);// (CWXXI42+1)           //="����������"
    prnMSG(CWXXI44);// (CWXXI43+1)           //="��ֹ���ָ���"
    prnMSG(CWXXI45);// (CWXXI44+1)           //="�޴˹���"
    prnMSG(CWXXI46);// (CWXXI45+1)           //="δ��С�Ƽ�!"
    prnMSG(CWXXI47);// (CWXXI46+1)           //="���ڹ������"
    prnMSG(CWXXI48);// (CWXXI47+1)           //="������ˮ��"
    prnMSG(CWXXI49);// (CWXXI48+1)           //="MODEMͨѶ��!"
    prnMSG(CWXXI50);// (CWXXI49+1)          //="����������!"
    prnMSG(CWXXI51);// (CWXXI50+1)          //="POS�����!"
    prnMSG(CWXXI52);// (CWXXI51+1)          //="�����ݴ�!"
    prnMSG(CWXXI53);// (CWXXI52+1)          //="Ϊ���ڿ�!"
    prnMSG(CWXXI54);// (CWXXI53+1)          //="Ϊ��ʧ��!"
    prnMSG(CWXXI55);// (CWXXI54+1)          //="�ͻ�����!"
    prnMSG(CWXXI56);// (CWXXI55+1)          //="Ϊ�¿�!"
    prnMSG(CWXXI57);// (CWXXI56+1)          //="���ǹ��￨!"
    prnMSG(CWXXI58);// (CWXXI57+1)          //="д������!"
    prnMSG(CWXXI59);// (CWXXI58+1)          //="���Ų���!"
    prnMSG(CWXXI60);// (CWXXI59+1)          //="�����ۿۿ�!"
    prnMSG(CWXXI61);// (CWXXI60+1)          //="�����ֽ�!"
    prnMSG(CWXXI62);// (CWXXI61+1)          //="�������ʿ�!"
    prnMSG(CWXXI63);// (CWXXI62+1)          //="����IC��!"
    prnMSG(CWXXI64);// (CWXXI63+1)          //="�忨����!"
    prnMSG(CWXXI65);// (CWXXI64+1)          //="�������!"
    prnMSG(CWXXI66);// (CWXXI65+1)          //="IC��ֵ����!"
    prnMSG(CWXXI67);// (CWXXI66+1)          //="IC��ʼ������"
    prnMSG(CWXXI68);// (CWXXI67+1)          //="��ֹ��ʼ��!"
    prnMSG(CWXXI69);// (CWXXI68+1)          //="IC����!"
    prnMSG(CWXXI70);// (CWXXI69+1)          //="IC�������!"
    prnMSG(CWXXI71);// (CWXXI70+1)          //="IP��ַ��"
    prnMSG(CWXXI72);// (CWXXI71+1)             //="��Ƶ������!"
    prnMSG(CWXXI73);// (CWXXI72+1)             //="����ʧ��!"
    prnMSG(CWXXI74);// (CWXXI73+1)             //="NO FISCAL MEMORY"
    prnMSG(CWXXI75);// (CWXXI74+1)             //="PRINT Z-REPORT"
    prnMSG(CWXXI76);// (CWXXI75+1)             //="WRITE FM ERROR"
    prnMSG(CWXXI77);// (CWXXI76+1)             //=FM����//
    prnMSG(CWXXI78);// (CWXXI77+1)             //="FM ERROR"
    prnMSG(CWXXI79);// (CWXXI78+1)             //="FISCALIZED"
    prnMSG(CWXXI80);// (CWXXI79+1)             //="Train Mode"
    prnMSG(CWXXI81);// (CWXXI80+1)             //="INITIALIZE FM"
    prnMSG(CWXXI82);// (CWXXI81+1)             //=FM�е������д�//
    prnMSG(CWXXI83);// (CWXXI82+1)             //="NO EJ"
    prnMSG(CWXXI84);// (CWXXI83+1)             //=EJ ��д����//
    prnMSG(CWXXI85);// (CWXXI84+1)             //=EJ������//
    prnMSG(CWXXI86);// (CWXXI85+1)             //="FM IS FULL"
    prnMSG(CWXXI87);// (CWXXI86+1)             //=EJ����//
    prnMSG(CWXXI88);// (CWXXI87+1)             //="EJ IS FULL"
    prnMSG(CWXXI89);// (CWXXI88+1)             //="MUST FORMAT SD"
    prnMSG(CWXXI90);// (CWXXI89+1)             //="New EJ"
    prnMSG(CWXXI91);// (CWXXI90+1)             //=���200�μӵ��ʼ��//
    prnMSG(CWXXI92);// (CWXXI91+1)             //="CHECKSUM ERROR"
    prnMSG(CWXXI93);// (CWXXI92+1)             //=FM ���տ����ƥ��//
    prnMSG(CWXXI94);// (CWXXI93+1)             //="NEW FM"
    prnMSG(CWXXI95);// (CWXXI94+1)             //="O.Battery Low!"
    prnMSG(CWXXI96);// (CWXXI95+1)             //="INNER EJ ERROR"
    prnMSG(CWXXI97);// (CWXXI96+1)             //="INITIALIZE EJ"
    prnMSG(CWXXI98);// (CWXXI97+1)             //=EJ���տ����ƥ��//
    prnMSG(CWXXI99);// (CWXXI98+1)             //="STOCK DISABLED"
    prnMSG(CWXXI100);// (CWXXI99+1)            //="INVALID TAX"
    prnMSG(CWXXI101);// (CWXXI100+1)   //TAX<0

    prnMSG(CWXXI102);// (CWXXI101+1) //GPRS����
    prnMSG(CWXXI103);// (CWXXI102+1) //�������ݳ���
    prnMSG(CWXXI104);// (CWXXI103+1) //�������ݳ���
    prnMSG(CWXXI105);// (CWXXI104+1) //�޷����ӷ�����
    prnMSG(CWXXI106);// (CWXXI105+1) //�޷�����IP��ַ
    prnMSG(CWXXI107);// (CWXXI106+1) //��SIM��
    prnMSG(CWXXI108);// (CWXXI107+1) //GPRSδ����
    prnMSG(CWXXI109);// (CWXXI108+1) //����δ���
    prnMSG(CWXXI110);// (CWXXI109+1) //����ͨѶʧ��

    //ccr2017-06-16>>>����������SD��������Ϣ>>>
    prnMSG(CWXXI111);           //INNER SD ����//
    prnMSG(CWXXI112);           //������EJ
    prnMSG(CWXXI113);           //�����ʼ��
    //ccr2017-06-16<<<<<<<<<<<<<<<<<<<<<<<<<
    prnMSG(CWXXI114);           //"File Not Found'
    prnMSG(CWXXI115);           //"File Not Found'
    prnMSG(CWXXI116);           //"NOT ACTIVED"
    prnMSG(CWXXI117);           //"OP-Times overflow"
    prnMSG(CWXXI118);           //"MUST RESTART ECR" //ccr2017-09-26

    prnMSG(CWXXI119);           //"URL/DNS NULL" //ccr2017-10-30
    prnMSG(CWXXI120);           //"FAILER ON DNS" //ccr2017-10-30
    prnMSG(CWXXI121);           //"ECR IP NULL" //ccr2017-10-30
    prnMSG(CWXXI122);           //"NO FILE/FOLDER-E"
    prnMSG(CWXXI123);           //"NO FILE/FOLDER-I"
    prnMSG(CWXXI124);           //"CACHE FULL"
    prnMSG(CWXXI125);           //"RATA DUPLICATION"
    prnMSG(CWXXI126);           //""PRINT DISCONNECT"   //ccr2018-04-02

    prnMSG(SETPORT1);
    prnMSG(SETPORT2);
    prnMSG(SETKP);

    prnMSG(KAHAO);//        1
    prnMSG(KLXING);// (KAHAO      +1)
    prnMSG(KNJE);// (KLXING     +1)
    prnMSG(KYJIN);// (KNJE       +1)
    prnMSG(XFZE);// (KYJIN      +1)
    prnMSG(CHZHZE);// (XFZE       +1)
    prnMSG(SHYCSHU);// (CHZHZE     +1)
    prnMSG(JGLBIE);// (SHYCSHU    +1)
    prnMSG(PINMA);// (JGLBIE     +1)
    prnMSG(BHJBIE);// (PINMA      +1)
    prnMSG(ZDJZHANG);// (BHJBIE     +1)
    prnMSG(ZHKRQI);// (ZDJZHANG   +1)
    prnMSG(KYXQI);// (ZHKRQI     +1)
    prnMSG(KHMCHEN);// (KYXQI      +1)
    prnMSG(CHSHHICKA);// (KHMCHEN    +1)
    prnMSG(ICKCHZHI);// (CHSHHICKA  +1)
    prnMSG(QCHICKA);// (ICKCHZHI   +1)
    prnMSG(GUASHIIC);// (QCHICKA   +1)
    prnMSG(ZHEKOUCA);// (GUASHIIC   +1)
    prnMSG(XIANJINKA);// (ZHEKOUCA   +1)
    prnMSG(SHEZHANGKA);// (XIANJINKA   +1)
    prnMSG(XFJIDIAN);// (SHEZHANGKA    +1)

    prnMSG(ZHKLVF);// (XFJIDIAN    +1)

    prnMSG(ICKTKUAN);// (ZHKLVF    +1)
    prnMSG(ICKDJDIANG);// (ICKTKUAN   +1)
    prnMSG(ICKSDIAN);// (ICKDJDIANG +1)
    prnMSG(ZHUOTAI);// (ICKSDIAN +1)

// liuj 0813
    prnMSG(RECNUMFR);// (ZHUOTAI+1)
    prnMSG(RECNUMTO);// (RECNUMFR+1)

    prnMSG(EJCSHUA);// (RECNUMTO+1)
    prnMSG(EJBHAO);// (EJCSHUA+1)
    prnMSG(EJBBIAO);// (EJBHAO+1)
    prnMSG(GRANDTOTAL);// (EJBBIAO+1)

// liuj 0813


#if (defined(FISCAL) || DD_FISPRINTER==1)
//cc 2006-09-19 for Fiscal>>>>>>>>>>>>>>>>>>
    prnMSG(ITEMTAXA);// (GRANDTOTAL+1)
    prnMSG(TAXTOTAL);// (ITEMTAXH+1)
    prnMSG(TOTALZCOUNTER);
    prnMSG(NETSALE);// (TAXTOTAL+1)
    prnMSG(RECNUMBER);// (NETSALE+1)
    prnMSG(FMPULLOUT);// (RECNUMBER+1) //ccr071212
    prnMSG(CHANGEHEAD);// (FMPULLOUT+1)
    prnMSG(CHANGEDATETIME),           //MessageNDATE,        ////"��������ʱ��",

    prnMSG(TAXACHG);// (CHANGEHEAD+1)
    prnMSG(TAXFROM);// (TAXHCHG+1)
    prnMSG(TAXTO);// (TAXFROM+1)
    prnMSG(PRNFISCAL);// (TAXTO+1)
    prnMSG(PRNTOTAL);// (PRNFISCAL+1)
    prnMSG(CLEARTOTAL);// (PRNTOTAL+1)
    prnMSG(MACRESET);// (CLEARTOTAL+1)
    prnMSG(CHANGETAX);//	(MACRESET+1)

//cc 2006-09-19 for Fiscal>>>>>>>>>>>>>>>>>>
//hf 20060919 for fiscal >>>>>>>>>>>>>>>>>>>>>>>>>>>
    prnMSG(SHKZBB);// (CHANGETAX+1)
    prnMSG(TAXCODE);// (SHKZBB+1)
    prnMSG(RIFCODE);// (TAXCODE+1)
    prnMSG(MIANSHUI);// (RIFCODE+1)
    prnMSG(SHUIMUA);// (MIANSHUI+1)
    prnMSG(KHMINGCH);// (SHUIMUA+1)
    prnMSG(JIQIHAO);// (KHMINGCH+1)
    prnMSG(RIQI);// (JIQIHAO+1)
    prnMSG(SHIJIAN);// (RIQI+1)
    prnMSG(XSHZHJI);// (SHIJIAN+1)
    prnMSG(THUOZHJI);// (XSHZHJI+1)
    prnMSG(ZHKOUZHJI);// (THUOZHJI+1)
    prnMSG(XIAOSHOUA);// (ZHKOUZHJI+1)
    prnMSG(NETAFTERTAX); //"NET AFTER TAX"	//"˰�����۶�"		//
    prnMSG(AMTWITHTAX);
    prnMSG(THXIAOSHOU);// (XIAOSHOUA+1)
    prnMSG(ZHKOUXSH);// (THXIAOSHOU+1)
    prnMSG(THZJSHUI);// (ZHKOUXSH+1)
    prnMSG(ZHKZJSHUI);// (THZJSHUI+1)


    prnMSG(EJXINXI);// (ZHKZJSHUI+1)
//hf end <<<<<<<<<<<<<<<<<<<<<<<<<<<<
    prnMSG(EJSHJIAN);// (EJXINXI+1)
    prnMSG(NONFISCAL);// (EJSHJIAN+1)
    prnMSG(SHKCSHUA);// (NONFISCAL+1)
    prnMSG(DATEFROM);// (SHKCSHUA+1)
    prnMSG(DATETO); // (DATEFROM+1)
    prnMSG(TIMEFROM);
    prnMSG(TIMETO);
    prnMSG(ZHJIFPHAO);// (DATETO+1)
    prnMSG(ZHJITHHAO);// (ZHJIFPHAO+1)
    prnMSG(ZHJIFSHHAO);// (ZHJITHHAO+1)
    prnMSG(FAPIAOHAO);// (ZHJIFSHHAO+1)
    prnMSG(DAILYRECEIPTS);
    prnMSG(THUOHAO);// (FAPIAOHAO+1)
    prnMSG(FEISHUIHAO);// (THUOHAO+1)
    prnMSG(SHKBBHAO);// (FEISHUIHAO+1)

    prnMSG(QZHJSHU);// (SHKBBHAO+1)

    prnMSG(REPLEFT);// (QZHJSHU   +1)

    prnMSG(SIZEFM);// (REPLEFT+1)
    prnMSG(SIZEEJ);// (SIZEFM+1)

#else
    prnMSG(SIZEEJ);// (GRANDTOTAL+1)
#endif

    prnMSG(VALUEINIC);// (SIZEEJ   +1)
    prnMSG(LOWBAT);// (VALUEINIC +1)
    prnMSG(CLEARIC);// (LOWBAT  +1)
    prnMSG(CHARGEIC);// (CLEARIC +1)
    prnMSG(ADPOINTS);// (CHARGEIC   +1)
    prnMSG(INITIC);// (ADPOINTS   +1)
    prnMSG(WAITEICCARD);// (INITIC   +1)
    prnMSG(ICCARDOK);// (WAITEICCARD+1) //
//ChipCard<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    prnMSG(ePOSTAC);// (ICCARDOK+1) //ccr epos
    prnMSG(WAITEPOS);// (ePOSTAC+1)//ccr epos
    prnMSG(ePOSCARNO);// (WAITEPOS+1)
    prnMSG(eCARREMAIN);// (ePOSCARNO+1)
    prnMSG(TMHYHAO);// (eCARREMAIN+1)
    prnMSG(BARREPORT);// (TMHYHAO+1)
    prnMSG(XFJE);// (BARREPORT+1)
    prnMSG(ZONGJI);// (XFJE+1)

    prnMSG(WAITING);// (LINK485+1)
    prnMSG(INITWAITING);// (WAITING+1)

    prnMSG(RECEIPTFROM);// (INITWAITING+1)         //    Cc "��ʼ�վݺ�", //
    prnMSG(RECEIPTTO);// (RECEIPTFROM+1)       //    Cc "�����վݺ�", //

    prnMSG(ZNumFORRECEIPT);     //MessageRecZNum,//	"#Z OF RECEIPT"         //"�վݺ�����Z������",	//
    prnMSG(RECEIPTNUMBER);      //MessageRecNum,//	"RECEIPT NUMBER"         //"��ѯ���վݺ�",	//

    prnMSG(SUM_EXC_VAT);// (RECEIPTTO+1)//����˰���۽��
    prnMSG(VAT_AMOUNT);// (SUM_EXC_VAT+1) //˰��
//ccr2017-05-09>>ѡ���տ��ģʽ�˵���>>>>>>>>>>>>>>>>>
    prnMSG(REG_MODE);// (VAT_AMOUNT+1)//MessMODEReg
    prnMSG(X_MODE);// (REG_MODE+1)//MessMODEX
    prnMSG(Z_MODE);// (X_MODE  +1)//MessMODEZ
    prnMSG(SET_MODE);// (Z_MODE  +1)//MessMODESET
#if !defined(CASE_GREECE)//ccr2017-12-14ȥ��������
    prnMSG(MG_MODE);// (SET_MODE+1)//MessMODEMAN
#endif
//>>>>>>>>����X��������>>>>>>>>>
     prnMSG(xDAILYJOURNAL);//"DAILY JOURNAL"
     prnMSG(xDEPARTMENTDAILY );// "DEPARTMENT DAILY"
     prnMSG(xPLUDAILY);//"PLU DAILY"
     prnMSG(xCLERKSDAILY);//"CLERKS DAILY"
#if (salNumber)
     prnMSG(xWAITERSDAILY );//"WAITERS DAILY"
#endif
     prnMSG(xCATEGORY);//"CATEGORY DAILY"
     prnMSG(xALLDAILY);//"ALL DAILY"
     prnMSG(xGENERALPARAM);//"GENERAL PARAMETERS"

//>>>>>>����Z��������>>>>>>>>>>>
     prnMSG(zPRINTZREPORT);//"PRINT Z REPORT"
#if defined(CMD_zHTTPPOSTSFILE)
     prnMSG(zHTTPPOSTSFILE);                // "SEND S-FILES OF Z"
#endif
     prnMSG(zCOPYLASTZ);//"COPY OF LAST Z"
     prnMSG(zDEPTSALES);//"DEPARTMENT SALES"
     prnMSG(zPLUSALES);//"PLU SALES"
     prnMSG(zCLERKSSALES);//"CLERKS  SALES"
#if (salNumber)
     prnMSG(zWAITERSSALES);//"WAITERS  SALES"
#endif
     prnMSG(zZERODEPARTMENT);//"ZERO DEPARTMENT"
     prnMSG(zZEROPLUSALES);//"ZERO PLU SALES"
     prnMSG(zZEROCLERKS);//"ZERO CLERKS"
#if (salNumber)
     prnMSG(zZEROWAITERS);//"ZERO WAITERS"
#endif
     prnMSG(zZEROALLSALES);//"ZERO ALL SALES"
     prnMSG(zFMREADZ_Z);//"FM READ Z-Z"
     prnMSG(zFMREADDATE);// "FM READ DATE"
#if defined(CMD_zFMREADTAXRATE)
     prnMSG(zFMREADTAXRATE);                // "READ TAX RATE "
     prnMSG(zFMREADHEAD);                // "READ HEAD "
     prnMSG(zFMREADSETDATE);                // "READ DATE CHANGED"
#endif
     prnMSG(xLISTPLU);// "PLU LIST"
     prnMSG(xLISTDEPARTMENT);// "DEPARTMENT LIST"
     prnMSG(xLISTCLERK);// "CLERK LIST"

     prnMSG(fmSYNOPSIS);    //"SYNOPSIS"      fmSYNOPSIS    //��������
     prnMSG(fmANALYTICAL);  //"ANALYTICAL"    fmANALYTICAL  //��ϸ����

     prnMSG(EJBYDATETIME);// strEJLOGBYDATE    ,// "EJ BY DATETIME"
     prnMSG(EJBYZNUMBER);//  strEJLOGBYZ_Z     ,// "EJ BY Z NUMBER"

     prnMSG(EJPrintReceipt);//    strRECEIPTPRINT,     //"RECEIPT PRINT"
     prnMSG(EJPrintZRport);//     strZREPORTPRINT,     //"Z REPORT PRINT"

//ccr2017-05-09<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#if (!defined(CASE_GPRS))  // ADD BY LQW 090827
#else
//ccr2014-11-11 NEWSETUP Step-4 �Ӳ˵���Ŀ��Ϣ���>>>>>>>>>>>>>>

    prnMSG(gprsSETMODE);        //
    prnMSG(gprsSendECRLog);     //
    prnMSG(gprsSendECRLogAll);  //
    prnMSG(gprsDownloadPLU);    // "���ص�Ʒ�ļ�"
    prnMSG(gprsDownloadDEPT);   // "���ز����ļ�"
    prnMSG(gprsDownloadCLERK);  // "�����տ�Ա"
    prnMSG(gprsDownloadHEAD);   // "����Ʊͷ"
    prnMSG(gprsDownloadTRAIL);  // "����Ʊβ"
    prnMSG(gprsDownloadALL);    // "����ȫ������"
    prnMSG(gprsRestart);        //  "��λGPRS"
    prnMSG(gprsSENDMESS);       //
#endif

#if (!defined(CASE_ETHERNET))  // ADD BY LQW 090827
#else
//ccr2014-11-11 NEWSETUP Step-4 �Ӳ˵���Ŀ��Ϣ���>>>>>>>>>>>>>>

    prnMSG(net_PINGMESS);// (HZMESSMAX_GPRS)
    prnMSG(net_SETMODE);// (net_PINGMESS+1)
    prnMSG(net_SendECRLog);// (net_SETMODE+1)
    prnMSG(net_SendECRLogAll);// (net_SendECRLog+1)
    prnMSG(net_UpdatePLU);// (net_SendECRLogAll+1) //"���ص�Ʒ�ļ�"
    prnMSG(net_UpdateDEPT);// (net_UpdatePLU+1)     //"���ز����ļ�"
    prnMSG(net_UpdateCLERK);// (net_UpdateDEPT+1) //"�����տ�Ա"
    prnMSG(net_UpdateHEAD);// (net_UpdateCLERK+1) //"����Ʊͷ"
    prnMSG(net_UpdateTRAIL);// (net_UpdateHEAD+1) //"����Ʊβ"
    prnMSG(net_UpdateALL);// (net_UpdateTRAIL+1) //"����ȫ������"
    prnMSG(net_Restart);// (net_UpdateALL+1)//  "��λGPRS"    //net_Restart //ccr2016-08-26

#endif

#if(defined(CASE_ETHERNET)||defined(CASE_GPRS))
    prnMSG(MINISTRYSEND);//   "MINISTRY SEND"
    prnMSG(SERVERURL)    ;
    prnMSG(PERSONALCODE) ;
    prnMSG(GPRSSEND)      ;
    prnMSG(DHCP)          ;//  "DHCP"
    prnMSG(PRIMARYDNS)    ;//  "PRIMARY DNS"
    prnMSG(SECONDARYDNS)  ;//  "SECONDARY DNS"
    prnMSG(PRINTSETTINGS) ;//  "PRINT SETTINGS"
#endif
//ccr2017-05-10 SETAUXFUNCS>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

    prnMSG(AUX_PRINTPLU);// (HZMESSMAX_ETH)      //��ӡ��Ʒ��Ϣ
    prnMSG(AUX_EXPLOREEJ);// (AUX_PRINTPLU    +1)    //��ѯEJ����
    prnMSG(AUX_PRINTFISCAL);// (AUX_READZTOTAL  +1)    //��ӡ������˰����Ϣ
    prnMSG(AUX_PRINTEJ);// (AUX_PRINTFISCAL +1)    //��ӡEJ��Ϣ
    prnMSG(AUX_SETPWDX);// (AUX_PRINTEJ     +1)    //����X��������
    prnMSG(AUX_SETPWDZ);// (AUX_SETPWDX     +1)    //����Z��������
    prnMSG(AUX_SETPWDSET);// (AUX_SETPWDZ     +1)    //����SET��������
    prnMSG(AUX_SETPWDMG);// (AUX_SETPWDSET   +1)    //���þ���MG��������
    prnMSG(AUX_INITFISCAL);// (AUX_SETPWDMG    +1)    //˰�س�ʼ��
    prnMSG(AUX_INITEJ);// (AUX_INITFISCAL  +1)    //��ʼ��EJ
    prnMSG(AUX_PRNGAPHIC);// (AUX_INITEJ      +1)    //��ӡ�տ��ͼ��
    prnMSG(AUX_ECRCONFIG);//  //��ӡ�տ������
//MSg[]<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
}

/////////////////////////////////////////////////////////////////////////

void printDEF(char *name,int idx)
{
    char buf[100];

    sprintf(buf,"%s  =  %d",name,idx);
    PrintRJ(buf);

}

#define prnDEF(a) printDEF(#a,a)

void PrintDefine()
{
        prnDEF(taxNumber);//@4,		// number of tax itemizers:4 for PANAMA
        prnDEF(taxCapSize);//@8,		// caption length max 12
        prnDEF(taxTotalOffSet);//@(taxCapSize+4),		// Start of totalizer in record
        prnDEF(taxRecordSize);//@(taxTotalOffSet+2*13),		// size of 1 tax record
//*************** Definitions Used for Clerk CLERKTABLE *************************
        prnDEF(clrkNumber);//@8,
        prnDEF(clrkCapSize);//@8,		// caption length max 12
        prnDEF(clrkRecordSize);//@(clrkCapSize+1+3),		// size of 1 Clerk record
//*************** Definitions Used for SALPERTABLE *************************
        prnDEF(salNumber);//@50,
        prnDEF(salRecordSize);//@9,		// size of 1 Salesperson record
        prnDEF(salCapSize);//@8,		// caption length max 24
//*************** Definitions Used for Time Zone ZONETABLE *************************
        prnDEF(zoneNumber);//@0,		//ccr2017-05-24 12
//*************** Definitions Used for Day of Week DAYTABLE *************************
        prnDEF(dayNumber);//@7,
//*************** Definitions Used for MONTHTABLE *************************
        prnDEF(monthNumber);//@12,
//***************** Definitions for);//@PORTTABLE ************************
        prnDEF(portNumber);//@2,		// number of PORT
        prnDEF(portCapSize);//@8,		// caption length max 24
        prnDEF(portRecordSize);//@0,		// size of 1 PORTRecord

        prnDEF(portTypeNum);//@7,
        prnDEF(portProNum);//@portTypeNum,		// ccr epos

// ***************** Definitions for);//@OFFTABLE ************************
        prnDEF(offNumber);//@0,		// number of OFF
        prnDEF(offCapSize);//@16,		// caption length max 24
        prnDEF(offPriUSize);//@3,		// Bytes for OFF Price u
        prnDEF(offRecordSize);//@(offCapSize+1+2*4+1+1+offPriUSize+4),		// size of 1 OFF record
// ***************** Definitions for);//@GROUPTABLE ************************
        prnDEF(grpNumber);//@10,		// number of Groups, max 250
        prnDEF(grpCapSize);//@16,		// caption length max 24
        prnDEF(grpTotalOffSet);//@(grpCapSize+2),		// Start of totalizer in record
        prnDEF(grpRecordSize);//@(grpTotalOffSet+2*20),		// size of 1 Group record
// *************** Definitions for);//@for the DEPTTABLE *****************
        prnDEF(depNumber);//@26,		// number of Departments
        prnDEF(depRandomSize);//@0,		// max random size is 7 bytes
        prnDEF(depCapSize);//@22,		// caption length max 24
        prnDEF(depPriceSize);//@4,		// max size is 4
        prnDEF(depPriMaxSize);//@4,		// max size is 4
        prnDEF(depTotalOffSet);//@(depRandomSize+depCapSize+depPriceSize+depPriMaxSize+5+(taxNumber!);//@0)*1),		// Start of totalizer in record
        prnDEF(depRecordSize);//@(depTotalOffSet+2*16),		// size of 1 Department record
// ***************** Definitions for);//@PLUTABLE ************************
        prnDEF(pluNumber);//@10,		// number of Plus
        prnDEF(pluRandomSize);//@7,		// max random size is 7 bytes
        prnDEF(pluCapSize);//@22,		// caption length max 24
        prnDEF(pluLevel);//@1,		// number of price levels, max is 4
        prnDEF(pluPriceSize);//@4,		// max is 10 digits
        prnDEF(pluCost);//@0,
        prnDEF(pluInvSize);//@5,		// number of bytes for inventory
        prnDEF(pluTotalOffSet);//@(pluRandomSize+pluCapSize+(offNumber>0)*2+1+(pluLevel*pluPriceSize)+(pluCost!);//@0)*pluPriceSize+pluInvSize),		// Start of totalizer in record
        prnDEF(pluRecordSize);//@(pluTotalOffSet+14),		// size of 1 PLU record, 8 is the total data size
// ***************** Definitions for);//@TENDTABLE **********
        prnDEF(tendNumber);//@6,		// PANANM:��Ҫ����6(˰�ش洢����));//@number of tendering functions
        prnDEF(tendCapSize);//@8,		// caption length max 12
        prnDEF(tendTotalOffSet);//@(tendCapSize+5),		// Start of totalizer in record
        prnDEF(tendRecordSize);//@(tendTotalOffSet+2*9+(clrkNumber+salNumber)*7*2),		// size of 1 tendering record
// ***************** Definitions for);//@PORATABLE **********
        prnDEF(poraNumber);//@6,		// number of PO & RA functions
        prnDEF(poraCapSize);//@8,		// caption length max 12
        prnDEF(poraTotalOffSet);//@(poraCapSize+4),		// Start of totalizer in record
        prnDEF(poraRecordSize);//@(poraTotalOffSet+2*8+(clrkNumber+salNumber)*6*2),		// size of 1 record
// ***************** Definitions for);//@CORRECTABLE **********
        prnDEF(corrNumber);//@4,		// number of correction functions
        prnDEF(corrCapSize);//@12,		// caption length max 24
        prnDEF(corrTotalOffSet);//@(corrCapSize+2),		// Start of totalizer in record
        prnDEF(corrRecordSize);//@(corrTotalOffSet+2*9+(clrkNumber+salNumber)*9*2),		// size of 1 record
// ***************** Definitions for);//@DISCTABLE **********
        prnDEF(discNumber);//@4,		// number of correction functions
        prnDEF(discCapSize);//@8,		// caption length max 12
        prnDEF(discTotalOffSet);//@(discCapSize+10),		// Start of totalizer in record
        prnDEF(discRecordSize);//@(discTotalOffSet+2*7+(clrkNumber+salNumber)*7*2),		// size of 1 record
// ***************** Definitions for CURRTABLE **********
        prnDEF(currNumber);//@5,		// number of foreign currency
        prnDEF(currCapSize);//@8,		// caption length max 12
        prnDEF(currTotalOffSet);//@(currCapSize+12),		// Start of totalizer in record
        prnDEF(currRecordSize);//@(currTotalOffSet+2*7+(clrkNumber+salNumber)*5*2),		// size of 1 currency record
// ***************** Definitions for PBTABLE **********
        prnDEF(pbNumber);//@12,		// 12 must,);//@number of PB functions
        prnDEF(pbCapSize);//@8,		// caption length max 24
        prnDEF(pbTotalOffSet);//@(pbCapSize+2),		// Start of totalizer in record
        prnDEF(pbRecordSize);//@(pbTotalOffSet+2*6+(clrkNumber+salNumber)*6*2),		// size of 1 PB function record
//***************Definitions for);//@PBTOTAL **********************
        prnDEF(pbNumberOfPb);//@45 // number of PB available
        prnDEF(pbRandom);//@0,		// random number size max 14 digits bit 0 to 3
        prnDEF(pbText);//@8,		// text for each PB# max 24
        prnDEF(pbAmtSize);//@4,		// size of pb amount
        prnDEF(pbtTotalOffset);//@(2+pbRandom+pbText+1+1+1+(pbAmtSize+1)+(pbAmtSize + 1) * 2),		//ccr 2003-10-31
        prnDEF(pbtRecordSize);//@(pbtTotalOffset+7+(clrkNumber+salNumber)*5),		// Record size for PBTable report ccr 2003-10-31
        prnDEF(pbAmtDisc);//@3,		// ccr091224 ����ۿ۽��,pbAmtDisc+pbArtAmt < 8 //
        prnDEF(pbArtAmt);//@3,		// max amount size for art record
        prnDEF(pbQty);//@3,		// max qty for artrecord
        prnDEF(pbArtSize);//@(pbAmtDisc+pbArtAmt+pbQty+1+2),		// ccr091210 size of art record is ArtAmt + Qty + 1 + 2
        prnDEF(pbNumberOfItems);//@10,		// number of items in 1 table record
        prnDEF(pbNumberOfBlocks);//@75,		// number table blocks
        prnDEF(pbBlockSize);//@(pbNumberOfItems * pbArtSize +2) // max 128 bytes
//***************** Definitions for DRAWERTABLE **********
        prnDEF(drawNumber);//@8,		// number of tendering functions
        prnDEF(drawCapSize);//@8,		// caption length max 24
        prnDEF(drawTotalOffSet);//@(drawCapSize+2),		// Start of totalizer in record
        prnDEF(drawRecordSize);//@(drawTotalOffSet+2*7+(clrkNumber+salNumber)*7*2),		// size of 1 Drawer record
//*************** Definitions for MODITABLE *************************
        prnDEF(modiNumber);//@20,
        prnDEF(modiCapSize);//@16,		// caption length max 24
//******************** Definitions for);//@TOTALSALES*********************
        prnDEF(totalRecordSize);//@(2*12+zoneNumber*9+(clrkNumber+salNumber)*7*2),		// size of TOTAL SALES record
//***************** Definitions for AGREETABLE **********
        prnDEF(agreeNumber);//@1,		// number of foreign currency
        prnDEF(agreeCapSize);//@12,		// caption length max 25
        prnDEF(agreeTotalOffSet);//@(agreeCapSize+20+18));//@
        prnDEF(agreeRecordSize);//@(agreeTotalOffSet+4),		// size of 1 currency record
//***************** Definitions for ICBLOCKTABLE **********,		//ccr chipcard 2004-07-01
        prnDEF(icblockNumber);//@1,
        prnDEF(icblockSize);//@4,
}

#endif

