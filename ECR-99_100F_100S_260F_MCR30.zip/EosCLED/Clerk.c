#define CLERK_C 5
#include "debug.h"
#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
#include "flowbill.h"  //lyq2003
#include "message.h"
#if (PC_EMUKEY==1)
#include "FEcrTest.h"
#endif

/****************************************************************/


void GetClerkOffSet()
{
    RamOffSet = (ApplVar.ClerkNumber - 1) * ApplVar.AP.Clerk.RecordSize + ApplVar.AP.StartAddress[AddrClerk];
}

void WriteClerk()
{
    if (ApplVar.ClerkNumber <= ApplVar.AP.Clerk.Number)
    {
		GetClerkOffSet();
		WriteRam(ApplVar.Clerk.Name, ApplVar.AP.Clerk.CapSize);
		WriteRam(&ApplVar.Clerk.Options, sizeof(ApplVar.Clerk.Options));
	    WriteRam(ApplVar.Clerk.Passwd,sizeof(ApplVar.Clerk.Passwd));
    }
}

void ReadClerk()
{
    if (!ApplVar.ClerkNumber || ApplVar.ClerkNumber > ApplVar.AP.Clerk.Number)
    		ApplVar.ClerkNumber = 1;

    GetClerkOffSet();
    ReadRam(ApplVar.Clerk.Name, ApplVar.AP.Clerk.CapSize);
    ApplVar.Clerk.Name[ApplVar.AP.Clerk.CapSize] = 0 ;
    ReadRam(&ApplVar.Clerk.Options, sizeof(ApplVar.Clerk.Options));
    ReadRam(ApplVar.Clerk.Passwd,sizeof(ApplVar.Clerk.Passwd));
#if defined(CASE_GREECE)//ccr2018-03-20 ��ֹ�տ�Ա��ѵģʽ
    SETBIT(ApplVar.Clerk.Options, BIT7);
#endif

}
//�����տ�Ա��˰��״̬,�趨��ѵģʽ״̬
void SetTrainMode()
{
#if defined(CASE_GREECE)//ccr2018-03-20 ��ֹ�տ�Ա��ѵģʽ
    ApplVar.FTrain = 0;	/* ����ѵģʽ */
#else
    if (!BIT(ApplVar.Clerk.Options, BIT7))	/* training clerk ? */
    {
#if (DISP2LINES)
        Puts1_Right(Msg[TRAINMODE].str);
#else
        PutsO_At('T',DISLEN-1);
#endif
        ApplVar.FTrain = 1;	  /* ��ѵģʽ��־ */
    }
    else
    {
        ApplVar.FTrain = 0;	/* ����ѵģʽ */
    }
#endif
}
/***************************************************************************************
 * ��¼���տ�Ա:
 * 1.������ѵģʽ��Ϊ����ѵģʽʱ,�Զ����屨��
 * 2.���ɷ���ѵģʽ��Ϊ��ѵģʽʱ,�����ӡZ����
 *
 * @author EutronSoftware (2017-04-21)
 *
 * @param lock
 ***************************************************************************************/
void SelectClerk(BYTE lock)
{
    WORD newclerk;
    short sSave;
    char cPass[7];

	if (ApplVar.CentralLock != RG && ApplVar.CentralLock != MG)
	{
		ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
		return;
	}

    newclerk = 0;
	if (ApplVar.Key.Code == CLERK)
	{
		if (!Appl_EntryCounter)
		{
#if PC_EMUKEY
			if(FisTestTask.PrnOFF)	 //    ccr080519 added for control the printing of pb message
			{
				FisTestTask.PrnOFF = 0;
				PutsO(MessageE49);
			}
			else
			{
				FisTestTask.PrnOFF = 1;
				PutsO(MessageE50);
			}
#endif
			return;
		}
		else if (Appl_NumberEntry < (OFFER-CLERK))
			newclerk = Appl_NumberEntry;
	}
	else if (!Appl_EntryCounter)
	{
		newclerk = ApplVar.Key.Code - CLERK;
		ApplVar.Entry = ZERO;
		WORDtoBCD(ApplVar.Entry.Value, newclerk);
	}
	if (newclerk > ApplVar.AP.Clerk.Number)
	{
	    ApplVar.ErrorNumber=ERROR_ID(CWXXI24);
		return;
	}


	if (ApplVar.FRegi)    /* still in regi and train no change clerk */
    {
	    if ((ApplVar.FPb && BIT(CLERKFIX, BIT1)) ||
		    BIT(CLERKFIX, BIT2) || ApplVar.FTrain || !newclerk)
	    {
		    ApplVar.ErrorNumber=ERROR_ID(CWXXI14);	/* still in registration */
			return;
		}
	}
//ccr090508	if (!lock)
	{
		if (!newclerk)
		{									   //lyq 20040227 added start
	      	ApplVar.ClerkNumber = 0;
			PutsO((char*)Prompt.Message[59]);
			return;
		}
		if(BIT(CLERKFIX, BIT5))		/* secret code ? */
		{/* ��ҪУ������ */
			sSave = ApplVar.ClerkNumber;
			ApplVar.ClerkNumber = newclerk;
			ReadClerk();
			ApplVar.ClerkNumber = sSave;
			HEXtoASC(cPass,ApplVar.Clerk.Passwd,3);
			cPass[6] = 0;
			if (!CheckPWD(cPass))
			{//ccr090508 �����д�ʱ,�������տ�Ա //
               ReadClerk();
				ApplVar.ErrorNumber=ERROR_ID(CWXXI36);
				return;
			}
		}
	}


//ccr090508>>>>>>>>>>>>>>>>>>
#if(defined(FISCAL))

	sSave = ApplVar.ClerkNumber;
	ApplVar.ClerkNumber = newclerk;
	ReadClerk();
	ApplVar.ClerkNumber = sSave;

	CWORD(cPass[0]) = CWORD(ApplVar.Entry.Value[0]);//save ApplVar.Entry.
	if(BIT(ApplVar.Clerk.Options,BIT7) && ApplVar.FTrain)
	{// ������ѵģʽ��Ϊ����ѵģʽʱ,�Զ����屨�� //
		 ClearAllReport();
#ifdef CASE_FATFS_EJ
         strcpy(SDRW_Buffer,"1:/TRAIN");
#if defined(TWO_SDCARDS)
         ff_SelectSDisk(FS_SD_2ND);
         ff_DeleteTree(SDRW_Buffer);
         ff_SelectSDisk(FS_SD);
#endif
         ff_DeleteTree(SDRW_Buffer);
#endif
	}
	else if(!BIT(ApplVar.Clerk.Options,BIT7))
	{/* Ϊ��ѵ�տ�Ա */
		if(!ApplVar.FTrain && MyFlags(ZREPORT))
		{// ���ɷ���ѵģʽ��Ϊ��ѵģʽʱ,�����ӡZ���� //
			ReadClerk();
			ApplVar.ErrorNumber=ERROR_ID(CWXXI75);
			return;
		}
		else/* ���µ���ѵ�տ�Ա��¼ʱ,�Զ����屨�� */
			ClearAllReport();
	}

	CWORD(ApplVar.Entry.Value[0]) = CWORD(cPass[0]);

#endif
//<<<<<<<<<<<<<

    if (ApplVar.RGRec.Key.Code < CLERK || ApplVar.RGRec.Key.Code >=OFFER)
		StoreInBuffer();
    ApplVar.RGRec.Key.Code = CLERK + newclerk;	/* store in buffer for correct CC update */

    ApplVar.ClerkNumber = newclerk;
	ReadClerk();
    SetTrainMode();
#if(CASE_RAMBILL)
	Collect_Data(OPERLOG);		  	 //    lyq2003
#endif
   	PutsO(DispQtyStr(DText[DTEXT_OPERATOR], &ApplVar.Entry,DISLEN));

#if (DISP2LINES)
    Puts1(Msg[SPACE].str);
#endif

}

/***********************************************
 * ��ӡȫ���տ�Ա����
 *
 * @author EutronSoftware (2017-06-02)
 *********************************************/
void PrintAllOfClerk()
{
    WORD pClerkNum=ApplVar.ClerkNumber;
    int l;

    if (ApplVar.AP.Clerk.Number)
    {
        SETBIT(ApplVar.PrintLayOut, BIT2);
        PrintStr_Center(MessageCLERK,true);
        RESETBIT(ApplVar.PrintLayOut, BIT2);
        PrintLine('=');

        for (ApplVar.ClerkNumber = 1; ApplVar.ClerkNumber <= ApplVar.AP.Clerk.Number; ApplVar.ClerkNumber++)
        {
            ReadClerk();

            //#001 Depart-Name       123.45
            memset(SysBuf,' ',PRTLEN);
            ULongtoASCZER0(SysBuf+4,ApplVar.ClerkNumber,4);
            SysBuf[0]='#';
            l=strlen(ApplVar.Clerk.Name);
            memcpy(SysBuf+PRTLEN-l-10,ApplVar.Clerk.Name,l);
            if(!BIT(ApplVar.Clerk.Options,BIT7))
                strcpy(SysBuf+PRTLEN-8,"[TRAIN]");
            SysBuf[PRTLEN] = 0;
            RJPrint(0,SysBuf);
        }
        PrintLine('=');
        ApplVar.BufKp = 0;
        CutRPaper(2);RFeed(4);//ccr070612
        ApplVar.ClerkNumber = pClerkNum;
        ReadClerk();
    }
}
