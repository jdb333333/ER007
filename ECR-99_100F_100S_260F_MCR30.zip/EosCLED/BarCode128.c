#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
#include "print.h"


#define bar128_ID_MAX 107
const BYTE bar128_dotsLib[bar128_ID_MAX][2] = {
	{0xD9, 0x80},  // ' '
	{0xCD, 0x80},  // '!'
	{0xCC, 0xC0},  // '"'
	{0x93, 0x00},  // '#'
	{0x91, 0x80},  // '$'
	{0x89, 0x80},  // '%'
	{0x99, 0x00},  // '&'
	{0x98, 0x80},  // '''
	{0x8C, 0x80},  // '('
	{0xC9, 0x00},  // ')'
	{0xC8, 0x80},  // '*'
	{0xC4, 0x80},  // '+'
	{0xB3, 0x80},  // ','
	{0x9B, 0x80},  // '-'
	{0x99, 0xC0},  // '.'
	{0xB9, 0x80},  // '/'
	{0x9D, 0x80},  // '0'
	{0x9C, 0xC0},  // '1'
	{0xCE, 0x40},  // '2'
	{0xCB, 0x80},  // '3'
	{0xC9, 0xC0},  // '4'
	{0xDC, 0x80},  // '5'
	{0xCE, 0x80},  // '6'
	{0xED, 0xC0},  // '7'
	{0xE9, 0x80},  // '8'
	{0xE5, 0x80},  // '9'
	{0xE4, 0xC0},  // ':'
	{0xEC, 0x80},  // ';'
	{0xE6, 0x80},  // '<'
	{0xE6, 0x40},  // '='
	{0xDB, 0x00},  // '>'
	{0xD8, 0xC0},  // '?'
	{0xC6, 0xC0},  // '@'
	{0xA3, 0x00},  // 'A'
	{0x8B, 0x00},  // 'B'
	{0x88, 0xC0},  // 'C'
	{0xB1, 0x00},  // 'D'
	{0x8D, 0x00},  // 'E'
	{0x8C, 0x40},  // 'F'
	{0xD1, 0x00},  // 'G'
	{0xC5, 0x00},  // 'H'
	{0xC4, 0x40},  // 'I'
	{0xB7, 0x00},  // 'J'
	{0xB1, 0xC0},  // 'K'
	{0x8D, 0xC0},  // 'L'
	{0xBB, 0x00},  // 'M'
	{0xB8, 0xC0},  // 'N'
	{0x8E, 0xC0},  // 'O'
	{0xEE, 0xC0},  // 'P'
	{0xD1, 0xC0},  // 'Q'
	{0xC5, 0xC0},  // 'R'
	{0xDD, 0x00},  // 'S'
	{0xDC, 0x40},  // 'T'
	{0xDD, 0xC0},  // 'U'
	{0xEB, 0x00},  // 'V'
	{0xE8, 0xC0},  // 'W'
	{0xE2, 0xC0},  // 'X'
	{0xED, 0x00},  // 'Y'
	{0xEC, 0x40},  // 'Z'
	{0xE3, 0x40},  // '['
	{0xEF, 0x40},  // '\'
	{0xC8, 0x40},  // ']'
	{0xF1, 0x40},  // '^'
	{0xA6, 0x00},  // '_'
	{0xA1, 0x80},  // '`'
	{0x96, 0x00},  // 'a'
	{0x90, 0xC0},  // 'b'
	{0x85, 0x80},  // 'c'
	{0x84, 0xC0},  // 'd'
	{0xB2, 0x00},  // 'e'
	{0xB0, 0x80},  // 'f'
	{0x9A, 0x00},  // 'g'
	{0x98, 0x40},  // 'h'
	{0x86, 0x80},  // 'i'
	{0x86, 0x40},  // 'j'
	{0xC2, 0x40},  // 'k'
	{0xCA, 0x00},  // 'l'
	{0xF7, 0x40},  // 'm'
	{0xC2, 0x80},  // 'n'
	{0x8F, 0x40},  // 'o'
	{0xA7, 0x80},  // 'p'
	{0x97, 0x80},  // 'q'
	{0x93, 0xC0},  // 'r'
	{0xBC, 0x80},  // 's'
	{0x9E, 0x80},  // 't'
	{0x9E, 0x40},  // 'u'
	{0xF4, 0x80},  // 'v'
	{0xF2, 0x80},  // 'w'
	{0xF2, 0x40},  // 'x'
	{0xDB, 0xC0},  // 'y'
	{0xDE, 0xC0},  // 'z'
	{0xF6, 0xC0},  // '{'
	{0xAF, 0x00},  // '|'
	{0xA3, 0xC0},  // '}'
	{0x8B, 0xC0},  // '~'
	{0xBD, 0x00},  // 'DEL'
	{0xBC, 0x40},  // 'FNC3'
	{0xF5, 0x00},  // 'FNC2'
	{0xF4, 0x40},  // 'SHIFT'
	{0xBB, 0xC0},  // 'C'
	{0xBD, 0xC0},  // 'FNC4'
	{0xEB, 0xC0},  // 'A'
	{0xF5, 0xC0},  // 'FNC1'
	{0xD0, 0x80},  // 'STARTA'
	{0xD2, 0x00},  // 'STARTB'
	{0xD3, 0x80},  // 'STARTC'
	{0xC7, 0x58},  // 'STOP' //13dot
};

#define barNum_MAX  52 //(576/11=52.3)
BYTE barLine[barNum_MAX];

static BYTE barLine_codeCnt, barLine_byteCnt;
static BYTE bar_DotsH, bar_DotsL;

#define BARCODE_START_B 104
#define BARCODE_START_C 105
#define BARCODE_STOP 	106
#define BARCODE_CODEC 	99
#define BARCODE_CODEB 	100

void barLine_Add(BYTE bar_ID)
{
	bar_DotsH = bar128_dotsLib[bar_ID][0];
	bar_DotsL = bar128_dotsLib[bar_ID][1];

	switch(barLine_codeCnt++ % 8)
	{
		case 0:
			barLine[barLine_byteCnt++]= bar_DotsH;
			barLine[barLine_byteCnt  ]= bar_DotsL;
			break;
		case 3: //1:
			barLine[barLine_byteCnt++]|= bar_DotsH>>1;
			barLine[barLine_byteCnt  ] =(bar_DotsL>>1) + (bar_DotsH<<7);
			//barLine[++barLine_byteCnt  ] =              bar_DotsL<<7;
			break;
		case 6: //2:
			barLine[barLine_byteCnt++]|= bar_DotsH>>2;
			barLine[barLine_byteCnt  ] =(bar_DotsL>>2) + (bar_DotsH<<6);
			//barLine[barLine_byteCnt  ] =                bar_DotsL<<6;
			break;
		case 1: //3:
			barLine[barLine_byteCnt++]|= bar_DotsH>>3;
			barLine[barLine_byteCnt  ] =(bar_DotsL>>3) + (bar_DotsH<<5);
			//barLine[barLine_byteCnt  ] =                bar_DotsL<<5;
			break;
		case 4:
			barLine[barLine_byteCnt++]|= bar_DotsH>>4;
			barLine[barLine_byteCnt  ] =(bar_DotsL>>4) + (bar_DotsH<<4);
			if(BARCODE_STOP == bar_ID)
				barLine[++barLine_byteCnt] =              bar_DotsL<<4;
			break;
		case 7: //5:
			barLine[barLine_byteCnt++]|= bar_DotsH>>5;
			barLine[barLine_byteCnt++] =(bar_DotsL>>5) + (bar_DotsH<<3);
			if(BARCODE_STOP == bar_ID)
				barLine[barLine_byteCnt] =                bar_DotsL<<3;
			break;
		case 2: //6:
			barLine[barLine_byteCnt++]|= bar_DotsH>>6;
			barLine[barLine_byteCnt++] =(bar_DotsL>>6) + (bar_DotsH<<2);
			barLine[barLine_byteCnt  ] =                  bar_DotsL<<2;
			break;
		case 5: //7:
			barLine[barLine_byteCnt++]|= bar_DotsH>>7;
			barLine[barLine_byteCnt++] =(bar_DotsL>>7) + (bar_DotsH<<1);
			barLine[barLine_byteCnt  ] =                  bar_DotsL<<1;
			break;
	}

}

BYTE barLine_Creat(BYTE *ASCIIstring, BYTE Length)
{
	BYTE i, bar_ID, checkBit_ID, tem;
	unsigned int SUM;
	BYTE N_cnt, N_pos;
	BYTE fCode[barNum_MAX];

	if(Length>barNum_MAX-4) //��ʼλ �� ��FNC1(ΪEAN128��ʱ��)�� �� ����λ �� ����λ �� ����λ
		return 0;

	//��ʼ��
	memset(barLine,0,sizeof(barLine));

    barLine_codeCnt=0;
	barLine_byteCnt=0;

	//�������������
	for(i=0; i<Length; i++)
	{
		tem=ASCIIstring[i];
		if('0'<=tem && tem<='9')
		{
			//��һ������
			N_pos=i;
			fCode[N_pos]=1;
			N_cnt=1;
			//�������������
			for(i++; i<Length; i++)
			{
				tem=ASCIIstring[i];
				if('0'<=tem && tem<='9'){
					fCode[i]=1;
					N_cnt++;
				}
				else {
					fCode[i]=0;
					break;
				}
			}
			//����������,���ַ�����
			if(N_cnt%2 == 1)
				fCode[N_pos]=0;
		}
		else
		{
			fCode[i]=0;
		}
	}

	/*��ʼλ �������� StartB*/
	if(fCode[0])
	{
		SUM=BARCODE_START_C;
		barLine_Add(BARCODE_START_C);
	}
	else
	{
		SUM=BARCODE_START_B;
		barLine_Add(BARCODE_START_B);
	}


	/*�������� codeB*/
	for(i=0; i<Length; )
	{
		if(fCode[i]) //���� ����ż����
		{
			if(i){
				SUM+=(unsigned int)BARCODE_CODEC * (unsigned int)barLine_codeCnt;
				barLine_Add(BARCODE_CODEC);
			}
			while(i<Length && fCode[i])
			{
				bar_ID=(ASCIIstring[i]&0x0F)*10 + (ASCIIstring[i+1]&0x0F);
				SUM += (unsigned int)bar_ID * (unsigned int)barLine_codeCnt;
				barLine_Add(bar_ID);
				i+=2;
			}
		}
		else //�ַ�
		{
			if(i){
				SUM+=(unsigned int)BARCODE_CODEB * (unsigned int)barLine_codeCnt;;
				barLine_Add(BARCODE_CODEB);
			}
			while(i<Length && !fCode[i])
			{
				bar_ID = ASCIIstring[i] - ' ';
				SUM += (unsigned int)bar_ID * (unsigned int)barLine_codeCnt;
				barLine_Add(bar_ID);
				i++;
			}
		}

	}

	/*У��λ*/
	checkBit_ID=(BYTE)(SUM%103);
	barLine_Add(checkBit_ID);

	/*����λ*/
	barLine_Add(BARCODE_STOP);

	return ++barLine_byteCnt;
}

///////////////////////////////////////////////////////////////////////////
/*  ��ӡһ�������ͼ��  *********************************
* _______LineBytes(ÿ���ֽ���)________
 /                                    \
*--------------------------------------\
*-------------------------------------- |
*-------------------------------------- |BARHIGH (����)
*-------------------------------------- |
*--------------------------------------/
**********************************************************/
#if (1)
void CreateBarcodeImage(BYTE *barcode_data, BYTE len)
{
#if BARCODESIZE

    ULONG	LineByte,i;

    {
        //���ɵ�������
        LineByte=barLine_Creat(barcode_data, len);

//        TotBytes = LineByte * BARIMGHIGH;// ���ֽ���=һ���ֽ���*���� //
//        while (TotBytes>BARCODESIZE) TotBytes-=LineByte;//ccr2018-01-26

        if (LineByte && LineByte<BYTES_OF_PAPER_LINE)
        {

            InfoBarCode_Graph.cGrapCols = LineByte;
            InfoBarCode_Graph.cLabels = 0;
            InfoBarCode_Graph.cPrintAt = 10;
            InfoBarCode_Graph.cWidthAChar = 8;
            InfoBarCode_Graph.cHighAChar = 24;
            InfoBarCode_Graph.cByteALine = 0;

            InfoBarCode_Graph.cGrapSize=0;
            memset(BarCode_Graph,0,BARCODESIZE);
            for (i=0;i<BARIMGHIGH && (InfoBarCode_Graph.cGrapSize+LineByte)<BARCODESIZE;i++)//ccr2018-01-26
            {
                memcpy(&BarCode_Graph[InfoBarCode_Graph.cGrapSize],barLine,LineByte);
                InfoBarCode_Graph.cGrapSize+=LineByte;
            }
        }
    }
#endif

}

void PrintBarcodeImage(BYTE *barcode_data, BYTE len)
{
#if BARCODESIZE
    char barBuf[PRTLEN];

    if (len && !MyFlags( CLOSEPRINT))
    {
        //���ɵ�������
        if (len>PRTLEN-3)
            len=PRTLEN-3;
        barBuf[0] = BARCODE_GRP_ID;//ccr2017-08-09 �˱��ר��������ӡ�����ͼƬ
        barBuf[1] = '0';//�޵��ӵ��ı�
        barBuf[2] = 0;  //ʹ��ͼƬ�Զ���λ�ô�ӡ
        memcpy(barBuf+3,barcode_data,len);
        RSPrint(barBuf,len+3,PRN_GRAPHIC_Mode);
    }
#endif

}

#else//ccr2018-02-01

void CreateBarcodeImage(BYTE *barcode_data, BYTE len)
{
}

void PrintBarcodeImage(BYTE *barcode_data, BYTE len)
{
#if BARCODESIZE

#define BarCode_Graph Self_Graph
#define InfoBarCode_Graph InfoSelf_Graph

    char barBuf[3];
    WORD	LineByte,TotBytes,i;
    BYTE xl;

    if (!MyFlags( CLOSEPRINT))
    {
        //���ɵ�������
        LineByte=barLine_Creat(barcode_data, len);

        TotBytes = LineByte * BARIMGHIGH;// ���ֽ���=һ���ֽ���*���� //

        if (LineByte && (TotBytes<SELFGRASIZE && LineByte<BYTES_OF_PAPER_LINE))
        {

            InfoBarCode_Graph.cGrapCols = LineByte;
            InfoBarCode_Graph.cLabels = 0;
            InfoBarCode_Graph.cPrintAt = 10;
            InfoBarCode_Graph.cWidthAChar = 8;
            InfoBarCode_Graph.cHighAChar = 24;
            InfoBarCode_Graph.cByteALine = 0;
            InfoBarCode_Graph.cGrapSize = TotBytes;

            TotBytes=0;
            memset(BarCode_Graph,0,sizeof(BarCode_Graph));
            for (i=0;i<BARIMGHIGH;i++)
            {
                memcpy(&BarCode_Graph[TotBytes],barLine,LineByte);
                TotBytes+=LineByte;
            }

            barBuf[0] = BARCODE_GRP_ID+1;//ccr2017-08-09 �˱��ר��������ӡ�����ͼƬ
            barBuf[1] = '0';

            RSPrint(barBuf,2,PRN_GRAPHIC_Mode);
        }
        else
            RJPrint(0,"  **** BARCODE IMAGE ERROR ****");
    }
#endif

}
#endif
