#ifndef _SDDISK_UTILITIES_H
#define _SDDISK_UTILITIES_H
#include "stdint.h"
//..................................................................
//ONLY_1SD:ֻ��һ���⿨�����ڿ�
//..................................................................
#define _MAX_PATH   64      //�ļ�·�����Ʋ�������
#define FOLDERSIZE  4    //�����ļ�����Ҫռ�õĿռ�(4096Bytes)

#define FS_RELEASE  0xff    //�ͷ�FatFS,��ִ��f_mount(,NULL)
#define FS_MOUNT    0xfe    //����FatFS,��ִ��f_mount(,FS_SD)

#define FS_BINARY    0      //�����������ļ���ʽ��ȡ����
#define FS_TEXT      1      //TEXT�ļ���ʽ��ȡ���ݣ����޳�'\r\n'

#define FS_SD       1   //FS_SD���⿨SD�豸��
#define _VOLUMES    3

#if defined(TWO_SDCARDS)
#define FS_SD_2ND  2   //�ڲ�SD���豸��//ccr2017-06-05
#define FS_NAND		2
#endif


#ifdef DEBUGBYPC

#define _MAX_LFN    32

/* File access control and file status flags (FIL.flag) */
#define FA_TEXT			    0x80    //ccr2017-11-17����TEXT��ʽ���ļ���ΪDEBUGBYPC)

#define	FA_OPEN_EXISTING	0x00//Opens the file. The function fails if the file is not existing. (Default)
#define	FA_READ				0x01//Specifies read access to the object.
                                //Data can be read from the file. Combine with FA_WRITE for read-write access.
#define	FA_WRITE			0x02//Specifies write access to the object. Data can be written to the file.
                                //Combine with FA_READ for read-write access.
#define	FA_CREATE_NEW		0x04//Creates a new file. The function fails with FR_EXIST if the file is existing.
#define	FA_CREATE_ALWAYS	0x08//Creates a new file. If the file is existing, it is truncated and overwritten.
#define	FA_OPEN_ALWAYS		0x10//Opens the file if it is existing. If not, a new file is created.
                                //To append data to the file, use f_lseek() function after file open in this method.
#define FA__WRITTEN			0x20//
#define FA__DIRTY			0x40//
#define FA__ERROR			0x80//

/* File function return code (FRESULT) */
typedef enum {
	FR_OK = 0,				/* (0) Succeeded */
	FR_DISK_ERR,			/* (1) A hard error occurred in the low level disk I/O layer */
	FR_INT_ERR,				/* (2) Assertion failed */
	FR_NOT_READY,			/* (3) The physical drive cannot work */
	FR_NO_FILE,				/* (4) Could not find the file */
	FR_NO_PATH,				/* (5) Could not find the path */
	FR_INVALID_NAME,		/* (6) The path name format is invalid */
	FR_DENIED,				/* (7) Access denied due to prohibited access or directory full */
	FR_EXIST,				/* (8) Access denied due to prohibited access */
	FR_INVALID_OBJECT,		/* (9) The file/directory object is invalid */
	FR_WRITE_PROTECTED,		/* (10) The physical drive is write protected */
	FR_INVALID_DRIVE,		/* (11) The logical drive number is invalid */
	FR_NOT_ENABLED,			/* (12) The volume has no work area */
	FR_NO_FILESYSTEM,		/* (13) There is no valid FAT volume */
	FR_MKFS_ABORTED,		/* (14) The f_mkfs() aborted due to any parameter error */
	FR_TIMEOUT,				/* (15) Could not get a grant to access the volume within defined period */
	FR_LOCKED,				/* (16) The operation is rejected according to the file sharing policy */
	FR_NOT_ENOUGH_CORE,		/* (17) LFN working buffer could not be allocated */
	FR_TOO_MANY_OPEN_FILES,	/* (18) Number of open files > _FS_SHARE */
	FR_INVALID_PARAMETER	/* (19) Given parameter is invalid */
} FRESULT;

//..................................................................
typedef struct {
    DWORD Folders;      //��ű����ļ��е��ļ�����Ŀ
    DWORD Files;        //��ű����ļ��е��ļ���Ŀ
    DWORD SpaceTotal;   //SD���ܿռ�(KB)
    DWORD SpaceFree;    //SD��ʣ��ռ�(KB)
    DWORD FilesSpace;    //ȫ���ļ���ռ�ռ�
    FILE  *File;         //�򿪵��ļ�
    BYTE  FS_Myself;    //�ļ�ϵͳ(FS_SD/FS_SD_INTR)
    BYTE  ManufacturerID;       /*!< ManufacturerID */
    WORD  OEM_AppliID;          /*!< OEM/Application ID */
    DWORD ProdSN;               /*!< Product Serial Number */
    //char  FileName[_MAX_PATH];//���浱ǰ������EJ�ļ�����(���ļ��к��ļ���)
} TSDISK;


/**
  * @brief  Card Specific Data: CSD Register
  */
typedef struct
{
  uint8_t  CSDStruct;            /*!< CSD structure */
  uint8_t  SysSpecVersion;       /*!< System specification version */
  uint8_t  Reserved1;            /*!< Reserved */
  uint8_t  TAAC;                 /*!< Data read access-time 1 */
  uint8_t  NSAC;                 /*!< Data read access-time 2 in CLK cycles */
  uint8_t  MaxBusClkFrec;        /*!< Max. bus clock frequency */
  uint16_t CardComdClasses;      /*!< Card command classes */
  uint8_t  RdBlockLen;           /*!< Max. read data block length */
  uint8_t  PartBlockRead;        /*!< Partial blocks for read allowed */
  uint8_t  WrBlockMisalign;      /*!< Write block misalignment */
  uint8_t  RdBlockMisalign;      /*!< Read block misalignment */
  uint8_t  DSRImpl;              /*!< DSR implemented */
  uint8_t  Reserved2;            /*!< Reserved */
  uint32_t DeviceSize;           /*!< Device Size */
  uint8_t  MaxRdCurrentVDDMin;   /*!< Max. read current @ VDD min */
  uint8_t  MaxRdCurrentVDDMax;   /*!< Max. read current @ VDD max */
  uint8_t  MaxWrCurrentVDDMin;   /*!< Max. write current @ VDD min */
  uint8_t  MaxWrCurrentVDDMax;   /*!< Max. write current @ VDD max */
  uint8_t  DeviceSizeMul;        /*!< Device size multiplier */
  uint8_t  EraseGrSize;          /*!< Erase group size */
  uint8_t  EraseGrMul;           /*!< Erase group size multiplier */
  uint8_t  WrProtectGrSize;      /*!< Write protect group size */
  uint8_t  WrProtectGrEnable;    /*!< Write protect group enable */
  uint8_t  ManDeflECC;           /*!< Manufacturer default ECC */
  uint8_t  WrSpeedFact;          /*!< Write speed factor */
  uint8_t  MaxWrBlockLen;        /*!< Max. write data block length */
  uint8_t  WriteBlockPaPartial;  /*!< Partial blocks for write allowed */
  uint8_t  Reserved3;            /*!< Reserded */
  uint8_t  ContentProtectAppli;  /*!< Content protection application */
  uint8_t  FileFormatGrouop;     /*!< File format group */
  uint8_t  CopyFlag;             /*!< Copy flag (OTP) */
  uint8_t  PermWrProtect;        /*!< Permanent write protection */
  uint8_t  TempWrProtect;        /*!< Temporary write protection */
  uint8_t  FileFormat;           /*!< File Format */
  uint8_t  ECC;                  /*!< ECC code */
  uint8_t  CSD_CRC;              /*!< CSD CRC */
  uint8_t  Reserved4;            /*!< always 1*/
} SD_CSD;

/**
  * @brief  Card Identification Data: CID Register
  */
typedef struct
{
  uint8_t  ManufacturerID;       /*!< ManufacturerID */
  uint16_t OEM_AppliID;          /*!< OEM/Application ID */
  uint32_t ProdName1;            /*!< Product Name part1 */
  uint8_t  ProdName2;            /*!< Product Name part2*/
  uint8_t  ProdRev;              /*!< Product Revision */
  uint32_t ProdSN;               /*!< Product Serial Number */
  uint8_t  Reserved1;            /*!< Reserved1 */
  uint16_t ManufactDate;         /*!< Manufacturing Date */
  uint8_t  CID_CRC;              /*!< CID CRC */
  uint8_t  Reserved2;            /*!< always 1 */
} SD_CID;

/**
  * @brief SD Card information
  */
typedef struct
{
  SD_CSD SD_csd;
  SD_CID SD_cid;
  uint32_t CardCapacity;  /*!< Card Capacity */
  uint32_t CardBlockSize; /*!< Card Block Size */
} SD_CardInfo;



typedef struct
{
    WORD fdate,ftime;
} FILINFO;


#else

#define FA_TEXT			    0x00    //ccr2017-11-17����TEXT��ʽ���ļ����տ��ʱ����Ϊ0)

#pragma pack(4)

typedef struct {
    DWORD Folders;      //��ű����ļ��е��ļ�����Ŀ
    DWORD Files;        //��ű����ļ��е��ļ���Ŀ
    DWORD SpaceTotal;   //SD���ܿռ�(KB)
    DWORD SpaceFree;    //SD��ʣ��ռ�(KB)
    DWORD FilesSpace;    //ȫ���ļ���ռ�ռ�
    FATFS *FatFS;       //ִ��f_mount�����ɵ�FATFS
    FIL   File;         //�򿪵��ļ�
    BYTE  FS_Myself;    //�ļ�ϵͳ(FS_SD/FS_SD_INTR)
    BYTE  ManufacturerID;       /*!< ManufacturerID */
    WORD  OEM_AppliID;          /*!< OEM/Application ID */
    DWORD ProdSN;               /*!< Product Serial Number */

    //char  FileName[_MAX_PATH];//���浱ǰ������EJ�ļ�����(���ļ��к��ļ���)
} TSDISK;

#endif

#define _FS_SD       (FS_SD-1)          //���FS_SD��0,_FS_SDӦ��=FS_SD

#if defined(FS_SD_2ND)
#define _FS_SD_2ND  (FS_SD_2ND-1)   //�Ƿ������ڲ�SD���ļ�ϵͳ
#endif
/////////////////////////////////////////////////////////////////////

void ReadFileData(char *filename);

void ff_ListFolder(char *path);
FRESULT ff_OpenFile(char *filename,BYTE mode);
FRESULT ff_OpenFileQ(char *filename,BYTE mode);
FRESULT ff_DeleteTree(char* path);
FRESULT ff_DeleteFolderFile(char *filename);
FRESULT ff_CreateFolders(char *folders);
FRESULT ff_MountSDisk(BYTE mount);
FRESULT ff_ScanFiles (char* path,TSDISK *folder);
DWORD ff_SDiskSpace(void);
int ff_WriteFile(BYTE *data,int length);
int ff_ReadFile(BYTE *data,int length,BYTE mode);
int ff_EofFile(void);
void ff_CloseFile(void);
void ff_SelectSDisk(BYTE sd_Disk);
FRESULT ff_OpenFileWrite(char *filename,BYTE *data,int length);
FRESULT ff_RenameFile(char *fileFr,char *fileTo);
FRESULT ff_OpenFolder(char *folders);
int ff_FileSize(void);

extern TSDISK fsSDisk[_VOLUMES-FS_SD];
extern TSDISK *fsSDiskP;

#if defined(DEBUGBYPC)
FRESULT f_opendir(char *sFileName);
FRESULT f_stat(char* sFileName, /* �ļ�����Ŀ¼����ָ�� */
				FILINFO* FileInfo /* FILINFO �ṹ��ָ�� */
				);
#endif
extern SD_CardInfo SDCardInfo;//ccr2017-06-20

#if defined(FOR_DEBUG)
#define XPRINTOUT     1  //�Ƿ����ñ�ģ���������xprintf/xputs/xputc�����Ϣ
#endif

#if (XPRINTOUT)
void print_FResult(char* filename,FRESULT result);
#else
#define print_FResult(filename,a) {}
#endif

#endif


