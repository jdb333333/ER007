#define  MAIN_C 4

#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
#include "fiscal.h"
#include "ejournal.h"
#include "message.h"
#if (CASE_MFRIC==1)
    #include "MFRCard.h"
#endif

#include "AES256.h"

#if defined(CASE_ETHERNET)

#if defined(DEBUGBYPC)

#define LwIP_Periodic_Handle(localtime) {}

#else

#include "httpClient.h"
#include "Ethernet_app.h"

#include "lwip/opt.h"

void Set_ETHERNET_Ready(BYTE  );//ccr2015-01-22
void LwIP_Periodic_Handle(__IO uint32_t localtime);
#endif

#endif

#if (defined(CASE_GPRS))
#include "Gprs.h"
#endif

//VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV

#if !defined(DEBUGBYPC)

//#include "monitor.h"

/*********************************************************************************************************
  �궨��
*********************************************************************************************************/

extern volatile BYTE keyget_flag;
/*********************************************************************************************************
  ����ȫ�ֱ���
*********************************************************************************************************/
#endif

//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
//  ===========================================================
//  Funzioni definite in questo file
//  ===========================================================

void OutPrint(WORD Cmd, CONSTBYTE *Line); //    Lancia stampa (standard)
void OutPrintEx(WORD Cmd, CONSTBYTE *Line, WORD DotLinesBlank);   //    Lancia stampa (comando generico)

extern BYTE Display_RGBuf(int UpDown);

void ProcessKey(void);
WORD KeyInput(void);

short   KbHit(void);
BYTE   Getch(void);

BYTE CheckPrinter(void);

void CheckICCard(void);


#ifdef CASE_FATFS_EJ
extern void StoreEJData(BYTE *str);
//extern BYTE testonly_BADEJ;
#endif

#if (PC_EMUKEY==1)
    #include "FEcrTest.h"
#endif

// =============================================================
// Variabili globali
// =============================================================

#if defined(DEBUGBYPC)
BYTE LoopInput=0;
#endif

//Main program>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

void CheckBattery()
{
// liuj 0803
    if (Bios_1(BiosCmd_CheckBattery)!=1)//Low Battery
    {

        PutsO((char*)Msg[LOWBAT].str);
        Bell(0);
        while (!KbHit() || Getch()!=CLEARKey) FM_EJ_Exist();
    }

}

/*********************************************************************************************************
** Function name:       mainTask
** Descriptions:        ������
** input parameters:    pvData: û��ʹ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
#if !defined(DEBUGBYPC)
extern __IO uint32_t LocalTime; /* this variable is used to create a time reference incremented by 10ms */
extern BYTE ETHCheck;
void mainTask(void *pvData)
#else
void main_pc()
#endif
{
    ULONG     i;

#if defined(DEBUGBYPC)
    ProcessMessages();
    if (LoopInput)
        return;

#else// DEBUGBYPC==0

    while (KbHit()) Getch();//20130728 �������Զ��а���,���֮

    InitApplication();     /* Initialise application program */
/****************************************************************************/
    CLRMyFlags(REBOOTMUST);
#if defined(CASE_ETHERNET)
    //Ethernet_Start() �����������տ����IP��ַ�Ȳ���,��˱�����õ�InitApplicationִ��
//    PutsO("Start Ethernet>>");//ccr2017-06-14 testonly
    Ethernet_Start();
    if (CLONG(MAC_ADDR[0])==0xffffffff)
        PutsO("NO MAC Address!");
    else
        PutsPre(0,ModeHead,((ApplVar.CentralLock==RG)||(ApplVar.CentralLock==MG))?(0):('>'));
#if (LWIP_DNS)
  //ͨ��URL��������ȡ��������IP��ַ
  if (ApplVar.AP.NetWork.ServerURL[0] && CLONG(ApplVar.AP.NetWork.PrimaryDNS[0]))
  {
      RESETBIT(ApplVar.AP.NetWork.Option,DNSPROGRESSFlag);
      CLONG(ApplVar.AP.NetWork.ServerIP[0])=0;//��ServerIP,�Դ�DNS���������»�ȡ�˵�ַ
  }
#endif

#endif
    ff_SelectSDisk(FS_SD);//ccr2017-04-21 testonly

//ccr2017-06-15>>>>>>>>>>>>
    if (RTC_AlarmStatus())
        SetZReportMust();

#if (defined(CASE_EURO))
    if (BIT(ApplVar.Fiscal_PrintFlag,(BIT2)))
    {
        ApplVar.FReport = ApplVar.CentralLock = Z;
        ApplVar.ReportNumber = 1;

        PrintStr_Center(POWEROFFONZ1,true);
        PrintStr_Center(POWEROFFONZ2,true);
        PrintStr_Center((char*)MsgNOTARECEIPT,true);
        Print_FiscalReport(true);//ccr2018-01-24

        ApplVar.CentralLock = RG;
    }
//ccr2017-12-20    DaylightSavingTimeSet();//ccr2017-08-09 ��ʱ�ƴ���
    if (!ApplVar.FRegi && ApplVar.ZReport == 2)     /* check if day changed when not in transaction */
    {//��������ӡZ����
        ApplVar.ErrorNumber=ERROR_ID(CWXXI75);       /* first take fiscal Z-ApplVar.Report */
    }
#endif
//ccr2017-06-15<<<<<<<<<<<<

    while (1)         /* Exit loop only with power fail */
#endif
    {
        //ccr2017-12-27>>>>>>>>>>>>>>>>
        if (!ApplVar.FRegi && ApplVar.ZReport==3)
        {
            ApplVar.ZReport = 2;    /* �����,���ñ����ӡZ������־ */
            ApplVar.ErrorNumber=ERROR_ID(CWXXI75);       /* first take fiscal Z-ApplVar.Report */
        }
        //ccr2017-12-27<<<<<<<<<<<<<<<<

        ApplRamSaved = 0x5a;//Appl Ram δ����

#if (defined(CASE_EURO) && !defined(DEBUGBYPC))//ccr2017-12-20>>>>>>>
        if (SUMMERTIME)// && !ApplVar.FRegi)
        {
            if (DaylightSavingTimeSet())//ccr2017-08-09 ��ʱ�ƴ���
            {
                CheckTime(true);            /* display time after 5 minutes */
                Bell(2);
                memset(SysBuf,' ',PRTLEN);
                if (RTC_GetStoreOperation() == RTC_StoreOperation_Set)//��ǰ������ʱ��
                {
                    PrintStr_Center(TOSUMMERTIME,true);
                    SysBuf[0]='S';SysBuf[1]='T';
                }
                else
                {
                    PrintStr_Center(TOWINTERTIME,true);
                    SysBuf[0]='W';SysBuf[1]='T';
                }
                strcpy(SysBuf+3,TimeAsci);
                PrintStr_Center(SysBuf,true);
            }
        }
#endif//ccr2017-12-20<<<<<<<<<


#if defined(CASE_GPRS)
        GPRSWaitForReady(false);
#endif


#if (!defined(DEBUGBYPC) && defined(CASE_ETHERNET))
  //ccr2017-10-16/����޷��Զ���ȡIP��ַ������
  if (!ETHCheck && Get_ETHERNET_Ready())//ccr2017-02-21
  {
    /* handle periodic timers for LwIP */
    LwIP_Periodic_Handle(LocalTime);
  }
  //ccr2017-10-31>>>>>>>
#if (LWIP_DNS)
  //����ͨ��URL��������ȡ��������IP��ַ
  if (CLONG(ApplVar.AP.NetWork.ServerIP[0])==0 && (BIT(ApplVar.AP.NetWork.Option,(IPByDHCPFlag+DNSPROGRESSFlag))==IPByDHCPFlag))//&& ApplVar.AP.NetWork.ServerURL[0]
  {
      GetIPByDNSFromURL(ApplVar.AP.NetWork.ServerIP,ApplVar.AP.NetWork.ServerURL,false);
  }
#endif

#endif

//ccr091125>>>>>>>>>>>>>>>>>

#if (defined(FISCAL) && defined(CASE_FATFS_EJ) && DD_FISPRINTER==0)
        //��⵽��EJ��,ֱ����ʾ��ʼ����EJ��.
        if (ApplVar.FiscalFlags==MUSTINITEJ && ApplVar.CentralLock != SET)
        {
            //testonly_BADEJ = 0;
            PutsO(INITEJPROMPT);
            do {
                FM_EJ_Exist();
                if (KbHit())
                {
                    i =Getch();
                    if (i==CLEARKey)
                        break;
                    if (i==ENTERKey)
                    {
                        Initial_EJ();
                        CheckError(0);
                    }
                }
            } while (ApplVar.FiscalFlags==MUSTINITEJ && !ApplVar.FTrain);//��ѵ״̬��,��ִֹ��EJ��ʼ������
            ClearEntry();
            PutsPre(0,ModeHead,((ApplVar.CentralLock==RG)||(ApplVar.CentralLock==MG))?(0):('>'));
#if (DISP2LINES)
            Puts1(Msg[SPACE].str);
#endif
            ApplVar.ErrorNumber = 0;
            CheckFisError();
        }
#endif
//<<<<<<<<<<<<<<<<<<<<<<<<<<<
#if PC_EMUKEY
        FisTestProc();
#endif


#if (DD_CHIPC==1)
        CheckICCard();//ccr050316
#endif
        Computer();//communicate with computer
#if DD_FISPRINTER == 0
#if !defined(DEBUGBYPC)


#if POWERCTRL
        if (!DC_DET_GET() && ApplVar.PoolPushIn==ApplVar.PoolPopOut)
        {
            mDrawPower(1);
            pwrGetStatus(GET_VIN_STATUS);
            if (BATTERYTooLow(PWR_WARNING2 | PWR_BY_BAT))
            {
                while (BatteryVoltage()<VIN_LOW && !DC_DET_GET())
                {
                    Bell(1);
        #if (DISP2LINES)
                    Puts1_Right(CaptionCWXXI95);
        #else
                    PutsO(CaptionCWXXI95);
        #endif
                    Delay(500);
                    pwrGetStatus(GET_VIN_STATUS);
                }
                if (BATTERYTooLow(PWR_BY_BAT | PWR_WARNING1))
                    ApplVar.ErrorNumber = ERROR_ID(CWXXI95);
            }
        }
#endif

        BalanceWeight();//ccr2017-09-22
        if (BarCode() || KeyInput())//ccr050331 get from keyboard or Bar reader
#else
        if (KeyInput())
#endif
        {
            ProcessKey();
        }
        else
        {
            CheckTime(false);            /* display time after 5 minutes */
            CheckPrinter();
        }
#else
        ProcessButton();

        CheckPrinter();
#endif//DD_FISPRINTER


#if defined(FISCAL)
        if (BIT(ApplVar.Fiscal_PrintFlag,BIT7) && !PrintNoPaper())//Printer_Status.g_bNOPAPER)//ccr2018-03-08ȱֽ���Ϊ��ֽ
            PrintAgain();

        FM_EJ_Exist();
#ifdef CASE_FATFS_EJ
        if (ApplVar.FiscalFlags == NOEJ || ApplVar.FiscalFlags==FM_X_EJ)
        {//����⵽û��EJ��ʱ,����˼��,�Ƿ�������¿�
            ApplVar.FiscalFlags=FISCALOK;
            CheckEJ(true);//����⵽û��EJ��ʱ,���¼��EJ

            if (ApplVar.FiscalFlags==FISCALOK)
                ApplVar.ErrorNumber=0;
            else if (ApplVar.FiscalFlags!=NOEJ && ApplVar.FiscalFlags!=MUSTINITEJ) //ccr090115 It is must the same EJ
                ApplVar.FiscalFlags=FM_X_EJ;
            CheckFisError();
        }
        //ccr2017-06-21>>>>������EJ�Ŀռ�ʣ�಻��ʱ,��ʾ���60��ǰ���ļ�>>>>>>>>>
        if (ApplVar.ErrorNumber==ERROR_ID(CWXXI111))//(ApplVar.FiscalFlags==FISCALOK)&&(ApplVar.EJSpaceFree[_FS_SD_2ND]<MMC_FULL))
        {
            ApplVar.ErrorNumber=0;
            PutsO(Msg[CWXXI111].str);
            PutsM((char*)MsgDELZBEFOR60);//ɾ��60��ǰ���ļ�
            do {
                FM_EJ_Exist();
                if (KbHit())
                {
                    i =Getch();
                    if (i==CLEARKey || i==EXITKey)
                        break;
                    if (i==ENTERKey)
                    {
                        if (ApplVar.ZReport==1)
                        {
                            PutsO((char*)MsgDELZBEFOR60ING);
                            PutsM(Msg[WAITING].str);//��ʾ�ȴ�
                            ApplVar.ErrorNumber=0;
                            DeleteSDBefor60Days(60);
                        }
                        else
                            ApplVar.ErrorNumber=ERROR_ID(CWXXI75); /* first take fiscal Z-Report */
                        break;
                    }
                }
            } while (true);//��ѵ״̬��,��ִֹ��EJ��ʼ������
            ClearEntry();
            PutsPre(0,ModeHead,((ApplVar.CentralLock==RG)||(ApplVar.CentralLock==MG))?(0):('>'));
#if (DISP2LINES)
            Puts1(Msg[SPACE].str);
#endif
        }//ccr2017-06-21<<<<<<<<<<<<<<<<
#endif
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#endif

//ccr070723>>>>>>>>>>>>
#if ((DD_FISPRINTER==0) && defined(FISCAL))
        if (ApplVar.ErrorNumber== ERROR_ID(CWXXI75) && ApplVar.CentralLock!=SET)       /* first take fiscal Z-ApplVar.Report */
        {
            //ApplVar.ErrorNumber=0;
            Appl_MaxEntry = 4;
            ClearEntry();
            ApplVar.CentralLock = Z;
            strcpy(ModeHead,DText[DTEXT_Z]);
            PutsPre(0,ModeHead,'>');
            ClearLine2();
        }
#endif
//<<<<<<<<<<<<<<<<<<<<

//ccr090202>>>>>>>>>>>>
#if (0) //ccr2017-06-21(EJ��ʱҪ������ӡZһ�α���) CASE_FATFS_EJ
        if (!ApplVar.FRegi && !ApplVar.ErrorNumber && ApplVar.FiscalFlags != FMISNEW &&
            ApplVar.FiscalFlags != FMFULL && ApplVar.FiscalFlags != MUSTINITEJ && ApplVar.FiscalFlags != EJFULL &&
            ApplVar.EJSpaceFree[_FS_SD]<MMC_FULL)
        {//������γ���ʱ,�տ�������Ǳ���,�޷�������������,ֱ������EJ
            ApplVar.ErrorNumber=ERROR_ID(CWXXI88);             // 5 KB left, only warn once
            ApplVar.FiscalFlags = EJFULL;
        }
#endif
//<<<<<<<<<<<<<<<<<<<<<
#if (DD_FISPRINTER && defined(FISCAL))//ccr090917
        CheckFisError();
#endif

        CheckError(0);

    }

}

//==================================================================
//Test if has some key for read
//Return True if a key pressed
//�Ȱ���ֽ,Ȼ������Ű�MODE,�����Զ���Ʊ����
short   KbHit()
{
#if (PC_EMUKEY)
    static WORD lastK=0;
#endif
    WORD i;
#if (defined(DEBUGBYPC))
    ProcessMessages();
#endif


        i =Bios_1(BiosCmd_CheckKeyborad);//����Ƿ��а���

#if (PC_EMUKEY)
        if (!ApplVar.FRegi && lastK==0xff)
        {
            if (FisTestTask.KeyEmuNum) FisTestTask.KeyEmuNum--;
            FisTestTask.Going = FisTestTask.PrnOFF = 0;//�رպ������Լ�ʱ���򿪴�ӡ��
        }
        if (i && (i==LOCKKey+1))// && ApplVar.CentralLock==RG && Appl_EntryCounter==0)
        {
            InActive = 0;//Disable display datetime

            if (FisTestTask.Going)//�ڶ��ΰ����Լ�ʱ���رմ�ӡ��
            {
                if (FisTestTask.PrnOFF == 0)
                    FisTestTask.PrnOFF = 1;
                else if (!ApplVar.FRegi)
                    FisTestTask.Going = FisTestTask.PrnOFF = 0;//�رպ������Լ�ʱ���򿪴�ӡ��
                else
                    lastK=0xff;
                Getch();
                if (lastK!=0xff)
                    lastK=0;
                return 0;
            }
            else if (Appl_EntryCounter==0 && ApplVar.CentralLock==RG && lastK==FEEDKey+1)
                {
                    FisTestTask.Going = 0x01;
                    Getch();
                    lastK=0;
                    return 0;
                }
        }
#endif
        if (i==0)
        {//�ް���
            if (KeyFrHost!=0xff)
            {
                i = KeyFrHost+1;
#if (defined(DEBUGBYPC) && PC_EMUKEY)
                if ((i==LOCKKey+1) && ApplVar.CentralLock==RG)//  && Appl_EntryCounter==0)
                {
                    if (FisTestTask.Going)//�ڶ��ΰ����Լ�ʱ���رմ�ӡ��
                    {
                        if (FisTestTask.PrnOFF == 0)
                            FisTestTask.PrnOFF = 1;
                        else if (!ApplVar.FRegi)
                            FisTestTask.Going = FisTestTask.PrnOFF = 0;//�رպ������Լ�ʱ���򿪴�ӡ��
                        else
                            lastK=0xff;
                        KeyFrHost = 0xff;//                     Getch();
                        if (lastK!=0xff)
                            lastK=0;
                        return 0;
                    }
                    else if (Appl_EntryCounter==0 && lastK==FEEDKey+1)
                        {
                            FisTestTask.Going = 0x01;
                            KeyFrHost = 0xff;//                     Getch();
                            if (lastK!=0xff)
                                lastK=0;
                            return 0;
                        }
                }
#endif
            }
        }
#if (!defined(DEBUGBYPC) && PC_EMUKEY)
        else if (lastK!=0xff)
            lastK=i;
#endif
        if (i)
        {
            InActive = 0;//Disable display datetime
#if (defined(DEBUGBYPC) && PC_EMUKEY)
            if (lastK!=0xff)
                lastK=i;
#endif
        }
        return i;
}


// test chipcard                  //
void CheckICCard()
{//ccr050316
#if (DD_CHIPC==1)
#if (CASE_MFRIC==1)
    if (BIT(IC.ICState,IC_INSERT) && !CC_Insert())// ���Կ��Ƿ�ȡ��  //
    {
        if (ApplVar.CentralLock == (SETUPMG | MG))
        {//  �ڽ����˶�IC�������ò���ʱ������γ������Զ��Ƴ�����   //
            ClearEntry();
            ApplVar.KeyNo =  EXITKey;
            CheckFirmKey();
        }
        if ((IC.REC_Customer[CC_CLIST] & 3)>0 && (IC.REC_Customer[CC_CLIST] & 3)<ApplVar.AP.Plu.Level)//ccr chipcard
            ApplVar.PluPriceLevel = 0;
        IC.CHIP_Flag = -1;
        RESETBIT(IC.ICState,IC_INSERT | IC_NOTREMOVED);
    }
#else
    if (BIT(IC.ICState,IC_INSERT) && !CC_Insert())// ���Կ��Ƿ�ȡ��  //
    {
        if ((IC.REC_Customer[CC_CLIST] & 3)>0 && (IC.REC_Customer[CC_CLIST] & 3)<ApplVar.AP.Plu.Level)//ccr chipcard
            ApplVar.PluPriceLevel = 0;
        IC.CHIP_Flag = -1;
        if (ApplVar.CentralLock == (SETUPMG | MG))// ���Կ��Ƿ�ȡ��  //
        {
            //  �ڽ����˶�IC�������ò���ʱ������γ������Զ��Ƴ�����   //
            ClearEntry();
            ApplVar.KeyNo =  EXITKey;
            CheckFirmKey();
        }
    }
    if (((ApplVar.CentralLock & 0xff) == MG || ApplVar.CentralLock == RG)  && ChipCard())//ccr chipcard
    {
        InActive = 0;
        if (!ApplVar.ErrorNumber)
        {
            PrintChipCard(0);
        }
    }
#endif
#endif
}
//--------------------------------------------------------
// ����ӡ���Ĺ���״̬    			//
//return:0-Error found  1-no error //
BYTE CheckPrinter(void)
{
    BYTE newErr;
#if (PC_EMUKEY)
    if (FisTestTask.Going)//�Զ���������ʱ��������ӡ��
        return TRUE;
    else
#endif
    {
#if (!defined(DEBUGBYPC))
        newErr = 0;

        Get_Printer_status();
        if (Printer_Status.g_bDisconnect)//ccr2018-04-02
        {
            if (BIT(ApplVar.Fiscal_PrintFlag,(BIT0 | BIT2)))
                SETBIT(ApplVar.Fiscal_PrintFlag,BIT7);//���ڿ���ȱֽ���´�ӡȱֽ
            if ((ApplVar.ErrorNumber&0x7fff)!=ERROR_ID(CWXXI126))//ccr2018-03-07
            {
               newErr = ERROR_ID(CWXXI126);
               Fiscal_AddDisconnect(FISxPRINTERCOUNT);
            }
        }
        else if (Printer_Status.g_bNOPAPER)//paper out                       /* Near End */
        {
            if (BIT(ApplVar.Fiscal_PrintFlag,(BIT0 | BIT2)))
                SETBIT(ApplVar.Fiscal_PrintFlag,BIT7);
            if ((ApplVar.ErrorNumber&0x7fff)!=ERROR_ID(CWXXI40))//ccr2018-03-07
               newErr = ERROR_ID(CWXXI40);
        }
#if(CASE_HANDUP)	//    cc 20070827
        else if (Printer_Status.g_bHANDUP)                       /*    Near End     */
        {
            newErr = ERROR_ID(CWXXI39);
        }
#endif
        else if (Prn_Status.g_bTOOHOT)                       /* Near End */
        {
            newErr = ERROR_ID(CWXXI41);
        }
#endif
        if (newErr!=0)
        {
            if (newErr!=(ApplVar.ErrorNumber&0x7fff))
                ApplVar.ErrorNumber=newErr;
            return false;
        }
        else if ((ApplVar.ErrorNumber&0x7fff)>=39 && (ApplVar.ErrorNumber&0x7fff)<=41)
        {
//         if ((ApplVar.ErrorNumber&0x7fff)==ERROR_ID(CWXXI40))
//             RFeed(1);//�Զ�������ӡ

            Start_When_Ready(Msg[SPACE].str);
            ApplVar.ErrorNumber=0;
        }
        return TRUE;
    }
}
//==========================================================================
short CheckFunctionEntry()
{
#if defined(CASE_EURO) //!!! GREECE_ONLY !!!
    if (ApplVar.Key.Code != TEND && ApplVar.Key.Code != MODI)
#endif
        if (ApplVar.Key.Code < 1000 && !(ApplVar.Key.Code % 100))
        {   /* number function key */
            if (!Appl_NumberEntry || Appl_NumberEntry > 99)
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                return 1;
            }
            ApplVar.Key.Code += Appl_NumberEntry;
            if (ApplVar.MultiplyCount)
            {
                ApplVar.DecimalPoint = ApplVar.Qty.Sign & 0x03;
                ApplVar.Entry = ApplVar.Qty;
                ApplVar.MultiplyCount = 0;
                GetLongEntry(); /* make word from entry to Appl_NumberEntry */
            }
            else
                Appl_EntryCounter = 0;
        }
    return 0;
}


void GetEntry()
{
    if (ApplVar.DecimalPoint)
    {
        ApplVar.DecimalPoint--;
        ApplVar.Entry.Sign = ApplVar.DecimalPoint;
    }
#if (AMTMUL100)//defined(CASE_EURO) && !defined(CASE_ITLIA))
    else
    {//û������С����ʱ,�Զ�Ϊ��λС��(����������Է�Ϊ��λ
        if ((ApplVar.Key.Code==NPRICE)||(ApplVar.Key.Code>PORA&&ApplVar.Key.Code<MODI)||(ApplVar.Key.Code==DISC+3)||(ApplVar.Key.Code==DISC+4)||(ApplVar.Key.Code>DEPT&&ApplVar.Key.Code<DEPT+100))
        {
            ApplVar.Entry.Sign =  2;
            ApplVar.DecimalPoint=2;
        }
/*	 		else if(ApplVar.Key.Code==MULT)
            {
                ApplVar.Entry.Sign =  3;
                memcpy(SysBuf, EntryBuffer, ENTRYSIZE);
                ApplVar.DecimalPoint=3;
                StrToBCDValue(ApplVar.Entry.Value, &SysBuf[ENTRYSIZE - 2], BCDLEN);
            }*/
        else
        {
            ApplVar.Entry.Sign =  0;
        }
    }
#else
    else
    {
        ApplVar.Entry.Sign =  0;
    }
#endif
    StrToBCDValue(ApplVar.Entry.Value, &EntryBuffer[ENTRYSIZE - 2], BCDLEN);
    GetLongEntry(); /* make long from entry to Appl_NumberEntry */
}

/*-------Process the input from keyboard-------------
    ApplVar.KeyNo: �������
    ApplVar.Key.Code:������Ӧ�Ĺ�����
------------------------------------------------------*/
void ProcessKey()
{
#if DD_FISPRINTER == 0
    short   i,j,k;
    BYTE    sDot,sP;
    BYTE    sFlag = 1;//=1,��ʾ����δ������;=2,��ʾ�����Ѵ���EntryBuffer

    if (ApplVar.Key.Code == CLEAR)                     /* clear key ? */
    {
        ApplVar.FSub = 0;
#if defined(FISCAL)
        if (ApplVar.FStatus > 0x90)
        {
            ApplVar.FStatus = 0;    /* exit fiscal init when lock changed */
            ReceiptIssue(0);
        }
#endif

        Fixed();
        if (ApplVar.CentralLock==RG || ApplVar.CentralLock==MG)
            Appl_MaxEntry = ENTRYSIZE-1;

#if POWERCTRL
        if (!DC_DET_GET() && !ApplVar.FRegi)
            mDrawPower(2);//��ʾ���
#endif
        return;
    }
    else if (ApplVar.ErrorNumber)  /* Error Condition ? */
        return;

//    if (!ApplVar.Key.Code && !BIT(ApplVar.ArrowsAlfa,INPUTVALUE))  //ccr2017-12-27
    //ccr2018-03-13>>>>>>>>>�ܿ�С����ת������>>>>>>>>
    if (ApplVar.CentralLock==RG || ApplVar.CentralLock==MG)
    {
        if (!ApplVar.Key.Code)
            return;
        if (ApplVar.Key.Code==SHIFT1)
        {
            Fixed();
            return;                        /*    don't clear entry     */
        }
    }
    //ccr2018-03-13<<<<<<<<<<<<<<<<<<


    if (ApplVar.Key.C.High && !BIT(ApplVar.ArrowsAlfa,INPUTVALUE) && ApplVar.KeyNo != fBACKSPACE)
    {//Ϊ���ַ�������,Key.C.High>0,Input from the keeyboard is a function key(�����ּ�)
#if defined(FISCAL)
        if (ApplVar.FiscalFlags != FISCALOK &&
            ApplVar.FiscalFlags != TESTFM &&
            ApplVar.FiscalFlags != FMLESS &&
            ApplVar.FiscalFlags != EJLESS &&
            (ApplVar.FiscalFlags!= BADEJ || !ApplVar.FRegi || ApplVar.Key.Code!=CORREC+4)) // ccr091124 EJ����ʱ,����ȡ������ //
        {
            /*		if(ApplVar.FiscalFlags == FMISNEW)
                        ApplVar.ErrorNumber=ERROR_ID(CWXXI94);
                    else*/
            CheckFisError();
            return;
        }

#if (defined(CASE_EURO))
        if (!ApplVar.FRegi && ApplVar.ZReport == 2)     /* check if day changed when not in transaction */
        {//��������ӡZ����
            ApplVar.ErrorNumber=ERROR_ID(CWXXI75);       /* first take fiscal Z-ApplVar.Report */
            return ;
        }
#endif
#endif

#if POWERCTRL
        if (!DC_DET_GET())
            mDrawPower(0);//����ʾ���
#endif
        Appl_NumberEntry = 0;
        if (Appl_EntryCounter)          /* ApplVar.Entry ? */
        {
            if (Appl_EntryCounter <= (BCDLEN * 2))
                GetEntry();
            else
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);     /*    maximum 16 digits entry     */
                return;
            }
        }
    }
    else   /*    if (!ApplVar.Key.C.High)     */
    {//Ϊ�༭�����������ַ���
        /* Key.C.High<0, Ascii '0'..'9','.' entry key     */
        if (Appl_EntryCounter < (ENTRYSIZE - 1))
        {
            if (ApplVar.KeyNo == fBACKSPACE)
            {//���ɾ����������ַ�
                sFlag = 2;//��ʾ�����Ѿ���������
                DeleteEntry(true);
            }

            if (Appl_EntryCounter<Appl_MaxEntry+(ASCIIINPUT*COMPOSEIN))
            {
                if (ApplVar.Key.Code == ZERO2)  /* double zero key*/
                {
                    if (!BIT(ApplVar.ArrowsAlfa,INPUTVALUE))//ccr2014-08-15 �ַ���ʽ�� || BIT(ApplVar.ArrowsAlfa,NUMRIC09 + INPUTVALUE))
                    {//'00'Ϊ��������0
                        sFlag = 2;//��ʾ�����Ѿ���������
                        if (!AppendEntry('0')) return;
                        if (!AppendEntry('0')) return;
                    }
                }//end of if(ApplVar.Key.Code == ZERO2)

                if (sFlag==1)//����δ���������̴���
                {
#if (ASCIIINPUT==1 || COMPOSEIN==0)
                    if ((sP = GetComposeASC(ApplVar.KeyNo))==0)
                        return;
#elif (COMPOSEIN==1)//�������������ĸ
                    if ((sP = GetComposeASC(ApplVar.Key.Code))==0)
                        return;//������Ϊ�Ƿ�����,�˳�
                    if (sP==0xff)
                        sFlag=2;//�ַ��Ѿ�����������
#endif

                    if (Appl_EntryCounter<Appl_MaxEntry && sFlag==1)
                    {
                        if (!AppendEntry(sP)) return;
                    }
                }
                if (ApplVar.ErrorNumber)
                    return;

                memset(SysBuf,' ',DISLEN+5);

                if (ApplVar.DecimalPoint>0)  //   �������С���㣬����д���  PenGH //
                {

                    j = DISLEN-1;
                    i = ENTRYSIZE-2;
                    k = Appl_EntryCounter;
                    sDot = 0;

                    while (k>0 && j>=0)  //  �����뻺�������ݸ��Ƶ�SysBuf������ //
                    {
#if ((DISP2LINES) || DD_LCD_1601 || defined(DEBUGBYPC))

                        //ccr2014-08-15>>>>>>>>>��.ת��Ϊ,
                        if (!BIT(COMMA,BIT0) && EntryBuffer[i]=='.')
                            SysBuf[j--] = ',';
                        else
                            SysBuf[j--] = EntryBuffer[i];
                        //<<<<<<<<<<<<<<<<<<<<<<
                        i--;
                        k--;
#else
                        if (EntryBuffer[i]=='.')
                            sDot = 0x80;//��С������ϵ���ǰһ���ַ���
                        else
                        {
                            SysBuf[j--] = EntryBuffer[i] | sDot;
                            sDot = 0;
                        }
                        i--;
                        k--;
#endif
                    }
                }
                else
                    memcpy(SysBuf,&AtEntryBuffer(DISLEN),DISLEN);

                SysBuf[DISLEN] = 0;

                if (BIT(ApplVar.ArrowsAlfa,INPUTPWD))// & (ApplVar.CentralLock & 0xff!=MG))        /* secret code entry ? */
                {
                    //Ϊ�������뷽ʽ
                    for (i=0;i<DISLEN;i++)
                    {
                        if (SysBuf[i]>' ')
                            SysBuf[i]='*';
                        else
                            SysBuf[i]='_';
                    }
                }
#if (DISP2LINES)
                if (ApplVar.CentralLock!=RG && (ApplVar.CentralLock & 0xff)!=MG)
                {
                    i = strlen(ModeHead);
                    while (i>0 && ModeHead[i-1]==' ') i--;

                    if (i>0 && SysBuf[i]==' ' && Appl_ProgLine<=1)
                    {
                        for (j=0;j<i;j++)
                        {
                            if (SysBuf[j]==' ' || !ModeHead[j])
                                break;
                            else
                                SysBuf[j] = ModeHead[j];
                        }
                    }
                }
                if (Appl_ProgStart || ApplVar.FuncOnEnter == FUNC800) //liuj 0604
                {
                    PutsO(ProgLineMes);
                }
                else
                {
                    //ccr2017-05-04>>>>>>>�Զ���ʾSET/X/Z�б�>>>>>>>>>>>>>>>>>>>>>>>>>
//                 if ((ApplVar.Key.Code>='0' && ApplVar.Key.Code<='9') &&
                    if (Appl_EntryCounter && ApplVar.FuncOnEnter==0 &&
                        ((ApplVar.CentralLock==SET) || ApplVar.CentralLock==Z || ApplVar.CentralLock==X))
                    {
                        i = StrToLong(&AtEntryBuffer(Appl_EntryCounter),Appl_EntryCounter);
                        switch  (ApplVar.CentralLock)
                        {
                          case SET:
                            if (i>=1 && i<=SETUPMAX)
                            {
                                PutsPre(0,(char*)Msg[i].str,'>');
//ccr2017-11-29                                if (i+1<=SETUPMAX)//ccr2017-09-15 ���ǵڶ��е�����
//ccr2017-11-29                                    strcpy(SysBuf,Msg[i+1].str);
                            }
                            else
                            {
                                for (j=0;j<AUX_FUNCITEMS;j++)
                                {
                                    if (i==TblAUX_Funcs[j])
                                    {
                                        PutsO(Msg[AUX_FUNC1ST+j].str);
                                        break;
                                    }
                                }
                                if (j>=AUX_FUNCITEMS)
                                    PutsO(Msg[CWXXI45].str);
                            }
                            break;
                          case X:
                              if (i>=1 && i<=ITEMS_X)
                              {
                                ApplVar.ReportNumber= i;   //ccr2017-09-15 �����һ�ΰ�DOWNʱ���¹�������
                                PutsPre(0,(char*)Msg[i+XREPORT1ST-1].str,'>');
//ccr2017-11-29                                if (i+1<=ITEMS_X)//ccr2017-09-15 ���ǵڶ��е�����
//ccr2017-11-29                                    strcpy(SysBuf,Msg[i+XREPORT1ST].str);
                              }
                              else
                                 PutsO(Msg[CWXXI45].str);
                              break;
                          case Z:
                            if (i>=1 && i<=ITEMS_Z)
                            {
                                ApplVar.ReportNumber= i;     //ccr2017-09-15 �����һ�ΰ�DOWNʱ���¹�������
                                PutsPre(0,(char*)Msg[i+ZREPORT1ST-1].str,'>');
//ccr2017-11-29                                if (i+1<=ITEMS_Z)//ccr2017-09-15 ���ǵڶ��е�����
//ccr2017-11-29                                    strcpy(SysBuf,Msg[i+ZREPORT1ST].str);
                            }
                            else
                                PutsO(Msg[CWXXI45].str);
                            break;
                        }
                    } //ccr2017-05-04<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
                    else if (ApplVar.FuncOnEnter==0)
                        PutsPre(0,ModeHead,((ApplVar.CentralLock==RG)||(ApplVar.CentralLock==MG))?(0):('>'));
                }
                Puts1(SysBuf);
#if(DD_ZIP_21==1)                     //    PenGH 2008-06-03
                if ( ((ApplVar.CentralLock==RG)||(ApplVar.CentralLock==MG))&&(Appl_ProgType!=0x91)  )
                {
                    PutsC(SysBuf+4);
                }
#endif
#else
                PutsO(SysBuf);
#endif

            }//��������̫��
//ccr20130104 �������Ȳ�����            else if (Appl_MaxEntry)//ccr070608
//ccr20130104 �������Ȳ�����                ApplVar.ErrorNumber=ERROR_ID(CWXXI18);
        }
        else
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);       /* Invalid ApplVar.Entry */
        return;
    }//end of if (!ApplVar.Key.C.High)

//    if (ApplVar.Key.Code >= TEND &&  ApplVar.Key.Code < (TEND + 100))
//		ApplVar.FRefund = 0;

    if (ApplVar.FuncOnEnter)
        return;

    if (ApplVar.FCorr || ApplVar.FRefund)
    {
        if (ApplVar.Key.Code >= TEND &&  ApplVar.Key.Code < (TEND + 100))
        {
            if (ApplVar.FRegi)
            {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                return;
            }
        }
        else if (ApplVar.Key.Code >= PBF &&  ApplVar.Key.Code < (PBF + 100))
        {
        }
        else if (ApplVar.Key.Code >= DISC &&  ApplVar.Key.Code < (DISC + 100))
        {
        }
        else if (ApplVar.Key.Code >= PORA &&  ApplVar.Key.Code < (PORA + 100))
        {
        }
        else if (ApplVar.Key.Code != MULT && ApplVar.Key.Code != NPRICE && ApplVar.Key.Code < DEPT)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            return;
        }
    }
    if (CheckFunctionEntry())
        return;
    if ((ApplVar.MultiplyCount || ApplVar.FPrice) && ApplVar.Key.Code < DEPT
        && ApplVar.Key.Code != MULT && (ApplVar.Key.Code < PORA || ApplVar.Key.Code > PORA+99))
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI01);    /* multiply only on article, pora and X key */
        return;
    }
    if ((ApplVar.Key.Code < DISC || ApplVar.Key.Code > DISC + 100) &&   //   ��������ۿ۴����Ҳ��Ǹ��ʽ��������С������ PenGH ?  //
        (ApplVar.Key.Code < TEND || ApplVar.Key.Code > TEND + 100))
        ApplVar.FSub = 0;       /* reset subtotal flag */

//ccr090526>>>>>>>>>>>>>>>
    if (ApplVar.DecimalPoint &&
        (ApplVar.Key.Code>=DRAW && ApplVar.Key.Code<=PORA ||
         ApplVar.Key.Code>=MODI && ApplVar.Key.Code<MULT ||
         ApplVar.Key.Code>=LEVEL1 && ApplVar.Key.Code<=DEPT && ApplVar.Key.Code!=SHIFT1 || //ccr2018-01-24
         ApplVar.Key.Code % 100==0)
        )//<<<<<<<<<<<<<<<<<<<<<<<<
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
        ClearEntry();
        return;
    }
    //ccr2017-07-27>>>>>>>>>С����ת��>>>>>>>>
    if (TestChangePointMust())
    {//���Ϲ��ܲ�Ҫ��С������ת��
        if (!ChangePoint())
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
            return;
        }
        SETMyFlags(DOTCHANGED);//ccr2016-05-28
    }
    else
        CLRMyFlags(DOTCHANGED);//ccr2016-05-28
    //ccr2017-07-27<<<<<<<<<<<<<<<<<<<<<<<<<<

/*    if (ApplVar.DecimalPoint && ApplVar.Key.Code != MULT &&
        ApplVar.Key.Code != NUMBER && ApplVar.Key.Code != NUMBER1 && ApplVar.Key.Code != NUMBER2 &&
         (ApplVar.Key.Code < DISC || ApplVar.Key.Code > DISC + 100) &&	(ApplVar.Key.Code < PLU1 + 1))
        ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
    else    */
//ccr2016-12-20#if (defined(CASE_EURO))
    if ((ApplVar.CentralLock & 0xff)==SET || ApplVar.CentralLock==X || ApplVar.CentralLock== Z)
    //cc 20071102>>>>>>>>>>>>>>>>>>>>>>>
    {
        ApplVar.ErrorNumber = 1;
        return;
    }
//ccr2016-12-20#endif
#if defined(CASE_EURO) //!!! GREECE_ONLY !!!//ccr2017-12-22>>>>>>>
	if (ApplVar.Key.Code==TEND_CASH && ApplVar.FRegi==0 && !Appl_EntryCounter)
        ApplVar.Key.Code=ODRAW;//��Ǯ��

//    switch  (ApplVar.Key.Code)
//    {
//    case TEND_CASH: ApplVar.Key.Code=ODRAW;break;//��Ǯ��
//    case SUB: ApplVar.Key.Code=ODRAW;break;//��Ǯ��
//    }
#endif//ccr2017-12-22<<<<<<<<<<<<
    if (ApplVar.Key.Code < 300)    /*    256 to 299 not used     */
        ApplVar.ErrorNumber=ERROR_ID(CWXXI42);  //   �Ƿ�������  //
    else if (ApplVar.FInv && ApplVar.Key.Code < PLU1 && ApplVar.Key.Code != SUB && ApplVar.Key.Code != CLEAR
             && ApplVar.Key.Code != SUB1 && ApplVar.Key.Code != MULT
             && (ApplVar.Key.Code < LEVEL1 || ApplVar.Key.Code > ARTLEVEL9) && ApplVar.Key.Code != LEVEL
             && ApplVar.Key.Code != ARTLEVEL)
        ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
#if !defined(CASE_EURO) //!!! GREECE_ONLY !!!
    else if ((ApplVar.KeyNo==UPKey) //ccr2014-08-15 �����ͻ||ApplVar.KeyNo==DOWNKey)
             && ApplVar.FRegi && Appl_EntryCounter==0)
    /* Ϊ�����������,ֻ�ڴ������վݺ�����ô˹��� */
     {
        if (ApplVar.KeyNo==UPKey)
            Display_RGBuf(-1);
        else
            Display_RGBuf(1);
     }
#endif
    else if (ApplVar.Key.Code < CORREC + 100)    //  correction functions 300 - 399 //
        Correction();
    else if (ApplVar.Key.Code < CURR + 100)    /*    currency functions 400 - 499     */
        Currency();
    else if (ApplVar.Key.Code < DISC + 100)    /*    discount functions 500 - 599     */
        Discount();
    else if (ApplVar.Key.Code < DRAW + 100)    /*    drawer functions 600 - 699     */
        Drawer();
    else if (ApplVar.Key.Code < PBF + 100)     /*    pb functions 700 - 799     */
        PbFunction();
    else if (ApplVar.Key.Code < PORA + 100)    /*    ApplVar.PoRa functions 800 - 899     */
        PaidOutRa();
    else if (ApplVar.Key.Code < TEND + 100)   /*    Tendering Functions 900 - 999     */
        Tender();
    else if (ApplVar.Key.Code < MODI + 1000)    /*    Modifiers  1000 - 1999     */
        GetModifier();
    else if (ApplVar.Key.Code < FIXED + 99)   /*    fixed functions 2000 - 2099     */
    {
        Fixed();
        return;                        /*    don't clear entry     */
    }
    else if (ApplVar.Key.Code >= SALPER && ApplVar.Key.Code < SALPER+256)
        SelectSalPer();
    else if (ApplVar.Key.Code < CLERK)
        ApplVar.ErrorNumber=ERROR_ID(CWXXI42);
    else if (ApplVar.Key.Code < OFFER)
        SelectClerk(0);
    else if (ApplVar.Key.Code >= DEPT && ApplVar.Key.Code < PLU1)
        ProcessDept();
    else if (ApplVar.Key.Code >= PLU1 && ApplVar.Key.Code < PLU3)
        ProcessPlu();
/*     else if (ApplVar.Key.Code < PLU3)
else if (ApplVar.Key.Code < 60000)
    */
    else
        ApplVar.ErrorNumber=ERROR_ID(CWXXI42);
    ClearEntry();
#endif
}

/*---------------------------------------------------------------------
  ����:true-��Ч����
    ApplVar.KeyNo:�ʹ��������
    ApplVar.Key.Code:�ͳ�������Ӧ�Ĺ�����
      false-��Ч����
---------------------------------------------------------------------*/
WORD KeyInput()
{
#if DD_FISPRINTER==0
    BYTE keyno;

    if (!KbHit() && !GetInputByListItems() )//ccr2017-05-09��ListItems�����л�ȡ���ⰴ��
    {
           return 0;
    }

    ApplVar.FBarcode = 0;
    keyno = Getch();        /*    read key     */

#if defined(CASE_EURO) //!!! GREECE_ONLY !!!//ccr2017-12-18>>>>>>>>>
    if (ApplVar.CentralLock == MG || ApplVar.CentralLock == RG)
        keyno=KeyOfSecondLayer(keyno);
#endif//ccr2017-12-18<<<<<<<<<

//ccr2017-12-18    if (keyno != DATEKey || Appl_EntryCounter>0)
    {
        //ccr20130308>>>>>>>>>>>>>>>>>>>>
        if (ACTIVE && InActive > ACTIVE && ApplVar.LCD_Operator[0] && keyno==CLEARKey)
        {//�������������Ҵ��ڰ�����ʱ��ʾʱ��ģʽ���������ʾʱ���ģʽ���ָ�֮ǰ����ʾ���ݣ�
            PutsO(ApplVar.LCD_Operator);
            ApplVar.LCD_Operator[0]=0;
#if (DD_LCD_1601==1)
            //     PutsC(ApplVar.LCD_Customer);
#endif
            return 0;
        }
        //<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
    }

    if (keyno < 64)                 /* if keyno larger 63 then Lock Code */
    {
        ApplVar.KeyNo = keyno;
        if (ApplVar.AP.KeyTable[ApplVar.KeyNo] != CLEAR)
            ApplVar.OldKey.Code = ApplVar.Key.Code;       /* save previous key */
        ApplVar.Key.Code = ApplVar.AP.KeyTable[ApplVar.KeyNo];
        keyno = CheckMode();
        if (keyno || (ApplVar.CentralLock != MG && ApplVar.CentralLock != RG && CheckFirmKey()))
            ApplVar.Key.Code = 0;
//     else if (ApplVar.Key.C.High && ApplVar.CentralLock == RG && ApplVar.Key.Code != CLEAR)    /* function ? */
//     {
//         if (ApplVar.AP.Manager[keyno >> 3] & (0x01 << (keyno & 7)))//??????keyno��CheckMode()���ı�,�˴��к���????
//             ApplVar.ErrorNumber=ERROR_ID(CWXXI28);
//         else
//             return TRUE;
//     }
        else
            return TRUE;
    }
    //else
//    if (keyno > 64 && !ApplVar.ErrorNumber)
// {
//		HEXtoASC(sBuf,&keyno,1);sBuf[2] = 0;
//		PutsO(sBuf);
//	}
    CheckError(0);

#endif
    return FALSE;

}


/* return 1 incase of error */
BYTE AmtInputMask()
{
/*    if (Appl_EntryCounter && BIT(ROUNDMASK, BIT0))
    {       // entry must end with 0 or 5
        switch(ApplVar.Entry.Value[0] & 0x0f)
        {
            case 0:
            case 5:
                break;
            default:
                ApplVar.ErrorNumber=ERROR_ID(CWXXI01);
                return 1;
        }
    }*/
    return 0;
}

//-----------------------------------------------------------
// Funzione OutPrint
// -----------------
//
// Lancia un comando di stampa standard sulla stampante
//
// Inputs :   Cmd              = Comando di stampa (CMDP_xx)
//         *Line            = Pointer a linea di dati da stampare
//


void OutPrint(WORD Cmd, CONSTBYTE *Line)
{

    if (!MyFlags( CLOSEPRNONPB+CLOSEPRINT))     //lyq20040223 added for control the printing of pb message
    {
#if (defined(FOR_DEBUG) && !defined(DEBUGBYPC))
        if (Line)
        {
            SendString(Line,PRTLEN);
            xputc('\n');
        }
#endif
        if (Line && Line[0]=='@')
        {
#if !defined(DEBUGBYPC)
            OutPrintEx(CMDP_DRJ, Line+1, 0);
#else
//         Cmd = CMDP_DRJ;

            OutPrintEx(Cmd, Line+1, 0);
#endif
#ifdef CASE_FATFS_EJ
            StoreEJData((BYTE*)Line+1);
#endif

        }
        else
        {
#if !defined(DEBUGBYPC)
            OutPrintEx(Cmd | CMDP_LFRJ, Line, 0);
#else
            Cmd |= CMDP_LFRJ;
            OutPrintEx(Cmd, Line, 0);
#endif
#ifdef CASE_FATFS_EJ
            StoreEJData((BYTE*)Line);
#endif

        }
    }
}




//
// Funzione OutPrintEx
// -------------------
//
// Lancia un comando di stampa esteso sulle stampanti interne (Scontrino e/o Giornale)
//
// Inputs :   Cmd              = Comando di stampa (CMDP_xx)
//         *Line            = Pointer a linea di dati da stampare
//         DotLinesBlank    = #dot line post-stampa addizionali
//
#if (!defined(DEBUGBYPC))
void OutPrintEx(WORD Cmd, CONSTBYTE *Line, WORD DotLinesBlank)
{
#if (PC_EMUKEY)
    if (!FisTestTask.PrnOFF || !FisTestTask.Going)
#endif
        if (!MyFlags( CLOSEPRNONPB+CLOSEPRINT))     //lyq20040223 added for control the printing of pb message
            Bios(BiosCmd_PrintX, (void*)Line, Cmd , DotLinesBlank);
}

#endif //    DEBUGBYPC

//    Reset the keyboard if user redefine a new function on the masked KEY
//    pReset:0 Set the mask if needed
//        1 set the mask alwasy
void MaskKeyBoard(char pReset)
{
    short i,j;
    char sMask[KEY_MAXKEYS];
    char sReset = pReset;

    memset(sMask,0,KEY_MAXKEYS);
    for (i=0;i<KEY_MAXKEYS;i++)
    {
        if (ApplVar.AP.KeyTable[i]!=0 && ApplVar.AP.KeyTable[i]!=0xffff)
        {
            j = i;
            sMask[j] = j+1;
            sReset = 1;
        }
    }

    if (sReset)
    {
        Bios_SetKeyboard(0, KEY_MAXKEYS,  (CONSTBYTE*)&sMask, 1);
    }
}


#if !defined(DEBUGBYPC)


/*********************************************************************************************************
** Function name:       main
** Descriptions:        �û�������ں���(ʹ���ж�ʱ�������OS���ж����ú���,��IRQ.h)
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
extern void STM32_Initial(void);

int main(void)
{

    InitMonitor(MONITOR_RS232);
    STM32_Initial();
    Print_Initial();

    MACSwitch=Bios_TestMAC();

    mainTask(0);

}
#endif
/*********************************************************************************************************
  End Of File
*********************************************************************************************************/


