#define PROGDUMP_C
#include "king.h"				/* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"


//liuj 0606
void DumpDept()
{
BCD bcdtemp;
	if(Appl_ProgNumber >=0  )
        {

	ApplVar.DeptNumber = Appl_ProgNumber;
	if(ApplVar.DeptNumber > ApplVar.AP.Dept.Number)
		return ;
	ReadDept();

	memset(SysBuf,' ',sizeof(SysBuf));
#if DD_ZIP
	CopyFrStr(SysBuf, Prompt.LineCap[Line_DEPART]);
	WORDtoASC(SysBuf + 15, Appl_ProgNumber + 1);
	SysBuf[12]='#';

#else
	CopyFrStr(SysBuf, Prompt.LineCap[Line_DEPART]);
	WORDtoASC(SysBuf + 8, Appl_ProgNumber + 1);
	SysBuf[6]='#';

#endif
	RJPrint(0, SysBuf);

	RJPrint(0, ApplVar.Dept.Name);

	memset(SysBuf,' ',sizeof(SysBuf));
	bcdtemp = ZERO;
	CopyFrStr(SysBuf, Prompt.Caption[ItemPrompt4]);
	memcpy(bcdtemp.Value, ApplVar.Dept.Price,5);
	FormatAmt(SysBuf+18, &bcdtemp);
	RJPrint(0, SysBuf);

	memset(SysBuf,' ',sizeof(SysBuf));
	bcdtemp = ZERO;
	CopyFrStr(SysBuf+1, Prompt.LineCap[Line_MAX]);

	memcpy(bcdtemp.Value, ApplVar.Dept.PriceMax,5);
	FormatAmt(SysBuf+18, &bcdtemp);
	RJPrint(0, SysBuf);


	memset(SysBuf,' ',sizeof(SysBuf));
	CopyFrStr(SysBuf, Prompt.Caption[ItemPrompt27]);
	OptionToStr(ApplVar.Dept.Tax,SysBuf+8);

	RJPrint(0,SysBuf);

	memset(SysBuf,' ',sizeof(SysBuf));
	CopyFrStr(SysBuf+1, Prompt.Caption[ItemPrompt50]);
	OptionToStr(ApplVar.Dept.Options,SysBuf+8);

	RJPrint(0,SysBuf);

	RFeed(1);

	}

}

void DumpTax()
{
BCD bcdtemp;
BYTE i;

	for(i=0;i<ApplVar.AP.Tax.Number;i++)
		{
			ApplVar.TaxNumber = i;
			ReadTax();

			memset(SysBuf,' ',sizeof(SysBuf));
			CopyFrStr(SysBuf, Prompt.Caption[ItemPrompt27]);
			WORDtoASC(SysBuf + 8, i + 1);
			SysBuf[6]='#';
			RJPrint(0, SysBuf);

			RJPrint(0, ApplVar.Tax.Name);

			memset(SysBuf,' ',sizeof(SysBuf));
			bcdtemp = ZERO;
			CopyFrStr(SysBuf+1, Prompt.LineCap[Line_TAXRATE]);
			memcpy(bcdtemp.Value, ApplVar.Tax.Rate,3);
			FormatAmt(SysBuf+18, &bcdtemp);
			RJPrint(0, SysBuf);


			memset(SysBuf,' ',sizeof(SysBuf));
			CopyFrStr(SysBuf+1, Prompt.Caption[ItemPrompt50]);
			OptionToStr(ApplVar.Tax.Options,SysBuf+10);

			RJPrint(0,SysBuf);
			RFeed(1);
		}


}

//liuj 0606

#if (DD_FISPRINTER==0 && defined(ID_DUMP))

void ProgramDump()
{
	BYTE s_type= Appl_ProgType;
	WORD s_number= Appl_ProgNumber;
    BYTE s_ProgStart =Appl_ProgStart;
    WORD s_ProgLine =Appl_ProgLine;
    BYTE s_BitNumber =Appl_BitNumber;
    int l,i,j;

	if (!(Appl_ProgType==SETPLU ||
		  Appl_ProgType==SETDEPT ||
		  Appl_ProgType==SETHEAD ||
		  Appl_ProgType==SETTRAIL ||
#if (DD_SETSLIP)
		  Appl_ProgType==SETSHEAD ||
#endif
		  Appl_ProgType==SETMODIF ||
		  Appl_ProgType==SETTAX ||
		  Appl_ProgType==SETTEND ||
		  Appl_ProgType==SETDISC ||
		  Appl_ProgType==SETCLERK ||
		  Appl_ProgType==SETSYSFLAG
		))
	{//ccr2017-05-10
		return;
	}
	if (!Appl_ProgStart) /* dump all */
	{
		Appl_ProgNumber = 0;
		Appl_NumberEntry = 0xffff;
	}
	Appl_ProgLine = 1;
	ApplVar.PrintLayOut = 0x02;
	Appl_ProgStart = 2;      /* indicate program dump */
	Appl_EntryCounter = 0;
/*	if (Appl_NumberEntry)   //liuj 0531 PM
		Appl_NumberEntry--;
	else   */
		Appl_NumberEntry = Appl_ProgNumber;

    while(Appl_ProgNumber == Appl_NumberEntry)	//liuj 0601
	{
		if (DisplayOption(false) && !ApplVar.ErrorNumber && Appl_ProgLine)//ccr2017-05-10
		{
		  	if (Appl_ProgNumber > Appl_NumberEntry && (Appl_NumberEntry > 0))        //liuj 0603
				break;
			if (Appl_ProgLine > 1)
			{
				MemSet(SysBuf, PRTLEN, ' ');
#if (!DISP2LINES)
                memcpy(SysBuf, ProgLineMes, sizeof(ProgLineMes));
#else
				l=strlen(ProgLine1Mes)-1;
				if (l>=sizeof(ProgLine1Mes)) l=sizeof(ProgLine1Mes)-1;
				for (;l>=0;l--)
				{
					if (ProgLine1Mes[l]!=' ')
						break;
				}
				ProgLine1Mes[++l]=0;

                for (j=0;j<strlen(ProgLine1Mes);j++)
                {
                    if (ProgLine1Mes[j]!=' ')
                        break;
                }
                i=strlen(&ProgLine1Mes[j]);

                if (Appl_ProgType == SETPLU && Appl_ProgLine==2 ||
					Appl_ProgType==SETHEAD ||
					Appl_ProgType==SETTRAIL ||
#if (DD_SETSLIP)
					Appl_ProgType==SETSHEAD ||
#endif
					Appl_ProgType==SETMODIF
					)
                {
                  l=0;
                }
                else
                {
					l=strlen(ProgLineMes)-1;
					if (l>=sizeof(ProgLineMes)) l=sizeof(ProgLineMes)-1;

					  for (;l>=0;l--)
					  {
						  if (ProgLineMes[l]!=' ')
							  break;
					  }
					  ProgLineMes[++l]=0;
					  CopyFrStr(SysBuf, ProgLineMes);
					  if (Appl_ProgLine>2 && (l+i)<PRTLEN)
					  {
						  l=32-i;
					  }
                }
				memcpy(SysBuf + l, ProgLine1Mes+j, i);
#endif
				SysBuf[PRTLEN]=0;
				PrintStr(SysBuf);
			}
			else
			{
				PrintStr(ProgLineMes);
				if (Appl_ProgType == SETPLU)      /* PLU ? */
				{
					if (Appl_ProgLine == 1 && ApplVar.AP.Plu.RandomSize) /* random number ?*/
					{
						SysBuf[0] = 'R';
						SysBuf[1] = '#';
						HEXtoASC(SysBuf+2, ApplVar.Plu.Random, ApplVar.AP.Plu.RandomSize);
						SysBuf[ApplVar.AP.Plu.RandomSize * 2 + 2] = 0;
						PrintStr(SysBuf);
					}
				}
			}
		}
		else
			break;
//		if (Appl_ProgType == SETSYSFLAG)
//			Appl_ProgNumber++;
//		else
		{
			Appl_ProgLine++;
			Appl_BitNumber = 0;  // liuj 0602
		}
		if (Appl_ProgType == SETSYSFLAG && Appl_ProgLine>=SYSUSED+2)
            break;

  		if (KbHit() && Getch() == CLEARKey)
			break;      /* clear key means break */
	}
	if(BIT(ARROWS, BIT0))        /* receipt on ?*/
		RFeed(2);
	Appl_ProgNumber = s_number;
	Appl_ProgType = s_type;
    Appl_ProgStart =s_ProgStart;
    Appl_ProgLine  =s_ProgLine;
    Appl_BitNumber =s_BitNumber;

    ApplVar.ErrorNumber=0;
}
#endif
