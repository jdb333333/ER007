/*********************************************************************************
 �˵���ʾ�Ͳ�����������
  �����д:�³���
  ��д����:2004��2����7��
  ��������:2004��10��
  �޸�����:2013��6��
*********************************************************************************/
#define MENU_C
#include "king.h"                               /* Kingtron library and I/O routines */
#include "exthead.h"
#include "exth.h"
#include "Message.h"


//>>>>>>>>>>>>>>>ccr2016-01-11>>>�����ӵĹ���>>>>>>>>>>>>>>>>>>>>>>>>>>>>
//ccr2016-01-12>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

void ReadHeader()
{
    strcpy(ListRecord.Name,ApplVar.TXT.Header[ListRecord.Number]);
}
void ReadTrail()
{
    strcpy(ListRecord.Name,ApplVar.TXT.Trailer[ListRecord.Number]);
}
void ReadSlipHeader()
{
    strcpy(ListRecord.Name,ApplVar.TXT.SlipHeader[ListRecord.Number]);
}

void ReadFlagsList()
{
    BYTE BitV, i,BitN;
    BYTE updownkey;
    WORD   sIdx;
    ULONG  sVal;

    if (ListRecord.Number<SYSUSED)
    {
        sIdx = SysFlagUsed[ListRecord.Number].Index;
        memset(ListRecord.Name,' ',sizeof(ListRecord.Name));
        CopyFrStr(ListRecord.Name,SysFlagUsed[ListRecord.Number].Name);

        if (SysFlagUsed[ListRecord.Number].Bit)
        {//Ϊ��־λ,����Yes��No
            BitV = BIT0<<(SysFlagUsed[ListRecord.Number].Bit-1);

            if ((ApplVar.AP.Flag[sIdx] & BitV))
                BitN = 'y' ^ SysFlagUsed[ListRecord.Number].Invert;
            else
                BitN = 'n' ^ SysFlagUsed[ListRecord.Number].Invert;

            if (BitN == 'y')
                strcpy(ListRecord.Name+SCREENWD-3,Prompt.LineCap[Line_YES]);
            else
                strcpy(ListRecord.Name+SCREENWD-3,Prompt.LineCap[Line_NO]);
        }
        else
        {//Ϊ��ֵ��,������ֵ
            if (sIdx==FLAGRECEIPTMAX)
            {//Ϊ�վ������
                sVal = ReceiptMAX;
            }
            else if (sIdx==62)// || sIdx==CONTRAST)//�����վݴ�����Աȶ�
            {//��4λΪ��־,��4Ϊ��ֵ  //
                sVal = ApplVar.AP.Flag[sIdx] & 0x0f;   //���ݱ�־λ
            }
            else
                sVal = ApplVar.AP.Flag[sIdx];
            ULongtoASC(ListRecord.Name+SCREENWD-1, sVal);
            //ccr2016-08-03>>>>>>>>>>>>>>>>>>
            if ((sIdx==10 || sIdx==11) && sVal && ListRecord.Name[SCREENWD-6]==' ')//PREFIX_1,PREFIX_2
                ListRecord.Name[SCREENWD-5]=(sVal & 0xff);
            //ccr2016-08-03<<<<<<<<<<<<<<<<<

            ListRecord.Name[SCREENWD] = 0;
        }
    }
}

void BackupScreen(BYTE a)
{
}
void RecallScreen()
{
}
#if !defined(FOR_FLASHRAM)//ccr2017-10-13 testonly
void mClearScreen()
{
    char buf[DISLEN+1];
    memset(buf,' ',sizeof(buf));
    buf[DISLEN]=0;
    PutsO(buf);
#if ((DISP2LINES))//ccr2017-11-29 && (LISTLINES>1))
    Puts1(buf);
#endif
}
#endif
void ReadKP()
{
    sprintf(ListRecord.Name,"%s#%d",Msg[SETKP].str,ListRecord.Number+1);
//    strcpy(ListRecord.Name,ApplVar.TXT.Header[ListRecord.Number]);
}
void ListICBlock()
{
}
void ReadGraphic()
{
}
void ReadXZReport()
{
}
void ReadRepUnit()
{
}
void ReadZone()
{
}
void ReadPBTable()
{
}


//......................................................................
TListRecord ListRecord;//������Name���ļ�,�����û������


TVirtualInput VirtualInput;

CONST WORD  MaxNum8=8,//������ӡ,�վ�Ʊͷ
            MaxNum6=6,//�վ�Ʊβ,Ʊ��Ʊͷ
            MaxKPNum=KPRNMAX,//
//ccr2006-12-22            MaxNumFL=FUNCLOOK_KEYS,
            MaxNumGR=GRAFESTMAX,
//ccr2006-12-22            MaxNumMG=MGFUNCS,//=7
            MaxNumXZ=XZNUM,
            MaxNumFlags=SYSUSED,
//ccr2006-12-22            MaxKeyDes=KEYDESMAX,
            MaxNum10=10,//ʮ������
            MaxRepType=15;//������Ԫ
//ccr2006-12-22            MaxNumKM=KEYMACROMAX;
#define EJInfoMAX   14
//...............................................................................
int ListID;       //ָ��ListDef�еĵ�ǰ��¼

CONST TListDef ListDef[]={//���ڲ������ڴ˱��е���Ŀ,��ʾ�޼�¼����,ֱ�ӽ������ý���
    //***********************************************************************
    { SETPERIPHERALS,(*ReadFromMsg),(char*)ListRecord.Name,     (WORD*)&ListRecord.Number,  (WORD*)SETPERIPHERAL_ITEMS,SETPORT1,0},//ccr2017-08-04 �����������ù���
    { xGENERALPARAM,(*ReadFromMsg), (char*)ListRecord.Name,     (WORD*)&ListRecord.Number,  (WORD*)ITEMS_xPARAM,  xLISTPLU,0},  //X���µ�xGENERALPARAM���ܲ˵�
    { zFMREADZ_Z,   (*ReadFromMsg), (char*)ListRecord.Name,     (WORD*)&ListRecord.Number,  (WORD*)ITEMS_fmPARAM, fmSYNOPSIS,0},  //Z���µ�Fm READ Z-Z/DATE���ܲ˵�
    { AUX_EXPLOREEJ,(*ReadFromMsg), (char*)ListRecord.Name,     (WORD*)&ListRecord.Number,  (WORD*)ITEMS_EJLOG,   EJPrintReceipt,0},  //AUX_EXPLOREEJ���ܲ˵�
    { EJBYDATETIME, (*ReadFromMsg), (char*)ListRecord.Name,     (WORD*)&ListRecord.Number,  (WORD*)ITEMS_EJRANGE, EJBYDATETIME,0},  //AUX_EXPLOREEJ���ܲ˵�
    { SETPROGRAM   ,(*ReadFromMsg), (char*)ListRecord.Name,     (WORD*)&ListRecord.Number,  (WORD*)SETUPMAX,      SETUPITEM1ST,0},  //ѡ���տ�������ļ��˵�
    { SETECRMODE,   (*ReadFromMsg), (char*)ListRecord.Name,     (WORD*)&ListRecord.Number,  (WORD*)ITEMS_MODE,    REGMODE1ST,0},  //ѡ���տ������ģʽ
    { SETAUXFUNCS,  (*ReadFromMsg), (char*)ListRecord.Name,     (WORD*)&ListRecord.Number,  (WORD*)AUX_FUNCITEMS, AUX_FUNC1ST,0},  //ETHERNET ��������
    { SETTEST,      (*ReadFromMsg), (char*)ListRecord.Name,     (WORD*)&ListRecord.Number,  (WORD*)TEST_FUNCITEMS,TEST_FUNC1ST,0},  //ϵͳ���Թ���
#if defined(CASE_GPRS)
    { SETGPRSFUNC,   (*ReadFromMsg), (char*)ListRecord.Name,    (WORD*)&ListRecord.Number,   (WORD*)gprsMAINITEMS,GPRSFUNC1ST,0},  //GPRS ��������
#endif
#if defined(CASE_ETHERNET)
    { SETETHERNETFUNC,   (*ReadFromMsg), (char*)ListRecord.Name,    (WORD*)&ListRecord.Number,   (WORD*)net_MAINITEMS,ETHERNETFUNC1ST,0},  //ETHERNET ��������
#endif
    { SETGROUP  ,(*ReadGroup),  (char*)ApplVar.Group.Name, (WORD*)&ApplVar.GroupNumber,  (WORD*)&ApplVar.AP.Group.Number,0,0},   //���� //ccr2014-11-11 NEWSETUP Step-3<<<<<<
    { SETDEPT   ,(*ReadDept),   (char*)ApplVar.Dept.Name,  (WORD*)&ApplVar.DeptNumber,   (WORD*)&ApplVar.AP.Dept.Number,0,0},    //����
    { SETPLU    ,(*ReadPlu),    (char*)ApplVar.Plu.Name,   (WORD*)&ApplVar.PluNumber,    (WORD*)&ApplVar.AP.Plu.RNumber,0,0},     //��Ʒ
    { SETPLUSTOCK,(*ReadPlu),    (char*)ApplVar.Plu.Name,   (WORD*)&ApplVar.PluNumber,    (WORD*)&ApplVar.AP.Plu.RNumber,0,0},     //��Ʒ

/* MENUCOMMAX:ͨѶ������˵�*/
//{ SETCOMPUTER  ,(*),ApplVar..Name,&number,&Max,0,0},	//ͨѶ��1
//{ SETBARCODE  ,(*),ApplVar..Name,&number,&Max,0,0},//ͨѶ��2
//{ SETBALANCE  ,(*),ApplVar..Name,&number,&Max,0,0},//ͨѶ��3
//{ SETPORT4  ,(*),ApplVar..Name,&number,&Max,0,0},//ͨѶ��4
//{ SETNETWORK		,(*),ApplVar..Name,&number,&Max,0,0},//IP��ַ
//{ SETSP     ,(*),ApplVar..Name,&number,&Max,0,0},		//Ʊ�ݴ�ӡ
    { SETKP     ,(*ReadKP),     (char*)ListRecord.Name,     (WORD*)&ListRecord.Number,      (WORD*)&MaxKPNum,0,0},//������ӡ

/* MENUMANMAX:���۹�������*/
#if offNumber
    { SETOFF    ,(*ReadOFFPrice),(char*)ApplVar.OFFPrice.Name,(WORD*)&ApplVar.OFFNumber,    (WORD*)&ApplVar.AP.OFFPrice.Number,0,0},//�Żݼ�
#endif
//{ SETPROM   ,(*),ApplVar..Name,&number,&Max,0,0},//�н�����
    { SETDISC   ,(*ReadDisc),   (char*)ApplVar.Disc.Name,   (WORD*)&ApplVar.DiscNumber,     (WORD*)&ApplVar.AP.Disc.Number,0,0},          //***BYTE //�ۿ�
    { SETPORA   ,(*ReadPoRa),   (char*)ApplVar.PoRa.Name,   (WORD*)&ApplVar.PoRaNumber,     (WORD*)&ApplVar.AP.PoRa.Number,0,0},          //***BYTE //�������
    { SETCORR   ,(*ReadCorrec), (char*)ApplVar.Correc.Name, (WORD*)&ApplVar.CorrecNumber,   (WORD*)&ApplVar.AP.Correc.Number,0,0},  //***BYTE //��������
    { SETTEND   ,(*ReadTender), (char*)ApplVar.Tend.Name,   (WORD*)&ApplVar.TendNumber,     (WORD*)&ApplVar.AP.Tend.Number,0,0},            //***BYTE //���ʽ
    { SETCURR   ,(*ReadCurr),   (char*)ApplVar.Curr.Name,   (WORD*)&ApplVar.CurrNumber,     (WORD*)&ApplVar.AP.Curr.Number,0,0},         //***BYTE //���
    { SETDRAWER ,(*ReadDrawer), (char*)ApplVar.Draw.Name,   (WORD*)&ApplVar.DrawNumber ,    (WORD*)&ApplVar.AP.Draw.Number,0,0},           //***BYTE //Ǯ��
#if !defined(CASE_FORHANZI)
    { SETTAX    ,(*ReadTax),    (char*)ApplVar.Tax.Name,    (WORD*)&ApplVar.TaxNumber,      (WORD*)&ApplVar.AP.Tax.Number,0,0},  //***BYTE//˰��
#endif
/* MENUICCMAX:IC������*/
//{ SETVIPIC     ,(*),ApplVar..Name,&number,&Max,0,0},//IC������
// { SETBLOCKIC,(*ListICBlock),(char*)ListRecord.Name,     (WORD*)&ApplVar.ICBlockNumber,  (WORD*)&ApplVar.AP.ICBlock.Number,0,0},//IC����ʧ
//{ SETPRINTIC,(*),ApplVar..Name,&number,&Max,0,0},	//��ӡ����Ϣ

/* MENUTICMAX:ƱͷƱβ*/
    { SETHEAD   ,(*ReadHeader), (char*)ListRecord.Name,     (WORD*)&ListRecord.Number,      (WORD*)&MaxNum8,0,0},    //�վ�Ʊͷ
    { SETTRAIL  ,(*ReadTrail),  (char*)ListRecord.Name,     (WORD*)&ListRecord.Number,      (WORD*)&MaxNum6,0,0},//�վ�Ʊβ
#if (DD_SETSLIP)
    { SETSHEAD  ,(*ReadSlipHeader),(char*)ListRecord.Name,  (WORD*)&ListRecord.Number,      (WORD*)&MaxNum6,0,0},    //Ʊ��Ʊͷ
#endif
    { SETGRAP   ,(*ReadGraphic),(char*)ListRecord.Name,     (WORD*)&ListRecord.Number,      (WORD*)&MaxNumGR,0,0},  //ƱβͼƬ
//{ SETPRTGRAP,(*),ApplVar..Name,&number,&Max,0,0},		//��ӡͼƬ

/* MENUREPMAX:��������*/
#if (DD_SETREPORT)
    { SETREPORT ,(*ReadXZReport),(char*)ListRecord.Name,    (WORD*)&ListRecord.Number,      (WORD*)&MaxNumXZ,0,0},   //���ñ�������
    { SETREPTYPE,(*ReadRepUnit),(char*)ListRecord.Name,     (WORD*)&ListRecord.Number,      (WORD*)&MaxRepType,0,0},  //������Ԫ
#endif
    { SETZONES  ,(*ReadZone),   (char*)ListRecord.Name,     (WORD*)&ListRecord.Number,      (WORD*)&ApplVar.AP.Zone.Number,0,0},    //***BYTE  //����ʱ������
//{ SETCLRREP ,(*),ApplVar..Name,&number,&Max,0,0},	//���屨��
//{ SETPRTJOUR,(*),ApplVar..Name,&number,&Max,0,0},	//��ӡ��ˮ

/* MENUTBLMAX:��������*/
#if (DD_FISPRINTER==0 && DD_DISABLEPBF==0)
    { SETPBINF  ,(*ReadPBTable),(char*)ApplVar.PB.Text,     (WORD*)&ApplVar.PbNumber,       (WORD*)&ApplVar.AP.Pb.NumberOfPb,0,0},   //��̨
    { SETPBF    ,(*ReadPbF),    (char*)ApplVar.PbF.Name,    (WORD*)&ApplVar.PbFNumber,      (WORD*)&ApplVar.AP.Pb.Number,0,0},   //***BYTE //��������
#endif
    { SETMODIF  ,(*ReadModi),   (char*)ApplVar.Modi.Name,   (WORD*)&ApplVar.ModiNumber ,    (WORD*)&ApplVar.AP.Modi.Number,0,0},           //�˵�˵��
#if (agreeNumber)
//ccr2006-12-22    { SETAGREE  ,(*ReadAgree),  (char*)ApplVar.Agree.Name,  (WORD*)&ApplVar.AgreeNumber ,   (WORD*)&ApplVar.AP.Agree.Number,0,0},//ǩ��
#endif

/* MENUPWDMAX:Ȩ������*/
    { SETCLERK  ,(*ReadClerk),  (char*)ApplVar.Clerk.Name,  (WORD*)&ApplVar.ClerkNumber ,   (WORD*)&ApplVar.AP.Clerk.Number,0,0},   //(ApplVar.ClerkNumber>=1)�տ�Ա
#if (salNumber)
    { SETSALER  ,(*ReadSalPer), (char*)ApplVar.SalPer.Name, (WORD*)&ApplVar.SalPerNumber ,  (WORD*)&ApplVar.AP.SalPer.Number,0,0},  //(ApplVar.SalPerNumber>=1)ӪҵԱ
#endif
    { SETSYSFLAG,(*ReadFlagsList),(char*)ListRecord.Name,   (WORD*)&ListRecord.Number,      (WORD*)&MaxNumFlags,0,(*ProgSysFlagNew)},  //ccr2017-05-08 ϵͳ����
//ccr2006-12-22    { SETPOINTTYPE,(*ReadFromMsg),(char*)ListRecord.Name,   (WORD*)&ListRecord.Number,      (WORD*)MsgPOINTMAX,MsgPOINTTYPE1,0},  //С����ʽѡ��
//ccr2006-12-22    { LISTMGFUNC,(*ReadFromMsg), (char*)ListRecord.Name,    (WORD*)&ListRecord.Number,      (WORD*)MsgMGMMAX,MsgMGADDINV,0},  //��������ѡ��С�ƹ���
//ccr2006-12-22    { LISTKEYDES,(*ReadKeyDesList),(char*)ListRecord.Name,  (WORD*)&ListRecord.Number,      (WORD*)&MaxKeyDes,0,0},  //���̹������б�
//ccr2006-12-22    { SETTEST,   (*ReadFromMsg), (char*)ListRecord.Name,    (WORD*)&ListRecord.Number,      (WORD*)MENUTSTMAX,SETTSTDISP,0},  //ϵͳ���Թ���
//ccr2006-12-22    { LISTNUMRIC,(*ReadNumric),  (char*)ListRecord.Name,    (WORD*)&ListRecord.Number,      (WORD*)&MaxNum10,0,0},  //ʮ������
/* ������־��ѯ��ӡ */
//ccr2006-12-22    { MsgALLLOG,  (*ReadFromMsg), (char*)ListRecord.Name,    (WORD*)&ListRecord.Number,      (WORD*)MsgPRNLOGMAX,MsgALLLOG,0},  //��ӡ���ۼ�¼
//ccr2006-12-22    { MsgALLCASH,(*ReadFromMsg), (char*)ListRecord.Name,    (WORD*)&ListRecord.Number,      (WORD*)2,MsgALLCASH,0},  //ѡ�񸶿ʽ
//ccr2006-12-22    { MsgALLDEPT,(*ReadFromMsg), (char*)ListRecord.Name,    (WORD*)&ListRecord.Number,      (WORD*)2,MsgALLDEPT,0},  //ѡ����
//ccr2006-12-22    { MsgALLPLU, (*ReadFromMsg), (char*)ListRecord.Name,    (WORD*)&ListRecord.Number,      (WORD*)2,MsgALLPLU,0},  //ѡ��Ʒ
//ccr2006-12-22    { SETREST,   (*ReadFromMsg), (char*)ListRecord.Name,    (WORD*)&ListRecord.Number,      (WORD*)KEYTYPEMAX,SETREST,0},  //����ģʽѡ��
//ccr2006-12-22    { SETKEYMACRO,(*ReadKeyMacro),(char*)ListRecord.Name,    (WORD*)&ListRecord.Number,     (WORD*)&MaxNumKM,0,0},  //���̺궨��
/* ѡ���ܱ��еĹ��� */
//ccr2006-12-22    { FUNCLOOK1, (*ReadFuncLook),  (char*)ListRecord.Name,    (WORD*)&ListRecord.Number,    (WORD*)&MaxNumFL,0,0},  //���ܱ�
/* EJ��ѯ��ӡ */
#if (defined(CASE_FATFS_EJ) || defined(CASE_EJFLASH))
//ccr2006-12-22    { MsgEJMESSAGES, (*ReadFromMsg), (char*)ListRecord.Name,    (WORD*)&ListRecord.Number,  (WORD*)MsgPRNEJMAX,MsgEJMESSAGES,0},  //��ӡEJ��¼
//ccr2006-12-22    { MENUXEJOURNAL, (*ReadEJInfo), (char*)ListRecord.Name,    (WORD*)&ListRecord.Number,   (WORD*)EJInfoMAX,MENUXEJOURNAL,0},  //��ӡEJ��¼
#endif
    { 0xffff  ,0,0,0,0,0,0},        //����
};
//****************************************************************************************
/**
 * ����Ҫ��ȡ�ļ�¼��
 *
 * @author EutronSoftware (2016-01-14)
 *
 * @param idx :��¼��ָ��
 * @param val :��¼��
 * @param b_w :=trueΪBYTE����,=falseΪWORD����
 */
void SetRecIndex(WORD *idx,WORD val,BYTE b_w)
{
    if (b_w)
        *(BYTE*)idx=val;
    else
        *idx=val;
}

void IncRecIndex(WORD *idx,BYTE b_w)
{
    if (b_w)
        (*(BYTE*)idx)++;
    else
        (*idx)++;
}
void DecRecIndex(WORD *idx,BYTE b_w)
{
    if (b_w)
        (*(BYTE*)idx)--;
    else
        (*idx)--;
}

WORD ReadRecIndex(WORD *idx,BYTE b_w)
{
    if (b_w)
        return (*(BYTE*)idx);
    else
        return (*idx);
}

void ClearVirtualInput()
{
    VirtualInput.vLen=0;
    VirtualInput.vKey=0xff;
}
/**
 * �������ⰴ��
 *
 * @author EutronSoftware (2016-01-28)
 *
 * @param key :=0xff,��������������
 */
void VirtualInputKey(BYTE key)
{
    VirtualInput.vLen = 0;
    VirtualInput.vKey=key;
}
/**
 *
 *
 * @author EutronSoftware (2016-01-28)
 *
 * @param key :=0xff,��������������
 * @param val :=0xffffʱ,����������
 */
void VirtualInputWORD(BYTE key,WORD val)
{
    if (val!=0xffff)
        VirtualInput.vLen=WORDtoASCL(VirtualInput.vInput,val);
    else
        VirtualInput.vLen = 0;
    VirtualInput.vKey=key;
}
/**
 *
 *
 * @author EutronSoftware (2016-01-28)
 *
 * @param key :=0xff,��������������
 * @param val :�������������
 * @param sLen :������������ݳ���.
 */
void VirtualInputStr(BYTE key,char *val,BYTE sLen)
{
    if (val && sLen)
    {
        if (sLen>sizeof(VirtualInput.vInput))
            sLen=sizeof(VirtualInput.vInput);
        memcpy(VirtualInput.vInput,val,sLen);
        VirtualInput.vLen=sLen;
    }
    else
        VirtualInput.vLen=0;
    VirtualInput.vKey=key;
}

/**
 *
 *
 * @author EutronSoftware (2016-01-28)
 *
 * @return BYTE:�������ⰴ��,=0xffʱ,�����ⰴ��
 */
BYTE CheckVirtualKey()
{
    return VirtualInput.vKey;
}

/**
 * ��ȡ��ListItems���õ�ѡ������
 *
 * @author EutronSoftware (2016-01-14)
 *
 * @return WORD:=0,������;
 *              >0,Ϊ����ļ���+1,Ӧ�ñ�����������KbHit������������,ͬʱ���ú�����������
 */
WORD GetInputByListItems()
{
    if (VirtualInput.vKey!=0xff)
    {
        ClearEntry();
        if (VirtualInput.vLen)
        {
            Appl_EntryCounter = VirtualInput.vLen;
            memcpy(&AtEntryBuffer(Appl_EntryCounter),VirtualInput.vInput, Appl_EntryCounter);
        }
        KeyFrHost=VirtualInput.vKey;
        VirtualInput.vKey=0xff;
        VirtualInput.vLen=0;
        return (KeyFrHost+1);
    }
    else
        return 0;
}
/**
 * ��ȡ��ѡ�����Ŀ���ƴ�
 *
 * @author EutronSoftware (2016-02-15)
 *
 * @return char*
 */
char* GetActiveItemStr()
{
    return VirtualInput.vInput;
}
/*********************************************************
 *
 *
 * @author EutronSoftware (2016-01-26)
 *
 * @param x :�����ʾλ��
 * @param y
 * @param val :���
 *
 * @return int :��ʾ�ļ�¼���λ��
 *********************************************************/
int DispIndex(BYTE x,BYTE y,WORD val)
{
    WORD temp;
    char decBuff[7];

    if (VirtualInput.vDispRecNo)//�Ƿ���ʾ���
    {
        temp = WORDtoASCL(decBuff,val);
        decBuff[temp++]='.';decBuff[temp]=0;
        DispStrXY(decBuff,x,y);
        return temp;
    }
    else
        return 0;
}
/**
 * ֱ�Ӵ�Msg[]�ж�ȡ��Ϣ�����б�
 *
 * @author EutronSoftware (2016-02-17)
 */
void ReadFromMsg()
{
    strcpy(ListRecord.Name,Msg[ListRecord.Number+ListDef[ListID].MsgIDX].str);
}
/***************************************************************
 * ���б�����ʾ�о�ָ�������ļ������е����ݲ�ѡ������һ�������༭
 * ʹ��SysBuf��Ϊ������
 * @author EutronSoftware (2016-01-11)
 *
 * @param fileType:��Ʒ/����/���������ID
 * @param saveSCR: �Ƿ񱣻���Ļ����
 * @param caption: ��״̬����ʾ�˵�������Ϣ
 * @param vKey: =true,�˳�ʱ�������ⰴ��
 *
 *
 * @return int:=0���б�����
 *             =It_PLU_MG(-1)Ϊ��ȷ�ϼ�,ȷ��PLU�����MGѡ����;
 *             =It_EXIT(-2)Ϊ���˳���.
 *             ����ֵ,������ѡ��ļ�¼���(1..0xfffd);
 ***************************************************************/


/**************************************************************
 * ���ô�ListItemsʱ��Ĭ���ļ��ͼ�¼��
 *
 * @author EutronSoftware (2017-12-04)
 *
 * @param fileType
 * @param fileRecno
 *************************************************************/
void SetItemDefault(WORD fileType,WORD fileRecno)
{
    VirtualInput.recLast=fileRecno;
    VirtualInput.fileLast=fileType;
}
//ccr2016-12-22>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
#define ACTIVEITEM  BIT(ScreenStat, BIT0)  //Ϊ��ǰ��¼
#define mSetInvAttr() SETBIT(ScreenStat, BIT0)
#define mClearInvAttr() RESETBIT(ScreenStat, BIT0)
//ccr2016-12-22<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//ccr2017-12-05>>>ȷ����������ݲ������>>
#define CLEANSCREEN     BIT(ScreenStat,BIT1)
#define mSetCLSFlag()   SETBIT(ScreenStat,BIT1)
#define mClearCLSFlag() RESETBIT(ScreenStat,BIT1)
//ccr2017-12-05<<<<<<<<<<<<<<<<<<<<<<<<<

/****************************************************************
 *
 *
 * @author EutronSoftware (2017-11-03)
 *
 * @param fileType
 * @param saveSCR
 * @param caption
 * @param vKey:  �˳�ʱ,�Ƿ�����ȡ����
 * @param pLast :�Ƿ�ʹ�����ļ�¼��(2017-11-03)
 *
 * @return WORD:=0,û�ж�Ӧ����;=It_PLU_MG,Ϊ����PLU;=It_EXITΪ�˳�
 *****************************************************************/
WORD ListItems(WORD fileType,BYTE saveSCR,const char* caption,BYTE vKey,BYTE pLast)
{
#define ID_CURRENT   0x7f     //ccr2018-03-14���ֲ��ҽ������,������ʾһ��
//ccr2017-12-05    ULONG timeKeyp=GetSystemTimer();//������ⰴ�����,����ָ�����ʱ,�Զ������һ�ε�����
    ULONG numInput;

    BYTE byteNum,ScreenStat;
    WORD *recIDX;
    char *sStr;
    WORD recFrom,recMAX;//��¼�ſ�ʼ��ź������Ŀ
    WORD recCurrent;    //��ǰѡ��ļ�¼��
    WORD recList[LISTLINES];//���浱ǰ�ҵ��ļ�¼ (recFrom..n)
    WORD recCount,recCountX;          //recList�еļ�¼��Ŀ
    BYTE keyID;
    WORD keyCode,temp;
    int  sLp;

    void    (*ReadFromFile)();
    BYTE    (*PorcessRecord)(BYTE y,WORD recNo);    //��Ӧ��ǰ��¼�Ĵ�������,=nullʱ,�޴�������,��������0ʱ,û�д������� //

    //...................................................

    VirtualInputStr(0xff,0,0);//�����������
    ListID=0;
    do
    {
        if (ListDef[ListID].SetupIDX==0xffff)
            return 0;
        if (ListDef[ListID].SetupIDX==fileType)
            break;
        ListID++;
    } while (true);

    recFrom=0;
    VirtualInput.vDispRecNo=0;//ccr2016-12-24 1;
    switch (fileType)
    {
    case SETDISC:          //***BYTE //�ۿ�
    case SETPORA:          //***BYTE //�������
    case SETCORR:          //***BYTE //��������
    case SETTEND:          //***BYTE //���ʽ
    case SETCURR:          //***BYTE //���
    case SETDRAWER:        //***BYTE //Ǯ��
#if !defined(CASE_FORHANZI)
    case SETTAX:           //***BYTE//˰��
#endif                           //
    case SETZONES:         //***BYTE  //����ʱ������
#if (DD_FISPRINTER==0 && DD_DISABLEPBF==0)
    case SETPBF:           //***BYTE //��������
#endif
        byteNum=true;
        break;
    case SETPLU:
    case SETPLUSTOCK:
        if (ApplVar.AP.Plu.RandomSize==0)//ccr2016-06-06
            ApplVar.AP.Plu.RNumber = ApplVar.AP.Plu.Number;
#if (defined(CASE_FATFS_EJ) || defined(CASE_EJFLASH))
//ccr2017-04-21    case MENUXEJOURNAL:
#endif
    case SETSYSFLAG:
        VirtualInput.vDispRecNo=0;
        byteNum=false;
        break;
    case SETGRAP:
        VirtualInput.vDispRecNo=0;
#if (DD_FISPRINTER==0 && DD_DISABLEPBF==0)
    case SETPBINF: //��Ŵ�1��ʼ
#endif
    case SETCLERK://�տ�Ա��ӪҵԱ�Ŀ�ʼ��Ŵ�1��ʼ
#if (salNumber)
    case SETSALER:
#endif
        recFrom=1;
    default:
        byteNum=false;
        break;
    }

    if (ListDef[ListID].MsgIDX==0)
    {
        recMAX=ReadRecIndex(ListDef[ListID].RecordMax,byteNum)+recFrom;
#if defined(CASE_GREECE)//ccr2017-09-13>>>>>VAT E -> Hidden>>>>
        if (fileType==SETTAX)
            recMAX--;
#endif//ccr2017-09-13<<<<<<VAT E -> Hidden<<<<
    }
    else
        recMAX=(WORD)ListDef[ListID].RecordMax+recFrom;

    //�����б�������

    ReadFromFile=ListDef[ListID].ReadRecord;
    PorcessRecord=ListDef[ListID].PorcessRecord;
    recIDX=ListDef[ListID].RecordIdx;
    sStr=ListDef[ListID].Caption;

    if  (!pLast) VirtualInput.recLast=recFrom;//ccr2017-11-03

    keyCode=ID_DOWN;
    if (fileType==VirtualInput.fileLast && VirtualInput.recLast<recMAX)
        SetRecIndex(recIDX,VirtualInput.recLast,byteNum);
    else
        SetRecIndex(recIDX,recFrom,byteNum);
    recCount=0;
    ClearEntry();//ccr2017-12-05Appl_EntryCounter=0;
    memset((BYTE*)recList,0,sizeof(recList));

    if (saveSCR)
        BackupScreen(1);
#if (DISP2LINES)
//ccr2017-09-11 ���ڵڶ�����ʾ    if (caption)
//ccr2017-09-11 ���ڵڶ�����ʾ       Puts1((char*)caption);
#endif
    mSetCLSFlag();
    while (true)//keycode<190) ccr080319
    {
        //��ȡһ���¼���ݲ�����Ļ����ʾ
        //DispSt0(ApplVar.ModeHead);
        if (CLEANSCREEN)
            mClearScreen();

        mSetCLSFlag();
        mSetInvAttr();
        recCountX=recCount;
        recCurrent=0;
        recCount=0;
        switch (keyCode)
        {
        case ID_UP://��ǰ���Ҽ�¼
//ccr2016-12-22        case ID_LEFT:
            if (recList[0]>recFrom)
            {
                SetRecIndex(recIDX,recList[0]-1,byteNum);
                while (recCount<LISTLINES)
                {
                    if (ReadRecIndex(recIDX,byteNum)>=recFrom)
                    {
                        //(*ReadFromFile)();
                        //DispStrXY(sStr,0,recCount);
                        //mClearInvAttr();
                            recList[recCount++]=ReadRecIndex(recIDX,byteNum);
                            if (ReadRecIndex(recIDX,byteNum)==recFrom)
                                break;
#if !defined(LINE2BUT1)
                            DecRecIndex(recIDX,byteNum);
#else
                            IncRecIndex(recIDX,byteNum);
#endif
                    }
                    else
                        break;
                }
                //���ҵ������ݼ�¼˳����з�ת
#if !defined(LINE2BUT1)
                for (sLp=0;sLp<recCount / 2;sLp++)
                {
                    temp=recList[sLp];
                    recList[sLp]=recList[recCount-sLp-1];
                    recList[recCount-sLp-1]=temp;
                }
#endif
                //��ʾ��¼����
                for (sLp=0;sLp<recCount;sLp++)
                {
                    SetRecIndex(recIDX,recList[sLp],byteNum);
                    (*ReadFromFile)();
                    if (SETSYSFLAG!=fileType)//ccr2018-01-17 Ϊϵͳ��������,������ʾ
                    {
#if (LISTLINES==1)
                        PutsPre(0,sStr,'>');//ccr2017-11-29
#else
                        DispStrXY(sStr,DispIndex(0,sLp,recList[sLp]+(1-recFrom)),sLp);
#endif
                    }
                    if (ACTIVEITEM)
                        strncpy(VirtualInput.vInput,sStr,sizeof(VirtualInput.vInput));//ccr2016-02-15
                    mClearInvAttr();
                }
                //����DOWN����ʱ�ظ����һ����¼
                IncRecIndex(recIDX,byteNum);
                break;
            }
//         if (recCount<LISTLINES && recMAX>=LISTLINES)
            {
                SetRecIndex(recIDX,recFrom,byteNum);
                recCount=0;
            }
        case ID_DOWN://�����Һ�����¼
//ccr2016-12-22        case ID_RIGHT:
        case ID_SELECT:
#if defined(LINE2BUT1)
            if (recCountX==1)
                SetRecIndex(recIDX,recList[0],byteNum);
            else if (recCountX==2)
                SetRecIndex(recIDX,recList[1],byteNum);
#endif
        case ID_CURRENT:
            while (recCount<LISTLINES)
            {
                if (ReadRecIndex(recIDX,byteNum)<recMAX)
                {
                    (*ReadFromFile)();

                    recList[recCount]=ReadRecIndex(recIDX,byteNum);
                    if (SETSYSFLAG!=fileType)//ccr2018-01-17 Ϊϵͳ��������,������ʾ
                    {
#if (LISTLINES==1)
                        PutsPre(0,sStr,'>');//ccr2017-11-29
#else
                        DispStrXY(sStr,DispIndex(0,recCount,recList[recCount]+(1-recFrom)),recCount);
#endif
                    }
                    if (ACTIVEITEM)
                        strncpy(VirtualInput.vInput,sStr,sizeof(VirtualInput.vInput));//ccr2016-02-15

                    mClearInvAttr();
                    recCount++;
                    IncRecIndex(recIDX,byteNum);
                }
                else if (recCount==0)
                {
                    if (recCountX>0)//��ʾ��һ�β��ҵ�������
                    {
                        recCount=recCountX;
                        //��ʾ��¼����
                        //mSetInvAttr();
                        for (sLp=0;sLp<recCount;sLp++)
                        {
                            SetRecIndex (recIDX,recList[sLp],byteNum);
                            (*ReadFromFile)();
                            if (ACTIVEITEM)
                                strncpy(VirtualInput.vInput,sStr,sizeof(VirtualInput.vInput));//ccr2016-02-15

    #if (LISTLINES==1)
                            PutsPre(0,sStr,'>');//ccr2017-11-29
    #else
                            DispStrXY(sStr,DispIndex(0,sLp,recList[sLp]+(1-recFrom)),sLp);
    #endif
                            mClearInvAttr();
                        }
                    }
                    else
                    {
    #if (LISTLINES==1)
                            PutsO("(NONE)");//ccr2017-11-29
    #else
                            DispStrXY("(NONE)",0,0);
    #endif
                    }

                    break;
                }
                else
                    break;
            }
            break;
        }
        //���´���ѡ���¼
        recCurrent=0;
        sLp=true;
        while (sLp)
        {//��һ���¼��ѡ��

#if (0)//ccr2017-09-11���ڵڶ�����ʾ(DISP2LINES)
            if (Appl_EntryCounter==0 && VirtualInput.vDispRecNo==0)
            {
                memset(SysBuf,' ',SCREENWD);
                if (caption)
                {
                    CopyFrStr(SysBuf,caption);
                }
                WORDtoASC(SysBuf+SCREENWD-1,recList[recCurrent]+(1-recFrom));//��״̬����ʾ��¼��
                SysBuf[SCREENWD]=0;
                Puts1(SysBuf);
            }
#endif
            if (PorcessRecord)
            {//����????
                keyID=keyCode=(*PorcessRecord)(recCurrent,recList[recCurrent]-recFrom);
                if (keyID==0)
                    break;
            }
            else
            {
                SetLoop();
                while (!KbHit())
                {

#if !defined(DEBUGBYPC)
                    if (!ApplVar.ErrorNumber)
                        CheckTime(false);
                    if ((fileType==SETPLU || fileType==SETPLUSTOCK) && BarCode())
                        continue;
                    Computer();//communicate with computer
#if defined(CASE_GPRS)
                    if (fileType==SETGPRSFUNC)
                        GPRSWaitForReady(false);
#endif
#else
                    ProcessMessages();
#endif
                    CheckError(0);
                    //continue;
                }
//ccr2017-12-05                if (GetSystemTimer()-timeKeyp>SECONDS(1))
//ccr2017-12-05                    ClearEntry();
//ccr2017-12-05                timeKeyp=GetSystemTimer();
                keyID=keyCode=Getch();
                ResetLoop();
            }

            if (keyCode<127)
                keyCode = GetFirmkeyID(keyCode);
            else
                continue;//<<<<<<<<<<

            if (keyCode<FIRMKEYS)
            {
                switch (keyCode)
                {
                case ID_LOCK:         //ccr2018-01-16 Ԥ��Ʊͷ>>>>>>>>>>>
                    if (fileType==SETHEAD)
                    {
                        PrintHeader();
                        RFeed(PREHEADER+2);
                    }
                    break;         //ccr2018-01-16 Ԥ��Ʊͷ<<<<<<<<<<<
                case ID_DELETE://�� ID_RJFEED ��ͬ
                    if ((fileType==SETHEAD ||
                         fileType==SETTRAIL ||
#if (DD_SETSLIP)
                         fileType==SETSHEAD ||
#endif
                         fileType==SETPLU)
                        && WaitForYesNo(SHANCHU,0,1,1)=='Y')
                    {//ɾ����Ʒ/Ʊͷ��

                        SetRecIndex(recIDX,recList[recCurrent],byteNum);
                        keyCode=ID_CURRENT;//ccr2018-03-14
                        if (fileType==SETHEAD)
                        {
                           if( ApplVar.FisNumber.TotalHeadChangeNum>=FHEADCHGMAX)
                               ApplVar.ErrorNumber=ERROR_ID(CWXXI117);//����������������
                           else
                               DeleteHeader(recList[recCurrent]);
                        }
                        else if (fileType==SETTRAIL)
                            DeleteTrailer(recList[recCurrent]);
#if (DD_SETSLIP)
                        else if (fileType==SETSHEAD)
                            DeleteSlipHead(recList[recCurrent]);
#endif
                        else if (fileType==SETPLU)
                        {
                            if (ApplVar.AP.Plu.RNumber)
                            {
                              GetPluOffSet();
                              CheckRandomPlu(1,1);
                              recMAX=ApplVar.AP.Plu.RNumber;//(WORD)ListDef[ListID].RecordMax+recFrom;
                              if (ApplVar.PluNumber+1==ApplVar.AP.Plu.RNumber)
                                 keyCode=ID_UP;
                            }
                            if (!ApplVar.AP.Plu.RNumber)
                                recCount=0;
                        }

                        sLp=false;//�ж�ѭ��
                    }
                    else
                        RFeed(1);
                    break;
                case ID_ENTER:
                    if (saveSCR)
                        RecallScreen();
                    else
                        mClearScreen();
                    VirtualInput.fileLast=fileType;
                    VirtualInput.recLast=recList[recCurrent];

                    temp = VirtualInput.recLast+(1-recFrom);//�տ�Ա�ȵļ�¼�Ŵ�1��ʼ
                    if (fileType==LISTMGFUNC && temp<=7)
                    {
                        if ((keyID = PosOfFuncKey(SUB))!=0xff)
                        {//����1/2/3/4/5/6/7+С��
                            VirtualInputWORD(keyID,temp);
                            temp = It_PLU_MG;
                        }
                    }
                    else if ((fileType==SETPLU || fileType==SETPLUSTOCK ) && Appl_EntryCounter)
                    {//������������༭��Ʒ
                        VirtualInputStr(ENTERKey,&AtEntryBuffer(Appl_EntryCounter),Appl_EntryCounter);
                        ClearEntry();
                        mClearInvAttr();
                        return It_PLU_MG;
                    }
#if defined(FOR_DEBUG)//ccr2017-12-08ֻ��DEBUG�汾������������
                    else if (fileType==SETPROGRAM && Appl_EntryCounter)
                    {
                        if (Appl_NumberEntry==CMD_HARDTEST)
                            temp=Appl_NumberEntry;
                    }
#endif
                    if (Appl_EntryCounter)
                        ClearEntry();

                    if (recMAX)//��Щ���ô����޼�¼
                    {
                        mClearInvAttr();
                        return temp;
                    }
                case ID_CLEAR:
                    //ccr2017-07-25>>>ϣ����CLEAR�����˳�>>>>
                    if (Appl_EntryCounter || ApplVar.ErrorNumber)
                    {
                        ApplVar.ErrorNumber=0;
                        ClearEntry();
                        DispStrXY(EntryBuffer ,0,1);
                        break;
                    }
                    else
                    {//ccr2017-07-25ϣ����CLEAR�����˳�
                        keyCode=ID_CANCEL;
                    }
                    //ccr2017-07-25<<<<<<<<<<<<<<<<<<<<
                case ID_CANCEL:
                    if (vKey)
                         VirtualInputKey(EXITKey);//���ⰴȡ����

                    if (saveSCR)
                        RecallScreen();
                    else
                        mClearScreen();
                    mClearInvAttr();
                    return It_EXIT;//Ϊ�˳�����־
                case ID_UP://������ʾ
//ccr2016-12-22                case ID_LEFT:
                    if (recCurrent>0)
                    {//��ʾ��һ����¼����
#if (LISTLINES>1)
                        SetRecIndex(recIDX,recList[recCurrent],byteNum);
                        (*ReadFromFile)();
                        mClearInvAttr();

                        DispStrXY(sStr,DispIndex(0,recCurrent,recList[recCurrent]+(1-recFrom)),recCurrent);
#endif
                        recCurrent--;

                        SetRecIndex(recIDX,recList[recCurrent],byteNum);
                        (*ReadFromFile)();
                        mSetInvAttr();

                        strncpy(VirtualInput.vInput,sStr,sizeof(VirtualInput.vInput));//ccr2016-02-15
#if (LISTLINES==1)
                        PutsPre(0,sStr,'>');//ccr2017-11-29
#else
                        DispStrXY(sStr,DispIndex(0,recCurrent,recList[recCurrent]+(1-recFrom)),recCurrent);
#endif
                        mClearInvAttr();
                    }
                    else
                        sLp=false;//�ж�ѭ��
                    break;
                case ID_DOWN:
#if !defined(LINE2BUT1)//ccr2017-09-12 ���е���һ�жԴ�,���ƶ����ڶ���
//ccr2016-12-22                case ID_RIGHT:
#if (LISTLINES>1)   //ccr2017-11-29
                    if (recCurrent<recCount-1)
                    {//��ʾ��һ����¼����
                        SetRecIndex(recIDX,recList[recCurrent],byteNum);

                        (*ReadFromFile)();
                        mClearInvAttr();

                        DispStrXY(sStr,DispIndex(0,recCurrent,recList[recCurrent]+(1-recFrom)),recCurrent);
                        recCurrent++;

                        SetRecIndex(recIDX,recList[recCurrent],byteNum);
                        (*ReadFromFile)();
                        mSetInvAttr();

                        strncpy(VirtualInput.vInput,sStr,sizeof(VirtualInput.vInput));//ccr2016-02-15
                        DispStrXY(sStr,DispIndex(0,recCurrent,recList[recCurrent]+(1-recFrom)),recCurrent);
                        mClearInvAttr();
                    }
                    else
#endif
                    {
                        SetRecIndex(recIDX,recList[recCurrent],byteNum);
                        IncRecIndex(recIDX,byteNum);
                        sLp=false;//�ж�ѭ��
                    }
                    break;
#endif
                case ID_SELECT:
                    sLp=false;//��ҳ��ʾ,�ж�ѭ��//recCurrent=recCount-1;
                    break;
                default:
                    Bell(1);
                    break;
                }
                Appl_EntryCounter=0;
            }
            else
            {
                keyCode = ApplVar.AP.KeyTable[keyID];//			i = GetNumric(keycode);
                if (keyCode==ZERO2 && Appl_EntryCounter==0)//ccr2017-12-08
                {//��ӡ�˵�
                    PrintSetupMenu();//��ӡ���ò˵�
                }
                else if (keyCode>='0' && keyCode <='9' && Appl_EntryCounter<13)
                {
                    mClearCLSFlag();
                    //ccr2017-12-05>>>>�����������뷶Χ�ڼ�¼��Ŀ��Χ��
                    numInput=Appl_NumberEntry*10+(keyCode & 0x0f);
#if defined(FOR_DEBUG)//ccr2017-12-08ֻ��DEBUG�汾������������
                    if (fileType==SETPLU || numInput>0 && numInput<=recMAX || fileType==SETPROGRAM)
#else
                    if (fileType==SETPLU || numInput>0 && numInput<=recMAX)
#endif
                    {
                        AppendEntry(keyCode);

                        DispStrXY(&AtEntryBuffer(DISLEN) ,0,1);
                        GetEntry();
                        if ((WORD)Appl_NumberEntry>0 && (WORD)Appl_NumberEntry<=recMAX)
                        {
                            SetRecIndex(recIDX,(WORD)Appl_NumberEntry-(1-recFrom),byteNum);
#if defined(LINE2BUT1)//ccr2017-09-12 ���е���һ�жԴ�,���ƶ����ڶ���
                            recCountX=2;
                            recList[1]=Appl_NumberEntry-(1-recFrom);
#endif
                            keyCode=ID_DOWN;
                            sLp=false;
                        }
#if defined(FOR_DEBUG)//ccr2017-12-08ֻ��DEBUG�汾������������
                        else if (fileType==SETPROGRAM)
                        {//�ж��Ƿ�Ϊ��Ч������
                        }
#endif
                    }
                }
                else
                {
                    if (keyCode>DEPT && keyCode<PLU1 && fileType==SETDEPT)
                    {//�������ʱ,ֱ�ӽ����Ӧ�Ĳ���
                        keyCode -= DEPT;
                    }
                    else if (keyCode>PLU1 && keyCode<PLU3 && (fileType==SETPLU || fileType==SETPLUSTOCK))
                    {//��Ʒ,������ͨ����ֱ�ӵ�Ʒ����
                        keyCode -= PLU1;
                    }
                    /*else if (keyCode>DISC && keyCode<DRAW && fileType==SETDISC)
                    {//�ۿ�
                        keyCode -= DISC;
                    }
                    else if (keyCode>TEND && keyCode<MODI && fileType==SETTEND)
                    {//���ʽ
                        keyCode -= TEND;
                    }*/
                    else
                        keyCode=0;
                    if (keyCode)
                    {
                        if (saveSCR)
                            RecallScreen();
                        else
                            mClearScreen();
                        return keyCode;
                    }
                    else
                        Bell(1);
                }
            }
        }//while (sLp)
    }//while (true)
}

/**
 * �����ļ����ͺ�ָ���ļ�¼��,���տ���ļ��л�ȡ��¼����
 *
 * @author EutronSoftware (2016-02-25)
 *
 * @param fileType:�ļ�����
 * @param idx:��¼���
 * @param caption:���صļ�¼�е�����
 *
 * @return word:true-�ж�Ӧ������;false-�޶�Ӧ������
 */
WORD ReadItemCaption(WORD fileType,WORD idx,char *caption)
{
    BYTE byteNum;
    WORD *recIDX;
    char *sStr;
    int  sListIdx;
    WORD recFrom,recMAX;//��¼�ſ�ʼ��ź������Ŀ
    void    (*ReadFromFile)();
    //...................................................

    sListIdx=0;
    do
    {
        if (ListDef[sListIdx].SetupIDX==0xffff)
        {
            caption[0]=0;
            return 0;
        }
        if (ListDef[sListIdx].SetupIDX==fileType)
            break;
        sListIdx++;
    } while (true);

    recFrom=0;

    switch (fileType)
    {
    case SETDISC:          //***BYTE //�ۿ�
    case SETPORA:          //***BYTE //�������
    case SETCORR:          //***BYTE //��������
    case SETTEND:          //***BYTE //���ʽ
    case SETCURR:          //***BYTE //���
    case SETDRAWER:        //***BYTE //Ǯ��
#if !defined(CASE_FORHANZI)
    case SETTAX:           //***BYTE//˰��
#endif                           //
    case SETZONES:         //***BYTE  //����ʱ������
#if (DD_FISPRINTER==0 && DD_DISABLEPBF==0)
    case SETPBF:           //***BYTE //��������
#endif
        byteNum=true;
        break;
    case SETGRAP:
    case SETCLERK://�տ�Ա��ӪҵԱ�Ŀ�ʼ��Ŵ�1��ʼ
#if (salNumber)
    case SETSALER:
#endif
        recFrom=1;
    default:
        byteNum=false;
        break;
    }
    if (ListDef[sListIdx].MsgIDX==0)
        recMAX=ReadRecIndex(ListDef[sListIdx].RecordMax,byteNum)+recFrom;
    else
        recMAX=(WORD)ListDef[sListIdx].RecordMax+recFrom;

    if (idx<recMAX)
    {
        ReadFromFile=ListDef[sListIdx].ReadRecord;
        recIDX=ListDef[sListIdx].RecordIdx;
        sStr=ListDef[sListIdx].Caption;
        SetRecIndex(recIDX,idx,byteNum);
        (*ReadFromFile)();
        strcpy(caption,sStr);
        return true;
    }
    else
    {
        caption[0]=0;
        return false;
    }

}
#if (0)//ccr2016-12-22>>>>>>>>>>>>>>>>>>
/**
 * ��ӡXZ���ܲ˵�
 *
 * @author EutronSoftware (2016-11-16)
 *
 * @param xz
 */
void PrintXZMenu(BYTE xz)
{
    MenuDefine *ItemXZReport;
    int msgFr,msgTo,msgLp;
    WORD recFrom,recMAX;//��¼�ſ�ʼ��ź������Ŀ
    WORD recCurrent;    //��ǰѡ��ļ�¼��
    WORD *recIDX;
    char *sStr,pBuf[PRTLEN+3];
    WORD recCount,recCountX;          //recList�еļ�¼��Ŀ
    void    (*ReadFromFile)();


    if (xz==X)
    {
        msgFr = MENUXREPORT;
        msgTo = msgFr+MENUXITEMMAX-1;
        ItemXZReport = (MenuDefine *)&ItemXReport;
        pBuf[0]='X';
    }
    else if (xz==Z)
    {
        msgFr = MENUZREPORT;
        msgTo = msgFr+MENUZITEMMAX-1;
        ItemXZReport = (MenuDefine *)&ItemZReport;
        pBuf[0]='Z';
    }
    else
        return;

    pBuf[1]=' ';
    strcpy(pBuf+2,cMESSSETMENU);
    PrintLine('.');
    PrintStr_Center(pBuf,true);
    PrintLine('=');
    for (msgLp=msgFr;msgLp<=msgTo;msgLp++)
    {

        //��ӡ�ϻ��˵�����
        recFrom = msgLp-msgFr+1;

        memset(pBuf,' ',sizeof(pBuf));
        if (recFrom>9) pBuf[3]=recFrom/10+'0';
        pBuf[4]=recFrom % 10+'0';
        pBuf[5]='.';
        strncpy(pBuf+6,Msg[msgLp].str,sizeof(pBuf)-6);
        pBuf[PRTLEN+3-1]=0;
        RJPrint(0,pBuf+3);


        recFrom=0;
        do
        {
            if (ItemXZReport[recFrom].MenuFrom==0)
            {
                recFrom = 0xffff;
                break;
            }
            else if (ItemXZReport[recFrom].MenuFrom==msgLp)
                break;
            recFrom++;
        } while (true);
        if (recFrom == 0xffff || ((recFrom = ItemXZReport[recFrom].MenuItems)==0))
            continue;

        ListID=0;
        do
        {
            if (ListDef[ListID].SetupIDX==0xffff)
            {
                ListID = 0xffff;
                break;
            }
            else if (ListDef[ListID].SetupIDX==recFrom)
                break;
            ListID++;
        } while (true);
        if (ListID == 0xffff)
            continue;

        if (ListDef[ListID].MsgIDX==0)
            recMAX=ReadRecIndex(ListDef[ListID].RecordMax,true);
        else
            recMAX=(WORD)ListDef[ListID].RecordMax;

        //�����б�������

        recIDX=ListDef[ListID].RecordIdx;
        ReadFromFile=ListDef[ListID].ReadRecord;
        sStr=ListDef[ListID].Caption;

        recFrom=1;
        SetRecIndex(recIDX,0,true);

        while (recFrom<=recMAX)
        {
            if (ReadRecIndex(recIDX,true)<recMAX)
            {
                (*ReadFromFile)();
                if (recFrom>9)
                    pBuf[6]=recFrom/10+'0';
                else
                    pBuf[6]=' ';
                pBuf[7]=recFrom % 10+'0';
                pBuf[8]='.';
                strncpy(pBuf+9,sStr,sizeof(pBuf)-9);
                pBuf[PRTLEN-1]=0;
                RJPrint(0,pBuf);
                recFrom++;
                IncRecIndex(recIDX,true);
            }
        }
    }
}
/**
 * ��ӡ�������µĲ��������б�
 *
 * @author EutronSoftware (2016-11-18)
 */
void PrintMGMenu()
{
    int i;
    char pBuf[PRTLEN+3];

    PrintLine('.');
    PrintStr_Center(Msg_MANAGEMENT,true);
    PrintLine('=');
    memset(pBuf,' ',PRTLEN);
    for (i=1;i<=MsgMGMMAX;i++)
    {
        if (i>9)
            pBuf[0]=i/10+'0';
        else
            pBuf[0]=' ';
        pBuf[1]=i % 10+'0';
        pBuf[2]='.';
        strncpy(pBuf+3,Msg[i+MsgMGADDINV-1].str,PRTLEN-3);
        RJPrint(0,pBuf);
    }
}
#endif//ccr2016-12-22<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

