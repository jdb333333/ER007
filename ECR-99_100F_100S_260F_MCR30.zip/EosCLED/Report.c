#define REPORT_C 5
#include "king.h"
#include "exthead.h"
#include "exth.h"
#include "ejournal.h"
#include "fiscal.h"

/****************************************************************/
#define PRINTDOTLINE()  PrintLine('.')  //ccr2017-06-01

void PrintReportType()
{
    MemSet(SysBuf, sizeof(SysBuf), ' ');
    memcpy(SysBuf + 4, ApplVar.TXT.ReportType[ApplVar.Report.Type], sizeof(ApplVar.TXT.ReportType[0]));
    PrintStr(SysBuf);
    //PrintLine('-');//��Լֽ��
}

void PrintGroup(WORD number)
{
    PRINTDOTLINE();
    ApplVar.GroupNumber = number;
    ReadGroup();

    if (ApplVar.RepComputer)
    {
        *((WORD *)SysBuf) = GROUP + 1;
        memcpy(SysBuf+7, ApplVar.Group.Name, ApplVar.AP.Group.CapSize);
        return;
    }
    if (SysBuf[0]&&ApplVar.AP.Group.CapSize)
    {
        memcpy(SysBuf+9,ApplVar.Group.Name,ApplVar.AP.Group.CapSize);
        PrintStr(SysBuf); /* print number */
    }
    else if (SysBuf[0])
        PrintStr(SysBuf); /* print number */
    else if (ApplVar.AP.Group.CapSize)
        PrintStr(ApplVar.Group.Name);
}

void PrintDept(WORD number)
{
    PRINTDOTLINE();

    ApplVar.DeptNumber = number;
    ReadDept();
    if (ApplVar.RepComputer)
    {
        *((WORD *)SysBuf) = DEPT + ApplVar.DeptNumber + 1;
        if (ApplVar.AP.Dept.RandomSize)
        {
            memcpy(SysBuf+7, ApplVar.Dept.Random, ApplVar.AP.Dept.RandomSize);
            SysBuf[2] = 0;  /* type = random number */
            SendRecord(SysBuf, 7 + 7);     /* always max size 14 */
        }
        *((WORD *)SysBuf) = DEPT + 1;
        memcpy(SysBuf+7, ApplVar.Dept.Name, ApplVar.AP.Dept.CapSize);
        return;
    }
    if (ApplVar.AP.Dept.RandomSize)
    {
        if (!SysBuf[0])
            SysBuf[0] = ' ';
        HEXtoASC(SysBuf + 10, ApplVar.Dept.Random, ApplVar.AP.Dept.RandomSize);
        SysBuf[9] = '#';
        PrintStr(SysBuf);
    }
    if (SysBuf[0]&&ApplVar.AP.Dept.CapSize)
    {
#if defined(CASE_EURO)//#00001(this change it to '#01') DEP1��ƨҪ�� ccr2017-08-02
        sprintf(SysBuf,"#%.2d        ",number+1);
#endif
        memcpy(SysBuf+9,ApplVar.Dept.Name,ApplVar.AP.Dept.CapSize);
        PrintStr(SysBuf);
    }
    else if (SysBuf[0])
        PrintStr(SysBuf);
    else if (ApplVar.AP.Dept.CapSize)
        PrintStr(ApplVar.Dept.Name);
}


void PrintPlu(WORD number)
{
    int i,l;
    BCD price;

    PRINTDOTLINE();

    ApplVar.PluNumber = number;
    ReadPlu();
    if (ApplVar.RepComputer)
    {
        *((WORD *)SysBuf) = PLU1 + ApplVar.PluNumber + 1;
        if (ApplVar.AP.Plu.RandomSize)
        {
            memcpy(SysBuf+7, ApplVar.Plu.Random, ApplVar.AP.Plu.RandomSize);
            SysBuf[2] = 0;  /* type = random number */
            SendRecord(SysBuf, 7 + 7);     /* always max size 14 */
        }
        *((WORD *)SysBuf) = PLU1 + 1;
        memcpy(SysBuf+7, ApplVar.Plu.Name, ApplVar.AP.Plu.CapSize);
        return;
    }
    if (ApplVar.AP.Plu.RandomSize)
    {
#if (PRTLEN<25)
        HEXtoASC(SysBuf + 6, ApplVar.Plu.Random, ApplVar.AP.Plu.RandomSize);
        SysBuf[6] = 'R';//SysBuf[0];          /* copy number sign */
#else
        HEXtoASC(SysBuf + 10, ApplVar.Plu.Random, ApplVar.AP.Plu.RandomSize);
        SysBuf[9] = 'R';//SysBuf[0];          /* copy number sign */
#endif
        PrintStr(SysBuf);
        if (ApplVar.AP.Plu.CapSize)
            PrintStr(ApplVar.Plu.Name);
    }
    else
    {
        if (ApplVar.AP.Plu.CapSize)
            strncpy(SysBuf+8,ApplVar.Plu.Name,ApplVar.AP.Plu.CapSize);
        PrintStr(SysBuf);
    }
    if (ApplVar.AP.Plu.InvSize && ApplVar.Report.Type == REPORT_PLU)
    {
        if (BIT(ART_LEVEL, BIT6))
            PrintQty(Prompt.Caption[ItemPrompt48], &ApplVar.PluInventory);    /* qty */
    }
    if (ApplVar.Report.Type == REPORT_INVENTORY) // lyq
    {
        if (ApplVar.AP.Plu.InvSize)     /* print inventory */
        {
            PrintQty(Prompt.Caption[ItemPrompt48], &ApplVar.PluInventory);    /* qty */
            Add(&ApplVar.SaleQty, &ApplVar.PluInventory);
            if (!BIT(ART_LEVEL, BIT2) && ApplVar.AP.Plu.Cost) /* ApplVar.Cost price active ? */
            {
                price = ZERO;
                memcpy(price.Value, ApplVar.Plu.Cost, ApplVar.AP.Plu.PriceSize);
                Multiply(&price, &ApplVar.PluInventory);
                PrintAmt(Prompt.Caption[ItemPrompt7], &price);   /* qty */
                Add(&ApplVar.SaleAmt, &price);
            }
        }
        return;
    }
    if (ApplVar.AP.Plu.PriceSize)
    {//ccr2017-06-01>>>>>
        price = ZERO;
        strcpy(ProgLineMes, Prompt.Caption[ItemPrompt4]);
        l=strlen(ProgLineMes);
        ProgLineMes[l]=' ';

        for (i = 0; i < ApplVar.AP.Plu.Level; i++)
        {
            if (ApplVar.AP.Plu.Level > 1)
                ProgLineMes[l]=i+'1';
            ProgLineMes[l+1]=0;
            memcpy(price.Value, ApplVar.Plu.Price[i], ApplVar.AP.Plu.PriceSize);
            PrintAmt(ProgLineMes, &price);
        }
    }//ccr2017-06-01<<<<<<
}


void PrintTender(WORD number)
{
    PRINTDOTLINE();
    ApplVar.TendNumber = number;
    ReadTender();
    if (ApplVar.RepComputer)
    {
        *((WORD *)SysBuf) = TEND + 1;
        memcpy(SysBuf+7, ApplVar.Tend.Name, ApplVar.AP.Tend.CapSize);
        return;
    }
    if (SysBuf[0]&&ApplVar.AP.Tend.CapSize)
    {
        memcpy(SysBuf+9,ApplVar.Tend.Name,ApplVar.AP.Tend.CapSize);
        PrintStr(SysBuf);
    } /* print number+name */
    else if (SysBuf[0])
        PrintStr(SysBuf); /* print number+name */
    else if (ApplVar.AP.Tend.CapSize)
        PrintStr(ApplVar.Tend.Name);
}


void PrintPoRa(WORD number)
{
    PRINTDOTLINE();
    ApplVar.PoRaNumber = number;
    ReadPoRa();
    if (ApplVar.RepComputer)
    {
        *((WORD *)SysBuf) = PORA + 1;
        memcpy(SysBuf+7, ApplVar.PoRa.Name, ApplVar.AP.PoRa.CapSize);
        return;
    }
    if (SysBuf[0]&&ApplVar.AP.PoRa.CapSize)
    {
        memcpy(SysBuf+9, ApplVar.PoRa.Name, ApplVar.AP.PoRa.CapSize);
        PrintStr(SysBuf); /* print number + name */
    }
    else if (SysBuf[0])
        PrintStr(SysBuf); /* print number */
    else if (ApplVar.AP.PoRa.CapSize)
        PrintStr(ApplVar.PoRa.Name);
}


void PrintCurrency(WORD number)
{
    PRINTDOTLINE();
    ApplVar.CurrNumber = number;
    ReadCurr();
    if (ApplVar.RepComputer)
    {
        *((WORD *)SysBuf) = CURR + 1;
        memcpy(SysBuf+7, ApplVar.Curr.Name, ApplVar.AP.Curr.CapSize);
        return;
    }
    if (SysBuf[0]&&ApplVar.AP.Curr.CapSize)
    {
        memcpy(SysBuf+9, ApplVar.Curr.Name, ApplVar.AP.Curr.CapSize);
        PrintStr(SysBuf); /* print number + name */
    }
    else if (SysBuf[0])
        PrintStr(SysBuf); /* print number */
    else if (ApplVar.AP.Curr.CapSize)
        PrintStr(ApplVar.Curr.Name);
}


void PrintDrawer(WORD number)
{
    PRINTDOTLINE();
    ApplVar.DrawNumber = number;
    ReadDrawer();
    if (ApplVar.RepComputer)
    {
        *((WORD *)SysBuf) = DRAW + 1;
        memcpy(SysBuf+7, ApplVar.Draw.Name, ApplVar.AP.Draw.CapSize);
        return;
    }
    if (SysBuf[0]&&ApplVar.AP.Draw.CapSize)
    {
        memcpy(SysBuf+9, ApplVar.Draw.Name, ApplVar.AP.Draw.CapSize);
        PrintStr(SysBuf); /* print number + name */
    }
    else if (SysBuf[0])
        PrintStr(SysBuf); /* print number */
    else if (ApplVar.AP.Draw.CapSize)
        PrintStr(ApplVar.Draw.Name);
}


void PrintCorrec(WORD number)
{
    short i,j;

    PRINTDOTLINE();
    ApplVar.CorrecNumber = number;
    ReadCorrec();

    if (ApplVar.RepComputer)
    {
        *((WORD *)SysBuf) = CORREC + 1;
        j = 0;
        for (i=0;i<ApplVar.AP.Correc.CapSize;i++)
        {
            if (ApplVar.Correc.Name[i] != '~')
            {
                SysBuf[7+j] = ApplVar.Correc.Name[i];
                j++;
            }
//			memcpy(SysBuf+7, ApplVar.Correc.Name, ApplVar.AP.Correc.CapSize);
        }
        return;
    }
    if (SysBuf[0])
    {
        if (ApplVar.AP.Correc.CapSize)
        {
            j = 9;
            for (i=0;i<ApplVar.AP.Correc.CapSize;i++)
            {
                if (ApplVar.Correc.Name[i] != '~')
                {
                    SysBuf[j] = ApplVar.Correc.Name[i];
                    j++;
                }
            }
        }
        PrintStr(SysBuf); /* print number */
    }
    else if (ApplVar.AP.Correc.CapSize)
    {
        j = 0;
        for (i=0;i<ApplVar.AP.Correc.CapSize;i++)
        {
            if (ApplVar.Correc.Name[i] != '~')
            {
                SysBuf[j] = ApplVar.Correc.Name[i];
                j++;
            }
        }
        SysBuf[j] = 0;
        PrintStr(SysBuf);
    }
#if defined(FISCAL)
//ccr091223	if((ApplVar.Correc.Options & 0x07) == 2 ) // refund
//ccr091223		Add(&ApplVar.FRetAmt,&ApplVar.Total.Amt);
#endif

}

void PrintDisc(WORD number)
{
    PRINTDOTLINE();
    ApplVar.DiscNumber = number;
    ReadDisc();

    if (ApplVar.RepComputer)
    {
        *((WORD *)SysBuf) = DISC + 1;
        memcpy(SysBuf+7, ApplVar.Disc.Name, ApplVar.AP.Disc.CapSize);
        return;
    }

    if (!MyFlags(CLOSEPRINT)) //ccr2018-03-21 Ϊ��ӡ˰�ر���ͬʱ�ر��˴�ӡ��(�������)
    {
       if (SysBuf[0])
       {
           if (ApplVar.AP.Disc.CapSize)
               memcpy(SysBuf+7, ApplVar.Disc.Name, ApplVar.AP.Disc.CapSize);
           PrintStr(SysBuf); /* print number */
       }
       else if (ApplVar.AP.Disc.CapSize)
           PrintStr(ApplVar.Disc.Name);
    }
#if defined(FISCAL)
    Add(&ApplVar.FDiscAmt,&ApplVar.Total.Amt);
#endif
}


void PrintTax(WORD number)
{
    BCD sVal1;//ccr2017-05-17

    PRINTDOTLINE();
    ApplVar.TaxNumber = number;
    ReadTax();
    if (ApplVar.RepComputer)
    {
        *((WORD *)SysBuf) = TAX + 1;
        memcpy(SysBuf+7, ApplVar.Tax.Name, ApplVar.AP.Tax.CapSize);
    }
    else if (!MyFlags(CLOSEPRINT)) //ccr2018-03-21 Ϊ��ӡ˰�ر���ͬʱ�ر��˴�ӡ��(�������)
    {
        if (SysBuf[0])
        {
#if defined(CASE_EURO)//#00001(this needs to be removed) VAT A?? 6,00%��ƨҪ�� ccr2017-08-02
            memset(SysBuf,' ',PRTLEN);
            memcpy(SysBuf, ApplVar.Tax.Name, strlen(ApplVar.Tax.Name));//ccr2017-05-17ApplVar.AP.Tax.CapSize);
#else
            if (ApplVar.AP.Tax.CapSize)
                 memcpy(SysBuf+9, ApplVar.Tax.Name, strlen(ApplVar.Tax.Name));//ccr2017-05-17ApplVar.AP.Tax.CapSize);
#endif
            //ccr2017-05-17>>>>>>>>>>>>>>>>>
            sVal1 = ZERO;
            CWORD(sVal1.Value[0]) = CWORD(ApplVar.Tax.Rate[0]);
            sVal1.Sign = 2;
            FormatQty(SysBuf+PRTLEN-2,&sVal1);//cr070424
            SysBuf[PRTLEN-1] = '%';      //ProgLineMes[13] = '%';
            SysBuf[PRTLEN] = 0;
            //ccr2017-05-17<<<<<<<<<<<<<<<<<<<
            PrintStr(SysBuf); /* print number */
        }
        else if (ApplVar.AP.Tax.CapSize)
            PrintStr(ApplVar.Tax.Name);
    }

    if (BIT(ApplVar.Tax.Options, BIT0)) /* vat then calculate vat  ? */
    {
        if (ApplVar.Tax.Rate[0] == 0x99 &&
            ApplVar.Tax.Rate[1] == 0x99 &&
            ApplVar.Tax.Rate[2] == 0x99)
            ApplVar.Total.Disc = ZERO;              /* NET is zero */
        else
        {
            memcpy(ApplVar.Total.Qty.Value, ApplVar.Tax.Rate, sizeof(ApplVar.Tax.Rate));
            ApplVar.Total.Cost = ApplVar.Total.Amt;
            ApplVar.Total.Disc = ApplVar.Total.Amt;
            Add(&ApplVar.Total.Qty, &THOUSAND10);
            ApplVar.Total.Qty.Sign = 0x04;
            Divide(&ApplVar.Total.Disc, &ApplVar.Total.Qty);

            RoundBcd(&ApplVar.Total.Disc, 0);

            AmtRound(1, &ApplVar.Total.Disc);
            Subtract(&ApplVar.Total.Cost, &ApplVar.Total.Disc);  /* taxable - net */
        }
    }
    else    /* add On */
    {
        ApplVar.Total.Disc = ApplVar.Total.Amt;     /* ApplVar.Disc -> total NET */
        Add(&ApplVar.Total.Amt, &ApplVar.Total.Cost);   /* ApplVar.Amt -> Net + ApplVar.Tax */
    }
#if defined(FISCAL)
    if (ApplVar.ReportNumber == 1 && ApplVar.FReport == Z
        && !BIT(ApplVar.FTotal_Flags,(1<<number))//ȱֽ���������´�ӡZ����,���ظ�ͳ�� //
        && !BIT(ApplVar.Fiscal_PrintFlag,BIT5))  // Ϊ��ӡ��Z������������Z���ݴ���,���ظ�ͳ�� //
    {

        Add(&ApplVar.FTaxTotal[number],&ApplVar.Total.Disc);       //����VAT(TAX)�ۻ�
        Add(&ApplVar.FNetTotal[number], &ApplVar.Total.Cost);            //����NET VALUE�ۻ�
        Add(&ApplVar.FNetSum[number],&ApplVar.Total.Disc);        //��ʷNET VALUE�ۻ�
        Add(&ApplVar.FTaxSum[number],&ApplVar.Total.Cost);        //��ʷVAT(TAX)�ۻ�
        ApplVar.FTotal_Flags |= 1<<number;//��Ǵ�˰�ֵ������Ѿ��ۼ�

    }
#endif

}


void PrintPbF(WORD number)
{
    PRINTDOTLINE();
    ApplVar.PbFNumber = number;
    ReadPbF();

    if (ApplVar.RepComputer)
    {
        *((WORD *)SysBuf) = PBF + 1;
        memcpy(SysBuf+7, ApplVar.PbF.Name, ApplVar.AP.Pb.CapSize);
        return;
    }

    if (SysBuf[0])
    {
        if (ApplVar.AP.Pb.CapSize)
            memcpy(SysBuf+9, ApplVar.PbF.Name, ApplVar.AP.Pb.CapSize);
        PrintStr(SysBuf); /* print number */
    }
    else if (ApplVar.AP.Pb.CapSize)
        PrintStr(ApplVar.PbF.Name);

}

void PrintPb(WORD number)
{
    PRINTDOTLINE();
    ApplVar.PbNumber = number;
    PbTotal(number+1,0);

    if (ApplVar.RepComputer)
    {
        *((WORD *)SysBuf) = PBTOT + 1;
        memcpy(SysBuf+7, ApplVar.PB.Text, ApplVar.AP.Pb.Text);
        return;
    }

    if (SysBuf[0])
    {
        if (ApplVar.AP.Pb.Text)
            memcpy(SysBuf+9, ApplVar.PB.Text, ApplVar.AP.Pb.Text);
        PrintStr(SysBuf); /* print number */
    }
    else if (ApplVar.AP.Pb.CapSize)
        PrintStr(ApplVar.PB.Text);

}

WORD PeriodSkip(struct REPSIZE *S, BYTE number)
{
    BYTE period;
    WORD skip;

    skip = 0;
    period = 0x08;
    do
    {
        if (S->Periods & period)
            skip += S->Length * (WORD)number;
        period >>= 1;
    }while (period);
    return skip;
}


/****************************************************************
 * set ApplVar.ErrorNumber to 27 if user break
 * �����ж�X������ӡ
 * @author EutronSoftware (2017-12-04)
 *
 * @return short
 ****************************************************************/
short CheckBreak()
{
//    if (ApplVar.RepComputer && COMPUTER)
//     ApplVar.ErrorNumber=ERROR_ID(CWXXI27);   /* rs232 error */
//    else
        CheckBreakKey();
    return(ApplVar.ErrorNumber);
}

void PrintRange()
{
    MemSet(SysBuf, sizeof(SysBuf), ' ');
    WORDtoASCZero(SysBuf + 11, ApplVar.Report.Start);
    SysBuf[12] = '-';
    WORDtoASCZero(SysBuf + 17, ApplVar.Report.End);
    SysBuf[18] = 0;

    PrintStr(SysBuf);

}
/**
 * �ж�ApplVar.Report.Type�ı����Ƿ���������
 *
 * @author EutronSoftware (2017-05-26)
 *
 * @return BYTE :=true,��������;=false,����������
 */
BYTE CheckZeroReport()
{
    switch (ApplVar.Report.Type)
    {
//ccr2017-12-15    case REPORT_PLU: /* PLU */
//ccr2017-12-15    case REPORT_TENDER: /* TENDER */
//ccr2017-12-15    case REPORT_CORRECTION: /* Corrections */
//ccr2017-12-15    case REPORT_DISCOUNT: /* Discount */
//ccr2017-12-15    case REPORT_GROUP: /* GROUP */
//ccr2017-12-15    case REPORT_DEPARTMENT: /* DEPARTMENT */
    case REPORT_TAX:    /* tax */
        return false;// δ��ӡ˰��z����֮ǰ�����ϱ��������ݽ�ֹ���
    default:
        return true;
    }
}
/**************************************************************
 * �����������,ʵ������ֻ�������������ı�ʾλ(BIT2),
 * ��BIT2Ϊ0ʱ,��Ϊ������û������,Ҳ������Ϊ0
 *
 * @author EutronSoftware (2017-05-24)
 *************************************************************/
void ResetReport()
{
#if defined(FISCAL)
    if (ApplVar.FReport == Z && !ApplVar.ErrorNumber && ApplVar.Report.Type != REPORTTYPE_MAX&& !BIT(ApplVar.Fiscal_PrintFlag,BIT2))        /* Z report ? */
    {
        if (!CheckZeroReport() &&
            ApplVar.Report.System != 3 &&   /* only reset with fiscal report */
            MyFlags(ZREPORT))//ccr20130318 !ApplVar.Report.PointerType)
        {
                ApplVar.ErrorNumber=ERROR_ID(CWXXI75);//�ȴ�ӡ˰��Z����
        }
        else
        {
                //ccr2017-05-24 BIT2=0ʱ,˵������������û�в�����,Ҳ���������������Ϊ��0
                ApplVar.BufCC = 1;  /* set write only sign byte */
                ApplVar.Total.Qty.Sign = 0;
                WriteTotal();
                ApplVar.BufCC = 0;
        }
    }
#else

    if (ApplVar.FReport == Z && !ApplVar.ErrorNumber && ApplVar.Report.Type != REPORTTYPE_MAX)      /* Z report ? */
    {
        ApplVar.BufCC = 1;  /* set write only sign byte */
        ApplVar.Total.Qty.Sign = 0;
        WriteTotal();
        ApplVar.BufCC = 0;
    }
#endif
}




short CheckTotal()
{
    BYTE temp, periods, periodnumber;
    WORD skip;
    struct REPSIZE *Si ;

    ApplVar.Report.Size = ApplVar.AP.Sales.RecordSize;
    ApplVar.Report.OffSet = 0;
    skip = 0;
    Si = ApplVar.AP.Sales.Size;
    if (ApplVar.Report.PointerType)
    {
        skip += PeriodSkip(Si, 1);
        Si++;
    }
    if (ApplVar.Report.PointerType > 1)
    {
        skip += PeriodSkip(Si, ApplVar.AP.Clerk.Number);
        Si++;
    }
    if (ApplVar.Report.PointerType > 2)
    {
        skip += PeriodSkip(Si, ApplVar.AP.Zone.Number);
        Si++;
    }
    if (ApplVar.Report.PointerType > 3)
    {
        skip += PeriodSkip(Si, ApplVar.AP.Day.Number);
        Si++;
    }
    if (ApplVar.Report.PointerType > 4)
    {
        skip += PeriodSkip(Si, ApplVar.AP.SalPer.Number);
        Si++;
    }
    memcpy(&ApplVar.Size, Si, sizeof(ApplVar.Size));    /* copy CONSTruction to work */
    if (!ApplVar.Size.Length)     /* not active report */
        return 0;
    if (!(ApplVar.Size.Periods & (0x01 << ApplVar.Report.Period))) /* not active */
        return 0;
    temp = 0x01;
    periods = 0;
    periodnumber = 0;
    do
    {
        if (temp & (0x01 << ApplVar.Report.Period))
            periodnumber = periods;
        if (ApplVar.Size.Periods & temp)
            periods++;
        temp <<= 1;
    } while (temp < 0x10);
    RamOffSet = ApplVar.AP.StartAddress[AddrTotl] + ApplVar.Report.OffSet + skip +
                (WORD)ApplVar.Report.Pointer * ApplVar.Size.Length * periods +
                (WORD)ApplVar.Size.Length * periodnumber +
                (WORD)ApplVar.Report.Start * ApplVar.Report.Size;
    ReadTotal();
    if (CheckNotZero(&ApplVar.Total.Amt))
        return 1;
    return 0;
}


void PrintReport(short RepFor,struct REPSIZE *S)
{
    BYTE temp, periods, periodnumber;

    WORD skip, total;
    UnLong save ;     /* unsigned long save; */
    UnLong TempL ;

    if (ApplVar.Report.Type != REPORT_INVENTORY)          /* ApplVar.Plu inventory ? */ //lyq
    {
        skip = 0;
        if (ApplVar.Report.PointerType)
        {
            skip += PeriodSkip(S, 1);
            S++;
        }
        if (ApplVar.Report.PointerType > 1)
        {
            skip += PeriodSkip(S, ApplVar.AP.Clerk.Number);
            S++;
        }
        if (ApplVar.Report.PointerType > 2)
        {
            skip += PeriodSkip(S, ApplVar.AP.Zone.Number);
            S++;
        }
        if (ApplVar.Report.PointerType > 3)
        {
            skip += PeriodSkip(S, ApplVar.AP.Day.Number);
            S++;
        }
        if (ApplVar.Report.PointerType > 4)
        {
            skip += PeriodSkip(S, ApplVar.AP.SalPer.Number);
            S++;
        }
        memcpy(&ApplVar.Size, S, sizeof(ApplVar.Size));    /* copy CONSTruction to work */
        if (!ApplVar.Size.Length)     /* not active report */
            return;
        if (!(ApplVar.Size.Periods & (0x01 << ApplVar.Report.Period))) /* not active */
            return;
        temp = 0x01;
        periods = 0;
        periodnumber = 0;
        do
        {
            if (temp & (0x01 << ApplVar.Report.Period))
                periodnumber = periods;
            if (ApplVar.Size.Periods & temp)
                periods++;
            temp <<= 1;
        } while (temp < 0x10);
        RamOffSet = ApplVar.AP.StartAddress[RepFor] + ApplVar.Report.OffSet + skip +
                    (WORD)ApplVar.Report.Pointer * ApplVar.Size.Length * periods +
                    (WORD)ApplVar.Size.Length * periodnumber +
                    (WORD)ApplVar.Report.Start * ApplVar.Report.Size;
    }

    temp = 0;

#if defined(FISCAL)
    if (ApplVar.MultiplyCount && !ApplVar.RepComputer && ApplVar.Report.System != 3)        /* range entered ? */
#else
    if (ApplVar.MultiplyCount && !ApplVar.RepComputer)      /* range entered ? */
#endif
    {
        if ((ApplVar.Report.Type == REPORT_PLU || ApplVar.Report.Type == REPORTTYPE_MAX) && ApplVar.AP.Plu.RandomSize)      /* PLU ? */
        {
            save = RamOffSet;               /* save report start */
            RamOffSet = ApplVar.AP.StartAddress[AddrPLU];    /* start plu table */
            ApplVar.Report.Start = GetPluNumber(0, ApplVar.Qty1.Value);
            if (ApplVar.MultiplyCount == 2)
            {
                RamOffSet = ApplVar.AP.StartAddress[AddrPLU];    /* start plu table */
                total = GetPluNumber(0, ApplVar.Qty2.Value);
            }
            else
                total = ApplVar.Report.Start;
            RamOffSet = save;
        }
        else
        {
            ApplVar.Report.Start = (WORD) BCDValueToULong(ApplVar.Qty1.Value, 3);
            if (ApplVar.MultiplyCount == 2)
                total = (WORD) BCDValueToULong(ApplVar.Qty2.Value, 3);      /* end address */
            else
                total = ApplVar.Report.Start;
        }
        if (total <= ApplVar.Report.End)
            ApplVar.Report.End = total;
        if (!ApplVar.Report.Start || ApplVar.Report.End < ApplVar.Report.Start)
            return;
        if (!MyFlags(CLOSEPRINT)) //ccr2018-03-21 Ϊ��ӡ˰�ر���ͬʱ�ر��˴�ӡ��(�������)
           PrintRange();   /* print Range Line */
        ApplVar.Report.Start--;
        RamOffSet += ApplVar.Report.Size * ApplVar.Report.Start;
    }

    for (total = ApplVar.Report.Start; total < ApplVar.Report.End; total++)
    {
        save = RamOffSet;
        if (ApplVar.RepComputer == 'C' && ApplVar.FReport == Z)
        {
            ResetReport();
            RamOffSet = save + ApplVar.Report.Size ;
            continue;
        }
        if (ApplVar.Report.Type == REPORT_INVENTORY)   //lyq       /* inventory then always all plu's */
        {
            if (!ApplVar.AP.Plu.InvSize)            /* not active */
                break;
            SETBIT(ApplVar.Total.Qty.Sign, BIT2);
        }
        else
        {
            ReadTotal();     /* read correct total */
            if (CheckNotZero(&ApplVar.Total.RetQty))   /* Not Zero then */
                SETBIT(ApplVar.Total.RetQty.Sign, BIT7); /* Always negative */
        }


#if defined(FISCAL)
        //ccr2017-08-02 In this section must print all taxes even the ones that are zero
        if (BIT(ApplVar.Total.Qty.Sign, BIT2) || ApplVar.Report.Type == REPORT_TAX)     /* used ? */
#else
        if (BIT(ApplVar.Total.Qty.Sign, BIT2))     /* used ? */
#endif
        {
            ApplVar.Total.Qty.Sign &= 0x83;
            if (!MyFlags(CLOSEPRINT)) //ccr2018-03-21 Ϊ��ӡ˰�ر���ͬʱ�ر��˴�ӡ��(�������)
               if (!temp)
            {//û�д�ӡ��������������,�ڴ˴�ӡ:/DEPARTMENT/GROUP/TAX....
                if (ApplVar.Report.System == 1)
                    PrintPointType();
                else if (!ApplVar.RepComputer)
                    PrintReportType();
                temp = 1;
            }

            if (!ApplVar.RepComputer)
            {
                memset(SysBuf, ' ', PRTLEN);
                if (ApplVar.Report.Type != REPORT_PLU && BIT(KEYTONE, BIT2))  /* Not print Number */
                    /* with PLU always */
                    SysBuf[0] = 0;
                else
                {
                    WORDtoASCZero(SysBuf + 5, total + 1);
                    if ((CHARSET & 0xf0) == 0x10 || (SLIP != 4 &&
                                                     ((CHARSET & 0x0f) == 3 || (CHARSET & 0x0f) == 7)
                                                    ))  /* number sign not available */
                        SysBuf[0] = 'N';
                    else
                        SysBuf[0] = '#';
                }
            }
            else
                memset(SysBuf + 7, 0, 24);

            if (ApplVar.Report.Type != REPORT_INVENTORY)  /* not inventory ? */ //lyq
            {
                Add(&ApplVar.SaleQty, &ApplVar.Total.Qty);
                Add(&ApplVar.SaleAmt, &ApplVar.Total.Amt);
            }
            //ccr2017-06-01..�ڵ������¹��ܺ���ǰ,����SysBuf[0]�����˱�־�ַ�,������ӡ��ʽ....................
            switch (ApplVar.Report.Type)
            {
            case REPORT_GRANDTOTAL:     /* total Sales */
                if (ApplVar.RepComputer)
                {
                    *((WORD *)SysBuf) = RTOTAL;
                    memcpy(SysBuf + 7, ApplVar.TXT.ReportType[0], sizeof(ApplVar.TXT.ReportType[0]));
                }
                break;
            case REPORT_GROUP:     /* group sales */
               if (!MyFlags(CLOSEPRINT)) //ccr2018-03-21 Ϊ��ӡ˰�ر���ͬʱ�ر��˴�ӡ��(�������)
                  PrintGroup(total);
                break;
            case REPORT_DEPARTMENT:     /* dept sales*/
               if (!MyFlags(CLOSEPRINT)) //ccr2018-03-21 Ϊ��ӡ˰�ر���ͬʱ�ر��˴�ӡ��(�������)
                  PrintDept(total);
                break;
            case REPORT_PLU:     /* plu sales*/
            case REPORTTYPE_MAX:        /* Inventory */      //lyq modefied 2003/11/1
               if (!MyFlags(CLOSEPRINT)) //ccr2018-03-21 Ϊ��ӡ˰�ر���ͬʱ�ر��˴�ӡ��(�������)
                  PrintPlu(total);
                break;
            case REPORT_TENDER:     /* tender */
               if (!MyFlags(CLOSEPRINT)) //ccr2018-03-21 Ϊ��ӡ˰�ر���ͬʱ�ر��˴�ӡ��(�������)
                  PrintTender(total);
                break;
            case REPORT_PORA:     /* Po & Ra */
               if (!MyFlags(CLOSEPRINT)) //ccr2018-03-21 Ϊ��ӡ˰�ر���ͬʱ�ر��˴�ӡ��(�������)
                  PrintPoRa(total);
                break;
            case REPORT_DRAWER:     /* drawer */
               if (!MyFlags(CLOSEPRINT)) //ccr2018-03-21 Ϊ��ӡ˰�ر���ͬʱ�ر��˴�ӡ��(�������)
                  PrintDrawer(total);
                break;
            case REPORT_CORRECTION:     /* correction */
               if (!MyFlags(CLOSEPRINT)) //ccr2018-03-21 Ϊ��ӡ˰�ر���ͬʱ�ر��˴�ӡ��(�������)
                  PrintCorrec(total);
                break;
            case REPORT_DISCOUNT:     /* discount*/
                PrintDisc(total);
                break;
            case REPORT_CURRENCY:     /* foreign currency */
               if (!MyFlags(CLOSEPRINT)) //ccr2018-03-21 Ϊ��ӡ˰�ر���ͬʱ�ر��˴�ӡ��(�������)
                  PrintCurrency(total);
                break;
            case REPORT_TAX: /* tax */
                PrintTax(total);
                break;
            case REPORT_PBFUNC: /* pb info */
               if (!MyFlags(CLOSEPRINT)) //ccr2018-03-21 Ϊ��ӡ˰�ر���ͬʱ�ر��˴�ӡ��(�������)
                  PrintPbF(total);
                break;
            case REPORT_TABLES:
               if (!MyFlags(CLOSEPRINT)) //ccr2018-03-21 Ϊ��ӡ˰�ر���ͬʱ�ر��˴�ӡ��(�������)
                  PrintPb(total);
                break;
            default:
                return;
            }
            if (ApplVar.RepComputer)
            {
                *((WORD *)SysBuf) += total;     /* add current total number */
                SysBuf[2] = 0x80 + ApplVar.Report.Type + 1;  /* type = descriptor */
                SendRecord(SysBuf, 7 + 24); /* always send max size */
                if (ApplVar.Report.Type == REPORT_INVENTORY && ApplVar.AP.Plu.InvSize)   //lyq
                    SendComp(11, &ApplVar.PluInventory);
            }
            if (!MyFlags(CLOSEPRINT)) //ccr2018-03-21 Ϊ��ӡ˰�ر���ͬʱ�ر��˴�ӡ��(�������)
               if (ApplVar.Report.Type != REPORT_INVENTORY)  //lyq            /* inventory  ? */
                  PrintTotal();

            if (ApplVar.Report.System == 4 &&
                (ApplVar.Report.Type == REPORT_GROUP || ApplVar.Report.Type == REPORT_DEPARTMENT))
            {
                Divide(&ApplVar.Total.Amt, &ApplVar.SubTotal);
                RoundBcd(&ApplVar.Total.Amt, 4);
                ApplVar.Total.Amt.Sign &= 0x80;
                ApplVar.Total.Amt.Sign |= 0x02;
                if (!MyFlags(CLOSEPRINT)) //ccr2018-03-21 Ϊ��ӡ˰�ر���ͬʱ�ر��˴�ӡ��(�������)
                {
                   MemSet(SysBuf, 24, ' ');
                   FormatQty(SysBuf+19, &ApplVar.Total.Amt);

                   SysBuf[4] = '_';
                   SysBuf[5] = SysBuf[13];
                   SysBuf[6] = '_';
                   SysBuf[7] = SysBuf[14];
                   SysBuf[8] = '_';
                   SysBuf[9] = SysBuf[15];
                   SysBuf[10] = '_';
                   SysBuf[11] = SysBuf[16];
                   SysBuf[12] = '_';
                   SysBuf[13] = SysBuf[17];
                   SysBuf[14] = '_';
                   SysBuf[15] = SysBuf[18];
                   SysBuf[16] = '_';
                   SysBuf[17] = SysBuf[19];
                   SysBuf[18] = '_';
                   SysBuf[19] = '%';
                   PrintStr(SysBuf);
                }
            }
            if (CheckBreak())
                return;
            RamOffSet = save;       /* reset address pointer */
            ResetReport();
        }
        else if (CheckBreak())
            return;
        RamOffSet = save + ApplVar.Report.Size;
    }

    if (!MyFlags(CLOSEPRINT)) //ccr2018-03-21 Ϊ��ӡ˰�ر���ͬʱ�ر��˴�ӡ��(�������)
       if (!ApplVar.RepComputer && temp)
    {
        PrintLine('-');
    }
}


void PrintPluReport(short RepFor)
{
    ApplVar.Report.End = ApplVar.AP.Plu.Number;
    if (ApplVar.AP.Plu.RandomSize)
        ApplVar.Report.End =ApplVar.AP.Plu.RNumber;     /* calculate bytes to move 2nd part */
    if (!ApplVar.Report.End)
        return;
    ApplVar.Report.OffSet = ApplVar.AP.Plu.TotalOffSet;
    ApplVar.Report.Size = ApplVar.AP.Plu.RecordSize;
    PrintReport(RepFor,ApplVar.AP.Plu.Size);
}


void PrintDeptReport()
{
    if (!ApplVar.AP.Dept.Number)
        return;
    ApplVar.Report.End = ApplVar.AP.Dept.Number;
    ApplVar.Report.OffSet = ApplVar.AP.Dept.TotalOffSet;
    ApplVar.Report.Size = ApplVar.AP.Dept.RecordSize;
    PrintReport(AddrDept,ApplVar.AP.Dept.Size);
}

void PrintGroupReport()
{
    if (!ApplVar.AP.Group.Number)
        return;
    ApplVar.Report.End = ApplVar.AP.Group.Number;
    ApplVar.Report.OffSet = ApplVar.AP.Group.TotalOffSet;
    ApplVar.Report.Size = ApplVar.AP.Group.RecordSize;
    PrintReport(AddrGroup,ApplVar.AP.Group.Size);
}


void PrintTendReport()
{
    if (!ApplVar.AP.Tend.Number)
        return;
    ApplVar.Report.End = ApplVar.AP.Tend.Number;
    ApplVar.Report.OffSet = ApplVar.AP.Tend.TotalOffSet;
    ApplVar.Report.Size = ApplVar.AP.Tend.RecordSize;
    PrintReport(AddrTend,ApplVar.AP.Tend.Size);
}

void PrintPoRaReport()
{
    if (!ApplVar.AP.PoRa.Number)
        return;
    ApplVar.Report.End = ApplVar.AP.PoRa.Number;
    ApplVar.Report.OffSet = ApplVar.AP.PoRa.TotalOffSet;
    ApplVar.Report.Size = ApplVar.AP.PoRa.RecordSize;
    PrintReport(AddrPoRa,ApplVar.AP.PoRa.Size);
}


void PrintCurrReport()
{
    if (!ApplVar.AP.Curr.Number)
        return;
    ApplVar.Report.End = ApplVar.AP.Curr.Number;
    ApplVar.Report.OffSet = ApplVar.AP.Curr.TotalOffSet;
    ApplVar.Report.Size = ApplVar.AP.Curr.RecordSize;
    PrintReport(AddrCurr,ApplVar.AP.Curr.Size);
}


void PrintDrawReport()
{
    if (!ApplVar.AP.Draw.Number)
        return;
    ApplVar.Report.End = ApplVar.AP.Draw.Number;
    ApplVar.Report.OffSet = ApplVar.AP.Draw.TotalOffSet;
    ApplVar.Report.Size = ApplVar.AP.Draw.RecordSize;
    PrintReport(AddrDrawer,ApplVar.AP.Draw.Size);
}

void PrintCorrecReport()
{
    if (!ApplVar.AP.Correc.Number)
        return;
    ApplVar.Report.End = ApplVar.AP.Correc.Number;
    ApplVar.Report.OffSet = ApplVar.AP.Correc.TotalOffSet;
    ApplVar.Report.Size = ApplVar.AP.Correc.RecordSize;
    PrintReport(AddrCorr,ApplVar.AP.Correc.Size);
}

void PrintDiscReport()
{
    if (!ApplVar.AP.Disc.Number)
        return;
    ApplVar.Report.End = ApplVar.AP.Disc.Number;
    ApplVar.Report.OffSet = ApplVar.AP.Disc.TotalOffSet;
    ApplVar.Report.Size = ApplVar.AP.Disc.RecordSize;
    PrintReport(AddrDisc,ApplVar.AP.Disc.Size);
}

void PrintTaxReport()
{
    if (!ApplVar.AP.Tax.Number)
        return;
    ApplVar.Report.End = ApplVar.AP.Tax.Number;
    ApplVar.Report.OffSet = ApplVar.AP.Tax.TotalOffSet;
    ApplVar.Report.Size = ApplVar.AP.Tax.RecordSize;
    PrintReport(AddrTax,ApplVar.AP.Tax.Size);
}


void PrintPbFReport()
{
    if (!ApplVar.AP.Pb.Number || !ApplVar.AP.Pb.NumberOfPb)
        return;
    ApplVar.Report.End = ApplVar.AP.Pb.Number;
    ApplVar.Report.OffSet = ApplVar.AP.Pb.TotalOffSet;
    ApplVar.Report.Size = ApplVar.AP.Pb.RecordSize;
    PrintReport(AddrPBf,ApplVar.AP.Pb.Size);
}

void PrintPbtReport()
{
    if (!ApplVar.AP.Pb.Number || !ApplVar.AP.Pb.NumberOfPb)
        return;
    ApplVar.Report.End = ApplVar.AP.Pb.NumberOfPb;
    ApplVar.Report.OffSet = ApplVar.AP.Pb.PBTTotalOffset;
    ApplVar.Report.Size = ApplVar.AP.Pb.PBTRecordSize;
    PrintReport(AddrPBt,ApplVar.AP.Pb.PBTSize);
}


void PrintOpenPb()
{
    BYTE printed;
    UnLong TempL ;
    if (!ApplVar.AP.Pb.NumberOfPb)     /* not active */
        return;

    ApplVar.Entry = ZERO;
    ApplVar.Report.End = ApplVar.AP.Pb.NumberOfPb;
    if (ApplVar.MultiplyCount && !ApplVar.RepComputer)
    {
        ApplVar.PbNumber = (WORD) BCDValueToULong(ApplVar.Qty1.Value, 3);
        if (ApplVar.MultiplyCount == 2)
        {
            ApplVar.Report.End = (WORD) BCDValueToULong(ApplVar.Qty2.Value,3);                 /* end address */
            if (ApplVar.AP.Pb.NumberOfPb < ApplVar.Report.End)
                ApplVar.Report.End = ApplVar.AP.Pb.NumberOfPb;
        }
        else
            ApplVar.Report.End = ApplVar.PbNumber;  /* One total only */
        ApplVar.Report.Start = ApplVar.PbNumber;
    }
    else
        ApplVar.PbNumber = 1;
    printed = 0;
    for (; ApplVar.PbNumber <= ApplVar.Report.End; ApplVar.PbNumber++)
    {
        PbTotal(ApplVar.PbNumber, 0);   /* read */
        if (ApplVar.PB.Block)        /* check if open */
        {
            if (ApplVar.Report.PointerType == 1 && ApplVar.Report.Pointer != (ApplVar.PB.Clerk - 1))
                continue;

//ccr091125PB.SalPer?			if (ApplVar.Report.PointerType == 5 && ApplVar.Report.Pointer != (ApplVar.PB.SalPer - 1))
//ccr091125PB.SalPer?				continue; //lyq20040113 added for print the "open table message"

            AmtRound(0, &ApplVar.PB.Amt);   /* round total amount */
            if (ApplVar.RepComputer && ApplVar.RepComputer != 'C')      /* 'C' is only reset */
            {
                *((WORD *)SysBuf) = PBTOT + ApplVar.PbNumber;
                SysBuf[3] = ApplVar.Report.Period;
                SysBuf[4] = ApplVar.Report.PointerType;
                if (ApplVar.Report.PointerType == 1)
                    *((WORD *)(SysBuf + 5)) = ApplVar.PB.Clerk - 1;
                else
                    *((WORD *)(SysBuf + 5)) = 0;
                if (ApplVar.AP.Pb.Random & 0x0f)
                {
                    SysBuf[2] = 0;  /* type = random number */
                    memcpy(SysBuf+7, ApplVar.PB.Random, 7);
                    SendRecord(SysBuf, 7 + 7);     /* always max size 14 */
                }
                if (ApplVar.AP.Pb.Text)
                {
                    SysBuf[2] = 1;  /* type = text */
                    memcpy(SysBuf+7, ApplVar.PB.Text, ApplVar.AP.Pb.Text);
                    SendRecord(SysBuf, 7 + 24);     /* always max size 24 */
                }
                SendComp(7, &ApplVar.PB.Amt);
            }
            else if (!ApplVar.RepComputer)
            {
                if (!printed)
                {
                    if (ApplVar.MultiplyCount)
                        PrintRange();           /* print entered range */
                    if (ApplVar.Report.System == 1)
                    {
                        if (ApplVar.Report.PointerType == 1)
                            PrintPointType();
                    }
                    else
                        PrintReportHeader();
                    printed = 1;
                }
                else
                    ApplVar.MultiplyCount = 0;
                if (ApplVar.AP.Pb.Random & 0x0f)
                {
                    memcpy(ApplVar.Entry.Value, ApplVar.PB.Random, 7);
                }
                else
                    WORDtoBCD(ApplVar.Entry.Value, ApplVar.PbNumber);
                PrintQty(Prompt.Caption[ItemPrompt23], &ApplVar.Entry);
                if (ApplVar.AP.Pb.Text)
                    PrintStr(ApplVar.PB.Text);
                PrintAmt(Prompt.Caption[ItemPrompt7], &ApplVar.PB.Amt);       /* Skip 2 spaces in front */
            }
            if (CheckBreak())
                return;

            Add(&ApplVar.SaleAmt, &ApplVar.PB.Amt);
#if (0)//ccr091214>>>>>>>>>>>
            if (ApplVar.FReport == Z)
            {
                if (ApplVar.Report.PointerType == 1 || ApplVar.MultiplyCount) /* clerk report */
                    PbTotal(ApplVar.PbNumber, 2);   /* reset ApplVar.PB of current ApplVar.Clerk */
                else
                {
                    MemSet(&ApplVar.PB, sizeof(ApplVar.PB), 0);
                    PbTotal(ApplVar.PbNumber, 1);    /* write back empty table */
                }
            }
#endif//<<<<<<<<<<<<<<<<<<<<
        }
    }
    //if (!ApplVar.RepComputer)
    //    PrintLine('=');//��Լֽ��
#if (0)//ccr091214>>>>>>>>>>>>>>>>>>>>>>
    if (ApplVar.Report.PointerType != 1  && !ApplVar.MultiplyCount && /* not clerk report */
        ApplVar.FReport == Z)
    {
        if (ApplVar.AP.StartAddress[AddrTrack] && ApplVar.AP.Pb.BlockSize) /* trackbuffer ? */
        {
            MemSet(SysBuf, ApplVar.AP.Pb.BlockSize, 0);
            RamOffSet = ApplVar.AP.StartAddress[AddrTrack];
            for (ApplVar.EmptyBlock = 0; ApplVar.EmptyBlock < ApplVar.AP.Pb.NumberOfBlocks; ApplVar.EmptyBlock++)
                WriteRam(SysBuf, ApplVar.AP.Pb.BlockSize);
            ApplVar.EmptyBlock = 0;
        }
    }
#endif//<<<<<<<<<<<<<<<<<<<<<<<<<<<
    ApplVar.PbNumber = 0;
}

void PrintPointReport()
{
    ApplVar.SaleAmt = ZERO;
    ApplVar.SaleQty = ZERO;
//ccr20130318>>>>>>>>>>>
    if (ApplVar.FReport == Z)
    {
        if (!CheckZeroReport() &&
            ApplVar.Report.System != 3 &&   /* only reset with fiscal */
            MyFlags(ZREPORT))//ccr20130318 !ApplVar.Report.PointerType)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI75);//�ȴ�ӡ˰��Z����
        }
    }
//<<<<<<<<<<<<<<<<<<<<<<<

    switch (ApplVar.Report.Type)
    {
    case REPORT_GRANDTOTAL://�����ܼ�Print TOTALSALES recordes
        ApplVar.Report.End = 1;
        ApplVar.Report.Size = ApplVar.AP.Sales.RecordSize;
        ApplVar.Report.OffSet = 0;
        PrintReport(AddrTotl,ApplVar.AP.Sales.Size);
        break;
    case REPORT_GROUP://����ͳ��
        PrintGroupReport();
        break;
    case REPORT_DEPARTMENT://����ͳ��
        PrintDeptReport();
        break;
    case REPORT_PLU://��Ʒͳ��
        PrintPluReport(AddrPLU);
        break;
    case REPORT_TENDER://����ͳ��
        PrintTendReport();
        break;
    case REPORT_PORA://�����ͳ��
        PrintPoRaReport();
        break;
    case REPORT_DRAWER://Ǯ��ͳ��
        PrintDrawReport();
        break;
    case REPORT_CORRECTION://����ͳ��
        PrintCorrecReport();
        break;
    case REPORT_DISCOUNT://�ۿ�ͳ��
        PrintDiscReport();
        break;
    case REPORT_CURRENCY://���ͳ��
        PrintCurrReport();
        break;
    case REPORT_TAX://��˰ͳ��
        PrintTaxReport();
        break;
    case REPORT_PBFUNC://����ͳ��
        PrintPbFReport();
        break;
    case REPORT_BALANCE://����ͳ�� /* open table */
        PrintOpenPb();
        break;
    case REPORT_TABLES:
        PrintPbtReport();
        break;
    case REPORT_INVENTORY://��Ʒ��� /* ApplVar.Plu inventory */
        PrintPluReport(AddrRPLU);
        break;
    default :
        break;
    }
    if (!MyFlags(CLOSEPRINT)) //ccr2018-03-21 Ϊ��ӡ˰�ر���ͬʱ�ر��˴�ӡ��(�������)
       if ((ApplVar.MultiplyCount && ApplVar.Report.Type && (ApplVar.Report.Type == REPORT_BALANCE || ApplVar.Report.Type < REPORT_TENDER))
           || ApplVar.Report.Type == REPORT_INVENTORY)   /* Inventory ? */   //lyq
    {
        if (ApplVar.Size.Qty || ApplVar.Report.Type == REPORT_INVENTORY)
            PrintQty(Prompt.Caption[ItemPrompt6], &ApplVar.SaleQty);
        PrintAmt(Prompt.Caption[ItemPrompt7], &ApplVar.SaleAmt);
        PrintLine('-');
    }
    ApplVar.MultiplyCount = 0;
}

/* you must set up the period, pointertype and pointer number */

void GetSystemReport(BYTE clearall )
{

    if (!ApplVar.RepComputer && !clearall)
    {
/*		if (!ApplVar.ClerkNumber)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI33);
            return;
        }
        if (ApplVar.AP.SalPer.Number && !ApplVar.SalPerNumber)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI34);
            return;
        }
*/
        if (!Appl_EntryCounter || Appl_EntryCounter > 5)
        {
            ApplVar.ErrorNumber=ERROR_ID(CWXXI26);
            return;
        }

#if defined(FISCAL)
        ApplVar.PrintLayOut = 0x0b;
        ApplVar.FStatus = 0;        /* not Fiscal */
#else
        ApplVar.PrintLayOut = 0x0a;
#endif
        CheckSlip();
    }
    if (!clearall)
    {
        MemSet(&ApplVar.Report, sizeof(ApplVar.Report), 0);
        ApplVar.Report.Type = EntryBuffer[ENTRYSIZE - 3] & 0x0f;
        ApplVar.Report.Type *= 10;
        ApplVar.Report.Type += EntryBuffer[ENTRYSIZE - 2] & 0x0f;
        ApplVar.Report.PointerType = EntryBuffer[ENTRYSIZE - 4] & 0x0f;
        ApplVar.Report.Period = EntryBuffer[ENTRYSIZE - 5] & 0x0f;
    }
    ApplVar.Report.System = 1;
    if (!SetUpReport() || clearall)
    {
        if (clearall)
            ApplVar.ErrorNumber=0;
        else if (!ApplVar.RepComputer)
        {
            PrintHeader();       /* print rest of header */
            PrintReportHeader();
            if (ApplVar.Report.Type < REPORT_BALANCE)
                PrintReportType();
        }
        if (Appl_EntryCounter < 5)
            ApplVar.Report.Pointer = 0;
        else
            ApplVar.Report.PointerEnd = ApplVar.Report.Pointer + 1;
        for (;ApplVar.Report.Pointer < ApplVar.Report.PointerEnd; ApplVar.Report.Pointer++)
        {
            if (ApplVar.Report.PointerType == 1)
            {
                ApplVar.ClerkNumber = ApplVar.Report.Pointer + 1;
                ReadClerk();
                if (!ApplVar.RepComputer && !BIT(ApplVar.Clerk.Options, BIT7) &&
                    Appl_EntryCounter < 5 && !BIT(CLERKFIX, BIT6))
                    /* all pointers then skip training clerk ? */
                    continue;
            }
            if (clearall)
                SETMyFlags( CLOSEPRINT);//ccr090508
            PrintPointReport();
            if (clearall)
                CLRMyFlags( CLOSEPRINT);//ccr090508

            if (ApplVar.ErrorNumber)  /* break */
                break;
        }

        if (!clearall)
            ReportEnd(1);
    }
}

/**
 * ��ӡ����
 *
 * @author EutronSoftware (2017-05-22)
 *
 * @param xzNum:1~XZNUM+1
 */
void GetReport(BYTE xzNum)
{
    BYTE i, repnum;
    int j;

    if (!xzNum || xzNum>XZNUM+1)
    {
        ApplVar.ErrorNumber=ERROR_ID(CWXXI26);
        return;
    }
    if (xzNum == XZNUM+1)
        repnum = XZNUM;// Pb Invoice report
    else
        repnum = XZTitle[xzNum-1].Index-1;

    if (xzNum==1 && ApplVar.FReport==Z && BIT(ApplVar.Fiscal_PrintFlag, BIT5))//���Z����
        CLRMyFlags(ZREPORT);

    MemSet(&ApplVar.Report, sizeof(ApplVar.Report), 0);

//	for(i=0;i<ApplVar.AP.Tax.Number;i++)
// 	ApplVar.FNetTotal[i] = ZERO;	//liuj 0605
    ApplVar.FStatus = 0;    /* non fiscal report */
    if (xzNum == 1 && ApplVar.FReport==Z)   /* fiscal report then copy report 0 from eprom */
    {
/*????	memcpy( (char *)&ApplVar.AP.ReportList[repnum],
           (CONSTCHAR *)&Default.ReportList[repnum], sizeof(struct FIXEDREPORT));*/
        ApplVar.Report.System = 3;  /* set fiscal report */
        MemSet(ApplVar.TaxItem, sizeof(ApplVar.TaxItem), 0);    /* used to collect data for */
        /* fiscal eprom */
    }

    if (repnum == XZNUM)
    {
#if !defined(FISCAL)
        if (!BIT(KEYTONE, BIT3))    /* print power up message ? */
            ApplVar.PrintLayOut = 0x03;     /* r & j */
        else
            ApplVar.PrintLayOut = 0x02;     /* r & j */
#else
        ApplVar.PrintLayOut = 0x03;     /* r & j */
#endif
    }
    else
    {
        ApplVar.Report.PointerType = ApplVar.AP.ReportList[repnum].PointerType;
        ApplVar.PrintLayOut = ApplVar.AP.ReportList[repnum].PrintLayOut;
        ApplVar.Report.Period = ApplVar.AP.ReportList[repnum].Period;
    }

    if (!ApplVar.RepComputer)
    {
#if (0) //ccr2018-01-17>>>������ѵģʽ�´�ӡZ��������>>>>
        if (ApplVar.FReport != SET)
        {
            if (ApplVar.FTrain) /* Training ? ��ѵģʽ��ֹ��ӡZ���� ???? */
            {
                if (ApplVar.Report.PointerType != 1)
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI32);
                    return;
                }
                else if (BIT(ApplVar.AP.ReportList[repnum].Options, BIT1))   /* all pointers ?*/
                {
                    ApplVar.ErrorNumber=ERROR_ID(CWXXI32);
                    return;
                }
            }
        }
#endif  //ccr2018-01-17>>>������ѵģʽ�´�ӡZ��������<<<<<<<
        if (CheckSlip())
            return;

        if (xzNum== 1  && ApplVar.FReport == Z)
        {
            ApplVar.FStatus = 1;    /* set fiscal report */
        }

        if (!MyFlags(CLOSEPRINT)) //ccr2018-03-21 Ϊ��ӡ˰�ر���ͬʱ�ر��˴�ӡ��(�������)
        {
   #if defined(CASE_GREECE)//ccr2018-01-09>>>>>>>>>>>>>>
           if (BIT(ApplVar.ContFlag, STOREEJ2_AZ) && !ApplVar.FTrain)
               PrintStr_Center((char*)MsgRECEIPTSTART,true);
           else
               PrintStr_Center((char*)MsgTEMPRECEIPTSTART,true);
   #endif

   //ccr2018-01-09        if (ApplVar.PrintLayOut & 0x02)     /* print on receipt ? */
                 PrintHeader();

   #if defined(CASE_ITALIA)
          if (!BIT(ApplVar.ContFlag, STOREEJ2_AZ) || ApplVar.FTrain)
              Print_NonFiscal(1);
   #endif//ccr2018-01-09

           PrintDateTime();
           PrintLine('.');
           AddReceiptNumber();
           FiscalHeader();

           if (repnum == XZNUM)
               memcpy(SysBuf, ApplVar.TXT.ReportType[REPORTTYPE_MAX], sizeof(ApplVar.TXT.ReportType[0]));
           else
               memcpy(SysBuf, ApplVar.AP.ReportList[repnum].Name, sizeof(ApplVar.AP.ReportList[0].Name));
           j=strlen(SysBuf);SysBuf[j++] = '-';
           memset(SysBuf+j, ' ',PRTLEN); SysBuf[PRTLEN]=0;;

           i = ApplVar.PrintLayOut;
           ApplVar.PrintLayOut &= 0xe7;
           SETBIT(ApplVar.PrintLayOut, BIT2);      /* Double Height */

           if (ApplVar.FReport == Z)//ccr071212
           {
               SysBuf[j++] = 'Z';
               SysBuf[PRTLEN-ULongtoASCZER0(SysBuf+PRTLEN-1,ApplVar.ZCount[FISCALZNUM],4)-1]='#';
               PrintRJ(SysBuf);
           }
           else
           {
               SysBuf[j++] = 'X';SysBuf[j]=0;
               PrintStr_Center(SysBuf,true);
           }


           ApplVar.PrintLayOut = i;
           PrintLine('=');
        }


        if (repnum == XZNUM)        /* Pb Invoice report ? */
        {
            if (!SetUpReport())
            {
                StorePbInvoice(2);      /* Print Pb Invoice report */
                ReportEnd(0);
                return;
            }
        }

        if (BIT(ApplVar.AP.ReportList[repnum].Options, BIT0))   /* open drawer ?*/
            OpenDrawer();
    }
    if (!SetUpReport())
    {
        if (ApplVar.RepComputer || BIT(ApplVar.AP.ReportList[repnum].Options, BIT1))   /* all pointers ?*/
            ApplVar.Report.Pointer = 0;
        else
            ApplVar.Report.PointerEnd = ApplVar.Report.Pointer + 1;
#if (defined(CASE_GREECE))//ϣ���ڽ��ǰ����ӡŷԪ����
        Prefix1 = Prefix2 = 0;
#endif
        for (;ApplVar.Report.Pointer < ApplVar.Report.PointerEnd; ApplVar.Report.Pointer++)
        {
            if (ApplVar.Report.PointerType == 1)
            {//report for clerk
                ApplVar.ClerkNumber = ApplVar.Report.Pointer + 1;
                ReadClerk();
                if (!ApplVar.RepComputer && !BIT(ApplVar.Clerk.Options,BIT7) &&
                    BIT(ApplVar.AP.ReportList[repnum].Options, BIT1) &&
                    !BIT(CLERKFIX, BIT6))
                    /* all pointers then skip training clerk ? */
                    continue;
            }
            if (ApplVar.RepComputer != 'C')
            {
                if ((ApplVar.Report.PointerType == 5 || ApplVar.Report.PointerType == 1) && CheckTotal() == 0)
                {
                    continue;
                }
                if (!MyFlags(CLOSEPRINT)) //ccr2018-03-21 Ϊ��ӡ˰�ر���ͬʱ�ر��˴�ӡ��(�������)
                   PrintPointType();
            }
            /* % comparison ? */
            if (!ApplVar.RepComputer && BIT(ApplVar.AP.ReportList[repnum].Options, BIT4))
            {
                i = ApplVar.PrintLayOut;
                ApplVar.PrintLayOut = 0;
                ApplVar.Report.Type = REPORT_GRANDTOTAL;                /* get total sales from this pointer */
                j = ApplVar.FReport;
                ApplVar.FReport = X;            /* simulate X */
                PrintPointReport();
                ApplVar.FReport = j;
                ApplVar.SubTotal = ApplVar.SaleAmt;             /* comparison total */
                ApplVar.Report.System = 4;              /* set percentage report */
                ApplVar.PrintLayOut = i;
            }
            for (i = 0; i < 16; i++)
            {
                ApplVar.Report.Type = ApplVar.AP.ReportList[repnum].Link[i];
                if (!ApplVar.Report.Type)   /* end list */
                    break;
                ApplVar.Report.Type--;
                if (ApplVar.MultiplyCount && !ApplVar.RepComputer)      /* range report? */
                    i = 16;         /* only print range !! */
                PrintPointReport();
                if (ApplVar.ErrorNumber)
                    break;
            }
            if (ApplVar.ErrorNumber)
                break;
        }
#if defined(FISCAL)
        if (xzNum == 1 && !ApplVar.RepComputer && !ApplVar.ErrorNumber /* fiscal report ? */
            && !BIT(ApplVar.Fiscal_PrintFlag,BIT5))     //�Ƿ���������ݴ���
        {
            //��ӡ������۹�����Ŀ��Z�������ݺ�,��ӡ�ʹ洢Z�����Ļ�������
            PrintFiscalTax();
        }
#else
        if (xzNum == 1 && !ApplVar.RepComputer && !ApplVar.ErrorNumber)     /* fiscal report ? */
            PrintAmt(Msg[GRANDTOTAL].str, &ApplVar.FTotal);  //cc 20071018
#endif

        ReportEnd(!BIT(ApplVar.AP.ReportList[repnum].Options, BIT3));   /* add Z-Count */
#if (defined(CASE_GREECE))//ϣ���ڽ��ǰ����ӡŷԪ����
        Prefix1 = PREFIX_1;
        Prefix2 = PREFIX_2;
#endif
#if !defined(FISCAL)//ccr091027
        if (BIT(ApplVar.AP.ReportList[repnum].Options, BIT2) && ApplVar.FReport == Z)   //ccr2014-9-11
        {
            if ((ApplVar.Report.PointerType == 1) && ApplVar.FTrain)
                ApplVar.FisNumber.ReceiptNum[TRECEIPTS] = 0; /*ccr091027 reset training receiptnumber ?*/
            else
            {/*ccr091027 reset  receiptnumber ?*/
                ApplVar.FisNumber.ReceiptNum[NRECEIPTS] = 0;
                ApplVar.FisNumber.ReceiptNum[FRECEIPTS] = 0; //ApplVar.SaleReceipts
            }
        }
#endif

    }
    //��ӡ��˺ֽλ��
    RFeed(PREHEADER+2);//    RFeed(4);//ccr2014-08-14 ����˺ֽλ��
}



