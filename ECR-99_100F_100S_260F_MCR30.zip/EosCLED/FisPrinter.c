#define FISPRINTER_C 7

#include "king.h"
#include "exthead.h"
#include "exth.h"
#include "flowbill.h"  //lyq2003
#include "Fiscal.h"
#include "ejournal.h"
#include "message.h"

#if(DD_FISPRINTER==1)

extern	WORD	sStartZ, sEndZ;

extern WORD BCC;

#define SendSeparator(sepChar) SendToHost(sepChar)
#define SendSTX() {BCC=STX;SendComm(COMPUTER_1,STX);}


#if !defined(FISCAL)

#define Read_FiscalData(a) {}
#define Write_FiscalRam(a,b,c)	1

#define  ProcessTax(a)		1

#define  ProcessHead()		1
#define  Read_FiscalRam(a,b,c)  1



WORD	sStartZ, sEndZ;


#endif



extern void LoadReceipLog();
extern BYTE CheckPrinter();

void FisPrinter_OperatePrivate();
BYTE FisPrinter_Status_Only();
BYTE FisPrinter_Status_Paper();


void UploadFiscalMemory();//ccr070214
void UploadElectronicMemory();;//ccr070214

#if CASE_FATFS_EJ  == 1
extern void ProcessEJ();
extern void PrintEJInfo();
extern void CheckEJ();
extern void PrintEJLog(BYTE prnCtrl);
#endif
/*******************************************************
�����ݴ�ASCII��ת����BCD
PAsc     ��Ҫת����ASCII
pBcd    �洢ת���õ�BCD
AscLen   ASCII�ĳ���
***********************************************************/
void AtoB(BYTE *pAsc,BYTE *pBcd,  BYTE AscLen)
{
    short   i,len;
    char   tmp[2];
    len= (AscLen/2)+ (AscLen%2);

    for(i=0;i<len;i++)
    	{
        if( *pAsc >= 'a' )
        	tmp[0]= *pAsc - 0x27;
        else if( *pAsc >= 'A')
        	tmp[0] = *pAsc - 7;
        else
        	tmp[0]= *pAsc;
        pAsc++;

        if( *pAsc >= 'a' )
        	tmp[1]= *pAsc - 0x27;
        else if( *pAsc >= 'A')
        	tmp[1] = *pAsc - 7;
        else
        	tmp[1]= *pAsc;
        pAsc++;

       *pBcd++ = ((tmp[0]&0x0f)<<4)+(tmp[1]&0x0f);
        }


}

// Set the fields position on PCBuffer

BYTE SetFields()
{
	BYTE  sFieldCount=0;
	WORD i;

	for (i=3;i<sizeof(PCBuffer) && sFieldCount<sizeof(FieldNumber);)
	{
		if (PCBuffer[i]==ETX)
		{
			FieldNumber[sFieldCount] = i+1;
			break;
		}
		else if (PCBuffer[i]==SEPARATOR)
		{
			i++;
			FieldNumber[sFieldCount++] = i;
		}
        else
            i++;
	}
	return sFieldCount;
}

//ccr070214>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>

// ���뽫ReadComm�еĶ�������ʱ�Ӵ�ASECOND*3 //
void SendToHost(BYTE cBYTE)
{
	if (cBYTE==STX) BCC=0;

	SendComm(COMPUTER_1,cBYTE);
	BCC+=cBYTE;
}
//---------------------------------------------
void SendAWord(WORD pWord)
{
	BYTE sStr[5];
	HEXtoASC(sStr,(char *)&pWord,2);
	SendComm(COMPUTER_1,sStr[0]);
	BCC+=sStr[0];
	SendComm(COMPUTER_1,sStr[1]);
	BCC+=sStr[1];
	SendComm(COMPUTER_1,sStr[2]);
	BCC+=sStr[2];
	SendComm(COMPUTER_1,sStr[3]);
	BCC+=sStr[3];
}
//---------------------------------------------
void SendAByte(BYTE pByte)
{
	BYTE sStr[3];
	HEXtoASC(sStr,(char *)&pByte,1);
	SendComm(COMPUTER_1,sStr[0]);
	BCC+=sStr[0];
	SendComm(COMPUTER_1,sStr[1]);
	BCC+=sStr[1];
}

//---------------------------------------------
//Send a BCD data
//pPoints=Bits after point must been send
//When pPoints=2:
//1234567.896---->123456789 been send
//1234567.8------>123456780 been send
void SendABCD(BCD *pBcd)
{
	BYTE sBcd,sP,sFlag,sCh;//
	short i;


	sP = (pBcd->Sign) & 0x07;
	if (BIT(pBcd->Sign, BIT7))
	{
		SendComm(COMPUTER_1,'-');
		BCC+='-';
	}

	sBcd=0xf0;
	sFlag = 0;
	for (i=BCDLEN-1;i>=0;)
	{
		sCh = pBcd->Value[i];
		if (!sFlag && (sCh & sBcd))
			sFlag = 1;
		if (sFlag)
		{
			if (sBcd == 0xf0)
				sCh = (sCh>>4)+'0';
			else
				sCh = (sCh & 0x0f)+'0';
			SendComm(COMPUTER_1,sCh);
			BCC+=sCh;
		}
		sBcd ^= 0xff;
		if (sBcd==0xf0)
			i--;
	}
	if(!sFlag)
		SendComm(COMPUTER_1, '0');

}
//-----------------------------------------
//Send a long short
void SendALong(long pLInt)
{
	BCD sBCD;
	sBCD = ZERO;
	if (pLInt<0)
	{
		SETBIT(sBCD.Sign,BIT7);
		pLInt = -pLInt;
	}
	ULongToBCDValue(sBCD.Value, pLInt);
	SendABCD(&sBCD);
}

//---------------------------------------------
void SendAString(BYTE *sStr,BYTE sLen)
{
	short i;
	for (i=0;i<sLen;i++)
	{
		SendComm(COMPUTER_1,sStr[i]);
		BCC+=sStr[i];
	}
}

//----------------------------------------------------------
void SendETX_BCC()
{
	BYTE sStr[5];

	SendComm(COMPUTER_1,ETX);
	BCC+=ETX;
	HEXtoASC(sStr,(char *)&BCC,2);
	SendComm(COMPUTER_1,sStr[0]);
	SendComm(COMPUTER_1,sStr[1]);
	SendComm(COMPUTER_1,sStr[2]);
	SendComm(COMPUTER_1,sStr[3]);
}
//---------------------------------------------
void SendDate()
{
	SendSeparator(SEPARATOR);
	SendAByte(Now.year);
	SendAByte(Now.month);
	SendAByte(Now.day);
}

//---------------------------------------------
void SendTime()
{
	SendSeparator(SEPARATOR);
	SendAByte(Now.hour);
	SendAByte(Now.min);
	SendAByte(Now.sec);
}


void SendTaxRate()
{
	BYTE sTaxType;

	for(ApplVar.TaxNumber = 0; ApplVar.TaxNumber < ApplVar.AP.Tax.Number; ApplVar.TaxNumber++)
	{
		ReadTax();
		SendSeparator(SEPARATOR);
		SendAByte(ApplVar.Tax.Rate[1]);
		SendAByte(ApplVar.Tax.Rate[0]);
	}
	if (BIT(ApplVar.Tax.Options,BIT0))
		sTaxType='V';
	else
		sTaxType='n';
	SendSeparator(SEPARATOR);
	SendToHost(sTaxType);
}

//---------------------------------------------

//get length of long short
BYTE BitsForLongint(ULONG sIn)
{
	BYTE len;
	ULONG sDiv = 1;

	len = 0;
	while(sIn>=sDiv && sDiv<1410065408)
	{
		sDiv *= 10;
		len++;
	}
	return len;
}

//return 0xffffffff: is not a digit
//else : return the digit
UnLong CheckDigit(char *Data, BYTE len)
{
	BYTE sTp;
	UnLong sLong = 0;

	for(sTp = 0; sTp < len; sTp++)
	{
		if(Data[sTp] > '9' || Data[sTp] < '0')
			return -1;
		sLong = sLong * 10 + Data[sTp] - '0';
	}
	return sLong;
}

//return 1: is a ascii string
//return 0: is not a ascii string
BYTE CheckString(char *Data, BYTE len)
{
	BYTE sTp;

	for(sTp = 0; sTp < len; sTp++)
	{
#if VV_RUSSIA
		if(Data[sTp] < ' ')
#else
		if(Data[sTp] > 0x7f || Data[sTp] < ' ')
#endif
			return 0;
	}
	return 1;
}

// Get the fiscal and Printer status,Set it in the sStr (aaaa \0x1c bbbb);
void SendFisPrnStatus()
{
	WORD PrnSta=0;

#if defined(FISCAL)
	if (!ApplVar.ErrorNumber)//ccr090511
		CheckFisError();
#endif
	SendSeparator(SEPARATOR);	SendAWord(ApplVar.ErrorNumber & 0x7fff);//Printer State
	SendSeparator(SEPARATOR);	SendAWord(ApplVar.Fiscal_Status);//Fiscal State
}

//hf add tax amt >>>>>>>>>>>>>>>>>>>>>>>>>>
BYTE getTaxNumber(BYTE TaxCode)
{
	BYTE sTax;

	if(!TaxCode)		//0 for tax-exempt
		return 0;

	for(sTax = 0;sTax < ApplVar.AP.Tax.Number; sTax++)
		if(BIT(TaxCode, (1<<sTax)))
			break;
	return (sTax+1);
}

void getTaxAmount(BCD *sAmt,BYTE TaxCode, BCD TotalAmt)
{
	BCD sRate;

	ApplVar.TaxNumber = TaxCode;
	ReadTax();
	*sAmt = ZERO;
	sRate = ZERO;

	//if (!CheckNotZero(&TotalAmt))
	//	return ZERO;

	*sAmt = TotalAmt;
	if (!BIT(ApplVar.Tax.Options, BIT0)) /* add on ? */
	{
		memcpy(sRate.Value, ApplVar.Tax.Rate, sizeof(ApplVar.Tax.Rate));
		sRate.Sign = 0x04;
		Multiply(sAmt, &sRate);
		RoundBcd(sAmt, 0);
		AmtRound(1, sAmt);
	}
	else
	{
		/* contains TAX */
		if (sRate.Value[0] == 0x99 &&
			sRate.Value[1] == 0x99 &&
			sRate.Value[2] == 0x99)
			*sAmt = ZERO; 	/* NET is zero */
		else
		{
			Add(&sRate, &THOUSAND10);
			sRate.Sign = 0x04;
			Divide(sAmt, &sRate);	/* calculate net */
			RoundTaxable(sAmt);
			//Subtract(&ApplVar.Cost, sAmt);	/* taxable - net */
		}
	}
}
//hf end <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<



//set net amt, qty of receipt, amt of tax of clear record
void SetClearRecord(BCD *sBcd, BYTE type)
{
	BYTE sTpt,sCRC;
	UnLong	sLong;

	switch(type)
	{
		case 1:	/* z count */
			ApplVar.FiscalBuff.Fis_ClearRecord.FCount = Bcd2Long(sBcd->Value, BCDLEN);
			break;
		case 3:	/* ApplVar.Tax ApplVar.Amt */
		case 4:
		case 5:
		case 6:
		case 7:
		case 8:
		case 9:
		case 10:
//hf 20070118 >>>>>>>>>>>>>>>>>>
			sLong = Bcd2Long(sBcd->Value, BCDLEN);
			if(BIT(sBcd->Sign, BIT7))
				ApplVar.FiscalBuff.Fis_ClearRecord.FTaxAmt[type -3] = 0 -sLong;
			else
				ApplVar.FiscalBuff.Fis_ClearRecord.FTaxAmt[type -3] = (long)sLong;
			break;
		case 12:		/* receipt number */
			//ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice = ReceiptNumber;
			//ApplVar.FiscalBuff.Fis_ClearRecord.FInvSum += ApplVar.FiscalBuff.Fis_ClearRecord.FInvoice;
			break;
		case 14:		/* net sale */
//20070313 remove FGross >>>>>>>>>>>>>>>>>>>>>>>>>>>
		/*	sLong = Bcd2Long(sBcd->Value, BCDLEN);
			if(BIT(sBcd->Sign, BIT7))
				ApplVar.FiscalBuff.Fis_ClearRecord.FGross -= sLong;
			else
				ApplVar.FiscalBuff.Fis_ClearRecord.FGross += sLong;	*/
//end <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
			break;
		case 16:				//TAX-EXEMPT
			sLong = Bcd2Long(sBcd->Value, BCDLEN);
			if(BIT(sBcd->Sign, BIT7))
				ApplVar.FiscalBuff.Fis_ClearRecord.NoTaxSale = 0 - sLong;
			else
				ApplVar.FiscalBuff.Fis_ClearRecord.NoTaxSale = sLong;
			break;
		case 17:				//REFUND AMT
			sLong = Bcd2Long(sBcd->Value, BCDLEN);
			if(BIT(sBcd->Sign, BIT7))
				ApplVar.FiscalBuff.Fis_ClearRecord.ReturnAmt = 0 - sLong;
			else
				ApplVar.FiscalBuff.Fis_ClearRecord.ReturnAmt = sLong;
			break;
		case 18:				//REFUND TAX
			sLong = Bcd2Long(sBcd->Value, BCDLEN);
			if(BIT(sBcd->Sign, BIT7))
				ApplVar.FiscalBuff.Fis_ClearRecord.ReturnTax = 0 - sLong;
			else
				ApplVar.FiscalBuff.Fis_ClearRecord.ReturnTax = sLong;
			break;
		case 19:	/* ApplVar.Tax Sale */
		case 20:
		case 21:
		case 22:
		case 23:
		case 24:
		case 25:
		case 26:
			sLong = Bcd2Long(sBcd->Value, BCDLEN);
			if(BIT(sBcd->Sign, BIT7))
				ApplVar.FiscalBuff.Fis_ClearRecord.FTaxSale[type -19] = 0 -sLong;
			else
				ApplVar.FiscalBuff.Fis_ClearRecord.FTaxSale[type -19] = (long)sLong;
			break;
		case 27:				//DISCOUNT AMT	20070313
			sLong = Bcd2Long(sBcd->Value, BCDLEN);
			if(BIT(sBcd->Sign, BIT7))
				ApplVar.FiscalBuff.Fis_ClearRecord.DiscAmt= 0 - sLong;
			else
				ApplVar.FiscalBuff.Fis_ClearRecord.DiscAmt= sLong;
			break;
		case 28:				//DISCOUNT TAX	20070313
			sLong = Bcd2Long(sBcd->Value, BCDLEN);
			if(BIT(sBcd->Sign, BIT7))
				ApplVar.FiscalBuff.Fis_ClearRecord.DiscTax= 0 - sLong;
			else
				ApplVar.FiscalBuff.Fis_ClearRecord.DiscTax = sLong;
			break;
//hf end <<<<<<<<<<<<<<<<<<<<<
		default:
			break;
	}
}



void GetFiscalDetail(BYTE clearTax)
{
	short RepFor;
	struct REPSIZE *S;

	BYTE temp, periods, periodnumber;
	WORD skip, total;
	UnLong save ;     //unsigned long save; //
	UnLong TempL ;
	//WORD saveMyFlag;	//20070313

	ApplVar.SaleAmt = ZERO;
	ApplVar.SaleQty = ZERO;
	ApplVar.Cost	= ZERO;	//

	ApplVar.Report.System = 0;
	ApplVar.Report.Period = 0;
	ApplVar.Report.Type = 10;
	ApplVar.Report.Start = 0;					//
	ApplVar.Report.End = ApplVar.AP.Tax.Number;
	ApplVar.Report.PointerType = 0;				//
	ApplVar.Report.Pointer = 0;					//
	ApplVar.Report.PointerEnd = 1;				//
	ApplVar.Report.Size = ApplVar.AP.Tax.RecordSize;	//0x1e
	ApplVar.Report.OffSet = ApplVar.AP.Tax.TotalOffSet;	//0x0c

	RepFor = AddrTax;
	S = ApplVar.AP.Tax.Size;

	skip = 0;
	memcpy(&ApplVar.Size, S, sizeof(ApplVar.Size));    // copy CONSTruction to work //
	if (!ApplVar.Size.Length)     // not active report //
		return;
	if (!(ApplVar.Size.Periods & (0x01 << ApplVar.Report.Period))) // not active //
		return;
	temp = 0x01;
	periods = 0;
	periodnumber = 0;
	do
	{
		if (temp & (0x01 << ApplVar.Report.Period))
			periodnumber = periods;
		if (ApplVar.Size.Periods & temp)
			periods++;
		temp <<= 1;
	} while (temp < 0x10);
	RamOffSet = ApplVar.AP.StartAddress[RepFor] + ApplVar.Report.OffSet + skip +
		(WORD)ApplVar.Report.Pointer * ApplVar.Size.Length * periods +
		(WORD)ApplVar.Size.Length * periodnumber +
		(WORD)ApplVar.Report.Start * ApplVar.Report.Size;

	for (total = ApplVar.Report.Start; total < ApplVar.Report.End; total++)
	{
		save = RamOffSet;

		ReadTotal();     					// read correct total //
		if (CheckNotZero(&ApplVar.Total.RetQty))   		// Not Zero then //
			SETBIT(ApplVar.Total.RetQty.Sign, BIT7); // Always negative //

		if (BIT(ApplVar.Total.Qty.Sign, BIT2))     	// used ? //
		{
			ApplVar.Total.Qty.Sign &= 0x83;

			ApplVar.TaxNumber = total;
			ReadTax();

			if(clearTax)
			{
				RamOffSet = save;       					// reset address pointer //
				//saveMyFlag = ApplVar.MyFlags;
				//CLRMyFlags( ENPRINTER);
				ResetReport();						// cc 2006-10-06 ApplVar.Report //
				//ApplVar.MyFlags = saveMyFlag;
			}
			else
			{
				if (BIT(ApplVar.Tax.Options, BIT0)) 			// vat then calculate vat  ? //
				{
					if (ApplVar.Tax.Rate[0] == 0x99 &&
						ApplVar.Tax.Rate[1] == 0x99 &&
						ApplVar.Tax.Rate[2] == 0x99)
						ApplVar.Total.Disc = ZERO;             		// NET is zero //
					else
					{
						memcpy(ApplVar.Total.Qty.Value, ApplVar.Tax.Rate, sizeof(ApplVar.Tax.Rate));
						ApplVar.Total.Cost = ApplVar.Total.Amt;
						ApplVar.Total.Disc = ApplVar.Total.Amt;
						Add(&ApplVar.Total.Qty, &THOUSAND10);
						ApplVar.Total.Qty.Sign = 0x04;
						Divide(&ApplVar.Total.Disc, &ApplVar.Total.Qty);

						RoundBcd(&ApplVar.Total.Disc, 0);

						AmtRound(1, &ApplVar.Total.Disc);
						Subtract(&ApplVar.Total.Cost, &ApplVar.Total.Disc);  // taxable - net //
					}
				}
				else    								// add On //
				{
					ApplVar.Total.Disc = ApplVar.Total.Amt;     			// ApplVar.Disc -> total NET //
					Add(&ApplVar.Total.Amt, &ApplVar.Total.Cost);   		// ApplVar.Amt -> Net + ApplVar.Tax //
				}

				SetClearRecord(&ApplVar.Total.Cost, total+3);		//TAX AMT
				SetClearRecord(&ApplVar.Total.Disc, total+19);		//TAX SALE

				Add(&ApplVar.SaleAmt, &ApplVar.Total.Disc);				//total tax sale

				RamOffSet = save;       					// reset address pointer //
				ResetReport();						// cc 2006-10-06 ApplVar.Report //
			}
		}
		RamOffSet = save + ApplVar.Report.Size;
	}

	if(clearTax)
		return;

	SetClearRecord(&ApplVar.ExemptAmt, 16);			//Save ApplVar.Tax-Exempt
	Add(&ApplVar.SaleAmt, &ApplVar.ExemptAmt);
	SetClearRecord(&ApplVar.SaleAmt, 14);				//total of exempt slae & tax sale

/*	ApplVar.Cost = ZERO;
	ApplVar.SaleAmt = ZERO;
	ApplVar.SaleQty = ZERO;
	for(total = 0; total < ApplVar.AP.Tax.Number+1; total++)
	//for(total = 0; total < 3+1; total++)
	{
		Add(&ApplVar.SaleAmt, &ApplVar.DiscountAmt[total]); 	//DISCOUNT TOTAL, include tax-exempt
	}
	for(total = 0; total < ApplVar.AP.Tax.Number; total++)
	//for(total = 0; total < 3+1; total++)
	{
		getTaxAmount(&ApplVar.SaleQty,total, ApplVar.DiscountAmt[total+1]);
		Add(&ApplVar.Cost, &ApplVar.SaleQty); 								//DISCOUNT TAX
	}	*/
	ApplVar.Cost = ZERO;
	ApplVar.SaleAmt = ApplVar.DiscountAmt;
	ApplVar.SaleQty = ZERO;
	for(total = 0; total < ApplVar.AP.Tax.Number; total++)
	//for(total = 0; total < 3+1; total++)
	{
		getTaxAmount(&ApplVar.SaleQty,total, ApplVar.DiscountAmt);
		Add(&ApplVar.Cost, &ApplVar.SaleQty); 								//DISCOUNT TAX
		Add(&ApplVar.SaleAmt, &ApplVar.DiscountAmt);
	}

	//total discount
	SetClearRecord(&ApplVar.SaleAmt, 27);							//Save DISCOUNT TOTAL
	SetClearRecord(&ApplVar.Cost, 28);								//Save DISCOUNT TAX TOTAL

/*	ApplVar.Cost = ZERO;
	ApplVar.SaleAmt = ZERO;
	ApplVar.SaleQty = ZERO;
	for(total = 0; total < ApplVar.AP.Tax.Number+1; total++)
	//for(total = 0; total < 3+1; total++)
	{
		Add(&ApplVar.SaleAmt, &ApplVar.RefundAmt); 	//REFUND TOTAL, include tax-exempt
	}
	for(total = 0; total < ApplVar.AP.Tax.Number; total++)
	//for(total = 0; total < 3; total++)
	{
		getTaxAmount(&ApplVar.SaleQty,total, ApplVar.RefundAmt);
		Add(&ApplVar.Cost, &ApplVar.SaleQty); 								//REFUND TAX
	}	*/
	ApplVar.Cost = ZERO;
	ApplVar.SaleAmt = ApplVar.RefundAmt;
	ApplVar.SaleQty = ZERO;
	//for(total = 0; total < ApplVar.AP.Tax.Number; total++)
	//for(total = 0; total < 3; total++)
	{
		getTaxAmount(&ApplVar.SaleQty,total, ApplVar.RefundAmt);
		Add(&ApplVar.Cost, &ApplVar.SaleQty); 								//REFUND TAX
		Add(&ApplVar.SaleAmt, &ApplVar.RefundAmt);
	}

	//total refund
	SetClearRecord(&ApplVar.SaleAmt, 17);							//Save REFUND TOTAL
	SetClearRecord(&ApplVar.Cost, 18);								//Save REFUND TAX TOTAL
}
//hf end <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<


//ApplVar.Report printer dtatus
//STX + SEC + 0x38 + 0x1c + cmd + ETX + BCC
//answer of N:
//STX + SEC + 0x38 + 0x1c + Rec# + 0x1c + NF# + 0x1c + Ttl Rec# + 0x1c + Ttl NF# + 0x1c + Z# + ETX + BCC
//answer of E:
//STX + SEC + 0x38 + 0x1c + Exempt sale + ETX + BCC
//answer of A:
//STX + SEC + 0x38 + 0x1c + ApplVar.Tax A sale + 0x1c + ApplVar.Tax A + ETX + BCC
//answer of B:
//STX + SEC + 0x38 + 0x1c + ApplVar.Tax B sale + 0x1c + ApplVar.Tax B + ETX + BCC
//answer of C:
//STX + SEC + 0x38 + 0x1c + ApplVar.Tax C sale + 0x1c + ApplVar.Tax C + ETX + BCC
//answer of D:
//STX + SEC + 0x38 + 0x1c + ApplVar.Disc sale + 0x1c + ApplVar.Disc ApplVar.Tax+ ETX + BCC
//answer of R:
//STX + SEC + 0x38 + 0x1c + Refund sale + 0x1c + Refund ApplVar.Tax + ETX + BCC
//answer of F/J/S/U:
//STX + SEC + 0x40 + 0x1c + Print state + 0x1c + fiscal state + ETX + BCC
void FisPrinter_Status()
{
	BYTE	sCmdOK=TRUE;
	short		i;
	BCD		sSale, sTax, sTmp;
	UnLong ltemp;

	if (FisPrinter_Status_Only())
		return;

	if (PCBuffer[3]==SEPARATOR)
	{
		BCC = 0;

		SendAString(PCBuffer,3);// STX-Sec-Command
		SendFisPrnStatus();		//Printer state-Error number

		switch (PCBuffer[4])
		{
		case 'N':		//number:data of counters
		case 'E':		//exempt:value of the sales without tax
		case 'A':		//tax A
		case 'B':		//tax B
		case 'C':		//tax C
		case 'D':		//tax D
		case 'R':		//tax R
			SendSeparator(SEPARATOR);	SendAByte(PCBuffer[1]);	//the last number of sequence

			//many error code...
			SendSeparator(SEPARATOR);	SendAByte(ApplVar.ErrorNumber);			//Printer status code	//???????

			SendSeparator(SEPARATOR);	SendAByte(PCBuffer[2]);	//The last command number
// -----------------------  liuj 070411 ---------------------------
			SendDate();				//Current Date
			SendTime();				//Current Time
// -----------------------  liuj 070411 ---------------------------
			if(PCBuffer[4] == 'N')	//number
			{
				SendSeparator(SEPARATOR);	SendAWord(ApplVar.FisNumber.ReceiptNum[FRECEIPTS]);// Number of receipt in the fiscal day
		    	SendSeparator(SEPARATOR);	SendAWord(ApplVar.FisNumber.ReceiptNum[NRECEIPTS]);		// ApplVar.TXTCount debug Number of DNF
				SendSeparator(SEPARATOR);	SendALong(ApplVar.FisNumber.TotalReceiptNum[FRECEIPTS]);	//Accumulated number of receipt
				SendSeparator(SEPARATOR);	SendALong(ApplVar.FisNumber.TotalReceiptNum[NRECEIPTS]);	//Accumulated number of DNF
				SendSeparator(SEPARATOR);	SendAWord(ApplVar.FisNumber.TotalClearNum-1);	//Number of closes day
			}
			else if(PCBuffer[4] == 'E')
			{
				SendSeparator(SEPARATOR);	SendABCD(&ApplVar.FExento);
			}
			else if(PCBuffer[4] >= 'A' && PCBuffer[4] <= 'C')
			{
				memset(&ApplVar.FiscalBuff, 0, FISRECORDLEN);
				//GetFiscalDetail(FALSE);
				SendSeparator(SEPARATOR);	SendABCD(&ApplVar.FTax[PCBuffer[4]-'A']);//SendALong(ApplVar.FiscalBuff.Fis_ClearRecord.FTaxSale[PCBuffer[4]-'A']);
				SendSeparator(SEPARATOR);	SendABCD(&ApplVar.FTaxTotal[PCBuffer[4]-'A']);//SendALong(ApplVar.FiscalBuff.Fis_ClearRecord.FTaxAmt[PCBuffer[4]-'A']);
			}
			else if(PCBuffer[4] == 'D')
			{
				/*sSale = ApplVar.DiscountAmt;	//tax exempt
				sTax = ZERO;
				for(i = 0; i < ApplVar.AP.Tax.Number; i++)
				{
					getTaxAmount(&sTmp, i, ApplVar.DiscountAmt);
					Add(&sTax, &sTmp);
					Add(&sSale, &ApplVar.DiscountAmt);
				}
				SendSeparator(SEPARATOR);	SendABCD(&sSale);*/
				SendSeparator(SEPARATOR);	SendABCD(&ApplVar.DiscountAmt);
			}
			else
			{
				sSale = ApplVar.RefundAmt;		//tax exempt
				sTax = ZERO;
				//for(i = 0; i < ApplVar.AP.Tax.Number; i++)
				//{
					//getTaxAmount(&sTmp, i, ApplVar.RefundAmt);
					//Add(&sTax, &sTmp);
					//Add(&sSale, &ApplVar.RefundAmt);
				//}
				SendSeparator(SEPARATOR);	SendABCD(&ApplVar.RefundAmt);
				//SendSeparator(SEPARATOR);	SendABCD(&sTax);
			}
			break;
		case 'S':		//it deactivates autocutter.
			SendDate();				//Current Date
			SendTime();				//Current Time
		case 'F':		//activate near end receipt paper sensor
		case 'J':		//activate near end journal paper sensor
		case 'U':		//It verifies if there is paper in slip of the printer.
			break;
		default:
			sCmdOK=false;
//????????????????!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
			break;
		}
		SendETX_BCC();
	}
	else
		sCmdOK=false;

}

//print daily closure report
//STX + SEC + 0x39 + 0x1c + 'Z'/'X' + 0x1c + 'P' + ETX + BCC
//answer:
//STX + SEC + 0x39 + 0x1c + exempt sale + 0x1c + tax sale + 0x1c + tax amont + 0x1c
//		+ disc sale + 0x1c + disc tax + 0x1c + refund sale + 0x1c + refund tax + 0x1c + date of Z + ETX + BCC
void FisPrinter_DailyRep()
{
	BYTE	sCmdOK=TRUE;
	BYTE	i, FieldCount;
	BYTE 	ReportFlag;	//BIT0: 1/0 Z/X , BIT2 1/0 printer on/off
	long 	sSaleAmt, sTaxAmt;
	WORD 	uLong=ApplVar.SaleReceipts;//ccr091027


	if (FisPrinter_Status_Only())//ccr090511
		return;

	FieldCount = SetFields();

	if ((PCBuffer[4] != 'Z' && PCBuffer[4] != 'X' )||
		(FieldCount==2 && PCBuffer[FieldNumber[1]]!='P') ||
		BIT(ApplVar.Fiscal_Status, OPENDOC+FISCALDOC))//ccr090819
		sCmdOK = FALSE;

	if(sCmdOK)
	{
		RESETBIT(ApplVar.Fiscal_Status, UNKNOWNCMD+INVALIDCMD+REJECTED);

		{
			ReportFlag = 0;

			if(PCBuffer[4] == 'Z')	//print daily closure Z
			{
				//Print_FiscalReport();
				SETBIT(ReportFlag, BIT0);
				memset(&ApplVar.FiscalBuff.Fis_ClearRecord, 0, sizeof(ApplVar.FiscalBuff.Fis_ClearRecord));

			}
			if(PCBuffer[FieldNumber[1]] == 'P')	//print daily closure X
			{
				SETBIT(ReportFlag, BIT1);
			}

		}
	}
	else
	{
		if(BIT(ApplVar.Fiscal_Status, OPENDOC+FISCALDOC))
			SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
		SETBIT(ApplVar.Fiscal_Status, INVALIDCMD);
	}

	//ask for wait a long time
	SendComm(COMPUTER_1, DC2);
	//read report date
	//GetFiscalDetail(FALSE);

	BCC = 0;
	SendAString(PCBuffer, 3);// same as received (STX/SEC/CMD)
	if (sCmdOK)
	{
		SendFisPrnStatus();//ccr091027
		SendSeparator(SEPARATOR);SendABCD(&ApplVar.FExento);//exempt sale

#if defined(FISCAL)
		if(BIT(ReportFlag, BIT0))
		{
			Print_FiscalReport(false);
		}
		else if(BIT(ReportFlag, BIT1))
#endif
		{
			ApplVar.FReport = X;
			ApplVar.RepComputer = 0;

			ApplVar.ReportNumber = 1;
			GetReport(ApplVar.ReportNumber);

			ApplVar.FReport = 0;
		}

		sSaleAmt = 0;
		sTaxAmt = 0;
		for(i = 0; i < ApplVar.AP.Tax.Number; i++)
		{
			sSaleAmt += ApplVar.FiscalBuff.Fis_ClearRecord.FTaxSale[i];
			sTaxAmt += ApplVar.FiscalBuff.Fis_ClearRecord.FTaxAmt[i];
		}
		SendSeparator(SEPARATOR);	SendALong(sSaleAmt);
		SendSeparator(SEPARATOR);	SendALong(sTaxAmt);
		SendSeparator(SEPARATOR);	SendALong(uLong);// receipts for the Z report;
//ccr091027		SendSeparator(SEPARATOR);	SendALong(ApplVar.FisNumber.TotalReceiptNum[FRECEIPTS]);
		SendSeparator(SEPARATOR);	SendALong(ApplVar.FiscalBuff.Fis_ClearRecord.ReturnAmt);	//refund tax
		SendSeparator(SEPARATOR);	SendALong(ApplVar.FiscalBuff.Fis_ClearRecord.ReturnTax);	//refund tax
		SendSeparator(SEPARATOR);	SendALong(ApplVar.FisNumber.TotalClearNum-1);	//ccr091027Z-Counter
		SendDate();SendTime();				//Current Date & Time
	}
	else
		SendFisPrnStatus();

	SendETX_BCC();

}

//command 0x3A, print FM report by date
//STX + Sec + 0x3A + 0x1c + AAMMDD + 0x1c + AAMMDD + 0x1c + 'D'/'M'/'R'/'C' + ETX + BCC
//answer to C
//STX + SEC + 0x40 + 0x1c + Print state + 0x1c + fiscal state + 0x1c + rank of the date + 0x1c + last Z of the rank + ETX + BCC
//answer to others
//STX + SEC + 0x40 + 0x1c + Print state + 0x1c + fiscal state + ETX + BCC
void FisPrinter_FMRepByDate()
{
	BYTE	sCmdOK=TRUE;
	BYTE	i, j, sQualifier, FieldCount, slen;
	WORD 	sYear[2], sMonth[2], sDay[2];	//From YYMMDD/ To YYMMDD

	if (FisPrinter_Status_Only())
		switch(ApplVar.FisCardFlag)
		{
			case NOFM:		//  4: no Card //
			case BADFM:		//  5: invalid Card //
//			case FMFULL:		//  6: fm  full
//			case FMMACFULL:		//  7: mac > 200
//			case FMERROR:	//  8: data error
//			case CHECKSUMCHANGED:
			case FM_X_ECR:
//			case FM_X_EJ:
//			case MUSTINITFM:
			case FMISNEW:
//			case BADEJ:
//			case EJFULL :
//			case MUSTINITEJ :
//			case NOEJ:
				return;
		}

	if(((FieldCount = SetFields()) == 3) && (!BIT(ApplVar.Fiscal_Status, OPENDOC+FISCALDOC)))
	{
		memset(&ApplVar.FiscalDefine, 0, sizeof(ApplVar.FiscalDefine));

		for(i = 0; i < FieldCount; i++)
		{
			if(!sCmdOK)
				break;
			j = FieldNumber[i];
			slen = FieldNumber[i+1]-j-1;
			switch(i)
			{
			case 0:	//YYMMDD
			case 1:	//YYMMDD
				if(slen != 6 || CheckDigit((char *)&PCBuffer[j], slen)==-1)
				{
					sCmdOK = FALSE;
					break;
				}
				sYear[i] = (((PCBuffer[j] & 0x0f) << 4) | (PCBuffer[j+1] & 0x0f));    j+=2;
				sMonth[i] = (((PCBuffer[j] & 0x0f) << 4) | (PCBuffer[j+1] & 0x0f));   j+=2;
				sDay[i] = (((PCBuffer[j] & 0x0f) << 4) | (PCBuffer[j+1] & 0x0f));     j+=2;
				break;
			}
		}

		if(sCmdOK)
		{
//----------------------liuj modify 070414 -----------------------
			RESETBIT(ApplVar.Fiscal_Status, UNKNOWNCMD+INVALIDCMD+REJECTED);
//----------------------liuj modify 070414 -----------------------

			sQualifier = PCBuffer[FieldNumber[FieldCount-1]];

			switch(sQualifier)
			{
			case 'D':		//Report by day. Print Summary when there is more than a closing for the same date.
				ApplVar.FiscalDefine.DateTo = ApplVar.FiscalDefine.DateFr = EncordBCDDate(sYear[0], sMonth[0], sDay[0]);

				Read_FiscalData(FUNC804-FUNC800);
				break;
			case 'M':		//Detailed by month
				    if(sMonth[0]==2){
				        if(sYear[0]%4==0 && sYear[0]%100!=0)
				        {
				            sDay[0] = 0x29;
				        }
				        else
				            sDay[0]=0x28;
				    }
					else  if(sMonth[0]==4||sMonth[0]==6||sMonth[0]==9||sMonth[0]==11)
				    {
				        sDay[0] =0x30;
				    }
				    else
				        sDay[0] = 0x31;

				ApplVar.FiscalDefine.DateFr = EncordBCDDate(sYear[0], sMonth[0], 0x01);
				ApplVar.FiscalDefine.DateTo = EncordBCDDate(sYear[0], sMonth[0],sDay[0]);
				Read_FiscalData(FUNC803-FUNC800);
				break;
			case 'R':		//ApplVar.Report with a summary of daily sales,but no detail
				ApplVar.FiscalDefine.DateFr = EncordBCDDate(sYear[0], sMonth[0],sDay[0]);
				ApplVar.FiscalDefine.DateTo = EncordBCDDate(sYear[1], sMonth[1],sDay[1]);
				Read_FiscalData(FUNC804-FUNC800);
				break;
			case 'C':		//Rank of reports Z between the requested date rank
				ApplVar.FiscalDefine.DateFr = EncordBCDDate(sYear[0], sMonth[0], sDay[0]);
				ApplVar.FiscalDefine.DateTo = EncordBCDDate(sYear[1], sMonth[1],sDay[1]);
				Read_FiscalData(FUNC803-FUNC800);
				break;
			default:
				sCmdOK = FALSE;
				break;
			}
		}
	}
	else
		sCmdOK = FALSE;

	if(sCmdOK == FALSE)
	{
		if(BIT(ApplVar.Fiscal_Status, OPENDOC+FISCALDOC))
			SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
		SETBIT(ApplVar.Fiscal_Status, INVALIDCMD);
	}

	BCC = 0;
	SendAString(PCBuffer,3);
	SendFisPrnStatus();

	if(sQualifier == 'C' && sCmdOK)
	{
		SendSeparator(SEPARATOR);	SendAWord(sStartZ);	//start Z number
		SendSeparator(SEPARATOR);	SendAWord(sEndZ);	//end Z number
	}

	SendETX_BCC();
}


//command 0x3A, print FM report by number
//STX + Sec + 0x3b + 0x1c + Begin Z + 0x1c + End Z + 0x1c + 'C'/other + ETX + BCC
//answer to C
//STX + SEC + 0x3b + 0x1c + exempt sale + 0x1c + tax sale + 0x1c + tax amont + 0x1c
//		+ disc sale + 0x1c + disc tax + 0x1c + refund sale + 0x1c + refund tax + 0x1c + date of Z + ETX + BCC
//answer to others
//STX + SEC + 0x3b + 0x1c + Print state + 0x1c + fiscal state + ETX + BCC
void FisPrinter_FMRepByNum()
{
	BYTE	sCmdOK=TRUE;
	BYTE	i, j, FieldCount, slen;
	BCD		sTaxSale, sTaxAmt;

	if (FisPrinter_Status_Only())
		switch(ApplVar.FisCardFlag)
		{
			case NOFM:		//  4: no Card //
			case BADFM:		//  5: invalid Card //
//			case FMFULL:		//  6: fm  full
//			case FMMACFULL:		//  7: mac > 200
//			case FMERROR:	//  8: data error
//			case CHECKSUMCHANGED:
			case FM_X_ECR:
//			case FM_X_EJ:
//			case MUSTINITFM:
			case FMISNEW:
//			case BADEJ:
//			case EJFULL :
//			case MUSTINITEJ :
//			case NOEJ:
				return;
		}

	if(((FieldCount = SetFields()) == 3) && (!BIT(ApplVar.Fiscal_Status, OPENDOC+FISCALDOC)))
	{
		memset(&ApplVar.FiscalDefine, 0, sizeof(ApplVar.FiscalDefine));

		for(i = 0; i < FieldCount; i++)
		{
			if(!sCmdOK)
				break;
			j= FieldNumber[i];
			slen = FieldNumber[i+1]-j-1;
			switch(i)
			{

			case 0:	//Start Z
			case 1:	//End Z
				if(i == 0)
				{
					ApplVar.FiscalDefine.RecNumFr = CheckDigit((char *)&PCBuffer[j], slen);
					if(ApplVar.FiscalDefine.RecNumFr==-1)
						sCmdOK = FALSE;
				}
				else
				{
					ApplVar.FiscalDefine.RecNumTo = CheckDigit((char *)&PCBuffer[j], slen);

					if(ApplVar.FiscalDefine.RecNumTo==-1)
						sCmdOK = FALSE;
				}
				break;
			}
		}

	}
	else
		sCmdOK = FALSE;

	if(sCmdOK)
	{
			RESETBIT(ApplVar.Fiscal_Status, UNKNOWNCMD+INVALIDCMD+REJECTED);
			Read_FiscalData(FUNC802-FUNC800);
	}
	else
	{
		if(BIT(ApplVar.Fiscal_Status, OPENDOC+FISCALDOC))
			SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
		SETBIT(ApplVar.Fiscal_Status, INVALIDCMD);
	}

	BCC = 0;
	SendAString(PCBuffer,3);


	if(PCBuffer[FieldNumber[FieldCount-1]] == 'C' && sCmdOK)
	{
		SendSeparator(SEPARATOR);	SendABCD(&ApplVar.FiscalTotal.NoTaxSale);	//exempt

		sTaxSale = ZERO;
		sTaxAmt = ZERO;
		for(i=0; i < ApplVar.AP.Tax.Number; i++)
		{
			Add(&sTaxSale,&ApplVar.FiscalTotal.FTaxSale[i]);//ccr070424
			Add(&sTaxAmt, &ApplVar.FiscalTotal.FTaxAmt[i]);//ccr070424
		}
		SendSeparator(SEPARATOR);	SendABCD(&sTaxSale);	//ApplVar.Tax Sale
		SendSeparator(SEPARATOR);	SendABCD(&sTaxAmt);	//ApplVar.Tax ApplVar.Amt
		SendSeparator(SEPARATOR);	SendALong(ApplVar.FiscalTotal.DiscAmt);	//ApplVar.Disc ApplVar.Amt
		SendSeparator(SEPARATOR);	SendALong(ApplVar.FiscalTotal.DiscTax);	//ApplVar.Disc ApplVar.Tax
		SendSeparator(SEPARATOR);	SendALong(ApplVar.FiscalTotal.ReturnAmt);	//Refund ApplVar.Amt
		SendSeparator(SEPARATOR);	SendALong(ApplVar.FiscalTotal.ReturnTax);	//ApplVar.Disc ApplVar.Tax
		SendDate();			//Date of ApplVar.Report Z	???
	}
	else
		SendFisPrnStatus();

	SendETX_BCC();

}

//fiscal the ecr 0x3c
//STX + Sec + 0x3c + 0x1c + serial# + 0x1c + RIF + 0x1c + YYMMDD + 0x1c + 'HHMMSS + ETX + BCC
//answer
//STX + SEC + 0x3c + 0x1c + Print state + 0x1c + fiscal state + ETX + BCC
void FisPrinter_Fiscaliation()
{
	BYTE	sCmdOK=TRUE;
	BYTE	i,j, FieldCount, slen;
	BYTE 	sYear[2], sMonth[2], sDay[2];
	BCD		Date, Time;
	struct TimeDate		sNow;


    sNow = Now ; // liuj 0914
	if(((FieldCount = SetFields()) == 4) && (!BIT(ApplVar.Fiscal_Status, OPENDOC+FISCALDOC)))
	{
		memset(&ApplVar.Fis_Header, 0, sizeof(ApplVar.Fis_Header));
		memset(&ApplVar.FiscalSerialNum, 0, sizeof(ApplVar.FiscalSerialNum));
		memset(&ApplVar.RIFNumber, 0, sizeof(ApplVar.RIFNumber));
		Date = Time = ZERO;

		for(i = 0; i < FieldCount; i++)
		{
			if(!sCmdOK)
				break;

			j = FieldNumber[i];
			slen = FieldNumber[i+1]-j-1;
			switch(i)
			{
			case 0:	//serial#
				if(slen <= MAXFISCALNO && CheckString((char *)&PCBuffer[j], slen))
					memcpy(ApplVar.FiscalSerialNum, &PCBuffer[j], slen);
				else
					sCmdOK=FALSE;
				break;
			case 1:	//RIF
				if(slen <= 10 && CheckString((char *)&PCBuffer[j], slen))
					memcpy(ApplVar.RIFNumber, &PCBuffer[j], slen);
				else
					sCmdOK=FALSE;
				break;
			case 2:	//YYMMDD
			case 3:	//HHMMSS
				if(slen != 6 || CheckDigit((char *)&PCBuffer[j], slen)==-1)
				{
					sCmdOK = FALSE;
					break;
				}
#if 0
//----------------liuj modify  070409 --------------------
				sYear[i-2] = (((PCBuffer[j] & 0x0f) << 4) | (PCBuffer[j+1] & 0x0f));
                                j+=2;
				sMonth[i-2] = (((PCBuffer[j] & 0x0f) << 4) | (PCBuffer[j+1] & 0x0f));
                                j+=2;
				sDay[i-2] = (((PCBuffer[j] & 0x0f) << 4) | (PCBuffer[j+1] & 0x0f));

//----------------liuj modify  070409 --------------------
#endif
                                if(i == 2)
				{
#if 0
					switch(TIME_DATE)
					{
					case 1:		//wMMDDYYYY //
						Date.Value[2] = sDay[0];		// DD //
						Date.Value[3] = sMonth[0];		// MM //
						Date.Value[0] = sYear[0];		// YY //
//----------------------liuj modify 070413----------------------------
						Date.Value[1] = ((Now.year>>8)&0xff);
//----------------------liuj modify 070413----------------------------
						break;
					case 2:		//wYYYYMMDD //
						Date.Value[0] = sDay[0];		// DD //
						Date.Value[1] = sMonth[0];		// MM //
						Date.Value[2] = sYear[0];		// YY //
						Date.Value[3] = ((Now.year>>8)&0xff);
						break;
					default:		 //wDDMMYYYY //
						Date.Value[3] = sDay[0];		// DD //
						Date.Value[2] = sMonth[0];		// MM //
						Date.Value[0] = sYear[0];		// YY //
						Date.Value[1] = ((Now.year>>8)&0xff);
						break;
					}
					ApplVar.Entry = Date;
//----------------liuj modify  070409 --------------------
					Appl_EntryCounter = 9;
//----------------liuj modify  070409 --------------------

					NewTimeDate(0x01);
					if(ApplVar.ErrorNumber)
					{
						sCmdOK = FALSE;
						break;
					}
#endif
				sNow.year = ((PCBuffer[j] & 0x0f) << 4) + (PCBuffer[j+1] & 0x0f);j+=2;		// yy //
				sNow.month=((PCBuffer[j] & 0x0f) << 4) + (PCBuffer[j+1] & 0x0f);j+=2;		// mm //
				sNow.day = ((PCBuffer[j] & 0x0f) << 4)  + (PCBuffer[j+1] & 0x0f);j+=2;		// yy //
				}
				else
				{
#if 0
//----------------liuj modify  070409 --------------------
				      	Time.Value[1] = sYear[1];		//HH //
					Time.Value[0] = sMonth[1];		//MM//
				     //	Time.Value[0] = sDay[1];		//SS //
					ApplVar.Entry = Time;

					Appl_EntryCounter = 4;
//----------------liuj modify  070409 --------------------

					NewTimeDate(0x02);
					if(ApplVar.ErrorNumber)
					{
						sCmdOK = FALSE;
						break;
					}
#endif
				sNow.hour= ((PCBuffer[j] & 0x0f) << 4) + (PCBuffer[j+1] & 0x0f);j+=2;		// yy //
				sNow.min= ((PCBuffer[j] & 0x0f) << 4)  + (PCBuffer[j+1] & 0x0f);j+=2;		// yy //
				sNow.sec= ((PCBuffer[j] & 0x0f) << 4) + (PCBuffer[j+1] & 0x0f);j+=2 ;		// yy //

				SetTimeDate(&sNow) ;
				Now = sNow;

				}
				break;
			}
		}

	}
	else
		sCmdOK = FALSE;

	if(sCmdOK)
	{
		RESETBIT(ApplVar.Fiscal_Status, UNKNOWNCMD+INVALIDCMD+REJECTED);

		if(ApplVar.FisCardFlag == FMISNEW)//ccr090511  && !MyFlags(ZREPORT) && !ApplVar.FTrain)
		{
			//serial #
			strcpy(ApplVar.Fis_Header.FFisCode, ApplVar.FiscalSerialNum);
			//RIF
			strcpy(ApplVar.Fis_Header.FRIFNumber, ApplVar.RIFNumber);
			//release
			memset(ApplVar.Fis_Header.FRelease,' ',sizeof(ApplVar.Fis_Header.FRelease));
			memcpy(ApplVar.Fis_Header.FRelease,Release,strlen(Release));
			//fiscal date time
			ApplVar.Fis_Header.FInitDate[0] = sYear[0];		// YY //
			ApplVar.Fis_Header.FInitDate[1] = sMonth[0];		// MM //
			ApplVar.Fis_Header.FInitDate[2] = sDay[0];		// DD //
			ApplVar.Fis_Header.FInitDate[3] = sYear[1];		// HH //
			ApplVar.Fis_Header.FInitDate[4] = sMonth[1];		// MM //
			ApplVar.Fis_Header.FInitDate[5] = sDay[1];		// SS //

			ApplVar.Entry = Time;
			Appl_EntryCounter = 9;

			NewTimeDate(2);

			ApplVar.Entry = Date;
			Appl_EntryCounter = 4;

			NewTimeDate(1);

			ApplVar.FisNumber.LastZDate = EncordBCDDate(ApplVar.Fis_Header.FInitDate[0], //20070313 date of last Z
											    ApplVar.Fis_Header.FInitDate[1],
											    ApplVar.Fis_Header.FInitDate[2]);
//			memcpy(ApplVar.FisNumber.LastZTime, &ApplVar.Fis_Header.FInitDate[3], 3);
			ApplVar.LastInvoiceDate = ApplVar.FisNumber.LastZDate = ApplVar.FisNumber.FiscalDate;//ccr070531
			memcpy(ApplVar.LastInvoiceTime,ApplVar.Fis_Header.FInitDate+3,3);

			ApplVar.Fis_Header.FFlag = FMINITEDFLAG;
//			ApplVar.Fis_Header.FReserve[FHEADERLEN-2] = 0xaa;

#if CASE_FATFS_EJ == 1
			ApplVar.ContFlag = 0;
#endif

			if(Write_FiscalRam(
				FISECRIDADDR + sizeof(ApplVar.Fis_Header.FFirst) +sizeof(ApplVar.Fis_Header.FPFirst),
				ApplVar.Fis_Header.FRelease,
				sizeof(ApplVar.Fis_Header.FRelease) +
				sizeof(ApplVar.Fis_Header.FFisCode) +
				sizeof(ApplVar.Fis_Header.FDeviceCode) +
				sizeof(ApplVar.Fis_Header.FRIFNumber) +
				sizeof(ApplVar.Fis_Header.FInitDate) +
				sizeof(ApplVar.Fis_Header.FFlag) +
				sizeof(ApplVar.Fis_Header.FRIFNumber)))
			{
				ApplVar.Fiscal_Status = 0;

				SendComm(COMPUTER_1,DC2);
				SendComm(COMPUTER_1,DC2);
				SendComm(COMPUTER_1,DC2);
				SendComm(COMPUTER_1,DC2);

				ClearAllReport();		/* Clear ApplVar.Report. */

                ApplVar.ZCount[FISCALZNUM]= ApplVar.ZCount[TRAINZNUM]=1;//ccr091027
				ApplVar.FisNumber.TotalClearNum = 1;
			    MemSet(ApplVar.FisNumber.ReceiptNum, sizeof(ApplVar.FisNumber.ReceiptNum), 0);     /* ccr091027 reset receiptnumber ?*/
			    MemSet(ApplVar.FisNumber.TotalReceiptNum, sizeof(ApplVar.FisNumber.TotalReceiptNum), 0);     /* ccr091027 reset receiptnumber ?*/

				SendComm(COMPUTER_1,DC2);

				//Fiscal_Flag = 0;
				ApplVar.FisCardFlag = FISCALOK;
				//init ApplVar.FiscalHead
				memset(&ApplVar.FiscalHead, 0, sizeof(ApplVar.FiscalHead));

				ApplVar.FiscalHead.MaxP = FISDATAADDR;
				ApplVar.FiscalHead.EJTblP = FISEJADDR;		//hf 20070118 for EJ

				Bell(2);
#if CASE_FATFS_EJ
				ApplVar.EJContent =  TXTCONT;	//0;	//20070118
				ApplVar.ContFlag = 0;
#endif
				PrintLine2('=');
                ApplVar.FStatus = 1;
				AddReceiptNumber();

				ApplVar.PrintLayOut = 0x03;

				RJPrint(0,Msg[SHKCSHUA].str);
				memset(SysBuf, ' ', sizeof(SysBuf));
				CopyFrStr(SysBuf, Msg[TAXCODE].str);
				strcpy(SysBuf+PRTLEN-strlen(ApplVar.FiscalSerialNum), ApplVar.FiscalSerialNum);
				SysBuf[PRTLEN] = 0;
				RJPrint(0, SysBuf);
				memset(SysBuf, ' ', sizeof(SysBuf));
				CopyFrStr(SysBuf, Msg[RIFCODE].str);
				strcpy(SysBuf+PRTLEN-strlen(ApplVar.RIFNumber), ApplVar.RIFNumber);
				SysBuf[PRTLEN] = 0;
				RJPrint(0, SysBuf);

				/*if(ApplVar.FTrain)	// not in trainning mode //
					{
					memset(ApplVar.FiscalSerialNum, 0, sizeof(ApplVar.FiscalSerialNum));
				}*/

				PrintRegiInfo(false);
				PrintLine2('=');
				RFeed(1);

				ProgLine = 0;
				ApplVar.FExento = ZERO;     /* clear daily itemizers */
				 ApplVar.FTotal = ZERO;      /* ApplVar.FTax is soft total and cleared at start of report */
				 memset(&ApplVar.FTaxTotal,0,sizeof(ApplVar.FTaxTotal));//ccr070615

				MemSet(ApplVar.CurrentTaxRate,0,sizeof(ApplVar.CurrentTaxRate));
				SETBIT(ApplVar.ChangeTax_Flag,BIT0);
				ProcessTax(true);
#if(CASE_FATFS_EJ == 1)
				CheckEJ();
#endif
				RFeed(1);
				//PrintHead1(3);
				ClearEntry();
				CLRMyFlags(ZREPORT) ;
 				RESETBIT(ApplVar.Fiscal_Status, UNKNOWNCMD+INVALIDCMD+REJECTED);
                ApplVar.FStatus = 0;
			}
			else
			{
				ApplVar.FisCardFlag = FMERROR;	//FISINVALID;
				memset(ApplVar.RIFNumber, 0, sizeof(ApplVar.RIFNumber));
				memset(ApplVar.FiscalSerialNum, 0, sizeof(ApplVar.FiscalSerialNum));

				SETBIT(ApplVar.Fiscal_Status, INVALIDCMD);
			}
		}
		else
			SETBIT(ApplVar.Fiscal_Status,REJECTED);
	}
	else
	{
		if(BIT(ApplVar.Fiscal_Status, OPENDOC+FISCALDOC))
			SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
		SETBIT(ApplVar.Fiscal_Status, INVALIDCMD);
	}

	BCC = 0;
	SendAString(PCBuffer,3);

	SendFisPrnStatus();
	SendETX_BCC();
}

//command = 0x3d, print data strored in EJ
//STX + Sec + 0x3d + 0x1c + Rec# + 0x1c + YYMMDDHH + 0x1c + 'YYMMDDHH + ETX + BCC
//if Rec# = 0x7f, print all data in the EJ
//answer
//STX + SEC + 0x3d + 0x1c + Print state + 0x1c + fiscal state + ETX + BCC
void FisPrinter_EJReprint()
{
	BYTE	sCmdOK=TRUE;
	BYTE	i,j, FieldCount, slen;
	WORD 	sYear[2], sMonth[2], sDay[2], sHour[2];	//From YYMMDDHH/ To YYMMDDHH

	if (FisPrinter_Status_Only())
		switch(ApplVar.FisCardFlag)
		{
			case NOFM:		//  4: no Card //
//			case BADFM:		//  5: invalid Card //
//			case FMFULL:		//  6: fm  full
//			case FMMACFULL:		//  7: mac > 200
//			case FMERROR:	//  8: data error
//			case CHECKSUMCHANGED:
//			case FM_X_ECR:
//			case FM_X_EJ:
//			case MUSTINITFM:
//			case FMISNEW:
			case BADEJ:
//			case EJFULL :
			case MUSTINITEJ :
			case NOEJ:
				return;
		}

	if(((FieldCount = SetFields()) == 3) && (!BIT(ApplVar.Fiscal_Status, OPENDOC+FISCALDOC)))
	{
		memset(&ApplVar.LogDefine, 0, sizeof(ApplVar.LogDefine));

		for(i = 0; i < FieldCount; i++)
		{
			if(!sCmdOK)
				break;

			j = FieldNumber[i];
			slen = FieldNumber[i+1]-j-1;
			switch(i)
			{
			case 0:	//Start Z
				if(PCBuffer[j] == 0x7f)
					ApplVar.LogDefine.RecNum = 0;
				else
				{
					ApplVar.LogDefine.RecNum = CheckDigit((char *)&PCBuffer[j], slen);
					if(ApplVar.LogDefine.RecNum==-1)
						sCmdOK = FALSE;
				}
				break;
			case 1:	//YYMMDDHH
			case 2:	//YYMMDDHH
				if(slen != 8 || CheckDigit((char *)&PCBuffer[j], slen)==-1)
				{
					sCmdOK = FALSE;
					break;
				}
				sYear[i-1] = (((PCBuffer[j] & 0x0f) << 4) + (PCBuffer[j+1] & 0x0f));j+=2;
				sMonth[i-1] = (((PCBuffer[j] & 0x0f) << 4) + (PCBuffer[j+1] & 0x0f));j+=2;
				sDay[i-1] = (((PCBuffer[j] & 0x0f) << 4) + (PCBuffer[j+1] & 0x0f));j+=2;
				sHour[i-1] = (((PCBuffer[j] & 0x0f) << 4) + (PCBuffer[j+1] & 0x0f));j+=2;
				if (i==1)
					ApplVar.LogDefine.DateFr = (((UnLong)sYear[0])<<24) + ((UnLong)sMonth[0]<<16) + ((UnLong)sDay[0]<<8) + 0x00;//sHour[0];
				else
					ApplVar.LogDefine.DateTo = (((UnLong)sYear[1])<<24) + ((UnLong)sMonth[1]<<16) + ((UnLong)sDay[1]<<8) + 0x24;//sHour[0];
				break;
			}
		}
	}
	else
		sCmdOK = FALSE;

	if(sCmdOK)
	{
		RESETBIT(ApplVar.Fiscal_Status, UNKNOWNCMD+INVALIDCMD+REJECTED);

		//ask for wait a long time
		SendComm(COMPUTER_1, DC2);

//ccr091020		ApplVar.LogDefine.DateFr = (((UnLong)sYear[0])<<24) + ((UnLong)sMonth[0]<<16) + ((UnLong)sDay[0]<<8) + 0x00;//sHour[0];
//ccr091020		ApplVar.LogDefine.DateTo = (((UnLong)sYear[1])<<24) + ((UnLong)sMonth[1]<<16) + ((UnLong)sDay[1]<<8) + 0x24;//sHour[0];
#if CASE_FATFS_EJ
		PrintEJLog(true);
#endif
	}
	else
	{
		if(BIT(ApplVar.Fiscal_Status, OPENDOC+FISCALDOC))
			SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
		SETBIT(ApplVar.Fiscal_Status, INVALIDCMD);
	}

	BCC = 0;
	SendAString(PCBuffer,3);
	SendFisPrnStatus();
	SendETX_BCC();
}


//Initialize MMC card (EJ)0x3E)
//STX + SEC + 0x3e + ETX + BCC
//Answer:
//STX + SEC + 0x3e + 0x1c + Print state + 0x1c + fiscal state + ETX + BCC
void FisPrinter_InitMMC()
{
	BYTE sCmdOK;
	short i;

	if (ApplVar.FisCardFlag == FMISNEW ||
		ApplVar.FisCardFlag == NOFM ||
		ApplVar.FisCardFlag == NOEJ ||
		ApplVar.FisCardFlag == FM_X_EJ ||
		ApplVar.FisCardFlag == FM_X_ECR ||
		ApplVar.FisCardFlag == BADFM ||
		ApplVar.FisCardFlag == BADEJ ||
		ApplVar.FisCardFlag == FMFULL)
	{//ccr090918
		FisPrinter_Status_Only();//ccr090511
		return;
	}

	BCC = 0;
	SendAString(PCBuffer,3);

	if(BIT(ApplVar.Fiscal_Status, OPENDOC+FISCALDOC))
		SETBIT(ApplVar.Fiscal_Status, REJECTED);
	else
	{
#if CASE_FATFS_EJ
			ApplVar.EJContent =  TXTCONT;	//0;	//20070118
			ApplVar.ContFlag = 0;
            ApplVar.FisCardFlag = MUSTINITEJ;//DEBUG FOR PRINT EJ-LIST BY ZY
			ProcessEJ();
			if(ApplVar.ErrorNumber)
				SETBIT(ApplVar.Fiscal_Status, REJECTED);
			else
			{
					ApplVar.FStatus = 1;
					SETBIT(ApplVar.ContFlag,(ENSTORE | ENHEADER));//ccr070608
					ApplVar.EJContent = TXTCONT;					//ccr070608

					PrintLine2('=');
					AddReceiptNumber();
					RJPrint(0, Msg[EJCSHUA].str);
					memset(SysBuf, ' ', PRTLEN);

					CopyFrStr(SysBuf, Msg[EJBHAO].str);
					i = strlen(Msg[EJBHAO].str);
					WORDtoASC(SysBuf+i+4, ApplVar.EJHeader.EJID);	//20070118
					DateTimeToStr(SysBuf+(PRTLEN-20),3);
					RJPrint(0, SysBuf);

                    memset(SysBuf,' ',PRTLEN);
                    slen=strlen(MsgSizeOfEJ)
                    memcpy(SysBuf, MsgSizeOfEJ,slen);
                    SysBuf[slen]='-';SysBuf[slen+1]='I';
                    sprintf(SysBuf+23,"%9lu",ApplVar.EJSpaceSize[_FS_SD_2ND]);
                    RJPrint(0,SysBuf);
                    SysBuf[slen+1]='E';
                    sprintf(SysBuf+23,"%9lu",ApplVar.EJSpaceSize[_FS_SD]);
                    RJPrint(0,SysBuf);

					PrintLine2('=');
					ReceiptIssue(1);//liuj 00610

					RFeed(1);
					ClearEntry();
					ApplVar.FStatus = 0;
			}
#endif
	}

	SendFisPrnStatus();
	SendSeparator(SEPARATOR);SendAWord(ApplVar.FisNumber.TotalEJNum);//ccr091110
	SendETX_BCC();



}



//Command = 0x40, Opening fiscal receipts
//STX + SEC + 0x40 + 0x1c + social reason + 0x1c + buyer RIF + 0x1c + Rec#  refund + 0x1c + Serial# refund +
//	0x1c + Date refund + 0x1c + time refund + 0x1c + 'D' + 0x1c + 0x7f + 0x1c + 0x7f + ETX + BCC
//answer:
//STX + SEC + 0x40 + 0x1c + Print state + 0x1c + fiscal state + ETX + BCC
void FisPrinter_OpenReceipts()
{
	BYTE	sCmdOK=TRUE;
	BYTE	i,j, FieldCount, slen, sCh;

	if (FisPrinter_Status_Only())//ccr090511
		return;

	FieldCount = SetFields();
	if((FieldCount == 7 || FieldCount == 9) && (!BIT(ApplVar.Fiscal_Status, OPENDOC+FISCALDOC)))
	{
		for(i = 0; i < FieldCount; i++)
		{
			if(!sCmdOK)
				break;

			j = FieldNumber[i];
			sCh = PCBuffer[j];

			if(sCh == 0x7f)
				continue;
			slen = FieldNumber[i+1]-j-1;
			switch (i)
			{
			case 0:	// get Social reason from PCBuffer[i];
				if(slen> PRTLEN ||  !CheckString(&PCBuffer[j], slen))
					sCmdOK = FALSE;
				break;
			case 1:	// get RIF from PCBuffer[i];
				if(slen> 11 || !CheckString(&PCBuffer[j], slen))
					sCmdOK = FALSE;
				break;
			case 2:	// number of receipt to be refund
				if(slen> 8 || CheckDigit(&PCBuffer[j], slen)==-1)
					sCmdOK = FALSE;
				break;
			case 3:	// fiscal machine serial that realized the receipt to be refunded
				if(slen> 10 || !CheckString(&PCBuffer[j], slen))
					sCmdOK = FALSE;
				break;
			case 4:	// date of the receipt AAMMDD
			case 5:	// time of the receipt HHMMSS
				if(slen> 6 || CheckDigit(&PCBuffer[j], slen)==-1)
					sCmdOK = FALSE;
				break;
			case 6:	// refund or normal receipt
				if(slen> 1 || !CheckString(&PCBuffer[j], slen))
					sCmdOK = FALSE;
				break;
			case 7:	// not used
			case 8:	// not used
				if(sCh != 0x7f ||  slen > 1)
					sCmdOK = FALSE;
				break;
			}
			i++;
		}
	}
	else
		sCmdOK = FALSE;

	if (sCmdOK)
	{
//----------------------liuj modify 070414 -----------------------

		RESETBIT(ApplVar.Fiscal_Status, UNKNOWNCMD+INVALIDCMD+REJECTED+REFUNDDOC);
//----------------------liuj modify 070414 -----------------------

		if(PCBuffer[FieldNumber[6]] == 'D')	//refund receipt
		{
			SETBIT(ApplVar.Fiscal_Status,REFUNDDOC);//ccr090918
//ccr090918			ApplVar.Key.Code = CORREC + 3;
//ccr090918            Appl_EntryCounter = 0 ;
//ccr090918			Correction();
		}
		if(ApplVar.ErrorNumber)
		{
			SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
		}
		else
		{
			if(ApplVar.FisCardFlag < FMISNEW && CompDate(&Now,(ApplVar.FisNumber.LastZDate))>0 && MyFlags(ZREPORT))
			{
				SETBIT(ApplVar.Fiscal_Status, OVERDATE);

			}
			else
			{

			ApplVar.PrintLayOut = 2;
			ApplVar.FReceipt=0;
		    if (!ApplVar.FRegi )  // liuj 0912
				ApplVar.FStatus = 1;	    /* set fiscal receipt */

			RegiStart();

			if(PCBuffer[FieldNumber[0]] != 0x7f )		//customer name
			{
				memset(SysBuf, 0, PRTLEN);
#if (VV_RUSSIA)//ccr091015
				memcpy(SysBuf, PCBuffer+FieldNumber[0], FieldNumber[1]-FieldNumber[0]-1);
#else
				CopyFrStr(SysBuf, Msg[KHMINGCH].str);
				memcpy(SysBuf + strlen(Msg[KHMINGCH].str), PCBuffer+FieldNumber[0], FieldNumber[1]-FieldNumber[0]-1);
#endif
				SysBuf[PRTLEN] = 0;
				RJPrint(0, SysBuf);
			}
			if(PCBuffer[FieldNumber[1]] != 0x7f )		//customer rif
			{
				memset(SysBuf, 0, PRTLEN);
				CopyFrStr(SysBuf, Msg[RIFCODE].str);
				memcpy(SysBuf + strlen(Msg[RIFCODE].str), PCBuffer+FieldNumber[1], FieldNumber[2]-FieldNumber[1]-1);
				SysBuf[PRTLEN] = 0;
				RJPrint(0, SysBuf);
			}
//liuj 0912
			PrintStr(Prompt.Title);
		 	PrintLine('=');

#if 0		// liuj 0911
			if(ApplVar.FRefund)// BIT(ApplVar.ContFlag, ENREFUND);
			{
				if(PCBuffer[FieldNumber[2]] != 0x7f )
				{//number of receipt to be refunded
					memset(SysBuf, 0, PRTLEN);
					CopyFrStr(SysBuf, Msg[YUANFPHAO].str);
					memcpy(SysBuf + strlen(Msg[YUANFPHAO].str), PCBuffer+FieldNumber[2], FieldNumber[3]-FieldNumber[2]-1);
					SysBuf[PRTLEN] = 0;
					RJPrint(0, SysBuf);
				}
				if(PCBuffer[FieldNumber[3]] != 0x7f )
				{//fiscal machine serial that realized the receipt to be refunded
					memset(SysBuf, 0, PRTLEN);
					CopyFrStr(SysBuf, Msg[JIQIHAO].str);
					memcpy(SysBuf + strlen(Msg[JIQIHAO].str), PCBuffer+FieldNumber[3], FieldNumber[4]-FieldNumber[3]-1);
					SysBuf[PRTLEN] = 0;
					RJPrint(0, SysBuf);
				}
				if(PCBuffer[FieldNumber[4]] != 0x7f && PCBuffer[FieldNumber[5]] != 0x7f)
				{//date time of the receipt
					memset(SysBuf, ' ', PRTLEN);
					CopyFrStr(SysBuf, Msg[RIQI].str);
					slen = strlen(Msg[RIQI].str);
					CWORD(SysBuf[slen]) = CWORD(PCBuffer[FieldNumber[4]]);
					slen+=2;SysBuf[slen++] = '/';
					CWORD(SysBuf[slen]) = CWORD(PCBuffer[FieldNumber[4]+2]);
					slen+=2;SysBuf[slen++] = '/';
					CWORD(SysBuf[slen]) = CWORD(PCBuffer[FieldNumber[4]+4]);
					slen = PRTLEN - strlen(Msg[SHIJIAN].str) - 9;
					CopyFrStr(SysBuf + slen, Msg[SHIJIAN].str);
					slen = PRTLEN - 9;
					CWORD(SysBuf[slen]) = CWORD(PCBuffer[FieldNumber[5]]);
					slen+=2;SysBuf[slen++] = '/';
					CWORD(SysBuf[slen]) = CWORD(PCBuffer[FieldNumber[5]+2]);
					slen+=2;SysBuf[slen++] = '/';
					CWORD(SysBuf[slen]) = CWORD(PCBuffer[FieldNumber[5]+4]);
					SysBuf[PRTLEN] = 0;
					RJPrint(0, SysBuf);
				}
			}
#endif
			//ApplVar.FStatus = 1;  liuj 0827

			SETBIT(ApplVar.Fiscal_Status, FISCALDOC+OPENDOC);
//--------------------------liuj modify 070412 ----------------------------
			RESETBIT(ApplVar.DocCount, (GROBLEDISC+CANCELSALE+OVERTEND+HAVETEND+ITEMSOLD));
			RESETBIT(ApplVar.Fiscal_Status, UNKNOWNCMD+INVALIDCMD+REJECTED);
//--------------------------liuj modify 070412 ----------------------------
			}
		}
	}
	else
	{
		if(BIT(ApplVar.Fiscal_Status, OPENDOC+FISCALDOC))
			SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
		SETBIT(ApplVar.Fiscal_Status, INVALIDCMD);
	}

	//fill response data
	BCC = 0;
	SendAString(PCBuffer, 3);
	SendFisPrnStatus();
	SendETX_BCC();
}

//Command=0x41,print fiscal text in fiscal receipt
//STX + SEC + 0x41 + 0x1c + text  + ETX + BCC
//answer:
//STX + SEC + 0x41 + 0x1c + Print state + 0x1c + fiscal state + ETX + BCC
void FisPrinter_FiscalText()
{
	BYTE	sCmdOK=TRUE;
	BYTE	FieldCount, slen;

	if (FisPrinter_Status_Only())//ccr090511
		return;

	FieldCount = SetFields();
	slen = FieldNumber[1]-FieldNumber[0]-1;
	if (FieldCount != 1 && !CheckString(&PCBuffer[4], slen))
		sCmdOK=false;

	if(sCmdOK)
	{
		RESETBIT(ApplVar.Fiscal_Status, UNKNOWNCMD+INVALIDCMD+REJECTED);

		if(!BIT(ApplVar.Fiscal_Status, FISCALDOC) || BIT(ApplVar.DocCount, ITEMSOLD) || (ApplVar.DocCount&0x07)>3)
		{//command rejected
			SETBIT(ApplVar.Fiscal_Status, REJECTED);
		}
		else
		{
			memset(SysBuf, 0, PRTLEN);
			memcpy(SysBuf, PCBuffer+4, slen);
			SysBuf[PRTLEN] = 0;
			RJPrint(0, SysBuf);
			ApplVar.DocCount++;
		}
	}
	else
		SETBIT(ApplVar.Fiscal_Status, INVALIDCMD);

	BCC = 0;
	SendAString(PCBuffer, 3);
	SendFisPrnStatus();
	SendETX_BCC();
}

//Print line item in fiscal receipt
//Command=0x42:
//STX + SEC + 0x42 + 0x1c + ApplVar.Qty + 0x1c + Amount + 0x1c + ApplVar.Tax + 0x1c + 'M'/'m' + 0x1c + 0x7f + 0x1c + 0x7f + ETX + BCC
//answer:
//STX + SEC + 0x42 + 0x1c + Print state + 0x1c + fiscal state + Number of sold item + ETX + BCC
void FisPrinter_Item()
{
	BCD		sReceTax,sTax,bcdTemp,bcdTemp1;

	BYTE	sCmdOK=TRUE;
	BYTE	i,j, FieldCount, slen,temp[12];
	BCD MAXSale = {0,{0x99,0x99,0x99,0x99,0x00,0,0,0}};

	if (FisPrinter_Status_Only())//ccr090511
		return;

	FieldCount = SetFields();
	if((FieldCount >= 5 || FieldCount <= 8))
	{
		for(i = 0; i < FieldCount; i++)
		{
			if(!sCmdOK)
				break;
			j =FieldNumber[i];
			slen = FieldNumber[i+1]-j-1;
			switch (i)
			{
			case 0:	// Descriptor
				if(slen> PRTLEN || !CheckString(&PCBuffer[j], slen))
					sCmdOK = FALSE;
				break;
			case 1:	// Quantity
				if(slen> 7 || CheckDigit(&PCBuffer[j], slen)==-1)
					sCmdOK = FALSE;
				break;
			case 2:	// Amount
				if(slen> 10 || CheckDigit(&PCBuffer[j], slen)==-1)
					sCmdOK = FALSE;
				break;
			case 3:	// Imposed ApplVar.Tax
				if(slen> 4 || CheckDigit(&PCBuffer[j], slen)==-1)
					sCmdOK = FALSE;
				break;
			case 4:	// Qualifier
				if(slen> 1 || (PCBuffer[j] != 'M' && PCBuffer[j] != 'm'))
					sCmdOK = FALSE;
				break;
			case 5:	// not used
			case 6:	// not used
			case 7:	// not used
				if(slen> 1 || (PCBuffer[j] != 0x7f))
					sCmdOK = FALSE;
				break;
			}
		}
	}
	else
		sCmdOK = FALSE;

	if (sCmdOK)
	{
		RESETBIT(ApplVar.Fiscal_Status, UNKNOWNCMD+INVALIDCMD+REJECTED);

		if(!BIT(ApplVar.Fiscal_Status, FISCALDOC) || BIT(ApplVar.DocCount, HAVETEND/*+GROBLEDISC*/))
			SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
		else
		{
			memset(ApplVar.ItemName, 0, sizeof(ApplVar.ItemName));
			i = FieldNumber[1]-FieldNumber[0]-1;
			if (i>=sizeof(ApplVar.ItemName)-4)
				i = sizeof(ApplVar.ItemName)-5;
			memcpy(ApplVar.ItemName, PCBuffer+FieldNumber[0], i);

			if(BIT(ApplVar.DocCount, ITEMSOLD) && PCBuffer[FieldNumber[4]] == 'm')
			{//void
				ApplVar.Key.Code = CORREC + 1;
                Appl_EntryCounter = 0;
				Correction();
				if(ApplVar.ErrorNumber)
				{
					SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
					ApplVar.FVoid = 0;//ccr100716
				}
			}
			else if(PCBuffer[FieldNumber[4]] == 'M')
			{//item sale
				//ccr090918>>>>>>>>>>>
				if (BIT(ApplVar.Fiscal_Status,REFUNDDOC))
				{
					ApplVar.Key.Code = CORREC + 3;
        		    Appl_EntryCounter = 0 ;
					Correction();
				}
				//<<<<<<<<<<<<<<<<<<<<
				ApplVar.Qty = ZERO;
				memset(temp,0,sizeof(temp));
				slen = FieldNumber[2]-FieldNumber[1]-1;
				if(slen%2)
					memcpy(temp+1, PCBuffer+FieldNumber[1], slen++);
				else
					memcpy(temp, PCBuffer+FieldNumber[1], slen);
				StrToBCDValue(ApplVar.Qty.Value,temp+slen-1, slen/2);	//qty of the item

				ApplVar.Qty.Sign = 3;

				if ((ApplVar.Qty.Value[0] & 0x0f)==0)
				{
					ApplVar.Qty.Sign = 2;
					BcdDiv10(&ApplVar.Qty);

					if ((ApplVar.Qty.Value[0] & 0xff)==0)
					{
						ApplVar.Qty.Sign = 1;
						BcdDiv10(&ApplVar.Qty);


						if ((ApplVar.Qty.Value[0] & 0x0f)==0)
						{
							ApplVar.Qty.Sign = 0;
							BcdDiv10(&ApplVar.Qty);

						}

					}
				}

				//if(ApplVar.FRefund)
				//	SETBIT(ApplVar.Qty.Sign, BIT7);
				ApplVar.MultiplyCount = 1;
				ApplVar.Entry = ZERO;		//price of the item
				memset(temp,0,sizeof(temp));
				slen = FieldNumber[3]-FieldNumber[2]-1;
				if(slen%2)
					memcpy(temp+1, PCBuffer+FieldNumber[2], slen++);
				else
					memcpy(temp, PCBuffer+FieldNumber[2], slen);

				StrToBCDValue(ApplVar.Entry.Value, temp+slen-1 ,slen/2);
				ApplVar.Entry.Sign = 0;
				sReceTax = ZERO;		//ApplVar.Tax justice
				sTax = ZERO;
				memset(temp,0,sizeof(temp));

				slen = FieldNumber[4]-FieldNumber[3]-1;
				if(slen%2)
					memcpy(temp+1, PCBuffer+FieldNumber[3], slen++);
				else
					memcpy(temp, PCBuffer+FieldNumber[3], slen);

				StrToBCDValue( sReceTax.Value,temp+slen-1, slen/2);

				sReceTax.Sign = 4;
				if(CheckNotZero(&sReceTax))
				{
					for(ApplVar.TaxNumber = 0; ApplVar.TaxNumber < ApplVar.AP.Tax.Number; ApplVar.TaxNumber++)
					{
						ReadTax();
						memcpy(sTax.Value, ApplVar.Tax.Rate, sizeof(ApplVar.Tax.Rate));
						sTax.Sign = 0x04;
						if(!CompareBCD(&sReceTax, &sTax))
							break;
					}
				}
				else
					ApplVar.TaxNumber = ApplVar.AP.Tax.Number+1;

				Appl_EntryCounter= (FieldNumber[3]-FieldNumber[2])/2;
				if(ApplVar.TaxNumber < ApplVar.AP.Tax.Number || ApplVar.TaxNumber == ApplVar.AP.Tax.Number+1 )
				{
					ApplVar.Key.Code = DEPT+ 1 + ApplVar.TaxNumber;

					bcdTemp = ApplVar.Qty;
					Multiply(&bcdTemp,&ApplVar.Entry);
					bcdTemp1 = ApplVar.SaleAmt;
					Add(&bcdTemp1,&bcdTemp);
					if(CompareBCD(&bcdTemp1, &MAXSale) == 1 || CompareBCD(&bcdTemp, &MAXSale) ==1)
						SETBIT(ApplVar.Fiscal_Status, OVERFLOW);
					else
					{
						ProcessDept();
						if(ApplVar.ErrorNumber)
							SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
						else
						{
							SETBIT(ApplVar.DocCount, ITEMSOLD);
						}
					}
				}
				else
				{
					ApplVar.ErrorNumber =ERROR_ID(CWXXI100);
					SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
				}
			}
		}
	}
	else
		SETBIT(ApplVar.Fiscal_Status, INVALIDCMD);

	//fill response data
	BCC = 0;
	SendAString(PCBuffer,3);// same as received
	SendFisPrnStatus();
	SendSeparator(SEPARATOR);	SendABCD(&ApplVar.SaleQty);
	SendETX_BCC();
}

//Subtotal in a fiscal receipt
//command=0x43,
//STX + SEC + 0x43 + 0x1c + 0x7f + 0x1c + 0x7f + ETX + BCC
//answer:
//STX + SEC + 0x43 + 0x1c + Print state + 0x1c + fiscal state + 0x1c + 0x7f + 0x1c + 0x7f + 0x1c +
//	Exempt Sale + 0x1c + ApplVar.Tax Sale + 0x1c + ApplVar.Tax ApplVar.Amt + 0x1c + 0x7f + ETX + BCC
void FisPrinter_Subtotal()
{
	BYTE sTp;
	BCD sRealTax, sReceTax, sVal;
	BYTE	FieldCount, sCmdOK=TRUE;

	if (FisPrinter_Status_Only())//ccr090511
		return;

	FieldCount = SetFields();
	if(FieldCount != 1 && FieldCount != 2)
		sCmdOK=false;

	if(sCmdOK)
	{
			RESETBIT(ApplVar.Fiscal_Status, UNKNOWNCMD+INVALIDCMD+REJECTED);

		if(!BIT(ApplVar.Fiscal_Status, FISCALDOC) || BIT(ApplVar.DocCount, HAVETEND))
			SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
		else
		{
			ApplVar.DeptNumber = 0;

			ApplVar.Key.Code = SUB;
            Appl_EntryCounter = 0 ;
			Fixed();
			if(ApplVar.ErrorNumber)
				SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
		}

		BCC = 0;
		SendAString(PCBuffer,3);// same as received
		SendFisPrnStatus();
		SendSeparator(SEPARATOR);SendToHost(BLANKFIELD);
		SendSeparator(SEPARATOR);SendToHost(BLANKFIELD);
		SendSeparator(SEPARATOR);SendABCD(&ApplVar.RegExempt);//exempt sale

		//sale tax base & taxable base & tax
		sRealTax = sReceTax = ZERO;

		for(sTp = 0; sTp < ApplVar.AP.Tax.Number; sTp++)
		{
			Add(&sRealTax, &ApplVar.TaxItem[0][sTp]);
			getTaxAmount(&sVal,sTp, ApplVar.TaxItem[0][sTp]);
			Add(&sReceTax, &sVal);
		}

		sVal = sRealTax;
		Add(&sVal, &sReceTax);
		SendSeparator(SEPARATOR);SendABCD(&sVal);//sale tax base

		SendSeparator(SEPARATOR);SendABCD(&sRealTax);//taxable base
		SendSeparator(SEPARATOR);SendABCD(&sReceTax);//tax
		SendSeparator(SEPARATOR);SendToHost(BLANKFIELD);
		SendETX_BCC();
	}
	else
	{
		SETBIT(ApplVar.Fiscal_Status, INVALIDCMD);
		BCC = 0;
		SendAString(PCBuffer,3);// same as received
		SendFisPrnStatus();
		SendETX_BCC();
	}
}

//ApplVar.Total/payment/cancel/discount in a fiscal receipt
//command=0x44:
//STX + SEC + 0x44 + 0x1c + 0x7f + 0x1c + amt + 0x1c + 0x7f + 0x1c + C/T/D + ETX + BCC
//answer:
//STX + SEC + 0x44 + 0x1c + Print state + 0x1c + fiscal state + 0x1c + 0x7f + 0x1c + 0x7f + 0x1c + 0x7f + ETX + BCC
void FisPrinter_Tender()
{
	BYTE 	i,j, sTp, slen , sCh,temp[12];
	BYTE	FieldCount, sCmdOK=TRUE;

	FieldCount = SetFields();
	if(FieldCount == 2 || FieldCount == 3)
	{
		for(i = 0; i < FieldCount; i++)
		{
			if(!sCmdOK)
				break;
			j =FieldNumber[i];
			sCh = PCBuffer[j];
			slen = FieldNumber[i+1]-j-1;
			switch (i)
			{
			case 0:	// not used
				if(slen > 1/* || sCh!= 0x7f*/)
					sCmdOK = FALSE;
				break;
			case 1:	// Quantity
				if(slen > 8 ||  CheckDigit((char *)&PCBuffer[j], slen)==-1)
					sCmdOK = FALSE;
				break;
			case 2:	//  3   payment Amount

				if(sCh != 'C' && sCh != 'T' && sCh != 'D' &&  sCh != '%' || slen > 1)
					sCmdOK = FALSE;
				break;
			default:
				sCmdOK=false;
				break;
			}
		}
	}
	else
		sCmdOK=false;

	if (!(PCBuffer[FieldNumber[2]]=='C'  && BIT(ApplVar.Fiscal_Status, FISCALDOC+OPENDOC)) &&
			(ApplVar.FisCardFlag==BADEJ || ApplVar.FisCardFlag==MUSTINITEJ))
		if (FisPrinter_Status_Only())//ccr090511
			return;

	if(sCmdOK)
	{
		RESETBIT(ApplVar.Fiscal_Status, UNKNOWNCMD+INVALIDCMD+REJECTED);

		if(!BIT(ApplVar.Fiscal_Status, FISCALDOC))
			SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
		else
		{

			if(PCBuffer[FieldNumber[2]]!='D' && PCBuffer[FieldNumber[2]]!='%')
				ApplVar.DeptNumber = 0;
			if (PCBuffer[FieldNumber[2]]!='C')
			{
				ApplVar.Entry = ZERO;		//price of the item
				memset(EntryBuffer,0,30);
				slen = FieldNumber[2]-FieldNumber[1]-1;

				if(slen & 1)
					memcpy(EntryBuffer+1, PCBuffer+FieldNumber[1], slen++);
				else
					memcpy(EntryBuffer, PCBuffer+FieldNumber[1], slen);

				StrToBCDValue(ApplVar.Entry.Value, EntryBuffer+slen-1 ,slen/2);
				ApplVar.Entry.Sign = 0;
				if(!CheckNotZero(&ApplVar.Entry))
					Appl_EntryCounter = 0;
				else
					Appl_EntryCounter = 1;
			}

			switch(PCBuffer[FieldNumber[2]])	{
			case 'C':			//cancel sale
				if(!BIT(ApplVar.DocCount, ITEMSOLD+HAVETEND))
				{
					SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
					break;
				}
				ApplVar.Key.Code = CORREC + 4;
				Appl_EntryCounter = 0;
				Correction();
				SETBIT(ApplVar.DocCount, CANCELSALE);
				break;
			case 'T':			//tender
				if(!BIT(ApplVar.DocCount, ITEMSOLD) || BIT(ApplVar.DocCount, CANCELSALE+OVERTEND))
				{
					SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
					break;
				}


				ApplVar.Key.Code = TEND + 1;

				Tender();
				if(ApplVar.ErrorNumber)
				{
					SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
					break;
				}
				SETBIT(ApplVar.DocCount, HAVETEND);
				break;
			case 'D':			//subtotal discount
			case '%':
/*ccr070423
				ApplVar.Key.Code = SUB;
                                Appl_EntryCounter=0;
				Fixed();
					if(ApplVar.ErrorNumber)//ccr070420
					{
						SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
						break;
					}
*/

				if (!BIT(ApplVar.DocCount,HAVETEND) && Appl_EntryCounter)
				{
					if (PCBuffer[FieldNumber[2]]=='%')
						ApplVar.Key.Code = DISC+2;	//ccr070420
					else
						ApplVar.Key.Code = DISC+4;	//ccr070420

					Discount();
					if(ApplVar.ErrorNumber)//ccr070420
					{
						SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
						break;
					}
					SETBIT(ApplVar.DocCount, GROBLEDISC);
				}
				else
					SETBIT(ApplVar.Fiscal_Status, REJECTED);		//ccr070420command rejected
				break;
			}
		}
	}
	else
		SETBIT(ApplVar.Fiscal_Status, INVALIDCMD);

	BCC = 0;
	SendAString(PCBuffer,3);// same as received
	SendFisPrnStatus();
	SendSeparator(SEPARATOR);SendToHost(BLANKFIELD);
	SendSeparator(SEPARATOR);SendToHost(BLANKFIELD);
	SendSeparator(SEPARATOR);SendToHost(BLANKFIELD);
	SendETX_BCC();

}

//Close afiscal receipt
//command=0x45:
//STX + SEC + 0x45 + 0x1c + 0x7f + ETX + BCC
//answer:
//STX + SEC + 0x45 + 0x1c + Print state + 0x1c + fiscal state + 0x1c + Rec# + ETX + BCC
void FisPrinter_CloseReceipts()
{

	BYTE i, slen, FieldCount, sCmdOK=TRUE;
	BCD bcdtemp;

	FieldCount = SetFields();

	if((FieldCount = SetFields()) > 1)
		sCmdOK=false;

	if(sCmdOK)
	{

		RESETBIT(ApplVar.Fiscal_Status, UNKNOWNCMD+INVALIDCMD+REJECTED);

		if(!BIT(ApplVar.Fiscal_Status, FISCALDOC) || ( BIT(ApplVar.DocCount,ITEMSOLD) && !BIT(ApplVar.DocCount, OVERTEND+CANCELSALE)))
			SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
		else
		{
			ApplVar.DocCount = 0;
			RESETBIT(ApplVar.Fiscal_Status, OPENDOC+FISCALDOC+REFUNDDOC);
#if (0)//ccr100719			//copy from Tender(); >>>>>>>>>>>>>>>>>>>>
			ApplVar.AmtDecimal = NO_DECIMAL;	    /* restore local values for kp */
			Prefix1 = PREFIX_1; 			/* and VAT print */
			Prefix2 = PREFIX_2;
			if (ApplVar.OpDraw)
				OpenDrawer();
			StoreInBuffer();
			if (PVAT)
			{
				CalculateTax(3);    /* print inclusive tax */
				//CalculateTax(2);    /* print inclusive tax */
			}
			PrintSaleQty();
			//ReceiptIssue(1);  liuj 0827
			ApplVar.BufCC = 1;		       /* set add Customer Count */
			ProcessBuffer();	/* reset Customer count and print kp */
#endif
			ApplVar.FSplit = 0;
			ApplVar.FRegi = 0; 		// liuj 0827
			ApplVar.FRefund = 0;
			//end <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
		}
	}
	else
		SETBIT(ApplVar.Fiscal_Status, INVALIDCMD);

	BCC = 0;
	SendAString(PCBuffer,3);
	SendFisPrnStatus();

	SendSeparator(SEPARATOR);SendALong(ApplVar.FisNumber.TotalReceiptNum[FRECEIPTS]);//ccr091027 receipt number
	SendETX_BCC();
}

//Open non fiscal document
//Command=0x48:
//STX + SEC + 0x48 + ETX + BCC
//answer:
//STX + SEC + 0x48 + 0x1c + Print state + 0x1c + fiscal state + ETX + BCC
void FisPrinter_OpenText()
{
	if (FisPrinter_Status_Only())//ccr090511
		return;

	if(BIT(ApplVar.Fiscal_Status, OPENDOC))
			SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
	else
	{
		RESETBIT(ApplVar.Fiscal_Status, UNKNOWNCMD+INVALIDCMD+REJECTED);
		ApplVar.FStatus = 0;
#if CASE_FATFS_EJ
		ApplVar.EJContent = TXTCONT;
		SETBIT(ApplVar.ContFlag, (ENSTORE|ENHEADER));
#endif
		AddReceiptNumber();
		PrintHead1(0);
	   //	PrintReceiptNum(); ???? debug
		ApplVar.DocCount = 0;	//SETBIT(ApplVar.DocCount, i);
		SETBIT(ApplVar.Fiscal_Status, OPENDOC);
		RESETBIT(ApplVar.Fiscal_Status, FISCALDOC);
	}

	BCC = 0;
	SendAString(PCBuffer,3);
	SendFisPrnStatus();
	SendETX_BCC();

 }

//Print non fiscal text in a non fiscal document
//COmmand=0x49:
//STX + SEC + 0x49 + 0x1c + text  + ETX + BCC
//answer:
//STX + SEC + 0x49 + 0x1c + Print state + 0x1c + fiscal state + ETX + BCC
void FisPrinter_PrintText()
{

	BYTE	sCmdOK=TRUE;
	BYTE	FieldCount, slen;

	if (FisPrinter_Status_Only())//ccr090511
		return;

	FieldCount = SetFields();
	slen = FieldNumber[1]-FieldNumber[0]-1;
	if (FieldCount != 1 && !CheckString(&PCBuffer[4], slen))
		sCmdOK=false;

	if(sCmdOK)
	{

		RESETBIT(ApplVar.Fiscal_Status, UNKNOWNCMD+INVALIDCMD+REJECTED);
		if(!BIT(ApplVar.Fiscal_Status, OPENDOC) || BIT(ApplVar.Fiscal_Status, FISCALDOC) || (ApplVar.DocCount & 0x07)>3)
		{//command rejected
			SETBIT(ApplVar.Fiscal_Status, REJECTED);
		}
		else
		{
			memset(SysBuf, 0, PRTLEN);
			memcpy(SysBuf, PCBuffer+4, slen);
			SysBuf[PRTLEN] = 0;
			RJPrint(0, SysBuf);
			ApplVar.DocCount++;
		}
	}
	else
		SETBIT(ApplVar.Fiscal_Status, INVALIDCMD);

	BCC = 0;
	SendAString(PCBuffer,3);
	SendFisPrnStatus();
	SendETX_BCC();

}

//Close a non fiscal document
//COmmand=0x4a:
//STX + SEC + 0x4a + 0x1c + 0x7f  + ETX + BCC
//answer:
//STX + SEC + 0x4a + 0x1c + Print state + 0x1c + fiscal state + 0x1c + NF# + ETX + BCC
void FisPrinter_CloseText()
{
	BYTE i, slen, FieldCount, sCmdOK=TRUE;

	if((FieldCount = SetFields()) > 1)
		sCmdOK=false;

	if(sCmdOK)
	{
		RESETBIT(ApplVar.Fiscal_Status, UNKNOWNCMD+INVALIDCMD+REJECTED);

		if(!BIT(ApplVar.Fiscal_Status, OPENDOC) || BIT(ApplVar.Fiscal_Status, FISCALDOC))
		{
			SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
		}
		else
		{
			RESETBIT(ApplVar.Fiscal_Status, OPENDOC);
			ApplVar.FReceipt = 1;
			ReceiptIssue(1);
			RFeed(1);
		}
	}
	else
		SETBIT(ApplVar.Fiscal_Status, INVALIDCMD);

	BCC = 0;
	SendAString(PCBuffer,3);
	SendFisPrnStatus();
	SendSeparator(SEPARATOR);SendAWord(ApplVar.TXTCount);//receipt number
	SendETX_BCC();

}

//Cut paper
//Command=0x4b:
//STX + SEC + 0x4b + 0x1c + text  + ETX + BCC
//answer:
//STX + SEC + 0x4b + 0x1c + Print state + 0x1c + fiscal state + ETX + BCC
void FisPrinter_PaperCut()
{

	if (FisPrinter_Status_Paper())
		return;

	if(BIT(ApplVar.Fiscal_Status, OPENDOC)|| !CheckPrinter())
		SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
	else
    {
        RESETBIT(ApplVar.Fiscal_Status, UNKNOWNCMD+INVALIDCMD+REJECTED);
        CutRPaper(2);//ccr070612
    }

	BCC = 0;
	SendAString(PCBuffer,3);
	SendFisPrnStatus();
	SendETX_BCC();
}

//Advanced of receipts paper
//Command=0x50:
//STX + SEC + 0x50 + 0x1c + text  + ETX + BCC
//answer:
//STX + SEC + 0x50 + 0x1c + Print state + 0x1c + fiscal state + ETX + BCC
void FisPrinter_PaperFeed()
{
	BYTE sRetry;

	if(BIT(ApplVar.Fiscal_Status, OPENDOC+FISCALDOC))
	{
		SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
	}
	else
	{
		RESETBIT(ApplVar.Fiscal_Status, UNKNOWNCMD+INVALIDCMD+REJECTED);
		RFeed(1);
	}

	BCC = 0;
	SendAString(PCBuffer,3);
	SendFisPrnStatus();
	SendETX_BCC();

}



//Command=0x57:Setting BaudRate of RS232 port
//STX + SEC + 0x57 + 0x1c + ApplVar.Port + 0x1c + Baud + ETX + BCC
// ApplVar.Port:'1'=RS232-1 '2'=RS232-2
//Baud:'1'-1200,'2'-2400,'3'-4800,'4'-9600,'5'-19200,'6'-38400,'7'-57600,'8'-115200
//answer:
//STX + SEC + 0x57 + 0x1c + Print state + 0x1c + fiscal state + ETX + BCC

void FisPrinter_SetBaudRate()
{
	BYTE	sCmdOK=TRUE;
	char    sProt[5];


	if (SetFields()!=2 || PCBuffer[FieldNumber[0]] != '1' && PCBuffer[FieldNumber[0]] != '2' ||
			PCBuffer[FieldNumber[1]] < '1' || PCBuffer[FieldNumber[1]] >'8')
		sCmdOK = FALSE;

	if(!sCmdOK)
		SETBIT(ApplVar.Fiscal_Status, INVALIDCMD);
	BCC = 0;
	SendAString(PCBuffer,3);
	SendFisPrnStatus();
	SendETX_BCC();
	if(sCmdOK)
	{
		ApplVar.PortNumber = PCBuffer[FieldNumber[0]] - '1';
		ReadPort();
		sProt[0] = PCBuffer[FieldNumber[1]];
		sProt[1] = '0';sProt[2] = '1';sProt[3] = '8';sProt[4] = '1';
		ApplVar.Port.Prot[ApplVar.Port.Type - 0x31]=EnCodeProto(sProt);
		WritePort();
		SetComm(ApplVar.PortNumber);
	}
}



//Command=0x58:Setting date and time,This command will be rejected in the following cases:
// 1. If there are Daily Totals in the Working Memory.
// 2. If the new date is smaller than the last one stored in the Fiscal Memory.
// 3. If previously you modified the Time and/or Date without carrying out a closing of the Fiscal ApplVar.Day.
//STX + SEC + 0x58 + 0x1c + YYMMDD + 0x1c + HHMMSS + ETX + BCC
//answer:
//STX + SEC + 0x58 + 0x1c + Print state + 0x1c + fiscal state + ETX + BCC
void FisPrinter_SetTime()
{

	BYTE	sCmdOK=TRUE;
	BYTE	i, FieldCount, slen ,j ;
	struct TimeDate		sNow;


	if((FieldCount = SetFields()) == 2)
	{
		memset(&ApplVar.LogDefine, 0, sizeof(ApplVar.LogDefine));

		for(i = 0; i < 2; i++)
		{
			if(!sCmdOK)
				break;

			j = FieldNumber[i];
			slen = FieldNumber[i+1]-j-1;
			if(slen != 6 || CheckDigit((char *)&PCBuffer[j], slen)==-1)
			{
				sCmdOK = FALSE;
				break;
			}
			if(i == 0)
			{
				sNow.year = ((PCBuffer[j] & 0x0f) << 4) + (PCBuffer[j+1] & 0x0f);j+=2;		// yy //
				sNow.month=((PCBuffer[j] & 0x0f) << 4) + (PCBuffer[j+1] & 0x0f);j+=2;		// mm //
				sNow.day = ((PCBuffer[j] & 0x0f) << 4)  + (PCBuffer[j+1] & 0x0f);j+=2;		// yy //
			}
			else
			{
				sNow.hour= ((PCBuffer[j] & 0x0f) << 4) + (PCBuffer[j+1] & 0x0f);j+=2;		// yy //
				sNow.min= ((PCBuffer[j] & 0x0f) << 4)  + (PCBuffer[j+1] & 0x0f);j+=2;		// yy //
				sNow.sec= ((PCBuffer[j] & 0x0f) << 4) + (PCBuffer[j+1] & 0x0f);j+=2 ;		// yy //
			}
		}
	}
	else
		sCmdOK = FALSE;

	if (sCmdOK)
	{

		RESETBIT(ApplVar.Fiscal_Status, UNKNOWNCMD+INVALIDCMD+REJECTED);

		if (BIT(ApplVar.Fiscal_Status, OPENDOC+FISCALDOC) || MyFlags(ZREPORT))   /* z report taken ? */
		{
			SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
		}
		else
		{//
			if(ApplVar.FisCardFlag < FMISNEW && CompDate(&sNow,ApplVar.FisNumber.LastZDate)<0)
				SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
			else
			{
				SetTimeDate(&sNow) ;
				Now = sNow;
			}
		}
	}
	else
		SETBIT(ApplVar.Fiscal_Status, INVALIDCMD);

	BCC = 0;
	SendAString(PCBuffer,3);
	SendFisPrnStatus();
	SendETX_BCC();
}

//get date and time
//Command=0x59
//STX + SEC + 0x59 + ETX + BCC
//answer:
//STX + SEC + 0x59 + 0x1c + YYMMDD + 0x1c + HHMMSS + ETX + BCC
void FisPrinter_GetTime()
{
	RESETBIT(ApplVar.Fiscal_Status, UNKNOWNCMD+INVALIDCMD+REJECTED);

	BCC = 0;
	SendAString(PCBuffer,3);
	SendFisPrnStatus();
	GetTimeDate(&Now);
	SendDate();
	SendTime();
	SendETX_BCC();

}

//Command=0x5a:Set tax rate for eight tax
//STX + SEC + 0x5a + 0x1c + Tax1(nnnn) + 0x1c + Tax2(nnnn) + 0x1c + Tax3(nnnn) + 0x1c + Tax4(nnnn)
//  + 0x1c + Tax5(nnnn) + 0x1c + Tax6(nnnn) + 0x1c + Tax7(nnnn) + 0x1c + Tax8(nnnn)+ ETX + BCC
//Answer:
//STX + SEC + 0x5a + 0x1c + Print state + 0x1c + fiscal state + ETX + BCC
void FisPrinter_SetTax()
{
	BYTE  sTaxType,sCh, sCmdOK=TRUE;
	BYTE sCount,FieldCount;
	WORD i;

	FieldCount=sCount=0;

	for (i=3;i<sizeof(PCBuffer);)
	{
		sCh = PCBuffer[i];
		if (sCh==ETX)
		{
			FieldNumber[FieldCount] = i;
			break;
		}
		else if (sCh==SEPARATOR)
		{
			i++;
			FieldNumber[FieldCount] = i;
			FieldCount++;

			sCount = 0;
		}
		else
		{
			sCount++;
			if (FieldCount>0)
			{
				if (FieldCount<=8)//ApplVar.AP.Tax.Number)
				{
					if(sCh < '0' || sCh > '9' || sCount > 4)
					sCmdOK = FALSE;
				}
				else if (FieldCount==9)
					sTaxType = sCh;//'V' or not
			}
			i++;
		}
	}
	if (sCmdOK)
	{
		RESETBIT(ApplVar.Fiscal_Status, UNKNOWNCMD+INVALIDCMD+REJECTED);

		if(ApplVar.FisCardFlag < FMISNEW && !BIT(ApplVar.Fiscal_Status, OPENDOC+FISCALDOC) && !MyFlags(ZREPORT))
		{
			for (ApplVar.TaxNumber=0;ApplVar.TaxNumber<ApplVar.AP.Tax.Number;ApplVar.TaxNumber++)
			{
				ReadTax();
				CWORD(ApplVar.FiscalBuff.Fis_TaxRate.FOTaxRate[ApplVar.TaxNumber][0]) = CWORD(ApplVar.Tax.Rate[0]);

				ApplVar.Tax.Rate[2] = 0;
				StrToBCDValue(ApplVar.Tax.Rate,&PCBuffer[FieldNumber[ApplVar.TaxNumber]+3], 2);
				CWORD(ApplVar.FiscalBuff.Fis_TaxRate.FNTaxRate[ApplVar.TaxNumber][0]) = CWORD(ApplVar.Tax.Rate[0]);
				if (sTaxType=='V')
					SETBIT(ApplVar.Tax.Options,BIT0);
				else
					RESETBIT(ApplVar.Tax.Options,BIT0);
				WriteTax();
			}
			ProcessTax(true);
		}
		else
			SETBIT(ApplVar.Fiscal_Status, REJECTED);
	}
	else
		SETBIT(ApplVar.Fiscal_Status, INVALIDCMD);

	BCC = 0;
	SendAString(PCBuffer,3);
	SendFisPrnStatus();
	SendSeparator(SEPARATOR);SendAWord(ApplVar.FisNumber.TotalTaxChangeNum);//ccr091110
	SendETX_BCC();

}

//Command=0x5b:Get tax rate from Fiscal printer
//STX + SEC + 0x5B +  ETX + BCC
//Answer:
//STX + SEC + 0x5B + 0x1c + Tax1(nnnn) + 0x1c + Tax2(nnnn) + 0x1c + Tax3(nnnn) + 0x1c + Tax4(nnnn)
//  + 0x1c + Tax5(nnnn) + 0x1c + Tax6(nnnn) + 0x1c + Tax7(nnnn) + 0x1c + Tax8(nnnn)+ ETX + BCC

void FisPrinter_GetTax()
{

	RESETBIT(ApplVar.Fiscal_Status, UNKNOWNCMD+INVALIDCMD+REJECTED);
	BCC = 0;
	SendAString(PCBuffer,3);
	SendFisPrnStatus();
	SendTaxRate();
	SendETX_BCC();

}

//Establishing Fixed Data of headings (0x5D) / footer (0x5E)
//STX	+ Sec +Command(0x5d /0x5e) +
//0x1c + line number 1 + 0x1c + Fiscal Text1 +
//0x1c + line number 2 + 0x1c + Fiscal Text2 +
//0x1c + line number 3 + 0x1c + Fiscal Text3 +
//0x1c + line number 4 + 0x1c + Fiscal Text4 + ETX + 	BCC <nnnn>
//Answer:
//STX + SEC + 0x5D/0x5e + 0x1c + Print state + 0x1c + fiscal state + ETX + BCC
void FisPrinter_SetHead_Footer(BYTE pH_F)
{
	BYTE	sCmdOK=TRUE;
	BYTE	sLen;
	BYTE	 sCount,sCh,FieldCount;
	WORD     i;

	if (pH_F==SETHEADING && FisPrinter_Status_Only())
		return;

	FieldCount= sCount = 0;

	for (i=3;i<sizeof(PCBuffer);)
	{
		sCh = PCBuffer[i];
		if (sCh==ETX)
		{
			FieldNumber[FieldCount] = i;
			break;
		}
		else if (sCh==SEPARATOR)
		{
			i++;
			FieldNumber[FieldCount] = i;
			FieldCount++;
			sCount = 0;
		}
		else
		{
			sCount++;
			if (!(FieldCount & 0x01))
				if(sCh < ' ' || sCount > PRTLEN)
					sCmdOK = FALSE;
			i++;
		}
	}

	if (sCmdOK && (FieldCount & 1)==0)
	{
		RESETBIT(ApplVar.Fiscal_Status, UNKNOWNCMD+INVALIDCMD+REJECTED);

		if (pH_F==SETHEADING)
		{
			if( ApplVar.FisNumber.TotalHeadChangeNum>FHEADCHGMAX)
			{
				SETBIT(ApplVar.Fiscal_Status, FM_FULL);
			}
			else
			{
				for (i=0;i<FieldCount;)
				{
					sCount = CheckDigit(&PCBuffer[FieldNumber[i]], FieldNumber[i+1]-FieldNumber[i]-1);

					if (sCount<8  && sCount>0) // liuj 0912
					{
						memset(ApplVar.TXT.Header[sCount-1],0,PRTLEN+1);	// liuj 0912
						i++;

                        if((FieldNumber[i+1]-FieldNumber[i])>1 )
						        memcpy(ApplVar.TXT.Header[sCount-1],&PCBuffer[FieldNumber[i]],FieldNumber[i+1]-FieldNumber[i]-1);
						i++;
					}
					else
					{
						SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
						sCmdOK = false;
						break;
					}
				}
			      	if (sCmdOK)
				{
					ProcessHead(true);
					if (ApplVar.ErrorNumber)
						SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
				}
			}
		}
		else
		{
				for (i=0;i<FieldCount;)
				{
					sCount = CheckDigit(&PCBuffer[FieldNumber[i]], FieldNumber[i+1]-FieldNumber[i]-1);
					if (sCount<8 && sCount>0)
					{
						memset(ApplVar.TXT.Trailer[sCount-1],0,PRTLEN+1);
						i++;
						if((FieldNumber[i+1]-FieldNumber[i])>1)
							memcpy(ApplVar.TXT.Trailer[sCount-1],&PCBuffer[FieldNumber[i]],FieldNumber[i+1]-FieldNumber[i]-1);
						i++;
					}
					else
					{
						SETBIT(ApplVar.Fiscal_Status, REJECTED);		//command rejected
						sCmdOK = false;
						break;
					}
				}
		}

	}
	else
		SETBIT(ApplVar.Fiscal_Status, INVALIDCMD);

	BCC = 0;
	SendAString(PCBuffer,3);
	SendFisPrnStatus();
	SendSeparator(SEPARATOR);SendAWord(ApplVar.FisNumber.TotalHeadChangeNum);//ccr091110
	SendETX_BCC();

}

void FisPrinter_OpenDrawer()
{
	RESETBIT(ApplVar.Fiscal_Status, UNKNOWNCMD+INVALIDCMD+REJECTED);

	OpenDrawer();
	BCC = 0;
	SendAString(PCBuffer,3);
	SendFisPrnStatus();
	SendETX_BCC();
}



//Command 0x70, Read Fiscall Memory by address
//STX + Sec + 0x70 + 0x1c + FMAddress + ETX + BCC
//Answer from FiscalPrinter:
//STX+Sec+0x70+0x1c+FMData+ETX + BCC
//Read 128Bytes from address to Address+127
void FisPrinter_FMRead()
{
	BYTE j,slen,asc[2];
	ULONG fmAddress;

	SetFields();

	BCC = 0;
	SendAString(PCBuffer,3);


	j = FieldNumber[0];
	slen = FieldNumber[1]-j-1;

	fmAddress =  CheckDigit((char *)&PCBuffer[j], slen);

	if(fmAddress != -1)
		if (Read_FiscalRam(PCBuffer,fmAddress,128))
		{
				SendFisPrnStatus();
				SendSeparator(SEPARATOR);
				for(j=0;j<128;j++)
					SendAByte(PCBuffer[j]);
		}
		else
		{
			SETBIT(ApplVar.Fiscal_Status, FM_ERR);
			SendFisPrnStatus();
		}
	else
		SendFisPrnStatus();
	SendETX_BCC();

}


//Command 0x71, Read Fiscall Data from Fiscal Memory by Date
//STX + Sec + 0x71 + 0x1c + Date / 0x7f + ETX + BCC
//Answer from FiscalPrinter:
//STX+Sec+0x71 +0x1c+FMData+ETX + BCC
void FisPrinter_FMReadByDate()
{
	BYTE	sCmdOK=TRUE,sNext=FALSE;
	BYTE	sQualifier, FieldCount, slen;
	WORD 	sYear, sMonth, sDay;	//From YYMMDD/ To YYMMDD
	WORD	i, j;

	if (FisPrinter_Status_Only())
		switch(ApplVar.FisCardFlag)
		{
			case NOFM:		//  4: no Card //
			case BADFM:		//  5: invalid Card //
//			case FMFULL:		//  6: fm  full
//			case FMMACFULL:		//  7: mac > 200
//			case FMERROR:	//  8: data error
//			case CHECKSUMCHANGED:
			case FM_X_ECR:
//			case FM_X_EJ:
//			case MUSTINITFM:
			case FMISNEW:
//			case BADEJ:
//			case EJFULL :
//			case MUSTINITEJ :
//			case NOEJ:
				return;
		}


	if(((FieldCount = SetFields()) == 1) && (!BIT(ApplVar.Fiscal_Status, OPENDOC)))
	{
		memset(&ApplVar.FiscalDefine, 0, sizeof(ApplVar.FiscalDefine));

//ccr070418		for(i = 0; i < FieldCount; i++)
		{
//ccr070418			if(!sCmdOK)		break;
			j = FieldNumber[0];
			slen = FieldNumber[1]-j-1;
//ccr070418			if(!i)
			{
				if(slen == 6)
				{
					if (CheckDigit((char *)&PCBuffer[j], slen)==-1)
						sCmdOK = FALSE;
					else
					{
						sYear = (((PCBuffer[j] & 0x0f) << 4) | (PCBuffer[j+1] & 0x0f));
						                                j+=2;
						sMonth = (((PCBuffer[j] & 0x0f) << 4) | (PCBuffer[j+1] & 0x0f));
						                                j+=2;
						sDay = (((PCBuffer[j] & 0x0f) << 4) | (PCBuffer[j+1] & 0x0f));
					}
				}
				else if (slen ==1 && PCBuffer[j] ==0x7f)
				{
					sNext = TRUE;
				}
				else
					sCmdOK = FALSE;
			}

		}
	}
	else
		sCmdOK = FALSE;


	BCC = 0;
	SendAString(PCBuffer,3);


	if(sCmdOK == FALSE)
	{
		SETBIT(ApplVar.Fiscal_Status, INVALIDCMD);
		SendFisPrnStatus();
	}
	else
	{
		if(sNext)
		{
			if(  ApplVar.LogDefine.RecNumTo  )
				ApplVar.LogDefine.RecNumTo += FISRECORDLEN ;
			else
				ApplVar.LogDefine.RecNumTo = FISDATAADDR;
			Bios_FM_Read(PCBuffer,ApplVar.LogDefine.RecNumTo,FISRECORDLEN);
		}
		else
		{
			ApplVar.FiscalDefine.DateFr = EncordBCDDate(sYear, sMonth, sDay);//ccr070418
			ApplVar.LogDefine.RecNumTo = FISDATAADDR;
			SendComm(COMPUTER_1,DC2);//ccr070418 Request delay
			while (ApplVar.LogDefine.RecNumTo < ApplVar.FiscalHead.MaxP)
			{
				Bios_FM_Read(PCBuffer,ApplVar.LogDefine.RecNumTo,FISRECORDLEN);//ccr070418
				if(CWORD(PCBuffer)>= ApplVar.FiscalDefine.DateFr)
					break;
				else
					ApplVar.LogDefine.RecNumTo += FISRECORDLEN ;
			}
		}
		SendFisPrnStatus();

		if(ApplVar.LogDefine.RecNumTo < ApplVar.FiscalHead.MaxP)
		{
			SendSeparator(SEPARATOR);
			for(j=0;j<FISRECORDLEN;j++)
				SendAByte(PCBuffer[j]);
		}
	}



	SendETX_BCC();


}

//ProcessFiscalCmd()
//-----------------
//Input:PCBuffer = Ӧ����һ�����������﷨�����ݰ� //
//		PCBuffer[0]=FISCOMM
//		PCBuffer[1]=Sec
//		PCBuffer[2]=Command
//		PCBuffer[3]=........
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<
void ProcessFiscalCmd()
{
	ApplVar.ErrorNumber=0;//ccr090917
	RESETBIT(ApplVar.Fiscal_Status, REJECTED);
	InActive = 0;
	PCBuffer[0]=STX;

	switch(PCBuffer[2]){//ccr070322
	case GETSTATUS:
		FisPrinter_Status();//ccr070322
		break;
	case DAILYCLOSE:
		FisPrinter_DailyRep();
		break;
	case FMREPBYDATE:
		FisPrinter_FMRepByDate();
		break;
	case FMREPBYNUM:
		FisPrinter_FMRepByNum();
		break;
	case FISCALIATION:
		FisPrinter_Fiscaliation();
		break;
	case EJREPRINT:
		FisPrinter_EJReprint();
		break;
	case EJINITIAL:
		FisPrinter_InitMMC();
		break;
	case OPENFISCAL:	//open fiscal document
		FisPrinter_OpenReceipts();//ccr070322
		break;
	case FISCALTEXT:		//print fiscal text
		FisPrinter_FiscalText();
		break;
	case PRINTITEM:		//item registration || void
		FisPrinter_Item();
		break;
	case PRINTSUB:		//subtotal
		FisPrinter_Subtotal();
		break;
	case PRINTTENDER:	//tender || cancel sale || subtotal discount
		FisPrinter_Tender();
		break;
	case CLOSEFISCAL:
		FisPrinter_CloseReceipts();
		break;
	case OPENTEXT:
		FisPrinter_OpenText();
		break;
	case PRINTTEXT:
		FisPrinter_PrintText();
		break;
	case CLOSETEXT:
		FisPrinter_CloseText();
		break;
	case PAPERCUT:
		FisPrinter_PaperCut();
		break;
	case PAPERFEED:
		FisPrinter_PaperFeed();
		break;
	case SETDATETIME:
		FisPrinter_SetTime();
		break;
	case GETDATETIME:
		FisPrinter_GetTime();
		break;
	case SETTAXRATE:
		FisPrinter_SetTax();
		break;
	case GETTAXRATE:
		FisPrinter_GetTax();
		break;
	case SETHEADING:
	case SETFOOTER:
		FisPrinter_SetHead_Footer(PCBuffer[2]);
		break;
	case OPENDRAWER:
	case OPENDRAWER+1:
		FisPrinter_OpenDrawer();
		break;
	case OPERATE_PRIVATE:
		FisPrinter_OperatePrivate();
		break;
	case READFM:
		FisPrinter_FMRead();
		break;
	case READFMBYDATE:
		FisPrinter_FMReadByDate();
         break;
	case SETBAUDRATE:
		FisPrinter_SetBaudRate();
		break;
	default:
		SETBIT(ApplVar.Fiscal_Status, INVALIDCMD);
		BCC = 0;
		SendAString(PCBuffer,3);
		SendFisPrnStatus();
		SendSeparator(SEPARATOR);SendAWord(ApplVar.TXTCount);//receipt number
		SendETX_BCC();
		break;
	}
//ccr090917	ApplVar.ErrorNumber=0;
}


/*
 send staus only if some error found befor a command
*/
BYTE FisPrinter_Status_Only()
{
#if defined(FISCAL)

	if(!Bios_FM_CheckPresence())
		ApplVar.FisCardFlag = NOFM;
	switch(ApplVar.FisCardFlag)
	{
	case 0://ccr100902
		CheckPrinter();
		break;
/*		case FMLESS:		// 3: already 100 EJs
		ApplVar.ErrorNumber=0;
		break;*/
	case NOFM:		//  4: no Card //
		ApplVar.ErrorNumber |=  74;
		break;
	case BADFM:		//  5: invalid Card //
		ApplVar.ErrorNumber |=  76;
		break;
	case FMFULL:		//  6: fm  full
		ApplVar.ErrorNumber |=  86;
		break;
	case FMMACFULL:		//  7: mac > 200
		ApplVar.ErrorNumber |=  91;
		break;
	case FMERROR:	//  8: data error
		ApplVar.ErrorNumber |=  78;
		break;
	case CHECKSUMCHANGED:
		ApplVar.ErrorNumber |= ERROR_ID(CWXXI92);
		break;
	case FM_X_ECR:
		ApplVar.ErrorNumber |= ERROR_ID(CWXXI93);
		break;
	case FM_X_EJ:
		ApplVar.ErrorNumber |= ERROR_ID(CWXXI98);
		break;
//	case MUSTINITFM:
	case FMISNEW:
		ApplVar.ErrorNumber |= ERROR_ID(CWXXI94);
		break;
	case BADEJ:
		ApplVar.ErrorNumber |= 84;
		break;
	case EJFULL :
		ApplVar.ErrorNumber |= 88 ;
		break;
	case MUSTINITEJ :
		ApplVar.ErrorNumber |= ERROR_ID(CWXXI97);
		break;
	case NOEJ:
		ApplVar.ErrorNumber |= 83;
		break;
	default:
		ApplVar.ErrorNumber |= ERROR_ID(CWXXI99);
		break;
	}

//	CheckFisError();
#endif

	if (ApplVar.ErrorNumber)//ccr090511 && PCBuffer[3]==SEPARATOR)
	{
		BCC = 0;
		SendAString(PCBuffer,3);// STX-Sec-Command
		SendFisPrnStatus();		//Printer state-Error number

		SendDate();				//Current Date
		SendTime();				//Current Time
		SendETX_BCC();
		return true;
	}
	else
		return false ;
}


/*
 send staus only if some error found befor a command
*/
BYTE FisPrinter_Status_Paper()
{
	ApplVar.ErrorNumber=0;

	CheckPrinter();

	if (ApplVar.ErrorNumber)//ccr090511 && PCBuffer[3]==SEPARATOR)
	{
		BCC = 0;
		SendAString(PCBuffer,3);// STX-Sec-Command
		SendFisPrnStatus();		//Printer state-Error number

		SendDate();				//Current Date
		SendTime();				//Current Time
		SendETX_BCC();
		return true;
	}
	else
		return false ;

}


/*
void	LightLED(BYTE on_off)
{

}

*/

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
//fiscal the ecr 0xa5
//STX + Sec + 0xA5 + 0x1c + command + ETX + BCC
//answer
//STX + SEC + 0xA5 + 0x1c + Print state + 0x1c + fiscal state + ETX + BCC
void FisPrinter_OperatePrivate()
{
	BYTE	sCmdOK=TRUE;
	BYTE	i,j, FieldCount, slen;
	BYTE 	sCom, sbuf[5];
	ULONG   sAddr;
	WORD 	AD0,AD1;

	if(((FieldCount = SetFields()) == 1) && (!BIT(ApplVar.Fiscal_Status, OPENDOC+FISCALDOC)))
	{

			j = FieldNumber[0];
			slen = FieldNumber[1]-j-1;
			if(slen != 2 || CheckDigit((char *)&PCBuffer[j], slen)==-1)
			{
				sCmdOK = FALSE;
			}
			else
				sCom = ((PCBuffer[j] & 0x0f) << 4) | (PCBuffer[j+1] & 0x0f);

	}
	else
		sCmdOK = FALSE;

	if(sCmdOK)
	{
		RESETBIT(ApplVar.Fiscal_Status, UNKNOWNCMD+INVALIDCMD+REJECTED);
		sbuf[0] = PCBuffer[0];
		sbuf[1] = PCBuffer[1];
		sbuf[2] = PCBuffer[2];

		switch (sCom){
#if (PC_EMUKEY)
		case 0x30:
				if (Bios_FM_CheckPresence())
				{
					BCC = 0;

					SendComm(COMPUTER_1,DC2);
					SendComm(COMPUTER_1,DC2);
					SendComm(COMPUTER_1,DC2);
					SendComm(COMPUTER_1,DC2);

					FM_AllErase();
#if (CASE_FATFS_EJ)
					if(MMC_CheckPresence())
					{
						Bios(BiosCmd_SD_Erase, SDRW_Buffer,0,0);
						RamOffSet = BLOCK0*SD_BLOCKSIZE;
						memset(PCBuffer,0xff,256);
						for (i=0;i<2;i++)
							WriteStream(PCBuffer,256,false);
					}
					else
						ApplVar.ErrorNumber=ERROR_ID(CWXXI83);

#endif
					if (Bios_FM_Read(PCBuffer,0, 256))
					{
						j = 0;
						do {
							if (PCBuffer[j]!=0xff)
							{
								ApplVar.ErrorNumber=ERROR_ID(CWXXI78);
								break;
							}
							j++;
						} while (j);
					}
					else
						ApplVar.ErrorNumber=ERROR_ID(CWXXI74);

					sAddr = CLONG(PCBuffer[0]);

				    memset(PCBuffer,' ',sizeof(PCBuffer));
					HEXtoASC(PCBuffer, (BYTE *)&sAddr,4);
					PCBuffer[8] = '|';

					if (!ApplVar.ErrorNumber || ApplVar.ErrorNumber== ERROR_ID(CWXXI83))
						strcpy(PCBuffer+9,MessageE61);
					else
						strcpy(PCBuffer+9,MessageE62);

					SendAString(sbuf,3);// STX-Sec-Command

					SendFisPrnStatus();		//Printer state-Error number

					SendSeparator(SEPARATOR);SendAString(PCBuffer, strlen(PCBuffer));
					SendETX_BCC();

					Delay(2*1000);
					PWFL_FlgOk = 0;
					Reset_int();
					return;
				}
				break;
		case 0x31:// erase EJ
#if (CASE_FATFS_EJ)
				if(MMC_CheckPresence())
				{
					Bios(BiosCmd_SD_Erase, SDRW_Buffer,0,0);
					RamOffSet = BLOCK0*SD_BLOCKSIZE;
					memset(PCBuffer,0xff,256);

					for (i=0;i<2;i++)
						WriteStream(PCBuffer,256,false);

					if (ApplVar.FisCardFlag != BADEJ)
					{
						RamOffSet = BLOCK0*SD_BLOCKSIZE;
						for (i=0;i<2;i++)
						{
							memset(PCBuffer, 0, 256);
							if (ReadFromMMC(PCBuffer,RamOffSet, 256))
							{
								j = 0;
								do {
									if (PCBuffer[j]!=0xff || j==255)
										break;
									j++;
								} while (1);
							}
							else
								break;
							if (PCBuffer[j]!=0xff)
								break;
						}
						if (i<2)
							ApplVar.ErrorNumber=ERROR_ID(CWXXI82);
					}
					else
						ApplVar.ErrorNumber=ERROR_ID(CWXXI84);
				}
				else
					ApplVar.ErrorNumber=ERROR_ID(CWXXI83);

				SendAString(sbuf,3);// STX-Sec-Command
				SendFisPrnStatus();		//Printer state-Error number
				if (ApplVar.ErrorNumber== ERROR_ID(CWXXI82))
				{
					SendSeparator(SEPARATOR);
					SendAByte(i);
					SendToHost('-');
					SendAByte(j);
					SendToHost('=');
					SendAByte(SysBuf[j]);
				}
				SendETX_BCC();
				return;
#else
				break;
#endif
		case 0x39:// test F.M
				if (Bios_FM_CheckPresence())
					for (sAddr=0;sAddr<FISMEMERYSIZE-128 && !CheckComm(COMPUTER_1);sAddr+=128)
					{
					    memset(PCBuffer,' ',sizeof(PCBuffer));
						HEXtoASC(PCBuffer, (BYTE *)&sAddr,4);
						PCBuffer[8] = '|';
						SendString(PCBuffer,9);

						for (i=0;i<64;i++)
						{
							PCBuffer[2*i] = i;
							PCBuffer[2*i+1] = (sAddr>>7) & 0xff;;
						}
						Bios_FM_Write(sAddr, PCBuffer, 128);
						memset(PCBuffer, 0, sizeof(PCBuffer));
						Bios_FM_Read(PCBuffer,sAddr, 128);
						for (i=0;i<64;i++)
						{
							if (PCBuffer[2*i+1] != ((sAddr>>7) & 0xff) || PCBuffer[2*i] != i)
							{
								SendString(PCBuffer,128);
								ApplVar.ErrorNumber=ERROR_ID(CWXXI76);
								SETBIT(ApplVar.Fiscal_Status, FM_ERR);
								break;
							}
						}
						if (i<64)
							break;
					}

				break;
#endif
		case 0x35:// debug
				FisPrinter_Debug();
				return;// ������������״̬ //
		default:
				break;
		}
	}
	else
		SETBIT(ApplVar.Fiscal_Status, INVALIDCMD);

	BCC = 0;
	SendAString(PCBuffer,3);
	SendFisPrnStatus();
	SendETX_BCC();
}

//ccr090918>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
// ����ӡ��,����������������  //

void FisPrinter_Debug()
{

#if !defined(DEBUGBYPC)
	short i,sSecOld,sSecNow;

	CheckFisError();
	HardTest(4096);//��ӡ�ļ������

    if (!ApplVar.ErrorNumber || ApplVar.FisCardFlag!=FMISNEW)
//	if (ApplVar.FisCardFlag!=FMISNEW && ApplVar.FisCardFlag!=NOFM && ApplVar.FisCardFlag!=BADFM && ApplVar.FisCardFlag!=NOEJ)
	{
		return;
	}

#if (CASE_FATFS_EJ == 1)
	RESETBIT(ApplVar.ContFlag, ENSTORE);
	if (!MMC_CheckPresence())
	{
		RJPrint(0, "--------EJ not found!");
	}
	else
	{
		Bios(BiosCmd_SD_Erase, SDRW_Buffer,0,0);
		RamOffSet = BLOCK0*SD_BLOCKSIZE;
		memset(SysBuf,0xff,sizeof(SysBuf));
		for (i=0;i<4;i++)
			WriteStream(SysBuf,sizeof(SysBuf),false);
		if (ApplVar.FisCardFlag != BADEJ)
		{
			memset(SysBuf, 0x55, sizeof(SysBuf));
			if (ReadFromMMC(SysBuf,BLOCK0*SD_BLOCKSIZE, sizeof(SysBuf)))
			{
				for (i=0;i<sizeof(SysBuf);i++)
				{
					if (SysBuf[i]==0x55)
						break;
				}
				if (i!=sizeof(SysBuf))
				{
					RJPrint(0, MsgError[ERROR_ID(CWXXI82)].str);
					PrnBuffer(SysBuf,sizeof(SysBuf));
				}
			}
			else
			{
				RJPrint(0, MsgError[ERROR_ID(CWXXI84)].str);
			}

		}
		else
		{
			RJPrint(0, MsgError[ERROR_ID(CWXXI84)].str);
		}

	}
#endif

/*
	if (!Bios_FM_CheckPresence())
		RJPrint(0, "--------FM not found!");
*/
	TestPrinter();
	TestRomRam();

	TestDateTime();

	TestOpenDrawer();
	TestSerial12();

	sSecOld = 0;

	RESET_Flag = true;//ccr091019 ���¿���ʱ,�Զ����и�λ //
	PWFL_FlgOk = false;// ����û�а����˳����,�������ֻص������� //
	SwitchLedON(100);// 1����˸1һ�� //
	do {
		CheckTime(0x80);
		sSecNow = ((Now.min>>4)*10+(Now.min & 0x0f))*60 + (Now.sec>>4)*10+(Now.sec & 0x0f);
		if(sSecOld != sSecNow)
		{
			sSecOld = sSecNow-sSecOld;
			if (sSecOld<0)
				sSecOld += (60*60);
			i += sSecOld;
			if (i >= 300)
			{
				memset(SysBuf,' ', sizeof(SysBuf));
				DateTimeToStr(SysBuf,3);
				SysBuf[PRTLEN] = 0;
				RJPrint(0,SysBuf);
				i = 0;
			}
			sSecOld = sSecNow ;
		}
	} while (!ReadKey());
	RJPrint(0,DMes[31]);
#endif
}
//<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#endif

